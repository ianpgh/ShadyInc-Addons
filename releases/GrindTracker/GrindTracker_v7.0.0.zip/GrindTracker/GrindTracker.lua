-- v6.5.22: Session accounting, loot log reuse, reload valuation and dungeon history fixes.
-- v6.5.21: Authentic Vanilla (Experimental): native Blizzard dialog art, engraved frames,
-- textured headers and classic normal/pressed/hover button states. All other skins preserved.
-- v6.5.20: Three optional Blizzard-textured skins: Classic Stone, Classic Leather,
-- and Tooltip Frame. Existing skins, opacity, saved preferences and /gt rescue retained.
-- v6.5.19: Header panel switching closes the previously opened panel; preserve main/minis and Escape.
-- v6.5.18: One-step restore for deleted dungeon runs; edit live/saved session names and notes.
-- v6.5.17: Remove redundant Best run GPH line from Dungeon History hover; preserve Personal Best value/time.
-- v6.5.13: One-step Analytics Restore button for accidentally removed loot rows.
--             Keeps original entry and position, with item/quest gold reconciled.
-- v6.5.12: Edit Mode under Start on Login; drag main stats into a saved per-character order.
--             Edit Mode defaults OFF; no changes to tracking, timers or calculations.
-- v6.5.11: Native Escape handling closes addon windows before the WoW game menu opens.
-- v6.5.10: Cumulative session XP survives level-ups; XP/h and next-level ETA keep running.
-- XP snapshots reconcile level transitions, reloads and pauses without double-counting.
-- v6.5.16: Dungeon History hover now shows wing-specific Personal Best
--           (highest earned value, elapsed time and GPH); excludes corrected fragments.
-- v6.5.15: Prefer verified lifetime HK changes for live PvP credit (assists included);
--           show the highest-value saved run for the SAME dungeon/SM wing in live mini.
-- v6.5.14: Scarlet Monastery wing-aware Dungeon History, six-run migration
--           (five pictured runs plus next Cathedral), map/subzone/mob detection,
--           and manual in-dungeon wing override.
-- v6.5.9: Readable history dates (Nov 17, 2026) and 12-hour AM/PM times; raw save timestamps unchanged.
-- v6.5.8: Saved Session History has Line/Pie and optional Quest/PvP stats tabs.
-- v6.5.7: Shift+right-click two saved sessions to select them; confirm Combine to merge totals and charts.
-- v6.5.6: Guard level-up XP ETA overflow and oversized time formatting.
-- v6.5.5: Analytics Quest [Q] pricing mode when Quest Tracker is on;
-- route item vendor value to Quest Coin instead of farm earnings, reversibly.
-- v6.5.4: Show session Repairs Paid under Durability on main tracker when Track Repairs is enabled.
-- v6.5.3: Optional live dungeon-run mini with click-to-expand details;
-- compact tracking health status showing received/handled event diagnostics.
-- v6.5.2: Independent optional main-window durability % + on-hover estimated repair bill;
-- optional verified repair expenses and simple dungeon CSV export.
-- v6.5.1: Shift-click either mini L button to close that mini only;
-- detach snapped pair safely before hiding one bar.
-- v6.5.0: Middle-click either mini L button to snap two visible mini bars;
--         drag the top bar to move the stack, or drag the bottom to detach.
-- Beta 9: Independent Mini Gold/GPH and XP/XP/h windows, toggled via left/right clicks.
-- Beta 8: Label Party Stats optional features as experimental; Beta 7 settings/tracking preserved.
-------------------------------------------------------------------------------
-- Trade exclusion: ignore received trade items and traded gold without adding them to farming totals.
-- PvP double-count fix: verified HK counter deltas, startup guard, event dedupe.
-- Grind Dont Stop  --  WoW Midnight / Forever Edition
-- Dungeon run fix: delayed exit confirmation, ghost reentry and empty-blip filtering.
-- One-time Drowned City history run-count correction (keep all earned gold).
-- 6.3.13: Fix Alt+Shift inventory clicks on mixin-based bag frames.
-- 6.3.12: Alt+Shift+left-click bag items to add to current loot value/GPH.
-- Mailbox fix: exclude attachments collected from mail from session loot.
-- 6.3.13: resume current session across UI reloads and relogs.
-- 6.3.3: Forever colors for active/inactive History and Bestiary tabs.
-- 6.3.2: hover timestamps/earnings and shared-position comparison views.
-- 6.3.1: overlapping gold timelines and paired hourly-rate/time graphs.
-- 6.3.0: compare saved runs by totals and hourly rates; record starting areas.
-- 6.2.2: persist skin and custom-color changes into the active profile so
-- they survive reloads, logouts and automatic profile loading.
-- 6.2.1: rename the WoW skin selector to Forever.
-- 6.2.0: Default, Forever and Custom skin modes. The Forever preset uses the
-- brown-and-gold Classic/Forever frame treatment; Custom uses the existing
-- background, border, accent, header and footer color selectors.
-- Tracks session kills, XP, coin, and item loot value.
--
-- CONFIRMED MIDNIGHT API / FORMAT FACTS:
--   GDS_ItemCompat.GetInfo(itemID) → name,_,quality,_,_,_,_,_,_,_,vendorPrice  (works by number)
--   GetItemLink()       → does NOT exist in Midnight, never call it
--   CHAT_MSG_LOOT format:
--     "You receive loot: |cnIQ2:|Hitem:237362::::::::89:251::::1:38:13:::::|h[Umbral Tin Ore|A:Professions-...|a|h|rx3"
--     • Quality tag ends with COLON: |cnIQ2:   (NOT a pipe)
--     • Item name has NO closing bracket: [Name|A:...  (NOT [Name])
--     • Quantity: last xN in message; absent entirely for single drops
--   AuctionCompanionAPI.GetPriceByItemID → per-unit copper or nil
--
-- /gt         → toggle window
-- /gtr        → toggle window
-- /gt reset   → reset session
-- /gt loot    → toggle loot log
-- /gt debug   → toggle debug output
-- /gt help    → list commands
-------------------------------------------------------------------------------

local ADDON_NAME = "GrindTracker" -- Client support versions are declared in the TOC.
-- This Lua build has its own release identifier so the footer is accurate even
-- when the user's existing TOC retains older version metadata. No TOC edit needed.
local VERSION = "7.0.0"
local DEFAULT_PROFILE_NAME = "Default"

-------------------------------------------------------------------------------
-- Saved variables
-------------------------------------------------------------------------------
GrindTrackerDB = GrindTrackerDB or {}

local DB  -- alias, set on PLAYER_LOGIN
local S   -- session state

local DEFAULT_THEME = {
    bgR=0.025, bgG=0.033, bgB=0.043, bgA=0.92,
    borderR=0.22, borderG=0.31, borderB=0.40,
    accentR=0.88, accentG=0.92, accentB=0.96,
    headerR=0.045, headerG=0.06, headerB=0.078, headerA=0.84,
    footerR=0.045, footerG=0.06, footerB=0.078, footerA=0.84,
}

local WOW_THEME = {
    bgR=0.105, bgG=0.070, bgB=0.032, bgA=0.97,
    borderR=0.58, borderG=0.40, borderB=0.15,
    accentR=0.94, accentG=0.90, accentB=0.80,
    headerR=0.175, headerG=0.105, headerB=0.035, headerA=0.94,
    footerR=0.105, footerG=0.068, footerB=0.028, footerA=0.96,
}

-- Nightfall: dark violet/obsidian with amethyst borders and cool silver text.
-- Global GDS_ namespace avoids an additional top-level Lua local variable.
GDS_NIGHTFALL_THEME = {
    bgR=0.020, bgG=0.015, bgB=0.035, bgA=0.96,
    borderR=0.42, borderG=0.30, borderB=0.62,
    accentR=0.92, accentG=0.89, accentB=0.99,
    headerR=0.070, headerG=0.044, headerB=0.105, headerA=0.96,
    footerR=0.045, footerG=0.027, footerB=0.074, footerA=0.97,
}

-- Fourth experimental preset: modern WoW professions-inspired dark leather,
-- black inset panels, warm gold lettering and carved brass frame accents.
-- This is deliberately NOT the broken full-page/spellbook texture approach.
GDS_WOWLOOK_THEME = {
    -- Blizzard's dark-dialog texture is already dark, so tint it lightly
    -- enough to reveal the original stone/leather detail rather than blacking
    -- it out. This affects WoW Experimental only; Original is untouched.
    bgR=0.51, bgG=0.42, bgB=0.31, bgA=0.98,
    borderR=0.80, borderG=0.60, borderB=0.28,
    accentR=0.94, accentG=0.83, accentB=0.60,
    headerR=0.105, headerG=0.077, headerB=0.045, headerA=0.98,
    footerR=0.075, footerG=0.051, footerB=0.029, footerA=0.98,
}

-- Experimental classic window treatments use only shipped Blizzard UI artwork.
-- No embedded images, custom dependencies, or texture overlays above controls.
GDS_CLASSIC_STONE_THEME = {
    bgR=0.57, bgG=0.55, bgB=0.50, bgA=0.98,
    borderR=0.80, borderG=0.63, borderB=0.33,
    accentR=0.99, accentG=0.87, accentB=0.59,
    headerR=0.12, headerG=0.11, headerB=0.09, headerA=0.96,
    footerR=0.11, footerG=0.10, footerB=0.08, footerA=0.97,
}
GDS_CLASSIC_LEATHER_THEME = {
    bgR=0.68, bgG=0.56, bgB=0.39, bgA=0.98,
    borderR=0.81, borderG=0.58, borderB=0.28,
    accentR=0.99, accentG=0.86, accentB=0.56,
    headerR=0.18, headerG=0.12, headerB=0.065, headerA=0.97,
    footerR=0.14, footerG=0.095, footerB=0.045, footerA=0.97,
}
GDS_TOOLTIP_FRAME_THEME = {
    bgR=0.10, bgG=0.10, bgB=0.15, bgA=0.97,
    borderR=0.57, borderG=0.51, borderB=0.72,
    accentR=0.94, accentG=0.91, accentB=0.99,
    headerR=0.07, headerG=0.065, headerB=0.10, headerA=0.97,
    footerR=0.06, footerG=0.055, footerB=0.09, footerA=0.97,
}

-- Authentic Vanilla is distinct from the older Vanilla color preset:
-- true Blizzard dialog art, textured headings, and real three-state buttons.
-- Theme is optional; original art/controls remain unchanged in other skins.
GDS_AUTHENTIC_VANILLA_THEME = {
    bgR=0.36, bgG=0.29, bgB=0.20, bgA=0.97,
    borderR=0.88, borderG=0.67, borderB=0.33,
    accentR=1.00, accentG=0.87, accentB=0.57,
    headerR=0.15, headerG=0.105, headerB=0.052, headerA=0.97,
    footerR=0.12, footerG=0.082, footerB=0.041, footerA=0.97,
}

local function CopyTheme(src)
    local out = {}
    for k, v in pairs(src or {}) do out[k] = v end
    return out
end

local function ThemesMatch(a, b)
    if type(a) ~= "table" or type(b) ~= "table" then return false end
    for k, v in pairs(b) do
        if type(v) == "number" and math.abs((a[k] or -99) - v) > 0.001 then return false end
    end
    return true
end

local function NewSession()
    return {
        running  = false,
        paused   = false,
        sessionName = "", -- optional descriptive name, saved with session
        sessionNote = "", -- optional note, saved with session
        timer    = 0,
        startXP  = 0, -- legacy baseline; retained for saved-session compatibility
        xpGained = 0,
        xpRawGained = 0, -- cumulative XP across all levels, before quest exclusion
        lastXP = nil, -- most recent character XP snapshot
        lastXPMax = nil, -- cap for the level at that snapshot
        lastXPLevel = nil,
        questXPExcluded = 0,
        questXP = 0,           -- quest rewards earned during this run only
        questGold = 0,
        questItemGold = 0, -- vendor value of Analytics loot classified Quest
        coinGold = 0,
        itemGold = 0,
        repairCosts = 0, -- actual copper paid for repairs; gross earnings unchanged
        kills    = 0,
        pvpHK    = 0,
        pvpKB    = 0,
        questTrackingSeen = false, -- record if Quest Tracker was used this run
        pvpTrackingSeen = false, -- record if PvP Tracking was used this run
        loot     = {},
        mobKills = {},
        coinByMinute = {},
        emaXPH   = 0,
        emaGPH   = 0,
        emaKPH   = 0,
    }
end

-------------------------------------------------------------------------------
-- State
-------------------------------------------------------------------------------
local mainFrame, statRows, miniBar
local lastVisibleStatCount
local minimapBtn
local lootFrame, lootScroll
local lootRowFrames = {}
local settingsFrame
local historyFrame, historyScroll
local historyRowFrames = {}
local historyActiveTab = "sessions"
local historySortCol   = "date"
local historySortDir   = "desc"
local historyTabBtns = {}
local comparisonFrame, comparisonPicking, comparisonA
local addonReady = false
local debugMode  = false
local ticker     = nil
local loginWindowShow = false
local ApplyVisibility
local gphGraphFrame, DrawGphGraph, ToggleGphGraph

-- Optional party-only stat sharing. No loot contents or history are transmitted.
local PARTY_PREFIX = "GDSParty1"
local partyPeers = {}
GDS_PartySync = GDS_PartySync or {}
GDS_PartySync.pendingXP = {}
GDS_PartySync.comm = { lastSend = "not attempted", sentAt = nil, recvAt = nil,
    recvCount = 0, rejected = 0, selfEcho = 0, unreadable = 0, dataCount = 0,
    lastRejectedSender = nil, lastReceivedSender = nil }
local partyFrame, partyMiniFrame
local RefreshPartyStats, SetPartyMiniVisible, EnsurePartyMini
local SendPartyStats
-- Quest rewards are tracked separately from farming totals. The main tracker
-- and Party Stats show QUEST REWARDS FROM THE ACTIVE SESSION, never the older
-- all-time counter. Legacy DB.questTotals remains as the historical tally.
local recentMoneyGain, pendingQuestMoney, pendingQuestUntil = nil, 0, 0
local function QuestTotals()
    if not S or not S.running then return 0, 0 end
    return tonumber(S.questXP) or 0, tonumber(S.questGold) or 0
end
local function PartyAvailable()
    return DB and DB.partyTracking == true and IsInGroup and IsInGroup()
        and not (IsInRaid and IsInRaid())
end
-- WoW may identify party players as Name, Name-Realm, or Name-ConnectedRealm.
-- Validate against party unit identities, not a single expected string format.
function GDS_PartySync.NameParts(text)
    if type(text) ~= "string" or text == "" then return nil end
    if issecretvalue and issecretvalue(text) then return nil end
    -- The party roster may use "Stoneblade-Mudhut" while the addon message
    -- sender comes through as "Stoneblade Mudhut" on some client builds.
    -- Normalize both forms to the same unambiguous character/realm pair.
    local name, realm = text:match("^([^%-]+)%-(.+)$")
    if not name then
        name, realm = text:match("^(%S+)%s+(.+)$")
    end
    if not name then name, realm = text, "" end
    name = name:match("^%s*(.-)%s*$")
    realm = (realm or ""):gsub("%s+", "")
    if name == "" then return nil end
    return name:lower(), realm:lower()
end

-- Party broadcasts can be echoed to the sending client. Ignore them instead
-- of reporting them as unknown party members ("party1".."party4" exclude self).
-- Never use an unverified sender name to create a leaderboard entry.
function GDS_PartySync.IsSelf(sender)
    local short, realm = GDS_PartySync.NameParts(sender)
    if not short then return false end
    local ownName, ownRealm
    if UnitFullName then
        local ok, n, r = pcall(UnitFullName, "player")
        if ok then ownName, ownRealm = n, r end
    end
    if not ownName and UnitName then
        local ok, n, r = pcall(UnitName, "player")
        if ok then ownName, ownRealm = n, r end
    end
    local myShort, embeddedRealm = GDS_PartySync.NameParts(ownName)
    if short ~= myShort then return false end
    if realm == "" then return true end
    local knownRealm = (type(ownRealm) == "string" and ownRealm ~= "" and ownRealm)
        or (embeddedRealm ~= "" and embeddedRealm) or nil
    if not knownRealm and GetRealmName then
        local ok, r = pcall(GetRealmName)
        if ok then knownRealm = r end
    end
    if type(knownRealm) ~= "string" then return false end
    return realm == knownRealm:gsub("%s+", ""):lower()
end

local function PartyMember(sender)
    local senderName, senderRealm = GDS_PartySync.NameParts(sender)
    if not senderName then return false end
    local shortMatches, exactMatches = 0, 0
    -- Iterate the actual party unit IDs. GetNumSubgroupMembers() can report 0
    -- temporarily during roster transitions even while a unit is visible.
    for i=1,4 do
        local unit = "party" .. i
        local exists = not UnitExists or UnitExists(unit)
        if exists then
            local name, realm
            if UnitFullName then
                local ok, n, r = pcall(UnitFullName, unit)
                if ok then name, realm = n, r end
            end
            if not name and UnitName then
                local ok, n, r = pcall(UnitName, unit)
                if ok then name, realm = n, r end
            end
            local unitName, suffix = GDS_PartySync.NameParts(name)
            if unitName == senderName then
                shortMatches = shortMatches + 1
                -- If the roster supplies a realm, prefer the exact identity.
                local knownRealm = (type(realm) == "string" and realm:gsub("%s+", ""):lower()) or suffix
                if knownRealm == "" then knownRealm = suffix end
                if senderRealm == "" or (knownRealm ~= "" and senderRealm == knownRealm) then
                    exactMatches = exactMatches + 1
                end
            end
        end
    end
    -- Fall back to a unique short name only when the unit API did not supply
    -- the realm. A duplicate short name must never identify the wrong player.
    return exactMatches == 1 or (exactMatches == 0 and shortMatches == 1)
end

local function PartySend(message)
    if not PartyAvailable() then return false end
    local sender = (C_ChatInfo and C_ChatInfo.SendAddonMessage) or SendAddonMessage
    if type(sender) ~= "function" then
        GDS_PartySync.comm.lastSend = "addon messaging unavailable"
        return false
    end
    local ok, result = pcall(sender, PARTY_PREFIX, message, "PARTY")
    if not ok then
        GDS_PartySync.comm.lastSend = "error: " .. tostring(result)
        return false
    end
    -- Current clients return a SendAddonMessageResult enum (0=success).
    -- Older versions return a boolean or nil.
    local success = result == nil or result == true or result == 0
    GDS_PartySync.comm.lastSend = success and "queued (delivery unconfirmed)" or ("rejected: " .. tostring(result))
    GDS_PartySync.comm.sentAt = GetTime()
    return success
end


-- Cooperative party sessions: a separate, opt-in run. No party history is stored.
-- The host invites individual addon users, and peers join only after approval.
-- Use one global namespace to avoid Lua's 200-local chunk limit.
GDS_PartySession = GDS_PartySession or {}
GDS_PartySession.capable = {}
GDS_PartySession.pending = {}
GDS_PartySession.peers = {}
GDS_PartySession.active = nil
GDS_PartySession.invite = nil

function GDS_PartySession.Note(text)
    DEFAULT_CHAT_FRAME:AddMessage("|cFFFFD27D[GDS Party Session]|r " .. text)
end
function GDS_PartySession.MyName()
    local name, realm
    if UnitFullName then name, realm = UnitFullName("player") end
    if not name and UnitName then name, realm = UnitName("player") end
    if name and realm and realm ~= "" then return name .. "-" .. realm end
    return name or "Unknown"
end
function GDS_PartySession.SamePlayer(a,b)
    local an,ar = GDS_PartySync.NameParts(a)
    local bn,br = GDS_PartySync.NameParts(b)
    return an and bn and an == bn and (ar == br or ar == "" or br == "")
end
function GDS_PartySession.FindName(map,name)
    for known in pairs(map or {}) do
        if GDS_PartySession.SamePlayer(known,name) then return known end
    end
    return nil
end
function GDS_PartySession.Active()
    local a = GDS_PartySession.active
    return a and a.running and not a.paused and PartyAvailable()
end
function GDS_PartySession.New(id,host,isHost)
    return {id=id,host=host,isHost=isHost == true,running=true,paused=false,
        timer=0,coin=0,items=0,repairs=0,xpRaw=0,questXP=0,questXPExcluded=0,questGold=0,pvpHK=0,pvpKB=0,
        lastXP=UnitXP("player") or 0,lastXPMax=UnitXPMax("player") or 1,
        lastLevel=UnitLevel("player") or 1,accepted={},manualIDs={}}
end
function GDS_PartySession.SendCaps()
    if PartyAvailable() then PartySend("PSCAP") end
end
function GDS_PartySession.Start()
    if not PartyAvailable() then
        GDS_PartySession.Note("Enable P and join a party before starting a shared session.")
        return
    end
    if GDS_PartySession.active then
        GDS_PartySession.Note("End the current party session first.")
        return
    end
    DB.partySessionSerial = (tonumber(DB.partySessionSerial) or 0) + 1
    local stamp = (GetServerTime and GetServerTime()) or time()
    local id = tostring(math.floor(stamp)) .. tostring(DB.partySessionSerial)
    local own = GDS_PartySession.MyName()
    GDS_PartySession.active = GDS_PartySession.New(id,own,true)
    GDS_PartySession.UpdateDungeon()
    GDS_PartySession.peers = {}
    GDS_PartySession.pending = {}
    GDS_PartySession.Note("Session started. Invite party members below.")
    GDS_PartySession.SendCaps()
    GDS_PartySession.Refresh()
end
function GDS_PartySession.Invite(name)
    local a = GDS_PartySession.active
    if not a or not a.isHost or not PartyAvailable() then return end
    if not GDS_PartySession.capable[name]
        or GetTime() - GDS_PartySession.capable[name] > 90 then
        GDS_PartySession.Note("That player has not announced a compatible addon recently.")
        return
    end
    if a.accepted[name] then return end
    GDS_PartySession.pending[name] = true
    PartySend("PSINVITE:" .. a.id .. ":" .. name)
    GDS_PartySession.Note("Invitation sent to " .. name)
    GDS_PartySession.Refresh()
end
function GDS_PartySession.Respond(yes)
    local request = GDS_PartySession.invite
    if not request or not PartyAvailable() then return end
    GDS_PartySession.invite = nil
    if GDS_PartySession.inviteFrame then GDS_PartySession.inviteFrame:Hide() end
    if yes then
        if GDS_PartySession.active then
            GDS_PartySession.Note("You're already in a party session. End it before joining another.")
            PartySend("PSDECLINE:"..request.id)
            return
        end
        GDS_PartySession.active = GDS_PartySession.New(request.id,request.host,false)
        GDS_PartySession.UpdateDungeon()
        GDS_PartySession.peers = {}
        PartySend("PSACCEPT:" .. request.id)
        GDS_PartySession.SendStats()
        GDS_PartySession.Note("Joined " .. request.host .. "'s party session.")
    else
        PartySend("PSDECLINE:" .. request.id)
        GDS_PartySession.Note("Declined the party session invitation.")
    end
    GDS_PartySession.Refresh()
end
function GDS_PartySession.Stop()
    local a = GDS_PartySession.active
    if not a then return end
    if PartyAvailable() then
        if a.isHost then PartySend("PSEND:" .. a.id)
        else PartySend("PSLEAVE:" .. a.id) end
    end
    GDS_PartySession.FinishDungeon()
    GDS_PartySession.active = nil
    GDS_PartySession.peers = {}
    GDS_PartySession.pending = {}
    DB.activePartySession = nil
    GDS_PartySession.Note("Party session ended. Personal tracking was not changed.")
    GDS_PartySession.Refresh()
end
function GDS_PartySession.TogglePause()
    local a = GDS_PartySession.active
    if not a or not a.isHost then return end
    a.paused = not a.paused
    a.lastXP=UnitXP("player") or 0
    a.lastXPMax=UnitXPMax("player") or 1
    a.lastLevel=UnitLevel("player") or 1
    PartySend((a.paused and "PSPAUSE:" or "PSRESUME:") .. a.id)
    GDS_PartySession.SendStats()
    GDS_PartySession.Refresh()
end
function GDS_PartySession.OnXP()
    local a = GDS_PartySession.active
    if not a then return end
    local cur = UnitXP("player") or 0
    local cap = math.max(1, UnitXPMax("player") or 1)
    local level = UnitLevel("player") or 1
    local prior, oldMax, oldLevel = a.lastXP or cur, a.lastXPMax or cap, a.lastLevel or level
    if level == oldLevel and cur < prior and GDS_PartySession.Active() then return end
    a.lastXP, a.lastXPMax, a.lastLevel = cur,cap,level
    if not GDS_PartySession.Active() then return end
    local gain = cur - prior
    if level > oldLevel then gain = math.max(0,oldMax-prior) + cur end
    if level >= oldLevel and gain > 0 then a.xpRaw = a.xpRaw + math.min(gain, 2000000) end
end
function GDS_PartySession.AddItem(total,id,manual)
    local a=GDS_PartySession.active
    if not GDS_PartySession.Active() then return end
    if manual and id and a.manualIDs[id] then return end
    if manual and id then a.manualIDs[id]=true end
    a.items = a.items + math.max(0,tonumber(total) or 0)
end
function GDS_PartySession.AddCoin(amount)
    local a=GDS_PartySession.active
    if GDS_PartySession.Active() then
        a.coin=a.coin+math.max(0, tonumber(amount) or 0)
    end
end
function GDS_PartySession.OnQuest(xp,gold)
    local a=GDS_PartySession.active
    if GDS_PartySession.Active() then
        -- Exclude quest XP from shared farming XP even with the Quest Tracker hidden.
        -- Keep display-only totals conditional on the checkbox.
        a.questXPExcluded = (a.questXPExcluded or 0) + math.max(0, tonumber(xp) or 0)
        if DB.questTracking then
            a.questXP = a.questXP + math.max(0, tonumber(xp) or 0)
            a.questGold = a.questGold + math.max(0, tonumber(gold) or 0)
        end
    end
end
function GDS_PartySession.OnPvP(kind,amount)
    local a=GDS_PartySession.active
    if GDS_PartySession.Active() and DB.pvpTracking then
        a[kind]=(a[kind] or 0)+amount
    end
end

-- Party-only dungeon runs go into the existing local Dungeon history.
-- Never record a second copy when the personal tracker already owns the run.
function GDS_PartySession.FinishDungeon()
    local a=GDS_PartySession.active
    local run=a and a.dungeonCurrent
    if not run then return end
    a.dungeonCurrent=nil
    if not DB then return end
    local elapsed=math.max(0,(a.timer or 0)-(run.startTime or 0))
    local coin=math.max(0,(a.coin or 0)-(run.startCoin or 0))
    local items=math.max(0,(a.items or 0)-(run.startItems or 0))
    local repairs=math.max(0,(a.repairs or 0)-(run.startRepairs or 0))
    if elapsed < 8 and coin==0 and items==0 then return end
    DB.dungeonRuns=DB.dungeonRuns or {}
    table.insert(DB.dungeonRuns,1,{
        dungeon=GDS_Dungeon.SavedName(run.name, run.wing),instanceID=run.instanceID,
        date=date("%Y-%m-%d %H:%M"),duration=elapsed,coin=coin,items=items,repairCosts=repairs,lootItems=run.lootItems,
    })
    GDS_LiveDungeon.historySummary = nil
    if RefreshHistory then RefreshHistory() end
end
function GDS_PartySession.UpdateDungeon()
    local a=GDS_PartySession.active
    if not a or not a.running then return end
    -- Personal sessions already record the local character's dungeon activity.
    if S and S.running then
        a.dungeonCurrent=nil
        return
    end
    if not PartyAvailable() then return end
    local name,kind,_,_,_,_,_,id=GetInstanceInfo()
    local inside=kind=="party" and type(name)=="string" and name~=""
    local wing,source
    if inside then wing,source=GDS_Dungeon.DetectWing(name) end
    local run=a.dungeonCurrent
    local same=inside and run and run.name==name
        and (not id or not run.instanceID or id==run.instanceID)
    if same and not run.resetConfirmed and not GDS_Dungeon.CanReplaceWing(run,wing,source) then
        if wing and not run.wing then run.wing,run.wingSource=wing,source end
        run.exitPendingAt=nil
        -- The same instance after a graveyard/ghost trip is one run.
        if run.deathOutsideSeen or not (UnitIsDeadOrGhost and UnitIsDeadOrGhost("player")) then
            run.deathRecovery=nil
            run.deathOutsideSeen=nil
        end
        return
    end
    if run and same and GDS_Dungeon.CanReplaceWing(run,wing,source) then
        -- Different SM wing, but the same instance map ID. Split immediately.
        GDS_PartySession.FinishDungeon()
        run=nil
    end
    if run then
        if not same then
            if UnitIsDeadOrGhost and UnitIsDeadOrGhost("player") then
                run.deathRecovery=true
                run.deathOutsideSeen=true
                run.exitPendingAt=nil
                return
            end
            -- Resurrection outside after a death must never split the run.
            if run.deathRecovery and not run.resetConfirmed then return end
        end
        if not run.resetConfirmed then
            run.exitPendingAt=run.exitPendingAt or GetTime()
            if GetTime()-run.exitPendingAt<8 then return end
        end
        GDS_PartySession.FinishDungeon()
    end
    if inside then
        a.dungeonCurrent={lootItems={}, name=name,instanceID=id,wing=wing,wingSource=source,startTime=a.timer,
            startCoin=a.coin,startItems=a.items,startRepairs=a.repairs or 0}
    end
end

function GDS_PartySession.SendStats()
    local a=GDS_PartySession.active
    if not a or not PartyAvailable() then return end
    local xp=math.max(0, math.floor(a.xpRaw-(a.questXPExcluded or a.questXP or 0)))
    PartySend(("PSDATA:%s:%d:%d:%d:%d:%d:%d:%d:%d:%d"):format(
        a.id, math.floor(a.timer),math.floor(a.coin),math.floor(a.items),
        xp,math.floor(a.questXP),math.floor(a.questGold),
        math.floor(a.pvpHK),math.floor(a.pvpKB),a.paused and 1 or 0))
end
function GDS_PartySession.OnMessage(sender,message)
    if message == "PSCAP" then
        GDS_PartySession.capable[sender] = GetTime()
        GDS_PartySession.Refresh()
        return true
    end
    local id,target = message:match("^PSINVITE:(%d+):(.+)$")
    if id then
        if GDS_PartySync.IsSelf(target) then
            if GDS_PartySession.active then
                PartySend("PSDECLINE:"..id)
            elseif not GDS_PartySession.invite or GDS_PartySession.invite.id ~= id then
                GDS_PartySession.invite={id=id,host=sender}
                -- Do not call Blizzard's StaticPopup_Show from an incoming addon
                -- packet. Its protected popup management can taint Blizzard UI.
                -- Our own ordinary frame has no secure actions or templates.
                GDS_PartySession.ShowInvite()
            end
        end
        return true
    end
    id=message:match("^PSACCEPT:(%d+)$")
    if id then
        local a=GDS_PartySession.active
        local pendingName=GDS_PartySession.FindName(GDS_PartySession.pending,sender)
        if a and a.isHost and a.id==id and pendingName then
            a.accepted[sender]=true
            GDS_PartySession.pending[pendingName]=nil
            GDS_PartySession.Note(sender.." joined the party session.")
            GDS_PartySession.SendStats()
            GDS_PartySession.Refresh()
        end
        return true
    end
    id=message:match("^PSDECLINE:(%d+)$")
    if id then
        local a=GDS_PartySession.active
        if a and a.isHost and a.id==id then
            local pendingName=GDS_PartySession.FindName(GDS_PartySession.pending,sender)
            if pendingName then GDS_PartySession.pending[pendingName]=nil end
            GDS_PartySession.Note(sender.." declined the invitation.")
            GDS_PartySession.Refresh()
        end
        return true
    end
    id=message:match("^PSLEAVE:(%d+)$")
    if id then
        local a=GDS_PartySession.active
        if a and a.isHost and a.id==id then
            local name=GDS_PartySession.FindName(a.accepted,sender)
            if name then a.accepted[name]=nil end
            for peerName in pairs(GDS_PartySession.peers) do
                if GDS_PartySession.SamePlayer(peerName,sender) then
                    GDS_PartySession.peers[peerName]=nil
                end
            end
            GDS_PartySession.Note(sender.." left the party session.")
            GDS_PartySession.Refresh()
        end
        return true
    end
    id=message:match("^PSEND:(%d+)$")
    if id then
        local a=GDS_PartySession.active
        if a and a.id==id and not a.isHost and GDS_PartySession.SamePlayer(sender,a.host) then
            GDS_PartySession.Stop()
        end
        return true
    end
    local verb, stateID=message:match("^(PSPAUSE):(%d+)$")
    if not verb then verb,stateID=message:match("^(PSRESUME):(%d+)$") end
    if verb then
        local a=GDS_PartySession.active
        if a and a.id==stateID and not a.isHost
            and GDS_PartySession.SamePlayer(sender,a.host) then
            a.paused=(verb=="PSPAUSE")
            a.lastXP=UnitXP("player") or 0
            a.lastXPMax=UnitXPMax("player") or 1
            a.lastLevel=UnitLevel("player") or 1
            GDS_PartySession.Refresh()
        end
        return true
    end
    local sid,timer,coin,items,xp,qxp,qgold,hk,kb,paused = message:match(
        "^PSDATA:(%d+):(%d+):(%d+):(%d+):(%d+):(%d+):(%d+):(%d+):(%d+):([01])$")
    if sid then
        local a=GDS_PartySession.active
        if a and a.id==sid and (not a.isHost and GDS_PartySession.SamePlayer(sender,a.host)
            or a.isHost and GDS_PartySession.FindName(a.accepted,sender)) then
            if not a.isHost and GDS_PartySession.SamePlayer(sender,a.host) then
                local wasPaused=a.paused
                a.paused=paused=="1"
                if wasPaused ~= a.paused then
                    a.lastXP=UnitXP("player") or 0
                    a.lastXPMax=UnitXPMax("player") or 1
                    a.lastLevel=UnitLevel("player") or 1
                end
            end
            GDS_PartySession.peers[sender]={timer=tonumber(timer),coin=tonumber(coin),
                items=tonumber(items),xp=tonumber(xp),questXP=tonumber(qxp),
                questGold=tonumber(qgold),pvpHK=tonumber(hk),pvpKB=tonumber(kb),
                questOn=true,pvpOn=true,running=paused=="0",received=GetTime()}
            GDS_PartySession.Refresh()
        end
        return true
    end
    return false
end
function GDS_PartySession.RosterChanged()
    if not PartyAvailable() then
        if GDS_PartySession.active then GDS_PartySession.Stop() end
        GDS_PartySession.capable={}
        GDS_PartySession.invite=nil
        if GDS_PartySession.inviteFrame then GDS_PartySession.inviteFrame:Hide() end
        return
    end
    GDS_PartySession.SendCaps()
    C_Timer.After(2,function()
        if PartyAvailable() then GDS_PartySession.SendCaps(); GDS_PartySession.SendStats() end
    end)
end
function GDS_PartySession.Refresh()
    if GDS_PartySession.RefreshUI then GDS_PartySession.RefreshUI() end
    if RefreshPartyStats then RefreshPartyStats() end
end
-- Only invited members are tracked; compat detection does not auto-enroll anyone.
-- A self-contained invitation frame avoids touching Blizzard's StaticPopupDialogs
-- table or StaticPopup_Show.  All controls are plain, non-protected frames.
function GDS_FocusWindow(frame)
    frame:SetFrameStrata("DIALOG")
    frame:SetToplevel(true)
    frame:HookScript("OnShow", function(self) self:Raise() end)
end

function GDS_PartySession.EnsureInviteFrame()
    local f=GDS_PartySession.inviteFrame
    if f then return f end
    f=CreateFrame("Frame", "GDSPartySessionInvitation", UIParent,
        BackdropTemplateMixin and "BackdropTemplate" or nil)
    GDS_FocusWindow(f)
    f:SetSize(350,137)
    f:SetPoint("CENTER",UIParent,"CENTER",0,120)
    f:SetFrameStrata("DIALOG")
    f:EnableMouse(true)
    if f.SetClampedToScreen then f:SetClampedToScreen(true) end
    if f.SetBackdrop then
        f:SetBackdrop({bgFile="Interface\\Buttons\\WHITE8X8",
            edgeFile="Interface\\Buttons\\WHITE8X8",edgeSize=1})
        f:SetBackdropColor(.035,.042,.053,.96)
        f:SetBackdropBorderColor(.42,.35,.18,1)
    else
        local bg=f:CreateTexture(nil,"BACKGROUND")
        bg:SetAllPoints()
        bg:SetColorTexture(.035,.042,.053,.96)
    end
    local title=f:CreateFontString(nil,"OVERLAY","GameFontNormal")
    title:SetPoint("TOP",f,"TOP",0,-13)
    title:SetText("Party Grind Don't Stop")
    local msg=f:CreateFontString(nil,"OVERLAY","GameFontHighlightSmall")
    msg:SetPoint("TOPLEFT",f,"TOPLEFT",14,-39)
    msg:SetPoint("TOPRIGHT",f,"TOPRIGHT",-14,-39)
    msg:SetJustifyH("CENTER")
    msg:SetText("Party session invitation")
    f.message=msg
    local function Button(label,x,approve)
        local b=CreateFrame("Button",nil,f)
        b:SetSize(118,26)
        b:SetPoint("BOTTOM",f,"BOTTOM",x,14)
        local bg=b:CreateTexture(nil,"BACKGROUND")
        bg:SetAllPoints()
        bg:SetColorTexture(.12,.15,.19,.96)
        local txt=b:CreateFontString(nil,"OVERLAY","GameFontNormalSmall")
        txt:SetAllPoints()
        txt:SetText(label)
        b:SetScript("OnEnter",function() bg:SetColorTexture(.20,.25,.30,1) end)
        b:SetScript("OnLeave",function() bg:SetColorTexture(.12,.15,.19,.96) end)
        b:SetScript("OnClick",function()
            f:Hide()
            GDS_PartySession.Respond(approve)
        end)
    end
    Button("Accept",-64,true)
    Button("Decline",64,false)
    f:Hide()
    GDS_PartySession.inviteFrame=f
    return f
end
function GDS_PartySession.ShowInvite()
    local req=GDS_PartySession.invite
    if not req then return end
    local f=GDS_PartySession.EnsureInviteFrame()
    f.message:SetText((req.host or "A party member") ..
        " invites you to a shared farming session. Join?")
    f:Show()
    GDS_PartySession.Note("Invite received. Accept or decline in the window; /gt partyaccept and /gt partydecline also work.")
end

-- Report the exact protected action, if the client supplies one. WoW sometimes
-- reports UNKNOWN; in that case we need the precise action that triggered it.
function GDS_PartySession.InstallActionDiagnostics()
    if GDS_PartySession.blockFrame then return end
    local f=CreateFrame("Frame",nil)
    f:RegisterEvent("ADDON_ACTION_BLOCKED")
    f:RegisterEvent("ADDON_ACTION_FORBIDDEN")
    f:SetScript("OnEvent",function(_,event,addonName,action)
        if type(addonName)=="string" and addonName:find("GrindTracker",1,true) then
            GDS_PartySession.Note("UI protection: " .. event .. " / " ..
                tostring(action or "unknown") .. ". Please share the action name.")
        end
    end)
    GDS_PartySession.blockFrame=f
end
GDS_PartySession.InstallActionDiagnostics()

local function ClearPartyPeers()
    partyPeers = {}
    GDS_PartySync.pendingXP = {}
    if RefreshPartyStats then RefreshPartyStats() end
end
-- Lifetime *party* killing-blow scoreboard. This is NOT the game's lifetime
-- PvP statistic: only unique KB events observed while grouped and opted in count.
-- Keep this separate from PvP resets and saved session/party peer snapshots.
GDS_KBBoard = GDS_KBBoard or {}

function GDS_KBBoard.Key(name)
    if type(name) ~= "string" or name == "" then return nil end
    -- Same-realm addon senders sometimes omit the realm suffix. Normalize them
    -- to match our locally recorded character and avoid duplicate entries.
    if not name:find("-", 1, true) then
        local realm = (GetRealmName and GetRealmName()) or ""
        if type(realm) == "string" and realm ~= "" then
            realm = realm:gsub("%s+", "")
            name = name .. "-" .. realm
        end
    end
    return name:lower(), name
end

function GDS_KBBoard.Record(name, token, isSelf)
    if not DB or type(token) ~= "string"
        or not token:match("^%d+:%d+$") then return false end
    local key, display = GDS_KBBoard.Key(name)
    if not key then return false end
    DB.partyKBLifetime = type(DB.partyKBLifetime) == "table" and DB.partyKBLifetime or {}
    local row = DB.partyKBLifetime[key]
    if type(row) ~= "table" then
        row = {name=display, count=0, seen={}, recent={}}
        DB.partyKBLifetime[key] = row
    end
    row.name = display
    row.seen = type(row.seen) == "table" and row.seen or {}
    row.recent = type(row.recent) == "table" and row.recent or {}
    if row.seen[token] then return false end
    row.seen[token] = true
    table.insert(row.recent, token)
    -- Bounded dedup history: prevents repeat party messages from double-counting
    -- after reloads without letting SavedVariables grow unbounded.
    while #row.recent > 256 do
        local oldest = table.remove(row.recent, 1)
        row.seen[oldest] = nil
    end
    row.count = math.max(0, math.floor(tonumber(row.count) or 0)) + 1
    if isSelf then row.selfPlayer = true end
    if GDS_KBBoard.Refresh then GDS_KBBoard.Refresh() end
    return true
end

function GDS_KBBoard.OnLocalKB()
    -- Only real, personally detected KBs while in a party are recorded.
    -- Everyone else must also use this addon with Party + PvP enabled to send KBs.
    if not DB or not DB.pvpTracking or not PartyAvailable() then return end
    DB.partyKBSerial = math.max(0, math.floor(tonumber(DB.partyKBSerial) or 0)) + 1
    local stamp = math.max(0, math.floor(tonumber(DB.partyKBStamp) or 0))
    local token = stamp .. ":" .. DB.partyKBSerial
    local name, realm = UnitFullName and UnitFullName("player")
    if not name and UnitName then name = UnitName("player") end
    if name and realm and realm ~= "" then name = name .. "-" .. realm end
    if name then GDS_KBBoard.Record(name, token, true) end
    -- A unique event is sent once at the moment of the KB; no session or
    -- lifetime counts are imported from joins, periodic syncs, or reloads.
    PartySend("KB:" .. token)
end

local function OnPartyMessage(prefix, message, channel, sender)
    if prefix ~= PARTY_PREFIX or not PartyAvailable() then return end
    -- An instance group can report INSTANCE_CHAT for the same party message.
    if channel ~= "PARTY" and channel ~= "INSTANCE_CHAT" then return end
    if GDS_PartySync.IsSelf(sender) then
        GDS_PartySync.comm.selfEcho = GDS_PartySync.comm.selfEcho + 1
        return
    end
    if type(message) ~= "string" then
        GDS_PartySync.comm.unreadable = GDS_PartySync.comm.unreadable + 1
        return
    end
    if not PartyMember(sender) then
        GDS_PartySync.comm.rejected = GDS_PartySync.comm.rejected + 1
        if type(sender) == "string" and not (issecretvalue and issecretvalue(sender)) then
            GDS_PartySync.comm.lastRejectedSender = sender
        end
        if debugMode then
            DEFAULT_CHAT_FRAME:AddMessage("|cFFFFAA00[GT Party]|r Unrecognized sender: "
                .. tostring(GDS_PartySync.comm.lastRejectedSender or "unreadable"))
        end
        return
    end
    GDS_PartySync.comm.recvAt = GetTime()
    GDS_PartySync.comm.recvCount = GDS_PartySync.comm.recvCount + 1
    GDS_PartySync.comm.lastReceivedSender = sender
    local dungeonResetName = message:match("^DRESET:(.+)$")
    if dungeonResetName then
        if GDS_Dungeon and GDS_Dungeon.OnConfirmedReset then
            GDS_Dungeon.OnConfirmedReset(dungeonResetName)
        end
        return
    end
    if GDS_PartySession.OnMessage(sender,message) then return end
    local kbStamp, kbSerial = message:match("^KB:(%d+):(%d+)$")
    if kbStamp then
        -- Sender must be an actual party member; counted only once per event.
        GDS_KBBoard.Record(sender, kbStamp .. ":" .. kbSerial)
        return
    end
    -- Grind XP travels as an optional extension so older addon versions still
    -- receive the original DATA packet unchanged. Only group members are read.
    local grindXP = message:match("^XP:(%d+)$")
    if grindXP then
        local peer = partyPeers[sender]
        local xp = math.min(tonumber(grindXP) or 0, 100000000)
        if peer then
            peer.xp = xp
            if RefreshPartyStats then RefreshPartyStats() end
        else
            -- An XP packet can precede the sender's first DATA packet.
            GDS_PartySync.pendingXP[sender] = xp
        end
        return
    end
    if message == "OFF" then
        partyPeers[sender] = nil
    elseif message == "HELLO" then
        if SendPartyStats then SendPartyStats() end
    else
        -- New clients also send optional PvP session HK / KB totals. Keep the
        -- previous payloads readable so mixed addon versions cannot break sync.
        local timer, coin, items, kills, running, questXP, questGold, questOn, pvpHK, pvpKB, pvpOn =
            message:match("^DATA:(%d+):(%d+):(%d+):(%d+):([01]):(%d+):(%d+):([01]):(%d+):(%d+):([01])$")
        if not timer then
            timer, coin, items, kills, running, questXP, questGold, questOn =
                message:match("^DATA:(%d+):(%d+):(%d+):(%d+):([01]):(%d+):(%d+):([01])$")
        end
        if not timer then
            timer, coin, items, kills, running =
                message:match("^DATA:(%d+):(%d+):(%d+):(%d+):([01])$")
        end
        if not timer then return end
        GDS_PartySync.comm.dataCount = GDS_PartySync.comm.dataCount + 1
        -- Preserve a previously delivered XP extension across the regular
        -- DATA refresh. Old clients never send XP and remain visibly unknown.
        local previousXP = (partyPeers[sender] and partyPeers[sender].xp)
            or GDS_PartySync.pendingXP[sender]
        GDS_PartySync.pendingXP[sender] = nil
        partyPeers[sender] = {
            xp=previousXP,
            timer=math.min(tonumber(timer), 100000000),
            coin=math.min(tonumber(coin), 1000000000000),
            items=math.min(tonumber(items), 1000000000000),
            kills=math.min(tonumber(kills), 100000000),
            running=running=="1", received=GetTime(),
            questXP=tonumber(questXP) or 0, questGold=tonumber(questGold) or 0,
            questOn=questOn == "1",
            pvpHK=math.min(tonumber(pvpHK) or 0, 100000000),
            pvpKB=math.min(tonumber(pvpKB) or 0, 100000000),
            pvpOn=pvpOn == "1",
        }
    end
    if RefreshPartyStats then RefreshPartyStats() end
end
SendPartyStats = function()
    if not PartyAvailable() then return end
    local active = S and S.running and not S.paused
    local qxp, qgold = QuestTotals()
    -- PvP is opt-in, as is sharing. Transmit only the two aggregate session
    -- counters, never opponent names or individual encounter information.
    local pvpEnabled = DB.pvpTracking == true
    PartySend(("DATA:%d:%d:%d:%d:%d:%d:%d:%d:%d:%d:%d"):format(
        math.max(0, math.floor(S and S.timer or 0)),
        math.max(0, math.floor(S and S.coinGold or 0)),
        math.max(0, math.floor(S and S.itemGold or 0)),
        math.max(0, math.floor(S and S.kills or 0)), active and 1 or 0,
        math.max(0, math.floor(qxp)), math.max(0, math.floor(qgold)),
        DB.questTracking and 1 or 0,
        pvpEnabled and math.max(0, math.floor(S and S.pvpHK or 0)) or 0,
        pvpEnabled and math.max(0, math.floor(S and S.pvpKB or 0)) or 0,
        pvpEnabled and 1 or 0))
    -- Only the existing non-quest farming XP is shared; no XP/h is sent.
    PartySend(("XP:%d"):format(math.max(0, math.floor(S and S.xpGained or 0))))
end
local function PartyRosterChanged()
    ClearPartyPeers()
    GDS_PartySession.RosterChanged()
    if PartyAvailable() then
        PartySend("HELLO")
        SendPartyStats()
        -- Roster events can precede fully populated party1..party4 unit IDs.
        -- Retry once after that short transition, without waiting 10 seconds.
        C_Timer.After(2, function()
            if PartyAvailable() then PartySend("HELLO"); SendPartyStats() end
        end)
    end
end

-- Local diagnostics: never requires the other player to reveal private data.
function GDS_PartySync.PrintStatus()
    local function msg(line)
        DEFAULT_CHAT_FRAME:AddMessage("|cFFFFD27D[GT Party]|r " .. line)
    end
    msg("Sharing: " .. ((DB and DB.partyTracking) and "ON" or "OFF")
        .. " | Group: " .. ((IsInGroup and IsInGroup()) and "yes" or "no")
        .. " | Last send: " .. tostring(GDS_PartySync.comm.lastSend))
    local shared = GDS_PartySession.active
    if shared then
        local n=0
        for _ in pairs(shared.accepted or {}) do n=n+1 end
        msg("Shared session: " .. (shared.isHost and "Hosting" or "Joined")
            .. (shared.paused and " (paused)" or " (running)")
            .. " | ID: " .. shared.id .. " | Accepted peers: " .. n)
    else
        msg("Shared session: Not started")
    end
    local members = 0
    for i=1,4 do
        local unit = "party" .. i
        if not UnitExists or UnitExists(unit) then
            local n, r
            if UnitFullName then
                local ok, name, realm = pcall(UnitFullName, unit)
                if ok then n, r = name, realm end
            end
            if not n and UnitName then
                local ok, name, realm = pcall(UnitName, unit)
                if ok then n, r = name, realm end
            end
            if n then
                members = members + 1
                local label = n .. ((r and r ~= "") and ("-" .. r) or "")
                local online = false
                local ago
                for sender, peer in pairs(partyPeers) do
                    if PartyMember(sender) and GDS_PartySync.NameParts(sender) == GDS_PartySync.NameParts(n) then
                        online = true
                        ago = math.floor(math.max(0, GetTime() - (peer.received or GetTime())))
                    end
                end
                msg(label .. (online and (" — syncing (" .. ago .. "s ago)")
                    or " — waiting for addon stats"))
            end
        end
    end
    if members == 0 then msg("No other visible party members") end
    msg("Peer packets: " .. GDS_PartySync.comm.recvCount
        .. " | Stats packets: " .. GDS_PartySync.comm.dataCount)
    msg("Self-echoes ignored: " .. GDS_PartySync.comm.selfEcho
        .. " | Unknown senders: " .. GDS_PartySync.comm.rejected
        .. " | Unreadable: " .. GDS_PartySync.comm.unreadable)
    if GDS_PartySync.comm.lastRejectedSender then
        msg("Last unknown sender: " .. GDS_PartySync.comm.lastRejectedSender)
    end
    if GDS_PartySync.comm.lastReceivedSender then
        msg("Last accepted sender: " .. GDS_PartySync.comm.lastReceivedSender)
    end
    if C_ChatInfo and type(C_ChatInfo.InChatMessagingLockdown) == "function" then
        local ok, locked = pcall(C_ChatInfo.InChatMessagingLockdown)
        if ok and locked then
            msg("Chat lockdown ACTIVE: live addon sharing may be unavailable.")
        end
    end
    if IsInInstance then
        local ok, inside = pcall(IsInInstance)
        if ok and inside then
            msg("Inside instance: compare sync again outside the dungeon.")
        end
    end
    if members > 0 and not next(partyPeers) then
        msg("Confirm friends installed the same addon and enabled the P checkbox.")
    end
    if PartyAvailable() then PartySend("HELLO"); SendPartyStats() end
end

-- Theme-aware UI refs for live recoloring
local GT_frames    = {}   -- frames using ApplyBackdrop (backdrop bg + border)
local GT_titles    = {}   -- title FontStrings (accent color)
local GT_btnEdges  = {}   -- {tex,...} per button (border color)
local GT_btnLabels = {}   -- button label FontStrings (accent color)
local GT_btnBgs    = {}   -- button background textures
local GT_thumbs    = {}   -- scrollbar thumb textures (border color)
local GT_dividers  = {}   -- divider bar textures (border color)
local GT_headers   = {}   -- header background textures (header color)
local GT_footers   = {}   -- footer background textures (footer color)
local GT_headerRules = {} -- header divider textures (header visibility)
local GT_footerRules = {} -- footer divider textures (footer visibility)
local GT_cbBorders = {}   -- checkbox border textures (border color)
local GT_softPanels = {}  -- soft inset panel/row backgrounds
local GT_texts     = setmetatable({}, { __mode = "k" }) -- themed body text FontStrings

-- Analytics tab state
local activeTab         = "log"
local chartFrames       = {}
local lootTabBtns       = {}
local pastAnalyticsFrame = nil
local mainChartFrame    = nil
local mainChartKey      = "stats"  -- "stats"|"line"|"bar"|"pie"
local mainContentClip   = nil      -- set in BuildMainFrame, used by SetMainChart

local watchedTarget  = nil   -- kept for lastKillName / loot source tagging
local lastKillName   = nil
local lastKillTime   = 0
local moneyBaseline  = 0
local merchantOpen = false -- prevent vendor sales being counted twice
-- Multi-unit kill tracking (taint-free, no combat log)
-- Maps unitID → { name } for every hostile we currently see alive
local watchedUnits   = {}
local deadKills      = {}   -- "time-bucket|name" → true, prevents double-count on re-fire

-------------------------------------------------------------------------------
-- Utilities
-------------------------------------------------------------------------------
local function StopTicker()
    if ticker and not ticker:IsCancelled() then ticker:Cancel() end
    ticker = nil
end

local FormatTime, FmtShort, FmtNum, FmtK, Coin, CoinShort
do
    local formatting = {}
    function formatting.FormatTime(sec)
        -- Formatting a runaway ETA with %d can overflow the client's integer range.
        if type(sec) ~= "number" or sec ~= sec or sec == math.huge or sec == -math.huge then
            return "---"
        end
        sec = math.max(0, math.floor(sec))
        if sec > 359999996 then return "---" end -- never format >99,999 hours
        return ("%02d:%02d:%02d"):format(
            math.floor(sec/3600), math.floor(sec%3600/60), sec%60)
    end

    -- Display-only conversion: saved history continues using YYYY-MM-DD HH:MM
    -- so chronological sorts, merges, daily-run detection and CSV exports are stable.
    -- Explicit English month abbreviations avoid dependence on client locale or
    -- availability of os.date parsing in WoW Forever. No timestamp is rewritten.
    GDS_HistoryDate = GDS_HistoryDate or {}
    function GDS_HistoryDate.Format(stamp)
        if type(stamp) ~= "string" or stamp == "" then return "Unknown date" end
        local year, month, day, hour, minute = stamp:match(
            "^(%d%d%d%d)%-(%d%d)%-(%d%d)[ T](%d%d):(%d%d)")
        if not year then
            year, month, day = stamp:match("^(%d%d%d%d)%-(%d%d)%-(%d%d)$")
        end
        if not year then return stamp end
        local months = {"Jan", "Feb", "Mar", "Apr", "May", "Jun",
            "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"}
        local mon = months[tonumber(month) or 0]
        if not mon or not tonumber(day) or tonumber(day) < 1 or tonumber(day) > 31 then
            return stamp
        end
        local label = mon .. " " .. tostring(tonumber(day)) .. ", " .. year
        if not hour then return label end
        local h, m = tonumber(hour), tonumber(minute)
        if not h or not m or h > 23 or m > 59 then return stamp end
        local meridiem = h >= 12 and "PM" or "AM"
        h = h % 12
        if h == 0 then h = 12 end
        return label .. (" %d:%02d %s"):format(h, m, meridiem)
    end

    function formatting.FmtShort(sec)
        sec = math.max(0, math.floor(sec))
        return ("%02d:%02d"):format(math.floor(sec/60), sec%60)
    end

    function formatting.FmtNum(n)
        local s = tostring(math.floor(n or 0))
        local k
        repeat s, k = s:gsub("^(-?%d+)(%d%d%d)", "%1,%2") until k == 0
        return s
    end

    function formatting.FmtK(n)
        n = math.floor(n or 0)
        if     n >= 1000000 then return string.format("%.1fm", n / 1000000)
        elseif n >= 1000    then return string.format("%.1fk", n / 1000)
        else                     return tostring(n) end
    end

    function formatting.Coin(c)
        c = math.max(0, math.floor(c or 0))
        if c == 0 then return "0|cFFC07A50c|r" end
        local g  = math.floor(c/10000)
        local s  = math.floor(c%10000/100)
        local cp = c%100
        local out = ""
        if g  > 0        then out = out .. g  .. "|cFFD9BE4Cg|r" end
        if g  > 0 or s>0 then out = out .. ("%02d|cFFB3B4BAs|r"):format(s) end
        out = out .. ("%02d|cFFC07A50c|r"):format(cp)
        return out
    end

    function formatting.CoinShort(c)
        c = math.max(0, math.floor(c or 0))
        if c == 0 then return "0c" end
        local g  = math.floor(c/10000)
        local s  = math.floor(c%10000/100)
        local cp = c%100
        if g > 0 then return g .. "|cFFD9BE4Cg|r" .. s  .. "|cFFB3B4BAs|r" end
        if s > 0 then return s .. "|cFFB3B4BAs|r" .. cp .. "|cFFC07A50c|r" end
        return cp .. "|cFFC07A50c|r"
    end
    FormatTime = formatting.FormatTime
    FmtShort = formatting.FmtShort
    FmtNum = formatting.FmtNum
    FmtK = formatting.FmtK
    Coin = formatting.Coin
    CoinShort = formatting.CoinShort
end

local function UpdateEMA(value, elapsed, oldEMA)
    if elapsed <= 0 then return oldEMA end
    local rate  = (value/elapsed)*3600
    local alpha = math.min(1.0, elapsed/60)*0.15
    return alpha*rate + (1-alpha)*oldEMA
end

local Q_COLOR = {
    [0]="|cFF9D9D9D",[1]="|cFFFFFFFF",[2]="|cFF1EFF00",
    [3]="|cFF0070DD",[4]="|cFFA335EE",[5]="|cFFFF8000",[6]="|cFFE6CC80",
}

-- forward declarations needed by OnLoot / loot log
local RefreshStats, RefreshLootLog, RefreshHistory
local DrawLineChart, DrawBarChart, DrawPieChart, SetAnalyticsTab, ShowPastAnalytics
local SetThemeTextColor, TrackThemeText
local EnsureProfiles, GetProfileNames, SaveProfile, LoadProfile, DeleteProfile, PrintProfiles
local BuildMinimapButton
local ShowSessionComparison
local ShowComparisonGraphs
local comparisonGraphsFrame

local function CopyComparisonPosition(destination, source)
    if not source then return end
    local x, y = source:GetCenter()
    if not x or not y then return end
    local scale = source:GetEffectiveScale() / UIParent:GetEffectiveScale()
    destination:ClearAllPoints()
    destination:SetPoint("CENTER", UIParent, "BOTTOMLEFT", x*scale, y*scale)
end

local function ComparisonHoverSample(points, seconds)
    local nearest = 1
    for i=2,#points do
        if math.abs(points[i].time-seconds) < math.abs(points[nearest].time-seconds) then nearest = i end
    end
    local point = points[nearest]
    local previous = points[nearest-1]
    return point, previous and point.value-previous.value or 0, seconds > points[#points].time
end

local function ComparisonGoldSeries(session)
    local duration = math.max(0, tonumber(session.duration) or 0)
    if duration <= 0 or not (session.c and type(session.c.gm) == "table") then return nil end
    local buckets = {}
    for minute, value in pairs(session.c.gm) do
        local m, v = tonumber(minute), tonumber(value)
        if m and m >= 0 and v and v > 0 then
            buckets[#buckets+1] = {start=math.min(duration, m*60), time=math.min(duration, (m+1)*60), value=v}
        end
    end
    table.sort(buckets, function(a,b) return a.time < b.time end)
    local points, total = {{time=0, value=0}}, 0
    for _, bucket in ipairs(buckets) do
        if bucket.start > points[#points].time then
            points[#points+1] = {time=bucket.start, value=total}
        end
        total = total + bucket.value
        local last = points[#points]
        if last.time == bucket.time then last.value = total
        else points[#points+1] = {time=bucket.time, value=total} end
    end
    if points[#points].time < duration then points[#points+1] = {time=duration, value=total} end
    return points, duration, total
end

local function SessionComparisonStats(session)
    local duration = math.max(0, tonumber(session.duration) or 0)
    local kills = math.max(0, tonumber(session.kills) or 0)
    local xp = math.max(0, tonumber(session.xp) or 0)
    local coin = math.max(0, tonumber(session.coin) or 0)
    local items = math.max(0, tonumber(session.items) or 0)
    local perHour = duration > 0 and 3600 / duration or 0
    return { duration=duration, kills=kills, xp=xp, coin=coin, items=items,
        total=coin+items, kph=kills*perHour, xph=xp*perHour,
        gph=(coin+items)*perHour, hasRate=duration > 0 }
end

local function ComparisonAdvantage(a, b)
    if math.abs(a-b) < 0.00001 then return "Equal" end
    local winner, low, high = a > b and "A" or "B", math.min(a,b), math.max(a,b)
    if low <= 0 then return "Run "..winner end
    return ("%s +%.1f%%"):format(winner, (high-low)/low*100)
end

-------------------------------------------------------------------------------
-- ITEM API COMPATIBILITY (Forever / Midnight and older clients)
-- Optional pricing addons are NOT required. The namespaced API replaces the
-- legacy global GetItemInfo on current clients.
-------------------------------------------------------------------------------
GDS_ItemCompat = GDS_ItemCompat or {}
GDS_ItemCompat.pending = GDS_ItemCompat.pending or {}
GDS_ItemCompat.recentAwards = GDS_ItemCompat.recentAwards or {}
function GDS_ItemCompat.GetInfo(item)
    local fn = (C_Item and C_Item.GetItemInfo) or GetItemInfo
    if type(fn) ~= "function" then return nil end
    return fn(item)
end
function GDS_ItemCompat.IsOwnRollWin(msg)
    if type(msg) ~= "string" or (issecretvalue and issecretvalue(msg)) then return false end
    -- Use the client's localized "You won" strings whenever available.
    for _, fmt in ipairs({ LOOT_ROLL_YOU_WON, LOOT_ROLL_YOU_WON_NO_SPAM_NEED,
         LOOT_ROLL_YOU_WON_NO_SPAM_GREED, LOOT_ROLL_YOU_WON_NO_SPAM_DE }) do
        if type(fmt) == "string" then
            local prefix = fmt:match("^(.-)%%")
            if prefix and prefix ~= "" and msg:sub(1,#prefix) == prefix then return true end
        end
    end
    return msg:match("^You won%s") ~= nil  -- English fallback
end
function GDS_ItemCompat.LootKind(msg,guid,ownLootFunction)
    if type(msg) ~= "string" or (issecretvalue and issecretvalue(msg)) then return nil end
    -- CHAT_MSG_LOOT contains roll activity, too.  A "You won" announcement is
    -- NOT proof of a newly received item and can be repeated by the client.
    -- Only the actual own-item receipt may contribute to either tracker.
    if GDS_ItemCompat.IsOwnRollWin(msg) then return nil end
    if msg:match("%s+wins%s") or msg:match("%s+won%s") then return nil end
    if ownLootFunction(msg,guid) then return "receipt" end
    return nil
end
function GDS_ItemCompat.DuplicateAward(id,qty,kind,quality)
    -- Keep legitimate separate cloth/mat receipts even when they happen in a
    -- burst. An occasional modern-client duplicate for the SAME rare item can
    -- be suppressed without suppressing distinct rare drops minutes apart.
    if kind ~= "receipt" or (tonumber(quality) or 0) < 2 then return false end
    local now=GetTime()
    local key=tostring(id)..":"..tostring(qty)
    local previous=GDS_ItemCompat.recentAwards[key]
    if previous and now >= previous.at and now-previous.at <= 2 then
        return true
    end
    GDS_ItemCompat.recentAwards[key]={kind=kind,at=now}
    return false
end
-------------------------------------------------------------------------------
-- PRICING
-- Returns per-unit price in copper.
-- knownVendor: pass infoVendor from GetItemInfo if already fetched, avoids
--              a second cache lookup that might fail on a fresh item.
-------------------------------------------------------------------------------
-- Read-only Forever forecasts adapted from Disenchantry.
--[[
MIT License

Copyright (c) 2026 x_Raven_x
Copyright (c) 2026 Rakuga

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
]]
do
local ns = {App={}}
function GDS_ItemCompat.MarketQuote(id)
    id = tonumber(id)
    local api = _G.AuctionCompanionAPI
    if not id or id <= 0 or type(api) ~= "table" or type(api.GetPriceByItemID) ~= "function" then return nil end
    local ok, value, source, stamp = pcall(api.GetPriceByItemID, id)
    if ok and type(value) == "number" and value > 0 and value < math.huge then
        return math.floor(value + .5), source, stamp
    end
end
local Policy = {overrides={}}
ns.ForecastPolicy = Policy
-- Opted-in estimates for these exact new crafts only, not all Forever rares.
-- Craft Ladder Data/Disenchant.lua (2026-11-03), buckets 335/336, guess=true.
-- See Docs/ForeverRareResearch.md. Player observations take precedence.
local lowCraft = {approximate=true,foreverCraftEstimate=true,
    {itemID=10940,chance=80,minQuantity=2,maxQuantity=3},
    {itemID=10938,chance=20,minQuantity=2,maxQuantity=3}}
local midCraft = {approximate=true,foreverCraftEstimate=true,
    {itemID=10940,chance=75,minQuantity=3,maxQuantity=4},
    {itemID=10939,chance=20,minQuantity=2,maxQuantity=3},
    {itemID=10978,chance=5,minQuantity=2,maxQuantity=2}}
for _,id in ipairs({250620,250482,250621,252424,252425,252426,252427,253885,253887}) do
    Policy.overrides[id]=lowCraft
end
for _,id in ipairs({250513,250514,250515,250516,250517,250508,250509,250510,250511,250512,250489,
    252428,252429,252430,252431,252432,252433,252494,252495,252496,252497,252498,252499,
    253889,253891,253893,253895,253897,253899,253901,253903,253905,253907,253909,253911,
    253913,253915,253917,253919,253921,253923}) do
    Policy.overrides[id]=midCraft
end
function Policy.ItemID(item)
    local ref = type(item)=="table" and (item.itemID or item.link) or item
    return type(ref)=="number" and ref or type(ref)=="string" and tonumber(ref:match("item:(%d+)")) or nil
end
function Policy.IsForever()
    return GetBuildInfo and tostring(GetBuildInfo()):match("^1%.60%.")~=nil
end
function Policy.IsUnverified(item)
    if not item then return false end
    local id=Policy.ItemID(item)
    return Policy.IsForever() and item.quality==3 and id and id>=200000 and not Policy.overrides[id] and not Policy.Estimate(item) and not Policy.Observed(item) or false
end
-- User-selected fallback for all new Forever rares, regardless of acquisition.
-- Low-level distributions are estimates; higher brackets use Classic rules.
function Policy.Estimate(item)
    local id=Policy.ItemID(item)
    local level=tonumber(item and item.baseItemLevel)
    if not Policy.IsForever() or not id or id<200000 or item.quality~=3 or not level
        or level<5 or level>99 or (item.classID~=2 and item.classID~=4) then return end
    local rows={approximate=true,foreverCraftEstimate=true}
    local function add(material,chance,minimum,maximum)
        rows[#rows+1]={itemID=material,chance=chance,minQuantity=minimum or 1,maxQuantity=maximum or minimum or 1}
    end
    local weapon=item.classID==2
    if level<=15 then
        add(10940,weapon and 20 or 80,2,3)
        add(10938,weapon and 80 or 20,2,3)
    elseif level<=20 then
        add(10940,weapon and 20 or 75,3,4)
        add(10939,weapon and 75 or 20,2,3)
        add(10978,5,2)
    elseif level<=25 then add(10978,100)
    elseif level<=30 then add(11084,100)
    elseif level<=35 then add(11138,100)
    elseif level<=40 then add(11139,100)
    elseif level<=45 then add(11177,100)
    elseif level<=50 then add(11178,100)
    elseif level<=55 then add(14343,100)
    else add(14344,99.5); add(20725,0.5) end
    return rows
end
function Policy.HasSalvagerBuff()
    if not Policy.IsForever() then return false end
    if C_UnitAuras and C_UnitAuras.GetPlayerAuraBySpellID then
        local ok,aura=pcall(C_UnitAuras.GetPlayerAuraBySpellID,1283701)
        return ok and type(aura)=="table"
    end
    if AuraUtil and AuraUtil.FindAuraBySpellID then return AuraUtil.FindAuraBySpellID(1283701,"player","HELPFUL")~=nil end
    return false
end
function Policy.SalvagerActive()
    if not Policy.IsForever() then return false end
    local settings=ns.App and ns.App.db or {}
    if settings.salvagerMode=="off" then return false end
    if settings.salvagerMode=="on" then return true end
    return Policy.HasSalvagerBuff()
end
local function sampleKey(item, boosted)
    local id=Policy.ItemID(item)
    if not id or type(item)~="table" then return end
    local version,build=GetBuildInfo()
    return table.concat({version or "",build or "",id,item.quality or 0,item.baseItemLevel or 0,item.classID or 0,boosted and "salvager" or "normal"},":")
end
function Policy.Observed(item)
    if not Policy.IsForever() then return end
    local key=sampleKey(item,Policy.SalvagerActive())
    local db=ns.App and ns.App.db
    local sample=key and db and type(db.disenchantSamples)=="table" and db.disenchantSamples[key]
    -- Small samples are collected but never advertised as reliable loot tables.
    if type(sample)~="table" or type(sample.count)~="number" or sample.count<20 or sample.count>10000000 or type(sample.materials)~="table" then return end
    local rows={empirical=true,approximate=true,samples=sample.count}
    for id,data in pairs(sample.materials) do
        if type(id)=="number" and type(data)=="table" and type(data.hits)=="number" and data.hits>0 and data.hits<=sample.count
            and type(data.total)=="number" and data.total>0 and type(data.min)=="number" and type(data.max)=="number" then
            rows[#rows+1]={itemID=id,chance=100*data.hits/sample.count,minQuantity=data.min,maxQuantity=data.max,meanQuantity=data.total/data.hits}
        else return end
    end
    if #rows==0 then return end
    table.sort(rows,function(a,b) return a.itemID<b.itemID end)
    return rows
end
function Policy.BonusPercent()
    if not Policy.SalvagerActive() then return 0 end
    local value=tonumber(ns.App and ns.App.db and ns.App.db.salvagerBonusPercent) or 0
    return value==value and math.max(0,math.min(1000,value)) or 0
end
local uncommon = {
    {5,15,10940,10938,nil,80,20,20,80,1,2,1,2},
    {16,20,10940,10939,10978,75,20,20,75,2,3,1,2},
    {21,25,10940,10998,10978,75,15,15,75,4,6,1,2},
    {26,30,11083,11082,11084,75,20,20,75,1,2,1,2},
    {31,35,11083,11134,11138,75,20,20,75,2,5,1,2},
    {36,40,11137,11135,11139,75,20,20,75,1,2,1,2},
    {41,45,11137,11174,11177,75,20,20,75,2,5,1,2},
    {46,50,11176,11175,11178,75,20,20,75,1,2,1,2},
    {51,55,11176,16202,14343,75,20,22,75,2,5,1,2},
    {56,60,16204,16203,14344,75,20,22,75,1,2,1,2},
    {61,65,16204,16203,14344,75,20,22,75,2,5,2,3},
}
local outland = {
    {79,79,22445,22447,22448,75,22,22,75,1,2,1,2},
    {80,99,22445,22447,22448,75,22,22,75,2,3,2,3},
    {100,120,22445,22446,22449,75,22,22,75,2,5,1,2},
}
local northrend = {
    {130,151,34054,34056,34053,75,22,22,75,2,3,1,2},
    {152,200,34054,34055,34052,75,22,22,75,4,7,1,2},
}
local rare = {
    {1,25,10978}, {26,30,11084}, {31,35,11138}, {36,40,11139},
    {41,45,11177}, {46,50,11178}, {51,55,14343}, {56,80,14344,20725},
}
local function outcome(id, chance, minQuantity, maxQuantity)
    return {itemID = id, chance = chance, minQuantity = minQuantity or 1, maxQuantity = maxQuantity or minQuantity or 1}
end
local function find(rows, level)
    for _, row in ipairs(rows) do
        if level >= row[1] and level <= row[2] then return row end
    end
end

ns.DisenchantResults = {}
-- Enchanter-crafted wands are exceptions to the quality/item-level tables.
-- Sources and scope: Docs/DisenchantExclusions.md. Use IDs, never localized names.
local noDisenchant = {
    [11287]=true, -- Lesser Magic Wand
    [11288]=true, -- Greater Magic Wand
    [11289]=true, -- Lesser Mystic Wand
    [11290]=true, -- Greater Mystic Wand
}
local foreverNoDisenchant = {
    [247789]=true, -- Novice's Practice Wand
    [249144]=true, -- Twisted Nether Wand
    [249234]=true, -- Dreambough Wand
    [249232]=true, -- Lesser Eternal Wand
    [249237]=true, -- Greater Eternal Wand
    [249385]=true, -- Brilliant Wand
}
local function IsForever()
    local version = GetBuildInfo and GetBuildInfo()
    return type(version) == "string" and version:match("^1%.60%.") ~= nil
end
function ns.DisenchantResults.IsExcluded(reference)
    if type(reference) == "table" then reference = reference.itemID or reference.link end
    local id = type(reference) == "number" and reference
        or type(reference) == "string" and tonumber(reference:match("item:(%d+)") or reference)
    return id ~= nil and (noDisenchant[id] == true or IsForever() and foreverNoDisenchant[id] == true) or false
end
function ns.DisenchantResults.IsRetail()
    return WOW_PROJECT_MAINLINE ~= nil and WOW_PROJECT_ID == WOW_PROJECT_MAINLINE and not IsForever()
end
function ns.DisenchantResults.IsSupported()
    return IsForever() or WOW_PROJECT_ID ~= nil
end
function ns.DisenchantResults.Get(item)
    if not item or not ns.DisenchantResults.IsSupported() then return nil end
    if ns.DisenchantResults.IsExcluded(item) then return nil end
    if ns.ForecastPolicy then
        local observed=ns.ForecastPolicy.Observed(item)
        if observed then return observed end
        local override=ns.ForecastPolicy.overrides[ns.ForecastPolicy.ItemID(item)]
        if ns.ForecastPolicy.IsForever() and override then return override end
        local estimate=ns.ForecastPolicy.Estimate(item)
        if estimate then return estimate end
        if ns.ForecastPolicy.IsUnverified(item) then return nil end
    end
    if not IsForever() then return nil end
    local forever = IsForever()
    local level, quality, expansion = item.baseItemLevel, item.quality, item.expansionID
    if not level or level <= 0 then return nil end
    -- Classic clients may return a sentinel (254) rather than an expansion.
    -- Era has only original materials. Elsewhere infer only the unambiguous
    -- low-level original range; do not guess across expansion overlaps.
    if forever or (WOW_PROJECT_CLASSIC and WOW_PROJECT_ID == WOW_PROJECT_CLASSIC) then
        expansion = 0
    elseif expansion == nil or expansion == 254 or expansion < 0 then
        if level <= 65 then expansion = 0 else return nil end
    end
    if item.classID ~= 2 and item.classID ~= 4 then return nil end
    if quality == 2 then
        local rows = expansion == 0 and uncommon or expansion == 1 and outland or expansion == 2 and northrend
        local row = rows and find(rows, level)
        if not row then return nil end
        local weapon = item.classID == 2
        local dust, essence = row[weapon and 8 or 6], row[weapon and 9 or 7]
        local essenceID = row[4]
        -- Forever: uncommon weapons ilvl 16-30 all yield Greater Magic Essence
        -- (Wowhead Forever disenchant data); armor keeps the classic essences.
        if forever and weapon and level >= 21 and level <= 30 then essenceID = 10939 end
        local results = {outcome(row[3], dust, row[10], row[11]), outcome(essenceID, essence, row[12], row[13])}
        if row[5] then results[#results + 1] = outcome(row[5], 100 - dust - essence) end
        return results
    elseif quality == 3 then
        local rows = expansion == 0 and rare
            or expansion == 1 and {{66,99,22448,20725},{100,115,22449,22450}}
            or expansion == 2 and {{130,166,34053},{167,200,34052}}
        local row = rows and find(rows, level)
        if not row then return nil end
        if row[4] then return {outcome(row[3],99.5),outcome(row[4],0.5)} end
        return {outcome(row[3],100)}
    elseif quality == 4 then
        local rows = expansion == 0 and {{40,45,11177,2,4},{46,50,11178,2,4},{51,55,14343,2,4},{56,60,20725,1,1},{61,88,20725,1,2}}
            or expansion == 1 and {{90,100,22450,1,2},{101,164,22450,1,2}}
            or expansion == 2 and {{185,199,34057,1,2},{200,284,34057,1,1}}
        local row = rows and find(rows, level)
        if row then return {outcome(row[3],100,row[4],row[5])} end
    end
end


local function materialQuote(id)
    return GDS_ItemCompat.MarketQuote(id)
end
function GDS_ItemCompat.ForeverDE(id, link)
    ns.App.db = _G.DisenchantryDB or {}
    if not IsForever() then return nil, "No Forever forecast on this client" end
    local name, _, quality, level, _, _, _, _, _, _, _, classID, _, _, expansion = GDS_ItemCompat.GetInfo(link)
    if not name then return nil, "Item information unavailable" end
    local rows = ns.DisenchantResults.Get({itemID=id,link=link,quality=quality,baseItemLevel=level,
        classID=classID,expansionID=expansion})
    if not rows then return nil, "No disenchant forecast for this item" end
    local total = 0
    for _, row in ipairs(rows) do
        if row.chance > 0 then
            local quote = materialQuote(row.itemID)
            if not quote or quote <= 0 then
                local material = GDS_ItemCompat.GetInfo(row.itemID)
                return nil, "Missing Auction Companion price for " .. (material or ("item #" .. row.itemID))
            end
            local qty = row.meanQuantity or (row.minQuantity + row.maxQuantity) / 2
            total = total + quote * qty * row.chance / 100
        end
    end
    return total * (1 + (rows.empirical and 0 or Policy.BonusPercent()) / 100)
end
end

local function GetPricePerItem(itemLink, quality, knownVendor, previewMode)
    if not itemLink then return 0 end

    local vendorPrice = tonumber(knownVendor)  -- nil if not pre-fetched

    if vendorPrice == nil then
        local info = { GDS_ItemCompat.GetInfo(itemLink) }
        if not info[1] then
            if debugMode then
                DEFAULT_CHAT_FRAME:AddMessage(
                    "|cFFFF8800[GT]|r GetItemInfo miss: " .. tostring(itemLink))
            end
            return 0
        end
        vendorPrice = tonumber(info[11]) or 0
        if quality == nil then quality = tonumber(info[3]) end
    end

    vendorPrice = vendorPrice or 0

    if debugMode then
        DEFAULT_CHAT_FRAME:AddMessage(
            "|cFF888888[GT price]|r vendor=" .. math.floor(vendorPrice/10000) .. "g"
            .. math.floor(vendorPrice%10000/100) .. "s  Q=" .. tostring(quality))
    end

    -- Individual item overrides take precedence over the global default.
    -- An unknown Auction Companion price safely falls back to vendor value.
    local itemID = tonumber(tostring(itemLink):match("item:(%d+)"))
    local choice = DB and DB.priceOverrides and itemID and DB.priceOverrides[tostring(itemID)]
    choice = previewMode or choice or (DB and DB.defaultPriceMode) or "vendor"
    if choice == "questDE" then choice = DB.questTracking and "disenchant" or "vendor" end
    if choice == "quest" then
        return vendorPrice -- Quest Coin tracks vendor value, never AH or DE
    end
    if choice == "disenchant" then
        -- Use the internal forecast with AC quotes, avoiding a bridge configured for another provider.
        local ok, estimate, reason = pcall(GDS_ItemCompat.ForeverDE, itemID, itemLink)
        if ok and type(estimate) == "number" and estimate > 0 then return math.floor(estimate + .5) end
        return vendorPrice, (ok and reason or "Forecast lookup failed") or "No material estimate"
    end
    if choice == "auction" then
        local ahPrice, source = GDS_ItemCompat.MarketQuote(itemID)
        if ahPrice then
            if debugMode then
                DEFAULT_CHAT_FRAME:AddMessage("|cFF00FFFF[GT price]|r AC " .. tostring(source) .. ": " .. tostring(ahPrice) .. " copper")
            end
            return ahPrice
        end
        if debugMode then DEFAULT_CHAT_FRAME:AddMessage("|cFFFF8800[GT price]|r AC quote unavailable; vendor fallback") end
    end
    return vendorPrice
end

-- Quest-valued loot is an estimate for Quest Coin, not currency received.
-- The existing per-item-ID pricing override is reused, but the mode is active
-- only while Quest Tracker is enabled. Always keep farm and quest totals disjoint.
GDS_QuestItems = GDS_QuestItems or {}
function GDS_QuestItems.IsQuest(id)
    return DB and DB.questTracking == true
        and type(DB.priceOverrides) == "table"
        and id ~= nil and (DB.priceOverrides[tostring(id)] == "quest" or DB.priceOverrides[tostring(id)] == "questDE")
end
function GDS_QuestItems.CanDisenchant(id, it)
    local _, _, q, _, _, _, _, _, _, _, _, classID = GDS_ItemCompat.GetInfo(id)
    return (q or it.quality or 0) >= 2 and (q or it.quality or 0) <= 4
        and (classID == 2 or classID == 4)
end
function GDS_QuestItems.EntryIsQuest(entry)
    if not entry then return false end
    if entry.questReceipt then return true end
    local id = tonumber(entry.itemID)
        or (entry.link and tonumber(entry.link:match("item:(%d+)")))
    return GDS_QuestItems.IsQuest(id)
end
function GDS_QuestItems.Credit(delta)
    if not S or not DB then return end
    delta = tonumber(delta) or 0
    if delta == 0 then return end
    S.questItemGold = math.max(0, (tonumber(S.questItemGold) or 0) + delta)
    S.questGold = math.max(0, (tonumber(S.questGold) or 0) + delta)
    DB.questTotals = DB.questTotals or {xp=0, gold=0}
    DB.questTotals.gold = math.max(0, (tonumber(DB.questTotals.gold) or 0) + delta)
end
function GDS_QuestItems.Reconcile()
    if not S or type(S.loot) ~= "table" then return end
    local quest, farm = 0, 0
    for _, it in ipairs(S.loot) do
        local value = math.max(0, tonumber(it.total) or 0)
        if GDS_QuestItems.EntryIsQuest(it) then quest = quest + value
        else farm = farm + value end
    end
    local change = quest - (tonumber(S.questItemGold) or 0)
    GDS_QuestItems.Credit(change)
    S.questItemGold = quest -- track the actual classified balance, even at zero
    S.itemGold = farm
    if GDS_DungeonLootSync then GDS_DungeonLootSync.Reconcile() end
end

-- v7.0.0-alpha.5: Dungeon loot ownership ledger. Analytics value/mode/restore/removal
-- edits update the correct active/completed dungeon run (including its item list),
-- without moving another run's earnings. Legacy unlinked history is untouched.
-- An active pre-upgrade run can safely backfill loot collected since entry.
GDS_DungeonLootSync = GDS_DungeonLootSync or {}
function GDS_DungeonLootSync.NewID()
    if not DB then return nil end
    DB.dungeonLootSerial = math.floor(tonumber(DB.dungeonLootSerial) or 0) + 1
    return tostring(time()) .. ":" .. tostring(DB.dungeonLootSerial)
end
function GDS_DungeonLootSync.SessionID()
    if not S or not DB then return nil end
    if not S.dungeonLootSessionID then
        S.dungeonLootSessionID = GDS_DungeonLootSync.NewID()
    end
    return S.dungeonLootSessionID
end
function GDS_DungeonLootSync.EnsureRun(run)
    if not S or not DB or type(run) ~= "table" then return nil end
    if run.dungeonLootID then return run.dungeonLootID end
    local sessionID = GDS_DungeonLootSync.SessionID()
    if not sessionID then return nil end
    run.dungeonLootSessionID = sessionID
    run.dungeonLootID = GDS_DungeonLootSync.NewID()
    -- Upgrade an ALREADY active dungeon once: only unowned entries recorded
    -- after its starting session time may be attributed to the current run.
    -- Do not guess the ownership of older completed dungeon records.
    if S.dungeonCurrent == run then
        local start = math.max(0, tonumber(run.startTime) or 0)
        local now = math.max(0, tonumber(S.timer) or 0)
        for _, entry in ipairs(S.loot or {}) do
            local received = tonumber(entry.time)
            if not entry.dungeonLootID and received and received >= start
                and received <= now then
                entry.dungeonLootID = run.dungeonLootID
            end
        end
    end
    return run.dungeonLootID
end
function GDS_DungeonLootSync.Stamp(entry)
    if not S or not S.running or S.paused or type(entry) ~= "table" then return end
    local run = S.dungeonCurrent
    if not run then return end
    entry.dungeonLootID = GDS_DungeonLootSync.EnsureRun(run)
end
function GDS_DungeonLootSync.Reconcile()
    if not S or not DB or type(S.loot) ~= "table" then return end
    local sessionID = S.dungeonLootSessionID
    if not sessionID then return end
    local totals = {}
    -- Only surviving Analytics entries contribute. Removed records keep their
    -- stable ownership ID for restore, but they do not earn gold or count as loot.
    for _, entry in ipairs(S.loot) do
        local id = entry.dungeonLootID
        if id and not GDS_QuestItems.EntryIsQuest(entry) then
            local bucket = totals[id]
            if not bucket then
                bucket = {value=0, items={}}
                totals[id] = bucket
            end
            bucket.value = bucket.value + math.max(0, tonumber(entry.total) or 0)
            local itemID = tonumber(entry.itemID)
                or (entry.link and tonumber(entry.link:match("item:(%d+)")))
            if itemID then
                local prior = bucket.items[itemID]
                if not prior then
                    prior = {name=entry.name or ("Item:"..itemID), qty=0}
                    bucket.items[itemID] = prior
                end
                prior.qty = prior.qty + math.max(0, tonumber(entry.qty) or 1)
                if entry.name then prior.name = entry.name end
            end
        end
    end
    local historyChanged = false
    local function apply(run, completed)
        if type(run)=="table" and type(run.gdsCombinedRuns)=="table" then
            for _, part in ipairs(run.gdsCombinedRuns) do apply(part, true) end
            local old = run.items
            GDS_Dungeon.SumCombined(run)
            if old ~= run.items then historyChanged = true end
            if GDS_LoginLog and GDS_LoginLog.ItemsChanged then GDS_LoginLog.ItemsChanged(run) end
            return
        end
        if type(run) ~= "table" or run.dungeonLootSessionID ~= sessionID
            or not run.dungeonLootID then return end
        local bucket = totals[run.dungeonLootID]
        local base = math.max(0, tonumber(run.dungeonCarryValue) or 0)
        local value = base + (bucket and bucket.value or 0)
        local items = {}
        -- An optional party-only prefix was earned before the personal tracker
        -- took ownership. It is not editable through personal Analytics.
        for key, old in pairs(run.dungeonCarryLootItems or {}) do
            if type(old) == "table" then
                items[key] = {name=old.name, qty=tonumber(old.qty) or 0}
            end
        end
        for key, item in pairs(bucket and bucket.items or {}) do
            local old = items[key]
            if old then
                old.qty = (tonumber(old.qty) or 0) + (tonumber(item.qty) or 0)
                if not old.name then old.name = item.name end
            else
                items[key] = item
            end
        end
        if completed and (tonumber(run.items) or 0) ~= value then
            historyChanged = true
        end
        run.dungeonItemValue = value
        if completed then run.items = value end
        run.lootItems = items
        if GDS_LoginLog and GDS_LoginLog.ItemsChanged then
            GDS_LoginLog.ItemsChanged(run)
        end
    end
    apply(S.dungeonCurrent, false)
    for _, run in ipairs(DB.dungeonRuns or {}) do apply(run, true) end
    -- Deleting a dungeon run in History must not detach its analytics ledger.
    -- Its one-step restore should retain any changes made while deleted.
    if DB.dungeonUndo then apply(DB.dungeonUndo.run, true) end
    if historyChanged then
        if GDS_LiveDungeon then GDS_LiveDungeon.historySummary = nil end
        if historyFrame and historyFrame:IsShown() and historyActiveTab == "dungeons"
            and RefreshHistory then RefreshHistory() end
    end
end

-- If an awarded item isn't cached yet, keep the award in the active session
-- at zero until the server provides its sell value. Credit the difference to
-- whichever sessions were actually running when the item was won.
function GDS_ItemCompat.BestDrop(loot)
    local best
    for _, entry in ipairs(loot or {}) do
        if entry.source ~= "manual" and not entry.questReceipt and (tonumber(entry.total) or 0) > (best and best.total or 0) then
            best = {name=entry.name, link=entry.link, qty=entry.qty or 1, total=tonumber(entry.total)}
        end
    end
    return best
end

function GDS_ItemCompat.DropText(entry)
    return (entry.link or entry.name or "Item") .. " x" .. entry.qty .. "  " .. CoinShort(entry.total)
end

function GDS_ItemCompat.AlertDrop(entry)
    if not entry.alertEligible then return end
    local threshold = tonumber(DB.dropAlertGold) or 0
    if threshold > 0 and entry.total >= threshold * 10000 then
        entry.alertEligible = nil
        local message = "Valuable drop: " .. GDS_ItemCompat.DropText(entry)
        DEFAULT_CHAT_FRAME:AddMessage(message)
        if UIErrorsFrame then UIErrorsFrame:AddMessage(message, 1, .82, .25) end
    end
end

function GDS_ItemCompat.Queue(id,qty,entry,personalSession,partySession,originalTotal,login,loginAward)
    if entry then entry.pricePending = true end
    local pending={id=id,qty=qty,entry=entry,personal=personalSession,login=login,loginAward=loginAward,
        party=partySession,originalTotal=tonumber(originalTotal) or 0}
    table.insert(GDS_ItemCompat.pending,pending)
    if C_Item and type(C_Item.RequestLoadItemDataByID)=="function" then
        pcall(C_Item.RequestLoadItemDataByID,id)
    end
    -- GET_ITEM_INFO_RECEIVED normally resolves it; retry on clients which
    -- don't emit that event, without polling indefinitely.
    if C_Timer and C_Timer.After then
        for _,delay in ipairs({1,4,12}) do
            C_Timer.After(delay,function() GDS_ItemCompat.Resolve(id) end)
        end
    end
end
function GDS_ItemCompat.Resolve(itemID)
    for i=#GDS_ItemCompat.pending,1,-1 do
        local p=GDS_ItemCompat.pending[i]
        if not itemID or p.id==itemID then
            local name,itemLink,quality,_,_,_,_,_,_,_,vendor=GDS_ItemCompat.GetInfo(p.id)
            if name and type(vendor)=="number" then
                table.remove(GDS_ItemCompat.pending,i)
                local price, reason
                if p.entry and p.entry.questReceipt then price=math.max(0,vendor)
                else price,reason=GetPricePerItem("item:"..p.id,quality,vendor) end
                local newTotal=math.max(0,price*(p.qty or 1))
                if p.login and p.loginAward then
                    p.login.itemValue = p.login.itemValue + newTotal - p.loginAward.total
                    for index,award in ipairs(p.login.pendingLoot or {}) do
                        if award == p.loginAward then table.remove(p.login.pendingLoot,index); break end
                    end
                end
                -- The entry may already have been repriced while the cache loaded.
                local previousTotal = p.entry and (tonumber(p.entry.total) or 0)
                    or (p.originalTotal or 0)
                local delta = newTotal - previousTotal
                -- Only update the session which originally received the award.
                if p.entry and p.personal==S then
                    p.entry.pricePending=false
                    p.entry.quality=quality or p.entry.quality
                    p.entry.vendorPrice=vendor
                    p.entry.deFallback=reason
                    p.entry.unitPrice=price
                    p.entry.total=newTotal
                    if p.entry.name==("Item:"..p.id) or p.entry.name=="Loot" then
                        p.entry.name=name
                    end
                    if type(itemLink)=="string" and itemLink~="" then
                        p.entry.link=itemLink
                    end
                    -- A removed item may still have an in-flight price lookup.
                    -- Keep its values ready for Undo, but don't award gold
                    -- while the row is absent from the session loot list.
                    if not p.entry._gtRemoved then
                        if GDS_ItemCompat.AlertDrop then GDS_ItemCompat.AlertDrop(p.entry) end
                        if GDS_QuestItems.EntryIsQuest(p.entry) then
                            GDS_QuestItems.Credit(delta)
                        else
                            S.itemGold=math.max(0,(S.itemGold or 0)+delta)
                        end
                    end
                end
                if p.party and p.party==GDS_PartySession.active then
                    delta = newTotal - p.originalTotal
                    if GDS_QuestItems.IsQuest(p.id) then
                        p.party.questGold = math.max(0, (p.party.questGold or 0) + delta)
                    else
                        p.party.items=math.max(0,(p.party.items or 0)+delta)
                    end
                end
                if GDS_DungeonLootSync then GDS_DungeonLootSync.Reconcile() end
                if RefreshStats then RefreshStats() end
                if RefreshLootLog then RefreshLootLog() end
                if GDS_PartySession.Refresh then GDS_PartySession.Refresh() end
            end
        end
    end
end

function GDS_ItemCompat.RestorePrices()
    for _, login in ipairs(DB.loginHistory or {}) do
        for _, award in ipairs(login.pendingLoot or {}) do
            GDS_ItemCompat.Queue(award.id,award.qty,nil,nil,nil,award.total,login,award)
        end
    end
    local function restoreRow(entry)
        if not entry or not entry.itemID then return end
        -- In earlier saves a cold cache and a genuine zero both appeared as zero.
        if entry.pricePending == nil and (entry.vendorPrice or 0) == 0 then
            local _, _, _, _, _, _, _, _, _, _, vendor = GDS_ItemCompat.GetInfo(entry.itemID)
            if vendor == 0 then entry.pricePending = false end
        end
        if entry.pricePending or (entry.pricePending == nil and (entry.vendorPrice or 0) == 0) then
            GDS_ItemCompat.Queue(entry.itemID, entry.qty, entry, S, nil, entry.total)
        end
    end
    if S then
        for _, entry in ipairs(S.loot) do restoreRow(entry) end
        for _, removed in ipairs(GDS_AnalyticsUndo.List() or {}) do
            restoreRow(removed.entry)
        end
    end
    local party = GDS_PartySession.active
    if party then
        for _, award in ipairs(party.pendingPrices or {}) do
            GDS_ItemCompat.Queue(award.id, award.qty, nil, nil, party, award.total)
        end
        party.pendingPrices = nil
    end
end

-------------------------------------------------------------------------------
-- LOOT PARSER
-- Only confirmed self loot receipts contribute; roll announcements are ignored.
--
-- Confirmed Midnight CHAT_MSG_LOOT format (from hex dump):
--   |cnIQ2:|Hitem:237362::::::::89:251::::1:38:13:::::|h[Umbral Tin Ore|A:Professions-ChatIcon-Quality-12-Tier1:17:15::1|a|h|rx3
--
--   Quality tag : |cnIQN:  where N=0-5, terminated by COLON (not pipe)
--   Item ID     : |Hitem:ID:
--   Item name   : [Name  with NO closing ] — ends at the next |
--   Quantity    : last xN in the whole string; absent for qty=1
-------------------------------------------------------------------------------
-- True when a CHAT_MSG_LOOT line is the player's own loot. Group members' loot
-- arrives on the same event and must not count toward the player's gold.
-- The looter's GUID (12th event argument) is used when readable; otherwise the
-- message must start with the game's own "You receive loot" wording.
local selfLootPrefixes
local function IsOwnLoot(msg, guid)
    if type(msg) ~= "string" or (issecretvalue and issecretvalue(msg)) then return false end
    -- The GUID by itself does NOT mean an item was received: need/greed/pass
    -- messages can also identify the local player as their source.
    if type(guid) == "string" and not (issecretvalue and issecretvalue(guid)) and guid:match("^Player%-") then
        local mine = UnitGUID("player")
        if mine and not (issecretvalue and issecretvalue(mine)) and guid ~= mine then
            return false
        end
    end
    if not selfLootPrefixes then
        selfLootPrefixes = {}
        for _, fmt in pairs({ LOOT_ITEM_SELF, LOOT_ITEM_SELF_MULTIPLE,
                               LOOT_ITEM_PUSHED_SELF, LOOT_ITEM_PUSHED_SELF_MULTIPLE }) do
            if type(fmt) == "string" then
                local prefix = fmt:match("^(.-)%%")
                if prefix and prefix ~= "" then selfLootPrefixes[#selfLootPrefixes+1] = prefix end
            end
        end
    end
    if #selfLootPrefixes > 0 then
        for _, prefix in ipairs(selfLootPrefixes) do
            if msg:sub(1, #prefix) == prefix then return true end
        end
    end
    -- Forever can emit the English receipt alongside a different localized template.
    return msg:match("^You receive loot%s*:") ~= nil
        or msg:match("^You receive item%s*:") ~= nil
end

-- Crafting produces CHAT_MSG_LOOT messages too (for example "You create: [Bolt ...]").
-- Ignore crafted outputs rather than valuing the input cloth AND the resulting bolts.
-- Use WoW's localized own-craft messages so this works beyond English clients.
local craftedLootPrefixes
local function IsCraftedLoot(msg)
    if type(msg) ~= "string" then return false end
    if not craftedLootPrefixes then
        craftedLootPrefixes = {}
        for _, fmt in ipairs({ LOOT_ITEM_CREATED_SELF, LOOT_ITEM_CREATED_SELF_MULTIPLE }) do
            if type(fmt) == "string" then
                local prefix = fmt:match("^(.-)%%")
                if prefix and prefix ~= "" then
                    craftedLootPrefixes[#craftedLootPrefixes+1] = prefix
                end
            end
        end
    end
    for _, prefix in ipairs(craftedLootPrefixes) do
        if msg:sub(1, #prefix) == prefix then return true end
    end
    -- Conservative fallback for clients without the localization globals.
    return msg:match("^You create%s*:") ~= nil
end

-- Profession crafts may be reported as ordinary "You receive loot" messages.
-- The chat text alone is not a reliable discriminator on Forever/Midnight.
 -- Suppress output while a trade-skill window is open. This intentionally
-- ignores ALL item acquisitions during that window, including unusual real
-- loot received without closing the profession UI.
local professionWindowOpen = false
local professionClosedAt = -100
function GDS_ItemCompat.Visible(frame)
    return frame and ((frame.IsVisible and frame:IsVisible()) or (not frame.IsVisible and frame.IsShown and frame:IsShown()))
end
local function ProfessionWindowVisible()
    for _, frameName in ipairs({ "ProfessionsFrame", "TradeSkillFrame" }) do
        local frame = _G[frameName]
        if GDS_ItemCompat.Visible(frame) then return true end
    end
    return professionWindowOpen
end
local function IgnoreProfessionLoot()
    if ProfessionWindowVisible() then return true end
    return (GetTime() - professionClosedAt) < 1.5
end

-- Disenchanting returns materials through CHAT_MSG_LOOT just like normal drops.
-- The source gear was already valued by GrindTracker (including DE estimates),
-- so these outputs must not be added as additional earnings. Disenchantry
-- confirms that spell 13262 is the disenchant spell on this client.
do
    local pending
    local materials = {}
    for _, id in ipairs({10940,10938,10939,10978,10998,11083,11082,11084,11134,11138,
        11137,11135,11139,11174,11177,11176,11175,11178,16202,14343,16204,16203,14344,
        20725,22445,22446,22447,22448,22449,22450,34052,34053,34054,34055,34056,34057}) do
        materials[id] = true
    end

    function GDS_ItemCompat.IsDEMaterial(id) return materials[id] == true end

    function GDS_ItemCompat.DisenchantEvent(event, unit, guid, spell)
        local now = GetTime()
        if event:find("UNIT_",1,true) == 1 then
            if unit ~= "player" or spell ~= 13262 then return end
            if event == "UNIT_SPELLCAST_START" or event == "UNIT_SPELLCAST_SUCCEEDED" then
                if not pending or pending.guid ~= guid or event == "UNIT_SPELLCAST_START" then
                    pending = {guid=guid}
                end
                pending.expires = now + 8
            elseif pending and pending.guid == guid then pending = nil end
            return
        end
        if not pending or (not pending.open and now > pending.expires) then pending=nil; return end
        if event == "LOOT_CLOSED" then
            pending.open = nil
            pending.closed = true
            pending.expires = now + 2
            return
        end
        if pending.closed or (not pending.open and now > pending.expires) then pending=nil; return end
        if pending.slots then return end
        local slots = {}
        for slot=1,GetNumLootItems() do
            local source = GetLootSourceInfo and GetLootSourceInfo(slot)
            if type(source) == "string" and source:match("^Creature%-") then pending=nil; return end
            local link = GetLootSlotLink(slot)
            local id = link and tonumber(link:match("item:(%d+)"))
            if id and not materials[id] then pending=nil; return end
            local qty = select(3, GetLootSlotInfo(slot))
            if not id or not qty or qty < 1 then return end
            slots[id] = (slots[id] or 0) + qty
        end
        if next(slots) then pending.open, pending.slots = true, slots end
    end

    function GDS_ItemCompat.IsDisenchantReceipt(id,qty)
        if not pending or not materials[id] then return false end
        if not pending.open and GetTime() > pending.expires then pending=nil; return false end
        if pending.slots then
            if (pending.slots[id] or 0) < qty then return false end
            pending.slots[id] = pending.slots[id] - qty
        end
        return true
    end
end

-- Mail attachments and collected mail copper (including auction proceeds)
-- are not farming income. Both CHAT_MSG_LOOT and PLAYER_MONEY can arrive a
-- little after the mailbox closes; share one suppression window for both.
local mailboxOpen = false
local mailboxClosedAt = -100
local function IgnoreMailboxLoot()
    if mailboxOpen or GDS_ItemCompat.Visible(MailFrame) then
        return true
    end
    return (GetTime() - mailboxClosedAt) < 3
end

-- Player-to-player trades are transfers, not loot or farming profit.  On
-- some clients their received items use the same CHAT_MSG_LOOT wording as a
-- mob drop, and traded copper produces PLAYER_MONEY.  The trade window can
-- close before those events arrive, so suppress a short completion window.
-- Global table avoids adding more Lua chunk locals (near the 200-local limit).
GDS_Trade = GDS_Trade or {}
GDS_Trade.active = false
GDS_Trade.closedAt = -100
GDS_Trade.graceSeconds = 3

function GDS_Trade.IsOpen()
    return GDS_Trade.active or
        GDS_ItemCompat.Visible(TradeFrame) or false
end

function GDS_Trade.RecentlyClosed()
    local elapsed = GetTime() - (GDS_Trade.closedAt or -100)
    return elapsed >= 0 and elapsed < GDS_Trade.graceSeconds
end

function GDS_Trade.IgnoreIncoming()
    return GDS_Trade.IsOpen() or GDS_Trade.RecentlyClosed()
end

-- Entering the world or opening creature loot ends stale interaction state
-- even if a replacement UI missed the corresponding close event.
function GDS_ItemCompat.RefreshLootContext()
    if not GDS_ItemCompat.Visible(MailFrame) then mailboxOpen, mailboxClosedAt = false, -100 end
    if not GDS_ItemCompat.Visible(TradeFrame) then GDS_Trade.active, GDS_Trade.closedAt = false, -100 end
    if not GDS_ItemCompat.Visible(MerchantFrame) then merchantOpen = false end
    if not (GDS_ItemCompat.Visible(ProfessionsFrame) or GDS_ItemCompat.Visible(TradeSkillFrame)) then
        professionWindowOpen, professionClosedAt = false, -100
    end
end

function GDS_ItemCompat.CheckLootSource()
    if not GetLootSourceInfo or not GetNumLootItems then return end
    for slot=1,GetNumLootItems() do
        local source = GetLootSourceInfo(slot)
        if type(source) == "string" and not (issecretvalue and issecretvalue(source))
            and source:match("^Creature%-") then
            GDS_ItemCompat.RefreshLootContext()
            return
        end
    end
end

function GDS_Trade.ResetCoinContext()
    -- A recent mob-money message must not accidentally validate traded gold.
    if GDS_Coin then
        GDS_Coin.lastLootAt, GDS_Coin.lastLootAmount = -100, nil
    end
    recentMoneyGain = nil
    moneyBaseline = GetMoney()
end

function GDS_Trade.OnShow()
    GDS_Trade.active = true
    GDS_Trade.closedAt = -100
    GDS_Trade.ResetCoinContext()
end

function GDS_Trade.OnClosed()
    GDS_Trade.active = false
    GDS_Trade.closedAt = GetTime()
    GDS_Trade.ResetCoinContext()
end

-- Login summaries have their own character ledger and never drive the manual session.
GDS_LoginLog = {}
function GDS_CheckboxChecked(control)
    local checked = control:GetChecked()
    return checked == true or checked == 1
end

function GDS_LoginLog.StartIfEnabled()
    if DB and DB.loginTracking and not GDS_LoginLog.row then
        GDS_LoginLog.Start(GDS_LoginLog.entryReason or "login")
    end
end

function GDS_LoginLog.InDungeon()
    return select(2,GetInstanceInfo()) == "party"
end

function GDS_LoginLog.XPBreakdown(row)
    if row.dungeonRawXP == nil then return nil, row.questXP, nil end
    -- XP bar and quest reward events can arrive in either order. Reconcile
    -- their cumulative totals at display time, leaving the raw counters intact.
    local quest = math.min(row.xp, row.questXP)
    local available = math.max(0, row.xp - quest - (row.unknownXP or 0))
    local dungeon = math.min(available, math.max(0, row.dungeonRawXP - row.dungeonQuestXP))
    return dungeon, quest, available - dungeon
end

function GDS_LoginLog.MergePair(rows,i)
    local older, newer = rows[i], rows[i-1]
    if not older or not newer or older == GDS_LoginLog.row or not older.ended
        or older.ended > newer.started or older.started >= newer.started then return end
    -- Keep the newest end/continuation flag and the oldest start.
    newer.joinedStarts = newer.joinedStarts or {}
    newer.joinedStarts[newer.started] = true
    for start in pairs(older.joinedStarts or {}) do newer.joinedStarts[start] = true end
    newer.manualStart = older.manualStart
    newer.started = older.started
    newer.partial = newer.partial or older.partial or older.questXP == nil or newer.questXP == nil
    for _, r in ipairs({older,newer}) do
        if r.dungeonRawXP == nil then
            r.unknownXP = math.max(0,(r.xp or 0)-(r.questXP or 0))
        end
    end
    for _, field in ipairs({"seconds","xp","kills","items","questXP","questCoin","lootCoin",
        "itemValue","hk","kb","unknownXP","dungeonRawXP","dungeonQuestXP"}) do
        newer[field] = (older[field] or 0) + (newer[field] or 0)
    end
    for _, award in ipairs(older.pendingLoot or {}) do
        newer.pendingLoot = newer.pendingLoot or {}
        table.insert(newer.pendingLoot,award)
    end
    local segments = older.walletSegments or {}
    for _, segment in ipairs(newer.walletSegments or {}) do table.insert(segments,segment) end
    newer.walletLegacy = older.walletLegacy or newer.walletLegacy or not older.walletSegments or not newer.walletSegments
    newer.walletIncomplete = older.walletIncomplete or newer.walletIncomplete
    newer.walletSegments = segments
    newer.net = (newer.net or 0) + (older.net or 0)
    table.remove(rows,i)
    for _, lookup in ipairs(GDS_ItemCompat.pending or {}) do
        if lookup.login == older then lookup.login = newer end
    end
    return true
end

-- Run before starting the live row or scheduling pending price updates.
function GDS_LoginLog.Reconcile(rows)
    if not rows then return end
    local covered = {}
    for _, row in ipairs(rows) do
        for start in pairs(row.joinedStarts or {}) do covered[start] = true end
    end
    for i=#rows,1,-1 do
        if covered[rows[i].started] then table.remove(rows,i) end
    end
    for i=#rows,2,-1 do
        local older, newer = rows[i], rows[i-1]
        local gap = older.ended and newer.started and newer.started - older.ended
        if gap and gap >= 0 and gap <= 3600 and older.continuable ~= false and not newer.manualStart then
            GDS_LoginLog.MergePair(rows,i)
        end
    end
end

-- A segment records actual on-character balances while the player is in world.
-- A new login/reload gets its own opening balance, excluding offline changes.
function GDS_LoginLog.WalletSample()
    local log = GDS_LoginLog
    local row = log.row
    if not row or not log.worldReady then return end
    local money = GetMoney()
    if type(money) ~= "number" or (issecretvalue and issecretvalue(money)) or money < 0 then return end
    if not log.segment then
        log.segment = {first=money, last=money}
        table.insert(row.walletSegments,log.segment)
    else
        log.segment.last = money
    end
end

function GDS_LoginLog.WalletText(row,formatCoin)
    if not row.walletSegments or row.walletLegacy then return "Unverified (older data)" end
    if #row.walletSegments == 0 or row.walletIncomplete then return "Unavailable" end
    local change = 0
    for _, segment in ipairs(row.walletSegments) do
        change = change + (segment.last - segment.first)
    end
    return (change < 0 and "-" or "+") .. formatCoin(math.abs(change))
end

function GDS_LoginLog.Start(reason)
    if GDS_LoginLog.row then return end
    local rows = DB.loginHistory or {}
    DB.loginHistory = rows
    local now = time()
    local row = rows[1]
    local gap = row and type(row.ended) == "number" and now - row.ended
    local recentLogin = reason == "login" and gap and gap >= 0 and gap <= 3600
    if not (row and ((row.continuable and reason == "reload") or (row.continuable ~= false and recentLogin))) then
        row = {manualStart=reason == "enabled", walletSegments={}, started=now, seconds=0, net=0, xp=0, kills=0, items=0, questXP=0, questCoin=0, lootCoin=0, itemValue=0, hk=0, kb=0}
        table.insert(rows, 1, row)
    end
    if row.questXP == nil then
        row.partial = true
        row.itemValue = 0
        row.questXP, row.questCoin, row.lootCoin, row.hk, row.kb = 0,0,0,0,0
    end
    if row.dungeonRawXP == nil then
        row.unknownXP = math.max(0,row.xp - row.questXP)
        row.dungeonRawXP, row.dungeonQuestXP = 0, 0
    end
    row.continuable = nil
    GDS_LoginLog.row = row
    GDS_LoginLog.clock = GetTime()
    if not row.walletSegments then row.walletLegacy, row.walletSegments = true, {} end
    GDS_LoginLog.segment = nil
    GDS_LoginLog.WalletSample()
    GDS_LoginLog.xp, GDS_LoginLog.cap, GDS_LoginLog.level =
        UnitXP("player"), UnitXPMax("player"), UnitLevel("player")
end
function GDS_LoginLog.Sample()
    local log = GDS_LoginLog
    local row = log.row
    if not row then return end
    local xp, cap, level = UnitXP("player"), UnitXPMax("player"), UnitLevel("player")
    if level == log.level and xp < log.xp then return end
    local gain = level > log.level and (log.cap - log.xp + xp) or xp - log.xp
    if level >= log.level and gain > 0 then
        row.xp = row.xp + gain
        if GDS_LoginLog.InDungeon() then row.dungeonRawXP = row.dungeonRawXP + gain end
    end
    log.xp, log.cap, log.level = xp, cap, level
end
function GDS_LoginLog.Stop(continuable)
    local row = GDS_LoginLog.row
    if not row then return end
    GDS_LoginLog.Sample()
    row.seconds = row.seconds + math.max(0, GetTime() - GDS_LoginLog.clock)
    if not GDS_LoginLog.segment then row.walletIncomplete = true end
    GDS_LoginLog.segment = nil
    row.ended, row.continuable = time(), continuable
    GDS_LoginLog.row = nil
end
function GDS_LoginLog.Report(page)
    local rows = DB.loginHistory or {}
    if #rows == 0 then print("GrindTracker: Enable Login tracker in Settings to record login sessions."); return end
    local pages = math.ceil(#rows / 10)
    page = math.max(1, math.min(pages, page or 1))
    print("GrindTracker login history  " .. page .. "/" .. pages .. "  (/gt logins <page>)")
    GDS_LoginLog.Sample()
    for i = (page-1)*10+1, math.min(page*10,#rows) do
        local row = rows[i]
        local live = row == GDS_LoginLog.row
        local duration = row.seconds + (live and math.max(0, GetTime()-GDS_LoginLog.clock) or 0)
        print(date("%b %d %I:%M %p", row.started) .. " – " ..
            (live and "Now" or date("%b %d %I:%M %p",row.ended or row.started)) ..
            "  " .. FormatTime(math.floor(duration)) .. "  Net coin " ..
            GDS_LoginLog.WalletText(row,CoinShort) ..
            "  XP " .. FmtNum(row.xp) .. "  Kills " .. row.kills .. "  Items looted " .. row.items)
    end
end

local function OnLoot(msg, guid)
    if GDS_LoginLog.experimentalQuestReceipt or merchantOpen then return end
    if not (S and S.running and not S.paused) and not GDS_PartySession.Active() and not GDS_LoginLog.row then return end
    if not msg then return end
    -- A crafted item is an inventory conversion, not extra farming income.
    if type(msg) ~= "string" or (issecretvalue and issecretvalue(msg)) then return end
    local exclusion = IsCraftedLoot(msg) and "crafted item" or IgnoreProfessionLoot() and "profession window"
        or IgnoreMailboxLoot() and "mailbox" or GDS_Trade.IgnoreIncoming() and "trade"
    if exclusion then
        if debugMode then
            DEFAULT_CHAT_FRAME:AddMessage("|cFFAAAAAA[GT]|r ignored item: "..exclusion)
        end
        return
    end
    local lootKind=GDS_ItemCompat.LootKind(msg,guid,IsOwnLoot)
    if not lootKind then
        if debugMode then DEFAULT_CHAT_FRAME:AddMessage("[GT loot] No self receipt: "..msg) end
        return
    end

    if debugMode then
        DEFAULT_CHAT_FRAME:AddMessage("|cFFFFAA00[GT raw]|r " .. msg:gsub("|","||"))
    end

    local ok, err = pcall(function()

        -- Quality: |cnIQ2:  — colon terminator
        local qualStr = msg:match("|cnIQ(%d+):")
        local quality = qualStr and tonumber(qualStr) or nil

        -- Item ID
        local itemID = tonumber(msg:match("|Hitem:(%d+)"))
        if not itemID then
            if debugMode then
                DEFAULT_CHAT_FRAME:AddMessage("|cFFFF0000[GT]|r no itemID in message")
            end
            return
        end

        -- Fetch item info by numeric ID — most reliable, works even cold cache
        local infoName, infoLink, infoQuality, _, _, _, _, _, _, _, infoVendor =
            GDS_ItemCompat.GetInfo(itemID)

        -- The message may contain unrelated [Loot] UI labels. Read only the
        -- actual item's hyperlink label; use C_Item's real name when cached.
        local linkedName = msg:match("|Hitem:%d+[^|]*|h%[([^|%]]+)")
        local itemName = infoName or linkedName or ("Item:"..itemID)
        if itemName == "Loot" or itemName == "" then
            itemName = "Item:"..itemID
        end

        -- Quality fallback
        if quality == nil then quality = infoQuality end

        -- Quantity: last xN in message; 1 if absent
        local qty = 1
        for n in msg:gmatch("x(%d+)") do qty = tonumber(n) or qty end
        if GDS_ItemCompat.IsDisenchantReceipt(itemID,qty) then return end
        if GDS_ItemCompat.DuplicateAward(itemID,qty,lootKind,quality) then return end

        if GDS_LoginLog.row then
            GDS_LoginLog.row.items = GDS_LoginLog.row.items + qty
        end

        if debugMode then
            DEFAULT_CHAT_FRAME:AddMessage(
                "|cFFAAAAAA[GT]|r '"..itemName.."' Q="..tostring(quality)
                .." id="..itemID.." qty="..qty
                .." vendor="..tostring(infoVendor))
        end

        -- Use item:ID as the item lookup key for vendor-only valuation.
        local apiLink = "item:" .. itemID

        -- Quality-colored display link for loot log
        local qHex = "ffffffff"
        if     quality == 0 then qHex = "ff9d9d9d"
        elseif quality == 2 then qHex = "ff1eff00"
        elseif quality == 3 then qHex = "ff0070dd"
        elseif quality == 4 then qHex = "ffa335ee"
        elseif quality == 5 then qHex = "ffff8000"
        elseif quality == 6 then qHex = "ffe6cc80"
        end
        local displayLink = (type(infoLink)=="string" and infoLink~="" and infoLink)
            or ("|c"..qHex.."|Hitem:"..itemID.."|h["..itemName.."]|h|r")

        local unitPrice, deFallback = GetPricePerItem(apiLink, quality, infoVendor)
        local total     = unitPrice * qty

        local isQuestLoot = GDS_QuestItems.IsQuest(itemID)
        local login = GDS_LoginLog.row
        local loginAward
        if login and not isQuestLoot then
            login.itemValue = login.itemValue + total
            if infoName == nil or infoVendor == nil then
                loginAward = {id=itemID,qty=qty,total=total}
                login.pendingLoot = login.pendingLoot or {}
                table.insert(login.pendingLoot,loginAward)
            end
        end
        if not isQuestLoot and not (S and S.running and not S.paused)
            and GDS_PartySession.Active() then
            local run = GDS_PartySession.active.dungeonCurrent
            if run and run.lootItems then
                local item = run.lootItems[itemID] or {name=itemName, qty=0}
                item.qty = item.qty + qty
                run.lootItems[itemID] = item
                if GDS_LoginLog.ItemsChanged then GDS_LoginLog.ItemsChanged(run) end
            end
        end
        if isQuestLoot then GDS_PartySession.OnQuest(0,total)
        else GDS_PartySession.AddItem(total,itemID,false) end
        if S and S.running and not S.paused then
            if isQuestLoot then GDS_QuestItems.Credit(total)
            else S.itemGold = S.itemGold + total end
        end

        local source = "gather"
        if lastKillName and (GetTime()-lastKillTime) < 15 then
            source = "kill"
        end

        local recordedEntry
        if S and S.running and not S.paused then
            recordedEntry = {
            time      = S.timer,
            name      = itemName,
            itemID    = itemID,
            vendorPrice = tonumber(infoVendor),
            pricePending = false,
            link      = displayLink,
            qty       = qty,
            unitPrice = unitPrice, deFallback = deFallback,
            total     = total,
            quality   = quality,
            source    = source,
            receiptZone = GetRealZoneText and GetRealZoneText() or nil,
            }
            local instance, kind = GetInstanceInfo()
            if GDS_Dungeon.SafeText(kind) and kind == "party" and GDS_Dungeon.SafeText(instance) then
                recordedEntry.receiptZone = "Dungeon: " .. instance
            elseif not GDS_Dungeon.SafeText(recordedEntry.receiptZone) then
                recordedEntry.receiptZone = nil
            end
            table.insert(S.loot,recordedEntry)
            GDS_DungeonLootSync.Stamp(recordedEntry)
            GDS_DungeonLootSync.Reconcile()
            recordedEntry.alertEligible = (tonumber(DB.dropAlertGold) or 0) > 0 or nil
            GDS_ItemCompat.AlertDrop(recordedEntry)
        end
        if infoName == nil or infoVendor == nil then
            GDS_ItemCompat.Queue(itemID,qty,recordedEntry,
                recordedEntry and S or nil,
                GDS_PartySession.Active() and GDS_PartySession.active or nil,total,login,loginAward)
        end

        if debugMode then
            DEFAULT_CHAT_FRAME:AddMessage(
                "|cFF00FF00[GT loot]|r "..itemName.." x"..qty
                .."  unit="..math.floor(unitPrice/10000).."g"
                ..math.floor(unitPrice%10000/100).."s"
                .."  total="..math.floor(total/10000).."g"
                ..math.floor(total%10000/100).."s")
        end

        RefreshStats()
        RefreshLootLog()
    end)

    if not ok then
        DEFAULT_CHAT_FRAME:AddMessage("|cFFFF0000[GT ERROR]|r "..tostring(err))
    end
end

-------------------------------------------------------------------------------
-- MANUAL BAG TRACKING (Alt+Shift+click an inventory item)
-- Uses the same session loot/pricing path as automatic drops.
-------------------------------------------------------------------------------
local function AddManualBagItem(bag, slot)
    if not (S and S.running and not S.paused) and not GDS_PartySession.Active() then
        DEFAULT_CHAT_FRAME:AddMessage("|cFFD8DDE6GT|r Start a personal or party session before adding gear.")
        return
    end
    if not (C_Container and C_Container.GetContainerItemLink) then return end
    local link = C_Container.GetContainerItemLink(bag, slot)
    if type(link) ~= "string" then return end
    local id = tonumber(link:match("item:(%d+)"))
    if not id then return end
    -- An already-logged piece of gear should not earn twice. This includes
    -- loot caught automatically before the player clicked it.
    for _, entry in ipairs(S.loot) do
        if tonumber(entry.itemID) == id then
            DEFAULT_CHAT_FRAME:AddMessage("|cFFD8DDE6GT|r Already tracked: " .. (entry.link or entry.name or link))
            return
        end
    end
    local name, _, quality, _, _, _, _, _, _, _, vendor = GDS_ItemCompat.GetInfo(link)
    name = name or link:match("%[(.-)%]") or ("Item:" .. id)
    local unitPrice, deFallback = GetPricePerItem(link, quality, vendor)
    -- One inventory slot is one manual entry; stacked items use their slot count.
    local info = C_Container.GetContainerItemInfo and C_Container.GetContainerItemInfo(bag, slot)
    local qty = (type(info) == "table" and tonumber(info.stackCount)) or 1
    qty = math.max(1, math.floor(qty))
    local total = unitPrice * qty
    local personal, entry
    if S and S.running and not S.paused then
        personal = S
        entry = {
            time=S.timer, name=name, itemID=id, vendorPrice=tonumber(vendor),
            link=link, qty=qty, unitPrice=unitPrice, deFallback=deFallback, total=total,
            quality=quality, source="manual", pricePending=false,
        }
        table.insert(S.loot, entry)
        GDS_DungeonLootSync.Stamp(entry)
        GDS_DungeonLootSync.Reconcile()
        if GDS_QuestItems.IsQuest(id) then GDS_QuestItems.Credit(total)
        else S.itemGold = S.itemGold + total end
    end
    local party = GDS_PartySession.Active() and GDS_PartySession.active
    if GDS_QuestItems.IsQuest(id) then
        GDS_PartySession.OnQuest(0,total)
    elseif party and not party.manualIDs[id] then
        GDS_PartySession.AddItem(total,id,true)
    else
        party = nil
    end
    if vendor == nil and (personal or party) then
        GDS_ItemCompat.Queue(id, qty, entry, personal, party, total)
    end
    RefreshStats()
    RefreshLootLog()
    DEFAULT_CHAT_FRAME:AddMessage("|cFFD8DDE6GT|r Added manually: " .. link .. " x" .. qty .. " (" .. CoinShort(total) .. ")")
end

local function ManualBagModifiedClick(button, mouseButton)
    if mouseButton ~= "LeftButton" or not IsAltKeyDown() or not IsShiftKeyDown() then return end
    if not button then return end
    local bag, slot
    if button.GetBagID then bag = button:GetBagID() end
    if button.GetID then slot = button:GetID() end
    if bag == nil then
        local parent = button.GetParent and button:GetParent()
        if parent and parent.GetID then bag = parent:GetID() end
        if parent and parent.GetBagID then bag = parent:GetBagID() or bag end
    end
    if type(bag) ~= "number" or type(slot) ~= "number" then return end
    AddManualBagItem(bag, slot)
end

local manualClickInstalled = false
local function InstallManualBagClicks()
    if manualClickInstalled then return end
    -- Older Forever / Classic bag windows call these global handlers.
    if type(ContainerFrameItemButton_OnModifiedClick) == "function" then
        hooksecurefunc("ContainerFrameItemButton_OnModifiedClick", ManualBagModifiedClick)
    end
    if type(ContainerFrameItemButton_OnClick) == "function" then
        hooksecurefunc("ContainerFrameItemButton_OnClick", ManualBagModifiedClick)
    end

    -- Modern bag buttons instead use a mixin method. Merely hooking the old
    -- global functions does not see clicks on those clients.
    if type(ContainerFrameItemButtonMixin) == "table" then
        if type(ContainerFrameItemButtonMixin.OnModifiedClick) == "function" then
            hooksecurefunc(ContainerFrameItemButtonMixin, "OnModifiedClick", ManualBagModifiedClick)
        end
        if type(ContainerFrameItemButtonMixin.OnClick) == "function" then
            hooksecurefunc(ContainerFrameItemButtonMixin, "OnClick", ManualBagModifiedClick)
        end
    end

    -- Most reliable modern-client fallback: the game routes linked item clicks
    -- through here with an ItemLocation object identifying the clicked bag slot.
    -- On clients without ItemLocation (older Forever builds), the above hooks
    -- continue to handle the shortcut instead.
    if type(HandleModifiedItemClick) == "function" then
        hooksecurefunc("HandleModifiedItemClick", function(_, itemLocation)
            if not IsAltKeyDown() or not IsShiftKeyDown() then return end
            if not itemLocation or type(itemLocation.IsBagAndSlot) ~= "function" then return end
            local ok, isBag = pcall(itemLocation.IsBagAndSlot, itemLocation)
            if not ok or not isBag then return end
            local success, bag, slot = pcall(itemLocation.GetBagAndSlot, itemLocation)
            if success and type(bag) == "number" and type(slot) == "number" then
                AddManualBagItem(bag, slot)
            end
        end)
    end
    manualClickInstalled = true
end

-------------------------------------------------------------------------------
-- XP tracking
-- XP in UnitXP is relative to the CURRENT level, not the full session.
-- Maintain an incremental, cumulative raw-XP ledger and subtract quest XP
-- separately; resetting a baseline on PLAYER_LEVEL_UP loses earlier levels.
-------------------------------------------------------------------------------
GDS_XP = GDS_XP or {} -- namespace keeps WoW's 200-local chunk limit intact
function GDS_XP.Snapshot()
    local cur = math.max(0, tonumber(UnitXP("player")) or 0)
    local cap = math.max(0, tonumber(UnitXPMax("player")) or 0)
    local level = math.max(1, tonumber(UnitLevel("player")) or 1)
    return cur, cap, level
end

function GDS_XP.ResetBaseline()
    if not S then return end
    S.lastXP, S.lastXPMax, S.lastXPLevel = GDS_XP.Snapshot()
end

local function OnXPUpdate()
    GDS_PartySession.OnXP()
    if not S or not S.running then return end
    local cur, cap, level = GDS_XP.Snapshot()
    local oldXP = tonumber(S.lastXP)
    local oldCap = tonumber(S.lastXPMax)
    local oldLevel = tonumber(S.lastXPLevel)
    if not oldXP or not oldCap or not oldLevel then
        -- Recover from an older /reload snapshot without re-awarding prior XP.
        GDS_XP.ResetBaseline()
        return
    end

    local gained = 0
    if level > oldLevel then
        -- Finish the OLD bar, then count any XP already earned in the new bar.
        -- Compare with the stored old cap, never the new level's larger cap.
        gained = math.max(0, oldCap - oldXP) + cur
    elseif level == oldLevel then
        if cur < oldXP then
            -- During a level-up, PLAYER_XP_UPDATE may arrive before UnitLevel
            -- catches up. Preserve the old snapshot until the new level exists.
            return
        end
        gained = cur - oldXP
    end
    -- A level decrease (e.g. character-level changes) is a new baseline,
    -- not negative earned XP; likewise paused XP is not farm-session XP.
    S.lastXP, S.lastXPMax, S.lastXPLevel = cur, cap, level
    if not S.paused then
        S.xpRawGained = math.max(0, tonumber(S.xpRawGained) or 0) + math.max(0, gained)
        S.xpGained = math.max(0, S.xpRawGained - (S.questXPExcluded or 0))
    end
    RefreshStats()
end

local function OnLevelUp()
    local personal, party = S, GDS_PartySession.active
    C_Timer.After(0.1, function()
        if S == personal and S and S.running and GDS_PartySession.active == party then
            OnXPUpdate()
        elseif party and GDS_PartySession.active == party then
            GDS_PartySession.OnXP()
        end
    end)
end

-------------------------------------------------------------------------------
-- Money tracking
-------------------------------------------------------------------------------
-- Use the game's actual money-loot chat message to identify true coin pickups.
-- In particular, a loot pickup immediately after a quest or mailbox visit must
-- not be mistaken for a quest payout or delayed auction-mail payment.
-- This is global to avoid exceeding the addon's Lua chunk local-variable limit.
GDS_Coin = GDS_Coin or {}
GDS_Coin.lastLootAt = -100
GDS_Coin.lastLootAmount = nil

function GDS_Coin.IsOwnLootMessage(msg)
    if type(msg) ~= "string" or (issecretvalue and issecretvalue(msg)) then return false end
    for _, name in ipairs({"YOU_LOOT_MONEY", "YOU_LOOT_MONEY_GUILD",
                          "LOOT_MONEY_SPLIT", "LOOT_MONEY_SPLIT_GUILD"}) do
        local fmt = _G[name]
        if type(fmt) == "string" then
            local prefix = fmt:match("^(.-)%%")
            if prefix and prefix ~= "" and msg:sub(1, #prefix) == prefix then return true end
        end
    end
    -- English-client fallback when any localization globals are unavailable.
    return msg:match("^You loot%s") ~= nil
        or msg:match("^Your share of the loot is%s") ~= nil
end

function GDS_Coin.ParseLootAmount(msg)
    -- Used to associate a money event with the matching chat loot event, not
    -- as the primary source of currency totals. Unparseable/localized messages
    -- still get the ordinary balance-delta handling.
    local str = msg:gsub(",", ""):lower()
    local g = tonumber(str:match("(%d+)%s+gold")) or 0
    local s = tonumber(str:match("(%d+)%s+silver")) or 0
    local c = tonumber(str:match("(%d+)%s+copper")) or 0
    local amount = g*10000+s*100+c
    return amount > 0 and amount or nil
end

function GDS_Coin.MatchesRecentLoot(delta)
    local age = GetTime() - (GDS_Coin.lastLootAt or -100)
    if age < 0 or age > 1.0 then return false end
    local amount = GDS_Coin.lastLootAmount
    return amount == nil or amount == delta
end

function GDS_Coin.OnLootMessage(msg)
    -- Mail and player-to-player trade payouts must never be mob-loot signals.
    -- A real post-trade mob pickup must still be accepted after the trade
    -- window closes. A TRADE_CLOSED grace period only filters unverified gains.
    if mailboxOpen or GDS_ItemCompat.Visible(MailFrame)
        or GDS_Trade.IsOpen() then return end
    if not GDS_Coin.IsOwnLootMessage(msg) then return end
    local amount = GDS_Coin.ParseLootAmount(msg)
    if amount and GDS_LoginLog.row then
        GDS_LoginLog.row.lootCoin = GDS_LoginLog.row.lootCoin + amount
    end
    -- The balance-delta handler credits both sessions. This chat message
    -- only verifies previously excluded coin, preventing double counting.
    GDS_Coin.lastLootAt = GetTime()
    GDS_Coin.lastLootAmount = amount
    -- CHAT_MSG_MONEY can fire just AFTER PLAYER_MONEY. Undo any incorrect
    -- suppression of that already-received drop, without crediting it twice.
    local recent = recentMoneyGain
    if not recent or (not (S and S.running and not S.paused)
        and not GDS_PartySession.Active()) then return end
    if GetTime() - recent.time > 1.0 then return end
    if amount and recent.raw ~= amount then return end
    -- Never turn an unparseable/ambiguous loot line into a trade payment.
    if recent.fromTrade and amount == nil then return end
    recent.isLoot = true
    local restore = math.max(0, recent.excluded or 0)
    if restore > 0 then
        if S and S.running and not S.paused then
            S.coinGold = (S.coinGold or 0) + restore
            local m = recent.minute
            S.coinByMinute[m] = (S.coinByMinute[m] or 0) + restore
        end
        if GDS_PartySession.Active() then
            GDS_PartySession.AddCoin(restore)
            recent.partyCredited = true
        end
        recent.amount = (recent.amount or 0) + restore
        recent.excluded = 0
        if recent.fromQuest then
            pendingQuestMoney = pendingQuestMoney + restore
            pendingQuestUntil = math.max(pendingQuestUntil, GetTime() + 2.0)
        end
        if debugMode then
            DEFAULT_CHAT_FRAME:AddMessage("|cFF66DD66[GT coin]|r restored looted coin " .. CoinShort(restore))
        end
        RefreshStats()
    end
end

local function OnMoneyChanged()
    local cur = GetMoney()
    local delta = cur - moneyBaseline
    -- Always refresh the baseline, including during pauses and exclusions.
    moneyBaseline = cur
    local personalActive = S and S.running and not S.paused
    local partyActive = GDS_PartySession.Active()
    if not personalActive and not partyActive then return end
    if delta <= 0 then
        if delta < 0 then recentMoneyGain = nil end
        return
    end
    local now = GetTime()
    local minute = math.floor((S and S.timer or 0) / 60)
    local verifiedLoot = GDS_Coin.MatchesRecentLoot(delta)

    -- Never count vendor sales twice (item value was already tracked).
    if merchantOpen or GDS_ItemCompat.Visible(MerchantFrame) then
        recentMoneyGain = nil
        return
    end

    -- Ignore money exchanged with players.  TRADE_CLOSED may precede the
    -- money update; the short grace period catches the delayed event too.
    -- Unlike chat-sourced coin, a generic positive PLAYER_MONEY delta is not
    -- evidence of farming income.
    if GDS_Trade.IsOpen() or (GDS_Trade.RecentlyClosed() and not verifiedLoot) then
        -- Keep an exclusion record for a real mob-loot message arriving on the
        -- following frame. The matching CHAT_MSG_MONEY then restores only the
        -- genuinely looted amount, never the unverified trade payment.
        recentMoneyGain = {amount=0, raw=delta, excluded=delta, time=now,
            minute=minute, fromTrade=true}
        if debugMode then
            DEFAULT_CHAT_FRAME:AddMessage("|cFFAAAAAA[GT coin]|r trade money ignored: " .. CoinShort(delta))
        end
        return
    end

    -- Money collected from mail is not farming. A self-loot chat event can
    -- override the short post-close grace period for a genuine new pickup.
    if IgnoreMailboxLoot() and not verifiedLoot then
        recentMoneyGain = {amount=0, raw=delta, excluded=delta, time=now,
            minute=minute, fromMail=true}
        if debugMode then
            DEFAULT_CHAT_FRAME:AddMessage("|cFFAAAAAA[GT coin]|r mail money ignored: " .. CoinShort(delta))
        end
        return
    end

    -- A quest payout is only a match if the balance gain covers the full
    -- expected reward. Never eat small, unrelated coin drops for four seconds.
    local questDeduction = 0
    if now > pendingQuestUntil then pendingQuestMoney = 0 end
    if DB and pendingQuestMoney > 0
        and delta >= pendingQuestMoney and not verifiedLoot then
        questDeduction = pendingQuestMoney
        pendingQuestMoney = 0
    end
    local farmDelta = delta - questDeduction
    recentMoneyGain = {amount=farmDelta, raw=delta, excluded=questDeduction,
        fromQuest=questDeduction > 0, isLoot=verifiedLoot,
        time=now, minute=minute, personalCredited=personalActive,
        partyCredited=partyActive}
    if farmDelta > 0 then
        if personalActive then
            S.coinGold = S.coinGold + farmDelta
            S.coinByMinute[minute] = (S.coinByMinute[minute] or 0) + farmDelta
            RefreshStats()
        end
        if partyActive then GDS_PartySession.AddCoin(farmDelta) end
    end
    if debugMode then
        DEFAULT_CHAT_FRAME:AddMessage("|cFF66DD66[GT coin]|r +" .. CoinShort(farmDelta)
            .. (questDeduction > 0 and (" quest excluded " .. CoinShort(questDeduction)) or ""))
    end
end

-- QUEST_TURNED_IN provides XP and copper earned on quest completion.
-- Quest XP/coin exclusions ALWAYS run for active sessions, even if the
-- separate quest-stat display toggle is OFF. Only displayed/archived quest
-- totals depend on the checkbox.
local function OnQuestTurnedIn(_, xpReward, moneyReward)
    -- Tracking display is optional; removing quest income from the farming
    -- session is mandatory, irrespective of the checkbox setting.
    if not DB then return end
    local xp = math.max(0, math.floor(tonumber(xpReward) or 0))
    local gold = math.max(0, math.floor(tonumber(moneyReward) or 0))
    local login = GDS_LoginLog.row
    if login then
        if xp > 0 then
            GDS_LoginLog.Sample()
            if GDS_LoginLog.InDungeon() then login.dungeonQuestXP = login.dungeonQuestXP + xp end
        end
        login.questXP = login.questXP + xp
        login.questCoin = login.questCoin + gold
    end
    GDS_PartySession.OnQuest(xp,gold)
    if S and S.running and not S.paused and DB.questTracking then
        S.questXP = (S.questXP or 0) + xp
        S.questGold = (S.questGold or 0) + gold
        -- Separate quest statistics are opt-in, but filtering is always on.
        DB.questTotals = DB.questTotals or {xp=0, gold=0}
        DB.questTotals.xp = (DB.questTotals.xp or 0) + xp
        DB.questTotals.gold = (DB.questTotals.gold or 0) + gold
    end
    if (S and S.running) or GDS_PartySession.Active() then
        if S and S.running and not S.paused then
            S.questXPExcluded = (S.questXPExcluded or 0) + xp
        end
        -- If PLAYER_MONEY was sent first, reverse only a whole matching quest
        -- reward. Old logic reversed any recent gain and could steal farm loot.
        local recent = recentMoneyGain
        if recent and GetTime() - recent.time <= 1.0 and not recent.isLoot
            and gold > 0 and (recent.amount or 0) >= gold then
            recent.amount = recent.amount - gold
            recent.excluded = (recent.excluded or 0) + gold
            recent.fromQuest = true
            if recent.personalCredited and S then
                S.coinGold = math.max(0, (S.coinGold or 0) - gold)
                local m = recent.minute
                S.coinByMinute[m] = math.max(0, (S.coinByMinute[m] or 0) - gold)
            end
            if recent.partyCredited and GDS_PartySession.active then
                local a=GDS_PartySession.active
                a.coin=math.max(0,(a.coin or 0)-gold)
            end
            gold = 0
        end
        pendingQuestMoney = pendingQuestMoney + gold
        pendingQuestUntil = GetTime() + 2.0
        OnXPUpdate()
        RefreshStats()
        GDS_PartySession.Refresh()
    end
    if SendPartyStats then SendPartyStats() end
    if RefreshPartyStats then RefreshPartyStats() end
end

-------------------------------------------------------------------------------
-- OPTIONAL PvP TRACKING -- honors and personal honorable killing blows.
-- WoW Forever/Midnight does not allow the unrestricted combat-log event.
-- Use changes in Blizzard's own honor counter for HK credit (including assists) and
-- PARTY_KILL for a personally landed killing blow; correlate them briefly so
-- non-honorable player kills, duels, and monster kills aren't falsely counted.
-- This table intentionally uses one global instead of many chunk-level locals:
-- GrindTracker is close to Lua's 200-local-variable chunk limit.
-------------------------------------------------------------------------------
GDS_PvP = GDS_PvP or {}

-- Count the exact HK changes that Blizzard credits to the character's
-- lifetime total, INCLUDING honorable group assists. Do not convert these to
-- solo killing blows. Some client versions have no working lifetime API, so
-- fall back to the daily counter only if the lifetime API is unavailable.
-- We rebase rather than import the whole counter when its source changes.
function GDS_PvP.ReadHonorCounter()
    for _, entry in ipairs({
        {name="lifetime", fn=GetPVPLifetimeStats},
        {name="today-fallback", fn=GetPVPSessionStats},
    }) do
        if type(entry.fn) == "function" then
            local ok, value = pcall(entry.fn)
            if ok and type(value) == "number"
                and not (issecretvalue and issecretvalue(value))
                and value >= 0 then
                return math.floor(value), entry.name
            end
        end
    end
    return nil, nil
end

-- Read the character's *actual* Blizzard lifetime HK total for the tooltip.
-- This is display-only: it must NEVER be added into the session delta counter.
-- Forever may initially return zero while PvP stats finish loading, so retain
-- the highest valid reading from this login instead of flickering back to 0.
function GDS_PvP.ReadLifetimeHK()
    if type(GetPVPLifetimeStats) == "function" then
        local ok, count = pcall(GetPVPLifetimeStats)
        if ok and type(count) == "number"
            and not (issecretvalue and issecretvalue(count))
            and count >= 0 then
            count = math.floor(count)
            if count > 0 or (GetTime() or 0) >= (GDS_PvP.initializingUntil or 0) then
                GDS_PvP.lifetimeHK = math.max(GDS_PvP.lifetimeHK or 0, count)
            end
        end
    end
    return GDS_PvP.lifetimeHK
end

function GDS_PvP.ResetBaseline(startup)
    GDS_PvP.lastCounter, GDS_PvP.lastCounterSource = GDS_PvP.ReadHonorCounter()
    -- A freshly loaded client may first report 0, then fill in historical HKs.
    -- Rebase silently during startup rather than treating that as new PvP.
    GDS_PvP.initializingUntil = (startup and ((GetTime() or 0) + 6)) or 0
    GDS_PvP.creditAt = 0
    GDS_PvP.unmatchedCredits = 0
    GDS_PvP.pendingBlows = {}
    GDS_PvP.seenVictims = {}
end

function GDS_PvP.IncrementHK(amount)
    if GDS_LoginLog.row then GDS_LoginLog.row.hk = GDS_LoginLog.row.hk + amount end
    if amount <= 0 or not DB or not DB.pvpTracking then return end
    DB.pvpTotals = DB.pvpTotals or {hk=0, kb=0}
    DB.pvpTotals.hk = (DB.pvpTotals.hk or 0) + amount
    GDS_PartySession.OnPvP("pvpHK",amount)
    -- A credited lifetime HK earned DURING an active personal session belongs
    -- in that very session, whether it was a direct kill or party assist.
    -- Idle/paused tracking remains excluded, as with other session statistics.
    if S and S.running and not S.paused then
        S.pvpHK = (S.pvpHK or 0) + amount
    end
    RefreshStats()
    if RefreshPartyStats then RefreshPartyStats() end
end

function GDS_PvP.IncrementKB()
    if GDS_LoginLog.row then GDS_LoginLog.row.kb = GDS_LoginLog.row.kb + 1 end
    if not DB or not DB.pvpTracking then return end
    DB.pvpTotals = DB.pvpTotals or {hk=0, kb=0}
    DB.pvpTotals.kb = (DB.pvpTotals.kb or 0) + 1
    GDS_PartySession.OnPvP("pvpKB",1)
    if GDS_KBBoard then GDS_KBBoard.OnLocalKB() end
    if S and S.running and not S.paused then
        S.pvpKB = (S.pvpKB or 0) + 1
    end
    RefreshStats()
    if RefreshPartyStats then RefreshPartyStats() end
end

function GDS_PvP.MatchBlows()
    local now = GetTime()
    GDS_PvP.pendingBlows = GDS_PvP.pendingBlows or {}
    -- Remove unmatched non-honorable blows after four seconds.
    for i=#GDS_PvP.pendingBlows,1,-1 do
        if now - GDS_PvP.pendingBlows[i] > 4 then
            table.remove(GDS_PvP.pendingBlows, i)
        end
    end
    if now - (GDS_PvP.creditAt or 0) > 4 then
        GDS_PvP.unmatchedCredits = 0
    end
    while (GDS_PvP.unmatchedCredits or 0) > 0 and #GDS_PvP.pendingBlows > 0 do
        table.remove(GDS_PvP.pendingBlows, 1)
        GDS_PvP.unmatchedCredits = GDS_PvP.unmatchedCredits - 1
        GDS_PvP.IncrementKB()
    end
end

-- Events indicate that HK credit may have changed. They do NOT represent
-- reliable "one kill per callback" counters on every Forever client. Only
-- count verified INCREASES in Blizzard's own HK total. Both the event handler
-- and the three-second poll share one baseline; repeated calls cannot double
-- the same credited HK.
function GDS_PvP.OnHonorChanged(isKillEvent)
    -- Keep lifetime display current, independently of live session counting.
    GDS_PvP.ReadLifetimeHK()
    local current, source = GDS_PvP.ReadHonorCounter()
    if current == nil then return end
    local previous, oldSource = GDS_PvP.lastCounter, GDS_PvP.lastCounterSource
    GDS_PvP.lastCounter, GDS_PvP.lastCounterSource = current, source

    -- Do not import older kills when a counter initializes or resets.
    if previous == nil or oldSource ~= source or current < previous then return end
    if (GetTime() or 0) < (GDS_PvP.initializingUntil or 0) then return end

    local delta = current - previous
    if delta == 0 then
        -- Sometimes Blizzard fires the event before the counter updates.
        -- A deferred read and the existing poll can catch the delayed change.
        if isKillEvent and C_Timer and C_Timer.After then
            C_Timer.After(0.4, function()
                if addonReady and GDS_PvP then GDS_PvP.OnHonorChanged(false) end
            end)
        end
        return
    end
    -- A large one-time jump is almost always historical stats becoming ready,
    -- not 25+ simultaneous personal HKs. Fail closed instead of overcounting.
    if delta > 20 then
        if debugMode then
            DEFAULT_CHAT_FRAME:AddMessage("|cFFFFAA00[GDS PvP]|r Ignored implausible HK counter jump: " .. delta)
        end
        return
    end
    if not DB or not (DB.pvpTracking or GDS_LoginLog.row) then return end

    GDS_PvP.IncrementHK(delta)
    local now = GetTime()
    if now - (GDS_PvP.creditAt or 0) > 4 then
        GDS_PvP.unmatchedCredits = 0
    end
    GDS_PvP.creditAt = now
    GDS_PvP.unmatchedCredits = (GDS_PvP.unmatchedCredits or 0) + delta
    GDS_PvP.MatchBlows()
end

function GDS_PvP.OnPartyKill(attackerGUID, victimGUID)
    if not DB or not (DB.pvpTracking or GDS_LoginLog.row) then return end
    -- Forever can mark identifiers as secret in certain PvP areas. Never
    -- compare/parse them if protected, and never count another party member.
    if type(attackerGUID) ~= "string" or type(victimGUID) ~= "string" then return end
    if issecretvalue and (issecretvalue(attackerGUID) or issecretvalue(victimGUID)) then return end
    if victimGUID:sub(1, 7) ~= "Player-" then return end
    local myGUID = UnitGUID and UnitGUID("player")
    local petGUID = UnitGUID and UnitGUID("pet")
    if issecretvalue then
        if myGUID and issecretvalue(myGUID) then myGUID = nil end
        if petGUID and issecretvalue(petGUID) then petGUID = nil end
    end
    if attackerGUID ~= myGUID and attackerGUID ~= petGUID then return end

    local now = GetTime()
    GDS_PvP.seenVictims = GDS_PvP.seenVictims or {}
    if GDS_PvP.seenVictims[victimGUID]
        and now - GDS_PvP.seenVictims[victimGUID] < 10 then return end
    -- Prune the short-lived GUID cache so it cannot grow forever.
    for guid, when in pairs(GDS_PvP.seenVictims) do
        if now - when > 10 then GDS_PvP.seenVictims[guid] = nil end
    end
    GDS_PvP.seenVictims[victimGUID] = now
    GDS_PvP.pendingBlows = GDS_PvP.pendingBlows or {}
    table.insert(GDS_PvP.pendingBlows, now)
    GDS_PvP.MatchBlows()
end

local function CopyMobKills(src)
    local out = {}
    if type(src) ~= "table" then return out end
    for name, count in pairs(src) do
        local kills = math.floor(tonumber(count) or 0)
        if name and name ~= "" and kills > 0 then
            out[name] = kills
        end
    end
    return out
end

-------------------------------------------------------------------------------
-- Kill tracking — taint-safe target/nameplate health and death-state events
--
-- Keep units registered from the moment they are first seen alive.  In particular,
-- do not discard the target on PLAYER_REGEN_DISABLED: fast kills may have only one
-- health event after combat begins, and that event can already report the unit dead.
-------------------------------------------------------------------------------

-- Units we listen to (target + visible nameplates)
local WATCHED_UNITIDS = { "target",
    "nameplate1","nameplate2","nameplate3","nameplate4",
    "nameplate5","nameplate6","nameplate7","nameplate8",
}

-- In Midnight, some UnitName results (raid/instance nameplates) are "secret"
-- strings that cannot be used as table keys. Detect and substitute "?".
local function SafeKey(name)
    if not name then return "?" end
    local probe = {}
    local ok = pcall(function() probe[name] = true end)
    if not ok then return "?" end
    return name
end

local function RecordKill(name, source)
    if GDS_LoginLog.row then GDS_LoginLog.row.kills = GDS_LoginLog.row.kills + 1 end
    if not S or not S.running or S.paused then return false end

    name = SafeKey(name)
    S.kills = S.kills + 1
    S.mobKills[name] = (S.mobKills[name] or 0) + 1
    lastKillName = name
    lastKillTime = GetTime()

    if debugMode then
        DEFAULT_CHAT_FRAME:AddMessage(
            "|cFF00FF00[GT kill]|r "..name.."  total="..S.kills
            .."  via="..tostring(source or "unknown"))
    end

    RefreshStats()
    return true
end

local function TrackUnit(unit)
    -- Only register living enemies — do NOT overwrite if already tracked
    if watchedUnits[unit] then return end  -- already watching, don't clobber
    if not UnitExists(unit) then return end
    if not UnitIsEnemy("player", unit) then return end
    if UnitIsDead(unit) then return end
    watchedUnits[unit] = { name = SafeKey(UnitName(unit)) }
    if GDS_Dungeon and GDS_Dungeon.ObserveUnit then GDS_Dungeon.ObserveUnit(unit) end
end

local function MarkDeadUnit(unit)
    if not unit then return end
    deadKills[unit] = true
    C_Timer.After(2, function() deadKills[unit] = nil end)
end

local function OnTargetChanged()
    if not GDS_LoginLog.row and (not S or not S.running) then return end
    -- Clear old target entry so TrackUnit can re-register the new target
    watchedUnits["target"] = nil
    TrackUnit("target")
    local wt = watchedUnits["target"]
    watchedTarget = wt and wt.name or nil
end

local function OnUnitHealth(unit)
    if not GDS_LoginLog.row and (not S or not S.running or S.paused) then return end
    if deadKills[unit] then return end

    -- If we aren't watching this unit yet, try to register it now
    if not watchedUnits[unit] then
        TrackUnit(unit)
        return  -- it just appeared alive; nothing to count yet
    end

    local w = watchedUnits[unit]

    -- Unit is dead: UnitIsDead is safe for addon use in Midnight.
    -- UnitHealth on nameplate units is taint-protected and cannot be compared.
    if not UnitIsDead(unit) then return end

    -- Clear this unit immediately so re-fires are ignored.
    watchedUnits[unit] = nil

    -- Deduplicate aliases under multiple unitIDs (e.g. target + nameplate).
    -- Deliberately avoids UnitGUID — it returns a tainted value inside delves, which
    -- causes "table index is secret" if used as a key.
    MarkDeadUnit(unit)
    for otherUnit in pairs(watchedUnits) do
        if UnitExists(otherUnit) and UnitIsUnit(unit, otherUnit) then
            watchedUnits[otherUnit] = nil
            MarkDeadUnit(otherUnit)
        end
    end

    RecordKill(w.name, unit)
    if unit == "target" then watchedTarget = nil end

end

-------------------------------------------------------------------------------
-- Session control
-------------------------------------------------------------------------------
-- Dungeon history: a run starts when a session enters an instance and ends
-- only after a CONFIRMED zone exit/switch. WoW can momentarily report "none"
-- during loading screens and ghost/corpse runs; the old immediate-close logic
-- could split a single dungeon into multiple history entries.
-- Use a global namespace rather than new chunk locals (Lua's 200-local limit).
GDS_Dungeon = GDS_Dungeon or {}
GDS_Dungeon.zoneSerial = 0
GDS_Dungeon.confirmSeconds = 8

-- Classic Scarlet Monastery wings share GetInstanceInfo() map 189. The UI map
-- may provide wing-specific 302..305 on some clients, but Classic clients may
-- return one generic map for all four. Never trust a map number ALONE: verify
-- its name or wait for a unique subzone or NPC. No movement or combat hooks.
GDS_Dungeon.scarletWings = {Graveyard=true, Library=true, Armory=true, Cathedral=true}
GDS_Dungeon.scarletMapWings = {[302]="Graveyard",[303]="Library",[304]="Armory",[305]="Cathedral"}
GDS_Dungeon.scarletSubzones = {
    ["forlorn cloister"]="Graveyard", ["the forlorn cloister"]="Graveyard",
    ["chamber of atonement"]="Graveyard", ["honor's tomb"]="Graveyard",
    ["huntsman's cloister"]="Library", ["gallery of treasures"]="Library",
    ["athenaeum"]="Library",
    ["training grounds"]="Armory", ["hall of champions"]="Armory",
    ["footman's armory"]="Armory", ["crusader's armory"]="Armory",
    ["chapel gardens"]="Cathedral", ["crusader's chapel"]="Cathedral",
}
-- Unique-wing enemies. Ignore generic Scarlet trash that also spawns elsewhere.
GDS_Dungeon.scarletNPCs = {
    ["interrogator vishas"]="Graveyard", ["bloodmage thalnos"]="Graveyard",
    ["ironspine"]="Graveyard", ["azshir the sleepless"]="Graveyard",
    ["fallen champion"]="Graveyard",
    ["houndmaster loksey"]="Library", ["arcanist doan"]="Library",
    ["scarlet beastmaster"]="Library",
    ["herod"]="Armory", ["scarlet myrmidon"]="Armory",
    ["scarlet centurion"]="Armory",
    ["high inquisitor whitemane"]="Cathedral",
    ["scarlet commander mograine"]="Cathedral",
    ["high inquisitor fairbanks"]="Cathedral",
}

function GDS_Dungeon.IsScarlet(name)
    return type(name)=="string" and
        (name=="Scarlet Monastery" or name=="Scarlet Monastery of Old")
end

function GDS_Dungeon.SavedName(name,wing)
    if GDS_Dungeon.IsScarlet(name) and GDS_Dungeon.scarletWings[wing] then
        return "Scarlet Monastery - " .. wing
    end
    return name
end

function GDS_Dungeon.ShortName(name)
    if type(name)~="string" then return name end
    local wing=name:match("^Scarlet Monastery %- (.+)$")
    if wing then return "SM - " .. wing end
    if GDS_Dungeon.IsScarlet(name) then return "SM - Unidentified" end
    return name
end

function GDS_Dungeon.SafeText(text)
    return type(text)=="string" and not (issecretvalue and issecretvalue(text))
end

function GDS_Dungeon.WingFromPlace(text)
    if not GDS_Dungeon.SafeText(text) then return nil end
    local key=text:lower():match("^%s*(.-)%s*$")
    local sub=GDS_Dungeon.scarletSubzones[key]
    if sub then return sub end
    -- A uniquely named UI map is reliable; 'Scarlet Monastery' by itself isn't.
    for wing in pairs(GDS_Dungeon.scarletWings) do
        if key:find(wing:lower(),1,true) then return wing end
    end
    return nil
end

function GDS_Dungeon.DetectWing(name)
    if not GDS_Dungeon.IsScarlet(name) then return nil end
    -- Require the player to be inside a dungeon, not at the outside entrance.
    if type(GetInstanceInfo)=="function" then
        local ok, current, kind=pcall(GetInstanceInfo)
        if not ok or kind~="party" or not GDS_Dungeon.IsScarlet(current) then return nil end
    end
    -- Unique on-foot subzones are preferable to UI-map IDs, which can be
    -- shared by all four wings on some Classic-derived clients.
    for _, getter in ipairs({GetSubZoneText, GetMinimapZoneText}) do
        if type(getter)=="function" then
            local ok, place=pcall(getter)
            if ok then
                local wing=GDS_Dungeon.WingFromPlace(place)
                if wing then return wing, "subzone" end
            end
        end
    end
    if C_Map and type(C_Map.GetBestMapForUnit)=="function" then
        local ok, id=pcall(C_Map.GetBestMapForUnit,"player")
        if ok and type(id)=="number" and GDS_Dungeon.scarletMapWings[id]
            and type(C_Map.GetMapInfo)=="function" then
            local valid,info=pcall(C_Map.GetMapInfo,id)
            local wing = valid and type(info)=="table"
                and GDS_Dungeon.WingFromPlace(info.name) or nil
            -- Reject map 302 if Classic supplies it as a generic Scarlet map.
            if wing and wing==GDS_Dungeon.scarletMapWings[id] then return wing,"map" end
        end
    end
    return nil  -- do NOT guess; player can specify /gt wing <name>.
end

function GDS_Dungeon.CanReplaceWing(run, wing, source)
    if not run or not wing or not run.wing or run.wing==wing or run.manualWing then
        return false
    end
    -- A generic/stale UI map must not override a clear NPC or subzone signal.
    if source=="map" and (run.wingSource=="npc" or run.wingSource=="subzone") then
        return false
    end
    return true
end

function GDS_Dungeon.WingFromNPC(name)
    if not GDS_Dungeon.SafeText(name) then return nil end
    return GDS_Dungeon.scarletNPCs[name:lower()]
end

-- One-time, player-confirmed classification of the five pictured Nov 16 runs
-- and (if finished before this update is first loaded) the SIXTH run, Cathedral.
-- Match the first five by saved timestamp + duration rather than screen order or
-- earnings. Then take ONLY the earliest newer unclassified Scarlet run. Do not
-- infer a seventh run or modify anything recorded after the migration runs.
function GDS_Dungeon.CorrectScarletHistory()
    if not DB or DB.scarletHistoryCorrectedV1 then return end
    local targets = {
        ["2026-11-16 00:04|1341"]="Cathedral",  -- bottom #1
        ["2026-11-16 00:26|1079"]="Armory",     -- bottom #2
        ["2026-11-16 13:49|1548"]="Cathedral",  -- bottom #3 (1:49 PM)
        ["2026-11-16 19:52|1264"]="Cathedral",  -- bottom #4
        ["2026-11-16 20:19|1379"]="Cathedral",  -- bottom #5
    }
    local matches, counts={},{}
    local sixth, sixthDate, sixthAmbiguous=nil,nil,false
    for _,run in ipairs(DB.dungeonRuns or {}) do
        if type(run)=="table" and GDS_Dungeon.IsScarlet(run.dungeon) then
            local stamp=tostring(run.date or "")
            local key=stamp .. "|" .. tostring(math.floor(tonumber(run.duration) or 0))
            if targets[key] then
                matches[key]=run
                counts[key]=(counts[key] or 0)+1
            elseif stamp:match("^%d%d%d%d%-%d%d%-%d%d %d%d:%d%d$")
                and stamp > "2026-11-16 20:19" then
                -- The next unclassified legacy entry is the player's sixth run.
                -- Avoid guessing when multiple runs share that earliest minute.
                if not sixthDate or stamp < sixthDate then
                    sixth, sixthDate, sixthAmbiguous=run,stamp,false
                elseif stamp==sixthDate then
                    sixthAmbiguous=true
                end
            end
        end
    end
    local changed, uniqueOriginals=0,0
    for key,run in pairs(matches) do
        if counts[key]==1 then
            run.dungeon=GDS_Dungeon.SavedName(run.dungeon,targets[key])
            changed=changed+1
            uniqueOriginals=uniqueOriginals+1
        end
    end
    -- Only make this extra assumption if all five identified records exist;
    -- otherwise the sixth could be misidentified from a different history set.
    if uniqueOriginals==5 and sixth and not sixthAmbiguous then
        sixth.dungeon=GDS_Dungeon.SavedName(sixth.dungeon,"Cathedral")
        changed=changed+1
    end
    -- Run once at installation. All later runs use live wing detection or
    -- /gt wing cathedral|armory|library|graveyard if detection is unavailable.
    DB.scarletHistoryCorrectedV1=true
    if changed>0 then GDS_LiveDungeon.historySummary = nil end
    if changed>0 and DEFAULT_CHAT_FRAME then
        DEFAULT_CHAT_FRAME:AddMessage("|cFFD8DDE6Grind Dont Stop|r Classified " .. changed
            .. " saved Scarlet Monastery run(s) by your confirmed wing list.")
    end
end

-- InstanceID from GetInstanceInfo is a dungeon MAP ID, not a unique copy ID.
-- A death/corpse run can leave and reenter the same map; only a confirmed
-- reset or an ordinary alive exit should finish the current dungeon run.
-- These flags live on the active run so /reload keeps them intact.
function GDS_Dungeon.MarkDeath()
    local name, kind = GetInstanceInfo()
    if kind ~= "party" then return end
    if S and S.running and S.dungeonCurrent
        and S.dungeonCurrent.name == name then
        S.dungeonCurrent.deathRecovery = true
    end
    local a = GDS_PartySession and GDS_PartySession.active
    if a and a.dungeonCurrent and a.dungeonCurrent.name == name then
        a.dungeonCurrent.deathRecovery = true
        a.dungeonCurrent.exitPendingAt = nil
    end
    GDS_Dungeon.zoneSerial = (GDS_Dungeon.zoneSerial or 0) + 1
end

-- Only accept actual WoW success messages, never reset attempts or failures.
-- The localized Blizzard string normally looks like "%s has been reset."
function GDS_Dungeon.ResetNameFromMessage(message)
    if type(message) ~= "string" or (issecretvalue and issecretvalue(message)) then
        return nil
    end
    local template = INSTANCE_RESET_SUCCESS
    if type(template) ~= "string" or not template:find("%s", 1, true) then
        template = "%s has been reset."
    end
    local first = template:find("%s", 1, true)
    if not first then return nil end
    local prefix = template:sub(1, first - 1)
    local suffix = template:sub(first + 2)
    if #message < #prefix + #suffix + 1 then return nil end
    if message:sub(1, #prefix) ~= prefix then return nil end
    if suffix ~= "" and message:sub(-#suffix) ~= suffix then return nil end
    local dungeon = message:sub(#prefix + 1, #message - #suffix)
    if dungeon == "" then return nil end
    return dungeon
end


-- Once-only historical correction requested by the player. The Drowned City
-- incorrectly shows two extra entries from prior zone/loading transitions.
-- Keep every original saved entry and its earned gold/time; exclude exactly
-- two *existing* entries from the run COUNTS only. New runs remain countable.
-- Tagging the old records (rather than subtracting a permanent global offset)
-- also means Clear Dungeons resets the correction naturally.
-- Dungeon History dropdowns use the existing saved run records. A previous
-- Drowned City correction may mark entries as not counted; display those
-- entries too, so the user can identify and delete bad fragments explicitly.
function GDS_Dungeon.BuildHistoryGroups(savedRuns)
    local grouped, rows = {}, {}
    local allRuns, allGold = 0, 0
    for index, run in ipairs(savedRuns or {}) do
        if type(run) == "table" and type(run.dungeon) == "string" and run.dungeon ~= "" then
            local key = tostring(run.instanceID or 0) .. ":" .. run.dungeon
            if not grouped[key] then
                grouped[key] = {key=key, name=run.dungeon, runs=0, total=0,
                    duration=0, entries={}, bestValue=nil, bestDuration=nil}
                table.insert(rows, grouped[key])
            end
            local group = grouped[key]
            local coin = math.max(0, tonumber(run.coin) or 0)
            local items = math.max(0, tonumber(run.items) or 0)
            local earned = coin + items
            if not run.gdsExcludeRunCount then
                group.runs = group.runs + 1
                allRuns = allRuns + 1
                -- The tooltip uses the same Personal Best definition as the
                -- live dungeon mini: largest total earned; faster run wins a tie.
                -- Never count corrected/duplicate history fragments as records.
                local elapsed = math.max(0, tonumber(run.duration) or 0)
                if group.bestValue == nil or earned > group.bestValue
                    or (earned == group.bestValue and elapsed < (group.bestDuration or math.huge)) then
                    group.bestValue, group.bestDuration = earned, elapsed
                end
            end
            group.total = group.total + earned
            group.duration = group.duration + math.max(0, tonumber(run.duration) or 0)
            group.entries[#group.entries+1] = {run=run, index=index, gold=earned}
            allGold = allGold + earned
        end
    end
    table.sort(rows, function(a,b)
        if a.total == b.total then return a.name < b.name end
        return a.total > b.total
    end)
    for _, group in ipairs(rows) do
        table.sort(group.entries, function(a,b)
            local ad, bd = a.run.date or "", b.run.date or ""
            if ad == bd then return a.index < b.index end
            return ad > bd
        end)
    end
    return rows, allRuns, allGold
end

-- Single-button Dungeon History export: clipboard only, no new window or addon file.
-- Per-run copper values preserve precision and are easy to analyze in Excel.
function GDS_Dungeon.ExportCSV()
    if not DB or type(DB.dungeonRuns) ~= "table" or #DB.dungeonRuns == 0 then
        DEFAULT_CHAT_FRAME:AddMessage("|cFFD8DDE6Grind Dont Stop|r No dungeon runs to export.")
        return
    end
    local function Cell(value)
        return '"' .. tostring(value or ""):gsub('"', '""') .. '"'
    end
    local rows = {"Dungeon,Date,Duration Seconds,Coin Copper,Items Copper,Total Copper,Repairs Copper,Counts As Run"}
    for _, run in ipairs(DB.dungeonRuns) do
        if type(run)=="table" and type(run.dungeon)=="string" then
            local coin=math.max(0,math.floor(tonumber(run.coin) or 0))
            local items=math.max(0,math.floor(tonumber(run.items) or 0))
            rows[#rows+1] = table.concat({Cell(run.dungeon), Cell(run.date),
                math.floor(tonumber(run.duration) or 0), coin, items, coin+items,
                math.max(0,math.floor(tonumber(run.repairCosts) or 0)),
                run.gdsExcludeRunCount and "No" or "Yes"}, ",")
        end
    end
    if C_Clipboard and type(C_Clipboard.SetText)=="function" then
        local ok=pcall(C_Clipboard.SetText,table.concat(rows,"\n"))
        if ok then
            DEFAULT_CHAT_FRAME:AddMessage("|cFFD8DDE6Grind Dont Stop|r Dungeon CSV copied to clipboard — paste into Excel.")
            return
        end
    end
    -- A small, on-demand copy box is the fallback for Forever clients that
    -- don't expose C_Clipboard. It is NOT permanently displayed in History.
    local f=GDS_Dungeon.csvWindow
    if not f then
        f=CreateFrame("Frame","GDSDungeonExportWindow",UIParent,
            BackdropTemplateMixin and "BackdropTemplate" or nil)
        GDS_FocusWindow(f)
        f:SetSize(565,360)
        f:SetPoint("CENTER",UIParent,"CENTER",0,30)
        f:SetFrameStrata("DIALOG")
        f:EnableMouse(true); f:SetMovable(true)
        f:RegisterForDrag("LeftButton")
        f:SetScript("OnDragStart",f.StartMoving)
        f:SetScript("OnDragStop",f.StopMovingOrSizing)
        -- This function is declared before the local ApplyBackdrop/MakeBtn
        -- constructors; build the popup directly to avoid unresolved upvalues.
        if f.SetBackdrop then
            f:SetBackdrop({bgFile="Interface\\Buttons\\WHITE8X8",
                edgeFile="Interface\\Buttons\\WHITE8X8",edgeSize=2})
            f:SetBackdropColor(.04,.055,.07,.98)
            f:SetBackdropBorderColor(.55,.43,.22,1)
        else
            local bg=f:CreateTexture(nil,"BACKGROUND")
            bg:SetAllPoints()
            bg:SetColorTexture(.04,.055,.07,.98)
        end
        local title=f:CreateFontString(nil,"OVERLAY","GameFontNormal")
        title:SetPoint("TOPLEFT",14,-13)
        title:SetText("Dungeon History CSV |  Ctrl+C to copy")
        local close=CreateFrame("Button",nil,f)
        close:SetSize(25,22)
        close:SetPoint("TOPRIGHT",-8,-8)
        local closeLabel=close:CreateFontString(nil,"OVERLAY","GameFontNormal")
        closeLabel:SetAllPoints()
        closeLabel:SetText("X")
        close:SetScript("OnClick",function() f:Hide() end)
        local scroll=CreateFrame("ScrollFrame",nil,f,"UIPanelScrollFrameTemplate")
        scroll:SetPoint("TOPLEFT",14,-45)
        scroll:SetPoint("BOTTOMRIGHT",-31,15)
        local edit=CreateFrame("EditBox",nil,scroll)
        edit:SetMultiLine(true)
        edit:SetAutoFocus(false)
        edit:SetFontObject("ChatFontNormal")
        edit:SetWidth(505)
        edit:SetHeight(300)
        edit:SetScript("OnEscapePressed",function() f:Hide() end)
        scroll:SetScrollChild(edit)
        f.csvEdit=edit
        f:Hide()
        GDS_Dungeon.csvWindow=f
    end
    f.csvEdit:SetText(table.concat(rows,"\n"))
    f.csvEdit:SetHeight(math.max(300,#rows*17))
    f:Show()
    f.csvEdit:SetFocus()
    f.csvEdit:HighlightText()
    DEFAULT_CHAT_FRAME:AddMessage("|cFFD8DDE6Grind Dont Stop|r Select CSV in the popup and press Ctrl+C, then paste into Excel.")
end

-- Original component records retain their analytics IDs; never credit session totals.
function GDS_Dungeon.SumCombined(run)
    local fields={"duration","coin","items","repairCosts","xp","kills"}
    for _, key in ipairs(fields) do run[key]=0 end
    run.lootItems={}
    for _, part in ipairs(run.gdsCombinedRuns or {}) do
        for _, key in ipairs(fields) do run[key]=run[key]+(tonumber(part[key]) or 0) end
        for id,item in pairs(part.lootItems or {}) do
            if type(item)=="table" then
                local out=run.lootItems[id] or {name=item.name,qty=0}
                out.qty=out.qty+(tonumber(item.qty) or 0)
                run.lootItems[id]=out
            end
        end
    end
end
function GDS_Dungeon.CombineRuns(chosen)
    if not DB or type(chosen)~="table" or #chosen<2 then return false end
    local first=chosen[1]
    local selected,indices={},{}
    for _,run in ipairs(chosen) do
        if selected[run] or run.dungeon~=first.dungeon or run.instanceID~=first.instanceID then return false end
        selected[run]=true
    end
    for i,run in ipairs(DB.dungeonRuns or {}) do if selected[run] then indices[#indices+1]=i end end
    if #indices~=#chosen then return false end
    local merged={dungeon=first.dungeon,instanceID=first.instanceID,date=first.date,gdsCombinedRuns={}}
    for _,i in ipairs(indices) do
        local run=DB.dungeonRuns[i]
        merged.gdsCombinedRuns[#merged.gdsCombinedRuns+1]=run
        if (run.date or "")>(merged.date or "") then merged.date=run.date end
    end
    GDS_Dungeon.SumCombined(merged)
    for i=#indices,1,-1 do table.remove(DB.dungeonRuns,indices[i]) end
    table.insert(DB.dungeonRuns,indices[1],merged)
    GDS_LiveDungeon.historySummary=nil
    return true
end
function GDS_Dungeon.UndoCombine(target)
    if not DB or type(target.gdsCombinedRuns)~="table" then return false end
    for i,run in ipairs(DB.dungeonRuns or {}) do
        if run==target then
            table.remove(DB.dungeonRuns,i)
            for j=#target.gdsCombinedRuns,1,-1 do table.insert(DB.dungeonRuns,i,target.gdsCombinedRuns[j]) end
            GDS_LiveDungeon.historySummary=nil
            return true
        end
    end
    return false
end
function GDS_Dungeon.DeleteHistoryRun(target)
    if not DB or type(DB.dungeonRuns) ~= "table" or type(target) ~= "table" then
        return false
    end
    -- Remove by object identity, not date or earnings (which can match).
    for index, run in ipairs(DB.dungeonRuns) do
        if run == target then
            DB.dungeonUndo = {run=run, index=index} -- one-step undo, character-local
            table.remove(DB.dungeonRuns, index)
            GDS_LiveDungeon.historySummary = nil
            return true
        end
    end
    return false
end

function GDS_Dungeon.RestoreDeletedRun()
    if not DB or type(DB.dungeonRuns) ~= "table" then return false end
    local saved = DB.dungeonUndo
    if type(saved) ~= "table" or type(saved.run) ~= "table" then return false end
    -- Never create a duplicate even if a stale undo record is somehow present.
    for _, run in ipairs(DB.dungeonRuns) do
        if run == saved.run then DB.dungeonUndo = nil; return false end
    end
    local at = math.max(1, math.min(#DB.dungeonRuns+1,
        math.floor(tonumber(saved.index) or (#DB.dungeonRuns+1))))
    table.insert(DB.dungeonRuns, at, saved.run)
    GDS_LiveDungeon.historySummary = nil
    DB.dungeonUndo = nil
    return true
end

local function FinishDungeonRun()
    if not DB or not S or not S.dungeonCurrent then return end
    local current = S.dungeonCurrent
    GDS_DungeonLootSync.EnsureRun(current)
    GDS_DungeonLootSync.Reconcile()
    -- Invalidate any pending exit confirmation before writing history.
    GDS_Dungeon.zoneSerial = (GDS_Dungeon.zoneSerial or 0) + 1
    S.dungeonCurrent = nil
    local elapsed = math.max(0, (S.timer or 0) - (current.startTime or 0))
    local coin = math.max(0, (S.coinGold or 0) - (current.startCoin or 0))
    local items = current.dungeonLootID
        and math.max(0, tonumber(current.dungeonItemValue) or 0)
        or math.max(0, (S.itemGold or 0) - (current.startItems or 0))
    local repairs = math.max(0, (S.repairCosts or 0) - (current.startRepairs or 0))
    -- Ignore loading-screen/instance-detection blips with no actual activity.
    -- Never discard a short genuine visit that earned gold.
    if elapsed < 8 and coin == 0 and items == 0 then return end
    DB.dungeonRuns = DB.dungeonRuns or {}
    table.insert(DB.dungeonRuns, 1, {
        dungeon = GDS_Dungeon.SavedName(current.name, current.wing), instanceID = current.instanceID,
        date = date("%Y-%m-%d %H:%M"),
        duration = elapsed, coin = coin, items = items, repairCosts = repairs, lootItems=current.lootItems,
        dungeonLootID = current.dungeonLootID,
        dungeonLootSessionID = current.dungeonLootSessionID,
        dungeonItemValue = current.dungeonItemValue,
        dungeonCarryValue = current.dungeonCarryValue,
        dungeonCarryLootItems = current.dungeonCarryLootItems,
    })
    GDS_LiveDungeon.historySummary = nil
    if historyFrame and historyFrame:IsShown() and historyActiveTab == "dungeons" then
        RefreshHistory()
    end
end

local function UpdateDungeonRun()
    if not DB or not S or not S.running then return end
    local name, instanceType, _, _, _, _, _, instanceID = GetInstanceInfo()
    local inside = instanceType == "party" and type(name) == "string" and name ~= ""
    local wing,source
    if inside then wing,source=GDS_Dungeon.DetectWing(name) end
    local current = S.dungeonCurrent
    if not current then
        -- No active run: enter dungeon. Cancel any stale transition callbacks.
        GDS_Dungeon.zoneSerial = (GDS_Dungeon.zoneSerial or 0) + 1
        if inside then
            S.dungeonCurrent = {lootItems={}, 
                name = name, instanceID = instanceID, wing=wing, wingSource=source,
                startTime = S.timer or 0,
                startCoin = S.coinGold or 0,
                startItems = S.itemGold or 0,
                startRepairs = S.repairCosts or 0,
            }
        end
        return
    end

    if inside and name == current.name and
        (not instanceID or not current.instanceID or instanceID == current.instanceID) then
        GDS_Dungeon.zoneSerial = (GDS_Dungeon.zoneSerial or 0) + 1
        if GDS_Dungeon.CanReplaceWing(current,wing,source) then
            -- Same instance ID, different Scarlet wing: split saved runs cleanly.
            FinishDungeonRun()
            S.dungeonCurrent = {lootItems={}, 
                name=name, instanceID=instanceID, wing=wing, wingSource=source,
                startTime=S.timer or 0, startCoin=S.coinGold or 0,
                startItems=S.itemGold or 0, startRepairs=S.repairCosts or 0,
            }
        elseif current.resetConfirmed then
            -- The map ID remains the same across fresh instance copies.
            -- An explicit, confirmed reset is the safe distinction.
            FinishDungeonRun()
            S.dungeonCurrent = {lootItems={}, 
                name = name, instanceID = instanceID, wing=wing, wingSource=source,
                startTime = S.timer or 0,
                startCoin = S.coinGold or 0,
                startItems = S.itemGold or 0,
                startRepairs = S.repairCosts or 0,
            }
        elseif current.deathOutsideSeen or not (UnitIsDeadOrGhost and UnitIsDeadOrGhost("player")) then
            if wing and not current.wing then current.wing,current.wingSource=wing,source end
            -- Reentered the old copy after a corpse run: still the same run.
            current.deathRecovery = nil
            current.deathOutsideSeen = nil
        end
        return
    end

    -- A corpse run may pass through an outdoor graveyard. Even if the player
    -- resurrects outside, never count it as a second run upon reentry.
    if UnitIsDeadOrGhost and UnitIsDeadOrGhost("player") then
        current.deathRecovery = true
        current.deathOutsideSeen = true
        GDS_Dungeon.zoneSerial = (GDS_Dungeon.zoneSerial or 0) + 1
        return
    end
    if current.deathRecovery and not current.resetConfirmed then
        GDS_Dungeon.zoneSerial = (GDS_Dungeon.zoneSerial or 0) + 1
        return
    end

    GDS_Dungeon.zoneSerial = (GDS_Dungeon.zoneSerial or 0) + 1
    local serial = GDS_Dungeon.zoneSerial
    local sessionRef, runRef = S, current
    C_Timer.After(GDS_Dungeon.confirmSeconds, function()
        if GDS_Dungeon.zoneSerial ~= serial or not DB or S ~= sessionRef
            or not S.running or S.dungeonCurrent ~= runRef then return end
        local nowName, nowType, _, _, _, _, _, nowID = GetInstanceInfo()
        local nowInside = nowType == "party" and type(nowName) == "string" and nowName ~= ""
        if nowInside and nowName == runRef.name and
            (not nowID or not runRef.instanceID or nowID == runRef.instanceID) then
            return -- still inside or reentered the same run
        end
        if UnitIsDeadOrGhost and UnitIsDeadOrGhost("player") then
            runRef.deathRecovery = true
            runRef.deathOutsideSeen = true
            return
        end
        if runRef.deathRecovery and not runRef.resetConfirmed then return end
        FinishDungeonRun()
        if nowInside and S == sessionRef and S.running and not S.dungeonCurrent then
            -- Genuinely switched to a different dungeon.
            S.dungeonCurrent = {lootItems={}, 
                name = nowName, instanceID = nowID,
                wing=GDS_Dungeon.DetectWing(nowName),
                startTime = S.timer or 0,
                startCoin = S.coinGold or 0,
                startItems = S.itemGold or 0,
                startRepairs = S.repairCosts or 0,
            }
        end
    end)
end

-- Refresh cheap wing signals while inside. Don't call UpdateDungeonRun every
-- tick: that would cancel its existing 8-second delayed exit confirmation.
function GDS_Dungeon.UpdateIdentification()
    local name,kind=GetInstanceInfo()
    if kind~="party" or not GDS_Dungeon.IsScarlet(name) then return end
    local wing,source=GDS_Dungeon.DetectWing(name)
    if not wing then return end
    local personal=S and S.running and S.dungeonCurrent
    if personal and personal.name==name then
        if not personal.wing then personal.wing,personal.wingSource=wing,source
        elseif GDS_Dungeon.CanReplaceWing(personal,wing,source) then UpdateDungeonRun() end
    end
    local party=GDS_PartySession and GDS_PartySession.active
    local other=party and party.dungeonCurrent
    if other and other.name==name then
        if not other.wing then other.wing,other.wingSource=wing,source
        elseif GDS_Dungeon.CanReplaceWing(other,wing,source) then GDS_PartySession.UpdateDungeon() end
    end
end

-- Also recognize distinctive mobs, useful when a client exposes neither a
-- wing-specific UI map nor a reliable subzone at the entrance.
function GDS_Dungeon.ObserveUnit(unit)
    if not unit or not UnitExists or not UnitExists(unit) then return end
    local name,kind=GetInstanceInfo()
    if kind~="party" or not GDS_Dungeon.IsScarlet(name) then return end
    local ok,mob=pcall(UnitName,unit)
    local wing=ok and GDS_Dungeon.WingFromNPC(mob) or nil
    if not wing then return end
    local personal=S and S.running and S.dungeonCurrent
    if personal and personal.name==name then
        if not personal.wing then personal.wing,personal.wingSource=wing,"npc"
        elseif GDS_Dungeon.CanReplaceWing(personal,wing,"npc") then
            -- A wing-specific mob proves a wing switch, even if a map is stale.
            local oldID=personal.instanceID
            FinishDungeonRun()
            S.dungeonCurrent={lootItems={}, name=name,instanceID=oldID,wing=wing,wingSource="npc",
                startTime=S.timer or 0,startCoin=S.coinGold or 0,
                startItems=S.itemGold or 0,startRepairs=S.repairCosts or 0}
        elseif personal.wing==wing then
            personal.wingSource="npc"
        end
    end
    local party=GDS_PartySession and GDS_PartySession.active
    local other=party and party.dungeonCurrent
    if other and other.name==name then
        if not other.wing then other.wing,other.wingSource=wing,"npc"
        elseif GDS_Dungeon.CanReplaceWing(other,wing,"npc") then
            GDS_PartySession.FinishDungeon()
            party.dungeonCurrent={lootItems={}, name=name,instanceID=other.instanceID,wing=wing,wingSource="npc",
                startTime=party.timer,startCoin=party.coin,startItems=party.items,
                startRepairs=party.repairs or 0}
        elseif other.wing==wing then
            other.wingSource="npc"
        end
    end
end

function GDS_Dungeon.ManualWing(wing)
    local name,kind=GetInstanceInfo()
    if kind~="party" or not GDS_Dungeon.IsScarlet(name) then return false end
    if not GDS_Dungeon.scarletWings[wing] then return false end
    local changed=false
    local personal=S and S.running and S.dungeonCurrent
    if personal and personal.name==name then
        personal.wing,personal.manualWing,personal.wingSource=wing,true,"manual"
        changed=true
    end
    local party=GDS_PartySession and GDS_PartySession.active
    local other=party and party.dungeonCurrent
    if other and other.name==name then
        other.wing,other.manualWing,other.wingSource=wing,true,"manual"
        changed=true
    end
    if changed and GDS_LiveDungeon and GDS_LiveDungeon.Refresh then
        GDS_LiveDungeon.Refresh()
    end
    return changed
end

-- A successful dungeon reset is the only reliable evidence of a NEW copy
-- when the player returns to the same map before the 8-second exit timer.
-- It may be seen locally or relayed by another party member running this addon.
function GDS_Dungeon.OnConfirmedReset(dungeonName)
    if type(dungeonName) ~= "string" or dungeonName == "" then return false end
    local didMatch = false
    local personal = S and S.running and S.dungeonCurrent
    local party = GDS_PartySession and GDS_PartySession.active
    local partyRun = party and party.dungeonCurrent
    if personal and personal.name == dungeonName then
        personal.resetConfirmed = true
        didMatch = true
    end
    if partyRun and partyRun.name == dungeonName then
        partyRun.resetConfirmed = true
        partyRun.exitPendingAt = nil
        didMatch = true
    end
    if didMatch then
        -- End the existing run immediately (even if the next entry is rapid).
        -- If zone data is briefly stale, the next zone event will split it.
        UpdateDungeonRun()
        if GDS_PartySession then GDS_PartySession.UpdateDungeon() end
    end
    return didMatch
end

function GDS_Dungeon.OnSystemMessage(message)
    local resetName = GDS_Dungeon.ResetNameFromMessage(message)
    if not resetName then return end
    GDS_Dungeon.OnConfirmedReset(resetName)
    if PartyAvailable() then
        -- The resetter may be the only party member shown the system message,
        -- even when they are not tracking a personal dungeon themselves.
        -- Use the existing validated party add-on channel for this notice.
        PartySend("DRESET:" .. resetName)
    end
end

-- Manual fallback if another leader resets and neither a local system
-- message nor a compatible party add-on packet is delivered.
-- Use ONLY for a real fresh dungeon copy (not a corpse run).
function GDS_Dungeon.MarkNewRun()
    if not DB then return false end
    local personal = S and S.running and S.dungeonCurrent
    local party = GDS_PartySession and GDS_PartySession.active
    local partyRun = party and party.dungeonCurrent
    if not personal and not partyRun then return false end
    if personal then FinishDungeonRun() end
    if partyRun then GDS_PartySession.FinishDungeon() end
    UpdateDungeonRun()
    if GDS_PartySession then GDS_PartySession.UpdateDungeon() end
    return true
end

local function ResetSession()
    pendingQuestMoney, pendingQuestUntil, recentMoneyGain = 0, 0, nil
    if GDS_Coin then GDS_Coin.lastLootAt, GDS_Coin.lastLootAmount = -100, nil end
    if DB then DB.activeSession = nil end
    if GDS_SessionMeta and GDS_SessionMeta.frame then GDS_SessionMeta.frame:Hide() end
    FinishDungeonRun()
    StopTicker()
    S             = NewSession()
    S.startXP     = UnitXP("player") or 0
    GDS_XP.ResetBaseline()
    moneyBaseline = GetMoney()
    watchedTarget = nil
    lastKillName  = nil
    lastKillTime  = 0
    watchedUnits  = {}
    deadKills     = {}
    if mainFrame and mainFrame.startBtn then
        mainFrame.startBtn.label:SetText("Start")
        mainFrame.startBtn:Enable()
    end
    RefreshStats()
    RefreshLootLog()
    if GDS_SessionMeta then GDS_SessionMeta.RefreshBadge() end
    if SendPartyStats then SendPartyStats() end
    if RefreshPartyStats then RefreshPartyStats() end
end

local function EndSession()
    if not DB then return end
    FinishDungeonRun()
    if S.timer > 0 or S.kills > 0 or S.coinGold > 0 or S.itemGold > 0
        or (S.questXP or 0) > 0 or (S.questGold or 0) > 0
        or (S.pvpHK or 0) > 0 or (S.pvpKB or 0) > 0 then
        if not DB.sessions then DB.sessions = {} end

        -- Pre-aggregate chart data before ResetSession wipes S
        local gm, im, itemTotals = {}, {}, {}
        for _, it in ipairs(S.loot) do
            if it.total > 0 and not GDS_QuestItems.EntryIsQuest(it) then
                local m  = math.floor(it.time / 60)
                local nm = it.name or "?"
                gm[m] = (gm[m] or 0) + it.total
                if not im[m] then im[m] = {} end
                im[m][nm] = (im[m][nm] or 0) + it.total
                itemTotals[nm] = (itemTotals[nm] or 0) + it.total
            end
        end
        local coinTotal = 0
        for m, v in pairs(S.coinByMinute) do
            gm[m] = (gm[m] or 0) + v
            if not im[m] then im[m] = {} end
            im[m]["__coin__"] = (im[m]["__coin__"] or 0) + v
            coinTotal = coinTotal + v
        end
        if coinTotal > 0 then itemTotals["__coin__"] = coinTotal end

        local sortedIt = {}
        for nm, g in pairs(itemTotals) do table.insert(sortedIt, {n=nm, g=g}) end
        table.sort(sortedIt, function(a,b) return a.g > b.g end)
        local MAX_STORE = 8
        if #sortedIt > MAX_STORE then
            local other = 0
            while #sortedIt > MAX_STORE do other = other + table.remove(sortedIt).g end
            table.insert(sortedIt, {n="__other__", g=other})
        end
        -- Prune im to only top stored items
        local topNm = {}
        for _, v in ipairs(sortedIt) do topNm[v.n] = true end
        for m, row in pairs(im) do
            local pruned, otherV = {}, 0
            for nm, v in pairs(row) do
                if topNm[nm] then pruned[nm] = v else otherV = otherV + v end
            end
            if otherV > 0 then pruned["__other__"] = (pruned["__other__"] or 0) + otherV end
            im[m] = pruned
        end

        local entry = {
            zone     = S.zone,
            sessionName = S.sessionName or "",
            sessionNote = S.sessionNote or "",
            date     = date("%Y-%m-%d %H:%M"),
            duration = S.timer,
            kills    = S.kills,
            pvpHK    = S.pvpHK or 0,
            pvpKB    = S.pvpKB or 0,
            questTrackingEnabled = S.questTrackingSeen == true or DB.questTracking == true,
            pvpTrackingEnabled = S.pvpTrackingSeen == true or DB.pvpTracking == true,
            xp       = S.xpGained,
            questXP  = S.questXP or 0,
            questGold = S.questGold or 0,
            coin     = S.coinGold,
            items    = S.itemGold,
            repairCosts = S.repairCosts or 0,
            bestDrop = GDS_ItemCompat.BestDrop(S.loot),
            bestDropRecorded = true,
            mobs     = CopyMobKills(S.mobKills),
            c        = {gm=gm, im=im, it=sortedIt},
        }
        table.insert(DB.sessions, 1, entry)
        if GDS_LoginLog.ExperimentalGrind then GDS_LoginLog.ExperimentalGrind(entry) end
        if entry.bestDrop then DEFAULT_CHAT_FRAME:AddMessage("Best Drop: " .. GDS_ItemCompat.DropText(entry.bestDrop)) end
        DEFAULT_CHAT_FRAME:AddMessage(
            "|cFFD8DDE6Grind Dont Stop|r Session saved!  "
            .. FormatTime(entry.duration)
            .. "  Kills: " .. FmtNum(entry.kills)
            .. "  Total: " .. Coin(entry.coin + entry.items))
    end
    ResetSession()
    if historyFrame and historyFrame:IsShown() then RefreshHistory() end
end

local function BeginSession()
    if not S or S.running then return end

    S.running     = true
    S.questTrackingSeen = S.questTrackingSeen == true or DB.questTracking == true
    S.pvpTrackingSeen = S.pvpTrackingSeen == true or DB.pvpTracking == true
    -- Keep the party-only segment on the dungeon ledger as ownership changes.
    -- Rebase its starting balances onto the independent personal counters.
    local party = GDS_PartySession.active
    local run = party and party.dungeonCurrent
    if run then
        run.dungeonCarryValue = math.max(0, (party.items or 0) - (run.startItems or 0))
        run.dungeonCarryLootItems = {}
        for id, item in pairs(run.lootItems or {}) do
            if type(item) == "table" then
                run.dungeonCarryLootItems[id] = {name=item.name, qty=item.qty}
            end
        end
        run.startTime = S.timer - math.max(0, party.timer - (run.startTime or 0))
        run.startCoin = S.coinGold - math.max(0, party.coin - (run.startCoin or 0))
        run.startItems = S.itemGold - math.max(0, party.items - (run.startItems or 0))
        run.startRepairs = (S.repairCosts or 0) - math.max(0, (party.repairs or 0) - (run.startRepairs or 0))
        party.dungeonCurrent = nil
        S.dungeonCurrent = run
        -- The carried party prefix belongs to this run, but not to Analytics.
        GDS_DungeonLootSync.EnsureRun(run)
        GDS_DungeonLootSync.Reconcile()
    end
    UpdateDungeonRun()
    S.paused      = false
    S.zone        = (GetRealZoneText and GetRealZoneText()) or (GetZoneText and GetZoneText())
    S.startXP     = UnitXP("player") or 0
    S.xpRawGained = math.max(0, (S.xpGained or 0) + (S.questXPExcluded or 0))
    GDS_XP.ResetBaseline()
    -- EasyFishing bridge: snapshot so Fish counts are "since Start", like XP.
    if _G.EasyFishing and EasyFishing.GetStats then
        local efs = EasyFishing.GetStats()
        S.fishStart = { fish = efs.fish, casts = efs.casts, value = efs.value }
    end
    moneyBaseline = GetMoney()
    watchedTarget = nil
    watchedUnits  = {}
    deadKills     = {}

    for _, unit in ipairs(WATCHED_UNITIDS) do TrackUnit(unit) end
    local wt = watchedUnits["target"]
    watchedTarget = wt and wt.name or nil

    if mainFrame and mainFrame.startBtn then
        mainFrame.startBtn.label:SetText("Pause")
        mainFrame.startBtn:Enable()
    end

    StopTicker()
    ticker = C_Timer.NewTicker(1, function()
        if S.running and not S.paused then
            S.timer = S.timer + 1
            RefreshStats()
        end
    end)
    RefreshStats()   -- draw the fishing rows immediately on Start
    if SendPartyStats then SendPartyStats() end
    if RefreshPartyStats then RefreshPartyStats() end
    DEFAULT_CHAT_FRAME:AddMessage("|cFFD8DDE6Grind Dont Stop|r started!")
end

-- Restore the live run after /reload or a character relog. The WoW client
-- serializes DB.activeSession on PLAYER_LOGOUT; elapsed offline time is not
-- added. Saved history stays separate until End Session is pressed.
local function RestoreActiveSession()
    local stored = DB and DB.activeSession
    if type(stored) ~= "table" or type(stored.loot) ~= "table" then
        ResetSession()
        return false
    end

    S = stored
    DB.activeSession = nil -- next logout makes a fresh snapshot
    S.running = S.running == true
    S.paused = S.paused == true
    S.timer = math.max(0, tonumber(S.timer) or 0)
    S.kills = tonumber(S.kills) or 0
    S.pvpHK = tonumber(S.pvpHK) or 0
    S.pvpKB = tonumber(S.pvpKB) or 0
    S.questTrackingSeen = S.questTrackingSeen == true or (S.running and DB.questTracking == true)
    S.pvpTrackingSeen = S.pvpTrackingSeen == true or (S.running and DB.pvpTracking == true)
    S.xpGained = math.max(0, tonumber(S.xpGained) or 0)
    S.questXPExcluded = math.max(0, tonumber(S.questXPExcluded) or 0)
    -- Earlier builds only saved current-level XP (which could reset on level-up).
    -- Preserve the currently displayed amount when upgrading an active run;
    -- already-lost XP from earlier levels cannot be reconstructed reliably.
    S.xpRawGained = math.max(tonumber(S.xpRawGained) or 0,
        S.xpGained + S.questXPExcluded)
    S.questXP = tonumber(S.questXP) or 0
    S.questGold = tonumber(S.questGold) or 0
    S.questItemGold = math.max(0, tonumber(S.questItemGold) or 0)
    S.startXP = tonumber(S.startXP) or (UnitXP("player") or 0)
    -- A /reload or relog preserves totals, but establishes a fresh character
    -- XP baseline; neither offline XP nor the same gain can be counted twice.
    GDS_XP.ResetBaseline()
    S.coinGold = tonumber(S.coinGold) or 0
    S.itemGold = tonumber(S.itemGold) or 0
    S.repairCosts = math.max(0, tonumber(S.repairCosts) or 0)
    S.mobKills = type(S.mobKills) == "table" and S.mobKills or {}
    S.coinByMinute = type(S.coinByMinute) == "table" and S.coinByMinute or {}
    S.emaXPH = tonumber(S.emaXPH) or 0
    S.emaGPH = tonumber(S.emaGPH) or 0
    S.emaKPH = tonumber(S.emaKPH) or 0
    moneyBaseline = GetMoney() -- do not count money movement during reload
    watchedTarget, lastKillName, lastKillTime = nil, nil, 0
    watchedUnits, deadKills = {}, {}
    if S.running then
        if S.dungeonCurrent then
            GDS_DungeonLootSync.EnsureRun(S.dungeonCurrent)
            GDS_DungeonLootSync.Reconcile()
        end
        for _, unit in ipairs(WATCHED_UNITIDS) do TrackUnit(unit) end
        local wt = watchedUnits["target"]
        watchedTarget = wt and wt.name or nil
        -- Install the ticker even for a restored PAUSED run. Otherwise
        -- pressing Resume after a /reload leaves the session clock frozen.
        StopTicker()
        ticker = C_Timer.NewTicker(1, function()
            if S and S.running and not S.paused then
                S.timer = S.timer + 1
                RefreshStats()
            end
        end)
    end
    if mainFrame and mainFrame.startBtn then
        mainFrame.startBtn.label:SetText(not S.running and "Start" or (S.paused and "Resume" or "Pause"))
        mainFrame.startBtn:Enable()
    end
    RefreshStats()
    RefreshLootLog()
    if GDS_SessionMeta then GDS_SessionMeta.RefreshBadge() end
    return true
end

local function TogglePause()
    if not S.running then
        local cd = 3
        mainFrame.startBtn.label:SetText(cd)
        mainFrame.startBtn:Disable()
        local ct
        ct = C_Timer.NewTicker(1, function()
            cd = cd - 1
            if cd > 0 then
                mainFrame.startBtn.label:SetText(cd)
            else
                ct:Cancel()
                BeginSession()
            end
        end)
    elseif S.paused then
        -- XP earned while paused must not slip in on the next XP event.
        GDS_XP.ResetBaseline()
        S.paused = false
        mainFrame.startBtn.label:SetText("Pause")
    else
        OnXPUpdate() -- collect any XP already reflected by the current bar
        S.paused = true
        mainFrame.startBtn.label:SetText("Resume")
    end
end

-- Reprice existing entries when the user changes an item's pricing source.
-- Saved sessions are historical snapshots and are not rewritten.
local function RepriceCurrentLoot(deOnly)
    if not S then return end
    for _, it in ipairs(S.loot) do
        local id = tonumber(it.itemID) or (it.link and tonumber(it.link:match("item:(%d+)")))
        local mode = (DB.priceOverrides or {})[tostring(id)]
        if id and not it.questReceipt and (not deOnly or mode == "disenchant" or (mode == "questDE" and DB.questTracking)) then
            it.itemID = id
            local vendor = it.vendorPrice
            if vendor == nil or it.pricePending then
                local _, _, _, _, _, _, _, _, _, _, v = GDS_ItemCompat.GetInfo(id)
                vendor = tonumber(v)
                it.vendorPrice = vendor
            end
            it.unitPrice, it.deFallback = GetPricePerItem("item:" .. id, it.quality, vendor)
            it.total = it.unitPrice * (tonumber(it.qty) or 1)
        end
    end
    GDS_QuestItems.Reconcile()
    RefreshStats()
    RefreshLootLog()
end

local function RecalcItemGold()
    GDS_QuestItems.Reconcile()
    RefreshStats()
end


-- Merge exactly two saved *session* snapshots; dungeon runs are a separate
-- ledger and must never be created or removed here. This is intentionally a
-- global namespace to avoid WoW Lua's per-chunk local-variable limit.
GDS_HistoryMerge = GDS_HistoryMerge or {}
function GDS_HistoryMerge.Make(a, b)
    if type(a) ~= "table" or type(b) ~= "table" or a == b then return nil end
    local older, newer = a, b
    if tostring(older.date or "") > tostring(newer.date or "") then
        older, newer = newer, older
    end
    local combined = {
        date = newer.date or older.date,
        combinedStart = older.combinedStart or older.date,
        combinedEnd = newer.combinedEnd or newer.date,
        combinedCount = math.max(1, tonumber(older.combinedCount) or 1)
            + math.max(1, tonumber(newer.combinedCount) or 1),
        zone = (older.zone == newer.zone and older.zone) or "Multiple areas",
    }
    combined.bestDropRecorded = older.bestDropRecorded and newer.bestDropRecorded or false
    combined.bestDrop = GDS_ItemCompat.BestDrop({older.bestDrop or {}, newer.bestDrop or {}})
    -- Preserve annotations when combining two saved sessions.
    local nameA, nameB = older.sessionName or "", newer.sessionName or ""
    if nameA ~= "" and nameB ~= "" and nameA ~= nameB then
        combined.sessionName = (nameA .. " + " .. nameB):sub(1,64)
    else
        combined.sessionName = nameB ~= "" and nameB or nameA
    end
    local noteA, noteB = older.sessionNote or "", newer.sessionNote or ""
    if noteA ~= "" and noteB ~= "" then
        combined.sessionNote = noteA .. "\n--- Combined session ---\n" .. noteB
    else
        combined.sessionNote = noteB ~= "" and noteB or noteA
    end
    for _, key in ipairs({"duration", "kills", "pvpHK", "pvpKB", "xp",
        "questXP", "questGold", "coin", "items", "repairCosts"}) do
        combined[key] = math.max(0, tonumber(older[key]) or 0)
            + math.max(0, tonumber(newer[key]) or 0)
    end
    combined.questTrackingEnabled = older.questTrackingEnabled == true or newer.questTrackingEnabled == true
        or (tonumber(older.questXP) or 0) > 0 or (tonumber(older.questGold) or 0) > 0
        or (tonumber(newer.questXP) or 0) > 0 or (tonumber(newer.questGold) or 0) > 0
    combined.pvpTrackingEnabled = older.pvpTrackingEnabled == true or newer.pvpTrackingEnabled == true
        or (tonumber(older.pvpHK) or 0) > 0 or (tonumber(older.pvpKB) or 0) > 0
        or (tonumber(newer.pvpHK) or 0) > 0 or (tonumber(newer.pvpKB) or 0) > 0
    combined.mobs = {}
    for _, part in ipairs({older, newer}) do
        local mobs = part.mobs or part.mobKills
        if type(mobs) == "table" then
            for name, count in pairs(mobs) do
                if type(name) == "string" and (tonumber(count) or 0) > 0 then
                    combined.mobs[name] = (combined.mobs[name] or 0) + tonumber(count)
                end
            end
        end
    end
    -- A historical chart is valid only if both source sessions have saved
    -- chart data; otherwise a partial chart would be misleading.
    if type(older.c) == "table" and type(newer.c) == "table" then
        local gm, im, totals = {}, {}, {}
        local elapsed = 0
        for _, part in ipairs({older, newer}) do
            local charts = part.c
            local offsetMinutes = math.floor(elapsed / 60)
            if type(charts.gm) == "table" then
                for minute, value in pairs(charts.gm) do
                    local min = tonumber(minute)
                    local gold = tonumber(value)
                    if min and min >= 0 and gold and gold > 0 then
                        local target = offsetMinutes + math.floor(min)
                        gm[target] = (gm[target] or 0) + gold
                    end
                end
            end
            if type(charts.im) == "table" then
                for minute, row in pairs(charts.im) do
                    local min = tonumber(minute)
                    if min and min >= 0 and type(row) == "table" then
                        local target = offsetMinutes + math.floor(min)
                        im[target] = im[target] or {}
                        for name, gold in pairs(row) do
                            if type(name) == "string" and (tonumber(gold) or 0) > 0 then
                                im[target][name] = (im[target][name] or 0) + gold
                            end
                        end
                    end
                end
            end
            if type(charts.it) == "table" then
                for _, it in ipairs(charts.it) do
                    if type(it.n) == "string" and (tonumber(it.g) or 0) > 0 then
                        totals[it.n] = (totals[it.n] or 0) + it.g
                    end
                end
            end
            elapsed = elapsed + math.max(0, tonumber(part.duration) or 0)
        end
        -- Prior archives may already have an __other__ bucket. Count it
        -- once, then fold any newly dropped categories into the same bucket.
        local other = totals.__other__ or 0
        totals.__other__ = nil
        local sorted = {}
        for name, value in pairs(totals) do
            sorted[#sorted+1] = {n=name, g=value}
        end
        table.sort(sorted, function(x,y)
            if x.g == y.g then return x.n < y.n end
            return x.g > y.g
        end)
        -- Keep the original top-eight/Other representation used by Analytics.
        while #sorted > 8 do
            local item = table.remove(sorted)
            other = other + item.g
        end
        local compact, visible = {}, {}
        for _, item in ipairs(sorted) do visible[item.n] = true; compact[#compact+1] = item end
        if other > 0 then
            compact[#compact+1] = {n="__other__", g=other}
            visible.__other__ = true
        end
        for minute, row in pairs(im) do
            local trimmed = {}
            for name, amount in pairs(row) do
                local key = visible[name] and name or "__other__"
                trimmed[key] = (trimmed[key] or 0) + amount
            end
            im[minute] = trimmed
        end
        combined.c = {gm=gm, im=im, it=compact}
    end
    return combined
end

function GDS_HistoryMerge.Apply(a, b)
    if not DB or type(DB.sessions) ~= "table" then return false end
    local ia, ib
    for i, session in ipairs(DB.sessions) do
        if session == a then ia = i end
        if session == b then ib = i end
    end
    if not ia or not ib or ia == ib then return false end
    local merged = GDS_HistoryMerge.Make(a, b)
    if not merged then return false end
    local insertion = math.min(ia, ib)
    table.remove(DB.sessions, math.max(ia, ib))
    table.remove(DB.sessions, insertion)
    table.insert(DB.sessions, insertion, merged)
    return true, merged
end

local function BuildBestiaryRows()
    local rows, mobTotals = {}, {}
    for _, se in ipairs(DB.sessions or {}) do
        local mobs = se.mobs or se.mobKills
        if type(mobs) == "table" then
            for name, count in pairs(mobs) do
                local kills = math.floor(tonumber(count) or 0)
                if name and name ~= "" and kills > 0 then
                    mobTotals[name] = (mobTotals[name] or 0) + kills
                end
            end
        end
    end

    local totalKills = 0
    for name, kills in pairs(mobTotals) do
        table.insert(rows, { name = name, kills = kills })
        totalKills = totalKills + kills
    end
    table.sort(rows, function(a, b)
        if a.kills == b.kills then
            return a.name < b.name
        end
        return a.kills > b.kills
    end)

    return rows, totalKills
end

local function GetTabAccent()
    local t = DB and DB.theme
    return (t and t.accentR or 0.88), (t and t.accentG or 0.92), (t and t.accentB or 0.96)
end

local function UpdateHistoryTabButton(btn)
    if not btn or not btn.bg then return end
    local active = (btn._gtTab == historyActiveTab)
    local theme = DB and DB.theme or DEFAULT_THEME
    if btn._gtPressed then
        btn.bg:SetColorTexture(theme.borderR * 0.25, theme.borderG * 0.25, theme.borderB * 0.25, 0.95)
    elseif btn._gtHovered then
        btn.bg:SetColorTexture(theme.borderR * 0.45, theme.borderG * 0.45, theme.borderB * 0.45, 0.95)
    elseif active and DB and DB.skinMode == "wowlook" then
        btn.bg:SetColorTexture(theme.headerR * 1.5, theme.headerG * 1.5, theme.headerB * 1.5, theme.headerA or 0.94)
    elseif active and DB and DB.skinMode == "wow" then
        btn.bg:SetColorTexture(theme.headerR, theme.headerG, theme.headerB, theme.headerA or 0.94)
    elseif active then
        local aR, aG, aB = GetTabAccent()
        btn.bg:SetColorTexture(aR * 0.22, aG * 0.22, aB * 0.22, 0.95)
    else
        btn.bg:SetColorTexture(theme.footerR, theme.footerG, theme.footerB, theme.footerA or 0.92)
    end
    if GDS_WoWLook and GDS_WoWLook.Tab then GDS_WoWLook.Tab(btn, active) end
end

local function SetupHistoryTabButton(btn)
    if not btn then return end
    btn:SetScript("OnEnter", function()
        btn._gtHovered = true
        UpdateHistoryTabButton(btn)
    end)
    btn:SetScript("OnLeave", function()
        btn._gtHovered, btn._gtPressed = nil, nil
        UpdateHistoryTabButton(btn)
    end)
    btn:SetScript("OnMouseDown", function()
        btn._gtPressed = true
        UpdateHistoryTabButton(btn)
    end)
    btn:SetScript("OnMouseUp", function()
        btn._gtPressed = nil
        UpdateHistoryTabButton(btn)
    end)
end

function RefreshHistory()
    if not historyFrame or not DB then return end
    local login = historyActiveTab == "logins"
    historyFrame.standardContent:SetShown(not login)
    historyFrame:SetHeight(login and 500 or 400)
    if login then
        for _, btn in pairs(historyTabBtns) do UpdateHistoryTabButton(btn) end
        GDS_LoginLog.ShowHistory(historyFrame)
        return
    end
    if historyFrame.loginPanel then historyFrame.loginPanel:Hide() end
    for _, f in ipairs(historyRowFrames) do f:Hide(); f:SetParent(nil) end
    historyRowFrames = {}

    local isSessions = (historyActiveTab == "sessions")
    local isDungeons = (historyActiveTab == "dungeons")
    -- Three summary cells for Session History; the fourth slot remains
    -- available for Dungeons' Avg / run statistic.
    if historyFrame.footerSessions then
        local function PlaceFooter(fs, x, width)
            if not fs then return end
            fs:ClearAllPoints()
            fs:SetPoint("BOTTOMLEFT", x, 42)
            fs:SetWidth(width)
        end
        if isSessions then
            PlaceFooter(historyFrame.footerSessions, 8, 121)
            PlaceFooter(historyFrame.footerTime, 129, 121)
            PlaceFooter(historyFrame.footerGold, 250, 122)
        else
            PlaceFooter(historyFrame.footerSessions, 8, 91)
            PlaceFooter(historyFrame.footerTime, 99, 91)
            PlaceFooter(historyFrame.footerKills, 190, 91)
            PlaceFooter(historyFrame.footerGold, 281, 91)
        end
    end
    if not isSessions then comparisonPicking, comparisonA = nil, nil end
    if historyFrame.csvBtn then
        historyFrame.csvBtn:SetShown(isDungeons and not historyFrame.confirmBar:IsShown())
    end
    if historyFrame.restoreDungeonBtn then
        historyFrame.restoreDungeonBtn:SetShown(isDungeons
            and type(DB.dungeonUndo)=="table" and type(DB.dungeonUndo.run)=="table"
            and not historyFrame.confirmBar:IsShown())
    end
    local selectedCount = 0
    if isSessions and historyFrame.combineSelected then
        local existing = {}
        for _, se in ipairs(DB.sessions or {}) do existing[se] = true end
        for session in pairs(historyFrame.combineSelected) do
            if not existing[session] then
                historyFrame.combineSelected[session] = nil
            else
                selectedCount = selectedCount + 1
            end
        end
    end
    if isDungeons then
        for _, run in ipairs(DB.dungeonRuns or {}) do
            if (historyFrame.combineSelected or {})[run] then selectedCount=selectedCount+1 end
        end
    end
    if historyFrame.combineBtn then
        local enabled = (isSessions and selectedCount == 2 and not comparisonPicking) or (isDungeons and selectedCount>=2)
        historyFrame.combineBtn:SetShown((isSessions or isDungeons) and not historyFrame.confirmBar:IsShown())
        historyFrame.combineBtn:SetEnabled(enabled)
        historyFrame.combineBtn:SetAlpha(enabled and 1 or 0.45)
        historyFrame.combineBtn.label:SetText(selectedCount > 0 and ("Combine (" .. selectedCount .. ")") or "Combine")
    end
    if historyFrame.compareBtn then
        local enough = #(DB.sessions or {}) >= 2
        historyFrame.compareBtn:SetShown(isSessions and not historyFrame.confirmBar:IsShown())
        historyFrame.compareBtn:SetEnabled(enough)
        historyFrame.compareBtn:SetAlpha(enough and 1 or 0.45)
        historyFrame.compareBtn.label:SetText(comparisonPicking and "Cancel Comparison" or "Compare Runs")
        historyFrame.compareHint:SetShown(isSessions and comparisonPicking == true)
        historyFrame.compareHint:SetText(comparisonA and "Select a different run for B" or "Select the first run for A")
        for _, key in ipairs({"footerSessions", "footerTime", "footerKills", "footerGold"}) do
            if historyFrame[key] then historyFrame[key]:SetShown(not comparisonPicking) end
        end
        -- "Kills" here is a reused footer cell for Dungeons' Avg / run.
        historyFrame.footerKills:SetShown(isDungeons and not comparisonPicking)
    end
    for _, btn in pairs(historyTabBtns) do
        UpdateHistoryTabButton(btn)
    end
    if historyFrame.sessionHeaders then
        for _, btn in pairs(historyFrame.sessionHeaders) do
            btn:SetShown(isSessions)
            if btn._updateLabel then btn._updateLabel() end
        end
    end
    if historyFrame.dungeonHeaders then
        for _, fs in ipairs(historyFrame.dungeonHeaders) do fs:SetShown(isDungeons) end
    end
    if historyFrame.clearBtn and historyFrame.clearBtn.label then
        historyFrame.clearBtn.label:SetText(isSessions and "Clear History" or "Clear Dungeons")
    end
    if historyFrame.confirmLabel then
        if isSessions and historyFrame.pendingCombine then
            historyFrame.confirmLabel:SetText("|cFFFFD27DCombine 2 sessions into 1?|r")
        elseif isSessions and historyFrame.pendingSessionDelete then
            local selected = historyFrame.pendingSessionDelete
            historyFrame.confirmLabel:SetText("|cFFFF4444Delete session "
                .. GDS_HistoryDate.Format(selected.date) .. "?|r")
        elseif isDungeons and historyFrame.pendingCombine then
            historyFrame.confirmLabel:SetText("|cFFFFD27DCombine "..#historyFrame.pendingCombine.." runs into 1?|r")
        elseif isDungeons and historyFrame.pendingDungeonDelete then
            local selected = historyFrame.pendingDungeonDelete
            historyFrame.confirmLabel:SetText("|cFFFF4444Delete run "
                .. GDS_HistoryDate.Format(selected.date) .. "?|r")
        else
            historyFrame.confirmLabel:SetText(isSessions
                and "|cFFFF4444Clear all saved sessions?|r"
                or "|cFFFF4444Clear all dungeon runs?|r")
        end
    end

    local yOff = 0
    if isSessions then
        local sessions = DB.sessions or {}
        local totalDur, totalCoin, totalItems = 0, 0, 0
        for _, se in ipairs(sessions) do
            totalDur   = totalDur   + (se.duration or 0)
            totalCoin  = totalCoin  + (se.coin     or 0)
            totalItems = totalItems + (se.items    or 0)
        end

        if historyFrame.noDataMsg then
            historyFrame.noDataMsg:SetText("No sessions recorded yet.\nClick 'End Session' to save a session.")
            if #sessions == 0 then historyFrame.noDataMsg:Show()
            else                   historyFrame.noDataMsg:Hide() end
        end
        if historyFrame.footerSessions then
            if #sessions > 0 then
                local lc = "|cFFAA8833"
                historyFrame.footerSessions:SetText(lc .. "Sessions|r\n" .. #sessions)
                historyFrame.footerTime:SetText(lc .. "Time|r\n" .. FormatTime(totalDur))
                historyFrame.footerKills:SetText("")
                historyFrame.footerGold:SetText(lc .. "Gold|r\n" .. Coin(totalCoin + totalItems))
            else
                historyFrame.footerSessions:SetText("")
                historyFrame.footerTime:SetText("")
                historyFrame.footerKills:SetText("")
                historyFrame.footerGold:SetText("")
            end
        end

        local sorted = {}
        for _, se in ipairs(sessions) do sorted[#sorted+1] = se end
        table.sort(sorted, function(a, b)
            local desc = historySortDir == "desc"
            local va, vb
            if historySortCol == "duration" then
                va, vb = a.duration or 0, b.duration or 0
            elseif historySortCol == "gold" then
                va = (a.coin or 0) + (a.items or 0)
                vb = (b.coin or 0) + (b.items or 0)
            else -- date
                va, vb = a.date or "", b.date or ""
            end
            if va == vb then return false end
            if desc then return va > vb else return va < vb end
        end)

        for i, se in ipairs(sorted) do
            local row = CreateFrame("Frame", nil, historyScroll.content)
            row:SetPoint("TOPLEFT", 0, yOff)
            row:SetPoint("TOPRIGHT", 0, yOff)
            row:SetHeight(20)
            row:EnableMouse(true)
            table.insert(historyRowFrames, row)

            local stripe = row:CreateTexture(nil, "BACKGROUND")
            stripe:SetAllPoints()
            local function RestoreStripe()
                if historyFrame.combineSelected and historyFrame.combineSelected[se] then
                    stripe:SetColorTexture(0.08, 0.42, 0.45, 0.72)
                elseif comparisonPicking and comparisonA == se then
                    stripe:SetColorTexture(0.3, 0.22, 0.05, 0.65)
                else
                    stripe:SetColorTexture(0, 0, 0, i%2==0 and 0.25 or 0)
                end
            end
            RestoreStripe()

            local dateTx = row:CreateFontString(nil,"OVERLAY","GameFontNormalSmall")
            dateTx:SetPoint("LEFT", 0, 0); dateTx:SetWidth(166); dateTx:SetJustifyH("LEFT")
            TrackThemeText(dateTx)
            dateTx:SetText((se.sessionName and se.sessionName ~= "")
                and se.sessionName or GDS_HistoryDate.Format(se.date))

            local durTx = row:CreateFontString(nil,"OVERLAY","GameFontNormalSmall")
            durTx:SetPoint("LEFT", 170, 0); durTx:SetWidth(64); durTx:SetJustifyH("LEFT")
            TrackThemeText(durTx)
            durTx:SetText(FormatTime(se.duration or 0))

            local goldTx = row:CreateFontString(nil,"OVERLAY","GameFontNormalSmall")
            goldTx:SetPoint("RIGHT", 0, 0); goldTx:SetWidth(105); goldTx:SetJustifyH("RIGHT")
            TrackThemeText(goldTx)
            goldTx:SetText(CoinShort((se.coin or 0) + (se.items or 0)))

            do
                local sesRef = se
                row:SetScript("OnEnter", function()
                    stripe:SetColorTexture(0.3, 0.22, 0.05, 0.5)
                    GameTooltip:SetOwner(row, "ANCHOR_TOPRIGHT")
                    GameTooltip:SetText((sesRef.sessionName and sesRef.sessionName ~= "")
                        and sesRef.sessionName or (sesRef.zone or "Area not recorded"))
                    if sesRef.sessionName and sesRef.sessionName ~= "" then
                        GameTooltip:AddLine(sesRef.zone or "Area not recorded", .8, .8, .8)
                    end
                    GameTooltip:AddLine(GDS_HistoryDate.Format(sesRef.date), 1, 1, 1)
                    if sesRef.sessionNote and sesRef.sessionNote ~= "" then
                        local preview = sesRef.sessionNote
                        if #preview > 240 then preview = preview:sub(1,240) .. "..." end
                        GameTooltip:AddLine("Note: " .. preview, .75, .85, 1, true)
                    end
                    if (sesRef.repairCosts or 0) > 0 then
                        GameTooltip:AddLine("Repair expenses: " .. CoinShort(sesRef.repairCosts), 1, .73, .52)
                    end
                    if (sesRef.pvpHK or 0) > 0 or (sesRef.pvpKB or 0) > 0 then
                        GameTooltip:AddLine("Honorable Kills: " .. (sesRef.pvpHK or 0)
                            .. "    Hon. Killing Blows: " .. (sesRef.pvpKB or 0), .9, .75, .42)
                    end
                    if (sesRef.combinedCount or 0) > 1 then
                        GameTooltip:AddLine("Combined from " .. tostring(sesRef.combinedCount) .. " sessions", .45, .93, .90)
                        GameTooltip:AddLine(GDS_HistoryDate.Format(sesRef.combinedStart) .. " to "
                            .. GDS_HistoryDate.Format(sesRef.combinedEnd), .7, .8, .8)
                    end
                    GameTooltip:AddLine(comparisonPicking and "Click to choose this run" or
                        (sesRef.c and "Click to view charts" or "Use Compare Runs to compare this session"), 0.94, 0.90, 0.80)
                    GameTooltip:AddLine("Right-Click: edit name / note", .82, .72, .45)
                    GameTooltip:AddLine("Shift + Right-Click: select/deselect for Combine", .45, .93, .90)
                    GameTooltip:AddLine("Shift + Left-Click to delete this session", 1, 0.42, 0.42)
                    GameTooltip:Show()
                end)
                row:SetScript("OnLeave", function()
                    RestoreStripe()
                    GameTooltip:Hide()
                end)
                row:SetScript("OnMouseUp", function(_, btn)
                    if btn == "RightButton" and IsShiftKeyDown() then
                        if historyFrame.confirmBar:IsShown() then return end
                        historyFrame.combineSelected = historyFrame.combineSelected or {}
                        local selected = historyFrame.combineSelected
                        if selected[sesRef] then
                            selected[sesRef] = nil
                        else
                            local count = 0
                            for _ in pairs(selected) do count = count + 1 end
                            if count >= 2 then
                                UIErrorsFrame:AddMessage("Grind Don't Stop: Select only two sessions to combine.")
                                return
                            end
                            selected[sesRef] = true
                        end
                        if comparisonPicking then comparisonPicking, comparisonA = nil, nil end
                        GameTooltip:Hide()
                        RefreshHistory()
                        return
                    end
                    if btn == "RightButton" and not IsShiftKeyDown() then
                        GameTooltip:Hide()
                        GDS_SessionMeta.Open(sesRef)
                        return
                    end
                    if btn ~= "LeftButton" then return end
                    if IsShiftKeyDown() then
                        -- Reuse the History confirmation bar. No session is
                        -- removed until the player explicitly clicks Yes.
                        comparisonPicking, comparisonA = nil, nil
                        historyFrame.pendingSessionDelete = sesRef
                        historyFrame.confirmLabel:SetText("|cFFFF4444Delete session "
                            .. GDS_HistoryDate.Format(sesRef.date) .. "?|r")
                        historyFrame.clearBtn:Hide()
                        historyFrame.compareBtn:Hide()
                        if historyFrame.combineBtn then historyFrame.combineBtn:Hide() end
                        historyFrame.compareHint:Hide()
                        historyFrame.confirmBar:Show()
                        if historyFrame.csvBtn then historyFrame.csvBtn:Hide() end
                        if historyFrame.restoreDungeonBtn then historyFrame.restoreDungeonBtn:Hide() end
                        GameTooltip:Hide()
                        return
                    end
                    if comparisonPicking then
                        if comparisonA == sesRef then return end
                        if not comparisonA then
                            comparisonA = sesRef
                            RefreshHistory()
                        else
                            local first = comparisonA
                            comparisonPicking, comparisonA = nil, nil
                            GameTooltip:Hide()
                            RefreshHistory()
                            ShowSessionComparison(first, sesRef)
                        end
                    elseif sesRef.c or sesRef.questTrackingEnabled or sesRef.pvpTrackingEnabled
                        or (tonumber(sesRef.questXP) or 0) > 0 or (tonumber(sesRef.questGold) or 0) > 0
                        or (tonumber(sesRef.pvpHK) or 0) > 0 or (tonumber(sesRef.pvpKB) or 0) > 0 then
                        ShowPastAnalytics(sesRef)
                    end
                end)
            end

            yOff = yOff - 20
        end
    elseif isDungeons then
        local rows, allRuns, allGold = GDS_Dungeon.BuildHistoryGroups(DB.dungeonRuns)
        DB.dungeonHistoryExpanded = DB.dungeonHistoryExpanded or {}
        if historyFrame.noDataMsg then
            historyFrame.noDataMsg:SetText("No dungeons tracked yet.\nStart a session and enter a dungeon.\nRuns save when you leave, end or reset the session.")
            historyFrame.noDataMsg:SetShown(#rows == 0)
        end
        if historyFrame.footerSessions then
            local lc = "|cFFAA8833"
            historyFrame.footerSessions:SetText(lc .. "Dungeons|r\n" .. #rows)
            historyFrame.footerTime:SetText(lc .. "Runs|r\n" .. allRuns)
            historyFrame.footerKills:SetText(lc .. "Avg / run|r\n" .. CoinShort(allRuns > 0 and allGold / allRuns or 0))
            historyFrame.footerGold:SetText(lc .. "Total gold|r\n" .. CoinShort(allGold))
        end
        for i, dungeon in ipairs(rows) do
            local expanded = DB.dungeonHistoryExpanded[dungeon.key] == true
            local row = CreateFrame("Frame", nil, historyScroll.content)
            row:SetPoint("TOPLEFT", 0, yOff)
            row:SetPoint("TOPRIGHT", 0, yOff)
            row:SetHeight(23)
            row:EnableMouse(true)
            table.insert(historyRowFrames, row)
            local stripe = row:CreateTexture(nil, "BACKGROUND")
            stripe:SetAllPoints()
            stripe:SetColorTexture(0.11, 0.13, 0.15, i%2==0 and 0.5 or 0.3)
            local function Cell(x, width, align, value)
                local fs = row:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
                fs:SetPoint("LEFT", row, "LEFT", x, 0)
                fs:SetWidth(width)
                fs:SetJustifyH(align)
                fs:SetNonSpaceWrap(false)
                TrackThemeText(fs)
                fs:SetText(value)
            end
            Cell(0, 139, "LEFT", (expanded and "[-] " or "[+] ")
                .. GDS_Dungeon.ShortName(dungeon.name))
            Cell(141, 38, "RIGHT", tostring(dungeon.runs))
            Cell(184, 76, "RIGHT", CoinShort(dungeon.total))
            Cell(263, 94, "RIGHT", dungeon.runs > 0 and CoinShort(dungeon.total / dungeon.runs) or "--")
            row:SetScript("OnEnter", function(self)
                stripe:SetColorTexture(0.25, 0.20, 0.08, 0.55)
                GameTooltip:SetOwner(self, "ANCHOR_RIGHT")
                GameTooltip:SetText(dungeon.name)
                GameTooltip:AddLine("Tracked runs: " .. dungeon.runs, 1, 1, 1)
                GameTooltip:AddLine("Saved entries: " .. #dungeon.entries, 1, 1, 1)
                GameTooltip:AddLine("Total earned: " .. CoinShort(dungeon.total), 1, 1, 1)
                if dungeon.runs > 0 then
                    GameTooltip:AddLine("Average per run: " .. CoinShort(dungeon.total / dungeon.runs), 1, 1, 1)
                end
                if dungeon.bestValue ~= nil then
                    GameTooltip:AddLine("Personal best: " .. CoinShort(dungeon.bestValue)
                        .. " in " .. FormatTime(dungeon.bestDuration or 0), .58, .95, .66)
                end
                GameTooltip:AddLine("Tracked time: " .. FormatTime(dungeon.duration), 1, 1, 1)
                GameTooltip:AddLine("Click to " .. (expanded and "collapse" or "expand") .. " individual runs", .9, .8, .5)
                GameTooltip:Show()
            end)
            row:SetScript("OnLeave", function()
                stripe:SetColorTexture(0.11, 0.13, 0.15, i%2==0 and 0.5 or 0.3)
                GameTooltip:Hide()
            end)
            row:SetScript("OnMouseUp", function(_, button)
                if button ~= "LeftButton" then return end
                DB.dungeonHistoryExpanded[dungeon.key] = not expanded
                GameTooltip:Hide()
                RefreshHistory()
            end)
            yOff = yOff - 23

            if expanded then
                -- Child rows deliberately include prior count-excluded fragments.
                -- Those fragments still affect gold totals until removed here.
                local childHeader = CreateFrame("Frame", nil, historyScroll.content)
                childHeader:SetPoint("TOPLEFT", 0, yOff)
                childHeader:SetPoint("TOPRIGHT", 0, yOff)
                childHeader:SetHeight(18)
                table.insert(historyRowFrames, childHeader)
                local childBg = childHeader:CreateTexture(nil, "BACKGROUND")
                childBg:SetAllPoints()
                childBg:SetColorTexture(0, 0, 0, 0.18)
                local function HCell(x, w, value, align)
                    local fs = childHeader:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
                    fs:SetPoint("LEFT", x, 0); fs:SetWidth(w)
                    fs:SetJustifyH(align or "LEFT")
                    TrackThemeText(fs)
                    fs:SetText(value)
                end
                HCell(10, 165, "Run date", "LEFT")
                HCell(178, 61, "Time", "RIGHT")
                HCell(242, 65, "Value", "RIGHT")
                HCell(322, 29, "Del", "RIGHT")
                yOff = yOff - 18

                for j, entry in ipairs(dungeon.entries) do
                    local savedRun = entry.run
                    local child = CreateFrame("Frame", nil, historyScroll.content)
                    child:SetPoint("TOPLEFT", 0, yOff)
                    child:SetPoint("TOPRIGHT", 0, yOff)
                    child:SetHeight(22)
                    child:EnableMouse(true)
                    table.insert(historyRowFrames, child)
                    local childStripe = child:CreateTexture(nil, "BACKGROUND")
                    childStripe:SetAllPoints()
                    local function PaintSelection()
                        if (historyFrame.combineSelected or {})[savedRun] then
                            childStripe:SetColorTexture(.55,.48,.03,.85)
                        else childStripe:SetColorTexture(0,0,0,j%2==0 and .23 or .1) end
                    end
                    PaintSelection()
                    local function SubCell(x, w, value, align)
                        local fs = child:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
                        fs:SetPoint("LEFT", x, 0); fs:SetWidth(w)
                        fs:SetJustifyH(align or "LEFT")
                        fs:SetNonSpaceWrap(false)
                        TrackThemeText(fs)
                        fs:SetText(value)
                    end
                    SubCell(10, 165, GDS_HistoryDate.Format(savedRun.date), "LEFT")
                    SubCell(178, 61, FormatTime(savedRun.duration or 0), "RIGHT")
                    SubCell(242, 65, CoinShort(entry.gold), "RIGHT")

                    -- A small delete control on the same row is clearer than a
                    -- hidden modifier key. Confirmation is required in both cases.
                    local del = CreateFrame("Button", nil, child)
                    del:SetSize(22, 19)
                    del:SetPoint("RIGHT", child, "RIGHT", -4, 0)
                    local db = del:CreateTexture(nil, "BACKGROUND")
                    db:SetAllPoints()
                    db:SetColorTexture(0.28, 0.08, 0.08, 0.45)
                    local dt = del:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
                    dt:SetAllPoints()
                    dt:SetJustifyH("CENTER")
                    dt:SetText("X")
                    dt:SetTextColor(1, 0.43, 0.39)
                    del:SetScript("OnEnter", function()
                        db:SetColorTexture(0.50, 0.10, 0.08, 0.85)
                        GameTooltip:SetOwner(del, "ANCHOR_RIGHT")
                        GameTooltip:SetText("Delete this dungeon run")
                        GameTooltip:AddLine("Only this saved entry will be removed.", 1, 1, 1)
                        GameTooltip:Show()
                    end)
                    del:SetScript("OnLeave", function()
                        db:SetColorTexture(0.28, 0.08, 0.08, 0.45)
                        GameTooltip:Hide()
                    end)
                    local function AskDelete()
                        historyFrame.pendingDungeonDelete = savedRun
                        historyFrame.pendingSessionDelete = nil
                        historyFrame.confirmLabel:SetText("|cFFFF4444Delete run "
                            .. GDS_HistoryDate.Format(savedRun.date) .. "?|r")
                        historyFrame.clearBtn:Hide()
                        if historyFrame.compareBtn then historyFrame.compareBtn:Hide() end
                        if historyFrame.combineBtn then historyFrame.combineBtn:Hide() end
                        if historyFrame.compareHint then historyFrame.compareHint:Hide() end
                        historyFrame.confirmBar:Show()
                        if historyFrame.csvBtn then historyFrame.csvBtn:Hide() end
                        if historyFrame.restoreDungeonBtn then historyFrame.restoreDungeonBtn:Hide() end
                        GameTooltip:Hide()
                    end
                    del:SetScript("OnClick", AskDelete)
                    child:SetScript("OnEnter", function(self)
                        childStripe:SetColorTexture(0.23, 0.19, 0.07, 0.4)
                        GameTooltip:SetOwner(self, "ANCHOR_RIGHT")
                        GameTooltip:SetText(dungeon.name)
                        GameTooltip:AddLine(GDS_HistoryDate.Format(savedRun.date), 1, 1, 1)
                        GameTooltip:AddLine("Coin: " .. CoinShort(savedRun.coin or 0), 1, 1, 1)
                        GameTooltip:AddLine("Items: " .. CoinShort(savedRun.items or 0), 1, 1, 1)
                        GameTooltip:AddLine("Duration: " .. FormatTime(savedRun.duration or 0), 1, 1, 1)
                        if (savedRun.repairCosts or 0) > 0 then
                            GameTooltip:AddLine("Repair expenses: " .. CoinShort(savedRun.repairCosts), 1, .73, .52)
                        end
                        if savedRun.gdsExcludeRunCount then
                            GameTooltip:AddLine("Earlier correction: not counted as a run,", 1, .7, .25)
                            GameTooltip:AddLine("but its gold still contributes to totals.", 1, .7, .25)
                        end
                        GameTooltip:AddLine("Shift + Right-click to select for Combine.",1,1,.25)
                        if savedRun.gdsCombinedRuns then GameTooltip:AddLine("Combined run: Alt + Right-click to undo.",1,1,.25) end
                        GameTooltip:AddLine("Click to view items looted.", 1, 1, 1)
                        GameTooltip:AddLine("Click X or Shift + Left-Click to delete", 1, .5, .45)
                        GameTooltip:Show()
                    end)
                    child:SetScript("OnLeave", function()
                        PaintSelection()
                        GameTooltip:Hide()
                    end)
                    child:SetScript("OnMouseUp", function(_, button)
                        if historyFrame.confirmBar:IsShown() then return end
                        if button=="RightButton" and IsShiftKeyDown() then
                            historyFrame.combineSelected=historyFrame.combineSelected or {}
                            local picks=historyFrame.combineSelected
                            if picks[savedRun] then picks[savedRun]=nil else
                                for other in pairs(picks) do
                                    if other.dungeon~=savedRun.dungeon or other.instanceID~=savedRun.instanceID then
                                        UIErrorsFrame:AddMessage("Select runs of the same dungeon and wing."); return
                                    end
                                end
                                picks[savedRun]=true
                            end
                            GameTooltip:Hide(); RefreshHistory()
                        elseif button=="RightButton" and IsAltKeyDown() and savedRun.gdsCombinedRuns then
                            GDS_Dungeon.UndoCombine(savedRun)
                            historyFrame.combineSelected={}
                            GameTooltip:Hide(); RefreshHistory()
                        elseif button == "LeftButton" then
                            if IsShiftKeyDown() then AskDelete() else GDS_LoginLog.OpenItems(savedRun) end
                        end
                    end)
                    yOff = yOff - 22
                end
            end
        end
    else
        local bestiaryRows, totalKills = BuildBestiaryRows()

        if historyFrame.noDataMsg then
            historyFrame.noDataMsg:SetText("No mob kills recorded yet.\nSaved sessions will build your bestiary.")
            if #bestiaryRows == 0 then historyFrame.noDataMsg:Show()
            else                       historyFrame.noDataMsg:Hide() end
        end
        if historyFrame.footerSessions then
            if #bestiaryRows > 0 then
                local lc = "|cFFAA8833"
                historyFrame.footerSessions:SetText(lc .. "Mobs Tracked|r\n" .. #bestiaryRows)
                historyFrame.footerTime:SetText(lc .. "Total Kills|r\n" .. FmtNum(totalKills))
                historyFrame.footerKills:SetText("")
                historyFrame.footerGold:SetText("")
            else
                historyFrame.footerSessions:SetText("")
                historyFrame.footerTime:SetText("")
                historyFrame.footerKills:SetText("")
                historyFrame.footerGold:SetText("")
            end
        end

        for i, mob in ipairs(bestiaryRows) do
            local row = CreateFrame("Frame", nil, historyScroll.content)
            row:SetPoint("TOPLEFT", 0, yOff)
            row:SetPoint("TOPRIGHT", 0, yOff)
            row:SetHeight(20)
            table.insert(historyRowFrames, row)

            local stripe = row:CreateTexture(nil, "BACKGROUND")
            stripe:SetAllPoints()
            stripe:SetColorTexture(0, 0, 0, i%2==0 and 0.25 or 0)

            local nameTx = row:CreateFontString(nil,"OVERLAY","GameFontNormalSmall")
            nameTx:SetPoint("LEFT", 0, 0)
            nameTx:SetPoint("RIGHT", row, "RIGHT", -88, 0)
            nameTx:SetJustifyH("LEFT")
            nameTx:SetNonSpaceWrap(false)
            TrackThemeText(nameTx)
            nameTx:SetText(mob.name)

            local killTx = row:CreateFontString(nil,"OVERLAY","GameFontNormalSmall")
            killTx:SetPoint("RIGHT", 0, 0)
            killTx:SetWidth(84)
            killTx:SetJustifyH("RIGHT")
            TrackThemeText(killTx)
            killTx:SetText(FmtNum(mob.kills))

            yOff = yOff - 20
        end
    end

    historyScroll.content:SetHeight(math.max(1, math.abs(yOff)))
    historyScroll:Update()
end

-------------------------------------------------------------------------------
-- MAIN STAT ROW LAYOUT (v6.5.12; display-only, per-character saved order)
-- Normal mode does not capture mouse input for rows without native tooltips.
-- All rows, including the optional quest/PvP separators, may be repositioned.
-------------------------------------------------------------------------------
GDS_RowLayout = GDS_RowLayout or {}
GDS_RowLayout.editMode = false -- intentionally OFF after login or /reload
GDS_RowLayout.defaultOrder = {
    "time", "kills", "kph", "fish", "fishph", "xp", "xph", "lvlt",
    "coin", "items", "total", "gph", "durability", "repairs",
    "questDivider", "questxp", "questcoin", "pvpDivider", "pvpHK", "pvpKB",
}

function GDS_RowLayout.GetOrder()
    local default = GDS_RowLayout.defaultOrder
    if not DB then return default end
    local saved = type(DB.mainRowOrder) == "table" and DB.mainRowOrder or {}
    local allowed, used, normalized = {}, {}, {}
    for _, key in ipairs(default) do allowed[key] = true end
    for _, key in ipairs(saved) do
        if type(key) == "string" and allowed[key] and not used[key] then
            normalized[#normalized+1] = key
            used[key] = true
        end
    end
    -- Future versions adding a stat automatically append it instead of losing it.
    for _, key in ipairs(default) do
        if not used[key] then normalized[#normalized+1] = key end
    end
    local changed = type(DB.mainRowOrder) ~= "table" or #saved ~= #normalized
    if not changed then
        for i, key in ipairs(normalized) do
            if saved[i] ~= key then changed = true; break end
        end
    end
    if changed then DB.mainRowOrder = normalized end
    return changed and normalized or saved
end

function GDS_RowLayout.MoveRow(key, where, target)
    if not DB or not key or not target or key == target then return false end
    local order = GDS_RowLayout.GetOrder()
    local from
    for i, entry in ipairs(order) do
        if entry == key then from = i; break end
    end
    if not from then return false end
    local nextOrder = {}
    for _, entry in ipairs(order) do
        if entry ~= key then nextOrder[#nextOrder+1] = entry end
    end
    local index
    for i, entry in ipairs(nextOrder) do
        if entry == target then
            index = where == "after" and i + 1 or i
            break
        end
    end
    if not index then return false end
    table.insert(nextOrder, index, key)
    local unchanged = #nextOrder == #order
    if unchanged then
        for i, entry in ipairs(order) do
            if entry ~= nextOrder[i] then unchanged = false; break end
        end
    end
    if unchanged then return false end
    DB.mainRowOrder = nextOrder
    local profile = DB.profiles and DB.currentProfile and DB.profiles[DB.currentProfile]
    if profile then
        profile.mainRowOrder = {}
        for i, entry in ipairs(nextOrder) do profile.mainRowOrder[i] = entry end
    end
    return true
end

function GDS_RowLayout.CancelDrag()
    GDS_RowLayout.dragKey = nil
    GDS_RowLayout.dropMode = nil
    GDS_RowLayout.dropTarget = nil
    if GDS_RowLayout.ghost then GDS_RowLayout.ghost:Hide() end
    if GDS_RowLayout.marker then GDS_RowLayout.marker:Hide() end
end

function GDS_RowLayout.SetEditMode(enabled)
    GDS_RowLayout.editMode = enabled == true
    if not GDS_RowLayout.editMode then GDS_RowLayout.CancelDrag() end
    if not statRows then return end
    for _, row in pairs(statRows) do
        if row.frame then
            row.frame:EnableMouse(GDS_RowLayout.editMode or row.hasNativeTooltip == true)
            if row.handle then row.handle:SetShown(GDS_RowLayout.editMode) end
            if row.lbl then
                row.lbl:ClearAllPoints()
                row.lbl:SetPoint("LEFT", GDS_RowLayout.editMode and 28 or 10, 0)
            end
        end
    end
end

function GDS_RowLayout.EnsureDragUI()
    if GDS_RowLayout.ghost then return end
    local ghost = CreateFrame("Frame", nil, UIParent)
    ghost:SetFrameStrata("TOOLTIP")
    ghost:SetSize(270, 22)
    ghost:EnableMouse(false)
    local bg = ghost:CreateTexture(nil, "BACKGROUND")
    bg:SetAllPoints()
    bg:SetColorTexture(0.10, 0.10, 0.12, 0.95)
    local upper = ghost:CreateTexture(nil, "ARTWORK")
    upper:SetPoint("TOPLEFT")
    upper:SetPoint("TOPRIGHT")
    upper:SetHeight(1)
    upper:SetColorTexture(0.96, 0.75, 0.30, 1)
    local lower = ghost:CreateTexture(nil, "ARTWORK")
    lower:SetPoint("BOTTOMLEFT")
    lower:SetPoint("BOTTOMRIGHT")
    lower:SetHeight(1)
    lower:SetColorTexture(0.96, 0.75, 0.30, 1)
    local label = ghost:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
    label:SetPoint("LEFT", 12, 0)
    label:SetPoint("RIGHT", -12, 0)
    label:SetJustifyH("LEFT")
    ghost.label = label
    ghost:SetScript("OnUpdate", function() GDS_RowLayout.UpdateDrag() end)
    ghost:Hide()
    GDS_RowLayout.ghost = ghost
    -- Use a higher-level child frame so the insertion line renders ABOVE
    -- stat row backgrounds instead of disappearing behind their frames.
    local marker = CreateFrame("Frame", nil, mainContentClip)
    marker:SetFrameLevel(mainContentClip:GetFrameLevel() + 20)
    marker:SetHeight(2)
    local markerLine = marker:CreateTexture(nil, "OVERLAY")
    markerLine:SetAllPoints()
    markerLine:SetColorTexture(1.0, 0.75, 0.25, 1)
    marker:Hide()
    GDS_RowLayout.marker = marker
end

function GDS_RowLayout.CursorDrop()
    if not GetCursorPosition or not mainContentClip or not statRows then return nil end
    local x, y = GetCursorPosition()
    local scale = UIParent:GetEffectiveScale()
    if not x or not y or not scale or scale <= 0 then return nil end
    x, y = x / scale, y / scale
    local left, right = mainContentClip:GetLeft(), mainContentClip:GetRight()
    local top, bottom = mainContentClip:GetTop(), mainContentClip:GetBottom()
    if not left or not right or not top or not bottom
        or x < left or x > right or y > top or y < bottom then return nil end
    local last
    for _, key in ipairs(GDS_RowLayout.GetOrder()) do
        local row = statRows[key]
        if row and row.frame and row.frame:IsShown() then
            last = key
            local rowTop = row.frame:GetTop()
            local rowBottom = row.frame:GetBottom()
            if rowTop and rowBottom and y >= (rowTop + rowBottom) / 2 then
                return "before", key
            end
        end
    end
    if last then return "after", last end
    return nil
end

function GDS_RowLayout.UpdateDrag()
    local key = GDS_RowLayout.dragKey
    local ghost, marker = GDS_RowLayout.ghost, GDS_RowLayout.marker
    if not key or not ghost or not marker then return end
    if not GDS_RowLayout.editMode or not mainFrame or not mainFrame:IsShown()
        or mainChartKey ~= "stats" then
        GDS_RowLayout.CancelDrag()
        return
    end
    local x, y = GetCursorPosition()
    local scale = UIParent:GetEffectiveScale()
    if x and y and scale and scale > 0 then
        ghost:ClearAllPoints()
        ghost:SetPoint("CENTER", UIParent, "BOTTOMLEFT", x / scale + 10, y / scale + 14)
    end
    local mode, target = GDS_RowLayout.CursorDrop()
    GDS_RowLayout.dropMode, GDS_RowLayout.dropTarget = mode, target
    local row = target and statRows[target]
    marker:Hide()
    if row and row.frame then
        marker:ClearAllPoints()
        if mode == "before" then
            marker:SetPoint("BOTTOMLEFT", row.frame, "TOPLEFT", 0, 2)
            marker:SetPoint("BOTTOMRIGHT", row.frame, "TOPRIGHT", 0, 2)
        else
            marker:SetPoint("TOPLEFT", row.frame, "BOTTOMLEFT", 0, -2)
            marker:SetPoint("TOPRIGHT", row.frame, "BOTTOMRIGHT", 0, -2)
        end
        marker:Show()
    end
end

function GDS_RowLayout.BeginDrag(key)
    if not GDS_RowLayout.editMode or not mainContentClip or mainChartKey ~= "stats" then return end
    local row = statRows and statRows[key]
    if not row or not row.frame or not row.frame:IsShown() then return end
    GDS_RowLayout.CancelDrag()
    GDS_RowLayout.EnsureDragUI()
    GDS_RowLayout.dragKey = key
    local name = row.lbl and row.lbl:GetText() or ""
    GDS_RowLayout.ghost.label:SetText(name ~= "" and name or "Section Divider")
    GDS_RowLayout.ghost:SetWidth(math.max(180, (mainContentClip:GetWidth() or 300) - 20))
    GDS_RowLayout.ghost:Show()
    GameTooltip:Hide()
    GDS_RowLayout.UpdateDrag()
end

function GDS_RowLayout.EndDrag(key)
    if GDS_RowLayout.dragKey ~= key then return end
    -- Read the actual release position rather than an earlier OnUpdate sample.
    local mode, target = GDS_RowLayout.CursorDrop()
    GDS_RowLayout.CancelDrag()
    if mode and target and GDS_RowLayout.MoveRow(key, mode, target) then
        if RefreshStats then RefreshStats() end
    end
end

-------------------------------------------------------------------------------
-- STATS DISPLAY
-------------------------------------------------------------------------------
function RefreshStats()
    local edge = GDS_TabSwitcher and GDS_TabSwitcher.edgeButton
    if edge and edge:IsShown() then edge.UpdateExpansion(edge.expanded) end
    if not statRows or not S or not DB then return end
    local t = S.timer
    local grandTotal = S.coinGold + S.itemGold

    if S.running and not S.paused and t > 0 and S.lastRateSample ~= t then
        S.lastRateSample = t
        S.emaXPH = UpdateEMA(S.xpGained, t, S.emaXPH)
        S.emaGPH = UpdateEMA(grandTotal,  t, S.emaGPH)
        -- Live GPH graph: one sample per tick; halve the history if it grows very long
        local samples = S.gphSamples
        if not samples then samples = {}; S.gphSamples = samples end
        samples[#samples+1] = {t = t, v = S.emaGPH}
        if #samples > 2400 then
            local kept = {}
            for i = 1, #samples, 2 do kept[#kept+1] = samples[i] end
            S.gphSamples = kept
        end
        S.emaKPH = UpdateEMA(S.kills,     t, S.emaKPH)
        -- Pace history: snapshot cumulative grandTotal each tick, prune > 65s old
        S.totalHistory = S.totalHistory or {}
        S.totalHistory[t] = grandTotal
        local cutoff = t - 65
        for k in pairs(S.totalHistory) do
            if k < cutoff then S.totalHistory[k] = nil end
        end
    end

    local vs = DB.show
    local function Set(key, val)
        local row = statRows[key]
        if not row then return end
        if vs[key] then
            row.lbl:Show(); row.val:Show()
            row.val:SetText(val)
        else
            row.lbl:Hide(); row.val:Hide()
        end
    end

    Set("time",  FormatTime(t))
    Set("kills", FmtNum(S.kills))
    Set("kph",   FmtNum(math.floor(S.emaKPH)))
    Set("xp",    FmtNum(S.xpGained))
    Set("xph",   FmtNum(math.floor(S.emaXPH)))
    do
        local xpMax = UnitXPMax("player") or 0
        local xpCur = UnitXP("player") or 0
        local xpLeft = xpMax - xpCur
        if xpMax <= 0 then
            Set("lvlt", "Max")
        elseif xpLeft <= 0 then
            Set("lvlt", "00:00:00")
        elseif (tonumber(S.emaXPH) or 0) >= 1 then
            local etaSeconds = (xpLeft / S.emaXPH) * 3600
            -- A new level can briefly leave XP/h near zero; don't show absurd
            -- ETAs or overflow the client's integer time formatter.
            if etaSeconds == etaSeconds and etaSeconds >= 0 and etaSeconds <= 30*86400 then
                Set("lvlt", FormatTime(math.ceil(etaSeconds)))
            else
                Set("lvlt", "---")
            end
        else
            Set("lvlt", "---")
        end
    end
    Set("coin",  Coin(S.coinGold))
    Set("items", Coin(S.itemGold))
    Set("gph",   Coin(math.floor(S.emaGPH)))
    Set("total", Coin(grandTotal))
    if statRows.durability then
        local visible = DB.showDurability == true
        local row = statRows.durability
        row.frame:SetShown(visible)
        row.lbl:SetShown(visible)
        row.val:SetShown(visible)
        if visible then
            local average, minimum, broken = GDS_Repairs and GDS_Repairs.ReadDurability()
            row.val:SetText(average and (average .. "%") or "---")
        end
    end
    -- Actual vendor repair expense for this session. This is not an estimate,
    -- and does not reduce the gross Gold, Total Value or GPH rows.
    if statRows.repairs then
        local visible = DB.repairTracking == true
        local row = statRows.repairs
        row.frame:SetShown(visible)
        row.lbl:SetShown(visible)
        row.val:SetShown(visible)
        if visible then
            row.val:SetText(Coin(math.max(0, tonumber(S.repairCosts) or 0)))
        end
    end

    -- Pace coloring on GPH: compare last 30s of earnings vs the 30s before that
    if statRows.gph and statRows.gph.val and vs.gph then
        local r, g, b = nil, nil, nil
        if S.running and not S.paused and S.totalHistory and t >= 60 then
            local now30 = S.totalHistory[t - 30]
            local prev60 = S.totalHistory[t - 60]
            if now30 and prev60 then
                local cur  = grandTotal - now30   -- last 30s earnings
                local prev = now30      - prev60  -- the 30s before that
                if prev <= 0 and cur > 0 then
                    r, g, b = 0.20, 1.00, 0.20    -- green: gained after a dry spell
                elseif cur > prev then
                    r, g, b = 0.20, 1.00, 0.20    -- green: pace rising
                elseif cur < prev then
                    r, g, b = 1.00, 0.30, 0.30    -- red: pace falling
                end
            end
        end
        if r then
            statRows.gph.val:SetTextColor(r, g, b, 0.98)
        else
            SetThemeTextColor(statRows.gph.val, 0.98)
        end
    end

    if gphGraphFrame and gphGraphFrame:IsShown() then DrawGphGraph() end

    -- Two independently visible mini views, both updated from the SAME
    -- personal session; no extra tracking events, timers, or XP accounting.
    -- Gold excludes quest/trade/mail using the existing session totals.
    if miniBar and miniBar:IsShown() then
        miniBar.text:SetText("Gold: " .. Coin(grandTotal)
            .. "   GPH: " .. Coin(math.floor(S.emaGPH)))
        local textWidth = miniBar.text:GetStringWidth() or 0
        miniBar:SetWidth(math.min(440, math.max(225, math.ceil(textWidth + 45))))
    end
    if GDS_XPMiniBar and GDS_XPMiniBar:IsShown() then
        GDS_XPMiniBar.text:SetText("XP: " .. FmtNum(S.xpGained)
            .. "   XP/h: " .. FmtNum(math.floor(S.emaXPH)))
        local textWidth = GDS_XPMiniBar.text:GetStringWidth() or 0
        GDS_XPMiniBar:SetWidth(math.min(440, math.max(225, math.ceil(textWidth + 45))))
    end
    -- A snapped pair shares the width of its widest bar; otherwise each keeps
    -- its natural size. Pure presentation: no changes to XP/coin accounting.
    if GDS_MiniViews and GDS_MiniViews.SyncWidths then
        GDS_MiniViews.SyncWidths()
    end

    -- Quest income is independent of ordinary farming totals and GPH.
    local questVisible = DB.questTracking == true
    local questXP, questGold = QuestTotals()
    for _, key in ipairs({"questDivider", "questxp", "questcoin"}) do
        local row = statRows[key]
        if row and row.frame then
            row.frame:SetShown(questVisible)
            if key ~= "questDivider" then
                row.lbl:SetShown(questVisible)
                row.val:SetShown(questVisible)
            end
        end
    end
    if questVisible then
        statRows.questxp.val:SetText(FmtNum(questXP))
        statRows.questcoin.val:SetText(Coin(questGold))
    end

    -- Separate player-versus-player counters. Unlike PvE kills, HK credit
    -- includes assists; honorable KBs require a matching personal PARTY_KILL.
    local pvpVisible = DB.pvpTracking == true
    for _, key in ipairs({"pvpDivider", "pvpHK", "pvpKB"}) do
        local row = statRows[key]
        if row and row.frame then
            row.frame:SetShown(pvpVisible)
            if key ~= "pvpDivider" then
                row.lbl:SetShown(pvpVisible)
                row.val:SetShown(pvpVisible)
            end
        end
    end
    if pvpVisible then
        statRows.pvpHK.val:SetText(FmtNum(S.pvpHK or 0))
        statRows.pvpKB.val:SetText(FmtNum(S.pvpKB or 0))
    end

    -- EasyFishing rows stay visible when enabled, including before Start, and
    -- count catches since the Grind Dont Stop session began (like XP gained).
    -- Each row is user-toggleable via DB.show.fish / DB.show.fishph.
    if statRows.fish and statRows.fishph and DB.show then
        local ef = _G.EasyFishing
        local efs = ef and ef.GetStats and ef.GetStats()
        local snap = S.fishStart
        local available = efs ~= nil
        local running = (efs and S.running and snap) and true or false
        local currentFish = available and (tonumber(efs.fish) or 0) or 0
        local startFish = snap and (tonumber(snap.fish) or 0) or currentFish
        local caught = running and math.max(0, currentFish - startFish) or 0
        local perHr = (running and S.timer and S.timer > 5)
            and (caught / (S.timer / 3600)) or 0

        -- Match the checkbox exactly: false or a missing value is off.
        local showFish   = available and (DB.show.fish   == true)
        local showFishph = available and (DB.show.fishph == true)

        local rF = statRows.fish
        if rF.frame then rF.frame:SetShown(showFish) end
        rF.lbl:SetShown(showFish); rF.val:SetShown(showFish)
        if showFish then rF.val:SetText(FmtNum(caught)) end

        local rP = statRows.fishph
        if rP.frame then rP.frame:SetShown(showFishph) end
        rP.lbl:SetShown(showFishph); rP.val:SetShown(showFishph)
        if showFishph then rP.val:SetText(FmtNum(math.floor(perHr + 0.5))) end

        -- Hidden optional rows must not retain blank slots. Re-anchor every
        -- visible row into one continuous list in the intended display order.
        local compactY = -6
        local visibleCount = 0
        for _, key in ipairs(GDS_RowLayout.GetOrder()) do
            local row = statRows[key]
            if row and row.frame and row.frame:IsShown() then
                visibleCount = visibleCount + 1
                row.frame:ClearAllPoints()
                -- Use the original parent-relative form. Explicitly supplying
                -- the clipping frame here can produce bad bounds on some WoW
                -- clients, pushing values and the first rows outside the clip.
                row.frame:SetPoint("TOPLEFT", 10, compactY)
                row.frame:SetPoint("TOPRIGHT", -10, compactY)
                compactY = compactY - ((key == "questDivider" or key == "pvpDivider") and 13 or 23)
            end
        end

        -- Resize only when the category count changes. This lets checkbox
        -- toggles shrink/grow the window while leaving manual resizing alone.
        if mainFrame and visibleCount ~= lastVisibleStatCount then
            lastVisibleStatCount = visibleCount
            local dividerAdjustment = (questVisible and 10 or 0) + (pvpVisible and 10 or 0)
            local targetH = math.max(332, (visibleCount * 23) + 119 - dividerAdjustment)
            if math.abs(mainFrame:GetHeight() - targetH) > 1 then
                mainFrame:SetHeight(targetH)
            end
            DB.mainH = targetH
            local prof = DB.profiles and DB.currentProfile and DB.profiles[DB.currentProfile]
            if prof then prof.mainH = targetH end
        end
    end
    -- Only presentation: these helpers read existing session data; no money,
    -- loot, XP or dungeon history is changed by their refreshes.
    if GDS_Health then GDS_Health.Refresh() end
    if GDS_LiveDungeon then GDS_LiveDungeon.Refresh() end
end

-------------------------------------------------------------------------------
-- LOOT LOG UI
-------------------------------------------------------------------------------
-- Removed records belong to the personal session and keep their original order.
GDS_AnalyticsUndo = GDS_AnalyticsUndo or {}
function GDS_AnalyticsUndo.List()
    if not S then return end
    if S.analyticsUndo and type(S.analyticsUndo.entry) == "table" then
        S.removedLoot = S.removedLoot or {}
        table.insert(S.removedLoot, S.analyticsUndo)
        S.analyticsUndo = nil
    end
    return S.removedLoot
end

function GDS_AnalyticsUndo.Remove(index)
    local removed = GDS_AnalyticsUndo.List() or {}
    S.removedLoot = removed
    -- Map the visible row back to its original slot, including earlier removals.
    local slots = {}
    for _, record in ipairs(removed) do slots[#slots + 1] = record.index end
    table.sort(slots)
    local original = index
    for _, slot in ipairs(slots) do
        if slot > original then break end
        original = original + 1
    end
    local entry = table.remove(S.loot, index)
    entry._gtRemoved = true
    table.insert(removed, {entry=entry, index=original})
end

function GDS_AnalyticsUndo.RefreshButton()
    local btn = lootFrame and lootFrame.restoreBtn
    if not btn then return end
    local removed = GDS_AnalyticsUndo.List()
    local count = removed and #removed or 0
    btn:SetShown(count > 0)
    if lootFrame.refreshRemoved then lootFrame.refreshRemoved(removed, count) end
end

function GDS_AnalyticsUndo.Restore(record)
    local removed = GDS_AnalyticsUndo.List()
    if not record or not removed then return end
    local pos = record.index
    local selected
    for i, other in ipairs(removed) do
        if other == record then selected = i
        elseif other.index < record.index then pos = pos - 1 end
    end
    if not selected then return end
    table.remove(removed, selected)
    local entry = record.entry
    entry._gtRemoved = nil
    table.insert(S.loot, math.max(1, math.min(#S.loot + 1, pos)), entry)
    RecalcItemGold()
    RefreshLootLog()
    DEFAULT_CHAT_FRAME:AddMessage("|cFFD8DDE6GT|r Restored: "
        .. (entry.name or "?") .. "  (" .. CoinShort(entry.total) .. ")")
end
do
local function suppressEquippedComparison(tip)
    local owner = GameTooltip:GetOwner()
    if owner and owner.gdsAnalyticsLootRow then tip:Hide() end
end
local hooked = {}
local function watchComparison(tip)
    if not tip or hooked[tip] then return end
    hooked[tip] = true
    tip:HookScript("OnShow", suppressEquippedComparison)
end
function RefreshLootLog()
    GDS_AnalyticsUndo.RefreshButton()
    -- Redraw inline main-frame chart if one is active
    if mainChartFrame and mainChartFrame:IsShown() and mainChartKey ~= "stats" and S then
        local k = mainChartKey
        if     k == "line" then DrawLineChart(mainChartFrame)
        elseif k == "bar"  then DrawBarChart(mainChartFrame)
        elseif k == "pie"  then DrawPieChart(mainChartFrame) end
    end

    if not lootFrame or not lootFrame:IsShown() or not S then return end
    if lootFrame.lootLegend then
        lootFrame.lootLegend:SetText(DB and DB.questTracking
            and "V=Vendor AH=Auction DE=Disenchant Q=Quest Q/DE=Quest DE"
            or "V=Vendor AH=Auction DE=Disenchant Left=cycle Right=remove")
    end
    if activeTab ~= "log" then
        local cf = chartFrames[activeTab]
        if cf and cf:IsShown() then
            if     activeTab == "line" then DrawLineChart(cf)
            elseif activeTab == "bar"  then DrawBarChart(cf)
            elseif activeTab == "pie"  then DrawPieChart(cf) end
        end
        return
    end

    local yOff = 0
    local n = #S.loot
    for slot = math.min(n, 300) + 1, #lootRowFrames do
        local row = lootRowFrames[slot]
        row.entry, row.index, row.pressedEntry = nil, nil, nil
        row:Hide()
    end

    for i = n, math.max(1, n-299), -1 do
        local it = S.loot[i]
        local slot = n - i + 1
        local row = lootRowFrames[slot]
        if not row then
            row = CreateFrame("Frame", nil, lootScroll.content)
            row.gdsAnalyticsLootRow = true
            lootRowFrames[slot] = row
            row:SetPoint("TOPLEFT", 0, yOff)
            row:EnableMouse(true)
            row.stripe = row:CreateTexture(nil, "BACKGROUND")
            row.stripe:SetAllPoints()
            row:SetScript("OnEnter", function(self)
                local it = self.entry
                if not it then return end
                self.stripe:SetColorTexture(0.3, 0.22, 0.05, 0.5)
                GameTooltip:SetOwner(self, "ANCHOR_TOPRIGHT")
                local link = it.link or (it.itemID and ("item:" .. it.itemID))
                if link then
                    for _, tip in pairs(GameTooltip.shoppingTooltips or {}) do
                        watchComparison(tip)
                        tip:Hide()
                    end
                    for _, name in ipairs({"ShoppingTooltip1", "ShoppingTooltip2", "ShoppingTooltip3"}) do
                        local tip = _G[name]
                        if tip then
                            watchComparison(tip)
                            tip:Hide()
                        end
                    end
                    GameTooltip:SetHyperlink(link)
                else
                    GameTooltip:SetText(it.name or "?")
                end
                GameTooltip:AddLine(" ")
                if it.receiptZone then GameTooltip:AddLine(it.receiptZone,.75,.85,.95,true) end
                if it.questReceipt then
                    GameTooltip:AddLine("Matched quest reward #" .. it.questReceipt,1,.82,.35,true)
                    GameTooltip:AddLine("Vendor estimate for Quest Coin",.85,.85,.85,true)
                    GameTooltip:AddLine("Right-click: remove",1,.35,.35)
                    GameTooltip:Show()
                    return
                end
                local mode = (DB.priceOverrides and it.itemID and DB.priceOverrides[tostring(it.itemID)])
                    or DB.defaultPriceMode or "vendor"
                if (mode == "quest" or mode == "questDE") and not DB.questTracking then mode = "vendor" end
                local modeName = mode == "questDE" and "Quest (disenchant estimate)"
                    or mode == "quest" and "Quest (vendor value)"
                    or mode == "auction" and "Auction House"
                    or mode == "disenchant" and "Disenchant estimate" or "Vendor"
                GameTooltip:AddLine("Pricing: " .. modeName, 0.4, 1, 0.65)
                if it.source == "manual" then GameTooltip:AddLine("Manually added from inventory", 0.35, 0.9, 0.9) end
                if mode == "disenchant" or mode == "questDE" then
                    if it.deFallback then GameTooltip:AddLine("Vendor fallback: " .. it.deFallback, 1,.78,.35,true) end
                    GameTooltip:AddLine("DE uses expected material value.", .7,.8,.9, true)
                    GameTooltip:AddLine("Unpriced / unsupported results fall back to vendor.", .9,.7,.5, true)
                elseif mode == "quest" then
                    GameTooltip:AddLine("Vendor value counts toward Quest Coin, not farming gold.", .9,.8,.5, true)
                    GameTooltip:AddLine("Quest value is estimated, not actual coin received.", .7,.8,.9, true)
                end
                GameTooltip:AddLine(DB.questTracking and "Left-click: V > AH > DE* > Quest Vendor > Quest DE*"
                    or "Left-click: Vendor > Auction > Disenchant* > Vendor", .8, .8, .8)
                GameTooltip:AddLine("*DE is skipped for non-disenchantable items.", .65,.7,.78)
                GameTooltip:AddLine("Middle-click: compare vendor and disenchant values", .8,.8,.8)
                GameTooltip:AddLine("Right-click: remove", 1, 0.35, 0.35)
                GameTooltip:Show()
            end)
            row:SetScript("OnLeave", function(self)
                self.stripe:SetColorTexture(0, 0, 0, self.index and self.index%2==0 and 0.25 or 0)
                GameTooltip:Hide()
            end)
            row:SetScript("OnMouseDown", function(self)
                self.pressedEntry = self.entry
            end)
            row:SetScript("OnMouseUp", function(self, btn)
                local pressed = self.pressedEntry
                self.pressedEntry = nil
                local it, idx = self.entry, self.index
                if it ~= pressed then return end
                if not it or not S or S.loot[idx] ~= it then return end
                if btn == "LeftButton" then
                    if it.questReceipt then return end
                    local id = tonumber(it.itemID) or (it.link and tonumber(it.link:match("item:(%d+)")))
                    if not id then return end
                    DB.priceOverrides = DB.priceOverrides or {}
                    local key = tostring(id)
                    local old = DB.priceOverrides[key] or DB.defaultPriceMode or "vendor"
                    if (old == "quest" or old == "questDE") and not DB.questTracking then old = "vendor" end
                    local mode
                    if old == "vendor" then mode = "auction"
                    elseif old == "auction" then
                        -- DE is meaningful for uncommon/rare/epic armor and weapons.
                        if GDS_QuestItems.CanDisenchant(id, it) then
                            mode = "disenchant"
                        else mode = DB.questTracking and "quest" or "vendor" end
                    elseif old == "disenchant" then
                        mode = DB.questTracking and "quest" or "vendor"
                    elseif old == "quest" and GDS_QuestItems.CanDisenchant(id, it) then
                        mode = "questDE"
                    else mode = "vendor" end
                    DB.priceOverrides[key] = mode
                    RepriceCurrentLoot()
                    DEFAULT_CHAT_FRAME:AddMessage("|cFFD8DDE6GT|r " .. (it.name or key)
                        .. " now uses " .. (mode == "questDE" and "Quest Coin (DE estimate, vendor fallback)" or
                            mode == "quest" and "Quest Coin (vendor value)" or
                            mode == "auction" and "Auction Companion (vendor fallback)" or
                            mode == "disenchant" and "Disenchantry estimate (vendor fallback)" or "vendor") .. ".")
                elseif btn == "MiddleButton" then
                    local link = it.link or (it.itemID and ("item:" .. it.itemID))
                    if not link then return end
                    local qty = tonumber(it.qty) or 1
                    local vendor = it.vendorPrice or select(11, GDS_ItemCompat.GetInfo(link))
                    GameTooltip:SetOwner(self, "ANCHOR_TOPRIGHT")
                    GameTooltip:SetText(it.name or "?")
                    GameTooltip:AddLine("Vendor: " .. (vendor and CoinShort(vendor * qty) or "Unknown"))
                    if GDS_QuestItems.CanDisenchant(link, it) then
                        local estimate, reason = GetPricePerItem(link, it.quality, vendor, "disenchant")
                        GameTooltip:AddLine("Disenchant: " .. (reason or (estimate > 0 and CoinShort(estimate * qty) or "Unknown")), .85,.8,1,true)
                    else
                        GameTooltip:AddLine("No disenchant estimate for this item.")
                    end
                    GameTooltip:Show()
                elseif btn == "RightButton" then
                    GDS_AnalyticsUndo.Remove(idx)
                    RecalcItemGold()
                    RefreshLootLog()
                    DEFAULT_CHAT_FRAME:AddMessage(
                        "|cFFD8DDE6GT|r Removed: "..(it.name or "?")
                        .."  ("..CoinShort(it.total)..")")
                end
            end)

            -- Timestamp
            local tsTx = row:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
            tsTx:SetPoint("LEFT", 4, 0); tsTx:SetWidth(36); tsTx:SetJustifyH("LEFT")
            TrackThemeText(tsTx)
            row.timeText = tsTx

            -- Qty
            local qtyTx = row:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
            qtyTx:SetPoint("LEFT", tsTx, "RIGHT", 2, 0); qtyTx:SetWidth(26)
            qtyTx:SetJustifyH("RIGHT"); TrackThemeText(qtyTx); row.qtyText = qtyTx

            -- Item name — anchored LEFT from qty, RIGHT stops 110px from edge
            -- giving the price column enough room for "99g99s99c"
            local nameTx = row:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
            nameTx:SetPoint("LEFT", qtyTx, "RIGHT", 4, 0)
            nameTx:SetPoint("RIGHT", row, "RIGHT", -112, 0)
            nameTx:SetJustifyH("LEFT")
            nameTx:SetNonSpaceWrap(false)
            row.nameText = nameTx
            -- Price — fixed 108px wide, right-aligned flush to edge
            local valTx = row:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
            valTx:SetPoint("RIGHT", row, "RIGHT", -4, 0); valTx:SetWidth(106)
            valTx:SetJustifyH("RIGHT"); TrackThemeText(valTx); row.valueText = valTx

        end
        row.entry, row.index = it, i
        row:SetSize(lootScroll.content:GetWidth(), 20)
        row.stripe:SetColorTexture(0, 0, 0, i%2==0 and 0.25 or 0)
        row.timeText:SetText(FmtShort(it.time))
        row.qtyText:SetText(it.qty.."x")
        row.valueText:SetText(CoinShort(it.total))
        local col = (it.quality and Q_COLOR[it.quality]) or "|cFFFFFFFF"
        -- Display the selected valuation separately from WoW item-quality color.
        -- Gray item names indicate item quality, not the pricing source.
        local pricingMode = (DB.priceOverrides and it.itemID and DB.priceOverrides[tostring(it.itemID)])
            or DB.defaultPriceMode or "vendor"
        if (pricingMode == "quest" or pricingMode == "questDE") and not DB.questTracking then pricingMode = "vendor" end
        if it.questReceipt then pricingMode = "quest" end
        local manualTag = it.source == "manual" and "|cFF55DDDD[M]|r " or ""
        local pricingTag = pricingMode == "questDE" and (it.deFallback and "|cFFFFD27F[Q/DE>V]|r " or "|cFFB99AFF[Q/DE]|r ")
            or pricingMode == "quest" and "|cFFFFD45A[Q]|r "
            or pricingMode == "auction" and "|cFF6BB9FF[AH]|r "
            or pricingMode == "disenchant" and (it.deFallback and "|cFFFFD27F[DE>V]|r " or "|cFFB99AFF[DE]|r ")
            or "|cFFFFD27F[V]|r "
        row.nameText:SetText(manualTag .. pricingTag .. col .. (it.name or "?") .. "|r")

        row:Show()
        yOff = yOff - 20
    end

    lootScroll.content:SetHeight(math.max(1, math.abs(yOff)))
    lootScroll:Update()
end
end

-------------------------------------------------------------------------------
-- UI HELPERS
-------------------------------------------------------------------------------
-- All theme-aware buttons use the current skin's background color.
function GDS_GetSkinButtonColor()
    if DB and DB.skinMode == "wow" then
        return 0.105, 0.068, 0.028, 0.96
    elseif DB and DB.skinMode == "nightfall" then
        return 0.084, 0.052, 0.126, 0.95
    elseif DB and DB.skinMode == "wowlook" then
        return 0.090, 0.061, 0.030, 0.98
    elseif DB and DB.skinMode == "classicstone" then
        return 0.16, 0.14, 0.10, 0.96
    elseif DB and DB.skinMode == "classicleather" then
        return 0.19, 0.12, 0.055, 0.97
    elseif DB and DB.skinMode == "tooltipframe" then
        return 0.09, 0.085, 0.14, 0.97
    elseif DB and DB.skinMode == "authenticvanilla" then
        return 0.17, 0.10, 0.035, 0.97
    end
    return 0.055, 0.067, 0.082, 0.92
end

-- WoW Experimental: black inset panels, raised Blizzard buttons,
-- bronze header rails and brass double-bordered panels. Everything added
-- here is a PARENT texture below child controls: no opaque overlay may sit
-- over text, tabs, or the tracker (the broken parchment failure mode).
-- All additions hide immediately on a return to Original / another skin.
-- Global namespace avoids WoW's 200-local-per-file limit.
GDS_WoWLook = GDS_WoWLook or {}
GDS_WoWLook.frames = setmetatable({}, {__mode="k"})
GDS_WoWLook.buttons = setmetatable({}, {__mode="k"})
GDS_WoWLook.headers = setmetatable({}, {__mode="k"})
GDS_WoWLook.footers = setmetatable({}, {__mode="k"})
GDS_WoWLook.statRows = setmetatable({}, {__mode="k"})
function GDS_WoWLook.Enabled()
    return DB ~= nil and DB.skinMode == "wowlook"
end
-- Make an ordinary colored strip: no borrowed art can cover content.
function GDS_WoWLook.Strip(parent, layer, left, right, top, height, color)
    local tex = parent:CreateTexture(nil, layer)
    tex:SetPoint("TOPLEFT", parent, "TOPLEFT", left, -top)
    tex:SetPoint("TOPRIGHT", parent, "TOPRIGHT", -right, -top)
    tex:SetHeight(height)
    tex:SetColorTexture(color[1], color[2], color[3], color[4])
    return tex
end
function GDS_WoWLook.SyncFrame(frame)
    if not frame then return end
    if not frame._gtWowV2 then
        local deco = {}
        -- The inset is deliberately attached to the same parent as the
        -- Backdrop, rather than a child frame at a higher frame level.
        -- Its BACKGROUND/BORDER textures are behind any descendant text.
        local isMain = frame == mainFrame
        local compact = frame:GetHeight() < 120
        local name = frame.GetName and frame:GetName()
        local top = compact and 6 or (isMain and 56)
            or (name == "GTHistoryFrame" and 63)
            or (name == "GTLootFrame" and 75) or 38
        local bottom = compact and 6 or (isMain and 61) or 14
        local left = compact and 6 or (isMain and 12) or 9
        local right = left
        deco.inset = frame:CreateTexture(nil, "BACKGROUND")
        deco.inset:SetPoint("TOPLEFT", frame, "TOPLEFT", left, -top)
        deco.inset:SetPoint("BOTTOMRIGHT", frame, "BOTTOMRIGHT", -right, bottom)
        deco.inset:SetColorTexture(.012, .011, .009, .82)
        -- Brass edge + black inner shadow, like classic WoW option-panel insets.
        local function Line(point1, point2, height, color, x, y)
            local line = frame:CreateTexture(nil, "BORDER")
            line:SetPoint(point1, deco.inset, point1, x or 0, y or 0)
            line:SetPoint(point2, deco.inset, point2, -(x or 0), y or 0)
            line:SetHeight(height)
            line:SetColorTexture(color[1], color[2], color[3], color[4])
            return line
        end
        deco.top = Line("TOPLEFT", "TOPRIGHT", 1, {.53, .40, .21, .90}, 0, 0)
        deco.bottom = Line("BOTTOMLEFT", "BOTTOMRIGHT", 2, {.36, .27, .15, .86}, 0, 0)
        deco.topShadow = Line("TOPLEFT", "TOPRIGHT", 2, {.012, .010, .008, .92}, 3, -2)
        deco.sideL = frame:CreateTexture(nil, "BORDER")
        deco.sideL:SetPoint("TOPLEFT", deco.inset, "TOPLEFT", 0, -1)
        deco.sideL:SetPoint("BOTTOMLEFT", deco.inset, "BOTTOMLEFT", 0, 1)
        deco.sideL:SetWidth(2)
        deco.sideL:SetColorTexture(.54, .39, .19, .82)
        deco.sideR = frame:CreateTexture(nil, "BORDER")
        deco.sideR:SetPoint("TOPRIGHT", deco.inset, "TOPRIGHT", 0, -1)
        deco.sideR:SetPoint("BOTTOMRIGHT", deco.inset, "BOTTOMRIGHT", 0, 1)
        deco.sideR:SetWidth(2)
        deco.sideR:SetColorTexture(.54, .39, .19, .82)
        -- WoW-style narrow outer rail, never extending into controls.
        deco.topRail = GDS_WoWLook.Strip(frame, "BORDER", 13, 13, 3, 2,
            {.74, .56, .28, .93})
        deco.topRailShadow = GDS_WoWLook.Strip(frame, "BORDER", 16, 16, 6, 1,
            {.13, .09, .045, .95})
        deco.bottomRail = frame:CreateTexture(nil,"BORDER")
        deco.bottomRail:SetPoint("BOTTOMLEFT", frame, "BOTTOMLEFT", 13, 3)
        deco.bottomRail:SetPoint("BOTTOMRIGHT", frame, "BOTTOMRIGHT", -13, 3)
        deco.bottomRail:SetHeight(2)
        deco.bottomRail:SetColorTexture(.69, .49, .24, .92)
        deco.studs = {}
        for i, corner in ipairs({"TOPLEFT","TOPRIGHT","BOTTOMLEFT","BOTTOMRIGHT"}) do
            local tex = frame:CreateTexture(nil,"BORDER")
            tex:SetSize(5,5)
            tex:SetPoint(corner, frame, corner,
                (i % 2 == 1) and 8 or -8, (i <= 2) and -8 or 8)
            tex:SetColorTexture(.97,.74,.28,.88)
            deco.studs[i]=tex
        end
        frame._gtWowV2=deco
    end
    for key, tex in pairs(frame._gtWowV2) do
        if key == "studs" then
            for _, part in ipairs(tex) do part:SetShown(GDS_WoWLook.Enabled()) end
        else
            tex:SetShown(GDS_WoWLook.Enabled())
        end
    end
    GDS_WoWLook.frames[frame] = true
end
function GDS_WoWLook.SyncHeader(tex)
    if not tex then return end
    local f=tex:GetParent()
    if not f then return end
    if not f._gtWoWHeader then
        local h={}
        -- Already-established header background remains; these are narrow
        -- textured bars BELOW the FontStrings, not another opaque header.
        h.top = GDS_WoWLook.Strip(f,"BORDER",6,6,1,2,{.62,.45,.22,.90})
        h.hi = GDS_WoWLook.Strip(f,"BORDER",11,11,4,1,{.25,.18,.10,.95})
        h.low = f:CreateTexture(nil,"BORDER")
        h.low:SetPoint("BOTTOMLEFT",f,"BOTTOMLEFT",5,2)
        h.low:SetPoint("BOTTOMRIGHT",f,"BOTTOMRIGHT",-5,2)
        h.low:SetHeight(2)
        h.low:SetColorTexture(.57,.42,.21,.88)
        f._gtWoWHeader=h
    end
    local active = GDS_WoWLook.Enabled() and (not DB.show or DB.show.header ~= false)
    for _, v in pairs(f._gtWoWHeader) do v:SetShown(active) end
    GDS_WoWLook.headers[tex]=true
end
function GDS_WoWLook.SyncFooter(tex)
    if not tex then return end
    local f=tex:GetParent()
    if not f then return end
    if not f._gtWoWFooter then
        local line=f:CreateTexture(nil,"BORDER")
        line:SetPoint("TOPLEFT",f,"TOPLEFT",7,-3)
        line:SetPoint("TOPRIGHT",f,"TOPRIGHT",-7,-3)
        line:SetHeight(2)
        line:SetColorTexture(.54,.39,.18,.84)
        f._gtWoWFooter=line
    end
    f._gtWoWFooter:SetShown(GDS_WoWLook.Enabled()
        and (not DB.show or DB.show.footer ~= false))
    GDS_WoWLook.footers[tex]=true
end
function GDS_WoWLook.SyncStatRow(row)
    if not row then return end
    if not row._gtWoWUnderline then
        local line=row:CreateTexture(nil,"BORDER")
        line:SetPoint("BOTTOMLEFT",row,"BOTTOMLEFT",3,0)
        line:SetPoint("BOTTOMRIGHT",row,"BOTTOMRIGHT",-3,0)
        line:SetHeight(1)
        line:SetColorTexture(.43,.34,.19,.42)
        row._gtWoWUnderline=line
    end
    row._gtWoWUnderline:SetShown(GDS_WoWLook.Enabled())
    GDS_WoWLook.statRows[row]=true
end
function GDS_WoWLook.SyncButton(button)
    if not button or not button._gtWoWLookTrim then return end
    local trim = button._gtWoWLookTrim
    if not button._gtWoWLookFace then
        local face=button:CreateTexture(nil, "BORDER")
        face:SetPoint("TOPLEFT",button,"TOPLEFT",0,0)
        face:SetPoint("BOTTOMRIGHT",button,"BOTTOMRIGHT",0,0)
        -- Native WoW raised button art, rendered BELOW its overlay label.
        -- Do not apply to 20px icon buttons whose art would be squashed.
        face:SetTexture("Interface\\Buttons\\UI-Panel-Button-Up")
        face:SetVertexColor(.63,.47,.32,.94)
        button._gtWoWLookFace=face
    end
    local visible = GDS_WoWLook.Enabled()
    for _, tex in pairs(trim) do tex:SetShown(visible) end
    button._gtWoWLookFace:SetShown(visible and button:GetWidth() >= 36)
    if visible then
        trim.top:SetColorTexture(.84,.60,.25,.85)
        trim.bottom:SetColorTexture(.018,.012,.006,.94)
        trim.left:SetColorTexture(1,.78,.33,.85)
        trim.right:SetColorTexture(1,.78,.33,.85)
        trim.active:SetShown(button._gtWoWLookSelected == true)
        trim.active:SetColorTexture(1,.79,.20,1)
    end
    GDS_WoWLook.buttons[button] = true
end
function GDS_WoWLook.Tab(button, selected)
    if not button then return end
    button._gtWoWLookSelected = selected == true
    GDS_WoWLook.SyncButton(button)
    if button._gtWoWLookFace and GDS_WoWLook.Enabled() then
        button._gtWoWLookFace:SetVertexColor(selected and .84 or .46,
            selected and .62 or .33, selected and .34 or .23, .96)
    end
end
function GDS_WoWLook.SyncAll()
    for frame in pairs(GDS_WoWLook.frames) do GDS_WoWLook.SyncFrame(frame) end
    for btn in pairs(GDS_WoWLook.buttons) do GDS_WoWLook.SyncButton(btn) end
    for tex in pairs(GDS_WoWLook.headers) do GDS_WoWLook.SyncHeader(tex) end
    for tex in pairs(GDS_WoWLook.footers) do GDS_WoWLook.SyncFooter(tex) end
    for row in pairs(GDS_WoWLook.statRows) do GDS_WoWLook.SyncStatRow(row) end
    for _, tex in ipairs(GT_headers) do GDS_WoWLook.SyncHeader(tex) end
    for _, tex in ipairs(GT_footers) do GDS_WoWLook.SyncFooter(tex) end
end

-- Authentic Vanilla draws only with Blizzard's shipped textures.  No borrowed
-- Blizzard frames, no protected action buttons, no OnUpdate loops, and no
-- textures above labels.  Art is created lazily and reused on skin switches.
-- The established DungeonQuester reference uses UI-DialogBox-Border and
-- UIPanelButtonTemplate; the three-state files below are from the same UI set.
GDS_VanillaArt = GDS_VanillaArt or {}
GDS_VanillaArt.frames = setmetatable({}, {__mode="k"})
GDS_VanillaArt.buttons = setmetatable({}, {__mode="k"})
GDS_VanillaArt.headers = setmetatable({}, {__mode="k"})
function GDS_VanillaArt.Enabled()
    return DB ~= nil and DB.skinMode == "authenticvanilla"
end
function GDS_VanillaArt.SyncFrame(frame)
    if not frame then return end
    local active = GDS_VanillaArt.Enabled()
    if active and not frame._gtAuthenticArt and frame:GetHeight() >= 165 then
        local deco = {}
        -- An inner stone panel, inset from the real dialog border. Keep it
        -- semitransparent so short text and graph axes stay legible.
        deco.stone = frame:CreateTexture(nil, "BACKGROUND", nil, 2)
        deco.stone:SetTexture("Interface\\FrameGeneral\\UI-Background-Rock")
        deco.stone:SetPoint("TOPLEFT", frame, "TOPLEFT", 12, -12)
        deco.stone:SetPoint("BOTTOMRIGHT", frame, "BOTTOMRIGHT", -12, 12)
        deco.stone:SetVertexColor(.39, .33, .25, .23)
        deco.top = frame:CreateTexture(nil, "BORDER")
        deco.top:SetPoint("TOPLEFT", frame, "TOPLEFT", 15, -9)
        deco.top:SetPoint("TOPRIGHT", frame, "TOPRIGHT", -15, -9)
        deco.top:SetHeight(2)
        deco.top:SetColorTexture(.83, .58, .26, .74)
        deco.bottom = frame:CreateTexture(nil, "BORDER")
        deco.bottom:SetPoint("BOTTOMLEFT", frame, "BOTTOMLEFT", 15, 9)
        deco.bottom:SetPoint("BOTTOMRIGHT", frame, "BOTTOMRIGHT", -15, 9)
        deco.bottom:SetHeight(2)
        deco.bottom:SetColorTexture(.61, .41, .18, .70)
        deco.left = frame:CreateTexture(nil, "BORDER")
        deco.left:SetPoint("TOPLEFT", frame, "TOPLEFT", 9, -15)
        deco.left:SetPoint("BOTTOMLEFT", frame, "BOTTOMLEFT", 9, 15)
        deco.left:SetWidth(2)
        deco.left:SetColorTexture(.64, .45, .21, .62)
        deco.right = frame:CreateTexture(nil, "BORDER")
        deco.right:SetPoint("TOPRIGHT", frame, "TOPRIGHT", -9, -15)
        deco.right:SetPoint("BOTTOMRIGHT", frame, "BOTTOMRIGHT", -9, 15)
        deco.right:SetWidth(2)
        deco.right:SetColorTexture(.64, .45, .21, .62)
        frame._gtAuthenticArt = deco
    end
    if frame._gtAuthenticArt then
        for _, tex in pairs(frame._gtAuthenticArt) do tex:SetShown(active) end
    end
    GDS_VanillaArt.frames[frame] = true
end
function GDS_VanillaArt.SyncHeader(bgTexture)
    if not bgTexture then return end
    local parent = bgTexture:GetParent()
    if not parent then return end
    if GDS_VanillaArt.Enabled() and not parent._gtAuthenticHeader then
        local art = parent:CreateTexture(nil, "BORDER")
        art:SetTexture("Interface\\DialogFrame\\UI-DialogBox-Header")
        art:SetSize(182, 28)
        art:SetPoint("TOP", parent, "TOP", 0, 1)
        art:SetVertexColor(.80, .61, .37, .65)
        parent._gtAuthenticHeader = art
    end
    if parent._gtAuthenticHeader then
        parent._gtAuthenticHeader:SetShown(GDS_VanillaArt.Enabled())
    end
    GDS_VanillaArt.headers[bgTexture] = true
end
function GDS_VanillaArt.SyncButton(button)
    if not button then return end
    -- Keep compact X, +/- and icon buttons legible in their original geometry.
    -- Skin ordinary controls only. Button foreground text stays OVERLAY.
    local active = GDS_VanillaArt.Enabled()
        and button:GetWidth() >= 40 and button:GetHeight() >= 18
        and button:GetHeight() <= 34
    if active and not button._gtAuthenticButton then
        button:SetNormalTexture("Interface\\Buttons\\UI-Panel-Button-Up")
        button:SetPushedTexture("Interface\\Buttons\\UI-Panel-Button-Down")
        button:SetHighlightTexture("Interface\\Buttons\\UI-Panel-Button-Highlight")
        local normal, pushed, highlight = button:GetNormalTexture(),
            button:GetPushedTexture(), button:GetHighlightTexture()
        if normal then normal:SetTexCoord(0, .625, 0, .6875) end
        if pushed then pushed:SetTexCoord(0, .625, 0, .6875) end
        if highlight then
            highlight:SetTexCoord(0, .625, 0, .6875)
            highlight:SetBlendMode("ADD")
            highlight:SetAlpha(.45)
        end
        button._gtAuthenticButton = true
    end
    if button._gtAuthenticButton then
        local normal, pushed, highlight = button:GetNormalTexture(),
            button:GetPushedTexture(), button:GetHighlightTexture()
        if normal then normal:SetShown(active) end
        if pushed then pushed:SetShown(active) end
        if highlight then highlight:SetShown(active) end
        -- Visibility is reset with the skin, not hidden permanently.
        if button.bg then button.bg:SetShown(not active) end
        if button._gtEdges then
            for _, edge in ipairs(button._gtEdges) do edge:SetShown(not active) end
        end
    end
    GDS_VanillaArt.buttons[button] = true
end
function GDS_VanillaArt.SyncAll()
    for frame in pairs(GT_frames) do GDS_VanillaArt.SyncFrame(frame) end
    for button in pairs(GDS_VanillaArt.buttons) do GDS_VanillaArt.SyncButton(button) end
    for _, texture in ipairs(GT_headers) do GDS_VanillaArt.SyncHeader(texture) end
end

local function SetFrameBackdropStyle(f)
    if not f.SetBackdrop then return end
    if DB and DB.skinMode == "wow" then
        f:SetBackdrop({
            bgFile = "Interface\\DialogFrame\\UI-DialogBox-Background-Dark",
            edgeFile = "Interface\\DialogFrame\\UI-DialogBox-Border",
            tile=true, tileSize=32, edgeSize=24,
            insets={left=8,right=8,top=8,bottom=8},
        })
    elseif DB and DB.skinMode == "wowlook" then
        -- Uses the same known working Blizzard dialog border as the Vanilla
        -- color skin, with slightly wider carved trim. Native backdrop only;
        -- unlike parchment overlays, this cannot hide child text or buttons.
        f:SetBackdrop({
            bgFile = "Interface\\DialogFrame\\UI-DialogBox-Background-Dark",
            edgeFile = "Interface\\DialogFrame\\UI-DialogBox-Border",
            tile=true, tileSize=32, edgeSize=28,
            insets={left=9,right=9,top=9,bottom=9},
        })
    elseif DB and DB.skinMode == "authenticvanilla" then
        -- Blizzard's genuine dialog-box frame and native dark backdrop.
        -- 28px border preserves ornate corners while leaving content visible.
        f:SetBackdrop({
            bgFile = "Interface\\DialogFrame\\UI-DialogBox-Background-Dark",
            edgeFile = "Interface\\DialogFrame\\UI-DialogBox-Border",
            tile=true, tileSize=32, edgeSize=28,
            insets={left=10,right=10,top=10,bottom=10},
        })
    elseif DB and DB.skinMode == "classicstone" then
        -- The rock background is the actual tiled backdrop used in Blizzard's
        -- classic framed panels. Tint stays dark enough for small gold numbers.
        f:SetBackdrop({
            bgFile = "Interface\\FrameGeneral\\UI-Background-Rock",
            edgeFile = "Interface\\DialogFrame\\UI-DialogBox-Border",
            tile=true, tileSize=128, edgeSize=24,
            insets={left=8,right=8,top=8,bottom=8},
        })
    elseif DB and DB.skinMode == "classicleather" then
        -- Native dialog artwork; distinct from Vanilla WoW's dark background.
        f:SetBackdrop({
            bgFile = "Interface\\DialogFrame\\UI-DialogBox-Background",
            edgeFile = "Interface\\DialogFrame\\UI-DialogBox-Border",
            tile=true, tileSize=32, edgeSize=24,
            insets={left=8,right=8,top=8,bottom=8},
        })
    elseif DB and DB.skinMode == "tooltipframe" then
        -- Blizzard tooltip-style boxed window, deliberately understated.
        f:SetBackdrop({
            bgFile = "Interface\\Tooltips\\UI-Tooltip-Background",
            edgeFile = "Interface\\Tooltips\\UI-Tooltip-Border",
            tile=true, tileSize=16, edgeSize=16,
            insets={left=5,right=5,top=5,bottom=5},
        })
    else
        f:SetBackdrop({
            bgFile   = "Interface\\Buttons\\WHITE8X8",
            edgeFile = "Interface\\Buttons\\WHITE8X8",
            tile=false, tileSize=0, edgeSize=1,
            insets={left=1,right=1,top=1,bottom=1},
        })
    end
end

-- Optional solid backing for opaque mode. Some Blizzard backdrop art has
-- transparency baked into the image, so an alpha=1 tint is not sufficient.
-- This lowest BACKGROUND sublevel never covers the frame's labels or buttons.
-- Unlike the old book-skin overlays, it is hidden unless explicitly enabled.
function GDS_ApplyOpaqueBase(f)
    if not f then return end
    if DB and DB.opaque == true then
        if not f._gtOpaqueBase then
            local backing = f:CreateTexture(nil, "BACKGROUND", nil, -8)
            backing:SetAllPoints(f)
            f._gtOpaqueBase = backing
        end
        local theme = DB.theme or DEFAULT_THEME
        f._gtOpaqueBase:SetColorTexture(theme.bgR, theme.bgG, theme.bgB, 1)
        f._gtOpaqueBase:Show()
    elseif f._gtOpaqueBase then
        f._gtOpaqueBase:Hide()
    end
end

local function ApplyBackdrop(f)
    if not f.SetBackdrop then return end
    SetFrameBackdropStyle(f)
    local t = DB and DB.theme
    f:SetBackdropColor(
        t and t.bgR or 0.025, t and t.bgG or 0.033, t and t.bgB or 0.043,
        (DB and DB.opaque) and 1 or (t and t.bgA or 0.92))
    f:SetBackdropBorderColor(
        t and t.borderR or 0.22, t and t.borderG or 0.31, t and t.borderB or 0.40, 0.95)
    GT_frames[f] = true
    GDS_ApplyOpaqueBase(f)
    GDS_WoWLook.SyncFrame(f)
    GDS_VanillaArt.SyncFrame(f)
end

SetThemeTextColor = function(fs, alpha)
    if not fs or not DB or not DB.theme then return end
    local t=DB.theme
    if DB.skinMode == "wowlook" then
        -- Use parchment-white body text and saturated gold titles.
        -- Keep personal tracker readouts readable at their small size.
        fs:SetTextColor(.93,.89,.79,alpha or 1)
    else
        fs:SetTextColor(t.accentR,t.accentG,t.accentB,alpha or 1)
    end
end

TrackThemeText = function(fs, alpha)
    if not fs then return fs end
    GT_texts[fs] = alpha or 1
    SetThemeTextColor(fs, alpha)
    return fs
end

local function ApplyTheme()
    if not DB or not DB.theme then return end
    local t = DB.theme
    for f in pairs(GT_frames) do
        if f.SetBackdropColor then
            SetFrameBackdropStyle(f)
            f:SetBackdropColor(t.bgR, t.bgG, t.bgB, DB.opaque and 1 or t.bgA)
            f:SetBackdropBorderColor(t.borderR, t.borderG, t.borderB, 0.9)
        end
        GDS_ApplyOpaqueBase(f)
        GDS_WoWLook.SyncFrame(f)
    end
    for _, fs in ipairs(GT_titles) do
        if DB.skinMode == "wowlook" then
            fs:SetTextColor(1, .84, .17, 1)
        else
            fs:SetTextColor(t.accentR,t.accentG,t.accentB)
        end
    end
    for _, edges in ipairs(GT_btnEdges) do
        for _, e in ipairs(edges) do
            e:SetColorTexture(t.borderR, t.borderG, t.borderB, 1)
        end
    end
    for _, fs in ipairs(GT_btnLabels) do
        if DB.skinMode == "wowlook" then
            fs:SetTextColor(.99,.84,.30,1)
        else
            fs:SetTextColor(t.accentR,t.accentG,t.accentB)
        end
    end
    for _, bg in ipairs(GT_btnBgs) do
        bg:SetColorTexture(GDS_GetSkinButtonColor())
    end
    for _, th in ipairs(GT_thumbs) do
        th:SetColorTexture(t.borderR, t.borderG, t.borderB, 0.9)
    end
    for _, d in ipairs(GT_dividers) do
        d:SetColorTexture(t.borderR, t.borderG, t.borderB, 0.8)
    end
    for _, bg in ipairs(GT_headers) do
        bg:SetColorTexture(t.headerR or 0.045, t.headerG or 0.06, t.headerB or 0.078, t.headerA or 0.84)
    end
    for _, bg in ipairs(GT_footers) do
        bg:SetColorTexture(t.footerR or 0.045, t.footerG or 0.06, t.footerB or 0.078, t.footerA or 0.84)
    end
    for _, cBd in ipairs(GT_cbBorders) do
        cBd:SetColorTexture(t.borderR, t.borderG, t.borderB, 1)
    end
    for _, p in ipairs(GT_softPanels) do
        if DB.skinMode == "wowlook" then
            p:SetColorTexture(.21,.15,.075,math.min(.55,(p._gtAlpha or .34)+.15))
        else
            p:SetColorTexture(t.headerR or .05,t.headerG or .07,t.headerB or .09,p._gtAlpha or .36)
        end
    end
    for fs, alpha in pairs(GT_texts) do
        SetThemeTextColor(fs, alpha)
    end
    for _, btn in pairs(historyTabBtns) do UpdateHistoryTabButton(btn) end
    GDS_WoWLook.SyncAll()
    GDS_VanillaArt.SyncAll()
    -- Restore the exact Analytics tab fill when a skin changes mid-session.
    if lootFrame and lootFrame:IsShown() and SetAnalyticsTab then SetAnalyticsTab(activeTab) end
end

local function PersistAppearance()
    if not DB then return end
    DB.customTheme = CopyTheme(DB.customTheme or DB.theme or DEFAULT_THEME)
    local profile = DB.profiles and DB.currentProfile and DB.profiles[DB.currentProfile]
    if profile then
        profile.skinMode = DB.skinMode
        profile.theme = CopyTheme(DB.theme)
        profile.customTheme = CopyTheme(DB.customTheme)
    end
end

local function SetSkinMode(mode)
    if not DB or (mode ~= "default" and mode ~= "wow" and mode ~= "nightfall"
        and mode ~= "wowlook" and mode ~= "classicstone"
        and mode ~= "classicleather" and mode ~= "tooltipframe"
        and mode ~= "authenticvanilla" and mode ~= "custom") then return end
    if DB.skinMode == "custom" and DB.theme then
        DB.customTheme = CopyTheme(DB.theme)
    end
    DB.skinMode = mode
    if mode == "default" then
        DB.theme = CopyTheme(DEFAULT_THEME)
    elseif mode == "wow" then
        DB.theme = CopyTheme(WOW_THEME)
    elseif mode == "nightfall" then
        DB.theme = CopyTheme(GDS_NIGHTFALL_THEME)
    elseif mode == "wowlook" then
        DB.theme = CopyTheme(GDS_WOWLOOK_THEME)
    elseif mode == "classicstone" then
        DB.theme = CopyTheme(GDS_CLASSIC_STONE_THEME)
    elseif mode == "classicleather" then
        DB.theme = CopyTheme(GDS_CLASSIC_LEATHER_THEME)
    elseif mode == "tooltipframe" then
        DB.theme = CopyTheme(GDS_TOOLTIP_FRAME_THEME)
    elseif mode == "authenticvanilla" then
        DB.theme = CopyTheme(GDS_AUTHENTIC_VANILLA_THEME)
    else
        DB.theme = CopyTheme(DB.customTheme or DEFAULT_THEME)
        DB.customTheme = CopyTheme(DB.theme)
    end
    ApplyTheme()
    PersistAppearance()
end

local function MakeBtn(parent, w, h, label)
    local b  = CreateFrame("Button", nil, parent)
    b:SetSize(w, h)
    local bg = b:CreateTexture(nil, "BACKGROUND")
    bg:SetAllPoints()
    bg:SetColorTexture(GDS_GetSkinButtonColor())
    b.bg = bg
    local t  = DB and DB.theme
    local bR = t and t.borderR or 0.22
    local bG = t and t.borderG or 0.31
    local bB = t and t.borderB or 0.40
    local edges = {}
    local function Edge(pt, ew, eh)
        local e = b:CreateTexture(nil, "BORDER")
        e:SetSize(ew,eh); e:SetPoint(pt)
        e:SetColorTexture(bR,bG,bB,1)
        table.insert(edges, e)
    end
    Edge("TOPLEFT",w,1); Edge("BOTTOMLEFT",w,1)
    Edge("TOPLEFT",1,h); Edge("TOPRIGHT",1,h)
    -- Inset engraved button bevel, not a translucent texture above the text.
    local trim = {}
    trim.top = b:CreateTexture(nil, "ARTWORK")
    trim.top:SetPoint("TOPLEFT", 3, -3)
    trim.top:SetPoint("TOPRIGHT", -3, -3)
    trim.top:SetHeight(1)
    trim.bottom = b:CreateTexture(nil, "ARTWORK")
    trim.bottom:SetPoint("BOTTOMLEFT", 3, 3)
    trim.bottom:SetPoint("BOTTOMRIGHT", -3, 3)
    trim.bottom:SetHeight(2)
    trim.left = b:CreateTexture(nil, "ARTWORK")
    trim.left:SetPoint("TOPLEFT", 1, -1)
    trim.left:SetSize(3, 3)
    trim.right = b:CreateTexture(nil, "ARTWORK")
    trim.right:SetPoint("TOPRIGHT", -1, -1)
    trim.right:SetSize(3, 3)
    trim.active = b:CreateTexture(nil, "ARTWORK")
    trim.active:SetPoint("BOTTOMLEFT", 5, 2)
    trim.active:SetPoint("BOTTOMRIGHT", -5, 2)
    trim.active:SetHeight(2)
    b._gtWoWLookTrim = trim
    GDS_WoWLook.SyncButton(b)
    local fs = b:CreateFontString(nil,"OVERLAY","GameFontNormalSmall")
    fs:SetAllPoints(); fs:SetJustifyH("CENTER"); fs:SetJustifyV("MIDDLE")
    local aR = t and t.accentR or 0.88
    local aG = t and t.accentG or 0.92
    local aB = t and t.accentB or 0.96
    fs:SetText(label or ""); fs:SetTextColor(aR,aG,aB); b.label = fs
    b:SetScript("OnEnter", function()
        local tt = DB and DB.theme
        bg:SetColorTexture((tt and tt.borderR or bR) * 0.45, (tt and tt.borderG or bG) * 0.45, (tt and tt.borderB or bB) * 0.45, 0.95)
    end)
    b:SetScript("OnLeave", function()
        bg:SetColorTexture(GDS_GetSkinButtonColor())
    end)
    b._gtEdges = edges
    table.insert(GT_btnEdges, edges)
    table.insert(GT_btnLabels, fs)
    table.insert(GT_btnBgs, bg)
    GDS_VanillaArt.SyncButton(b)
    return b
end

do
    local log = GDS_LoginLog
    local window
    local perPage = 8

    local function stamp(t)
        return date("%b %d, %Y  %I:%M %p", t)
    end

    local function duration(row)
        local extra = row == log.row and math.max(0,GetTime()-log.clock) or 0
        return FormatTime(math.floor(row.seconds + extra))
    end

    local function previousIndex(rows, selected)
        for i=2,#rows do
            local older = rows[i]
            if rows[i-1] == selected and older.ended and older.ended <= selected.started
                and older.started < selected.started then return i end
        end
    end

    local function render(f)
        local rows = DB.loginHistory or {}
        local details = f.mode == "details"
        local dungeon = f.mode == "items"
        local count = dungeon and #f.items or #rows
        local pages = math.max(1,math.ceil(count/perPage))
        f.page = math.max(1,math.min(f.page,pages))
        f.title:SetText(details and "Login session details" or dungeon and "Dungeon loot" or "Login sessions")
        f.back:SetShown(details)
        local index = details and previousIndex(rows,f.selected)
        local previous = index and rows[index]
        if f.mergeTarget ~= previous then f.mergeTarget = nil end
        f.merge:SetShown(not not previous)
        f.merge.label:SetText(f.mergeTarget and "Confirm merge" or "Merge with previous")
        f.prev:SetShown(not details and f.page > 1)
        f.next:SetShown(not details and f.page < pages)
        f.footer:ClearAllPoints()
        f.footer:SetPoint("BOTTOM",0,details and 32 or 14)
        f.footer:SetText(details and "" or ("Page "..f.page.." / "..pages))
        for _, line in ipairs(f.lines) do line:Hide() end
        local function line(i,label,value,row)
            local b = f.lines[i]
            b.left:SetText(label)
            b.right:SetText(value or "")
            b.row = row
            b:EnableMouse(row ~= nil)
            b:Show()
        end
        if details then
            local r = f.selected
            local function stat(value, fmt)
                return value ~= nil and fmt(value) or "Unrecorded"
            end
            f.caption:SetText(stamp(r.started).."   –   "..(r == log.row and "Now" or stamp(r.ended or r.started)))
            if f.mergeTarget then f.caption:SetText("Merge with session from "..stamp(f.mergeTarget.started).."?") end
            line(1,"Time played",duration(r))
            local dungeonXP,questXP,otherXP = log.XPBreakdown(r)
            line(2,"Dungeon XP",stat(dungeonXP,FmtNum))
            line(3,"Quest XP",stat(questXP,FmtNum))
            line(4,"Other XP",stat(otherXP,FmtNum))
            line(5,"Total XP",FmtNum(r.xp))
            line(6,"Looted coin",stat(r.lootCoin,Coin))
            line(7,"Quest reward coin",stat(r.questCoin,Coin))
            line(8,"Net wallet change",log.WalletText(r,Coin))
            line(9,"Kills",FmtNum(r.kills))
            line(10,"Items looted",FmtNum(r.items))
            line(11,"Honorable kills",stat(r.hk,FmtNum))
            line(12,"Killing blows",stat(r.kb,FmtNum))
            line(13,"Looted item value",stat(r.itemValue,Coin))
            line(14,"Farming gold (loot coin + item value)",stat(r.itemValue and (r.itemValue+r.lootCoin),Coin))
            if (r.unknownXP or 0) > 0 then
                f.footer:SetText(FmtNum(r.unknownXP).." earlier XP unclassified")
            elseif r.partial then f.footer:SetText("New stats begin at the update") end
        elseif dungeon then
            f.caption:SetText(f.run.dungeon or f.run.name or "Dungeon run")
            for i=1,perPage do
                local item = f.items[(f.page-1)*perPage+i]
                if item then line(i,item.name,"× "..item.qty) end
            end
            if count == 0 then
                line(1,f.run.lootItems and "No loot recorded." or "Item list unavailable for this older run.")
            end
        else
            f.caption:SetText("Choose a session to view its details.")
            for i=1,perPage do
                local r = rows[(f.page-1)*perPage+i]
                if r then line(i,stamp(r.started)..(r == log.row and "   • Live" or ""),duration(r).."  ›",r) end
            end
            if #rows == 0 then line(1,"Enable Login tracker in Settings to start a log.") end
        end
    end

    local function build(parent)
        local f
        if parent then
            f = CreateFrame("Frame",nil,parent)
            f:SetPoint("TOPLEFT",parent,"TOPLEFT",2,-58)
            f:SetPoint("BOTTOMRIGHT",parent,"BOTTOMRIGHT",-2,2)
        else
            f = CreateFrame("Frame","GDSActivityLogFrame",UIParent,BackdropTemplateMixin and "BackdropTemplate")
            GDS_FocusWindow(f)
            f:SetSize(405,436)
            f:SetPoint("CENTER")
            f:SetClampedToScreen(true)
            f:EnableMouse(true)
            f:SetMovable(true)
            f:RegisterForDrag("LeftButton")
            f:SetScript("OnDragStart",f.StartMoving)
            f:SetScript("OnDragStop",f.StopMovingOrSizing)
            ApplyBackdrop(f)
            table.insert(UISpecialFrames,"GDSActivityLogFrame")
        end
        local function label(parent,font,anchor,x,y)
            local fs = parent:CreateFontString(nil,"OVERLAY",font)
            fs:SetPoint(anchor,x,y)
            return fs
        end
        f.title = label(f,"GameFontNormalLarge","TOP",0,-10)
        f.caption = label(f,"GameFontNormalSmall","TOPLEFT",14,-38)
        f.footer = label(f,"GameFontHighlightSmall","BOTTOM",0,14)
        if not parent then
            local close = MakeBtn(f,22,20,"X")
            close:SetPoint("TOPRIGHT",-5,-5)
            close:SetScript("OnClick",function() f:Hide() end)
        end
        f.prev = MakeBtn(f,62,20,"Previous")
        f.prev:SetPoint("BOTTOMLEFT",10,8)
        f.prev:SetScript("OnClick",function() f.page=f.page-1; render(f) end)
        f.next = MakeBtn(f,62,20,"Next")
        f.next:SetPoint("BOTTOMRIGHT",-10,8)
        f.next:SetScript("OnClick",function() f.page=f.page+1; render(f) end)
        f.back = MakeBtn(f,62,20,"Back")
        f.back:SetPoint("BOTTOMLEFT",10,8)
        f.back:SetScript("OnClick",function() f.mode="list"; render(f) end)
        f.merge = MakeBtn(f,130,20,"Merge with previous")
        f.merge:SetPoint("BOTTOMRIGHT",-10,8)
        f.merge:SetScript("OnClick",function()
            local rows = DB.loginHistory or {}
            local i = previousIndex(rows,f.selected)
            if i and f.mergeTarget == rows[i] then
                log.MergePair(rows,i)
                f.mergeTarget = nil
            else
                f.mergeTarget = i and rows[i]
            end
            render(f)
        end)
        f:SetScript("OnHide",function() f.mergeTarget = nil end)
        f.lines = {}
        for i=1,14 do
            local b = CreateFrame("Button",nil,f)
            b:SetPoint("TOPLEFT",10,-56-(i-1)*24)
            b:SetPoint("TOPRIGHT",-10,-56-(i-1)*24)
            b:SetHeight(24)
            local stripe = b:CreateTexture(nil,"BACKGROUND")
            stripe:SetAllPoints()
            stripe:SetColorTexture(0,0,0,i%2==0 and .25 or .12)
            b:SetHighlightTexture("Interface\\QuestFrame\\UI-QuestTitleHighlight")
            b.left = label(b,"GameFontHighlightSmall","LEFT",5,0)
            b.left:SetWidth(280)
            b.left:SetJustifyH("LEFT")
            b.right = label(b,"GameFontNormalSmall","RIGHT",-5,0)
            b:SetScript("OnClick",function(self)
                if self.row then f.selected=self.row; f.mode="details"; render(f) end
            end)
            f.lines[i]=b
        end
        f:SetScript("OnUpdate",function(self,elapsed)
            self.elapsed=(self.elapsed or 0)+elapsed
            if self.elapsed<1 then return end
            self.elapsed=0
            if self.mode=="items" then
                if self.run==GDS_LiveDungeon.ActiveRun() and self.dirty then log.OpenItems(self.run,true) end
            else render(f) end
        end)
        return f
    end

    function log.ShowHistory(parent)
        if not parent.loginPanel then
            parent.loginPanel = build(parent)
            parent.loginPanel:Hide()
        end
        local f = parent.loginPanel
        if not f:IsShown() then
            log.Sample()
            f.mode, f.page = "list", 1
            f:Show()
        end
        render(f)
    end

    function log.ItemsChanged(run)
        if window and window.run==run then window.dirty=true end
    end

    function log.OpenItems(run,refresh)
        if not window then window = build() end
        local f = window
        if not refresh then
            f.mode, f.page = "items", 1
            f:Show()
            f:Raise()
        end
        f.run,f.items,f.dirty=run,{},false
        for _, item in pairs(run.lootItems or {}) do table.insert(f.items,item) end
        table.sort(f.items,function(a,b) return a.name < b.name end)
        render(f)
    end
end

-- Separate saved scoreboard; not tied to current party roster or grind session.
-- Open it using "KB Board" in Party Stats, even when playing solo.
function GDS_KBBoard.Refresh()
    local f = GDS_KBBoard.window
    if not f or not f:IsShown() or not DB then return end
    local data = {}
    for key, rec in pairs(DB.partyKBLifetime or {}) do
        if type(rec) == "table" and (tonumber(rec.count) or 0) > 0 then
            data[#data+1] = {key=key, name=rec.name or key,
                count=math.floor(rec.count), selfPlayer=rec.selfPlayer}
        end
    end
    table.sort(data, function(a,b)
        if a.count == b.count then return a.name < b.name end
        return a.count > b.count
    end)
    local sum=0
    for _, rec in ipairs(data) do sum=sum+rec.count end
    f.summary:SetText(("%d players  |  %d party killing blows"):format(#data, sum))
    f.empty:SetShown(#data == 0)
    for i, rec in ipairs(data) do
        local row = f.rows[i]
        if not row then
            row = CreateFrame("Frame", nil, f.content)
            row:SetSize(338, 23)
            row:SetPoint("TOPLEFT", f.content, "TOPLEFT", 0, -(i-1)*24)
            local bg = row:CreateTexture(nil, "BACKGROUND")
            bg:SetAllPoints()
            bg:SetColorTexture(.40,.45,.52, i%2 == 1 and .10 or .035)
            local left = row:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
            left:SetPoint("LEFT", row, "LEFT", 7, 0)
            left:SetPoint("RIGHT", row, "RIGHT", -77, 0)
            left:SetJustifyH("LEFT")
            left:SetWordWrap(false)
            local right = row:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
            right:SetPoint("RIGHT", row, "RIGHT", -7, 0)
            right:SetWidth(64)
            right:SetJustifyH("RIGHT")
            row.left, row.right = left, right
            f.rows[i] = row
        end
        row.left:SetText(i .. ".  " .. rec.name .. (rec.selfPlayer and " (You)" or ""))
        row.right:SetText(FmtNum(rec.count))
        row:Show()
    end
    for i=#data+1,#f.rows do f.rows[i]:Hide() end
    local height = math.max(238, #data*24)
    f.content:SetHeight(height)
    f.maxScroll = math.max(0, height-238)
    if f.scroll:GetVerticalScroll() > f.maxScroll then
        f.scroll:SetVerticalScroll(f.maxScroll)
    end
end

function GDS_KBBoard.ToggleWindow()
    local f = GDS_KBBoard.window
    if not f then
        f = CreateFrame("Frame", "GDSLifetimeKBBoard", UIParent,
            BackdropTemplateMixin and "BackdropTemplate")
        GDS_FocusWindow(f)
        GDS_KBBoard.window = f
        f:SetSize(378, 372)
        f:SetFrameStrata("DIALOG")
        f:SetClampedToScreen(true)
        f:SetMovable(true)
        f:EnableMouse(true)
        f:RegisterForDrag("LeftButton")
        f:SetScript("OnDragStart", f.StartMoving)
        f:SetScript("OnDragStop", function(self)
            self:StopMovingOrSizing()
            local point, _, rel, x, y = self:GetPoint()
            if DB then DB.partyKBBoardPos = {p=point, rel=rel, x=x, y=y} end
        end)
        local pos = DB and DB.partyKBBoardPos
        if type(pos) == "table" and pos.p then
            f:SetPoint(pos.p, UIParent, pos.rel or pos.p, pos.x or 0, pos.y or 0)
        else
            f:SetPoint("CENTER", UIParent, "CENTER", 0, 0)
        end
        ApplyBackdrop(f)
        local title = f:CreateFontString(nil, "OVERLAY", "GameFontNormal")
        title:SetPoint("TOPLEFT", f, "TOPLEFT", 12, -12)
        title:SetText("Lifetime Party Killing Blows")
        local close = MakeBtn(f, 20, 20, "X")
        close:SetPoint("TOPRIGHT", -6, -6)
        close:SetScript("OnClick", function() f:Hide() end)
        local summary = f:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
        summary:SetPoint("TOPLEFT", 12, -39)
        summary:SetTextColor(.74,.77,.82,1)
        f.summary=summary
        local explanation = f:CreateFontString(nil, "OVERLAY", "GameFontDisableSmall")
        explanation:SetPoint("TOPLEFT", 12, -58)
        explanation:SetWidth(351)
        explanation:SetJustifyH("LEFT")
        explanation:SetText("Only confirmed KBs earned while you were grouped together.")
        local head = f:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
        head:SetPoint("TOPLEFT", 17, -80)
        head:SetText("PLAYER")
        local headCount = f:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
        headCount:SetPoint("TOPRIGHT", -22, -80)
        headCount:SetText("KBs")
        local scroll = CreateFrame("ScrollFrame", nil, f)
        scroll:SetPoint("TOPLEFT", f, "TOPLEFT", 13, -100)
        scroll:SetSize(347, 238)
        scroll:EnableMouseWheel(true)
        scroll:SetScript("OnMouseWheel", function(self, delta)
            self:SetVerticalScroll(math.max(0, math.min(f.maxScroll or 0,
                self:GetVerticalScroll()-delta*48)))
        end)
        f.scroll=scroll
        local content = CreateFrame("Frame", nil, scroll)
        content:SetSize(338, 238)
        scroll:SetScrollChild(content)
        f.content=content
        f.rows={}
        local empty = f:CreateFontString(nil, "OVERLAY", "GameFontDisableSmall")
        empty:SetPoint("CENTER", scroll, "CENTER", 0, 0)
        empty:SetText("No party killing blows recorded yet.")
        f.empty=empty
        local reset = MakeBtn(f, 105, 22, "Clear Board")
        reset:SetPoint("BOTTOMRIGHT", f, "BOTTOMRIGHT", -9, 8)
        reset:SetScript("OnClick", function(self)
            if not self.confirm then
                self.confirm=true
                self.label:SetText("Confirm Clear?")
                C_Timer.After(6, function()
                    if self.confirm then self.confirm=nil; self.label:SetText("Clear Board") end
                end)
                return
            end
            self.confirm=nil
            self.label:SetText("Clear Board")
            if DB then DB.partyKBLifetime = {} end
            GDS_KBBoard.Refresh()
        end)
        local help = f:CreateFontString(nil, "OVERLAY", "GameFontDisableSmall")
        help:SetPoint("BOTTOMLEFT", f, "BOTTOMLEFT", 12, 13)
        help:SetText("Drag to move  |  Scroll for more")
        f:SetScript("OnShow", GDS_KBBoard.Refresh)
        f:Hide()
    end
    if f:IsShown() then f:Hide()
    else f:Show(); GDS_KBBoard.Refresh() end
end

ShowSessionComparison = function(first, second)
    if not comparisonFrame then
        local f = CreateFrame("Frame", "GTSessionComparisonFrame", UIParent,
            BackdropTemplateMixin and "BackdropTemplate")
        GDS_FocusWindow(f)
        comparisonFrame = f
        f:SetSize(680, 500)
        f:SetPoint("CENTER")
        f:SetFrameStrata("DIALOG")
        f:SetClampedToScreen(true)
        f:EnableMouse(true)
        f:SetMovable(true)
        f:RegisterForDrag("LeftButton")
        f:SetScript("OnDragStart", f.StartMoving)
        f:SetScript("OnDragStop", f.StopMovingOrSizing)
        ApplyBackdrop(f)

        local title = f:CreateFontString(nil, "OVERLAY", "GameFontNormalLarge")
        title:SetPoint("TOP", 0, -14)
        title:SetText("Session Comparison")
        local theme = DB.theme or DEFAULT_THEME
        title:SetTextColor(theme.accentR, theme.accentG, theme.accentB)
        table.insert(GT_titles, title)
        local close = MakeBtn(f, 20, 20, "X")
        close:SetPoint("TOPRIGHT", -6, -6)
        close:SetScript("OnClick", function() f:Hide() end)

        local function Text(x, y, width, text)
            local fs = f:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
            fs:SetPoint("TOPLEFT", x, y)
            fs:SetWidth(width)
            fs:SetJustifyH("CENTER")
            TrackThemeText(fs)
            fs:SetText(text or "")
            return fs
        end
        Text(152, -44, 170, "Run A")
        Text(332, -44, 170, "Run B")
        f.runA = Text(152, -64, 170)
        f.runB = Text(332, -64, 170)
        f.runA:SetHeight(46)
        f.runB:SetHeight(46)
        Text(512, -118, 132, "Rate advantage")
        f.metrics = {}
        local definitions = {
            {"Tracked Time", "duration", FormatTime},
            {"Kills", "kills", FmtNum},
            {"XP Earned", "xp", FmtNum},
            {"Coin Looted", "coin", Coin},
            {"Item Value", "items", Coin},
            {"Total Value", "total", Coin},
            {"Kills / Hour", "kph", FmtNum, true},
            {"XP / Hour", "xph", FmtNum, true},
            {"Gold / Hour", "gph", Coin, true},
        }
        for i, metric in ipairs(definitions) do
            local y = -142 - (i-1)*26
            local stripe = f:CreateTexture(nil, "BACKGROUND")
            stripe:SetPoint("TOPLEFT", 10, y+5)
            stripe:SetPoint("TOPRIGHT", -10, y+5)
            stripe:SetHeight(25)
            stripe:SetColorTexture(0, 0, 0, i%2 == 0 and 0.25 or 0.08)
            local label = Text(18, y, 124, metric[1])
            label:SetJustifyH("LEFT")
            f.metrics[i] = {key=metric[2], format=metric[3], rate=metric[4],
                a=Text(152, y, 170), b=Text(332, y, 170), advantage=Text(512, y, 132)}
        end
        Text(14, -386, 632, "Hourly rates use tracked time. Item values use each run's saved prices.")
        local choose = MakeBtn(f, 160, 26, "Choose Other Runs")
        choose:SetPoint("BOTTOMLEFT", 152, 12)
        choose:SetScript("OnClick", function()
            f:Hide()
            historyActiveTab = "sessions"
            comparisonPicking, comparisonA = true, nil
            historyFrame.confirmBar:Hide()
            historyFrame.clearBtn:Show()
            RefreshHistory()
            historyFrame:Show()
        end)
        local graphs = MakeBtn(f, 170, 26, "Comparison Graphs")
        graphs:SetPoint("BOTTOMLEFT", 332, 12)
        graphs:SetScript("OnClick", function() ShowComparisonGraphs(f.first, f.second) end)
    end
    local f = comparisonFrame
    if comparisonGraphsFrame and comparisonGraphsFrame:IsShown() then
        CopyComparisonPosition(f, comparisonGraphsFrame)
        comparisonGraphsFrame:Hide()
    end
    f.first, f.second = first, second
    local function Label(session)
        local zone = session.zone
        if not zone or zone == "" then zone = "Area not recorded" end
        return zone.."\n"..GDS_HistoryDate.Format(session.date)
    end
    f.runA:SetText(Label(first))
    f.runB:SetText(Label(second))
    local a, b = SessionComparisonStats(first), SessionComparisonStats(second)
    for _, metric in ipairs(f.metrics) do
        metric.a:SetText(metric.rate and not a.hasRate and "N/A" or metric.format(a[metric.key]))
        metric.b:SetText(metric.rate and not b.hasRate and "N/A" or metric.format(b[metric.key]))
        metric.advantage:SetText(metric.rate and
            (a.hasRate and b.hasRate and ComparisonAdvantage(a[metric.key], b[metric.key]) or "N/A") or "-")
    end
    f:Show()
    f:Raise()
end

local function MakeScrollFrame(parent, contentW, padTop, padBottom)
    padBottom = padBottom or 8
    local clip = CreateFrame("Frame", nil, parent)
    clip:SetPoint("TOPLEFT", 8, -padTop)
    clip:SetPoint("BOTTOMRIGHT", -16, padBottom)
    clip:SetClipsChildren(true)

    local content = CreateFrame("Frame", nil, clip)
    content:SetWidth(contentW); content:SetHeight(1); content:SetPoint("TOPLEFT")

    local bar = CreateFrame("Slider", nil, parent)
    bar:SetOrientation("VERTICAL")
    bar:SetPoint("TOPRIGHT",    -3, -padTop)
    bar:SetPoint("BOTTOMRIGHT", -3,  padBottom)
    bar:SetWidth(7)
    bar:SetMinMaxValues(0,1); bar:SetValue(0)
    local bt = bar:CreateTexture(nil,"BACKGROUND")
    bt:SetAllPoints(); bt:SetColorTexture(0.035,0.045,0.060,0.80)
    local th = bar:CreateTexture(nil,"OVERLAY")
    local _t = DB and DB.theme
    th:SetSize(5,28)
    th:SetColorTexture(_t and _t.borderR or 0.22, _t and _t.borderG or 0.31, _t and _t.borderB or 0.40, .9)
    table.insert(GT_thumbs, th)
    bar:SetThumbTexture(th)

    local scrollOff = 0

    local function DoUpdate()
        local clipH    = clip:GetHeight()    or 1
        local contentH = content:GetHeight() or 1
        local maxOff   = math.max(0, contentH-clipH)
        scrollOff      = math.min(scrollOff, maxOff)
        content:SetPoint("TOPLEFT", 0, scrollOff)
        if maxOff <= 0 then bar:Hide(); return end
        bar:Show()
        bar:SetMinMaxValues(0, maxOff)
        bar:SetValue(maxOff-scrollOff)
    end

    bar:SetScript("OnValueChanged", function(self, val)
        local _, mx = self:GetMinMaxValues()
        scrollOff = math.max(0, mx-val)
        content:SetPoint("TOPLEFT", 0, scrollOff)
    end)

    clip:EnableMouseWheel(true)
    clip:SetScript("OnMouseWheel", function(_, d)
        local clipH    = clip:GetHeight()    or 1
        local contentH = content:GetHeight() or 1
        local maxOff   = math.max(0, contentH-clipH)
        scrollOff = math.max(0, math.min(maxOff, scrollOff-d*22))
        content:SetPoint("TOPLEFT", 0, scrollOff)
        local _, mx = bar:GetMinMaxValues()
        if mx > 0 then bar:SetValue(mx-scrollOff) end
    end)

    return { content=content, clip=clip, bar=bar, Update=DoUpdate }
end

-------------------------------------------------------------------------------
-- Session name + note: one small editor shared by current and saved sessions.
-- Uses the existing regular UI widget helpers; never touches earned stats.
-------------------------------------------------------------------------------
GDS_SessionMeta = GDS_SessionMeta or {}
function GDS_SessionMeta.Trim(value, limit)
    if type(value) ~= "string" then return "" end
    value = value:gsub("\r", ""):gsub("^%s+", ""):gsub("%s+$", "")
    return value:sub(1, limit or 1000)
end
function GDS_SessionMeta.RefreshBadge()
    if not mainFrame or not mainFrame.metaBtn or not mainFrame.metaBtn.label then return end
    local hasText = S and ((S.sessionName and S.sessionName ~= "")
        or (S.sessionNote and S.sessionNote ~= ""))
    mainFrame.metaBtn.label:SetText(hasText and "N*" or "N")
end
function GDS_SessionMeta.Open(target)
    if type(target) ~= "table" then return end
    local f = GDS_SessionMeta.frame
    if not f then
        f = CreateFrame("Frame", "GTSessionNoteFrame", UIParent,
            BackdropTemplateMixin and "BackdropTemplate" or nil)
        GDS_FocusWindow(f)
        f:SetSize(370, 256)
        f:SetPoint("CENTER", UIParent, "CENTER", 0, 90)
        f:SetFrameStrata("DIALOG")
        f:EnableMouse(true)
        f:SetMovable(true)
        f:RegisterForDrag("LeftButton")
        f:SetClampedToScreen(true)
        f:SetScript("OnDragStart", f.StartMoving)
        f:SetScript("OnDragStop", f.StopMovingOrSizing)
        ApplyBackdrop(f)

        local heading = f:CreateFontString(nil,"OVERLAY","GameFontNormalLarge")
        heading:SetPoint("TOPLEFT", 14, -12)
        heading:SetText("Session Details")
        local x = MakeBtn(f, 22, 22, "X")
        x:SetPoint("TOPRIGHT", -7, -7)
        x:SetScript("OnClick", function() f:Hide() end)
        local nameLabel = f:CreateFontString(nil,"OVERLAY","GameFontHighlightSmall")
        nameLabel:SetPoint("TOPLEFT", 15, -46)
        nameLabel:SetText("Name  (optional)")
        local name = CreateFrame("EditBox", nil, f, "InputBoxTemplate")
        name:SetSize(325, 25)
        name:SetPoint("TOPLEFT", 22, -65)
        name:SetAutoFocus(false)
        name:SetMaxLetters(64)
        name:SetScript("OnEscapePressed", function() f:Hide() end)
        f.nameEdit = name

        local noteLabel = f:CreateFontString(nil,"OVERLAY","GameFontHighlightSmall")
        noteLabel:SetPoint("TOPLEFT", 15, -102)
        noteLabel:SetText("Note  (optional)")
        local panel = CreateFrame("Frame", nil, f)
        panel:SetPoint("TOPLEFT", 14, -119)
        panel:SetSize(341, 84)
        local panelBg = panel:CreateTexture(nil,"BACKGROUND")
        panelBg:SetAllPoints()
        panelBg:SetColorTexture(.04,.045,.055,.92)
        local scroll = CreateFrame("ScrollFrame", nil, panel)
        scroll:SetPoint("TOPLEFT", 7, -5)
        scroll:SetPoint("BOTTOMRIGHT", -7, 5)
        local note = CreateFrame("EditBox", nil, scroll)
        note:SetMultiLine(true)
        note:SetAutoFocus(false)
        note:SetFontObject("ChatFontNormal")
        note:SetWidth(318)
        note:SetHeight(75)
        note:SetMaxLetters(1000) -- expanded to preserve longer combined notes when editing
        note:SetScript("OnEscapePressed", function() f:Hide() end)
        note:SetScript("OnTextChanged", function(self)
            if self.GetStringHeight then
                self:SetHeight(math.max(75, self:GetStringHeight()+12))
            end
            if scroll.UpdateScrollChildRect then scroll:UpdateScrollChildRect() end
        end)
        note:SetScript("OnCursorChanged", function(self, _, y, _, h)
            local top = math.max(0, -y)
            local bottom = top + math.max(0,h or 0)
            local current = scroll:GetVerticalScroll() or 0
            local visible = scroll:GetHeight() or 70
            if top < current then scroll:SetVerticalScroll(top)
            elseif bottom > current + visible then
                scroll:SetVerticalScroll(math.max(0,bottom-visible))
            end
        end)
        scroll:SetScrollChild(note)
        scroll:EnableMouseWheel(true)
        scroll:SetScript("OnMouseWheel", function(self, delta)
            local maxScroll = math.max(0, (note:GetHeight() or 75) - self:GetHeight())
            self:SetVerticalScroll(math.max(0, math.min(maxScroll,
                (self:GetVerticalScroll() or 0) - delta * 28)))
        end)
        f.noteEdit = note
        local hint = f:CreateFontString(nil,"OVERLAY","GameFontHighlightSmall")
        hint:SetPoint("BOTTOMLEFT", 16, 43)
        hint:SetText("Saved with the session; does not affect tracking.")
        hint:SetTextColor(.68,.72,.75)

        local cancel = MakeBtn(f, 76, 24, "Cancel")
        cancel:SetPoint("BOTTOMRIGHT", -100, 11)
        cancel:SetScript("OnClick", function() f:Hide() end)
        local save = MakeBtn(f, 78, 24, "Save")
        save:SetPoint("BOTTOMRIGHT", -11, 11)
        save:SetScript("OnClick", function()
            local entry = f.target
            if type(entry) ~= "table" then f:Hide(); return end
            -- Guard against editing a stale live-session table after a reset.
            if f.editingCurrent and entry ~= S then f:Hide(); return end
            entry.sessionName = GDS_SessionMeta.Trim(f.nameEdit:GetText(),64)
            entry.sessionNote = GDS_SessionMeta.Trim(f.noteEdit:GetText(),10000)
            f:Hide()
            GDS_SessionMeta.RefreshBadge()
            if historyFrame and historyFrame:IsShown() then RefreshHistory() end
        end)
        f.saveBtn = save
        f:SetScript("OnHide", function(self)
            self.target = nil
            self.editingCurrent = nil
            self.nameEdit:ClearFocus()
            self.noteEdit:ClearFocus()
        end)
        f:Hide()
        GDS_SessionMeta.frame = f
    end
    f.target = target
    f.editingCurrent = target == S
    f.nameEdit:SetText(target.sessionName or "")
    f.noteEdit:SetMaxLetters(math.max(1000, #(target.sessionNote or "")))
    f.noteEdit:SetText(target.sessionNote or "")
    f.noteEdit:SetCursorPosition(0)
    local p = f.noteEdit:GetParent()
    if p and p.SetVerticalScroll then p:SetVerticalScroll(0) end
    f:Show()
    f.nameEdit:SetFocus()
end

-------------------------------------------------------------------------------
-- Header panel switcher: one secondary workspace panel at a time.
-- Keep the main tracker, optional mini HUDs, and standalone name/note editor
-- untouched. Only a user opening a different header panel closes siblings.
-- Named WoW frames are resolved at click-time so lazily-created tabs work.
-- A global namespace avoids Lua's local-variable limit in this large file.
-------------------------------------------------------------------------------
GDS_TabSwitcher = GDS_TabSwitcher or {}
function GDS_TabSwitcher.CloseOthers(keepName)
    for _, name in ipairs({
        "GTLootFrame", "GTHistoryFrame", "GTSettingsFrame", "GTSkinsFrame",
        "GTGphGraphFrame", "GTPartyStatsFrame",
        -- Historical detail panels are children of the History workflow.
        "GTSessionComparisonFrame", "GTComparisonGraphsFrame", "GTPastAnalyticsFrame",
    }) do
        if name ~= keepName then
            local panel = _G[name]
            if panel and panel.IsShown and panel:IsShown() then
                panel:Hide()
            end
        end
    end
end

-------------------------------------------------------------------------------
-- HISTORY WINDOW
-------------------------------------------------------------------------------
local function SetHistoryTab(tab)
    if tab ~= "sessions" and tab ~= "dungeons" and tab ~= "logins" then return end
    if tab == "logins" then comparisonPicking, comparisonA = nil, nil end
    historyActiveTab = tab
    if historyFrame then
        historyFrame.combineSelected = {}
        historyFrame.pendingCombine = nil
        historyFrame.pendingSessionDelete = nil
        historyFrame.pendingDungeonDelete = nil
        if historyFrame.confirmBar then historyFrame.confirmBar:Hide() end
        if historyFrame.clearBtn then historyFrame.clearBtn:Show() end
    end
    if historyFrame and historyFrame:IsShown() then RefreshHistory() end
end

local function ToggleHistory(requestedTab)
    if requestedTab == "logins" then
        if historyFrame and historyFrame.loginPanel then historyFrame.loginPanel:Hide() end
        SetHistoryTab(requestedTab)
        if historyFrame and historyFrame:IsShown() then historyFrame:Raise(); return end
    end
    if historyFrame and historyFrame:IsShown() then
        historyFrame.combineSelected = {}
        historyFrame.pendingCombine = nil
        historyFrame.pendingSessionDelete = nil
        historyFrame.pendingDungeonDelete = nil
        if historyFrame.confirmBar then historyFrame.confirmBar:Hide() end
        if historyFrame.clearBtn then historyFrame.clearBtn:Show() end
        historyFrame:Hide(); return
    end
    GDS_TabSwitcher.CloseOthers("GTHistoryFrame")
    if not historyFrame then
        historyFrame = CreateFrame("Frame", "GTHistoryFrame", UIParent,
            BackdropTemplateMixin and "BackdropTemplate")
        GDS_FocusWindow(historyFrame)
        historyFrame:SetSize(380, 400)
        historyFrame:SetPoint("TOPLEFT", mainFrame, "TOPRIGHT", 6, 0)
        historyFrame:SetFrameStrata("DIALOG")
        historyFrame:EnableMouse(true); historyFrame:SetMovable(true)
        historyFrame:SetClampedToScreen(true); historyFrame:RegisterForDrag("LeftButton")
        ApplyBackdrop(historyFrame)
        -- Hiding History from a different header tab must cancel any pending
        -- destructive confirmation, just like clicking its own close button.
        historyFrame:SetScript("OnHide", function(self)
            if self.loginPanel then self.loginPanel:Hide() end
            self.combineSelected = {}
            self.pendingCombine = nil
            self.pendingSessionDelete = nil
            self.pendingDungeonDelete = nil
            if self.confirmBar then self.confirmBar:Hide() end
            if self.clearBtn then self.clearBtn:Show() end
        end)

        local header = CreateFrame("Frame", nil, historyFrame)
        header:SetPoint("TOPLEFT", 4, -4)
        header:SetPoint("TOPRIGHT", -4, -4)
        header:SetHeight(28)
        local headerBg = header:CreateTexture(nil, "BACKGROUND")
        headerBg:SetAllPoints()
        local _hb = DB and DB.theme
        headerBg:SetColorTexture(_hb and _hb.headerR or 0.045, _hb and _hb.headerG or 0.06, _hb and _hb.headerB or 0.078, _hb and _hb.headerA or 0.84)
        table.insert(GT_headers, headerBg)
        local headerRule = header:CreateTexture(nil, "BORDER")
        headerRule:SetPoint("BOTTOMLEFT")
        headerRule:SetPoint("BOTTOMRIGHT")
        headerRule:SetHeight(1)
        local _hr = DB and DB.theme
        headerRule:SetColorTexture(_hr and _hr.borderR or 0.22, _hr and _hr.borderG or 0.31, _hr and _hr.borderB or 0.40, 0.72)
        table.insert(GT_dividers, headerRule)
        table.insert(GT_headerRules, headerRule)

        local ttl = header:CreateFontString(nil,"OVERLAY","GameFontNormalLarge")
        ttl:SetPoint("TOP",0,-6); ttl:SetText("History")
        local _tt = DB and DB.theme
        ttl:SetTextColor(_tt and _tt.accentR or 0.88, _tt and _tt.accentG or 0.92, _tt and _tt.accentB or 0.96)
        table.insert(GT_titles, ttl)

        local xb = MakeBtn(historyFrame, 20, 20, "X")
        xb:SetPoint("TOPRIGHT",-4,-4)
        xb:SetScript("OnClick", function()
            historyFrame.combineSelected = {}
            historyFrame.pendingCombine = nil
            historyFrame:Hide()
        end)

        local tabY = -34
        local previous
        for _, entry in ipairs({{"sessions","Grind Sessions"},{"dungeons","Dungeons"},{"logins","Login Sessions"}}) do
            local tab = entry[1]
            local btn = MakeBtn(historyFrame,118,22,entry[2])
            if previous then btn:SetPoint("LEFT",previous,"RIGHT",5,0)
            else btn:SetPoint("TOPLEFT",8,tabY) end
            btn._gtTab = tab
            SetupHistoryTabButton(btn)
            btn:SetScript("OnClick", function() SetHistoryTab(tab) end)
            historyTabBtns[tab] = btn
            previous = btn
        end

        local content = CreateFrame("Frame",nil,historyFrame)
        content:SetAllPoints()
        historyFrame.standardContent = content
        -- Column headers
        local hdrFrame = CreateFrame("Frame", nil, content)
        hdrFrame:SetPoint("TOPLEFT", 8, -62)
        hdrFrame:SetPoint("TOPRIGHT", -8, -62)
        hdrFrame:SetHeight(18)
        local function HCol(txt, side, off, w, j, sortKey)
            local btn = CreateFrame("Button", nil, hdrFrame)
            btn:SetHeight(18)
            if w then btn:SetWidth(w) end
            btn:SetPoint(side, hdrFrame, side, off, 0)
            local bg = btn:CreateTexture(nil, "BACKGROUND")
            bg:SetAllPoints(); bg:SetColorTexture(0,0,0,0); btn._bg = bg
            local fs = btn:CreateFontString(nil,"OVERLAY","GameFontNormalSmall")
            fs:SetAllPoints(); fs:SetJustifyH(j or "LEFT"); fs:SetJustifyV("MIDDLE")
            TrackThemeText(fs); btn._fs = fs; btn._sortKey = sortKey
            local function upd()
                if historySortCol == sortKey then
                    fs:SetText(txt .. (historySortDir == "desc" and " ^" or " v"))
                else
                    fs:SetText(txt)
                end
            end
            btn._updateLabel = upd; upd()
            btn:SetScript("OnEnter", function() bg:SetColorTexture(1,1,1,0.08) end)
            btn:SetScript("OnLeave", function() bg:SetColorTexture(0,0,0,0) end)
            btn:SetScript("OnClick", function()
                if historySortCol == sortKey then
                    historySortDir = historySortDir == "desc" and "asc" or "desc"
                else
                    historySortCol = sortKey; historySortDir = "desc"
                end
                RefreshHistory()
            end)
            return btn
        end
        historyFrame.sessionHeaders = {
            HCol("Ended / Name", "LEFT", 0, 166, "LEFT",  "date"),
            HCol("Duration", "LEFT", 170,  64, "LEFT",  "duration"),
            HCol("Gold", "RIGHT", 0, 105, "RIGHT", "gold"),
        }
        -- Passive headings: rows are sorted by total earnings.
        historyFrame.dungeonHeaders = {}
        local function DungeonHeading(text, x, width, justify)
            local fs = hdrFrame:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
            fs:SetPoint("LEFT", hdrFrame, "LEFT", x, 0)
            fs:SetWidth(width)
            fs:SetJustifyH(justify or "LEFT")
            TrackThemeText(fs)
            fs:SetText(text)
            table.insert(historyFrame.dungeonHeaders, fs)
        end
        DungeonHeading("Dungeon", 0, 139, "LEFT")
        DungeonHeading("Runs", 141, 38, "RIGHT")
        DungeonHeading("Total", 184, 76, "RIGHT")
        DungeonHeading("Avg / run", 263, 94, "RIGHT")

        local div = content:CreateTexture(nil,"BACKGROUND")
        div:SetPoint("TOPLEFT", 8, -80); div:SetPoint("TOPRIGHT", -8, -80)
        div:SetHeight(1)
        local _dt = DB and DB.theme
        div:SetColorTexture(_dt and _dt.borderR or 0.22, _dt and _dt.borderG or 0.31, _dt and _dt.borderB or 0.40, 0.72)
        table.insert(GT_dividers, div)

        -- Scroll area (leaves 68px at bottom for footer)
        local scrollClip = CreateFrame("Frame", nil, content)
        scrollClip:SetPoint("TOPLEFT", 8, -82)
        scrollClip:SetPoint("BOTTOMRIGHT", -16, 68)
        scrollClip:SetClipsChildren(true)

        local scrollContent = CreateFrame("Frame", nil, scrollClip)
        scrollContent:SetWidth(380-24); scrollContent:SetHeight(1)
        scrollContent:SetPoint("TOPLEFT")

        local scrollBar = CreateFrame("Slider", nil, content)
        scrollBar:SetOrientation("VERTICAL")
        scrollBar:SetPoint("TOPRIGHT", -3, -82)
        scrollBar:SetPoint("BOTTOMRIGHT", -3, 68)
        scrollBar:SetWidth(7)
        scrollBar:SetMinMaxValues(0,1); scrollBar:SetValue(0)
        local sbt = scrollBar:CreateTexture(nil,"BACKGROUND")
        sbt:SetAllPoints(); sbt:SetColorTexture(0.035,0.045,0.060,0.80)
        local sth = scrollBar:CreateTexture(nil,"OVERLAY")
        local _st = DB and DB.theme
        sth:SetSize(5,28)
        sth:SetColorTexture(_st and _st.borderR or 0.22, _st and _st.borderG or 0.31, _st and _st.borderB or 0.40, .9)
        table.insert(GT_thumbs, sth)
        scrollBar:SetThumbTexture(sth)

        local scrollOff = 0
        local function DoScrollUpdate()
            local clipH    = scrollClip:GetHeight() or 1
            local contentH = scrollContent:GetHeight() or 1
            local maxOff   = math.max(0, contentH-clipH)
            scrollOff      = math.min(scrollOff, maxOff)
            scrollContent:SetPoint("TOPLEFT", 0, scrollOff)
            if maxOff <= 0 then scrollBar:Hide(); return end
            scrollBar:Show()
            scrollBar:SetMinMaxValues(0, maxOff)
            scrollBar:SetValue(maxOff-scrollOff)
        end
        scrollBar:SetScript("OnValueChanged", function(self, val)
            local _, mx = self:GetMinMaxValues()
            scrollOff = math.max(0, mx-val)
            scrollContent:SetPoint("TOPLEFT", 0, scrollOff)
        end)
        scrollClip:EnableMouseWheel(true)
        scrollClip:SetScript("OnMouseWheel", function(_, d)
            local clipH    = scrollClip:GetHeight() or 1
            local contentH = scrollContent:GetHeight() or 1
            local maxOff   = math.max(0, contentH-clipH)
            scrollOff = math.max(0, math.min(maxOff, scrollOff-d*22))
            scrollContent:SetPoint("TOPLEFT", 0, scrollOff)
            local _, mx = scrollBar:GetMinMaxValues()
            if mx > 0 then scrollBar:SetValue(mx-scrollOff) end
        end)
        historyScroll = { content=scrollContent, clip=scrollClip,
                          bar=scrollBar, Update=DoScrollUpdate }

        -- "No data" placeholder shown when history is empty
        local noMsg = content:CreateFontString(nil,"OVERLAY","GameFontNormalSmall")
        noMsg:SetPoint("CENTER", 0, 20)
        TrackThemeText(noMsg)
        noMsg:SetText("No sessions recorded yet.\nClick 'End Session' to save a session.")
        noMsg:SetJustifyH("CENTER")
        historyFrame.noDataMsg = noMsg

        -- Footer divider
        local fdiv = content:CreateTexture(nil,"BACKGROUND")
        fdiv:SetPoint("BOTTOMLEFT", 8, 65); fdiv:SetPoint("BOTTOMRIGHT", -8, 65)
        fdiv:SetHeight(1)
        local _ft = DB and DB.theme
        fdiv:SetColorTexture(_ft and _ft.borderR or 0.22, _ft and _ft.borderG or 0.31, _ft and _ft.borderB or 0.40, 0.72)
        table.insert(GT_dividers, fdiv)

        -- Footer: 4 evenly-spaced labelled stat cells
        local function MakeFootStat(xOff)
            local fs = content:CreateFontString(nil,"OVERLAY","GameFontNormalSmall")
            fs:SetPoint("BOTTOMLEFT", xOff, 42)
            fs:SetWidth(91)
            fs:SetJustifyH("CENTER")
            TrackThemeText(fs)
            fs:SetText("")
            return fs
        end
        historyFrame.footerSessions = MakeFootStat(8)
        historyFrame.footerTime     = MakeFootStat(99)
        historyFrame.footerKills    = MakeFootStat(190)
        historyFrame.footerGold     = MakeFootStat(281)

        -- Clear button
        -- Forward-declare so the confirmBar closures can reference it
        local clearBtn

        -- Confirmation bar: hidden by default, shown after clicking Clear History
        local confirmBar = CreateFrame("Frame", nil, content)
        confirmBar:SetPoint("BOTTOMLEFT", 8, 8)
        confirmBar:SetPoint("BOTTOMRIGHT", -8, 8)
        confirmBar:SetHeight(26)
        confirmBar:Hide()

        local confirmLabel = confirmBar:CreateFontString(nil,"OVERLAY","GameFontNormalSmall")
        confirmLabel:SetPoint("LEFT", 0, 0)
        confirmLabel:SetText("|cFFFF4444Are you sure?|r")
        historyFrame.confirmLabel = confirmLabel

        local yesBtn = MakeBtn(confirmBar, 54, 22, "Yes")
        yesBtn:SetPoint("RIGHT", confirmBar, "RIGHT", 0, 0)
        yesBtn:SetScript("OnClick", function()
            local combine = historyFrame.pendingCombine
            historyFrame.pendingCombine = nil
            if combine then
                local dungeonMerge = historyActiveTab=="dungeons"
                local ok
                if dungeonMerge then ok=GDS_Dungeon.CombineRuns(combine)
                else ok=GDS_HistoryMerge.Apply(combine[1], combine[2]) end
                if ok then
                    historyFrame.combineSelected = {}
                    comparisonPicking, comparisonA = nil, nil
                    if comparisonFrame then comparisonFrame:Hide() end
                    if comparisonGraphsFrame then comparisonGraphsFrame:Hide() end
                    DEFAULT_CHAT_FRAME:AddMessage("|cFFD8DDE6Grind Dont Stop|r Selected records combined into one saved record.")
                else
                    UIErrorsFrame:AddMessage("Grind Don't Stop: Could not combine these saved records.")
                end
                historyFrame.pendingSessionDelete = nil
                historyFrame.pendingDungeonDelete = nil
                confirmBar:Hide()
                clearBtn:Show()
                RefreshHistory()
                return
            end
            local selected = historyFrame.pendingSessionDelete
            local dungeonSelected = historyFrame.pendingDungeonDelete
            historyFrame.pendingSessionDelete = nil
            historyFrame.pendingDungeonDelete = nil
            historyFrame.combineSelected = {}
            if dungeonSelected then
                GDS_Dungeon.DeleteHistoryRun(dungeonSelected)
            elseif selected and DB and type(DB.sessions) == "table" then
                -- Delete exactly the selected saved entry, even when two
                -- sessions have the same date or matching gold totals.
                for index, session in ipairs(DB.sessions) do
                    if session == selected then
                        table.remove(DB.sessions, index)
                        break
                    end
                end
                comparisonPicking, comparisonA = nil, nil
                if comparisonFrame then comparisonFrame:Hide() end
                if comparisonGraphsFrame then comparisonGraphsFrame:Hide() end
            elseif DB then
                if historyActiveTab == "sessions" and DB.sessions then
                    wipe(DB.sessions)
                    comparisonPicking, comparisonA = nil, nil
                    if comparisonFrame then comparisonFrame:Hide() end
                    if comparisonGraphsFrame then comparisonGraphsFrame:Hide() end
                elseif historyActiveTab == "dungeons" and DB.dungeonRuns then
                    wipe(DB.dungeonRuns)
                    GDS_LiveDungeon.historySummary = nil
                    DB.dungeonUndo = nil -- Clear Dungeons intentionally cannot be undone
                end
            end
            confirmBar:Hide()
            clearBtn:Show()
            RefreshHistory()
        end)

        local noBtn = MakeBtn(confirmBar, 54, 22, "No")
        noBtn:SetPoint("RIGHT", yesBtn, "LEFT", -4, 0)
        noBtn:SetScript("OnClick", function()
            historyFrame.pendingCombine = nil
            historyFrame.pendingSessionDelete = nil
            historyFrame.pendingDungeonDelete = nil
            confirmBar:Hide()
            clearBtn:Show()
            if historyFrame.compareBtn then RefreshHistory() end
        end)

        clearBtn = MakeBtn(content, 120, 26, "Clear History")
        clearBtn:SetPoint("BOTTOMRIGHT", -8, 8)
        clearBtn:SetScript("OnClick", function()
            -- Ordinary Clear History continues to clear the full tab; it
            -- cannot inherit an earlier single-session deletion target.
            historyFrame.pendingSessionDelete = nil
            historyFrame.pendingDungeonDelete = nil
            historyFrame.pendingCombine = nil
            historyFrame.confirmLabel:SetText(historyActiveTab == "sessions"
                and "|cFFFF4444Clear all saved sessions?|r"
                or "|cFFFF4444Clear all dungeon runs?|r")
            clearBtn:Hide()
            historyFrame.compareBtn:Hide()
            if historyFrame.combineBtn then historyFrame.combineBtn:Hide() end
            historyFrame.compareHint:Hide()
            confirmBar:Show()
            if historyFrame.csvBtn then historyFrame.csvBtn:Hide() end
            if historyFrame.restoreDungeonBtn then historyFrame.restoreDungeonBtn:Hide() end
        end)
        historyFrame.clearBtn = clearBtn
        historyFrame.confirmBar = confirmBar

        -- Reuses the left footer slot occupied by Compare Runs on Sessions.
        -- Shown only on Dungeons, so it adds no permanent button clutter.
        local dungeonCsvBtn = MakeBtn(content, 46, 26, "CSV")
        dungeonCsvBtn:SetPoint("BOTTOMLEFT", 8, 8)
        dungeonCsvBtn:SetScript("OnClick", function() GDS_Dungeon.ExportCSV() end)
        dungeonCsvBtn:SetScript("OnEnter", function(self)
            GameTooltip:SetOwner(self, "ANCHOR_TOP")
            GameTooltip:SetText("Export Dungeon History")
            GameTooltip:AddLine("Copies individual dungeon runs as CSV, including repairs and durations. Paste into Excel.", .8, .8, .8, true)
            GameTooltip:Show()
        end)
        dungeonCsvBtn:SetScript("OnLeave", function() GameTooltip:Hide() end)
        historyFrame.csvBtn = dungeonCsvBtn

        -- Visible only after a confirmed single-run deletion. The CSV button
        -- remains in its original position; there is no permanent extra control.
        local restoreBtn = MakeBtn(content, 74, 26, "Restore")
        restoreBtn:SetPoint("LEFT", dungeonCsvBtn, "RIGHT", 5, 0)
        restoreBtn:SetScript("OnClick", function()
            if GDS_Dungeon.RestoreDeletedRun() then
                DEFAULT_CHAT_FRAME:AddMessage("|cFFD8DDE6Grind Dont Stop|r Last deleted dungeon run restored.")
            end
            RefreshHistory()
        end)
        restoreBtn:SetScript("OnEnter", function(self)
            GameTooltip:SetOwner(self, "ANCHOR_TOP")
            GameTooltip:SetText("Restore last deleted dungeon run")
            GameTooltip:AddLine("Restores its original duration, coin, item value and dungeon wing.", .8,.8,.8,true)
            GameTooltip:AddLine("Only the most recent deleted run is available.", .7,.8,.9,true)
            GameTooltip:Show()
        end)
        restoreBtn:SetScript("OnLeave", function() GameTooltip:Hide() end)
        historyFrame.restoreDungeonBtn = restoreBtn
        restoreBtn:Hide()

        local compareBtn = MakeBtn(content, 118, 26, "Compare Runs")
        compareBtn:SetPoint("BOTTOMLEFT", 8, 8)
        compareBtn:SetScript("OnClick", function()
            if #(DB.sessions or {}) < 2 then return end
            comparisonPicking = not comparisonPicking
            comparisonA = nil
            if comparisonPicking then historyFrame.combineSelected = {} end
            RefreshHistory()
        end)
        historyFrame.compareBtn = compareBtn

        -- Middle footer button: only enabled for two Shift+Right-click selections.
        local combineBtn = MakeBtn(content, 104, 26, "Combine")
        combineBtn:SetPoint("BOTTOMLEFT", 134, 8)
        combineBtn:SetScript("OnClick", function()
            if not DB then return end
            local dungeonMerge=historyActiveTab=="dungeons"
            local chosen = {}
            local selectMap = historyFrame.combineSelected or {}
            for _, session in ipairs((dungeonMerge and DB.dungeonRuns or DB.sessions) or {}) do
                if selectMap[session] then chosen[#chosen+1] = session end
            end
            if (dungeonMerge and #chosen<2) or (not dungeonMerge and #chosen~=2) then return end
            historyFrame.pendingCombine = chosen
            historyFrame.pendingSessionDelete = nil
            historyFrame.pendingDungeonDelete = nil
            historyFrame.confirmLabel:SetText(dungeonMerge and ("|cFFFFD27DCombine "..#chosen.." runs into 1?|r") or "|cFFFFD27DCombine 2 sessions into 1?|r")
            if historyFrame.csvBtn then historyFrame.csvBtn:Hide() end
            if historyFrame.restoreDungeonBtn then historyFrame.restoreDungeonBtn:Hide() end
            historyFrame.clearBtn:Hide()
            historyFrame.compareBtn:Hide()
            combineBtn:Hide()
            historyFrame.compareHint:Hide()
            historyFrame.confirmBar:Show()
        end)
        combineBtn:SetScript("OnEnter", function(self)
            GameTooltip:SetOwner(self, "ANCHOR_TOP")
            if historyActiveTab=="dungeons" then
                GameTooltip:SetText("Combine dungeon runs")
                GameTooltip:AddLine("Shift + Right-click two or more runs of the same dungeon, then Combine.",1,1,1,true)
                GameTooltip:AddLine("Alt + Right-click a combined run to undo.",.8,.8,.8,true)
                GameTooltip:Show(); return
            end
            GameTooltip:SetText("Combine saved sessions")
            GameTooltip:AddLine("Shift + Right-click exactly two session rows, then Combine.", 1, 1, 1, true)
            GameTooltip:AddLine("Sums their totals and joins chart history. Dungeon records are unchanged.", .75, .86, .8, true)
            GameTooltip:Show()
        end)
        combineBtn:SetScript("OnLeave", function() GameTooltip:Hide() end)
        historyFrame.combineBtn = combineBtn
        local compareHint = content:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
        compareHint:SetPoint("BOTTOM", 0, 46)
        compareHint:SetWidth(360)
        TrackThemeText(compareHint)
        historyFrame.compareHint = compareHint

        historyFrame:SetScript("OnDragStart", historyFrame.StartMoving)
        historyFrame:SetScript("OnDragStop", function(self) self:StopMovingOrSizing() end)
    end
    ApplyVisibility()
    RefreshHistory()
    historyFrame:Show()
end

-------------------------------------------------------------------------------
-- SETTINGS PANEL
-------------------------------------------------------------------------------
function GDS_TabSwitcher.ToggleMain()
    if not mainFrame then return end
    if mainFrame:IsShown() then
        mainFrame:Hide()
    else
        if miniBar then miniBar:Hide() end
        if GDS_XPMiniBar then GDS_XPMiniBar:Hide() end
        mainFrame:Show()
        mainFrame:Raise()
    end
end

function GDS_TabSwitcher.UpdateEdgeButton()
    local button = GDS_TabSwitcher.edgeButton
    if not DB.leftEdgeButton then
        if button then button:Hide() end
        return
    end
    if not button then
        button = CreateFrame("Button", nil, UIParent)
        GDS_TabSwitcher.edgeButton = button
        button:SetSize(15, 30)
        button:SetFrameStrata("MEDIUM")
        button:SetClampedToScreen(true)
        button:RegisterForDrag("LeftButton")
        button:RegisterForClicks("LeftButtonUp", "RightButtonUp")
        local bg = button:CreateTexture(nil, "BACKGROUND")
        bg:SetAllPoints()
        bg:SetColorTexture(.07, .05, .03, .94)
        local edge = button:CreateTexture(nil, "ARTWORK")
        edge:SetPoint("TOPRIGHT")
        edge:SetPoint("BOTTOMRIGHT")
        edge:SetWidth(2)
        edge:SetColorTexture(.78, .59, .23, .95)
        local label = button:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
        label:SetPoint("CENTER", -1, 0)
        local function expand(open)
            button.expanded = open
            local caption = DB.leftEdgeUseG and "G" or ">"
            local width = 15
            if open then
                caption, width = "GrindTracker", 94
            elseif S and S.running then
                caption = FormatTime(S.timer)
                width = 64
            end
            if caption ~= button.caption then
                label:SetText(caption)
                button.caption = caption
            end
            if button:GetWidth() ~= width then button:SetWidth(width) end
        end
        local function place(y)
            local height = UIParent:GetHeight()
            if height <= 0 then return end
            local half = button:GetHeight() / 2
            y = math.max(half, math.min(height - half, y))
            button:ClearAllPoints()
            button:SetPoint("LEFT", UIParent, "BOTTOMLEFT", 0, y)
            return y / height
        end
        function button:RestoreHeight()
            place((tonumber(DB.leftEdgeHeight) or .5) * UIParent:GetHeight())
        end
        local function cursorY()
            local _, y = GetCursorPosition()
            return y / UIParent:GetEffectiveScale()
        end
        local function drag(self)
            DB.leftEdgeHeight = place(cursorY() - self.grabOffset)
        end
        button:SetScript("OnEnter", function() expand(true) end)
        button:SetScript("OnLeave", function(self) if not self.dragging then expand(false) end end)
        button:SetScript("OnMouseDown", function(self)
            self.suppressClick = false
            self.grabOffset = cursorY() - select(2, self:GetCenter())
        end)
        button:SetScript("OnDragStart", function(self)
            self.dragging, self.suppressClick = true, true
            self:SetScript("OnUpdate", drag)
        end)
        button:SetScript("OnDragStop", function(self)
            drag(self)
            self.dragging = false
            self:SetScript("OnUpdate", nil)
            expand(self:IsMouseOver())
        end)
        button:SetScript("OnClick", function(self, mouseButton)
            if self.suppressClick then return end
            if mouseButton == "RightButton" then
                if addonReady then BeginSession() end
            else
                GDS_TabSwitcher.ToggleMain()
            end
        end)
        button:SetScript("OnHide", function(self)
            self.dragging = false
            self:SetScript("OnUpdate", nil)
            expand(false)
        end)
        UIParent:HookScript("OnSizeChanged", function()
            if button:IsShown() and not button.dragging then button:RestoreHeight() end
        end)
        button.UpdateExpansion = expand
    end
    button.UpdateExpansion(button:IsShown() and button:IsMouseOver())
    button:RestoreHeight()
    button:Show()
end

function GDS_TabSwitcher.ToggleEdgeSettings(anchor)
    local panel = GDS_TabSwitcher.edgeSettings
    if not panel then
        panel = CreateFrame("Frame", nil, settingsFrame, BackdropTemplateMixin and "BackdropTemplate")
        GDS_TabSwitcher.edgeSettings = panel
        panel:SetSize(208, 78)
        panel:SetPoint("TOPLEFT", anchor, "BOTTOMLEFT", 0, -3)
        panel:SetClampedToScreen(true)
        panel:SetFrameLevel(anchor:GetFrameLevel() + 15)
        panel:EnableMouse(true)
        ApplyBackdrop(panel)
        local title = panel:CreateFontString(nil, "OVERLAY", "GameFontNormal")
        title:SetPoint("TOPLEFT", 10, -10)
        title:SetText("Left-edge launcher")
        local close = MakeBtn(panel, 20, 18, "X")
        close:SetPoint("TOPRIGHT", -5, -5)
        close:SetScript("OnClick", function() panel:Hide() end)
        local choice = CreateFrame("CheckButton", nil, panel, "UICheckButtonTemplate")
        choice:SetSize(24, 24)
        choice:SetPoint("TOPLEFT", 8, -35)
        local label = choice:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
        label:SetPoint("LEFT", choice, "RIGHT", 2, 0)
        label:SetText("Use G instead of arrow")
        choice:SetHitRectInsets(0, -label:GetStringWidth()-3, 0, 0)
        choice:SetScript("OnClick", function(self)
            DB.leftEdgeUseG = GDS_CheckboxChecked(self)
            GDS_TabSwitcher.UpdateEdgeButton()
        end)
        panel:SetScript("OnShow", function() choice:SetChecked(DB.leftEdgeUseG == true) end)
        settingsFrame:HookScript("OnHide", function() panel:Hide() end)
        panel:Hide()
    end
    panel:SetShown(not panel:IsShown())
end

local function ToggleSettings(partyOnly)
    if not partyOnly and settingsFrame and settingsFrame:IsShown() then
        settingsFrame:Hide(); return
    end
    GDS_TabSwitcher.CloseOthers(partyOnly and "GTPartyStatsFrame" or "GTSettingsFrame")
    if not settingsFrame then
        settingsFrame = CreateFrame("Frame", "GTSettingsFrame", mainFrame,
            BackdropTemplateMixin and "BackdropTemplate")
        GDS_FocusWindow(settingsFrame)
        settingsFrame:SetSize(198, 190)
        settingsFrame:SetPoint("TOPLEFT", mainFrame, "TOPRIGHT", 6, 0)
        settingsFrame:SetFrameStrata("DIALOG")
        ApplyBackdrop(settingsFrame)
        settingsFrame.showTicks = {}
        -- Collapsible Options are inside Settings; no overlapping tracker panels.
        local optionsPanel = CreateFrame("Frame", "GTSettingsOptionsPanel", settingsFrame,
            BackdropTemplateMixin and "BackdropTemplate" or nil)
        optionsPanel:SetSize(198, _G.EasyFishing and 571 or 527)
        optionsPanel:SetPoint("TOPLEFT", settingsFrame, "TOPLEFT", 0, -64)
        optionsPanel:SetFrameStrata("DIALOG")
        optionsPanel:SetFrameLevel(settingsFrame:GetFrameLevel()+12)
        optionsPanel:EnableMouse(true)
        optionsPanel:Hide()
        ApplyBackdrop(optionsPanel)
        settingsFrame.optionsPanel = optionsPanel

        local header = CreateFrame("Frame", nil, settingsFrame)
        header:SetPoint("TOPLEFT", 4, -4)
        header:SetPoint("TOPRIGHT", -4, -4)
        header:SetHeight(24)
        local headerBg = header:CreateTexture(nil, "BACKGROUND")
        headerBg:SetAllPoints()
        local _hb = DB and DB.theme
        headerBg:SetColorTexture(_hb and _hb.headerR or 0.045, _hb and _hb.headerG or 0.06, _hb and _hb.headerB or 0.078, _hb and _hb.headerA or 0.84)
        table.insert(GT_headers, headerBg)
        local headerRule = header:CreateTexture(nil, "BORDER")
        headerRule:SetPoint("BOTTOMLEFT")
        headerRule:SetPoint("BOTTOMRIGHT")
        headerRule:SetHeight(1)
        local _hr = DB and DB.theme
        headerRule:SetColorTexture(_hr and _hr.borderR or 0.22, _hr and _hr.borderG or 0.31, _hr and _hr.borderB or 0.40, 0.72)
        table.insert(GT_dividers, headerRule)
        table.insert(GT_headerRules, headerRule)

        local ttl = header:CreateFontString(nil,"OVERLAY","GameFontNormal")
        ttl:SetPoint("TOP",0,-6); ttl:SetText("Settings")
        local _st = DB and DB.theme
        ttl:SetTextColor(_st and _st.accentR or 0.88, _st and _st.accentG or 0.92, _st and _st.accentB or 0.96)
        table.insert(GT_titles, ttl)

        local xb = MakeBtn(settingsFrame, 20, 20, "X")
        xb:SetPoint("TOPRIGHT", -4, -4)
        xb:SetScript("OnClick", function() settingsFrame:Hide() end)

        local analytics = MakeBtn(optionsPanel,178,22,"Login Analytics")
        analytics:SetPoint("BOTTOM",0,9)
        analytics:SetScript("OnClick",function() GDS_LoginLog.ExperimentalShow() end)

        local opts = {
            {k="time",l="Session Time"},{k="kills",l="Kills"},{k="kph",l="K/h"},
        }
        if _G.EasyFishing then
            opts[#opts+1] = {k="fish",   l="Fish (EasyFishing)"}
            opts[#opts+1] = {k="fishph", l="Fish/h (EasyFishing)"}
        end
        opts[#opts+1] = {k="xp",    l="XP Earned"}
        opts[#opts+1] = {k="xph",   l="XP Earned/H"}
        opts[#opts+1] = {k="lvlt",  l="Time Until Next Level"}
        opts[#opts+1] = {k="coin",  l="Coin Looted"}
        opts[#opts+1] = {k="items", l="Items Loot Value"}
        opts[#opts+1] = {k="total", l="Total Value"}
        opts[#opts+1] = {k="gph",   l="Gold Per Hour"}
        -- Everything below the checkbox column uses hardcoded Y offsets tuned for
        -- 10 rows; shift them down by the EasyFishing extras (22px each).
        local yo = -8
        for _, opt in ipairs(opts) do
            local row = CreateFrame("Frame", nil, optionsPanel)
            row:SetSize(182,20); row:SetPoint("TOPLEFT",8,yo); yo = yo-22

            local cb = CreateFrame("Button", nil, row)
            cb:SetSize(14,14); cb:SetPoint("LEFT",0,0)
            local cBg = cb:CreateTexture(nil,"BACKGROUND")
            cBg:SetAllPoints(); cBg:SetColorTexture(.12,.12,.12,1)
            local cBd = cb:CreateTexture(nil,"BORDER")
            local _cb = DB and DB.theme
            cBd:SetAllPoints()
            cBd:SetColorTexture(_cb and _cb.borderR or .5, _cb and _cb.borderG or .4, _cb and _cb.borderB or .1, 1)
            table.insert(GT_cbBorders, cBd)
            local cIn = cb:CreateTexture(nil,"ARTWORK")
            cIn:SetPoint("TOPLEFT",1,-1); cIn:SetPoint("BOTTOMRIGHT",-1,1)
            cIn:SetColorTexture(0.035,0.045,0.060,1)
            local cTk = cb:CreateFontString(nil,"OVERLAY","GameFontNormalSmall")
            cTk:SetAllPoints(); TrackThemeText(cTk)
            cTk:SetText(DB.show[opt.k] and "x" or "")
            settingsFrame.showTicks[opt.k] = cTk

            local lbl = row:CreateFontString(nil,"OVERLAY","GameFontHighlightSmall")
            lbl:SetPoint("LEFT",cb,"RIGHT",5,0); TrackThemeText(lbl); lbl:SetText(opt.l)

            local key = opt.k
            cb:SetScript("OnClick", function()
                DB.show[key] = not DB.show[key]
                cTk:SetText(DB.show[key] and "x" or "")
                ApplyVisibility()
                RefreshStats()
            end)
            if key == "fish" or key == "fishph" then
                cb:SetScript("OnEnter", function(self)
                    GameTooltip:SetOwner(self, "ANCHOR_RIGHT")
                    GameTooltip:SetText(opt.l)
                    GameTooltip:AddLine("Shows zero before Start, then tracks catches "
                        .. "during the current Grind Dont Stop session.", .8, .8, .8, true)
                    GameTooltip:Show()
                end)
                cb:SetScript("OnLeave", function() GameTooltip:Hide() end)
            end
        end

        -- Startup behavior now lives beside the main Start button.
        -- The obsolete "Start window hidden" checkbox was removed to avoid
        -- conflicting with the single "Start on Login" setting.

        local function RefreshShowTicks()
            if not settingsFrame.showTicks or not DB or not DB.show then return end
            for key, tick in pairs(settingsFrame.showTicks) do
                tick:SetText(DB.show[key] and "x" or "")
            end
        end
        settingsFrame.RefreshShowTicks = RefreshShowTicks

        local optionsBtn = MakeBtn(settingsFrame, 180, 24, "Options  >")
        optionsBtn:SetPoint("TOPLEFT", 9, -36)
        optionsBtn:SetScript("OnClick", function(self)
            local show = not optionsPanel:IsShown()
            optionsPanel:SetShown(show)
            self.label:SetText(show and "Options  v" or "Options  >")
            if settingsFrame.UpdateLayout then settingsFrame.UpdateLayout() end
            if show and GDS_Repairs then GDS_Repairs.RefreshLabel() end
        end)
        settingsFrame.optionsBtn = optionsBtn

        -- Default pricing source: individual loot-row selections override this.
        local priceBtn = MakeBtn(settingsFrame, 180, 24, "Default: Vendor")
        priceBtn:SetPoint("TOPLEFT", 9, -74)
        local function UpdatePriceLabel()
            priceBtn.label:SetText("Default: " .. ((DB.defaultPriceMode == "auction") and "Auction" or "Vendor"))
        end
        priceBtn:SetScript("OnClick", function()
            DB.defaultPriceMode = (DB.defaultPriceMode == "auction") and "vendor" or "auction"
            UpdatePriceLabel()
            RepriceCurrentLoot()
        end)
        priceBtn:SetScript("OnEnter", function(self)
            GameTooltip:SetOwner(self, "ANCHOR_RIGHT")
            GameTooltip:SetText("Default loot valuation")
            GameTooltip:AddLine("Click to switch Vendor / Auction Companion prices.", .9,.9,.9)
            GameTooltip:AddLine("Left-click item: Vendor / Auction / Disenchant (gear).", .7,.8,.9,true)
            GameTooltip:AddLine("Auction prices fall back to vendor if unavailable.", .7,.8,.9,true)
            GameTooltip:Show()
        end)
        priceBtn:SetScript("OnLeave", function() GameTooltip:Hide() end)
        settingsFrame.UpdatePriceLabel = UpdatePriceLabel
        UpdatePriceLabel()

        -- Multiplayer opt-in: stored independently of visual profiles.
        local edgeCB = CreateFrame("CheckButton", nil, settingsFrame, "UICheckButtonTemplate")
        edgeCB:SetSize(23, 23)
        edgeCB:SetPoint("TOPLEFT", priceBtn, "BOTTOMLEFT", -2, -4)
        local edgeLabel = edgeCB:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
        edgeLabel:SetPoint("LEFT", edgeCB, "RIGHT", 1, 0)
        edgeLabel:SetText("Left menu")
        edgeCB:SetHitRectInsets(0, -edgeLabel:GetStringWidth()-3, 0, 0)
        edgeCB:SetChecked(DB.leftEdgeButton == true)
        edgeCB:SetScript("OnClick", function(self)
            DB.leftEdgeButton = GDS_CheckboxChecked(self)
            GDS_TabSwitcher.UpdateEdgeButton()
        end)
        local edgeOptions = MakeBtn(settingsFrame, 62, 19, "Settings")
        edgeOptions:SetPoint("LEFT", edgeLabel, "RIGHT", 8, 0)
        edgeOptions:SetScript("OnClick", GDS_TabSwitcher.ToggleEdgeSettings)
        local loginCB = CreateFrame("CheckButton", nil, settingsFrame, "UICheckButtonTemplate")
        loginCB:SetSize(23, 23)
        loginCB:SetPoint("TOPLEFT", edgeCB, "BOTTOMLEFT", 0, 0)
        local loginLabel = loginCB:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
        loginLabel:SetPoint("LEFT", loginCB, "RIGHT", 1, 0)
        loginLabel:SetText("Login tracker")
        loginCB:SetHitRectInsets(0, -loginLabel:GetStringWidth(), 0, 0)
        loginCB:SetChecked(DB.loginTracking == true)
        loginCB:SetScript("OnShow", function(self) self:SetChecked(DB.loginTracking == true) end)
        loginCB:SetScript("OnClick", function(self)
            DB.loginTracking = GDS_CheckboxChecked(self)
            if DB.loginTracking then GDS_LoginLog.Start("enabled") else GDS_LoginLog.Stop(false) end
        end)
        local loginHistory = MakeBtn(settingsFrame, 62, 19, "View log")
        loginHistory:SetPoint("LEFT", loginLabel, "RIGHT", 8, 0)
        loginHistory:SetScript("OnClick", function() ToggleHistory("logins") end)
        local partyY = -171
        local partyDiv = settingsFrame:CreateTexture(nil, "ARTWORK")
        partyDiv:SetHeight(1)
        partyDiv:SetPoint("TOPLEFT", 8, partyY + 7)
        partyDiv:SetPoint("TOPRIGHT", -8, partyY + 7)
        local t = DB.theme or DEFAULT_THEME
        partyDiv:SetColorTexture(t.borderR, t.borderG, t.borderB, .5)
        local partyHdr = settingsFrame:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
        partyHdr:SetPoint("TOPLEFT", 8, partyY)
        partyHdr:SetText("Party & Alerts")
        partyHdr:SetTextColor(t.accentR, t.accentG, t.accentB)
        table.insert(GT_titles, partyHdr)

        -- Party sharing is controlled from the main window header.
        -- Keep this entry accessible for healer / threat alerts even when
        -- Party Tracking is disabled, since those features do not require sync.
        local partyBtn = MakeBtn(settingsFrame, 180, 24, "Party Stats")
        partyBtn:SetPoint("TOPLEFT", 9, partyY - 18)
        settingsFrame.UpdateLayout = function()
            local extra = optionsPanel:IsShown() and (optionsPanel:GetHeight() + 6) or 0
            settingsFrame:SetHeight(241 + extra)
            priceBtn:ClearAllPoints()
            priceBtn:SetPoint("TOPLEFT", 9, -74 - extra)
            partyDiv:ClearAllPoints()
            partyDiv:SetPoint("TOPLEFT", 8, partyY + 7 - extra)
            partyDiv:SetPoint("TOPRIGHT", -8, partyY + 7 - extra)
            partyHdr:ClearAllPoints()
            partyHdr:SetPoint("TOPLEFT", 8, partyY - extra)
            partyBtn:ClearAllPoints()
            partyBtn:SetPoint("TOPLEFT", 9, partyY - 18 - extra)
        end
        settingsFrame.UpdateLayout()
        settingsFrame.TogglePartyStats = function(fromHeader)
            if not partyFrame then
                partyFrame = CreateFrame("Frame", "GTPartyStatsFrame", UIParent,
                    BackdropTemplateMixin and "BackdropTemplate")
                GDS_FocusWindow(partyFrame)
                -- Size is determined by the visible controls and party roster.
                partyFrame:SetSize(340, 305)
                partyFrame:SetPoint("TOPLEFT", settingsFrame, "TOPRIGHT", 6, 0)
                partyFrame:SetFrameStrata("DIALOG")
                -- Drag the unused title/header area (not the checkboxes).
                partyFrame:EnableMouse(true)
                partyFrame:SetMovable(true)
                partyFrame:SetClampedToScreen(true)
                partyFrame:RegisterForDrag("LeftButton")
                partyFrame:SetScript("OnDragStart", function(self)
                    self:StartMoving()
                end)
                partyFrame:SetScript("OnDragStop", function(self)
                    self:StopMovingOrSizing()
                    if not DB then return end
                    local left,top=self:GetLeft(),self:GetTop()
                    if not left or not top then return end
                    local scale=self:GetEffectiveScale()/UIParent:GetEffectiveScale()
                    DB.partyStatsPos = {x=left*scale, y=top*scale}
                end)
                -- A newly created WoW frame starts shown; hide it until the
                -- toggle below explicitly opens it (including on the first P click).
                partyFrame:Hide()
                ApplyBackdrop(partyFrame)
                local title = partyFrame:CreateFontString(nil, "OVERLAY", "GameFontNormal")
                title:SetPoint("TOPLEFT", 10, -12)
                title:SetText("Party Stats")
                local close = MakeBtn(partyFrame, 20, 20, "X")
                close:SetPoint("TOPRIGHT", -5, -5)
                close:SetScript("OnClick", function() partyFrame:Hide() end)
                local kbBoardBtn = MakeBtn(partyFrame, 77, 20, "KB Board")
                kbBoardBtn:SetPoint("TOPRIGHT", partyFrame, "TOPRIGHT", -30, -5)
                kbBoardBtn:SetScript("OnClick", function() GDS_KBBoard.ToggleWindow() end)
                kbBoardBtn:SetScript("OnEnter", function(self)
                    GameTooltip:SetOwner(self, "ANCHOR_TOP")
                    GameTooltip:SetText("Lifetime Party Killing Blows")
                    GameTooltip:AddLine("Records a killing blow only when a participating addon user earns it while grouped with you.", .9,.9,.9,true)
                    GameTooltip:Show()
                end)
                kbBoardBtn:SetScript("OnLeave", function() GameTooltip:Hide() end)
                local miniCB = CreateFrame("CheckButton", nil, partyFrame, "UICheckButtonTemplate")
                miniCB:SetSize(23, 23)
                miniCB:SetPoint("TOPLEFT", 7, -34)
                miniCB:SetChecked(DB.partyMiniVisible == true)
                local miniLabel = partyFrame:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
                miniLabel:SetPoint("LEFT", miniCB, "RIGHT", 1, 0)
                miniLabel:SetText("Show Compact Party Window")
                miniCB:SetScript("OnClick", function(self)
                    SetPartyMiniVisible(GDS_CheckboxChecked(self))
                end)
                partyFrame.miniCB = miniCB
                -- Collapse the optional healer/threat controls by default.
                -- This affects configuration visibility only; active alerts
                -- continue running with their saved settings.
                local optionalCB = CreateFrame("CheckButton", nil, partyFrame, "UICheckButtonTemplate")
                optionalCB:SetSize(23,23)
                optionalCB:SetPoint("TOPLEFT", 7, -65)
                optionalCB:SetChecked(DB.partyStatsOptionalExpanded == true)
                local optionalLabel = partyFrame:CreateFontString(nil,"OVERLAY","GameFontHighlightSmall")
                optionalLabel:SetPoint("LEFT",optionalCB,"RIGHT",1,0)
                optionalLabel:SetText("Optional (Experimental)")
                optionalCB:SetScript("OnClick",function(self)
                    DB.partyStatsOptionalExpanded = GDS_CheckboxChecked(self)
                    if partyFrame.UpdateManaOptionsVisibility then
                        partyFrame.UpdateManaOptionsVisibility()
                    end
                    if partyFrame.RefreshLayout then partyFrame.RefreshLayout() end
                end)
                optionalCB:SetScript("OnEnter",function(self)
                    GameTooltip:SetOwner(self,"ANCHOR_RIGHT")
                    GameTooltip:SetText("Optional tracking options")
                    GameTooltip:AddLine("Show or hide Healer Mana, Tank Threat, and DPS Threat settings. Hiding the options does not disable tracking.",.8,.8,.8,true)
                    GameTooltip:Show()
                end)
                optionalCB:SetScript("OnLeave",function() GameTooltip:Hide() end)
                partyFrame.optionalCB = optionalCB
                -- Independent healer-mana alert: no gold stats or party addon sync required.
                local manaCB = CreateFrame("CheckButton", nil, partyFrame, "UICheckButtonTemplate")
                manaCB:SetSize(23, 23)
                manaCB:SetPoint("TOPLEFT", 7, -66)
                manaCB:SetChecked(DB.healerManaTracking == true)
                local manaLabel = partyFrame:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
                manaLabel:SetPoint("LEFT", manaCB, "RIGHT", 1, 0)
                manaLabel:SetText("Healer Mana Tracking")
                -- An inline dedication, kept separate so the option itself stays readable.
                local manaDedication = partyFrame:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
                manaDedication:SetPoint("LEFT", manaLabel, "RIGHT", 5, 0)
                manaDedication:SetFont(STANDARD_TEXT_FONT, 9, "")
                manaDedication:SetText("(Bespoke for Stoneblade Mudhut)")
                manaDedication:SetTextColor(0.85, 0.72, 0.43)
                manaCB:SetScript("OnClick", function(self)
                    DB.healerManaTracking = GDS_CheckboxChecked(self)
                    if not DB.healerManaTracking and partyFrame and partyFrame.previewCB then
                        partyFrame.previewCB:SetChecked(false)
                        if partyFrame.UpdateManaOptionsVisibility then partyFrame.UpdateManaOptionsVisibility() end
                        if GTSetHealerManaPreview then GTSetHealerManaPreview(false) end
                    end
                    if GTUpdateHealerManaAlert then GTUpdateHealerManaAlert() end
                end)
                manaCB:SetScript("OnEnter", function(self)
                    GameTooltip:SetOwner(self, "ANCHOR_RIGHT")
                    GameTooltip:SetText("Healer Mana Tracking")
                    GameTooltip:AddLine("Show a movable warning when healer mana falls to your activation threshold; hide at your recovery threshold.", .8,.8,.8,true)
                    GameTooltip:AddLine("Uses assigned HEALER role first, otherwise a healing-capable class. Combat API restrictions may block detection.", .7,.8,.9,true)
                    GameTooltip:Show()
                end)
                manaCB:SetScript("OnLeave", function() GameTooltip:Hide() end)
                partyFrame.manaCB = manaCB
                partyFrame.manaLabel = manaLabel
                partyFrame.manaDedication = manaDedication
                -- Preview the alert without a party or low-mana healer.
                local previewCB = CreateFrame("CheckButton", nil, partyFrame, "UICheckButtonTemplate")
                previewCB:SetSize(23, 23)
                previewCB:SetPoint("TOPLEFT", 18, -94)
                local previewLabel = partyFrame:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
                previewLabel:SetPoint("LEFT", previewCB, "RIGHT", 1, 0)
                previewLabel:SetText("Preview / Move Mana Alert")
                previewCB:SetChecked(false)
                previewCB:SetScript("OnClick", function(self)
                    if not DB.healerManaTracking then
                        self:SetChecked(false)
                        DEFAULT_CHAT_FRAME:AddMessage("|cFFD8DDE6Grind Dont Stop|r Enable Healer Mana Tracking first.")
                        return
                    end
                    if partyFrame.UpdateManaOptionsVisibility then
                        partyFrame.UpdateManaOptionsVisibility()
                    end
                    if GTSetHealerManaPreview then GTSetHealerManaPreview(GDS_CheckboxChecked(self)) end
                end)
                partyFrame.previewCB = previewCB
                partyFrame.previewLabel = previewLabel
                local sizeLabel = partyFrame:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
                sizeLabel:SetPoint("TOPLEFT", 13, -123)
                sizeLabel:SetText("Alert size")
                local sizeValue = partyFrame:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
                sizeValue:SetPoint("TOPRIGHT", -15, -123)
                local sizeSlider = CreateFrame("Slider", nil, partyFrame,
                    BackdropTemplateMixin and "BackdropTemplate" or nil)
                sizeSlider:SetPoint("TOPLEFT", 87, -125)
                sizeSlider:SetSize(125, 14)
                sizeSlider:SetOrientation("HORIZONTAL")
                sizeSlider:SetMinMaxValues(70, 160)
                sizeSlider:SetValueStep(5)
                if sizeSlider.SetObeyStepOnDrag then sizeSlider:SetObeyStepOnDrag(true) end
                if sizeSlider.SetBackdrop then
                    sizeSlider:SetBackdrop({bgFile="Interface\\Buttons\\WHITE8X8"})
                    sizeSlider:SetBackdropColor(.12, .14, .17, 1)
                end
                local thumb = sizeSlider:CreateTexture(nil, "OVERLAY")
                thumb:SetTexture("Interface\\Buttons\\UI-SliderBar-Button-Horizontal")
                thumb:SetSize(18, 20)
                sizeSlider:SetThumbTexture(thumb)
                sizeSlider:SetValue(DB.healerManaScale or 100)
                sizeSlider:SetScript("OnValueChanged", function(self, value)
                    local amount = math.floor(value / 5 + .5) * 5
                    sizeValue:SetText(amount .. "%")
                    if DB then DB.healerManaScale = amount end
                    if GTSetHealerManaScale then GTSetHealerManaScale(amount) end
                end)
                sizeValue:SetText(tostring(DB.healerManaScale or 100).."%")
                partyFrame.sizeSlider = sizeSlider
                -- Independent activation and recovery thresholds, with hysteresis.
                -- When activation is 100%, the alert remains visible at all mana levels.
                local function MakeManaThresholdSlider(y, caption, savedKey, initialValue, onAdjust)
                    local captionText = partyFrame:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
                    captionText:SetPoint("TOPLEFT", 13, y)
                    captionText:SetText(caption)
                    local numberText = partyFrame:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
                    numberText:SetPoint("TOPRIGHT", -15, y)
                    local slider = CreateFrame("Slider", nil, partyFrame,
                        BackdropTemplateMixin and "BackdropTemplate" or nil)
                    slider:SetPoint("TOPLEFT", 110, y-2)
                    slider:SetSize(103, 14)
                    slider:SetOrientation("HORIZONTAL")
                    slider:SetMinMaxValues(0, 100)
                    slider:SetValueStep(1)
                    if slider.SetObeyStepOnDrag then slider:SetObeyStepOnDrag(true) end
                    if slider.SetBackdrop then
                        slider:SetBackdrop({bgFile="Interface\\Buttons\\WHITE8X8"})
                        slider:SetBackdropColor(.12, .14, .17, 1)
                    end
                    local thumbTex = slider:CreateTexture(nil, "OVERLAY")
                    thumbTex:SetTexture("Interface\\Buttons\\UI-SliderBar-Button-Horizontal")
                    thumbTex:SetSize(18,20)
                    slider:SetThumbTexture(thumbTex)
                    slider:SetScript("OnValueChanged", function(self, value)
                        local amount = math.max(0, math.min(100, math.floor(value + .5)))
                        if DB then DB[savedKey] = amount end
                        numberText:SetText(amount .. "%")
                        if onAdjust then onAdjust(amount) end
                        if partyFrame.previewCB and partyFrame.previewCB:GetChecked()
                            and GTSetHealerManaPreview then
                            GTSetHealerManaPreview(true)
                        elseif GTUpdateHealerManaAlert then
                            GTUpdateHealerManaAlert()
                        end
                    end)
                    slider:SetValue(DB[savedKey] or initialValue)
                    numberText:SetText(tostring(DB[savedKey] or initialValue).."%")
                    return slider, numberText, captionText
                end
                local hideSlider, hideNumber, hideLabel = MakeManaThresholdSlider(-194, "Disappear at", "healerManaHidePct", 50)
                local showSlider, showNumber, showLabel = MakeManaThresholdSlider(-159, "Activate at", "healerManaShowPct", 10,
                    function(amount)
                        if amount >= 100 then
                            hideSlider:Disable()
                            hideSlider:SetAlpha(.4)
                            hideNumber:SetText("N/A")
                        else
                            hideSlider:Enable()
                            hideSlider:SetAlpha(1)
                            if (DB.healerManaHidePct or 50) <= amount then
                                hideSlider:SetValue(amount + 1)
                            else
                                hideNumber:SetText((DB.healerManaHidePct or 50).."%")
                            end
                        end
                    end)
                hideSlider:SetScript("OnValueChanged", function(self, value)
                    local amount = math.max(0, math.min(100, math.floor(value + .5)))
                    local show = DB.healerManaShowPct or 10
                    if show < 100 and amount <= show then
                        amount = show + 1
                        if math.abs(value - amount) > .001 then self:SetValue(amount); return end
                    end
                    DB.healerManaHidePct = amount
                    hideNumber:SetText(show >= 100 and "N/A" or (amount.."%"))
                    if partyFrame.previewCB and partyFrame.previewCB:GetChecked()
                        and GTSetHealerManaPreview then GTSetHealerManaPreview(true)
                    elseif GTUpdateHealerManaAlert then GTUpdateHealerManaAlert() end
                end)
                if (DB.healerManaShowPct or 10) >= 100 then
                    hideSlider:Disable(); hideSlider:SetAlpha(.4); hideNumber:SetText("N/A")
                elseif (DB.healerManaHidePct or 50) <= (DB.healerManaShowPct or 10) then
                    hideSlider:SetValue((DB.healerManaShowPct or 10) + 1)
                end
                partyFrame.manaShowSlider = showSlider
                partyFrame.manaHideSlider = hideSlider
                partyFrame.manaSliders = {
                    {sizeLabel,sizeSlider,sizeValue},
                    {showLabel,showSlider,showNumber},
                    {hideLabel,hideSlider,hideNumber},
                }
                -- Keep configuration tucked away until Preview / Move is checked.
                -- This only controls visibility; saved thresholds remain active.
                partyFrame.UpdateManaOptionsVisibility = function()
                    local visible = GDS_CheckboxChecked(partyFrame.optionalCB)
                        and GDS_CheckboxChecked(previewCB) and DB.healerManaTracking == true
                    for _, widget in ipairs({
                        sizeLabel, sizeValue, sizeSlider,
                        showLabel, showNumber, showSlider,
                        hideLabel, hideNumber, hideSlider,
                    }) do
                        widget:SetShown(visible)
                    end
                    if partyFrame.RefreshLayout then partyFrame.RefreshLayout() end
                end
                partyFrame.UpdateManaOptionsVisibility()
                partyFrame.rows = {}
                for i=1,6 do
                    local fs = partyFrame:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
                    fs:SetPoint("TOPLEFT", 10, -235-i*(DB.questTracking and 54 or 31))
                    fs:SetWidth(260)
                    fs:SetJustifyH("LEFT")
                    partyFrame.rows[i] = fs
                end
                if GTBuildThreatControls then GTBuildThreatControls(partyFrame) end
                GDS_PartySession.SetupUI(partyFrame)
                if partyFrame.RefreshLayout then partyFrame.RefreshLayout() end
            end
            if partyFrame:IsShown() then
                partyFrame:Hide()
            else
                -- Party Stats must have UIParent as its parent, not the Settings
                -- window; otherwise the P shortcut cannot display it by itself.
                partyFrame:ClearAllPoints()
                local saved = DB and DB.partyStatsPos
                if saved and type(saved.x)=="number" and type(saved.y)=="number" then
                    partyFrame:SetPoint("TOPLEFT", UIParent, "BOTTOMLEFT", saved.x, saved.y)
                elseif fromHeader then
                    partyFrame:SetPoint("TOPLEFT", mainFrame, "TOPRIGHT", 6, 0)
                else
                    partyFrame:SetPoint("TOPLEFT", settingsFrame, "TOPRIGHT", 6, 0)
                end
                partyFrame:Show()
                RefreshPartyStats()
            end
        end
        partyBtn:SetScript("OnClick", function() settingsFrame.TogglePartyStats(false) end)
        -- Separate opt-in quest reward tracking, independent of party sharing.
        local questCB = CreateFrame("CheckButton", nil, optionsPanel, "UICheckButtonTemplate")
        questCB:SetSize(23, 23)
        questCB:SetPoint("TOPLEFT", 5, -10 - #opts*22)
        questCB:SetChecked(DB.questTracking == true)
        local questLabel = optionsPanel:CreateFontString(nil,"OVERLAY","GameFontHighlightSmall")
        questLabel:SetPoint("LEFT", questCB, "RIGHT", 1, 0)
        questLabel:SetText("Quest Tracker")
        questCB:SetScript("OnClick", function(self)
            DB.questTracking = GDS_CheckboxChecked(self)
            if S and S.running and DB.questTracking then S.questTrackingSeen = true end
            -- Previously assigned [Q] entries count as farm items while Quest
            -- Tracker is off; reclassify them when it is turned back on.
            RepriceCurrentLoot()
            -- Do not erase in-flight reward exclusion when toggling display.
            if settingsFrame.RefreshTrackingResetButtons then settingsFrame.RefreshTrackingResetButtons() end
            ApplyVisibility()
            RefreshStats()
            if SendPartyStats then SendPartyStats() end
            if RefreshPartyStats then RefreshPartyStats() end
        end)
        questCB:SetScript("OnEnter", function(self)
            GameTooltip:SetOwner(self, "ANCHOR_RIGHT")
            GameTooltip:SetText("Quest Tracker")
            GameTooltip:AddLine("Quest rewards are ALWAYS excluded from farming totals. Enable only to display separate quest XP and gold statistics.", .8,.8,.8,true)
            GameTooltip:AddLine("Counts quest rewards only while a farming session is running and not paused. Session totals reset at End Session; all-time tracked totals are retained.", .7,.8,.9,true)
            GameTooltip:Show()
        end)
        questCB:SetScript("OnLeave", function() GameTooltip:Hide() end)
        settingsFrame.questCB = questCB

        -- Reset button is only visible while Quest Tracker is enabled.
        -- A second click confirms; past completed-session history is untouched.
        local questReset = MakeBtn(optionsPanel, 64, 20, "Reset")
        questReset:SetPoint("TOPRIGHT", -8, -12 - #opts*22)
        questReset:SetScript("OnClick", function(self)
            if not DB or not DB.questTracking then return end
            if not self._gtConfirm then
                self._gtConfirm = true
                self.label:SetText("Confirm?")
                C_Timer.After(6, function()
                    if self._gtConfirm then
                        self._gtConfirm = nil
                        self.label:SetText("Reset")
                    end
                end)
                return
            end
            self._gtConfirm = nil
            self.label:SetText("Reset")
            -- Reset both visible session totals and archived all-time totals,
            -- but NOT the quest XP exclusion baseline or pending money filter.
            -- Those exclusions protect the farming XP/coin calculations.
            DB.questTotals = {xp=0, gold=0}
            if S then
                S.questXP, S.questGold = 0, 0
                local alreadyClassified = 0
                for _, entry in ipairs(S.loot or {}) do
                    if GDS_QuestItems.EntryIsQuest(entry) then
                        alreadyClassified = alreadyClassified + (tonumber(entry.total) or 0)
                    end
                end
                S.questItemGold = alreadyClassified
            end
            RefreshStats()
            if SendPartyStats then SendPartyStats() end
            if RefreshPartyStats then RefreshPartyStats() end
            DEFAULT_CHAT_FRAME:AddMessage("|cFFD8DDE6Grind Dont Stop|r Quest XP and Quest Coin reset to zero. Saved history kept.")
        end)
        questReset:SetScript("OnEnter", function(self)
            GameTooltip:SetOwner(self, "ANCHOR_RIGHT")
            GameTooltip:SetText("Reset Quest Tracker")
            GameTooltip:AddLine("Clear current-session and all-time tracked Quest XP/Coin. Click twice to confirm. Saved run history and farming stats are unchanged.", .8, .8, .8, true)
            GameTooltip:Show()
        end)
        questReset:SetScript("OnLeave", function() GameTooltip:Hide() end)
        settingsFrame.questResetBtn = questReset

        -- Optional, independent PvP kill / killing-blow tracking.
        local pvpCB = CreateFrame("CheckButton", nil, optionsPanel, "UICheckButtonTemplate")
        pvpCB:SetSize(23, 23)
        pvpCB:SetPoint("TOPLEFT", 5, -39 - #opts*22)
        pvpCB:SetChecked(DB.pvpTracking == true)
        local pvpLabel = optionsPanel:CreateFontString(nil,"OVERLAY","GameFontHighlightSmall")
        pvpLabel:SetPoint("LEFT", pvpCB, "RIGHT", 1, 0)
        pvpLabel:SetText("PvP Tracking")
        pvpCB:SetScript("OnClick", function(self)
            DB.pvpTracking = GDS_CheckboxChecked(self)
            if S and S.running and DB.pvpTracking then S.pvpTrackingSeen = true end
            if settingsFrame.RefreshTrackingResetButtons then settingsFrame.RefreshTrackingResetButtons() end
            if GDS_PvP then GDS_PvP.ResetBaseline() end
            RefreshStats()
            if SendPartyStats then SendPartyStats() end
            if RefreshPartyStats then RefreshPartyStats() end
        end)
        pvpCB:SetScript("OnEnter", function(self)
            GameTooltip:SetOwner(self, "ANCHOR_RIGHT")
            GameTooltip:SetText("PvP Tracking")
            GameTooltip:AddLine("Track honorable-kill credit (including assists) and your own honorable killing blows separately from PvE kills.", .8,.8,.8,true)
            GameTooltip:AddLine("Your PvP totals persist even when no grind session is running. Session PvP counts are saved in History.", .7,.8,.9,true)
            GameTooltip:Show()
        end)
        pvpCB:SetScript("OnLeave", function() GameTooltip:Hide() end)
        settingsFrame.pvpCB = pvpCB

        -- Opaque affects window backdrops only, not XP/loot/coin tracking.
        -- It defaults to OFF and is saved on this character with other settings.
        local opaqueCB = CreateFrame("CheckButton", nil, optionsPanel, "UICheckButtonTemplate")
        opaqueCB:SetSize(23, 23)
        opaqueCB:SetPoint("TOPLEFT", 5, -69 - #opts*22)
        opaqueCB:SetChecked(DB.opaque == true)
        local opaqueLabel = optionsPanel:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
        opaqueLabel:SetPoint("LEFT", opaqueCB, "RIGHT", 1, 0)
        opaqueLabel:SetText("Opaque")
        opaqueCB:SetScript("OnClick", function(self)
            DB.opaque = GDS_CheckboxChecked(self)
            ApplyTheme()
        end)
        opaqueCB:SetScript("OnEnter", function(self)
            GameTooltip:SetOwner(self, "ANCHOR_RIGHT")
            GameTooltip:SetText("Opaque windows")
            GameTooltip:AddLine("On: solid window backgrounds so the world does not show through.", .8,.8,.8,true)
            GameTooltip:AddLine("Off (default): keep the current skin transparency. Saved per character.", .7,.8,.9,true)
            GameTooltip:Show()
        end)
        opaqueCB:SetScript("OnLeave", function() GameTooltip:Hide() end)
        settingsFrame.opaqueCB = opaqueCB

        -- Repair costs are optional and NEVER subtracted from gross GP/GPH.
        -- The indicator reads equipment durability without opening a merchant;
        -- exact copper expenses are recorded only after a verified repair.
        local repairCB = CreateFrame("CheckButton", nil, optionsPanel, "UICheckButtonTemplate")
        repairCB:SetSize(23, 23)
        repairCB:SetPoint("TOPLEFT", 5, -99 - #opts*22)
        repairCB:SetChecked(DB.repairTracking == true)
        local repairLabel = optionsPanel:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
        repairLabel:SetPoint("LEFT", repairCB, "RIGHT", 1, 0)
        repairLabel:SetText("Track Repairs")
        repairCB:SetScript("OnClick", function(self)
            DB.repairTracking = GDS_CheckboxChecked(self)
            if GDS_Repairs then GDS_Repairs.OnToggle(); GDS_Repairs.RefreshLabel() end
            RefreshStats() -- show/hide Repairs Paid immediately and resize main window
        end)
        repairCB:SetScript("OnEnter", function(self)
            GameTooltip:SetOwner(self, "ANCHOR_RIGHT")
            GameTooltip:SetText("Track Repairs")
            GameTooltip:AddLine("Show equipped durability before reaching a vendor. Exact copper spent is recorded when repairing at an NPC.", .8,.8,.8,true)
            GameTooltip:AddLine("Gross farming totals and GPH never change. Durability does NOT give an exact remote repair bill.", .7,.8,.9,true)
            GameTooltip:Show()
        end)
        repairCB:SetScript("OnLeave", function() GameTooltip:Hide() end)
        settingsFrame.repairCB = repairCB
        local repairStatus = optionsPanel:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
        repairStatus:SetPoint("TOPLEFT", 11, -165 - #opts*22)
        repairStatus:SetWidth(180)
        repairStatus:SetJustifyH("LEFT")
        repairStatus:SetText("")
        TrackThemeText(repairStatus)
        settingsFrame.repairStatus = repairStatus

        local durabilityCB = CreateFrame("CheckButton", nil, optionsPanel, "UICheckButtonTemplate")
        durabilityCB:SetSize(23, 23)
        durabilityCB:SetPoint("TOPLEFT", 5, -130 - #opts*22)
        durabilityCB:SetChecked(DB.showDurability == true)
        local durabilityCBLabel = optionsPanel:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
        durabilityCBLabel:SetPoint("LEFT", durabilityCB, "RIGHT", 1, 0)
        durabilityCBLabel:SetText("Show Durability")
        durabilityCB:SetScript("OnClick", function(self)
            DB.showDurability = GDS_CheckboxChecked(self)
            RefreshStats()
        end)
        durabilityCB:SetScript("OnEnter", function(self)
            GameTooltip:SetOwner(self, "ANCHOR_RIGHT")
            GameTooltip:SetText("Show Durability")
            GameTooltip:AddLine("Shows equipped durability % in your main tracker. Hover the row for estimated repair cost before visiting a vendor.", .8, .8, .8, true)
            GameTooltip:AddLine("Separate from Track Repairs, which records actual repair expenses. Off by default.", .7, .8, .9, true)
            GameTooltip:Show()
        end)
        durabilityCB:SetScript("OnLeave", function() GameTooltip:Hide() end)
        settingsFrame.durabilityCB = durabilityCB

        -- Two optional, non-invasive helpers; neither changes farming totals.
        local healthCB = CreateFrame("CheckButton", nil, optionsPanel, "UICheckButtonTemplate")
        healthCB:SetSize(23, 23)
        healthCB:SetPoint("TOPLEFT", 5, -194 - #opts*22)
        healthCB:SetChecked(DB.showTrackingHealth ~= false)
        local healthLabel = optionsPanel:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
        healthLabel:SetPoint("LEFT", healthCB, "RIGHT", 1, 0)
        healthLabel:SetText("Tracking Status")
        healthCB:SetScript("OnClick", function(self)
            DB.showTrackingHealth = GDS_CheckboxChecked(self)
            if GDS_Health then GDS_Health.Refresh() end
        end)
        healthCB:SetScript("OnEnter", function(self)
            GameTooltip:SetOwner(self, "ANCHOR_RIGHT")
            GameTooltip:SetText("Tracking Status")
            GameTooltip:AddLine("Small footer status with hover diagnostics for XP, loot and coin events. Does not change tracking.", .8,.8,.8,true)
            GameTooltip:AddLine("Healthy means listeners are registered and events processed; it cannot guarantee every drop was valued.", .7,.8,.9,true)
            GameTooltip:Show()
        end)
        healthCB:SetScript("OnLeave", function() GameTooltip:Hide() end)
        settingsFrame.healthCB = healthCB

        local dungeonLiveCB = CreateFrame("CheckButton", nil, optionsPanel, "UICheckButtonTemplate")
        dungeonLiveCB:SetSize(23, 23)
        dungeonLiveCB:SetPoint("TOPLEFT", 5, -221 - #opts*22)
        dungeonLiveCB:SetChecked(DB.showLiveDungeon == true)
        local dungeonLiveLabel = optionsPanel:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
        dungeonLiveLabel:SetPoint("LEFT", dungeonLiveCB, "RIGHT", 1, 0)
        dungeonLiveLabel:SetText("Live Dungeon")
        dungeonLiveCB:SetScript("OnClick", function(self)
            DB.showLiveDungeon = GDS_CheckboxChecked(self)
            if GDS_LiveDungeon then GDS_LiveDungeon.Refresh() end
        end)
        dungeonLiveCB:SetScript("OnEnter", function(self)
            GameTooltip:SetOwner(self, "ANCHOR_RIGHT")
            GameTooltip:SetText("Live Dungeon Run")
            GameTooltip:AddLine("Shows a small, draggable dungeon panel only while a run is active. Click to expand time and earnings.", .8,.8,.8,true)
            GameTooltip:AddLine("Reads the current dungeon run; your main session and dungeon-history recording stay unchanged.", .7,.8,.9,true)
            GameTooltip:Show()
        end)
        dungeonLiveCB:SetScript("OnLeave", function() GameTooltip:Hide() end)
        settingsFrame.dungeonLiveCB = dungeonLiveCB

        local pvpReset = MakeBtn(optionsPanel, 64, 20, "Reset")
        pvpReset:SetPoint("TOPRIGHT", -8, -41 - #opts*22)
        pvpReset:SetScript("OnClick", function(self)
            if not DB or not DB.pvpTracking then return end
            if not self._gtConfirm then
                self._gtConfirm = true
                self.label:SetText("Confirm?")
                C_Timer.After(6, function()
                    if self._gtConfirm then
                        self._gtConfirm = nil
                        self.label:SetText("Reset")
                    end
                end)
                return
            end
            self._gtConfirm = nil
            self.label:SetText("Reset")
            -- Clear both the persistent record and the current session's PvP
            -- values. Keep completed sessions in History for reference.
            DB.pvpTotals = {hk=0, kb=0}
            if S then S.pvpHK, S.pvpKB = 0, 0 end
            if GDS_PvP then GDS_PvP.ResetBaseline() end
            RefreshStats()
            if SendPartyStats then SendPartyStats() end
            if RefreshPartyStats then RefreshPartyStats() end
            DEFAULT_CHAT_FRAME:AddMessage("|cFFD8DDE6Grind Dont Stop|r Honorable Kills and Killing Blows reset to zero. Saved history kept.")
        end)
        pvpReset:SetScript("OnEnter", function(self)
            GameTooltip:SetOwner(self, "ANCHOR_RIGHT")
            GameTooltip:SetText("Reset PvP Tracker")
            GameTooltip:AddLine("Clear current-session and all-time tracked HKs and killing blows. Click twice to confirm. Saved runs are unchanged.", .8, .8, .8, true)
            GameTooltip:Show()
        end)
        pvpReset:SetScript("OnLeave", function() GameTooltip:Hide() end)
        settingsFrame.pvpResetBtn = pvpReset

        settingsFrame.RefreshTrackingResetButtons = function()
            for _, entry in ipairs({
                {button=settingsFrame.questResetBtn, visible=DB.questTracking == true},
                {button=settingsFrame.pvpResetBtn, visible=DB.pvpTracking == true},
            }) do
                if entry.button then
                    entry.button._gtConfirm = nil
                    entry.button.label:SetText("Reset")
                    entry.button:SetShown(entry.visible)
                end
            end
        end
        settingsFrame.RefreshTrackingResetButtons()
        -- End multiplayer, quest and PvP settings -------------------------------

        settingsFrame.RefreshOptions = function()
            RefreshShowTicks()
            if settingsFrame.questCB then settingsFrame.questCB:SetChecked(DB.questTracking == true) end
            if settingsFrame.pvpCB then settingsFrame.pvpCB:SetChecked(DB.pvpTracking == true) end
            if settingsFrame.opaqueCB then settingsFrame.opaqueCB:SetChecked(DB.opaque == true) end
            if settingsFrame.repairCB then settingsFrame.repairCB:SetChecked(DB.repairTracking == true) end
            if settingsFrame.durabilityCB then settingsFrame.durabilityCB:SetChecked(DB.showDurability == true) end
            if settingsFrame.healthCB then settingsFrame.healthCB:SetChecked(DB.showTrackingHealth ~= false) end
            if settingsFrame.dungeonLiveCB then settingsFrame.dungeonLiveCB:SetChecked(DB.showLiveDungeon == true) end
            if GDS_Repairs then GDS_Repairs.RefreshLabel() end
            if settingsFrame.RefreshTrackingResetButtons then settingsFrame.RefreshTrackingResetButtons() end
            if settingsFrame.UpdatePriceLabel then settingsFrame.UpdatePriceLabel() end
        end
    end
    if settingsFrame.RefreshOptions then settingsFrame.RefreshOptions() end
    ApplyVisibility()
    if partyOnly then
        -- Open independently of Settings from the main-header P shortcut.
        settingsFrame:Hide()
        settingsFrame.TogglePartyStats(true)
    else
        settingsFrame:Show()
    end
end

-- Healer mana alert: configurable activation/recovery, or always on at 100%.
-- WoW Midnight/Forever sometimes returns secret power values in combat. Do
-- not compare or format protected values; skip those updates rather than error.
do
local healerManaFrame
local healerManaActive = false
local healerManaUnit = nil
local healerManaPreview = false
local function ReadHealerMana(unit)
    if not unit or not UnitExists(unit) then return nil end
    if UnitPowerType then
        local ok, kind = pcall(UnitPowerType, unit)
        if not ok or (issecretvalue and issecretvalue(kind)) or kind ~= 0 then return nil end
    end
    if UnitPowerPercent then
        local ok, pct = pcall(UnitPowerPercent, unit, 0)
        if ok and type(pct) == "number" and not (issecretvalue and issecretvalue(pct)) then
            return math.max(0, math.min(100, pct))
        end
    end
    if not (UnitPower and UnitPowerMax) then return nil end
    local ok, pct = pcall(function()
        local current, maximum = UnitPower(unit, 0), UnitPowerMax(unit, 0)
        if (issecretvalue and (issecretvalue(current) or issecretvalue(maximum)))
            or type(current) ~= "number" or type(maximum) ~= "number" or maximum <= 0 then
            return nil
        end
        return math.max(0, math.min(100, current * 100 / maximum))
    end)
    return ok and pct or nil
end

local HEALER_CLASSES = { PRIEST=true, DRUID=true, PALADIN=true, SHAMAN=true, MONK=true, EVOKER=true }
local function FindPartyHealer()
    if not (IsInGroup and IsInGroup()) then return nil end
    local units = {"player"}
    local n = GetNumSubgroupMembers and GetNumSubgroupMembers() or 0
    for i=1,n do units[#units+1] = "party"..i end
    -- Respect assigned roles when available.
    if UnitGroupRolesAssigned then
        for _,u in ipairs(units) do
            if UnitExists(u) and UnitGroupRolesAssigned(u) == "HEALER" then return u end
        end
    end
    -- Unassigned Classic/Forever parties: choose the first mana-based healing class.
    -- A role assignment is preferred whenever possible to avoid ambiguities.
    for _,u in ipairs(units) do
        if UnitExists(u) and UnitClass then
            local _, class = UnitClass(u)
            if HEALER_CLASSES[class] then
                local ok, kind = pcall(UnitPowerType, u)
                if ok and not (issecretvalue and issecretvalue(kind)) and kind == 0 then
                    return u
                end
            end
        end
    end
    return nil
end

local function EnsureHealerManaFrame()
    if healerManaFrame then return healerManaFrame end
    local f = CreateFrame("Frame", "GTHealerManaAlertFrame", UIParent,
        BackdropTemplateMixin and "BackdropTemplate")
    healerManaFrame = f
    f:SetSize(236, 70)
    f:SetScale((DB and DB.healerManaScale or 100) / 100)
    f:SetFrameStrata("HIGH")
    f:SetClampedToScreen(true)
    f:EnableMouse(true)
    f:SetMovable(true)
    f:RegisterForDrag("LeftButton")
    f:SetScript("OnDragStart", function(self) self:StartMoving() end)
    f:SetScript("OnDragStop", function(self)
        self:StopMovingOrSizing()
        if DB then
            local x,y=self:GetCenter()
            if x and y then
                local scale = self:GetEffectiveScale()/UIParent:GetEffectiveScale()
                DB.healerManaPos={x=x*scale,y=y*scale}
            end
        end
    end)
    if DB and type(DB.healerManaPos)=="table" and DB.healerManaPos.x and DB.healerManaPos.y then
        f:SetPoint("CENTER", UIParent, "BOTTOMLEFT", DB.healerManaPos.x, DB.healerManaPos.y)
    else
        f:SetPoint("CENTER", UIParent, "CENTER", 0, 170)
    end
    ApplyBackdrop(f)
    local title = f:CreateFontString(nil,"OVERLAY","GameFontNormalSmall")
    title:SetPoint("TOPLEFT",10,-9)
    title:SetText("HEALER LOW MANA")
    title:SetTextColor(1,.35,.3)
    f.title=title
    local percent = f:CreateFontString(nil,"OVERLAY","GameFontHighlightSmall")
    percent:SetPoint("TOPRIGHT",-11,-9)
    f.percent=percent
    local bg = f:CreateTexture(nil,"BACKGROUND")
    bg:SetPoint("TOPLEFT",10,-32)
    bg:SetPoint("TOPRIGHT",-10,-32)
    bg:SetHeight(13)
    bg:SetColorTexture(.10,.13,.18,.95)
    local bar = CreateFrame("StatusBar",nil,f)
    bar:SetPoint("TOPLEFT",bg,"TOPLEFT",1,-1)
    bar:SetPoint("BOTTOMRIGHT",bg,"BOTTOMRIGHT",-1,1)
    bar:SetMinMaxValues(0,100)
    local tex=bar:CreateTexture(nil,"ARTWORK")
    tex:SetColorTexture(1,.2,.2,1)
    bar:SetStatusBarTexture(tex)
    f.bar=bar
    local caption = f:CreateFontString(nil,"OVERLAY","GameFontDisableSmall")
    caption:SetPoint("BOTTOMLEFT",10,8)
    caption:SetText("Drag to move  |  Custom thresholds")
    f.caption=caption
    f:Hide()
    return f
end

-- These two callbacks are called from the Party Stats controls created above.
GTSetHealerManaScale = function(percent)
    if healerManaFrame then healerManaFrame:SetScale((percent or 100) / 100) end
end
local function ApplyHealerManaVisual(f, pct)
    f.percent:SetText(("%.0f%% Mana"):format(pct))
    f.bar:SetValue(pct)
    if pct <= 10 then
        f.bar:GetStatusBarTexture():SetColorTexture(.95,.16,.16,1)
        f.percent:SetTextColor(1,.3,.3)
    elseif pct <= 25 then
        f.bar:GetStatusBarTexture():SetColorTexture(1,.53,.12,1)
        f.percent:SetTextColor(1,.72,.3)
    elseif pct <= 50 then
        f.bar:GetStatusBarTexture():SetColorTexture(1,.84,.2,1)
        f.percent:SetTextColor(1,.9,.5)
    else
        f.bar:GetStatusBarTexture():SetColorTexture(.24,.68,1,1)
        f.percent:SetTextColor(.55,.8,1)
    end
    local show = (DB and DB.healerManaShowPct) or 10
    local hide = (DB and DB.healerManaHidePct) or 50
    f.caption:SetText(show >= 100 and "Drag to move  |  Always visible"
        or ("Drag to move  |  Hides at "..hide.."%"))
end
GTSetHealerManaPreview = function(enabled)
    healerManaPreview = enabled == true and DB and DB.healerManaTracking == true
    if healerManaPreview then
        local f = EnsureHealerManaFrame()
        f.title:SetText("HEALER MANA PREVIEW")
        -- Preview uses the activation setting to illustrate the corresponding fill/color.
        ApplyHealerManaVisual(f, DB.healerManaShowPct or 10)
        f:Show()
    elseif GTUpdateHealerManaAlert then
        GTUpdateHealerManaAlert()
    end
end

GTUpdateHealerManaAlert = function()
    if healerManaPreview and DB and DB.healerManaTracking then
        return
    end
    if not DB or not DB.healerManaTracking or not (IsInGroup and IsInGroup()) then
        healerManaActive, healerManaUnit = false, nil
        if healerManaFrame then healerManaFrame:Hide() end
        return
    end
    local unit = FindPartyHealer()
    if unit ~= healerManaUnit then
        healerManaActive, healerManaUnit = false, unit
        if healerManaFrame then healerManaFrame:Hide() end
    end
    if not unit then return end
    local pct = ReadHealerMana(unit)
    if pct == nil then return end -- Never make alert decisions from secret values.
    local show = math.max(0, math.min(100, tonumber(DB.healerManaShowPct) or 10))
    local hide = math.max(show + 1, math.min(100, tonumber(DB.healerManaHidePct) or 50))
    if show >= 100 then
        healerManaActive = true -- Always show while a healer is detected.
    else
        if healerManaActive and pct >= hide then healerManaActive = false end
        if pct <= show then healerManaActive = true end
    end
    if not healerManaActive then
        if healerManaFrame then healerManaFrame:Hide() end
        return
    end
    local f = EnsureHealerManaFrame()
    local name = UnitName(unit) or "Healer"
    f.title:SetText("HEALER: "..name)
    ApplyHealerManaVisual(f, pct)
    f:Show()
end

end -- end healer mana implementation scope

-------------------------------------------------------------------------------
-- Optional Tank/DPS Threat Alerts. Addon-owned data is deliberately isolated
-- in this scope to stay under the WoW Lua 200-local limit. All combat returns
-- are checked for Midnight secret values before comparison or arithmetic.
-- Numeric thresholds are used only when readable; otherwise we show safe
-- status-only warnings (never invent a threat percentage).
-------------------------------------------------------------------------------
do
    local specs = {
        tank = {title="TANK THREAT", prefix="tankThreat", mode="low", defaultShow=85, defaultHide=95,
            defaultX=255, defaultY=135},
        dps = {title="DPS THREAT", prefix="dpsThreat", mode="high", defaultShow=85, defaultHide=50,
            defaultX=255, defaultY=38},
    }

    local function Usable(value)
        return value ~= nil and not (issecretvalue and issecretvalue(value))
    end

    local function GetTrackedUnit(kind)
        if not (IsInGroup and IsInGroup()) then return kind == "dps" and "player" or nil end
        local roster = {"player"}
        for i=1, (GetNumSubgroupMembers and GetNumSubgroupMembers() or 0) do
            roster[#roster + 1] = "party"..i
        end
        local wanted = kind == "tank" and "TANK" or "DAMAGER"
        if UnitGroupRolesAssigned then
            for _, unit in ipairs(roster) do
                local ok, role = pcall(UnitGroupRolesAssigned, unit)
                if ok and Usable(role) and role == wanted and UnitExists(unit) then
                    return unit
                end
            end
        end
        if kind == "tank" then
            -- Classic parties often leave role assignments blank. This fallback
            -- is a guess, and can select a damage-spec warrior/paladin/druid.
            local tankClasses = {WARRIOR=true,PALADIN=true,DRUID=true,DEATHKNIGHT=true,MONK=true,DEMONHUNTER=true}
            for _, unit in ipairs(roster) do
                if UnitExists(unit) and UnitClass then
                    local ok, _, class = pcall(UnitClass, unit)
                    if ok and Usable(class) and tankClasses[class] then return unit end
                end
            end
            return nil
        end
        -- When party roles are not assigned, prefer a non-healing class.
        local likelyDPS = {HUNTER=true,ROGUE=true,MAGE=true,WARLOCK=true}
        for _, unit in ipairs(roster) do
            if UnitExists(unit) and UnitClass then
                local ok, _, class = pcall(UnitClass, unit)
                if ok and Usable(class) and likelyDPS[class] then return unit end
            end
        end
        return "player"
    end

    local function IsHostile(unit)
        if not unit or not UnitExists(unit) then return false end
        if not UnitCanAttack then return false end
        local ok, hostile = pcall(UnitCanAttack, "player", unit)
        return ok and Usable(hostile) and hostile == true
    end

    local function FindThreatMob(unit)
        if IsHostile("target") then return "target" end
        if unit and IsHostile(unit.."target") then return unit.."target" end
        return nil
    end

    local function ReadThreat(unit, mob)
        local status, pct
        if UnitDetailedThreatSituation then
            local ok, _, st, scaled = pcall(UnitDetailedThreatSituation, unit, mob)
            if ok then
                if Usable(st) and type(st) == "number" then status = st end
                if Usable(scaled) and type(scaled) == "number" then
                    pct = math.max(0, math.min(100, scaled))
                end
            end
        end
        if status == nil and UnitThreatSituation then
            local ok, st = pcall(UnitThreatSituation, unit, mob)
            if ok and Usable(st) and type(st) == "number" then status = st end
        end
        return status, pct
    end

    local function EnsureAlert(kind)
        local cfg = specs[kind]
        if cfg.frame then return cfg.frame end
        local f = CreateFrame("Frame", "GT"..(kind == "tank" and "Tank" or "DPS").."ThreatAlertFrame",
            UIParent, BackdropTemplateMixin and "BackdropTemplate")
        cfg.frame = f
        f:SetSize(240, 70)
        f:SetScale((DB and DB[cfg.prefix.."Scale"] or 100) / 100)
        f:SetFrameStrata("HIGH")
        f:SetClampedToScreen(true)
        f:EnableMouse(true)
        f:SetMovable(true)
        f:RegisterForDrag("LeftButton")
        f:SetScript("OnDragStart", f.StartMoving)
        f:SetScript("OnDragStop", function(self)
            self:StopMovingOrSizing()
            if not DB then return end
            local x, y = self:GetCenter()
            if x and y then
                local scale = self:GetEffectiveScale()/UIParent:GetEffectiveScale()
                DB[cfg.prefix.."Pos"] = {x=x*scale, y=y*scale}
            end
        end)
        local position = DB and DB[cfg.prefix.."Pos"]
        if type(position)=="table" and position.x and position.y then
            f:SetPoint("CENTER", UIParent, "BOTTOMLEFT", position.x, position.y)
        else
            f:SetPoint("CENTER", UIParent, "CENTER", cfg.defaultX, cfg.defaultY)
        end
        ApplyBackdrop(f)
        f.title = f:CreateFontString(nil,"OVERLAY","GameFontNormalSmall")
        f.title:SetPoint("TOPLEFT",10,-9)
        f.title:SetText(cfg.title)
        f.percent = f:CreateFontString(nil,"OVERLAY","GameFontHighlightSmall")
        f.percent:SetPoint("TOPRIGHT",-10,-9)
        local bg = f:CreateTexture(nil,"BACKGROUND")
        bg:SetPoint("TOPLEFT",10,-32)
        bg:SetPoint("TOPRIGHT",-10,-32)
        bg:SetHeight(13)
        bg:SetColorTexture(.10,.13,.18,.95)
        local bar = CreateFrame("StatusBar",nil,f)
        bar:SetPoint("TOPLEFT",bg,"TOPLEFT",1,-1)
        bar:SetPoint("BOTTOMRIGHT",bg,"BOTTOMRIGHT",-1,1)
        bar:SetMinMaxValues(0,100)
        local tex = bar:CreateTexture(nil,"ARTWORK")
        tex:SetColorTexture(1,.3,.2,1)
        bar:SetStatusBarTexture(tex)
        f.bar = bar
        f.caption = f:CreateFontString(nil,"OVERLAY","GameFontDisableSmall")
        f.caption:SetPoint("BOTTOMLEFT",10,8)
        f:Hide()
        return f
    end

    local function Render(kind, f, name, pct, status, preview)
        local cfg = specs[kind]
        f.title:SetText(preview and (cfg.title.." PREVIEW") or (cfg.title..": "..name))
        local danger, label
        if kind == "tank" then
            danger = status ~= nil and status < 2 or (pct and pct <= 85)
            if status ~= nil then
                label = status >= 2 and "Holding aggro" or "Losing aggro"
            end
        else
            danger = status ~= nil and status >= 1 or (pct and pct >= 85)
            if status ~= nil then
                label = status >= 2 and "AGGRO" or (status == 1 and "High threat" or "Low threat")
            end
        end
        if pct ~= nil then
            f.percent:SetText(("%.0f%% Threat"):format(pct))
            f.bar:SetValue(pct)
        else
            f.percent:SetText(label or "Threat status")
            f.bar:SetValue(100) -- Full-width status indicator, NOT a % reading.
        end
        local r,g,b
        if kind == "tank" then
            if danger then r,g,b = 1,.19,.18 else r,g,b = .22,.79,.40 end
        else
            if status and status>=2 or (pct and pct>=100) then r,g,b=1,.17,.16
            elseif danger then r,g,b=1,.53,.12
            else r,g,b=.24,.65,1 end
        end
        f.bar:GetStatusBarTexture():SetColorTexture(r,g,b,1)
        f.percent:SetTextColor(r,g,b)
        f.title:SetTextColor(r,g,b)
        local show = DB and DB[cfg.prefix.."ShowPct"] or cfg.defaultShow
        local hide = DB and DB[cfg.prefix.."HidePct"] or cfg.defaultHide
        f.caption:SetText(pct == nil and "Drag to move  |  Status only (no %)"
            or (show == 100 and "Drag to move  |  Always visible"
                or "Drag to move  |  Recovery: "..hide.."%"))
    end

    GTSetThreatScale = function(kind, value)
        local cfg = specs[kind]
        if cfg and cfg.frame then cfg.frame:SetScale((value or 100)/100) end
    end
    GTSetThreatPreview = function(kind, enabled)
        local cfg = specs[kind]
        if not cfg then return end
        cfg.preview = enabled == true and DB and DB[cfg.prefix.."Tracking"] == true
        if cfg.preview then
            local f = EnsureAlert(kind)
            Render(kind, f, "Preview", DB[cfg.prefix.."ShowPct"] or cfg.defaultShow, nil, true)
            f:Show()
        elseif GTUpdateThreatAlerts then
            GTUpdateThreatAlerts()
        end
    end

    GTUpdateThreatAlerts = function()
        if not DB then return end
        for kind,cfg in pairs(specs) do
            if not cfg.preview then
                if not DB[cfg.prefix.."Tracking"] then
                    cfg.active, cfg.lastUnit, cfg.lastMob = false, nil, nil
                    if cfg.frame then cfg.frame:Hide() end
                else
                    local unit = GetTrackedUnit(kind)
                    local mob = FindThreatMob(unit)
                    if unit ~= cfg.lastUnit or mob ~= cfg.lastMob then
                        cfg.active, cfg.lastUnit, cfg.lastMob = false, unit, mob
                    end
                    if not unit or not mob then
                        cfg.active = false
                        if cfg.frame then cfg.frame:Hide() end
                    else
                        local status, pct = ReadThreat(unit,mob)
                        if status == nil and pct == nil then
                            -- No readable threat: do not fabricate a reading or
                            -- keep showing an out-of-date value.
                            cfg.active = false
                            if cfg.frame then cfg.frame:Hide() end
                        else
                            local show = math.max(0,math.min(100,tonumber(DB[cfg.prefix.."ShowPct"]) or cfg.defaultShow))
                            local hide = math.max(0,math.min(100,tonumber(DB[cfg.prefix.."HidePct"]) or cfg.defaultHide))
                            if show == 100 then
                                cfg.active = true
                            elseif pct ~= nil then
                                -- A real readable percent is needed to honor sliders.
                                if kind == "tank" then
                                    if cfg.active and pct >= hide and (status == nil or status >= 2) then cfg.active = false end
                                    if pct <= show or (status ~= nil and status < 2) then cfg.active = true end
                                else
                                    if cfg.active and pct <= hide and (status == nil or status < 1) then cfg.active = false end
                                    if pct >= show or (status ~= nil and status >= 2) then cfg.active = true end
                                end
                            elseif status ~= nil then
                                -- Threat status is qualitative. Respect aggro
                                -- warning states without inventing a percentage.
                                if kind == "tank" then cfg.active = status < 2
                                else cfg.active = status >= 1 end
                            end
                            if cfg.active then
                                local f = EnsureAlert(kind)
                                local name = UnitName(unit)
                                if not Usable(name) or type(name)~="string" then name = kind == "tank" and "Tank" or "DPS" end
                                Render(kind, f, name, pct, status, false)
                                f:Show()
                            elseif cfg.frame then cfg.frame:Hide() end
                        end
                    end
                end
            end
        end
    end

    -- Draws within the Party Stats window; the preview checkbox exposes the
    -- same scale/activation/recovery controls that the healer alert uses.
    GTBuildThreatControls = function(f)
        if f.threatControlsBuilt then return end
        f.threatControlsBuilt = true
        local function MakeSlider(role, caption, keySuffix, default, step, minValue, maxValue)
            local cfg = specs[role]
            local key = cfg.prefix..keySuffix
            local row = {}
            row.label = f:CreateFontString(nil,"OVERLAY","GameFontHighlightSmall")
            row.label:SetText(caption)
            row.value = f:CreateFontString(nil,"OVERLAY","GameFontHighlightSmall")
            row.slider = CreateFrame("Slider",nil,f,BackdropTemplateMixin and "BackdropTemplate" or nil)
            row.slider:SetSize(120,14)
            row.slider:SetOrientation("HORIZONTAL")
            row.slider:SetMinMaxValues(minValue,maxValue)
            row.slider:SetValueStep(step)
            if row.slider.SetObeyStepOnDrag then row.slider:SetObeyStepOnDrag(true) end
            if row.slider.SetBackdrop then
                row.slider:SetBackdrop({bgFile="Interface\\Buttons\\WHITE8X8"})
                row.slider:SetBackdropColor(.12,.14,.17,1)
            end
            local thumb = row.slider:CreateTexture(nil,"OVERLAY")
            thumb:SetTexture("Interface\\Buttons\\UI-SliderBar-Button-Horizontal")
            thumb:SetSize(18,20)
            row.slider:SetThumbTexture(thumb)
            -- Populate initial value BEFORE installing OnValueChanged. Otherwise
            -- creation invokes the callback before all three sliders exist.
            row.slider:SetValue(DB[key] or default)
            row.value:SetText((DB[key] or default).."%")
            row.slider:SetScript("OnValueChanged", function(self, raw)
                if not DB then return end
                local value = math.floor(raw/step + .5)*step
                value = math.max(minValue,math.min(maxValue,value))
                if keySuffix == "ShowPct" and value < 100 then
                    local hide = DB[cfg.prefix.."HidePct"] or cfg.defaultHide
                    local recovery = f.threatUI[role].recovery
                    if role == "tank" and hide <= value then recovery.slider:SetValue(value+1) end
                    if role == "dps" and hide >= value then recovery.slider:SetValue(math.max(0,value-1)) end
                elseif keySuffix == "HidePct" then
                    local show = DB[cfg.prefix.."ShowPct"] or cfg.defaultShow
                    if show < 100 then
                        if role == "tank" and value <= show then value = math.min(100,show+1) end
                        if role == "dps" and value >= show then value = math.max(0,show-1) end
                    end
                end
                DB[key] = value
                row.value:SetText(value.."%")
                if keySuffix == "Scale" then GTSetThreatScale(role,value) end
                if keySuffix == "ShowPct" then
                    local recovery = f.threatUI[role].recovery
                    if value < 100 then recovery.slider:Enable() else recovery.slider:Disable() end
                    recovery.slider:SetAlpha(value < 100 and 1 or .4)
                    recovery.value:SetText(value == 100 and "N/A" or ((DB[cfg.prefix.."HidePct"] or cfg.defaultHide).."%"))
                end
                if f.threatUI[role].preview:GetChecked() then GTSetThreatPreview(role,true)
                else GTUpdateThreatAlerts() end
            end)
            return row
        end

        f.threatUI = {}
        for _,role in ipairs({"tank","dps"}) do
            local cfg = specs[role]
            local ui = {}
            f.threatUI[role] = ui
            ui.enabled = CreateFrame("CheckButton",nil,f,"UICheckButtonTemplate")
            ui.enabled:SetSize(23,23)
            ui.enabled:SetChecked(DB[cfg.prefix.."Tracking"] == true)
            ui.text = f:CreateFontString(nil,"OVERLAY","GameFontHighlightSmall")
            ui.text:SetPoint("LEFT",ui.enabled,"RIGHT",1,0)
            ui.text:SetText(role == "tank" and "Tank Threat Tracking" or "DPS Threat Tracking")
            ui.enabled:SetScript("OnClick",function(self)
                DB[cfg.prefix.."Tracking"] = GDS_CheckboxChecked(self)
                if not DB[cfg.prefix.."Tracking"] then
                    ui.preview:SetChecked(false)
                    GTSetThreatPreview(role,false)
                end
                if f.RefreshLayout then f.RefreshLayout() end
                GTUpdateThreatAlerts()
            end)
            ui.enabled:SetScript("OnEnter",function(self)
                GameTooltip:SetOwner(self,"ANCHOR_RIGHT")
                GameTooltip:SetText(role == "tank" and "Tank Threat Tracking" or "DPS Threat Tracking")
                GameTooltip:AddLine(role == "tank" and
                    "Warn when the party tank is losing threat on your target. Numeric thresholds work only when threat percentages are available." or
                    "Warn when the selected DPS approaches or pulls aggro on your target. Numeric thresholds work only when threat percentages are available.",.8,.8,.8,true)
                GameTooltip:AddLine("Uses assigned group roles, then class/self fallbacks. Some Forever combat data is protected.",.7,.8,.9,true)
                GameTooltip:Show()
            end)
            ui.enabled:SetScript("OnLeave",function() GameTooltip:Hide() end)
            ui.preview = CreateFrame("CheckButton",nil,f,"UICheckButtonTemplate")
            ui.preview:SetSize(23,23)
            ui.preview:SetChecked(false)
            ui.previewLabel = f:CreateFontString(nil,"OVERLAY","GameFontHighlightSmall")
            ui.previewLabel:SetPoint("LEFT",ui.preview,"RIGHT",1,0)
            ui.previewLabel:SetText("Preview / Move "..(role == "tank" and "Tank" or "DPS").." Alert")
            ui.preview:SetScript("OnClick",function(self)
                if not DB[cfg.prefix.."Tracking"] then
                    self:SetChecked(false)
                    DEFAULT_CHAT_FRAME:AddMessage("|cFFD8DDE6Grind Dont Stop|r Enable "..cfg.title.." tracking first.")
                    return
                end
                GTSetThreatPreview(role,GDS_CheckboxChecked(self))
                if f.RefreshLayout then f.RefreshLayout() end
            end)
            ui.scale = MakeSlider(role,"Alert size","Scale",100,5,70,160)
            ui.activate = MakeSlider(role,"Activate at","ShowPct",cfg.defaultShow,1,role == "dps" and 1 or 0,100)
            ui.recovery = MakeSlider(role,"Disappear at","HidePct",cfg.defaultHide,1,0,100)
            -- Set initial disabled state after both sliders have been created.
            if (DB[cfg.prefix.."ShowPct"] or cfg.defaultShow) >= 100 then
                ui.recovery.slider:Disable()
                ui.recovery.slider:SetAlpha(.4)
                ui.recovery.value:SetText("N/A")
            end
        end

        local function Position(widget,x,y)
            widget:ClearAllPoints()
            widget:SetPoint("TOPLEFT",f,"TOPLEFT",x,y)
        end
        f.RefreshLayout = function()
            local optional = f.optionalCB and GDS_CheckboxChecked(f.optionalCB)
            -- The compact default keeps only Mini, Optional, and the shared
            -- party-session controls visible. Alert settings expand on demand.
            f.manaCB:SetShown(optional)
            f.manaLabel:SetShown(optional)
            f.manaDedication:SetShown(optional)
            f.previewCB:SetShown(optional)
            f.previewLabel:SetShown(optional)
            local manaExpanded = optional and f.previewCB:GetChecked()
                and DB.healerManaTracking
            local y = -97
            if optional then
                Position(f.manaCB,7,y)
                Position(f.previewCB,18,y-28)
                if f.manaSliders then
                    for i,widgets in ipairs(f.manaSliders) do
                        local at = y-57-(i-1)*35
                        Position(widgets[1],13,at)
                        Position(widgets[2],i==1 and 87 or 110,at-2)
                        widgets[3]:ClearAllPoints()
                        widgets[3]:SetPoint("TOPRIGHT",f,"TOPRIGHT",-15,at)
                        for _,widget in ipairs(widgets) do
                            widget:SetShown(manaExpanded == true)
                        end
                    end
                end
                y = y - (manaExpanded and 169 or 59)
            else
                if f.manaSliders then
                    for _,widgets in ipairs(f.manaSliders) do
                        for _,widget in ipairs(widgets) do widget:Hide() end
                    end
                end
            end
            for _,role in ipairs({"tank","dps"}) do
                local ui = f.threatUI[role]
                ui.enabled:SetShown(optional)
                ui.text:SetShown(optional)
                ui.preview:SetShown(optional)
                ui.previewLabel:SetShown(optional)
                local expanded = optional and GDS_CheckboxChecked(ui.preview)
                    and DB[specs[role].prefix.."Tracking"] == true
                if optional then
                    Position(ui.enabled,7,y)
                    Position(ui.preview,18,y-29)
                end
                for i,row in ipairs({ui.scale,ui.activate,ui.recovery}) do
                    if optional then
                        local at = y-58-(i-1)*35
                        Position(row.label,13,at)
                        Position(row.slider,116,at-2)
                        row.value:ClearAllPoints()
                        row.value:SetPoint("TOPRIGHT",f,"TOPRIGHT",-15,at)
                    end
                    row.label:SetShown(expanded)
                    row.slider:SetShown(expanded)
                    row.value:SetShown(expanded)
                end
                if optional then y = y - (expanded and 170 or 65) end
            end
            y = GDS_PartySession.PositionUI(f,y-5)
            local line = ((DB and DB.questTracking) and 54 or 31)
                + ((DB and DB.pvpTracking) and 25 or 0)
            local rowTop = y-13
            local count = math.max(1,math.min(#(f.rows or {}), f.visibleStatsRows or 1))
            for i,row in ipairs(f.rows or {}) do
                row:ClearAllPoints()
                row:SetPoint("TOPLEFT",f,"TOPLEFT",10,rowTop - (i-1)*line)
                row:SetWidth(f:GetWidth()-20)
                row:SetShown(i<=count)
            end
            f:SetHeight(math.max(275,-rowTop + count*line + 16))
        end
        f.RefreshLayout()
    end
end


function GDS_PartySession.SetupUI(f)
    if f.partySessionUI then return end
    local ui={}
    f.partySessionUI=ui
    local function Text(label)
        local fs=f:CreateFontString(nil,"OVERLAY","GameFontHighlightSmall")
        fs:SetText(label)
        return fs
    end
    local function Button(label,width,handler)
        local b=CreateFrame("Button",nil,f,"UIPanelButtonTemplate")
        b:SetSize(width,21)
        b:SetText(label)
        b:SetScript("OnClick",handler)
        return b
    end
    ui.title=Text("|cFFFFD27DShared Party Session|r")
    ui.status=Text("Not started")
    ui.start=Button("Start Party",100,function() GDS_PartySession.Start() end)
    ui.pause=Button("Pause",72,function() GDS_PartySession.TogglePause() end)
    ui.ending=Button("End",57,function() GDS_PartySession.Stop() end)
    ui.available=Text("Available addon players (invite individually):")
    ui.rows={}
    for i=1,4 do
        local row={}
        row.name=Text("")
        row.name:SetWidth(208)
        row.name:SetJustifyH("LEFT")
        row.button=Button("Invite",65,function()
            if row.player then GDS_PartySession.Invite(row.player) end
        end)
        ui.rows[i]=row
    end
    GDS_PartySession.RefreshUI()
end
function GDS_PartySession.PositionUI(f,y)
    local ui=f.partySessionUI
    if not ui then return y end
    local function position(w,x,dy)
        w:ClearAllPoints()
        w:SetPoint("TOPLEFT",f,"TOPLEFT",x,dy)
    end
    position(ui.title,12,y)
    position(ui.status,12,y-18)
    position(ui.start,12,y-37)
    position(ui.pause,115,y-37)
    position(ui.ending,191,y-37)
    position(ui.available,12,y-63)
    local shown = 0
    for i,row in ipairs(ui.rows) do
        local exists = row.player ~= nil
        row.name:SetShown(exists)
        row.button:SetShown(exists)
        if exists then
            shown=shown+1
            position(row.name,16,y-82-(shown-1)*22)
            position(row.button,230,y-81-(shown-1)*22)
        end
    end
    return y-87-shown*22
end
function GDS_PartySession.RefreshUI()
    local f=partyFrame
    local ui=f and f.partySessionUI
    if not ui then return end
    local a=GDS_PartySession.active
    local ready=PartyAvailable()
    ui.status:SetText(not ready and "Enable P and join a party"
        or not a and "Not started (host starts, then invites)"
        or (a.isHost and "Hosting: " or "Joined: ") .. (a.paused and "Paused" or "Running"))
    ui.start:SetEnabled(ready and not a)
    ui.pause:SetEnabled(ready and a and a.isHost)
    ui.pause:SetText(a and a.paused and "Resume" or "Pause")
    ui.ending:SetEnabled(a ~= nil)
    local available={}
    if ready then
        for sender,when in pairs(GDS_PartySession.capable) do
            if GetTime()-when < 90 and PartyMember(sender) then
                available[#available+1]=sender
            end
        end
    end
    table.sort(available)
    for i,row in ipairs(ui.rows) do
        local name=available[i]
        row.player=name
        row.name:SetText(name or "")
        local accepted=a and a.accepted and name and GDS_PartySession.FindName(a.accepted,name)
        local pending=name and GDS_PartySession.FindName(GDS_PartySession.pending,name)
        row.button:SetText(accepted and "Joined" or pending and "Pending" or "Invite")
        row.button:SetEnabled(name ~= nil and a ~= nil and a.isHost and not accepted and not pending)
        row.button:SetShown(name ~= nil)
    end
end

-- Independent, draggable mini leaderboard; stays visible when Settings closes.
-- Columns: Player | Earned | GPH | Grind XP | Time. XP excludes quest rewards.
-- The checkbox in Party Stats and the X button both control this same setting.
EnsurePartyMini = function()
    if partyMiniFrame then return partyMiniFrame end
    local f = CreateFrame("Frame", "GTPartyMiniFrame", UIParent,
        BackdropTemplateMixin and "BackdropTemplate")
    partyMiniFrame = f
    f:SetSize(math.max(440, (DB and DB.partyMiniW) or 440), (DB and DB.partyMiniH) or 224)
    f:SetFrameStrata("MEDIUM")
    f:SetClampedToScreen(true)
    f:EnableMouse(true)
    f:SetMovable(true)
    f:RegisterForDrag("LeftButton")
    f:SetScript("OnDragStart", f.StartMoving)
    f:SetScript("OnDragStop", function(self)
        self:StopMovingOrSizing()
        local x, y = self:GetCenter()
        if x and y and DB then
            local scale = self:GetEffectiveScale() / UIParent:GetEffectiveScale()
            DB.partyMiniPos = {x=x * scale, y=y * scale}
        end
    end)
    if DB and type(DB.partyMiniPos) == "table" and DB.partyMiniPos.x and DB.partyMiniPos.y then
        f:SetPoint("CENTER", UIParent, "BOTTOMLEFT", DB.partyMiniPos.x, DB.partyMiniPos.y)
    else
        f:SetPoint("LEFT", UIParent, "LEFT", 24, 0)
    end
    ApplyBackdrop(f)
    local title = f:CreateFontString(nil, "OVERLAY", "GameFontNormal")
    title:SetPoint("TOPLEFT", 11, -12)
    title:SetText("Party |cFFFFD27DGrind Don't Stop|r")
    local close = MakeBtn(f, 19, 19, "X")
    close:SetPoint("TOPRIGHT", -6, -6)
    close:SetScript("OnClick", function() SetPartyMiniVisible(false) end)

    -- Separate header cells share their boundaries with the data cells.
    -- Right-aligned numeric columns remain aligned at every window width.
    local function header(text, justify)
        local fs = f:CreateFontString(nil, "OVERLAY", "GameFontDisableSmall")
        fs:SetPoint("TOP", f, "TOP", 0, -38)
        fs:SetHeight(15)
        fs:SetJustifyH(justify or "LEFT")
        fs:SetText(text)
        return fs
    end
    local headers = {
        name = header("PLAYER"), earned = header("EARNED", "RIGHT"),
        gph = header("GPH", "RIGHT"), xp = header("XP", "RIGHT"),
        time = header("TIME", "RIGHT"),
    }
    f.status = f:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
    f.status:SetPoint("TOPLEFT", 12, -66)
    f.status:SetPoint("RIGHT", f, "RIGHT", -12, 0)
    f.status:SetJustifyH("LEFT")
    f.rows = {}
    for i=1,5 do
        local row = CreateFrame("Frame", nil, f)
        row:SetPoint("TOPLEFT", 8, -59 - (i-1)*30)
        row:SetPoint("RIGHT", f, "RIGHT", -8, 0)
        row:SetHeight(29)
        local bg = row:CreateTexture(nil,"BACKGROUND")
        bg:SetAllPoints()
        if i%2==1 then bg:SetColorTexture(.5,.5,.5,.085) end
        local function cell(justify)
            local fs=row:CreateFontString(nil,"OVERLAY","GameFontHighlightSmall")
            fs:SetHeight(26)
            fs:SetJustifyH(justify or "LEFT")
            fs:SetWordWrap(false)
            return fs
        end
        local qxp = row:CreateFontString(nil, "OVERLAY", "GameFontDisableSmall")
        qxp:SetJustifyH("LEFT")
        local qgold = row:CreateFontString(nil, "OVERLAY", "GameFontDisableSmall")
        qgold:SetJustifyH("LEFT")
        local hkText = row:CreateFontString(nil, "OVERLAY", "GameFontDisableSmall")
        hkText:SetJustifyH("LEFT")
        local kbText = row:CreateFontString(nil, "OVERLAY", "GameFontDisableSmall")
        kbText:SetJustifyH("RIGHT")
        f.rows[i]={frame=row, name=cell(), earned=cell("RIGHT"),
            gph=cell("RIGHT"), xp=cell("RIGHT"), time=cell("RIGHT"), questXP=qxp, questGold=qgold,
            pvpHK=hkText, pvpKB=kbText}
    end
    local foot = f:CreateFontString(nil,"OVERLAY","GameFontDisableSmall")
    foot:SetPoint("BOTTOMLEFT", 11, 8)
    foot:SetText("Drag to move  |  Syncs every 10s")
    f.syncFoot = foot

    -- Resize by dragging the bottom-right corner, with width/height saved.
    f:SetResizable(true)
    f:SetResizeBounds(440, 120, 640, 440)
    local grip = CreateFrame("Button", nil, f)
    grip:SetSize(16, 16)
    grip:SetPoint("BOTTOMRIGHT", 0, 0)
    local tex = grip:CreateTexture(nil, "OVERLAY")
    tex:SetAllPoints()
    tex:SetTexture("Interface\\ChatFrame\\UI-ChatIM-SizeGrabber-Up")
    grip:SetHighlightTexture("Interface\\ChatFrame\\UI-ChatIM-SizeGrabber-Highlight")
    grip:SetPushedTexture("Interface\\ChatFrame\\UI-ChatIM-SizeGrabber-Down")
    grip:RegisterForDrag("LeftButton")
    grip:SetScript("OnDragStart", function() f:StartSizing("BOTTOMRIGHT") end)
    grip:SetScript("OnDragStop", function()
        f:StopMovingOrSizing()
        if DB then
            DB.partyMiniW = math.floor(f:GetWidth()+.5)
            DB.partyMiniH = math.floor(f:GetHeight()+.5)
        end
    end)
    grip:SetScript("OnEnter", function(self)
        GameTooltip:SetOwner(self, "ANCHOR_TOP")
        GameTooltip:SetText("Resize party window")
        GameTooltip:Show()
    end)
    grip:SetScript("OnLeave", function() GameTooltip:Hide() end)

    local function layout()
        local width, height = f:GetWidth(), f:GetHeight()
        -- Right edge of Time is 7px from the inner row edge; other columns
        -- use matching anchors in both header and data rows.
        local function column(fs, parent, right, w)
            fs:ClearAllPoints()
            fs:SetPoint("RIGHT", parent, "RIGHT", right, 0)
            fs:SetWidth(w)
        end
        -- Header edges match the exact right edges of the data cells.
        local function headerRight(fs, x, w)
            fs:ClearAllPoints()
            fs:SetPoint("TOPRIGHT", f, "TOPRIGHT", x, -38)
            fs:SetWidth(w)
        end
        headerRight(headers.time, -15, 62)
        headerRight(headers.xp, -91, 74)
        headerRight(headers.gph, -172, 70)
        headerRight(headers.earned, -255, 75)
        headers.name:ClearAllPoints()
        headers.name:SetPoint("TOPLEFT", f, "TOPLEFT", 13, -38)
        headers.name:SetWidth(math.max(65, width-350))
        local questMode = DB and DB.questTracking == true
        local pvpMode = DB and DB.pvpTracking == true
        local rowStep = 30 + (questMode and 32 or 0) + (pvpMode and 24 or 0)
        local mainOffset = (rowStep - 30) / 2
        for i,r in ipairs(f.rows) do
            r.frame:ClearAllPoints()
            r.frame:SetPoint("TOPLEFT", f, "TOPLEFT", 8, -59-(i-1)*rowStep)
            r.frame:SetPoint("RIGHT", f, "RIGHT", -8, 0)
            r.frame:SetHeight(rowStep - 1)
            column(r.time, r.frame, -7, 62)
            column(r.xp, r.frame, -83, 74)
            column(r.gph, r.frame, -164, 70)
            column(r.earned, r.frame, -247, 75)
            if mainOffset > 0 then
                for _, entry in ipairs({{r.time,-7},{r.xp,-83},{r.gph,-164},{r.earned,-247}}) do
                    entry[1]:ClearAllPoints()
                    entry[1]:SetPoint("RIGHT", r.frame, "RIGHT", entry[2], mainOffset)
                end
            end
            r.name:ClearAllPoints()
            r.name:SetPoint("LEFT", r.frame, "LEFT", 5, mainOffset)
            r.name:SetWidth(math.max(65, width-350))
            r.questXP:ClearAllPoints()
            r.questXP:SetPoint("TOPLEFT", r.frame, "TOPLEFT", 5, -36)
            r.questXP:SetWidth(math.max(65, (width-24)*0.53))
            r.questGold:ClearAllPoints()
            r.questGold:SetPoint("TOPRIGHT", r.frame, "TOPRIGHT", -7, -36)
            r.questGold:SetWidth(math.max(65, (width-24)*0.44))
            r.questGold:SetJustifyH("RIGHT")
            r.questXP:SetShown(questMode)
            r.questGold:SetShown(questMode)
            local pvpY = questMode and -60 or -36
            r.pvpHK:ClearAllPoints()
            r.pvpHK:SetPoint("TOPLEFT", r.frame, "TOPLEFT", 5, pvpY)
            r.pvpHK:SetWidth(math.max(65, (width-24)*0.53))
            r.pvpKB:ClearAllPoints()
            r.pvpKB:SetPoint("TOPRIGHT", r.frame, "TOPRIGHT", -7, pvpY)
            r.pvpKB:SetWidth(math.max(65, (width-24)*0.44))
            r.pvpHK:SetShown(pvpMode)
            r.pvpKB:SetShown(pvpMode)
            -- Reserve bottom space for the footer; resizing smaller hides rows.
            r.frame:SetShown(r._hasEntry and (59+(i-1)*rowStep+(rowStep-1) <= height-24) or false)
        end
    end
    f.LayoutPartyMini = layout
    f:SetScript("OnSizeChanged", layout)
    layout()
    f:Hide()
    return f
end

SetPartyMiniVisible = function(visible)
    if not DB then return end
    DB.partyMiniVisible = visible == true
    if partyFrame and partyFrame.miniCB then
        partyFrame.miniCB:SetChecked(DB.partyMiniVisible)
    end
    if DB.partyMiniVisible then
        EnsurePartyMini():Show()
        if RefreshPartyStats then RefreshPartyStats() end
    elseif partyMiniFrame then
        partyMiniFrame:Hide()
    end
end

RefreshPartyStats = function()
    local showLarge = partyFrame and partyFrame:IsShown()
    local showMini = partyMiniFrame and partyMiniFrame:IsShown()
    if not showLarge and not showMini then return end
    if showLarge then
        GDS_PartySession.RefreshUI()
        for _, row in ipairs(partyFrame.rows) do row:SetText("") end
        partyFrame.visibleStatsRows = 1
    end
    local reason
    if not DB or (not DB.partyTracking and not DB.questTracking and not DB.pvpTracking) then
        reason = "Enable Party Tracking by the title, or Quest / PvP Tracking in Settings."
    end
    if not reason and not GDS_PartySession.active then
        reason="No shared party session. Use Start Party, then invite addon players."
    end
    if reason then
        if showLarge then
            partyFrame.rows[1]:SetText(reason)
            partyFrame.visibleStatsRows = 1
            if partyFrame.RefreshLayout then partyFrame.RefreshLayout() end
        end
        if showMini then
            partyMiniFrame.status:SetText(reason)
            for _, row in ipairs(partyMiniFrame.rows) do row.frame:Hide() end
        end
        return
    end
    local entries = {}
    local function add(name, stat)
        local total = (stat.coin or 0) + (stat.items or 0)
        entries[#entries+1] = {name=name, total=total, gph=stat.timer > 0 and total*3600/stat.timer or 0,
            xp=stat.xp, timer=stat.timer, kills=stat.kills or 0, running=stat.running,
            questXP=stat.questXP or 0, questGold=stat.questGold or 0, questOn=stat.questOn,
            pvpHK=stat.pvpHK or 0, pvpKB=stat.pvpKB or 0, pvpOn=stat.pvpOn}
    end
    local shared=GDS_PartySession.active
    if shared and PartyAvailable() then
        add((UnitName and UnitName("player") or "You") .. " (You)", {
            timer=shared.timer,coin=shared.coin,items=shared.items,
            xp=math.max(0,shared.xpRaw-shared.questXP),running=not shared.paused,
            questXP=shared.questXP,questGold=shared.questGold,questOn=DB.questTracking,
            pvpHK=shared.pvpHK,pvpKB=shared.pvpKB,pvpOn=DB.pvpTracking,
        })
        for name,stat in pairs(GDS_PartySession.peers) do
            if GetTime()-(stat.received or 0)<40 and PartyMember(name)
                and (not shared.isHost
                    or GDS_PartySession.FindName(shared.accepted,name)) then
                add(name,stat)
            end
        end
    end
    table.sort(entries, function(a,b) return a.total > b.total end)
    if showMini and partyMiniFrame.syncFoot then
        if PartyAvailable() and #entries == 1 then
            local run=GDS_PartySession.active
            partyMiniFrame.syncFoot:SetText(run and run.isHost
                and not next(run.accepted or {}) and "Invite players in Party Stats"
                or "Waiting for shared-session player stats  |  /gt partystatus")
        else
            partyMiniFrame.syncFoot:SetText("Party session  |  Syncs every 10s")
        end
    end
    if showLarge then
        for i=1,math.min(#entries, #partyFrame.rows) do
            local e = entries[i]
            local text = ("%d. %s%s\n%s  |  %s/h  |  %s"):format(i, e.name,
                e.running and "" or " (idle)", CoinShort(e.total),
                CoinShort(math.floor(e.gph)), FormatTime(e.timer))
            if DB.questTracking then
                text = text .. "\nQuest XP: " .. (e.questOn and FmtNum(e.questXP) or "--")
                    .. "  Quest Gold: " .. (e.questOn and CoinShort(e.questGold) or "--")
            end
            if DB.pvpTracking then
                text = text .. "\nHonorable Kills: " .. (e.pvpOn and FmtNum(e.pvpHK) or "--")
                    .. "  Killing Blows: " .. (e.pvpOn and FmtNum(e.pvpKB) or "--")
            end
            partyFrame.rows[i]:SetText(text)
        end
        partyFrame.visibleStatsRows = math.max(1,math.min(#entries,#partyFrame.rows))
        if PartyAvailable() and #entries == 1 and partyFrame.rows[2] then
            partyFrame.rows[2]:SetText("|cFFAAAAAAWaiting for party data. Type /gt partystatus to check connection.|r")
            partyFrame.visibleStatsRows = 2
        end
        if partyFrame.RefreshLayout then partyFrame.RefreshLayout() end
    end
    if showMini then
        partyMiniFrame.status:SetText("")
        for i,row in ipairs(partyMiniFrame.rows) do
            local e = entries[i]
            row._hasEntry = e ~= nil
            if e then
                local nm=e.name:gsub("%-.*$", "")
                if #nm>15 then nm=nm:sub(1,13)..".." end
                row.name:SetText((i..". "..nm)..(e.running and "" or " |cFF999999*|r"))
                row.earned:SetText(CoinShort(e.total))
                row.gph:SetText(CoinShort(math.floor(e.gph)))
                row.xp:SetText(e.xp ~= nil and FmtNum(e.xp) or "--")
                row.time:SetText(FmtShort(e.timer))
                row.questXP:SetText("Quest XP: " .. (e.questOn and FmtNum(e.questXP) or "--"))
                row.questGold:SetText("Quest Gold: " .. (e.questOn and CoinShort(e.questGold) or "--"))
                row.pvpHK:SetText("HKs: " .. (e.pvpOn and FmtNum(e.pvpHK) or "--"))
                row.pvpKB:SetText("Killing Blows: " .. (e.pvpOn and FmtNum(e.pvpKB) or "--"))
            end
        end
        if partyMiniFrame.LayoutPartyMini then partyMiniFrame.LayoutPartyMini() end
    end
end

-------------------------------------------------------------------------------
-- LOOT LOG WINDOW
-------------------------------------------------------------------------------
local function ToggleLootLog()
    if lootFrame:IsShown() then
        lootFrame:Hide()
    else
        GDS_TabSwitcher.CloseOthers("GTLootFrame")
        RepriceCurrentLoot(true)
        lootFrame:Show()
        SetAnalyticsTab(activeTab)
    end
end

-------------------------------------------------------------------------------
-- ANALYTICS CHARTS
-------------------------------------------------------------------------------
local PIE_COLORS = {
    {1.00,0.82,0.00},{0.00,0.70,1.00},{0.12,1.00,0.00},
    {0.80,0.20,0.90},{1.00,0.45,0.00},{0.20,0.90,0.80},
    {0.90,0.30,0.30},{0.60,0.60,0.60},
}

-- Build topKeys/keyName/keyColor from a sorted [{name, total}] list.
-- Items named "__other__" and "__coin__" get fixed display names and colors.
local function MakeItemColors(sortedItems)
    local topKeys, keyName, keyColor = {}, {}, {}
    for i, item in ipairs(sortedItems) do
        local nm = item.name
        table.insert(topKeys, nm)
        keyName[nm]  = nm == "__other__" and "Other"
                    or nm == "__coin__"  and "Coin"
                    or nm
        keyColor[nm] = nm == "__other__" and {0.60,0.60,0.60}
                    or PIE_COLORS[i] or PIE_COLORS[#PIE_COLORS]
    end
    return topKeys, keyName, keyColor
end

local function RebuildCanvas(frame)
    if frame._canvas then
        if frame._canvas._gtPieHover or frame._canvas._gtComparisonHover then GameTooltip:Hide() end
        frame._canvas:SetParent(nil)
        frame._canvas:Hide()
    end
    local c = CreateFrame("Frame", nil, frame)
    c:SetAllPoints()
    frame._canvas = c
    return c
end

ShowComparisonGraphs = function(first, second)
    if not first or not second then return end
    local colors = {{0.30, 0.72, 1.0}, {1.0, 0.72, 0.22}}
    if not comparisonGraphsFrame then
        local f = CreateFrame("Frame", "GTComparisonGraphsFrame", UIParent,
            BackdropTemplateMixin and "BackdropTemplate")
        GDS_FocusWindow(f)
        comparisonGraphsFrame = f
        f:SetSize(680, 500)
        f:SetPoint("CENTER", 30, -20)
        f:SetFrameStrata("DIALOG")
        f:SetClampedToScreen(true)
        f:EnableMouse(true); f:SetMovable(true); f:RegisterForDrag("LeftButton")
        f:SetScript("OnDragStart", f.StartMoving)
        f:SetScript("OnDragStop", f.StopMovingOrSizing)
        ApplyBackdrop(f)
        local title = f:CreateFontString(nil, "OVERLAY", "GameFontNormalLarge")
        title:SetPoint("TOP", 0, -12)
        title:SetText("Comparison Graphs")
        local theme = DB.theme or DEFAULT_THEME
        title:SetTextColor(theme.accentR, theme.accentG, theme.accentB)
        table.insert(GT_titles, title)
        local close = MakeBtn(f, 20, 20, "X")
        close:SetPoint("TOPRIGHT", -6, -6)
        close:SetScript("OnClick", function() f:Hide() end)
        f.legend = f:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
        f.legend:SetPoint("TOP", 0, -40); f.legend:SetWidth(648); f.legend:SetHeight(34)
        TrackThemeText(f.legend)
        f.plot = CreateFrame("Frame", nil, f)
        f.plot:SetPoint("TOPLEFT", 14, -92); f.plot:SetSize(652, 292)
        f.note = f:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
        f.note:SetPoint("TOP", 0, -402); f.note:SetWidth(644); f.note:SetHeight(44)
        TrackThemeText(f.note)
        f.tabs = {}
        for i, label in ipairs({"Gold Overlap", "Hourly Rates & Time"}) do
            local button = MakeBtn(f, 240, 26, label)
            button:SetPoint("BOTTOMLEFT", 96+(i-1)*248, 14)
            button:SetScript("OnClick", function()
                f.mode = i
                ShowComparisonGraphs(f.first, f.second)
            end)
            f.tabs[i] = button
        end
        f.mode = 1
        local back = MakeBtn(f, 170, 24, "Back to Totals")
        back:SetPoint("TOPRIGHT", -30, -10)
        back:SetScript("OnClick", function() ShowSessionComparison(f.first, f.second) end)
    end
    local f = comparisonGraphsFrame
    if comparisonFrame and comparisonFrame:IsShown() then
        CopyComparisonPosition(f, comparisonFrame)
        comparisonFrame:Hide()
    end
    f.first, f.second = first, second
    local function RunLabel(session)
        return (session.zone and session.zone ~= "" and session.zone or "Area not recorded")
            .." - "..GDS_HistoryDate.Format(session.date)
    end
    f.legend:SetText("|cFF4DB8FFRun A: "..RunLabel(first).."|r\n|cFFFFB838Run B: "..RunLabel(second).."|r")
    local canvas = RebuildCanvas(f.plot)
    local function Text(x, y, width, value, align)
        local label = canvas:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
        label:SetPoint("BOTTOMLEFT", x, y); label:SetWidth(width)
        label:SetJustifyH(align or "LEFT"); TrackThemeText(label); label:SetText(value)
        return label
    end
    local function Line(x1, y1, x2, y2, color, thickness)
        local line = canvas:CreateLine()
        line:SetStartPoint("BOTTOMLEFT", canvas, x1, y1)
        line:SetEndPoint("BOTTOMLEFT", canvas, x2, y2)
        line:SetColorTexture(color[1], color[2], color[3], 0.95)
        line:SetThickness(thickness or 2)
    end
    if f.mode == 1 then
        local a, da, va = ComparisonGoldSeries(first)
        local b, db, vb = ComparisonGoldSeries(second)
        if not a or not b then
            Text(32, 138, 588, "Both runs need saved timeline data and tracked time for overlap.", "CENTER")
            f.note:SetText("You can still compare these runs using Hourly Rates & Time.")
        else
            local maxTime, maxValue = math.max(da, db, 1), math.max(va, vb, 1)
            local left, bottom, width, height = 74, 32, 558, 234
            for i=0,4 do
                local y = bottom+height*i/4
                Line(left, y, left+width, y, {0.25,0.25,0.25}, 1)
                Text(0, y-5, 68, CoinShort(maxValue*i/4), "RIGHT")
            end
            for i=0,4 do
                Text(left+width*i/4-24, 10, 48, ("%.1fm"):format(maxTime*i/4/60), "CENTER")
            end
            for index, series in ipairs({a,b}) do
                for i=2,#series do
                    local previous, point = series[i-1], series[i]
                    Line(left+previous.time/maxTime*width, bottom+previous.value/maxValue*height,
                        left+point.time/maxTime*width, bottom+point.value/maxValue*height, colors[index])
                end
                local last = series[#series]
                local dot = canvas:CreateTexture(nil, "OVERLAY")
                dot:SetSize(6,6)
                dot:SetPoint("CENTER", canvas, "BOTTOMLEFT", left+last.time/maxTime*width,
                    bottom+last.value/maxValue*height)
                dot:SetColorTexture(unpack(colors[index]))
            end
            local cursorLine = canvas:CreateLine()
            cursorLine:SetColorTexture(0.9,0.9,0.9,0.45); cursorLine:SetThickness(1); cursorLine:Hide()
            canvas:EnableMouse(true)
            local function ClearHover()
                if canvas._gtComparisonHover then GameTooltip:Hide() end
                canvas._gtComparisonHover = nil
                cursorLine:Hide()
            end
            canvas:SetScript("OnLeave", ClearHover)
            canvas:SetScript("OnHide", ClearHover)
            local tick = 0
            canvas:SetScript("OnUpdate", function(self, elapsed)
                tick = tick + elapsed
                if tick < 0.05 then return end
                tick = 0
                if not self:IsMouseOver() then ClearHover(); return end
                local mx, my = GetCursorPosition()
                local scale = self:GetEffectiveScale()
                local x, y = mx/scale-self:GetLeft(), my/scale-self:GetBottom()
                if x < left or x > left+width or y < bottom or y > bottom+height then ClearHover(); return end
                local seconds = (x-left)/width*maxTime
                cursorLine:SetStartPoint("BOTTOMLEFT", self, x, bottom)
                cursorLine:SetEndPoint("BOTTOMLEFT", self, x, bottom+height)
                cursorLine:Show()
                self._gtComparisonHover = true
                GameTooltip:SetOwner(self, "ANCHOR_CURSOR")
                GameTooltip:SetText("Elapsed "..FormatTime(seconds))
                for index, series in ipairs({a,b}) do
                    local point, gained, ended = ComparisonHoverSample(series, seconds)
                    local color = colors[index]
                    GameTooltip:AddLine((index == 1 and "Run A" or "Run B").." - "..
                        (ended and "Ended at " or "Sample at ")..FormatTime(point.time), color[1], color[2], color[3])
                    GameTooltip:AddLine("Total: "..Coin(point.value).."   Sample gain: "..Coin(gained), 1,1,1)
                end
                GameTooltip:AddLine("Nearest saved samples; earnings are recorded in minute buckets.", 0.7,0.7,0.7)
                GameTooltip:Show()
            end)
            f.note:SetText("Hover over the plot for timestamps, total earnings, and sample gains.\nEach line ends when its run ends. Hover values use saved minute samples.")
        end
    else
        local a, b = SessionComparisonStats(first), SessionComparisonStats(second)
        local metrics = {{"Gold / Hour", "gph", Coin}, {"XP / Hour", "xph", FmtNum},
            {"Kills / Hour", "kph", FmtNum},
            {"Tracked Time (hours)", "duration", function(value) return ("%.3f h"):format(value/3600) end}}
        for i, metric in ipairs(metrics) do
            local y = 274-(i-1)*72
            Text(0, y, 230, metric[1])
            local maximum = math.max(a[metric[2]], b[metric[2]], 1)
            for index, stats in ipairs({a,b}) do
                local value = stats[metric[2]]
                local available = metric[2] == "duration" or stats.hasRate
                local barY = y-18-(index-1)*18
                Text(0, barY, 20, index == 1 and "A" or "B")
                local track = canvas:CreateTexture(nil, "BACKGROUND")
                track:SetPoint("BOTTOMLEFT", 28, barY); track:SetSize(438,12)
                track:SetColorTexture(0.18,0.18,0.18,0.6)
                if available and value > 0 then
                    local fill = canvas:CreateTexture(nil, "ARTWORK")
                    fill:SetPoint("BOTTOMLEFT", 28, barY); fill:SetSize(438*value/maximum,12)
                    fill:SetColorTexture(unpack(colors[index]))
                end
                Text(476, barY, 170, available and metric[3](value) or "N/A", "RIGHT")
                local hit = CreateFrame("Frame", nil, canvas)
                hit:SetPoint("BOTTOMLEFT", 28, barY); hit:SetSize(438,12); hit:EnableMouse(true)
                hit:SetScript("OnEnter", function()
                    canvas._gtComparisonHover = true
                    GameTooltip:SetOwner(hit, "ANCHOR_CURSOR")
                    GameTooltip:SetText((index == 1 and "Run A - " or "Run B - ")..metric[1])
                    GameTooltip:AddLine(available and metric[3](value) or "N/A", 1,1,1)
                    GameTooltip:AddLine("Tracked time: "..FormatTime(stats.duration), 1,1,1)
                    GameTooltip:AddLine("Total earnings: "..Coin(stats.total), 1,1,1)
                    GameTooltip:Show()
                end)
                local function ClearBarHover()
                    if canvas._gtComparisonHover then GameTooltip:Hide() end
                    canvas._gtComparisonHover = nil
                end
                hit:SetScript("OnLeave", ClearBarHover)
                hit:SetScript("OnHide", ClearBarHover)
            end
        end
        f.note:SetText("Each metric has its own scale; compare A and B within the same pair.\nHourly rates use tracked time. Gold includes saved coin and item value.")
    end
    for i, button in ipairs(f.tabs) do
        button:SetAlpha(f.mode == i and 1 or 0.65)
    end
    f:Show(); f:Raise()
end

local function GetMinuteGold()
    local byMin, maxMin = {}, 0
    for _, it in ipairs(S and S.loot or {}) do
        if not GDS_QuestItems.EntryIsQuest(it) then
            local m = math.floor(it.time / 60)
            byMin[m] = (byMin[m] or 0) + it.total
            if m > maxMin then maxMin = m end
        end
    end
    for m, v in pairs(S and S.coinByMinute or {}) do
        byMin[m] = (byMin[m] or 0) + v
        if m > maxMin then maxMin = m end
    end
    return byMin, maxMin
end

local function NoDataMsg(canvas)
    local fs = canvas:CreateFontString(nil,"OVERLAY","GameFontNormalSmall")
    fs:SetPoint("CENTER"); fs:SetJustifyH("CENTER")
    TrackThemeText(fs)
    fs:SetText("No data yet.\nStart a session and loot items.")
end

local function ChartTitle(canvas, text)
    local ttl = canvas:CreateFontString(nil,"OVERLAY","GameFontNormalSmall")
    ttl:SetPoint("TOP", canvas, "TOP", 0, -3)
    TrackThemeText(ttl)
    ttl:SetText(text)
end

local function GTAtan2(y, x)
    if x > 0 then return math.atan(y / x) end
    if x < 0 and y >= 0 then return math.atan(y / x) + math.pi end
    if x < 0 and y < 0 then return math.atan(y / x) - math.pi end
    if y > 0 then return math.pi / 2 end
    if y < 0 then return -math.pi / 2 end
    return 0
end

function DrawLineChart(frame, hist)
    local canvas = RebuildCanvas(frame)
    local W = frame:GetWidth()
    local H = frame:GetHeight()
    if not W or W < 30 then return end

    local byMin, maxMin
    if hist then
        byMin, maxMin = hist.gm or {}, 0
        for m in pairs(byMin) do if type(m)=="number" and m>maxMin then maxMin=m end end
    else
        byMin, maxMin = GetMinuteGold()
    end
    if not next(byMin) then NoDataMsg(canvas); return end

    local maxVal = 0
    for m = 0, maxMin do
        local v = byMin[m] or 0
        if v > maxVal then maxVal = v end
    end
    if maxVal == 0 then NoDataMsg(canvas); return end

    ChartTitle(canvas, "Gold per Minute")

    local mL, mR, mT, mB = 46, 8, 18, 26
    local pW = W - mL - mR
    local pH = H - mT - mB

    -- Horizontal grid lines + Y labels
    for i = 0, 4 do
        local y = mB + pH * i / 4
        local gl = canvas:CreateLine()
        gl:SetColorTexture(0.3, 0.3, 0.3, i == 0 and 0.9 or 0.35)
        gl:SetThickness(1)
        gl:SetStartPoint("BOTTOMLEFT", canvas, mL, y)
        gl:SetEndPoint("BOTTOMLEFT", canvas, mL + pW, y)
        if i > 0 then
            local lbl = canvas:CreateFontString(nil,"OVERLAY","GameFontNormalSmall")
            lbl:SetPoint("RIGHT", canvas, "BOTTOMLEFT", mL - 3, y - 5)
            TrackThemeText(lbl)
            lbl:SetJustifyH("RIGHT"); lbl:SetTextScale(0.72)
            lbl:SetText(CoinShort(math.floor(maxVal * i / 4)))
        end
    end

    -- Y axis
    local yAx = canvas:CreateLine()
    yAx:SetColorTexture(0.5,0.5,0.5,0.8); yAx:SetThickness(1)
    yAx:SetStartPoint("BOTTOMLEFT", canvas, mL, mB)
    yAx:SetEndPoint("BOTTOMLEFT", canvas, mL, mB + pH)

    -- X labels
    local step = math.max(1, math.ceil((maxMin + 1) / 8))
    for m = 0, maxMin, step do
        local x = mL + (maxMin > 0 and (m / maxMin) or 0) * pW
        local lbl = canvas:CreateFontString(nil,"OVERLAY","GameFontNormalSmall")
        lbl:SetPoint("TOP", canvas, "BOTTOMLEFT", x, mB - 2)
        TrackThemeText(lbl)
        lbl:SetJustifyH("CENTER"); lbl:SetTextScale(0.72)
        lbl:SetText(m .. "m")
    end

    -- Data line + dots
    local t = DB and DB.theme
    local aR = t and t.accentR or 0.88
    local aG = t and t.accentG or 0.92
    local aB = t and t.accentB or 0.96
    local prevX, prevY
    for m = 0, maxMin do
        local v = byMin[m] or 0
        local x = mL + (maxMin > 0 and (m / maxMin) or 0) * pW
        local y = mB + (v / maxVal) * pH
        if prevX then
            local seg = canvas:CreateLine()
            seg:SetColorTexture(aR, aG, aB, 0.9)
            seg:SetThickness(2)
            seg:SetStartPoint("BOTTOMLEFT", canvas, prevX, prevY)
            seg:SetEndPoint("BOTTOMLEFT", canvas, x, y)
        end
        local dot = canvas:CreateTexture(nil,"OVERLAY")
        dot:SetSize(5, 5)
        dot:SetPoint("BOTTOMLEFT", canvas, x - 2, y - 2)
        dot:SetColorTexture(aR, aG, aB, 1)
        prevX, prevY = x, y
    end
end

function DrawBarChart(frame, hist)
    local canvas = RebuildCanvas(frame)
    local W = frame:GetWidth()
    local H = frame:GetHeight()
    if not W or W < 30 then return end

    local topKeys, keyName, keyColor, byMin, maxMin

    if hist then
        -- Historical: data already aggregated
        local normItems = {}
        for _, v in ipairs(hist.it or {}) do
            table.insert(normItems, {name = v.n, total = v.g or 0})
        end
        if #normItems == 0 then NoDataMsg(canvas); return end
        topKeys, keyName, keyColor = MakeItemColors(normItems)

        local topSet = {}
        for _, k in ipairs(topKeys) do topSet[k] = true end
        byMin, maxMin = {}, 0
        for m, row in pairs(hist.im or {}) do
            local mi = tonumber(m)
            if mi then
                if not byMin[mi] then byMin[mi] = {} end
                for nm, v in pairs(row) do
                    local k = topSet[nm] and nm or "__other__"
                    byMin[mi][k] = (byMin[mi][k] or 0) + v
                end
                if mi > maxMin then maxMin = mi end
            end
        end
    else
        -- Live: aggregate from S
        local itemTotals = {}
        for _, it in ipairs(S and S.loot or {}) do
            if it.total > 0 and not GDS_QuestItems.EntryIsQuest(it) then
                local nm = it.name or "?"
                itemTotals[nm] = (itemTotals[nm] or 0) + it.total
            end
        end
        local coinTotal = 0
        for _, v in pairs(S and S.coinByMinute or {}) do coinTotal = coinTotal + v end
        if coinTotal > 0 then itemTotals["__coin__"] = coinTotal end
        if not next(itemTotals) then NoDataMsg(canvas); return end

        local sorted = {}
        for k, v in pairs(itemTotals) do table.insert(sorted, {name=k, total=v}) end
        table.sort(sorted, function(a,b) return a.total > b.total end)
        local MAX_ITEMS = 7
        if #sorted > MAX_ITEMS then
            local other = 0
            while #sorted > MAX_ITEMS do other = other + table.remove(sorted).total end
            table.insert(sorted, {name="__other__", total=other})
        end
        topKeys, keyName, keyColor = MakeItemColors(sorted)

        local topSet = {}
        for _, k in ipairs(topKeys) do topSet[k] = true end
        byMin, maxMin = {}, 0
        for _, it in ipairs(S and S.loot or {}) do
            if it.total > 0 and not GDS_QuestItems.EntryIsQuest(it) then
                local m  = math.floor(it.time / 60)
                local nm = it.name or "?"
                local k  = topSet[nm] and nm or "__other__"
                if not byMin[m] then byMin[m] = {} end
                byMin[m][k] = (byMin[m][k] or 0) + it.total
                if m > maxMin then maxMin = m end
            end
        end
        for m, v in pairs(S and S.coinByMinute or {}) do
            if not byMin[m] then byMin[m] = {} end
            local k = topSet["__coin__"] and "__coin__" or "__other__"
            byMin[m][k] = (byMin[m][k] or 0) + v
            if m > maxMin then maxMin = m end
        end
    end

    if not next(byMin) then NoDataMsg(canvas); return end

    local maxTotal = 0
    for m = 0, maxMin do
        if byMin[m] then
            local s = 0
            for _, v in pairs(byMin[m]) do s = s + v end
            if s > maxTotal then maxTotal = s end
        end
    end
    if maxTotal == 0 then NoDataMsg(canvas); return end

    -- No static legend — hover over a segment to see item + value
    local mL, mR, mT, mB = 46, 4, 18, 26
    local pW = W - mL - mR
    local pH = H - mT - mB

    ChartTitle(canvas, "Gold per Minute by Item (hover for details)")

    -- Grid + Y axis
    for i = 0, 4 do
        local y = mB + pH * i / 4
        local gl = canvas:CreateLine()
        gl:SetColorTexture(0.3,0.3,0.3, i==0 and 0.9 or 0.35); gl:SetThickness(1)
        gl:SetStartPoint("BOTTOMLEFT", canvas, mL, y)
        gl:SetEndPoint("BOTTOMLEFT", canvas, mL+pW, y)
        if i > 0 then
            local lbl = canvas:CreateFontString(nil,"OVERLAY","GameFontNormalSmall")
            lbl:SetPoint("RIGHT", canvas, "BOTTOMLEFT", mL-3, y-5)
            TrackThemeText(lbl)
            lbl:SetJustifyH("RIGHT"); lbl:SetTextScale(0.72)
            lbl:SetText(CoinShort(math.floor(maxTotal * i / 4)))
        end
    end
    local yAx = canvas:CreateLine()
    yAx:SetColorTexture(0.5,0.5,0.5,0.8); yAx:SetThickness(1)
    yAx:SetStartPoint("BOTTOMLEFT", canvas, mL, mB)
    yAx:SetEndPoint("BOTTOMLEFT", canvas, mL, mB+pH)

    -- Stacked bars + invisible hover frames per segment
    local nMin    = maxMin + 1
    local barStep = math.max(2, math.floor(pW / nMin))
    local barW    = math.max(1, barStep - 1)
    local xStep   = math.max(1, math.ceil(nMin / 8))
    for m = 0, maxMin do
        local x   = mL + m * barStep
        local row = byMin[m]
        if row then
            local stackY = mB
            for _, key in ipairs(topKeys) do
                local v = row[key] or 0
                if v > 0 then
                    local bH  = math.max(1, math.floor(v / maxTotal * pH))
                    local col = keyColor[key]
                    local seg = canvas:CreateTexture(nil,"ARTWORK")
                    seg:SetPoint("BOTTOMLEFT", canvas, x, stackY)
                    seg:SetSize(barW, bH)
                    seg:SetColorTexture(col[1], col[2], col[3], 0.88)
                    -- Hover frame for this individual segment
                    local tipF = CreateFrame("Frame", nil, canvas)
                    tipF:SetPoint("BOTTOMLEFT", canvas, x, stackY)
                    tipF:SetSize(barW, bH)
                    tipF:EnableMouse(true)
                    local nm_l = keyName[key] or key
                    local v_l  = v
                    local c1,c2,c3 = col[1], col[2], col[3]
                    tipF:SetScript("OnEnter", function(self)
                        GameTooltip:SetOwner(self, "ANCHOR_RIGHT")
                        GameTooltip:AddLine(nm_l, c1, c2, c3)
                        GameTooltip:AddLine(CoinShort(v_l), 1, 0.82, 0)
                        GameTooltip:Show()
                    end)
                    tipF:SetScript("OnLeave", function() GameTooltip:Hide() end)
                    stackY = stackY + bH
                end
            end
        end
        if m % xStep == 0 then
            local lbl = canvas:CreateFontString(nil,"OVERLAY","GameFontNormalSmall")
            lbl:SetPoint("TOP", canvas, "BOTTOMLEFT", x + barW/2, mB-2)
            TrackThemeText(lbl)
            lbl:SetJustifyH("CENTER"); lbl:SetTextScale(0.72)
            lbl:SetText(m.."m")
        end
    end
end

function DrawPieChart(frame, hist)
    local canvas = RebuildCanvas(frame)
    local W = frame:GetWidth()
    local H = frame:GetHeight()
    if not W or W < 30 then return end

    local items, totalGold = {}, 0

    if hist then
        -- Historical: use pre-sorted list
        for _, v in ipairs(hist.it or {}) do
            local nm = v.n == "__other__" and "Other"
                    or v.n == "__coin__"  and "Coin Pickups"
                    or v.n
            table.insert(items, {name=nm, total=v.g or 0})
            totalGold = totalGold + (v.g or 0)
        end
    else
        -- Live: aggregate from S
        local byItem = {}
        for _, it in ipairs(S and S.loot or {}) do
            if it.total > 0 and not GDS_QuestItems.EntryIsQuest(it) then
                local key = it.name or "?"
                if not byItem[key] then byItem[key] = {name=key, total=0} end
                byItem[key].total = byItem[key].total + it.total
                totalGold = totalGold + it.total
            end
        end
        local coinTotal = S and S.coinGold or 0
        if coinTotal > 0 then
            totalGold = totalGold + coinTotal
            byItem["__coin__"] = {name="Coin Pickups", total=coinTotal}
        end
        for _, v in pairs(byItem) do table.insert(items, v) end
        table.sort(items, function(a,b) return a.total > b.total end)
        local MAX_SLICES = 7
        if #items > MAX_SLICES then
            local other = 0
            while #items > MAX_SLICES do other = other + table.remove(items).total end
            table.insert(items, {name="Other", total=other})
        end
    end

    if totalGold == 0 then NoDataMsg(canvas); return end

    ChartTitle(canvas, "Gold by Item")

    local r        = math.max(10, math.floor(math.min(W - 28, H - 42) / 2) - 2)
    local cx       = W / 2
    local cy       = math.max(r + 8, (H - 16) / 2)
    local slices   = {}

    -- Draw pie slices; step count scales with radius so arc spacing ≤ 2px → solid fill
    local TWO_PI     = math.pi * 2
    local startAngle = math.pi / 2
    for i, item in ipairs(items) do
        local col   = PIE_COLORS[i] or PIE_COLORS[#PIE_COLORS]
        local frac  = item.total / totalGold
        local sweep = frac * TWO_PI
        local steps = math.max(3, math.ceil(sweep * r / 2))
        for s = 0, steps do
            local theta = startAngle - sweep * s / steps
            local line  = canvas:CreateLine()
            line:SetColorTexture(col[1], col[2], col[3], 0.95)
            line:SetThickness(3)
            line:SetStartPoint("BOTTOMLEFT", canvas, cx, cy)
            line:SetEndPoint("BOTTOMLEFT", canvas, cx + r*math.cos(theta), cy + r*math.sin(theta))
        end
        table.insert(slices, {
            item=item,
            color=col,
            offsetStart=(math.pi / 2 - startAngle) % TWO_PI,
            offsetEnd=(math.pi / 2 - (startAngle - sweep)) % TWO_PI,
            percent=math.floor(frac * 100 + 0.5),
        })
        startAngle = startAngle - sweep
    end

    -- Slice dividers
    startAngle = math.pi / 2
    for _, item in ipairs(items) do
        local bline = canvas:CreateLine()
        bline:SetColorTexture(0,0,0,0.8); bline:SetThickness(2)
        bline:SetStartPoint("BOTTOMLEFT", canvas, cx, cy)
        bline:SetEndPoint("BOTTOMLEFT", canvas, cx + r*math.cos(startAngle), cy + r*math.sin(startAngle))
        startAngle = startAngle - (item.total / totalGold) * TWO_PI
    end

    -- Outer border ring (1-degree steps → smooth)
    for deg = 0, 359 do
        local t1 = math.rad(deg); local t2 = math.rad(deg + 1)
        local bord = canvas:CreateLine()
        bord:SetColorTexture(0,0,0,0.65); bord:SetThickness(2)
        bord:SetStartPoint("BOTTOMLEFT", canvas, cx + r*math.cos(t1), cy + r*math.sin(t1))
        bord:SetEndPoint("BOTTOMLEFT", canvas, cx + r*math.cos(t2), cy + r*math.sin(t2))
    end

    -- Center cover
    local covR  = math.max(3, math.min(7, math.floor(r * 0.08)))
    local bg    = DB and DB.theme
    local cover = canvas:CreateTexture(nil,"OVERLAY")
    cover:SetPoint("BOTTOMLEFT", canvas, cx - covR, cy - covR)
    cover:SetSize(covR * 2, covR * 2)
    cover:SetColorTexture(bg and bg.bgR or 0, bg and bg.bgG or 0, bg and bg.bgB or 0, 1)

    canvas:EnableMouse(true)
    canvas:SetScript("OnUpdate", function(self)
        local mx, my = GetCursorPosition()
        local scale = self:GetEffectiveScale() or 1
        mx, my = mx / scale, my / scale
        local left, bottom = self:GetLeft() or 0, self:GetBottom() or 0
        local dx, dy = mx - left - cx, my - bottom - cy
        local dist = math.sqrt(dx * dx + dy * dy)
        if dist > r or dist < covR then
            if self._gtPieHover then
                self._gtPieHover = nil
                GameTooltip:Hide()
            end
            return
        end

        local theta = GTAtan2(dy, dx)
        local offset = ((math.pi / 2 - theta) % TWO_PI)
        local hit
        for i, slice in ipairs(slices) do
            local last = (i == #slices)
            if offset >= slice.offsetStart and (offset < slice.offsetEnd or last) then
                hit = slice
                break
            end
        end
        if not hit then
            if self._gtPieHover then
                self._gtPieHover = nil
                GameTooltip:Hide()
            end
            return
        end
        if self._gtPieHover == hit then return end

        self._gtPieHover = hit
        local c = hit.color
        GameTooltip:SetOwner(self, "ANCHOR_CURSOR")
        GameTooltip:ClearLines()
        GameTooltip:AddLine(hit.item.name or "Unknown", c[1], c[2], c[3])
        GameTooltip:AddLine(hit.percent .. "%  " .. CoinShort(hit.item.total), 0.88, 0.92, 0.96)
        GameTooltip:Show()
    end)
    canvas:SetScript("OnLeave", function(self)
        self._gtPieHover = nil
        GameTooltip:Hide()
    end)
end

function SetAnalyticsTab(tab)
    activeTab = tab
    local isLog = (tab == "log")

    lootScroll.clip:SetShown(isLog)
    if isLog then
        lootScroll:Update()
    else
        lootScroll.bar:Hide()
    end

    if lootFrame.lootLegend then lootFrame.lootLegend:SetShown(isLog) end

    for key, cf in pairs(chartFrames) do cf:SetShown(key == tab) end

    for key, btn in pairs(lootTabBtns) do
        local active = (key == tab)
        if DB and DB.skinMode == "wowlook" then
            if active then btn.bg:SetColorTexture(.19, .13, .052, .99)
            else btn.bg:SetColorTexture(.073, .050, .026, .98) end
        else
            btn.bg:SetColorTexture(active and 0.12 or 0.055, active and 0.15 or 0.067, active and 0.22 or 0.082, 0.95)
        end
        GDS_WoWLook.Tab(btn, active)
    end

    if isLog then
        RefreshLootLog()
    else
        local cf = chartFrames[tab]
        if cf then
            C_Timer.After(0, function()
                if     tab == "line" then DrawLineChart(cf)
                elseif tab == "bar"  then DrawBarChart(cf)
                elseif tab == "pie"  then DrawPieChart(cf) end
            end)
        end
    end
end

function ShowPastAnalytics(se)
    if not se then return end
    local hist = se.c
    -- Older saved runs may lack enabled-setting flags. In those records only,
    -- nonzero archived activity is sufficient to reveal the corresponding tab.
    local showQuest = se.questTrackingEnabled == true
        or (tonumber(se.questXP) or 0) > 0 or (tonumber(se.questGold) or 0) > 0
    local showPvP = se.pvpTrackingEnabled == true
        or (tonumber(se.pvpHK) or 0) > 0 or (tonumber(se.pvpKB) or 0) > 0
    local hasCharts = type(hist) == "table"
    if not hasCharts and not showQuest and not showPvP then
        if pastAnalyticsFrame then pastAnalyticsFrame:Hide() end
        UIErrorsFrame:AddMessage("|cFFD8DDE6Grind Dont Stop:|r No saved statistics for that session.")
        return
    end

    local W, H = 440, 400
    if not pastAnalyticsFrame then
        local f = CreateFrame("Frame", "GTPastAnalyticsFrame", UIParent,
            BackdropTemplateMixin and "BackdropTemplate")
        GDS_FocusWindow(f)
        f:SetSize(W, H)
        f:SetPoint("CENTER")
        f:EnableMouse(true); f:SetMovable(true)
        f:SetClampedToScreen(true); f:RegisterForDrag("LeftButton")
        f:SetFrameStrata("DIALOG")
        f:SetScript("OnDragStart", f.StartMoving)
        f:SetScript("OnDragStop", f.StopMovingOrSizing)
        ApplyBackdrop(f)

        local ttl = f:CreateFontString(nil,"OVERLAY","GameFontNormalLarge")
        ttl:SetPoint("TOP",0,-10)
        local t = DB and DB.theme
        ttl:SetTextColor(t and t.accentR or 0.88, t and t.accentG or 0.92, t and t.accentB or 0.96)
        table.insert(GT_titles, ttl)
        f._ttl = ttl

        local loginAnalytics = MakeBtn(f,96,18,"Login Analytics")
        loginAnalytics:SetPoint("TOPRIGHT",f,"TOPLEFT",-4,-8)
        loginAnalytics:SetScript("OnClick",function() GDS_LoginLog.ExperimentalShow() end)

        local sub = f:CreateFontString(nil,"OVERLAY","GameFontNormalSmall")
        sub:SetPoint("TOP",0,-26)
        TrackThemeText(sub)
        f._sub = sub
        local best = f:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
        best:SetPoint("TOPLEFT", 10, -40)
        best:SetPoint("TOPRIGHT", -10, -40)
        best:SetWordWrap(false)
        TrackThemeText(best)
        f._best = best

        local xb = MakeBtn(f, 18, 18, "X")
        xb:SetPoint("TOPRIGHT",-4,-4)
        xb:SetScript("OnClick", function() f:Hide() end)

        -- Two chart tabs and two read-only historical-stat tabs. They share
        -- the same canvas slot, so we never overlay an existing graph.
        f._charts = {}
        f._summary = {}
        for _, key in ipairs({"line", "pie", "quest", "pvp"}) do
            local cf = CreateFrame("Frame", nil, f)
            cf:SetPoint("TOPLEFT",     f, "TOPLEFT",     8, -44)
            cf:SetPoint("BOTTOMRIGHT", f, "BOTTOMRIGHT", -16, 30)
            cf:Hide()
            f._charts[key] = cf
            if key == "quest" or key == "pvp" then
                local heading = cf:CreateFontString(nil, "OVERLAY", "GameFontNormalLarge")
                heading:SetPoint("TOPLEFT", cf, "TOPLEFT", 18, -24)
                heading:SetText(key == "quest" and "Quest Rewards" or "PvP Statistics")
                f._summary[key] = {}
                local labels = cf:CreateFontString(nil, "OVERLAY", "GameFontHighlight")
                labels:SetPoint("TOPLEFT", cf, "TOPLEFT", 20, -89)
                labels:SetWidth(188)
                labels:SetJustifyH("LEFT")
                labels:SetText(key == "quest" and "Quest XP Earned\n\nQuest Coin" or "Honorable Kills\n\nHon. Killing Blows")
                TrackThemeText(labels)
                local values = cf:CreateFontString(nil, "OVERLAY", "GameFontHighlight")
                values:SetPoint("TOPRIGHT", cf, "TOPRIGHT", -24, -89)
                values:SetWidth(165)
                values:SetJustifyH("RIGHT")
                TrackThemeText(values)
                f._summary[key].values = values
                local note = cf:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
                note:SetPoint("TOPLEFT", cf, "TOPLEFT", 20, -183)
                note:SetPoint("TOPRIGHT", cf, "TOPRIGHT", -20, -183)
                note:SetJustifyH("LEFT")
                note:SetText(key == "quest"
                    and "Separate saved quest rewards. Quest Coin can also include the selected value of quest loot in Analytics. It is not added to farming income."
                    or "Honorable Kills include credited assists. Hon. Killing Blows count your personal credited finishing blows during the session.")
                TrackThemeText(note, 0.75)
            end
        end

        -- Create all potential tabs once; dynamically size and hide them for
        -- each opened historical record to keep the footer uncluttered.
        f._tabs = {}
        for _, td in ipairs({{"Line","line"}, {"Pie","pie"}, {"Quest","quest"}, {"PvP","pvp"}}) do
            f._tabs[td[2]] = MakeBtn(f, 100, 22, td[1])
        end
        pastAnalyticsFrame = f
    end

    local f = pastAnalyticsFrame
    f._openedSession = se
    local best = se.bestDrop
    local hasDropLine = best or se.bestDropRecorded
    f._best:SetText(best and ((se.bestDropRecorded and "Best Drop: " or "Best recorded drop: ")
        .. GDS_ItemCompat.DropText(best)) or (se.bestDropRecorded and "Best Drop: None" or ""))
    for _, chart in pairs(f._charts) do
        chart:SetPoint("TOPLEFT", f, "TOPLEFT", 8, hasDropLine and -60 or -44)
    end
    if historyFrame and historyFrame:IsShown() then
        local scale = historyFrame:GetEffectiveScale() / UIParent:GetEffectiveScale()
        local left = (historyFrame:GetLeft() or 0) * scale
        local right = UIParent:GetWidth() - (historyFrame:GetRight() or 0) * scale
        local width = f:GetWidth() * f:GetEffectiveScale() / UIParent:GetEffectiveScale()
        f:ClearAllPoints()
        if right >= width + 4 or right >= left then
            f:SetPoint("TOPLEFT", historyFrame, "TOPRIGHT", 4, 0)
        else
            f:SetPoint("TOPRIGHT", historyFrame, "TOPLEFT", -4, 0)
        end
    end
    local dur = math.max(0, tonumber(se.duration) or 0)
    local h2 = math.floor(dur/3600)
    local m2 = math.floor((dur%3600)/60)
    local s2 = math.floor(dur%60)
    local durStr = h2>0 and string.format("%dh %02dm %02ds",h2,m2,s2)
                         or string.format("%dm %02ds",m2,s2)
    f._ttl:SetText(GDS_HistoryDate.Format(se.date))
    local goldTotal = math.floor((se.coin or 0)/10000)
    local silv = math.floor(((se.coin or 0)%10000)/100)
    local cop = (se.coin or 0)%100
    local goldStr = string.format("%dg %ds %dc", goldTotal, silv, cop)
    f._sub:SetText(durStr .. "  " .. goldStr .. "  " .. (se.kills or 0) .. " kills")
    f._summary.quest.values:SetText(FmtNum(se.questXP or 0) .. "\n\n" .. Coin(se.questGold or 0))
    f._summary.pvp.values:SetText(FmtNum(se.pvpHK or 0) .. "\n\n" .. FmtNum(se.pvpKB or 0))

    local tabOrder = {}
    if hasCharts then
        tabOrder[#tabOrder+1] = "line"
        tabOrder[#tabOrder+1] = "pie"
    end
    if showQuest then tabOrder[#tabOrder+1] = "quest" end
    if showPvP then tabOrder[#tabOrder+1] = "pvp" end
    local width = math.floor((W - 16 - (#tabOrder-1)*2) / #tabOrder)
    local previous
    for _, key in ipairs({"line", "pie", "quest", "pvp"}) do
        f._tabs[key]:Hide()
    end
    for _, key in ipairs(tabOrder) do
        local btn = f._tabs[key]
        btn:ClearAllPoints()
        btn:SetWidth(width)
        if previous then
            btn:SetPoint("BOTTOMLEFT", previous, "BOTTOMRIGHT", 2, 0)
        else
            btn:SetPoint("BOTTOMLEFT", f, "BOTTOMLEFT", 8, 5)
        end
        btn:Show()
        previous = btn
    end

    local function setPastTab(tab)
        if not f._tabs[tab] or not f._tabs[tab]:IsShown() then return end
        for key, btn in pairs(f._tabs) do
            local active = key == tab
            btn.bg:SetColorTexture(active and 0.12 or 0.055,
                active and 0.15 or 0.067, active and 0.22 or 0.082, 0.95)
        end
        for key, cf in pairs(f._charts) do cf:SetShown(key == tab) end
        local cf = f._charts[tab]
        if cf and (tab == "line" or tab == "pie") then
            C_Timer.After(0, function()
                if not f:IsShown() or not cf:IsShown() or f._openedSession ~= se then return end
                if tab == "line" then DrawLineChart(cf, hist)
                else DrawPieChart(cf, hist) end
            end)
        end
    end
    for key, btn in pairs(f._tabs) do
        local tabKey = key
        btn:SetScript("OnClick", function() setPastTab(tabKey) end)
    end
    f:Show()
    f:Raise()
    setPastTab(tabOrder[1])
end

local function BuildLootFrame()
    lootFrame = CreateFrame("Frame", "GTLootFrame", UIParent,
        BackdropTemplateMixin and "BackdropTemplate")
    GDS_FocusWindow(lootFrame)
    lootFrame:SetSize(DB.lootW or 400, DB.lootH or 420)
    lootFrame:SetPoint("LEFT", mainFrame, "RIGHT", 10, 0)
    lootFrame:EnableMouse(true); lootFrame:SetMovable(true)
    lootFrame:SetClampedToScreen(true); lootFrame:RegisterForDrag("LeftButton")
    lootFrame:Hide()
    ApplyBackdrop(lootFrame)

    local header = CreateFrame("Frame", nil, lootFrame)
    header:SetPoint("TOPLEFT", 4, -4)
    header:SetPoint("TOPRIGHT", -4, -4)
    header:SetHeight(40)
    local headerBg = header:CreateTexture(nil, "BACKGROUND")
    headerBg:SetAllPoints()
    local _hb = DB and DB.theme
    headerBg:SetColorTexture(_hb and _hb.headerR or 0.045, _hb and _hb.headerG or 0.06, _hb and _hb.headerB or 0.078, _hb and _hb.headerA or 0.84)
    table.insert(GT_headers, headerBg)
    local headerRule = header:CreateTexture(nil, "BORDER")
    headerRule:SetPoint("BOTTOMLEFT")
    headerRule:SetPoint("BOTTOMRIGHT")
    headerRule:SetHeight(1)
    local _hr = DB and DB.theme
    headerRule:SetColorTexture(_hr and _hr.borderR or 0.22, _hr and _hr.borderG or 0.31, _hr and _hr.borderB or 0.40, 0.72)
    table.insert(GT_dividers, headerRule)
    table.insert(GT_headerRules, headerRule)

    local ttl = header:CreateFontString(nil,"OVERLAY","GameFontNormalLarge")
    ttl:SetPoint("TOP",0,-6); ttl:SetText("Analytics")
    local _lt = DB and DB.theme
    ttl:SetTextColor(_lt and _lt.accentR or 0.88, _lt and _lt.accentG or 0.92, _lt and _lt.accentB or 0.96)
    table.insert(GT_titles, ttl)

    local leg = header:CreateFontString(nil,"OVERLAY","GameFontNormalSmall")
    leg:SetPoint("TOP",0,-22)
    TrackThemeText(leg)
    leg:SetText(DB.questTracking
        and "V=Vendor AH=Auction DE=Disenchant Q=Quest Q/DE=Quest DE"
        or "V=Vendor AH=Auction DE=Disenchant Left=cycle Right=remove")
    lootFrame.lootLegend = leg

    -- Small, contextual header button. Hidden until a row is removed.
    local restoreBtn = MakeBtn(lootFrame, 64, 18, "Restore")
    restoreBtn:SetPoint("TOPLEFT", lootFrame, "TOPLEFT", 6, -4)
    lootFrame.restoreBtn = restoreBtn
    restoreBtn:Hide()
    restoreBtn:SetScript("OnEnter", function(self)
        GameTooltip:SetOwner(self, "ANCHOR_BOTTOM")
        GameTooltip:SetText("Choose a removed item to restore")
        GameTooltip:Show()
    end)
    restoreBtn:SetScript("OnLeave", function() GameTooltip:Hide() end)
    do
        local panel = CreateFrame("Frame", nil, lootFrame)
        panel:SetPoint("TOPLEFT", restoreBtn, "BOTTOMLEFT", 0, -2)
        panel:SetSize(390, 245)
        panel:SetFrameLevel(lootFrame:GetFrameLevel() + 20)
        panel:EnableMouse(true)
        local bg = panel:CreateTexture(nil, "BACKGROUND")
        bg:SetAllPoints()
        bg:SetColorTexture(.055, .045, .035, 1)
        panel:Hide()
        local title = panel:CreateFontString(nil, "OVERLAY", "GameFontNormal")
        title:SetPoint("TOP", 0, -8)
        local close = MakeBtn(panel, 22, 20, "X")
        close:SetPoint("TOPRIGHT", -3, -3)
        close:SetScript("OnClick", function() panel:Hide() end)
        local page, rows = 1, {}
        local perPage = 8
        for slot = 1, perPage do
            local row = MakeBtn(panel, 380, 23, "")
            row:SetPoint("TOPLEFT", 5, -27 - (slot - 1) * 23)
            row.label:SetWidth(368)
            row.label:SetWordWrap(false)
            row:HookScript("OnMouseDown", function(self) self.pressedRecord = self.record end)
            row:SetScript("OnClick", function(self)
                if self.record == self.pressedRecord then GDS_AnalyticsUndo.Restore(self.record) end
                self.pressedRecord = nil
            end)
            rows[slot] = row
        end
        local prev = MakeBtn(panel, 70, 22, "Previous")
        local nextBtn = MakeBtn(panel, 70, 22, "Next")
        prev:SetPoint("BOTTOMLEFT", 5, 5)
        nextBtn:SetPoint("BOTTOMRIGHT", -5, 5)
        lootFrame.refreshRemoved = function(removed, count)
            if count == 0 then panel:Hide(); return end
            if not panel:IsShown() then return end
            local pages = math.ceil(count / perPage)
            page = math.max(1, math.min(page, pages))
            title:SetText("Restore removed loot  (" .. page .. "/" .. pages .. ")")
            prev:SetShown(page > 1)
            nextBtn:SetShown(page < pages)
            for slot, row in ipairs(rows) do
                local record = removed[count - (page - 1) * perPage - slot + 1]
                row.record = record
                row:SetShown(record ~= nil)
                if record then
                    local e = record.entry
                    row.label:SetText(FmtShort(e.time or 0) .. "   " .. (e.qty or 1) .. "x "
                        .. (e.name or "?") .. "   " .. CoinShort(e.total or 0))
                end
            end
        end
        prev:SetScript("OnClick", function() page = page - 1; GDS_AnalyticsUndo.RefreshButton() end)
        nextBtn:SetScript("OnClick", function() page = page + 1; GDS_AnalyticsUndo.RefreshButton() end)
        lootFrame:HookScript("OnHide", function() panel:Hide() end)
        restoreBtn:SetScript("OnClick", function()
            page = 1
            panel:SetShown(not panel:IsShown())
            GDS_AnalyticsUndo.RefreshButton()
        end)
    end

    local xb = MakeBtn(lootFrame, 18, 18, "X")
    xb:SetPoint("TOPRIGHT",-4,-4)
    xb:SetScript("OnClick", ToggleLootLog)

    local csvBtn = MakeBtn(lootFrame, 40, 18, "CSV")
    csvBtn:SetPoint("TOPRIGHT", xb, "TOPLEFT", -4, 0)

    local clearBtn = MakeBtn(lootFrame, 48, 18, "Clear")
    clearBtn:SetPoint("TOPRIGHT", csvBtn, "TOPLEFT", -4, 0)
    clearBtn:SetScript("OnEnter", function(self)
        GameTooltip:SetOwner(self, "ANCHOR_BOTTOM")
        GameTooltip:SetText("Clear Analytics Loot")
        GameTooltip:AddLine("Clear the current personal loot log and its restore list. Item value is removed from Total/GPH.", .8, .8, .8, true)
        GameTooltip:AddLine("Coin, XP, and Party Session are unaffected. Linked completed dungeon runs keep their records, but item earnings/loot are cleared. Click twice to confirm.", .7, .8, .9, true)
        GameTooltip:Show()
    end)
    clearBtn:SetScript("OnLeave", function() GameTooltip:Hide() end)
    clearBtn:SetScript("OnClick", function(self)
        if not S or not S.loot or (#S.loot == 0 and #(GDS_AnalyticsUndo.List() or {}) == 0) then
            DEFAULT_CHAT_FRAME:AddMessage("|cFFD8DDE6Grind Dont Stop|r No personal analytics loot to clear.")
            return
        end
        if not self._gtConfirm then
            self._gtConfirm = true
            self.label:SetText("Sure?")
            C_Timer.After(6, function()
                if self._gtConfirm then
                    self._gtConfirm = nil
                    self.label:SetText("Clear")
                end
            end)
            return
        end
        self._gtConfirm = nil
        self.label:SetText("Clear")

        -- Cancel only the PERSONAL portion of delayed item valuation; any
        -- independent party-only session may still finish pricing its awards.
        for _, pending in ipairs(GDS_ItemCompat.pending or {}) do
            if pending.personal == S then
                pending.personal = nil
                pending.entry = nil
            end
        end
        local cleared = #S.loot
        S.loot = {}
        S.analyticsUndo = nil
        S.removedLoot = nil
        GDS_QuestItems.Reconcile() -- remove both farm and Quest Coin entries
        RefreshStats()
        RefreshLootLog()
        DEFAULT_CHAT_FRAME:AddMessage("|cFFD8DDE6Grind Dont Stop|r Cleared " .. cleared .. " personal analytics loot entries. Linked dungeon item earnings updated; coin, XP and run records kept.")
    end)

    csvBtn:SetScript("OnEnter", function(self)
        GameTooltip:SetOwner(self, "ANCHOR_BOTTOM")
        GameTooltip:SetText("Export Session to CSV", 1, 1, 1)
        GameTooltip:AddLine("Copies kill counts and loot to clipboard.\nPaste into any spreadsheet.", 0.8, 0.8, 0.8, true)
        GameTooltip:Show()
    end)
    csvBtn:SetScript("OnLeave", function() GameTooltip:Hide() end)
    csvBtn:SetScript("OnClick", function()
        if not S then
            DEFAULT_CHAT_FRAME:AddMessage("|cFFD8DDE6Grind Dont Stop:|r No active session to export.")
            return
        end

        local lines = {}

        -- Session summary header
        lines[#lines+1] = "Grind Dont Stop Session Export"
        lines[#lines+1] = "Duration,Kills,XP,Coin (copper),Item Gold (copper)"
        lines[#lines+1] = string.format("%s,%d,%d,%d,%d",
            FormatTime(S.timer or 0),
            S.kills    or 0,
            S.xpGained or 0,
            S.coinGold or 0,
            S.itemGold or 0)
        lines[#lines+1] = "Quest Loot Vendor Estimate (copper)," ..
            tostring(math.max(0, tonumber(S.questItemGold) or 0))
        lines[#lines+1] = ""

        -- Mob kill counts
        if S.mobKills and next(S.mobKills) then
            lines[#lines+1] = "Mob,Kills"
            local mobs = {}
            for name, count in pairs(S.mobKills) do
                mobs[#mobs+1] = { name = name, count = count }
            end
            table.sort(mobs, function(a, b) return a.count > b.count end)
            for _, mob in ipairs(mobs) do
                lines[#lines+1] = string.format("%s,%d", mob.name:gsub(",", ";"), mob.count)
            end
            lines[#lines+1] = ""
        end

        -- Keep quest-valued estimates distinguishable from farm earnings.
        lines[#lines+1] = "Item,Quantity,Value (copper),Category"
        local byItem, order = {}, {}
        for _, it in ipairs(S.loot or {}) do
            local category = GDS_QuestItems.EntryIsQuest(it) and "Quest estimate" or "Farming"
            local key = (it.name or "?") .. "\t" .. category
            if not byItem[key] then
                byItem[key] = { name=it.name or "?", category=category, qty=0, total=0 }
                order[#order+1] = key
            end
            byItem[key].qty   = byItem[key].qty   + (it.qty   or 1)
            byItem[key].total = byItem[key].total + (it.total or 0)
        end
        table.sort(order, function(a, b) return byItem[a].total > byItem[b].total end)
        for _, key in ipairs(order) do
            local d = byItem[key]
            lines[#lines+1] = string.format("%s,%d,%d,%s",
                d.name:gsub(",", ";"), d.qty, d.total, d.category)
        end
        if (S.coinGold or 0) > 0 then
            lines[#lines+1] = string.format("Coin Pickups,1,%d,Farming", S.coinGold)
        end

        local csv = table.concat(lines, "\n")
        if C_Clipboard and C_Clipboard.SetText then
            C_Clipboard.SetText(csv)
            DEFAULT_CHAT_FRAME:AddMessage("|cFFD8DDE6Grind Dont Stop:|r Session exported — paste into a spreadsheet.")
        else
            DEFAULT_CHAT_FRAME:AddMessage("|cFFD8DDE6Grind Dont Stop:|r Clipboard not available on this client.")
        end
    end)

    GDS_AnalyticsUndo.RefreshButton()
    lootScroll = MakeScrollFrame(lootFrame, (DB.lootW or 400)-24, 44, 30)

    -- Tab buttons at bottom
    local tabDefs = {{"Log","log"},{"Line","line"},{"Bar","bar"},{"Pie","pie"}}
    local tabW = math.floor(((DB.lootW or 400) - 18 - 3*2) / 4)
    local prevBtn = nil
    for _, td in ipairs(tabDefs) do
        local btn = MakeBtn(lootFrame, tabW, 22, td[1])
        if prevBtn then
            btn:SetPoint("BOTTOMLEFT", prevBtn, "BOTTOMRIGHT", 2, 0)
        else
            btn:SetPoint("BOTTOMLEFT", lootFrame, "BOTTOMLEFT", 8, 5)
        end
        local tabKey = td[2]
        btn:SetScript("OnClick", function() SetAnalyticsTab(tabKey) end)
        lootTabBtns[tabKey] = btn
        prevBtn = btn
    end

    -- Chart canvas frames (same area as scroll)
    for _, key in ipairs({"line","bar","pie"}) do
        local cf = CreateFrame("Frame", nil, lootFrame)
        cf:SetPoint("TOPLEFT",     lootFrame, "TOPLEFT",     8,   -44)
        cf:SetPoint("BOTTOMRIGHT", lootFrame, "BOTTOMRIGHT", -16,  30)
        cf:Hide()
        chartFrames[key] = cf
        local k = key
        cf:SetScript("OnSizeChanged", function()
            if cf:IsShown() then
                C_Timer.After(0, function()
                    if     k == "line" then DrawLineChart(cf)
                    elseif k == "bar"  then DrawBarChart(cf)
                    elseif k == "pie"  then DrawPieChart(cf) end
                end)
            end
        end)
    end

    lootFrame:SetScript("OnDragStart", lootFrame.StartMoving)
    lootFrame:SetScript("OnDragStop", function(self)
        self:StopMovingOrSizing()
        local p,_,_,x,y = self:GetPoint()
        DB.lootPos = {p=p,x=x,y=y}
        local prof = DB.profiles and DB.currentProfile and DB.profiles[DB.currentProfile]
        if prof then prof.lootPos = {p=p,x=x,y=y} end
    end)

    local lp = DB.lootPos
    if lp and lp.p then
        lootFrame:ClearAllPoints()
        lootFrame:SetPoint(lp.p, UIParent, lp.p, lp.x or 0, lp.y or 0)
    end
end

-------------------------------------------------------------------------------
-- MAIN WINDOW
-------------------------------------------------------------------------------
-------------------------------------------------------------------------------
-- LIVE GPH GRAPH
-------------------------------------------------------------------------------
local GPH_GRAPH_W, GPH_GRAPH_H = 480, 300
local GPH_PLOT_X, GPH_PLOT_Y, GPH_PLOT_W, GPH_PLOT_H = 66, 78, 396, 170
local GPH_MAX_POINTS = 160

local function GphSeries()
    local raw = S and S.gphSamples
    if not raw or #raw < 2 then return nil end
    local n = #raw
    if n <= GPH_MAX_POINTS then return raw end
    local pts = {}
    for i = 1, GPH_MAX_POINTS do
        local a = math.floor((i - 1) * n / GPH_MAX_POINTS) + 1
        local b = math.max(a, math.floor(i * n / GPH_MAX_POINTS))
        local sum = 0
        for j = a, b do sum = sum + raw[j].v end
        pts[i] = {t = raw[b].t, v = sum / (b - a + 1)}
    end
    return pts
end

local function BuildGphGraph()
    local f = CreateFrame("Frame", "GTGphGraphFrame", UIParent,
        BackdropTemplateMixin and "BackdropTemplate")
    GDS_FocusWindow(f)
    gphGraphFrame = f
    f:SetSize(GPH_GRAPH_W, GPH_GRAPH_H)
    f:SetFrameStrata("DIALOG")
    f:SetClampedToScreen(true)
    f:EnableMouse(true); f:SetMovable(true); f:RegisterForDrag("LeftButton")
    f:SetScript("OnDragStart", f.StartMoving)
    f:SetScript("OnDragStop", f.StopMovingOrSizing)
    ApplyBackdrop(f)
    f:Hide()

    local theme = (DB and DB.theme) or DEFAULT_THEME
    local title = f:CreateFontString(nil, "OVERLAY", "GameFontNormalLarge")
    title:SetPoint("TOPLEFT", 14, -12)
    title:SetText("Live Gold Per Hour")
    title:SetTextColor(theme.accentR, theme.accentG, theme.accentB)
    table.insert(GT_titles, title)

    local close = MakeBtn(f, 22, 22, "X")
    close:SetPoint("TOPRIGHT", -8, -8)
    close:SetScript("OnClick", function() f:Hide() end)

    -- Summary line: now / peak / session average
    f.summary = f:CreateFontString(nil, "OVERLAY", "GameFontHighlight")
    f.summary:SetPoint("TOPLEFT", 14, -40)
    f.summary:SetPoint("TOPRIGHT", -14, -40)
    f.summary:SetJustifyH("LEFT")
    TrackThemeText(f.summary, 0.9)

    local plot = CreateFrame("Frame", nil, f)
    plot:SetSize(GPH_PLOT_W, GPH_PLOT_H)
    plot:SetPoint("TOPLEFT", f, "TOPLEFT", GPH_PLOT_X, -GPH_PLOT_Y)
    f.plot = plot
    local plotBg = plot:CreateTexture(nil, "BACKGROUND")
    plotBg:SetAllPoints()
    plotBg:SetColorTexture(0.03, 0.04, 0.055, 0.55)

    f.grid, f.yLabels = {}, {}
    for i = 0, 4 do
        local g = plot:CreateLine()
        g:SetThickness(1)
        g:SetColorTexture(0.30, 0.38, 0.46, i == 0 and 0.75 or 0.30)
        g:SetStartPoint("BOTTOMLEFT", plot, 0, GPH_PLOT_H * i / 4)
        g:SetEndPoint("BOTTOMLEFT", plot, GPH_PLOT_W, GPH_PLOT_H * i / 4)
        f.grid[i] = g
        local lb = f:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
        lb:SetPoint("RIGHT", plot, "BOTTOMLEFT", -6, GPH_PLOT_H * i / 4)
        lb:SetJustifyH("RIGHT")
        TrackThemeText(lb, 0.75)
        f.yLabels[i] = lb
    end
    f.xLabels = {}
    for i = 0, 2 do
        local lb = f:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
        lb:SetPoint("TOP", plot, "BOTTOMLEFT", GPH_PLOT_W * i / 2, -6)
        TrackThemeText(lb, 0.75)
        f.xLabels[i] = lb
    end

    f.lines, f.fills = {}, {}
    f.cursor = plot:CreateLine()
    f.cursor:SetThickness(1); f.cursor:SetColorTexture(0.9, 0.9, 0.9, 0.45); f.cursor:Hide()
    f.dot = plot:CreateTexture(nil, "OVERLAY")
    f.dot:SetSize(8, 8); f.dot:SetColorTexture(1, 0.86, 0.30, 1); f.dot:Hide()
    f.endDot = plot:CreateTexture(nil, "OVERLAY")
    f.endDot:SetSize(7, 7); f.endDot:SetColorTexture(0.35, 1, 0.55, 1); f.endDot:Hide()

    f.empty = plot:CreateFontString(nil, "OVERLAY", "GameFontNormal")
    f.empty:SetPoint("CENTER")
    f.empty:SetText("Start a session to see your gold per hour")
    TrackThemeText(f.empty, 0.7)

    f.hint = f:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
    f.hint:SetPoint("BOTTOM", 0, 12)
    f.hint:SetText("Updates every second  -  hover the graph for exact values")
    TrackThemeText(f.hint, 0.55)

    -- Hover readout
    plot:EnableMouse(true)
    local tick = 0
    plot:SetScript("OnLeave", function()
        f.cursor:Hide(); f.dot:Hide(); GameTooltip:Hide(); f._hoverOn = nil
    end)
    plot:SetScript("OnUpdate", function(self, elapsed)
        tick = tick + elapsed
        if tick < 0.05 then return end
        tick = 0
        local pts = f._pts
        if not pts or not self:IsMouseOver() then
            if f._hoverOn then f.cursor:Hide(); f.dot:Hide(); GameTooltip:Hide(); f._hoverOn = nil end
            return
        end
        local mx = GetCursorPosition() / self:GetEffectiveScale() - self:GetLeft()
        local frac = math.min(1, math.max(0, mx / GPH_PLOT_W))
        local t0, t1 = pts[1].t, pts[#pts].t
        local want = t0 + (t1 - t0) * frac
        local best, bestD = 1, math.huge
        for i = 1, #pts do
            local d = math.abs(pts[i].t - want)
            if d < bestD then best, bestD = i, d end
        end
        local p = pts[best]
        local x = (t1 > t0) and ((p.t - t0) / (t1 - t0) * GPH_PLOT_W) or 0
        local y = (f._max > 0) and (p.v / f._max * GPH_PLOT_H) or 0
        f.cursor:SetStartPoint("BOTTOMLEFT", self, x, 0)
        f.cursor:SetEndPoint("BOTTOMLEFT", self, x, GPH_PLOT_H)
        f.cursor:Show()
        f.dot:ClearAllPoints(); f.dot:SetPoint("CENTER", self, "BOTTOMLEFT", x, y); f.dot:Show()
        f._hoverOn = true
        GameTooltip:SetOwner(self, "ANCHOR_CURSOR")
        GameTooltip:SetText("At "..FormatTime(p.t))
        GameTooltip:AddLine(Coin(p.v).." per hour", 1, 1, 1)
        GameTooltip:Show()
    end)
    plot:SetScript("OnHide", function() GameTooltip:Hide() end)
    return f
end

DrawGphGraph = function()
    local f = gphGraphFrame
    if not f then return end
    local pts = GphSeries()
    f._pts = pts

    local now, peak, avg = 0, 0, 0
    if S then
        now = math.floor(S.emaGPH or 0)
        if S.timer and S.timer > 0 then
            avg = math.floor((S.coinGold + S.itemGold) / S.timer * 3600)
        end
    end
    if S and S.gphSamples then
        for i = 1, #S.gphSamples do if S.gphSamples[i].v > peak then peak = S.gphSamples[i].v end end
    end
    f.summary:SetText("Now: "..Coin(now).."    Peak: "..Coin(math.floor(peak)).."    Average: "..Coin(avg))

    for _, ln in ipairs(f.lines) do ln:Hide() end
    for _, fl in ipairs(f.fills) do fl:Hide() end
    f.endDot:Hide()
    if not pts then
        f._max = 0
        f.empty:Show()
        for i = 0, 4 do f.yLabels[i]:SetText("") end
        for i = 0, 2 do f.xLabels[i]:SetText("") end
        return
    end
    f.empty:Hide()

    local maxV = 0
    for i = 1, #pts do if pts[i].v > maxV then maxV = pts[i].v end end
    local top = math.max(maxV * 1.1, 100)
    f._max = top
    for i = 0, 4 do f.yLabels[i]:SetText(CoinShort(top * i / 4)) end
    local t0, t1 = pts[1].t, pts[#pts].t
    f.xLabels[0]:SetText(FormatTime(t0))
    f.xLabels[1]:SetText(FormatTime((t0 + t1) / 2))
    f.xLabels[2]:SetText(FormatTime(t1))

    local span = math.max(1, t1 - t0)
    local prevX, prevY
    for i = 1, #pts do
        local x = (pts[i].t - t0) / span * GPH_PLOT_W
        local y = pts[i].v / top * GPH_PLOT_H
        if prevX then
            local ln = f.lines[i - 1]
            if not ln then
                ln = f.plot:CreateLine()
                ln:SetThickness(2)
                ln:SetColorTexture(0.35, 1, 0.55, 0.95)
                f.lines[i - 1] = ln
            end
            ln:SetStartPoint("BOTTOMLEFT", f.plot, prevX, prevY)
            ln:SetEndPoint("BOTTOMLEFT", f.plot, x, y)
            ln:Show()
            -- Faint fill under the line (one thin bar per segment)
            local fl = f.fills[i - 1]
            if not fl then
                fl = f.plot:CreateTexture(nil, "ARTWORK")
                fl:SetColorTexture(0.35, 1, 0.55, 0.10)
                f.fills[i - 1] = fl
            end
            fl:ClearAllPoints()
            fl:SetPoint("BOTTOMLEFT", f.plot, "BOTTOMLEFT", prevX, 0)
            fl:SetSize(math.max(1, x - prevX + 0.5), math.max(1, (prevY + y) / 2))
            fl:Show()
        end
        prevX, prevY = x, y
    end
    f.endDot:ClearAllPoints()
    f.endDot:SetPoint("CENTER", f.plot, "BOTTOMLEFT", prevX, prevY)
    f.endDot:Show()
end

ToggleGphGraph = function()
    if not gphGraphFrame then
        BuildGphGraph()
        gphGraphFrame:ClearAllPoints()
        if mainFrame then
            gphGraphFrame:SetPoint("TOPLEFT", mainFrame, "TOPRIGHT", 8, 0)
        else
            gphGraphFrame:SetPoint("CENTER", 200, 0)
        end
    end
    if gphGraphFrame:IsShown() then
        gphGraphFrame:Hide()
    else
        GDS_TabSwitcher.CloseOthers("GTGphGraphFrame")
        gphGraphFrame:Show()
        DrawGphGraph()
    end
end

-- The header Skins button uses a separate, extendable palette selector.
-- Do not create additional top-level locals in this large addon's chunk.
GDS_Skins = GDS_Skins or {}
function GDS_Skins.Toggle()
    if GDS_Skins.frame and GDS_Skins.frame:IsShown() then
        GDS_Skins.frame:Hide()
        return
    end
    GDS_TabSwitcher.CloseOthers("GTSkinsFrame")
    if GDS_Skins.frame then
        if GDS_Skins.Refresh then GDS_Skins.Refresh() end
        GDS_Skins.frame:Show()
        return
    end
    local panel = CreateFrame("Frame", "GTSkinsFrame", mainFrame,
        BackdropTemplateMixin and "BackdropTemplate")
    GDS_FocusWindow(panel)
    panel:SetSize(253, 502)
    panel:SetPoint("TOPLEFT", mainFrame, "TOPRIGHT", 6, 0)
    panel:SetFrameStrata("DIALOG")
    panel:SetFrameLevel(mainFrame:GetFrameLevel() + 15)
    ApplyBackdrop(panel)
    GDS_Skins.frame = panel

    local ttl = panel:CreateFontString(nil, "OVERLAY", "GameFontNormal")
    ttl:SetPoint("TOPLEFT", 12, -11)
    ttl:SetText("Skins")
    table.insert(GT_titles, ttl)
    local exitBtn = MakeBtn(panel, 20, 20, "X")
    exitBtn:SetPoint("TOPRIGHT", -6, -6)
    exitBtn:SetScript("OnClick", function() panel:Hide() end)

    local choices = {
        { mode="default", title="Original", description="Clean charcoal and slate", bg={.025,.033,.043}, trim={.22,.31,.40} },
        { mode="wow", title="Vanilla WoW", description="Classic brown and gold", bg={.105,.070,.032}, trim={.58,.40,.15} },
        { mode="authenticvanilla", title="Authentic Vanilla (Exp)", description="Blizzard art, buttons and trim", bg={.36,.29,.20}, trim={.88,.67,.33} },
        { mode="classicstone", title="Classic Stone (Exp)", description="WoW rock texture + ornate frame", bg={.57,.55,.50}, trim={.80,.63,.33} },
        { mode="classicleather", title="Classic Leather (Exp)", description="WoW dialog box + gold border", bg={.68,.56,.39}, trim={.81,.58,.28} },
        { mode="tooltipframe", title="Tooltip Frame (Exp)", description="Blizzard tooltip-style window", bg={.10,.10,.15}, trim={.57,.51,.72} },
        { mode="nightfall", title="Nightfall", description="Obsidian, amethyst, silver", bg={.020,.015,.035}, trim={.42,.30,.62} },
        { mode="wowlook", title="WoW Experimental", description="Carved borders, inset panels and gold tabs", bg={.05,.035,.023}, trim={.80,.60,.28} },
    }
    local marks = {}
    for i, entry in ipairs(choices) do
        local skinKey = entry.mode
        local row = MakeBtn(panel, 231, 48, "")
        row:SetPoint("TOPLEFT", 11, -39 - (i - 1) * 53)
        local swatch = row:CreateTexture(nil, "ARTWORK")
        swatch:SetSize(25, 29)
        swatch:SetPoint("LEFT", 8, 0)
        swatch:SetColorTexture(entry.bg[1], entry.bg[2], entry.bg[3], 1)
        local trim = row:CreateTexture(nil, "OVERLAY")
        trim:SetSize(3, 29)
        trim:SetPoint("LEFT", 8, 0)
        trim:SetColorTexture(entry.trim[1], entry.trim[2], entry.trim[3], 1)
        local name = row:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
        name:SetPoint("TOPLEFT", 45, -9)
        name:SetText(entry.title)
        TrackThemeText(name)
        local detail = row:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
        detail:SetPoint("TOPLEFT", 45, -25)
        detail:SetText(entry.description)
        detail:SetTextColor(.65, .68, .73, 1)
        local mark = row:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
        mark:SetPoint("TOPRIGHT", -8, -9)
        mark:SetTextColor(.65, 1, .72, 1)
        marks[skinKey] = mark
        row:SetScript("OnClick", function()
            SetSkinMode(skinKey)
            if GDS_Skins.Refresh then GDS_Skins.Refresh() end
        end)
    end
    local note = panel:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
    note:SetPoint("BOTTOMLEFT", 12, 11)
    note:SetText("Skin saved; /gt rescue restores Original")
    note:SetTextColor(.68, .70, .75, 1)
    GDS_Skins.Refresh = function()
        local current = DB and DB.skinMode or "default"
        for skinKey, mark in pairs(marks) do
            mark:SetText(skinKey == current and "[ON]" or "")
        end
    end
    GDS_Skins.Refresh()
    panel:Show()
end

local function BuildMainFrame()
    mainFrame = CreateFrame("Frame", "GTMainFrame", UIParent,
        BackdropTemplateMixin and "BackdropTemplate")
    GDS_FocusWindow(mainFrame)
    mainFrame:Hide()
    -- Title, party opt-in, P shortcut and existing header buttons must not overlap.
    -- Widen narrow older saved layouts once; normal resizing is still supported.
    DB.mainW = math.max(DB.mainW or 540, 540)
    mainFrame:SetSize(DB.mainW, DB.mainH or 380)
    mainFrame:SetPoint("CENTER")
    mainFrame:EnableMouse(true); mainFrame:SetMovable(true)
    mainFrame:SetClampedToScreen(true); mainFrame:RegisterForDrag("LeftButton")
    ApplyBackdrop(mainFrame)

    local header = CreateFrame("Frame", nil, mainFrame)
    header:SetPoint("TOPLEFT", 6, -6)
    header:SetPoint("TOPRIGHT", -6, -6)
    header:SetHeight(42)
    local headerBg = header:CreateTexture(nil, "BACKGROUND")
    headerBg:SetAllPoints()
    local _hb = DB and DB.theme
    headerBg:SetColorTexture(_hb and _hb.headerR or 0.045, _hb and _hb.headerG or 0.06, _hb and _hb.headerB or 0.078, _hb and _hb.headerA or 0.84)
    table.insert(GT_headers, headerBg)
    local headerRule = header:CreateTexture(nil, "BORDER")
    headerRule:SetPoint("BOTTOMLEFT")
    headerRule:SetPoint("BOTTOMRIGHT")
    headerRule:SetHeight(1)
    local _hr = DB and DB.theme
    headerRule:SetColorTexture(_hr and _hr.borderR or 0.22, _hr and _hr.borderG or 0.31, _hr and _hr.borderB or 0.40, 0.72)
    table.insert(GT_dividers, headerRule)
    table.insert(GT_headerRules, headerRule)

    local ttl = header:CreateFontString(nil,"OVERLAY","GameFontNormalLarge")
    ttl:SetPoint("TOPLEFT", 12, -7)
    -- Two compact lines keep the longer title clear of the header buttons,
    -- including at the window's minimum width.
    ttl:SetWidth(108)
    ttl:SetJustifyH("LEFT")
    local titleFont, _, titleFlags = ttl:GetFont()
    if titleFont then ttl:SetFont(titleFont, 12, titleFlags) end
    ttl:SetText("Grind Don't\nStop, Won't Stop")
    local _mt = DB and DB.theme
    ttl:SetTextColor(_mt and _mt.accentR or 0.88, _mt and _mt.accentG or 0.92, _mt and _mt.accentB or 0.96)
    table.insert(GT_titles, ttl)

    -- Opt-in party sharing lives next to the title instead of Settings.
    -- It does NOT control healer mana or threat monitoring; those remain solo-capable.
    local partyToggle = CreateFrame("CheckButton", nil, header, "UICheckButtonTemplate")
    partyToggle:SetSize(20, 20)
    partyToggle:SetPoint("TOPLEFT", 129, -10)
    partyToggle:SetChecked(DB.partyTracking == true)
    mainFrame.partyToggle = partyToggle
    partyToggle:SetScript("OnEnter", function(self)
        GameTooltip:SetOwner(self, "ANCHOR_BOTTOM")
        GameTooltip:SetText("Enable Party Tracking")
        GameTooltip:AddLine("Share farming stats with party members who also opt in.", .8,.8,.8,true)
        GameTooltip:AddLine("The P button opens Party Stats and alert settings.", .7,.8,.9,true)
        GameTooltip:Show()
    end)
    partyToggle:SetScript("OnLeave", function() GameTooltip:Hide() end)

    local partyHeaderBtn = MakeBtn(mainFrame, 23, 22, "P")
    partyHeaderBtn:SetPoint("TOPLEFT", header, "TOPLEFT", 154, -10)
    partyHeaderBtn:SetShown(DB.partyTracking == true)
    mainFrame.partyHeaderBtn = partyHeaderBtn
    partyHeaderBtn:SetScript("OnClick", function() ToggleSettings(true) end)
    partyHeaderBtn:SetScript("OnEnter", function(self)
        GameTooltip:SetOwner(self, "ANCHOR_BOTTOM")
        GameTooltip:SetText("Party Stats")
        GameTooltip:AddLine("Open multiplayer stats, the compact window and mana/threat alerts.", .8,.8,.8,true)
        GameTooltip:Show()
    end)
    partyHeaderBtn:SetScript("OnLeave", function() GameTooltip:Hide() end)
    partyToggle:SetScript("OnClick", function(self)
        local enabled = GDS_CheckboxChecked(self)
        if not enabled then
            GDS_PartySession.Stop()
            PartySend("OFF")
        end
        DB.partyTracking = enabled
        partyHeaderBtn:SetShown(enabled)
        ClearPartyPeers()
        if enabled then PartyRosterChanged() end
        if RefreshPartyStats then RefreshPartyStats() end
    end)

    -- Only one compact shortcut; text editing lives in its own popup.
    local metaBtn = MakeBtn(mainFrame, 20, 22, "N")
    metaBtn:SetPoint("TOPLEFT", header, "TOPLEFT", 179, -10)
    mainFrame.metaBtn = metaBtn
    metaBtn:SetScript("OnClick", function() GDS_SessionMeta.Open(S) end)
    metaBtn:SetScript("OnEnter", function(self)
        GameTooltip:SetOwner(self, "ANCHOR_BOTTOM")
        GameTooltip:SetText("Session Name / Note")
        if S and S.sessionName and S.sessionName ~= "" then
            GameTooltip:AddLine(S.sessionName, 1, .86, .55, true)
        end
        if S and S.sessionNote and S.sessionNote ~= "" then
            GameTooltip:AddLine(S.sessionNote, .8, .85, .95, true)
        end
        GameTooltip:AddLine("Click to label the current run or add a note.", .75,.8,.85,true)
        GameTooltip:AddLine("Saved sessions can be edited with right-click in History.", .65,.75,.85,true)
        GameTooltip:Show()
    end)
    metaBtn:SetScript("OnLeave", function() GameTooltip:Hide() end)
    GDS_SessionMeta.RefreshBadge()

    -- Header tools: analytics, history, settings, M mini view, close.
    -- Live GPH graph button: a small line-chart icon drawn from lines
    local gb = MakeBtn(mainFrame, 24, 22, "")
    gb:SetPoint("TOPRIGHT",-308,-16)
    do
        local th = (DB and DB.theme) or DEFAULT_THEME
        local pts = {{4, 6}, {8, 12}, {12, 8}, {16, 16}, {20, 14}}
        for i = 2, #pts do
            local ln = gb:CreateLine(nil, "OVERLAY")
            ln:SetThickness(1.5)
            ln:SetColorTexture(th.accentR or 0.88, th.accentG or 0.92, th.accentB or 0.96, 1)
            ln:SetStartPoint("BOTTOMLEFT", gb, pts[i-1][1], pts[i-1][2] + 1)
            ln:SetEndPoint("BOTTOMLEFT", gb, pts[i][1], pts[i][2] + 1)
        end
        local base = gb:CreateLine(nil, "OVERLAY")
        base:SetThickness(1)
        base:SetColorTexture(0.55, 0.62, 0.70, 0.8)
        base:SetStartPoint("BOTTOMLEFT", gb, 4, 4)
        base:SetEndPoint("BOTTOMLEFT", gb, 20, 4)
    end
    gb:SetScript("OnClick", ToggleGphGraph)
    gb:SetScript("OnEnter", function(f)
        GameTooltip:SetOwner(f,"ANCHOR_RIGHT")
        GameTooltip:SetText("Live GPH Graph\nLine graph of your gold per hour this session")
        GameTooltip:Show()
    end)
    gb:SetScript("OnLeave", function() GameTooltip:Hide() end)

    local lb = MakeBtn(mainFrame, 64, 22, "Analytics")
    lb:SetPoint("TOPRIGHT",-240,-16)
    lb:SetScript("OnClick", ToggleLootLog)
    lb:SetScript("OnEnter", function(f)
        GameTooltip:SetOwner(f,"ANCHOR_RIGHT")
        GameTooltip:SetText("Analytics\nLoot log, line chart, bar chart, pie chart")
        GameTooltip:Show()
    end)
    lb:SetScript("OnLeave", function() GameTooltip:Hide() end)

    local hb = MakeBtn(mainFrame, 54, 22, "History")
    hb:SetPoint("TOPRIGHT",-184,-16)
    hb:SetScript("OnClick", ToggleHistory)
    hb:SetScript("OnEnter", function(f)
        GameTooltip:SetOwner(f,"ANCHOR_RIGHT")
        GameTooltip:SetText("Session History\nView all past sessions & totals")
        GameTooltip:Show()
    end)
    hb:SetScript("OnLeave", function() GameTooltip:Hide() end)

    local sb = MakeBtn(mainFrame, 56, 22, "Settings")
    sb:SetPoint("TOPRIGHT",-126,-16)
    sb:SetScript("OnClick", function() ToggleSettings(false) end)
    sb:SetScript("OnEnter", function(f)
        GameTooltip:SetOwner(f,"ANCHOR_RIGHT")
        GameTooltip:SetText("Settings\n|cFFAAAAAA/gt debug|r to toggle debug")
        GameTooltip:Show()
    end)
    sb:SetScript("OnLeave", function() GameTooltip:Hide() end)

    -- Separate expandable Skins selector; kept out of the settings layout.
    local skinHeaderBtn = MakeBtn(mainFrame, 44, 22, "Skins")
    skinHeaderBtn:SetPoint("TOPRIGHT", -80, -16)
    skinHeaderBtn:SetScript("OnClick", GDS_Skins.Toggle)
    skinHeaderBtn:SetScript("OnEnter", function(f)
        GameTooltip:SetOwner(f, "ANCHOR_RIGHT")
        GameTooltip:SetText("Skins\nOriginal, Vanilla WoW, Authentic Vanilla, Classic Stone, Classic Leather, Tooltip Frame, Nightfall, WoW Experimental")
        GameTooltip:Show()
    end)
    skinHeaderBtn:SetScript("OnLeave", function() GameTooltip:Hide() end)

    -- Left-click Mini opens Gold/GPH; right-click opens XP/XP/h.
    -- Once compact, right-click the L button on either bar to toggle the other.
    local compactBtn = MakeBtn(mainFrame, 42, 22, "Mini")
    compactBtn:SetPoint("TOPRIGHT", -36, -16)
    compactBtn:RegisterForClicks("LeftButtonUp", "RightButtonUp")
    compactBtn:SetScript("OnClick", function(_, button)
        if not (GDS_MiniViews and GDS_MiniViews.Show) then return end
        mainFrame:Hide()
        if settingsFrame then settingsFrame:Hide() end
        GDS_MiniViews.Show(button == "RightButton" and "xp" or "gold")
    end)
    compactBtn:SetScript("OnEnter", function(f)
        GameTooltip:SetOwner(f, "ANCHOR_LEFT")
        GameTooltip:SetText("Mini views\nLeft: Gold / GPH\nRight: XP / XP per hour\nRight-click L: Toggle the other mini\nMiddle-click L: Snap both minis")
        GameTooltip:Show()
    end)
    compactBtn:SetScript("OnLeave", function() GameTooltip:Hide() end)

    local xb = MakeBtn(mainFrame, 24, 22, "X")
    xb:SetPoint("TOPRIGHT",-10,-16)
    xb:SetScript("OnClick", function() mainFrame:Hide() end)

    -- Clip container: rows live inside this frame so SetClipsChildren(true) creates a
    -- scissor rectangle that hides content that falls outside the resizable window area.
    -- Font strings on direct child frames ARE included in the scissor; font strings
    -- created on mainFrame itself would not be — hence the extra level of indirection.
    local contentClip = CreateFrame("Frame", nil, mainFrame)
    contentClip:SetPoint("TOPLEFT",     0, -54)
    contentClip:SetPoint("BOTTOMRIGHT", 0,  60)
    contentClip:SetClipsChildren(true)
    mainContentClip = contentClip

    -- Inline chart panel (same bounds as contentClip, swapped in by < / > arrows)
    mainChartFrame = CreateFrame("Frame", nil, mainFrame)
    mainChartFrame:SetPoint("TOPLEFT",     0, -54)
    mainChartFrame:SetPoint("BOTTOMRIGHT", 0,  60)
    mainChartFrame:Hide()
    mainChartFrame:SetScript("OnSizeChanged", function()
        if mainChartFrame:IsShown() and mainChartKey ~= "stats" then
            local k = mainChartKey
            C_Timer.After(0, function()
                if     k == "line" then DrawLineChart(mainChartFrame)
                elseif k == "bar"  then DrawBarChart(mainChartFrame)
                elseif k == "pie"  then DrawPieChart(mainChartFrame) end
            end)
        end
    end)

    statRows = {}
    local yo = -6
    local rowDefs = {
        {k="time", l="Session Time"}, {k="kills", l="Kills"}, {k="kph", l="K/h"},
        {k="fish", l="Fish"}, {k="fishph", l="Fish/h"},
        {k="xp", l="XP Earned"}, {k="xph", l="XP Earned/H"}, {k="lvlt", l="Time Until Next Level"},
        {k="coin", l="Coin Looted"}, {k="items", l="Items Loot Value"}, {k="total", l="Total Value"},
        {k="gph", l="Gold Per Hour"},
        {k="durability", l="Durability"}, {k="repairs", l="Repairs Paid"},
        {k="questDivider", l=""}, {k="questxp", l="Quest XP"}, {k="questcoin", l="Quest Coin"},
        {k="pvpDivider", l=""}, {k="pvpHK", l="Honorable Kills"},
        {k="pvpKB", l="Hon. Killing Blows"},
    }
    for i, def in ipairs(rowDefs) do
        -- Each row is a child Frame so the scissor clips its font strings too.
        local rowFrame = CreateFrame("Frame", nil, contentClip)
        rowFrame:SetPoint("TOPLEFT",  10, yo)
        rowFrame:SetPoint("TOPRIGHT", -10, yo)
        rowFrame:SetHeight(22)
        local rowBg = rowFrame:CreateTexture(nil, "BACKGROUND")
        rowBg:SetAllPoints()
        rowBg._gtAlpha = (i % 2 == 0) and 0.24 or 0.34
        local _rp = DB and DB.theme
        rowBg:SetColorTexture(_rp and _rp.headerR or 0.045, _rp and _rp.headerG or 0.06, _rp and _rp.headerB or 0.078, rowBg._gtAlpha)
        table.insert(GT_softPanels, rowBg)
        GDS_WoWLook.SyncStatRow(rowFrame)
        local lbl = rowFrame:CreateFontString(nil,"OVERLAY","GameFontHighlight")
        lbl:SetPoint("LEFT", 10, 0); TrackThemeText(lbl, 0.62); lbl:SetText(def.l)
        local val = rowFrame:CreateFontString(nil,"OVERLAY","GameFontHighlight")
        val:SetPoint("LEFT", lbl, "RIGHT", 10, 0)
        val:SetPoint("RIGHT", -10, 0)
        val:SetJustifyH("RIGHT"); TrackThemeText(val, 0.98); val:SetText("0")
        statRows[def.k] = {frame=rowFrame, bg=rowBg, lbl=lbl, val=val}
        if def.k == "questDivider" or def.k == "pvpDivider" then
            rowFrame:SetHeight(12)
            rowBg:Hide()
            lbl:Hide(); val:Hide()
            local rule = rowFrame:CreateTexture(nil, "ARTWORK")
            rule:SetHeight(2)
            rule:SetPoint("LEFT", 4, 0)
            rule:SetPoint("RIGHT", -4, 0)
            local theme = DB and DB.theme or DEFAULT_THEME
            rule:SetColorTexture(theme.borderR, theme.borderG, theme.borderB, 0.95)
            table.insert(GT_dividers, rule)
        elseif def.k == "questxp" or def.k == "questcoin"
            or def.k == "pvpHK" or def.k == "pvpKB" then
            -- Make the two quest totals bold while matching the existing skin.
            lbl:SetFontObject("GameFontNormal")
            val:SetFontObject("GameFontNormal")
            TrackThemeText(lbl, 0.95)
            TrackThemeText(val, 0.98)
        end
        if def.k == "durability" then
            rowFrame:EnableMouse(true)
            rowFrame:SetScript("OnEnter", function(self)
                GameTooltip:SetOwner(self, "ANCHOR_RIGHT")
                GameTooltip:SetText("Equipment Durability")
                local avg, low, broken = GDS_Repairs.ReadDurability()
                if avg then
                    GameTooltip:AddLine("Equipped: " .. avg .. "%   Lowest item: " .. low .. "%", 1, 1, 1)
                    if broken then GameTooltip:AddLine("At least one item is broken", 1, .45, .35) end
                else
                    GameTooltip:AddLine("Durability unavailable on this client", 1, .7, .55)
                end
                local copper, method = GDS_Repairs.EstimateRepair()
                if copper ~= nil then
                    GameTooltip:AddLine("Estimated repair: " .. CoinShort(copper), 1, .83, .47)
                    GameTooltip:AddLine(method == "item tooltip" and
                        "From equipped-item tooltip data (may vary by vendor)." or
                        "Rough estimate from equipped gear; actual vendor price varies.", .72, .78, .83, true)
                else
                    GameTooltip:AddLine("Estimated repair: unavailable", 1, .75, .55)
                end
                GameTooltip:AddLine("Only equipped gear is included; bags and NPC discounts may change the bill.", .67, .73, .8, true)
                if DB.repairTracking then
                    GameTooltip:AddLine("Repairs paid this session: " .. CoinShort(S and S.repairCosts or 0), .75, .88, 1)
                end
                GameTooltip:Show()
            end)
            rowFrame:SetScript("OnLeave", function() GameTooltip:Hide() end)
        end
        if def.k == "repairs" then
            rowFrame:EnableMouse(true)
            rowFrame:SetScript("OnEnter", function(self)
                GameTooltip:SetOwner(self, "ANCHOR_RIGHT")
                GameTooltip:SetText("Repairs Paid")
                GameTooltip:AddLine("Confirmed repair expenses during this personal session.", 1, 1, 1, true)
                GameTooltip:AddLine("Gold, Total Value, and GPH remain gross and are not reduced by repairs.", .7, .8, .9, true)
                GameTooltip:Show()
            end)
            rowFrame:SetScript("OnLeave", function() GameTooltip:Hide() end)
        end
        if def.k == "questxp" or def.k == "questcoin" then
            rowFrame:EnableMouse(true)
            rowFrame:SetScript("OnEnter", function(self)
                GameTooltip:SetOwner(self, "ANCHOR_RIGHT")
                if def.k == "questxp" then
                    GameTooltip:SetText("Quest XP")
                    GameTooltip:AddLine("Current session: " .. FmtNum(S and S.questXP or 0), 1, 1, 1)
                    GameTooltip:AddLine("All-time tracked: " .. FmtNum(DB and DB.questTotals and DB.questTotals.xp or 0), .9, .75, .42)
                else
                    GameTooltip:SetText("Quest Coin")
                    GameTooltip:AddLine("Current session: " .. CoinShort(S and S.questGold or 0), 1, 1, 1)
                    GameTooltip:AddLine("Includes estimated quest loot value: " .. CoinShort(S and S.questItemGold or 0), .9, .78, .45)
                    GameTooltip:AddLine("Quest loot value is an estimate, not money received.", .7, .8, .9, true)
                    GameTooltip:AddLine("All-time tracked: " .. CoinShort(DB and DB.questTotals and DB.questTotals.gold or 0), .9, .75, .42)
                end
                GameTooltip:Show()
            end)
            rowFrame:SetScript("OnLeave", function() GameTooltip:Hide() end)
        end
        if def.k == "pvpHK" or def.k == "pvpKB" then
            -- HK hover shows Blizzard's real lifetime HKs (including kills from
            -- before installation). KB hover shows locally recorded lifetime
            -- blows: Blizzard does not expose the equivalent total here.
            rowFrame:EnableMouse(true)
            rowFrame:SetScript("OnEnter", function(self)
                GameTooltip:SetOwner(self, "ANCHOR_RIGHT")
                GameTooltip:SetText(def.k == "pvpHK" and "Honorable Kills" or "Hon. Killing Blows")
                GameTooltip:AddLine("Current session: " .. FmtNum((S and (def.k == "pvpHK" and S.pvpHK or S.pvpKB)) or 0), 1, 1, 1)
                if def.k == "pvpHK" then
                    local lifetime = GDS_PvP and GDS_PvP.ReadLifetimeHK and GDS_PvP.ReadLifetimeHK()
                    GameTooltip:AddLine("All-time HKs: " .. (lifetime and FmtNum(lifetime) or "Loading..."), .9, .75, .42)
                    GameTooltip:AddLine("Blizzard-credited group assists count in both totals while your personal session is running.", .7, .8, .9, true)
                else
                    local totals = DB and DB.pvpTotals or {}
                    GameTooltip:AddLine("All-time tracked KBs: " .. FmtNum(totals.kb or 0), .9, .75, .42)
                end
                GameTooltip:Show()
            end)
            rowFrame:SetScript("OnLeave", function() GameTooltip:Hide() end)
        end
        -- EasyFishing rows stay hidden until RefreshStats decides to show them.
        if def.k == "fish" or def.k == "fishph" or def.k == "questDivider"
            or def.k == "questxp" or def.k == "questcoin"
            or def.k == "pvpDivider" or def.k == "pvpHK" or def.k == "pvpKB" then
            rowFrame:Hide(); lbl:Hide(); val:Hide()
        end

        -- Edit Mode adds a small grip only while editing. Existing hover
        -- tooltips retain their normal behavior when editing is switched off.
        local key, rowName = def.k, def.l
        local nativeEnter = rowFrame:GetScript("OnEnter")
        local nativeLeave = rowFrame:GetScript("OnLeave")
        statRows[key].hasNativeTooltip = nativeEnter ~= nil
        local gripText = rowFrame:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
        gripText:SetPoint("LEFT", 5, 0)
        gripText:SetText("::")
        gripText:SetTextColor(1, .75, .30, 1)
        gripText:Hide()
        statRows[key].handle = gripText
        rowFrame:SetScript("OnEnter", function(self)
            if GDS_RowLayout.editMode then
                if GDS_RowLayout.dragKey then return end
                GameTooltip:SetOwner(self, "ANCHOR_RIGHT")
                GameTooltip:SetText(rowName ~= "" and rowName or "Section Divider")
                GameTooltip:AddLine("Hold left mouse and drag to reorder this row.", .8, .8, .8, true)
                GameTooltip:Show()
            elseif nativeEnter then
                nativeEnter(self)
            end
        end)
        rowFrame:SetScript("OnLeave", function(self)
            if nativeLeave then nativeLeave(self) else GameTooltip:Hide() end
        end)
        rowFrame:RegisterForDrag("LeftButton")
        rowFrame:SetScript("OnDragStart", function() GDS_RowLayout.BeginDrag(key) end)
        rowFrame:SetScript("OnDragStop", function() GDS_RowLayout.EndDrag(key) end)
        rowFrame:EnableMouse(statRows[key].hasNativeTooltip)
        yo = yo - 23
    end

    local footer = CreateFrame("Frame", nil, mainFrame)
    footer:SetPoint("BOTTOMLEFT", 6, 6)
    footer:SetPoint("BOTTOMRIGHT", -6, 6)
    footer:SetHeight(50)
    local footerBg = footer:CreateTexture(nil, "BACKGROUND")
    footerBg:SetAllPoints()
    local _fb = DB and DB.theme
    footerBg:SetColorTexture(_fb and _fb.footerR or 0.045, _fb and _fb.footerG or 0.06, _fb and _fb.footerB or 0.078, _fb and _fb.footerA or 0.84)
    table.insert(GT_footers, footerBg)
    local footerRule = footer:CreateTexture(nil, "BORDER")
    footerRule:SetPoint("TOPLEFT")
    footerRule:SetPoint("TOPRIGHT")
    footerRule:SetHeight(1)
    local _fr = DB and DB.theme
    footerRule:SetColorTexture(_fr and _fr.borderR or 0.22, _fr and _fr.borderG or 0.31, _fr and _fr.borderB or 0.40, 0.72)
    table.insert(GT_dividers, footerRule)
    table.insert(GT_footerRules, footerRule)

    -- Narrow Start slightly to provide room for the login checkbox at the
    -- minimum window width, without overlapping the centered arrow/lock group.
    local startBtn = MakeBtn(mainFrame, 94, 24, "Start")
    startBtn:SetPoint("BOTTOMLEFT",12,25)
    startBtn:SetScript("OnClick", TogglePause)
    mainFrame.startBtn = startBtn

    -- Default OFF: login keeps the tracker closed and does not start a NEW run.
    -- ON: show the personal window and start tracking on the next login.
    -- A previously running saved session will still restore in either mode.
    local loginCB = CreateFrame("CheckButton", nil, mainFrame, "UICheckButtonTemplate")
    loginCB:SetSize(18, 18)
    loginCB:SetPoint("LEFT", startBtn, "RIGHT", 4, 0)
    loginCB:SetFrameLevel(footer:GetFrameLevel() + 5)
    loginCB:SetChecked(DB.startOnLogin == true)
    mainFrame.startOnLoginCB = loginCB
    local loginLabel = loginCB:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
    loginLabel:SetPoint("LEFT", loginCB, "RIGHT", 2, 0)
    loginLabel:SetWidth(80)
    loginLabel:SetJustifyH("LEFT")
    loginLabel:SetText("Start on Login")
    TrackThemeText(loginLabel)
    loginCB:SetScript("OnClick", function(self)
        DB.startOnLogin = GDS_CheckboxChecked(self)
    end)
    loginCB:SetScript("OnEnter", function(self)
        GameTooltip:SetOwner(self, "ANCHOR_TOP")
        GameTooltip:SetText("Start on Login")
        GameTooltip:AddLine("On: open the personal tracker and start a new session when logging in.", .8, .8, .8, true)
        GameTooltip:AddLine("Off (default): keep the window hidden. Ongoing saved sessions still resume normally.", .7, .8, .9, true)
        GameTooltip:Show()
    end)
    loginCB:SetScript("OnLeave", function() GameTooltip:Hide() end)

    -- Not a saved toggle: editing always defaults OFF on reload, but the row
    -- order itself is saved per character and survives sessions and reloads.
    -- The second checkbox fits in the narrow footer directly below Start on Login.
    local editCB = CreateFrame("CheckButton", nil, mainFrame, "UICheckButtonTemplate")
    editCB:SetSize(18, 18)
    editCB:SetPoint("TOPLEFT", loginCB, "BOTTOMLEFT", 0, -1)
    editCB:SetFrameLevel(footer:GetFrameLevel() + 5)
    editCB:SetChecked(false)
    mainFrame.editRowsCB = editCB
    local editLabel = editCB:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
    editLabel:SetPoint("LEFT", editCB, "RIGHT", 2, 0)
    editLabel:SetWidth(80)
    editLabel:SetJustifyH("LEFT")
    editLabel:SetText("Edit Mode")
    TrackThemeText(editLabel)
    editCB:SetScript("OnClick", function(self)
        GDS_RowLayout.SetEditMode(GDS_CheckboxChecked(self))
    end)
    editCB:SetScript("OnEnter", function(self)
        GameTooltip:SetOwner(self, "ANCHOR_TOP")
        GameTooltip:SetText("Edit Mode")
        GameTooltip:AddLine("Check to drag the main stats into any order. The new order saves automatically.", .8, .8, .8, true)
        GameTooltip:AddLine("Uncheck to restore normal window dragging and tooltips. Edit Mode starts off after reload.", .7, .8, .9, true)
        GameTooltip:Show()
    end)
    editCB:SetScript("OnLeave", function() GameTooltip:Hide() end)
    mainFrame:HookScript("OnHide", function() GDS_RowLayout.CancelDrag() end)

    local endBtn = MakeBtn(mainFrame, 108, 24, "End Session")
    endBtn:SetPoint("BOTTOMRIGHT",-12,25)
    endBtn:SetScript("OnClick", function() EndSession() end)

    -- Inline chart cycle: < / > swap out stats for a mini chart on the main frame
    local MAIN_CYCLE  = {"stats","line","bar","pie"}
    local MAIN_LABELS = {stats="Stats",line="Line",bar="Bar",pie="Pie"}

    local function SetMainChart(key)
        mainChartKey = key
        local showStats = (key == "stats")
        mainContentClip:SetShown(showStats)
        mainChartFrame:SetShown(not showStats)
        if not showStats then
            C_Timer.After(0, function()
                if     key == "line" then DrawLineChart(mainChartFrame)
                elseif key == "bar"  then DrawBarChart(mainChartFrame)
                elseif key == "pie"  then DrawPieChart(mainChartFrame) end
            end)
        end
    end

    local function CycleMain(dir)
        local idx = 1
        for i, t in ipairs(MAIN_CYCLE) do if t == mainChartKey then idx = i; break end end
        idx = ((idx - 1 + dir) % #MAIN_CYCLE) + 1
        SetMainChart(MAIN_CYCLE[idx])
    end

    local function AddSilverArrowIcon(button, direction)
        -- Build a crisp triangle from the same solid silver used by the lock.
        -- This avoids Blizzard arrow artwork whose black pixels cannot be tinted.
        local arrow = CreateFrame("Frame", nil, button)
        arrow:SetSize(12, 12)
        arrow:SetPoint("CENTER")

        local heights = direction == "left"
            and {1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12}
            or  {12, 11, 10, 9, 8, 7, 6, 5, 4, 3, 2, 1}
        for i, height in ipairs(heights) do
            local piece = arrow:CreateTexture(nil, "ARTWORK")
            piece:SetSize(1, height)
            piece:SetPoint("LEFT", arrow, "LEFT", i - 0.5, 0)
            piece:SetColorTexture(0.86, 0.89, 0.93, 1)
        end

        button:HookScript("OnMouseDown", function(_, mouseButton)
            if mouseButton == "LeftButton" then
                arrow:ClearAllPoints()
                arrow:SetPoint("CENTER", 1, -1)
            end
        end)
        button:HookScript("OnMouseUp", function()
            arrow:ClearAllPoints()
            arrow:SetPoint("CENTER")
        end)
    end

    local prevArrow = MakeBtn(mainFrame, 24, 24, "")
    AddSilverArrowIcon(prevArrow, "left")
    prevArrow:SetPoint("BOTTOMLEFT", startBtn, "BOTTOMRIGHT", 6, 0)
    prevArrow:SetScript("OnClick", function() CycleMain(-1) end)
    prevArrow:SetScript("OnEnter", function(f)
        GameTooltip:SetOwner(f,"ANCHOR_TOP")
        local idx = 1
        for i, t in ipairs(MAIN_CYCLE) do if t == mainChartKey then idx = i; break end end
        local prev = MAIN_CYCLE[((idx-2) % #MAIN_CYCLE)+1]
        GameTooltip:SetText("Show "..MAIN_LABELS[prev])
        GameTooltip:Show()
    end)
    prevArrow:SetScript("OnLeave", function() GameTooltip:Hide() end)

    local nextArrow = MakeBtn(mainFrame, 24, 24, "")
    AddSilverArrowIcon(nextArrow, "right")
    nextArrow:SetPoint("BOTTOMRIGHT", endBtn, "BOTTOMLEFT", -6, 0)
    nextArrow:SetScript("OnClick", function() CycleMain(1) end)
    nextArrow:SetScript("OnEnter", function(f)
        GameTooltip:SetOwner(f,"ANCHOR_TOP")
        local idx = 1
        for i, t in ipairs(MAIN_CYCLE) do if t == mainChartKey then idx = i; break end end
        local nxt = MAIN_CYCLE[(idx % #MAIN_CYCLE)+1]
        GameTooltip:SetText("Show "..MAIN_LABELS[nxt])
        GameTooltip:Show()
    end)
    nextArrow:SetScript("OnLeave", function() GameTooltip:Hide() end)

    -- Resize gripper at bottom-right corner (near Reset button)
    mainFrame:SetResizable(true)
    mainFrame:SetResizeBounds(540, 320, 740, 820)

    local grip = CreateFrame("Button", nil, mainFrame)
    grip:SetSize(16, 16)
    grip:SetPoint("BOTTOMRIGHT", 0, 0)
    local gripTex = grip:CreateTexture(nil, "OVERLAY")
    gripTex:SetAllPoints()
    gripTex:SetTexture("Interface\\ChatFrame\\UI-ChatIM-SizeGrabber-Up")
    grip:SetHighlightTexture("Interface\\ChatFrame\\UI-ChatIM-SizeGrabber-Highlight")
    grip:SetPushedTexture("Interface\\ChatFrame\\UI-ChatIM-SizeGrabber-Down")
    grip:RegisterForDrag("LeftButton")
    grip:SetScript("OnDragStart", function()
        mainFrame:StartSizing("BOTTOMRIGHT")
    end)
    grip:SetScript("OnDragStop", function()
        mainFrame:StopMovingOrSizing()
        DB.mainW = math.floor(mainFrame:GetWidth())
        DB.mainH = math.floor(mainFrame:GetHeight())
        local prof = DB.profiles and DB.currentProfile and DB.profiles[DB.currentProfile]
        if prof then
            prof.mainW = DB.mainW
            prof.mainH = DB.mainH
        end
    end)

    mainFrame:SetScript("OnDragStart", mainFrame.StartMoving)
    mainFrame:SetScript("OnDragStop", function(self)
        self:StopMovingOrSizing()
        local p,_,_,x,y = self:GetPoint()
        DB.mainPos = {p=p,x=x,y=y}
        local prof = DB.profiles and DB.currentProfile and DB.profiles[DB.currentProfile]
        if prof then prof.mainPos = {p=p,x=x,y=y} end
    end)

    -- Lock button — re-anchor all three as a centered group: < [lock] >
    -- Group total width = 24 + 3 + 20 + 3 + 24 = 74px, centered at W/2.
    -- prevArrow BOTTOM offset -25 places its center at W/2 - 25, so left edge = W/2 - 37.
    local lockBtn = MakeBtn(mainFrame, 20, 24, "")
    prevArrow:ClearAllPoints()
    prevArrow:SetPoint("BOTTOM", mainFrame, "BOTTOM", -25, 25)
    lockBtn:SetPoint("LEFT", prevArrow, "RIGHT", 3, 0)
    nextArrow:ClearAllPoints()
    nextArrow:SetPoint("LEFT", lockBtn, "RIGHT", 3, 0)

    -- Draw the lock from solid UI textures instead of using an item icon.
    -- Some current clients no longer include INV_Misc_Lock_01, leaving this
    -- button blank.  These pieces also let us show a true open-lock state.
    local lockBody = lockBtn:CreateTexture(nil, "ARTWORK")
    lockBody:SetSize(11, 8)
    lockBody:SetColorTexture(0.76, 0.79, 0.83, 1)

    local shackleLeft = lockBtn:CreateTexture(nil, "ARTWORK")
    shackleLeft:SetSize(2, 6)
    shackleLeft:SetColorTexture(0.76, 0.79, 0.83, 1)

    local shackleTop = lockBtn:CreateTexture(nil, "ARTWORK")
    shackleTop:SetSize(8, 2)
    shackleTop:SetColorTexture(0.76, 0.79, 0.83, 1)

    local shackleRight = lockBtn:CreateTexture(nil, "ARTWORK")
    shackleRight:SetSize(2, 6)
    shackleRight:SetColorTexture(0.76, 0.79, 0.83, 1)

    local keyhole = lockBtn:CreateTexture(nil, "OVERLAY")
    keyhole:SetSize(2, 3)
    keyhole:SetColorTexture(0.16, 0.18, 0.21, 1)

    local function PositionLockIcon(locked)
        lockBody:ClearAllPoints()
        lockBody:SetPoint("CENTER", lockBtn, "CENTER", 0, -3)
        keyhole:ClearAllPoints()
        keyhole:SetPoint("CENTER", lockBody, "CENTER", 0, 0)

        shackleLeft:ClearAllPoints()
        shackleTop:ClearAllPoints()
        shackleRight:ClearAllPoints()
        if locked then
            shackleRight:SetSize(2, 6)
            shackleLeft:SetPoint("BOTTOMLEFT", lockBody, "TOPLEFT", 1, 0)
            shackleTop:SetPoint("BOTTOM", lockBody, "TOP", 0, 4)
            shackleRight:SetPoint("BOTTOMRIGHT", lockBody, "TOPRIGHT", -1, 0)
        else
            -- Keep the shackle recognizable while lifting its right side away
            -- from the body for a clean unlocked-padlock silhouette.
            shackleRight:SetSize(2, 3)
            shackleLeft:SetPoint("BOTTOMLEFT", lockBody, "TOPLEFT", 1, 0)
            shackleTop:SetPoint("BOTTOM", lockBody, "TOP", 0, 4)
            shackleRight:SetPoint("TOPRIGHT", shackleTop, "TOPRIGHT", 0, 0)
        end
    end

    local function ApplyLockState()
        local t = DB and DB.theme
        PositionLockIcon(DB.windowLocked)
        if DB.windowLocked then
            -- Bright silver: active/locked.
            lockBody:SetColorTexture(0.86, 0.89, 0.93, 1)
            shackleLeft:SetColorTexture(0.86, 0.89, 0.93, 1)
            shackleTop:SetColorTexture(0.86, 0.89, 0.93, 1)
            shackleRight:SetColorTexture(0.86, 0.89, 0.93, 1)
            lockBtn.bg:SetColorTexture(
                (t and t.borderR or 0.22) * 0.55,
                (t and t.borderG or 0.31) * 0.55,
                (t and t.borderB or 0.40) * 0.55, 0.92)
            mainFrame:SetScript("OnDragStart", nil)
            grip:Hide()
        else
            -- Slightly darker silver: unlocked / free to move.
            lockBody:SetColorTexture(0.62, 0.65, 0.69, 1)
            shackleLeft:SetColorTexture(0.62, 0.65, 0.69, 1)
            shackleTop:SetColorTexture(0.62, 0.65, 0.69, 1)
            shackleRight:SetColorTexture(0.62, 0.65, 0.69, 1)
            lockBtn.bg:SetColorTexture(0.055, 0.067, 0.082, 0.92)
            mainFrame:SetScript("OnDragStart", mainFrame.StartMoving)
            grip:Show()
        end
    end

    lockBtn:SetScript("OnClick", function()
        DB.windowLocked = not DB.windowLocked
        ApplyLockState()
    end)
    lockBtn:SetScript("OnEnter", function(f)
        GameTooltip:SetOwner(f, "ANCHOR_TOP")
        GameTooltip:SetText(DB.windowLocked and "Unlock window position" or "Lock window position", 1, 1, 1)
        GameTooltip:Show()
    end)
    lockBtn:SetScript("OnLeave", function() GameTooltip:Hide() end)

    ApplyLockState()

    -- Dedicated high-layer footer overlay: drawn ABOVE the footer background
    -- (which is a separate child frame) rather than underneath it.
    local tributeLayer = CreateFrame("Frame", nil, mainFrame)
    tributeLayer:SetSize(145, 16)
    tributeLayer:SetPoint("BOTTOM", mainFrame, "BOTTOM", 0, 4)
    tributeLayer:SetFrameLevel(footer:GetFrameLevel() + 15)
    local shadyTribute = tributeLayer:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
    shadyTribute:SetAllPoints()
    shadyTribute:SetText("RIP Shady")
    shadyTribute:SetJustifyH("CENTER")
    shadyTribute:SetJustifyV("MIDDLE")
    shadyTribute:SetFont("Fonts\\MORPHEUS.TTF", 11, "OUTLINE")
    shadyTribute:SetTextColor(1, 0.87, 0.47, 1)

    -- Stable build label below the Start button. A separate high-level frame
    -- keeps it visible above footer textures without touching RIP Shady.
    local versionLayer = CreateFrame("Frame", nil, mainFrame)
    versionLayer:SetSize(135, 14)
    versionLayer:SetPoint("BOTTOMLEFT", mainFrame, "BOTTOMLEFT", 10, 5)
    versionLayer:SetFrameLevel(footer:GetFrameLevel() + 15)
    local versionText = versionLayer:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
    versionText:SetAllPoints()
    versionText:SetJustifyH("LEFT")
    versionText:SetText("v" .. VERSION)
    local versionFont, _, versionFlags = versionText:GetFont()
    if versionFont then versionText:SetFont(versionFont, 10, versionFlags) end
    TrackThemeText(versionText, 0.72)
    mainFrame.versionText = versionText

    -- Tiny bottom-right status, independent of all stat rows and chart modes.
    -- A compact tooltip provides event diagnostics without another window.
    local healthButton = CreateFrame("Button", nil, mainFrame)
    healthButton:SetSize(155, 15)
    healthButton:SetPoint("BOTTOMRIGHT", mainFrame, "BOTTOMRIGHT", -10, 4)
    healthButton:SetFrameLevel(footer:GetFrameLevel() + 15)
    local healthText = healthButton:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
    healthText:SetAllPoints()
    healthText:SetJustifyH("RIGHT")
    local healthFont, _, healthFlags = healthText:GetFont()
    if healthFont then healthText:SetFont(healthFont, 10, healthFlags) end
    TrackThemeText(healthText, .82)
    healthText:SetText("Tracking: Ready")
    healthButton.text = healthText
    mainFrame.gdsHealthButton = healthButton
    healthButton:SetScript("OnEnter", function(self)
        if GDS_Health then GDS_Health.ShowTooltip(self) end
    end)
    healthButton:SetScript("OnLeave", function() GameTooltip:Hide() end)

    local mp = DB.mainPos
    if mp and mp.p then
        mainFrame:ClearAllPoints()
        mainFrame:SetPoint(mp.p, UIParent, mp.p, mp.x or 0, mp.y or 0)
    end

    ---------------------------------------------------------------------------
    -- Independent mini Gold/GPH and mini XP/XP/h windows.
    -- Both use the same RefreshStats calculation and can remain open together.
    -- No additional event listeners, addon messages, or sessions are created.
    ---------------------------------------------------------------------------
    miniBar = CreateFrame("Frame", "GTMiniBar", UIParent,
        BackdropTemplateMixin and "BackdropTemplate")
    miniBar:SetSize(245, 28)
    miniBar:SetPoint("CENTER")
    miniBar:EnableMouse(true); miniBar:SetMovable(true)
    miniBar:SetClampedToScreen(true); miniBar:RegisterForDrag("LeftButton")
    miniBar:SetFrameStrata("DIALOG")
    miniBar:Hide()
    ApplyBackdrop(miniBar)

    local miniText = miniBar:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
    miniText:SetPoint("LEFT", 9, 0)
    miniText:SetPoint("RIGHT", -30, 0)
    miniText:SetJustifyH("LEFT")
    TrackThemeText(miniText)
    miniBar.text = miniText

    GDS_XPMiniBar = CreateFrame("Frame", "GTXPMiniBar", UIParent,
        BackdropTemplateMixin and "BackdropTemplate")
    GDS_XPMiniBar:SetSize(245, 28)
    -- Until moved separately, open it just below Gold rather than overlapping.
    GDS_XPMiniBar:SetPoint("TOPLEFT", miniBar, "BOTTOMLEFT", 0, -8)
    GDS_XPMiniBar:EnableMouse(true); GDS_XPMiniBar:SetMovable(true)
    GDS_XPMiniBar:SetClampedToScreen(true)
    GDS_XPMiniBar:RegisterForDrag("LeftButton")
    GDS_XPMiniBar:SetFrameStrata("DIALOG")
    GDS_XPMiniBar:Hide()
    ApplyBackdrop(GDS_XPMiniBar)

    local xpMiniText = GDS_XPMiniBar:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
    xpMiniText:SetPoint("LEFT", 9, 0)
    xpMiniText:SetPoint("RIGHT", -30, 0)
    xpMiniText:SetJustifyH("LEFT")
    TrackThemeText(xpMiniText)
    GDS_XPMiniBar.text = xpMiniText

    GDS_MiniViews = GDS_MiniViews or {}

    -- Keep all position bookkeeping in the character's existing DB. Each bar
    -- has an independent UIParent anchor except while explicitly snapped.
    function GDS_MiniViews.Bar(which)
        return which == "xp" and GDS_XPMiniBar or miniBar
    end

    function GDS_MiniViews.SavePosition(which)
        local frame = GDS_MiniViews.Bar(which)
        if not frame then return end
        local x, y = frame:GetCenter()
        if not x or not y then return end
        local key = which == "xp" and "miniXPPos" or "miniPos"
        DB[key] = {p="CENTER", relative="BOTTOMLEFT", x=x, y=y}
    end

    function GDS_MiniViews.FixIndependentAnchor(frame)
        if not frame then return end
        local x, y = frame:GetCenter()
        if not x or not y then return end
        frame:ClearAllPoints()
        frame:SetPoint("CENTER", UIParent, "BOTTOMLEFT", x, y)
    end

    function GDS_MiniViews.SyncWidths()
        if not miniBar or not GDS_XPMiniBar then return end
        if not (DB and DB.miniSnapped and miniBar:IsShown() and GDS_XPMiniBar:IsShown()) then
            return
        end
        local goldWidth = math.min(440, math.max(225,
            math.ceil((miniBar.text:GetStringWidth() or 0) + 45)))
        local xpWidth = math.min(440, math.max(225,
            math.ceil((GDS_XPMiniBar.text:GetStringWidth() or 0) + 45)))
        local width = math.max(goldWidth, xpWidth)
        miniBar:SetWidth(width)
        GDS_XPMiniBar:SetWidth(width)
    end

    function GDS_MiniViews.Unsnap(bottom)
        -- Capture its current on-screen position *before* removing its anchor
        -- to the upper frame; otherwise dragging may jump or pull both bars.
        if not DB.miniSnapped then return end
        GDS_MiniViews.FixIndependentAnchor(bottom)
        DB.miniSnapped = false
        DB.miniSnapTop = nil
        -- Restore individual auto-sized widths immediately, even if paused.
        miniBar:SetWidth(math.min(440, math.max(225,
            math.ceil((miniBar.text:GetStringWidth() or 0) + 45))))
        GDS_XPMiniBar:SetWidth(math.min(440, math.max(225,
            math.ceil((GDS_XPMiniBar.text:GetStringWidth() or 0) + 45))))
    end

    function GDS_MiniViews.ApplySnap()
        if not DB.miniSnapped then return end
        local top = DB.miniSnapTop == "xp" and GDS_XPMiniBar or miniBar
        local bottom = top == miniBar and GDS_XPMiniBar or miniBar
        -- The bottom remains a separate frame; only its positioning follows
        -- the top. No shared parent/visibility changes or event duplication.
        bottom:ClearAllPoints()
        bottom:SetPoint("TOPLEFT", top, "BOTTOMLEFT", 0, -3)
        GDS_MiniViews.SyncWidths()
    end

    function GDS_MiniViews.Snap()
        -- Clicking middle when just one mini is visible must do nothing.
        if not (miniBar:IsShown() and GDS_XPMiniBar:IsShown()) then return end
        if DB.miniSnapped then return end
        -- Whichever bar is physically higher stays where the user placed it.
        local goldY, xpY = miniBar:GetTop(), GDS_XPMiniBar:GetTop()
        local topIsXP = xpY and goldY and xpY > goldY
        GDS_MiniViews.SavePosition("gold")
        GDS_MiniViews.SavePosition("xp")
        DB.miniSnapTop = topIsXP and "xp" or "gold"
        DB.miniSnapped = true
        GDS_MiniViews.ApplySnap()
        RefreshStats()
    end

    function GDS_MiniViews.Show(which)
        local target = GDS_MiniViews.Bar(which)
        if not target then return end
        target:Show()
        target:Raise()
        RefreshStats()
    end
    function GDS_MiniViews.Close(which)
        -- Closing one mini must never restore the main tracker. If the pair is
        -- snapped, preserve both on-screen positions before hiding either bar
        -- so the surviving mini isn't anchored to a now-hidden companion.
        local target = GDS_MiniViews.Bar(which)
        if not target or not target:IsShown() then return end
        if DB.miniSnapped then
            local top = DB.miniSnapTop == "xp" and GDS_XPMiniBar or miniBar
            local bottom = top == miniBar and GDS_XPMiniBar or miniBar
            GDS_MiniViews.Unsnap(bottom)
            GDS_MiniViews.FixIndependentAnchor(top)
            GDS_MiniViews.SavePosition("gold")
            GDS_MiniViews.SavePosition("xp")
        else
            GDS_MiniViews.FixIndependentAnchor(target)
            GDS_MiniViews.SavePosition(which)
        end
        target:Hide()
    end
    function GDS_MiniViews.Toggle(which)
        local target = GDS_MiniViews.Bar(which)
        if not target then return end
        if target:IsShown() then
            GDS_MiniViews.Close(which)
        else
            GDS_MiniViews.Show(which)
        end
    end
    function GDS_MiniViews.Restore()
        miniBar:Hide()
        GDS_XPMiniBar:Hide()
        mainFrame:Show()
        mainFrame:Raise()
    end

    -- Existing left/right click behavior is preserved. Middle-click either L
    -- snaps both visible minis with a 3px gap; no effect with just one open.
    local miniPlus = MakeBtn(miniBar, 20, 20, "L")
    miniPlus:SetPoint("TOPRIGHT", -5, -4)
    miniBar.restoreBtn = miniPlus
    miniPlus:RegisterForClicks("LeftButtonUp", "RightButtonUp", "MiddleButtonUp")
    miniPlus:SetScript("OnClick", function(_, button)
        if IsShiftKeyDown and IsShiftKeyDown() then
            GDS_MiniViews.Close("gold")
        elseif button == "MiddleButton" then
            GDS_MiniViews.Snap()
        elseif button == "RightButton" then
            GDS_MiniViews.Toggle("xp")
        elseif button == "LeftButton" then
            GDS_MiniViews.Restore()
        end
    end)
    miniPlus:SetScript("OnEnter", function(f)
        GameTooltip:SetOwner(f, "ANCHOR_LEFT")
        GameTooltip:SetText("Gold / GPH mini\nLeft-click: Restore main window\nRight-click: Toggle XP mini\nMiddle-click: Snap both visible minis\nShift-click: Close this mini only")
        GameTooltip:Show()
    end)
    miniPlus:SetScript("OnLeave", function() GameTooltip:Hide() end)

    local xpMiniPlus = MakeBtn(GDS_XPMiniBar, 20, 20, "L")
    xpMiniPlus:SetPoint("TOPRIGHT", -5, -4)
    GDS_XPMiniBar.restoreBtn = xpMiniPlus
    xpMiniPlus:RegisterForClicks("LeftButtonUp", "RightButtonUp", "MiddleButtonUp")
    xpMiniPlus:SetScript("OnClick", function(_, button)
        if IsShiftKeyDown and IsShiftKeyDown() then
            GDS_MiniViews.Close("xp")
        elseif button == "MiddleButton" then
            GDS_MiniViews.Snap()
        elseif button == "RightButton" then
            GDS_MiniViews.Toggle("gold")
        elseif button == "LeftButton" then
            GDS_MiniViews.Restore()
        end
    end)
    xpMiniPlus:SetScript("OnEnter", function(f)
        GameTooltip:SetOwner(f, "ANCHOR_LEFT")
        GameTooltip:SetText("XP / XP per hour mini\nLeft-click: Restore main window\nRight-click: Toggle Gold mini\nMiddle-click: Snap both visible minis\nShift-click: Close this mini only")
        GameTooltip:Show()
    end)
    xpMiniPlus:SetScript("OnLeave", function() GameTooltip:Hide() end)

    -- When snapped, dragging the upper bar moves the connected pair.
    -- Grabbing the lower bar detaches it at its current screen position.
    local function StartMiniDrag(self)
        if DB.miniSnapped then
            local top = DB.miniSnapTop == "xp" and GDS_XPMiniBar or miniBar
            if self ~= top then
                GDS_MiniViews.Unsnap(self)
            end
        end
        GDS_MiniViews.FixIndependentAnchor(self)
        self:StartMoving()
    end
    local function StopMiniDrag(self, which)
        self:StopMovingOrSizing()
        GDS_MiniViews.FixIndependentAnchor(self)
        GDS_MiniViews.SavePosition(which)
    end
    miniBar:SetScript("OnDragStart", StartMiniDrag)
    miniBar:SetScript("OnDragStop", function(self) StopMiniDrag(self, "gold") end)
    GDS_XPMiniBar:SetScript("OnDragStart", StartMiniDrag)
    GDS_XPMiniBar:SetScript("OnDragStop", function(self) StopMiniDrag(self, "xp") end)

    -- Old Beta 9 positions continue to load; newer saves include the anchor's
    -- relative point so center-based dragging won't shift after /reload.
    local mbp = DB.miniPos
    if mbp and mbp.p then
        miniBar:ClearAllPoints()
        miniBar:SetPoint(mbp.p, UIParent, mbp.relative or mbp.p, mbp.x or 0, mbp.y or 0)
    end

    local xpSaved = DB.miniXPPos
    if xpSaved and xpSaved.p then
        GDS_XPMiniBar:ClearAllPoints()
        GDS_XPMiniBar:SetPoint(xpSaved.p, UIParent, xpSaved.relative or xpSaved.p,
            xpSaved.x or 0, xpSaved.y or 0)
    else
        -- Start near Gold, but independently anchored until user requests snap.
        local gx, gy = miniBar:GetCenter()
        GDS_XPMiniBar:ClearAllPoints()
        if gx and gy then
            GDS_XPMiniBar:SetPoint("CENTER", UIParent, "BOTTOMLEFT", gx, gy - 36)
        else
            GDS_XPMiniBar:SetPoint("CENTER", UIParent, "CENTER", 0, -36)
        end
    end
    -- A saved snap only influences layout; opening either mini stays separate.
    if DB.miniSnapped then
        GDS_MiniViews.ApplySnap()
    end

    BuildLootFrame()
    -- Opening the frame manually must never silently start a session.
    -- Only Start itself and the opt-in Start on Login control may do so.
    ApplyTheme()
end

function ApplyVisibility()
    if not statRows or not DB then return end
    for k, row in pairs(statRows) do
        -- fish / fishph visibility is owned entirely by RefreshStats (needs a
        -- running session + activity), so ApplyVisibility leaves them alone.
        if DB.show[k] ~= nil and k ~= "fish" and k ~= "fishph" then
            if DB.show[k] then
                if row.frame then row.frame:Show() end
                row.lbl:Show(); row.val:Show()
            else
                if row.frame then row.frame:Hide() end
                row.lbl:Hide(); row.val:Hide()
            end
        end
    end
    local showHeader = DB.show.header ~= false
    local showFooter = DB.show.footer ~= false
    for _, bg in ipairs(GT_headers) do bg:SetShown(showHeader) end
    for _, rule in ipairs(GT_headerRules) do rule:SetShown(showHeader) end
    for _, bg in ipairs(GT_footers) do bg:SetShown(showFooter) end
    for _, rule in ipairs(GT_footerRules) do rule:SetShown(showFooter) end
    -- Header/footer trim follows the same visibility switches as its panels.
    if GDS_WoWLook then GDS_WoWLook.SyncAll() end
end

-------------------------------------------------------------------------------
-- PROFILE SETTINGS
-------------------------------------------------------------------------------
local function CopyTable(src)
    local out = {}
    if type(src) ~= "table" then return out end
    for k, v in pairs(src) do
        out[k] = type(v) == "table" and CopyTable(v) or v
    end
    return out
end

local function TrimProfileName(name)
    name = tostring(name or ""):match("^%s*(.-)%s*$") or ""
    if name == "" then return nil end
    return name
end

local function GetCharacterProfileKey()
    return GDS_Characters and GDS_Characters.key
end

local function CaptureProfile()
    if not DB then return nil end
    return {
        designVersion = DB.designVersion,
        mainW   = DB.mainW,
        mainH   = DB.mainH,
        mainPos = CopyTable(DB.mainPos),
        lootW   = DB.lootW,
        lootH   = DB.lootH,
        lootPos = CopyTable(DB.lootPos),
        show    = CopyTable(DB.show),
        mainRowOrder = CopyTable(DB.mainRowOrder),
        theme   = CopyTable(DB.theme),
        skinMode = DB.skinMode,
        customTheme = CopyTable(DB.customTheme),
    }
end

EnsureProfiles = function()
    if not DB then return end
    DB.profiles = DB.profiles or {}
    DB.characterProfiles = DB.characterProfiles or {}
    local charKey = GetCharacterProfileKey()
    DB.currentProfile = TrimProfileName(charKey and DB.characterProfiles[charKey] or DB.currentProfile)
        or DEFAULT_PROFILE_NAME
    if not DB.profiles[DB.currentProfile] then
        DB.profiles[DB.currentProfile] = CaptureProfile()
    end
    if not DB.profiles[DEFAULT_PROFILE_NAME] then
        DB.profiles[DEFAULT_PROFILE_NAME] = CaptureProfile()
    end
end

GetProfileNames = function()
    if EnsureProfiles then EnsureProfiles() end
    local names = {}
    for name in pairs(DB and DB.profiles or {}) do table.insert(names, name) end
    table.sort(names)
    return names
end

local function ApplyProfileToFrames()
    if not DB then return end
    if mainFrame then
        DB.mainW = math.max(DB.mainW or 540, 540)
        local prof = DB.profiles and DB.currentProfile and DB.profiles[DB.currentProfile]
        if prof then prof.mainW = DB.mainW end
        mainFrame:SetSize(DB.mainW, DB.mainH or 380)
        mainFrame:ClearAllPoints()
        local mp = DB.mainPos
        if mp and mp.p then
            mainFrame:SetPoint(mp.p, UIParent, mp.p, mp.x or 0, mp.y or 0)
        else
            mainFrame:SetPoint("CENTER")
        end
    end
    if lootFrame then
        lootFrame:SetSize(DB.lootW or 400, DB.lootH or 420)
        lootFrame:ClearAllPoints()
        local lp = DB.lootPos
        if lp and lp.p then
            lootFrame:SetPoint(lp.p, UIParent, lp.p, lp.x or 0, lp.y or 0)
        elseif mainFrame then
            lootFrame:SetPoint("LEFT", mainFrame, "RIGHT", 10, 0)
        else
            lootFrame:SetPoint("CENTER")
        end
    end
    ApplyVisibility()
    ApplyTheme()
    RefreshStats()
    RefreshLootLog()
end

SaveProfile = function(name)
    if not DB then return false, "Addon is not ready." end
    name = TrimProfileName(name)
    if not name then return false, "Enter a profile name." end
    EnsureProfiles()
    DB.profiles[name] = CaptureProfile()
    DB.currentProfile = name
    local charKey = GetCharacterProfileKey()
    if charKey then DB.characterProfiles[charKey] = name end
    return true, "Saved profile '" .. name .. "'."
end

LoadProfile = function(name)
    if not DB then return false, "Addon is not ready." end
    name = TrimProfileName(name)
    EnsureProfiles()
    if not name then return false, "Enter a profile name." end
    local profile = DB.profiles and DB.profiles[name]
    if not profile then return false, "Profile '" .. name .. "' was not found." end

    DB.designVersion = profile.designVersion or DB.designVersion
    DB.mainW   = profile.mainW or DB.mainW
    DB.mainH   = profile.mainH or DB.mainH
    DB.mainPos = CopyTable(profile.mainPos)
    DB.lootW   = profile.lootW or DB.lootW
    DB.lootH   = profile.lootH or DB.lootH
    DB.lootPos = CopyTable(profile.lootPos)
    DB.show    = CopyTable(profile.show or DB.show)
    DB.mainRowOrder = CopyTable(profile.mainRowOrder or DB.mainRowOrder)
    DB.show.header = true
    DB.show.footer = true
    DB.theme   = CopyTable(profile.theme or DB.theme)
    DB.skinMode = profile.skinMode or (profile.theme and "custom") or DB.skinMode or "default"
    DB.customTheme = CopyTable(profile.customTheme or profile.theme or DB.customTheme or DB.theme)
    if DB.skinMode == "default" then DB.theme = CopyTheme(DEFAULT_THEME)
    elseif DB.skinMode == "wow" then DB.theme = CopyTheme(WOW_THEME)
    elseif DB.skinMode == "nightfall" then DB.theme = CopyTheme(GDS_NIGHTFALL_THEME)
    elseif DB.skinMode == "wowlook" then DB.theme = CopyTheme(GDS_WOWLOOK_THEME)
    elseif DB.skinMode == "classicstone" then DB.theme = CopyTheme(GDS_CLASSIC_STONE_THEME)
    elseif DB.skinMode == "classicleather" then DB.theme = CopyTheme(GDS_CLASSIC_LEATHER_THEME)
    elseif DB.skinMode == "tooltipframe" then DB.theme = CopyTheme(GDS_TOOLTIP_FRAME_THEME)
    elseif DB.skinMode == "authenticvanilla" then DB.theme = CopyTheme(GDS_AUTHENTIC_VANILLA_THEME) end
    DB.currentProfile = name
    local charKey = GetCharacterProfileKey()
    if charKey then DB.characterProfiles[charKey] = name end
    ApplyProfileToFrames()
    return true, "Loaded profile '" .. name .. "'."
end

DeleteProfile = function(name)
    if not DB then return false, "Addon is not ready." end
    name = TrimProfileName(name)
    EnsureProfiles()
    if not name then return false, "Enter a profile name." end
    if name == DEFAULT_PROFILE_NAME then return false, "The Default profile cannot be deleted." end
    if not DB.profiles[name] then return false, "Profile '" .. name .. "' was not found." end
    DB.profiles[name] = nil
    if DB.currentProfile == name then DB.currentProfile = DEFAULT_PROFILE_NAME end
    for charKey, profileName in pairs(DB.characterProfiles or {}) do
        if profileName == name then DB.characterProfiles[charKey] = DEFAULT_PROFILE_NAME end
    end
    return true, "Deleted profile '" .. name .. "'."
end

PrintProfiles = function()
    if not DB then return end
    EnsureProfiles()
    local names = {}
    for name in pairs(DB.profiles or {}) do table.insert(names, name) end
    table.sort(names)
    DEFAULT_CHAT_FRAME:AddMessage("|cFFD8DDE6Grind Dont Stop profiles:|r " .. table.concat(names, ", "))
    DEFAULT_CHAT_FRAME:AddMessage("|cFFAAAAAACurrent:|r " .. tostring(DB.currentProfile or DEFAULT_PROFILE_NAME))
end

-------------------------------------------------------------------------------
-- PER-CHARACTER STORAGE (account-wide SavedVariables, keyed by Name + Realm)
-- Legacy records are COPIED once to the character who installs this upgrade.
-- The old account-level tables remain untouched as a recovery backup.
-------------------------------------------------------------------------------
GDS_Characters = GDS_Characters or {}
-- Match the two profiles confirmed by the supplied save and its backup.
function GDS_Characters.VerifiedSplit(root, key)
    if key ~= "Crillz - CAMWOW US2 Realm 8 PvP" or root.characterHistoryOwner ~= key then return end
    local profiles = root.characters
    local split = profiles and profiles["Crillz - "]
    if not split or not profiles[key] then return end
    for _, row in ipairs(split.loginHistory or {}) do
        if row.started == 1795214275 or row.started == 1795237286 then return split end
    end
end

-- Realm display names and UnitFullName's realm can differ in spacing.
function GDS_Characters.ResolveKey()
    local root = GrindTrackerDB
    local name = UnitName("player")
    if not name or name == "" or name == UNKNOWNOBJECT then return end
    local guid = UnitGUID and UnitGUID("player")
    local prefix = name .. " - "
    local cached = guid and root.characterKeysByGUID and root.characterKeysByGUID[guid]
    local backup = guid and root.characterBackups and root.characterBackups[guid]
    if type(cached) == "string" and cached:sub(1,#prefix) == prefix
        and ((root.characters and type(root.characters[cached]) == "table")
            or (backup and backup.key == cached)) then
        return cached
    end
    if backup and type(backup.key) == "string" and backup.key:sub(1,#prefix) == prefix then
        return backup.key
    end
    local realm = GetRealmName and GetRealmName()
    if not realm or not realm:find("%S") then
        local unitRealm
        if UnitFullName then unitRealm = select(2, UnitFullName("player")) end
        realm = unitRealm
    end
    if not realm or not realm:find("%S") then
        realm = GetNormalizedRealmName and GetNormalizedRealmName()
    end
    if not realm or not realm:find("%S") then
        -- On Forever every realm API can stay blank for the entire login.
        local owner = root.characterHistoryOwner
        if name ~= "Crillz" or not GDS_Characters.VerifiedSplit(root, owner) then return end
        for other in pairs(root.characters) do
            if other:sub(1,#prefix) == prefix and other ~= prefix and other ~= owner then return end
        end
        for knownGUID, profile in pairs(root.characterKeysByGUID or {}) do
            if profile == owner and knownGUID ~= guid then return end
        end
        realm = owner:sub(#prefix+1)
    end
    local key = prefix .. realm
    if not (root.characters and root.characters[key]) then
        local normalized = realm:gsub("%s+", ""):lower()
        for existing in pairs(root.characters or {}) do
            if existing:sub(1,#prefix) == prefix and
                existing:sub(#prefix+1):gsub("%s+", ""):lower() == normalized then
                key = existing
                break
            end
        end
    end
    if guid then
        for otherGUID, bound in pairs(root.characterKeysByGUID or {}) do
            if bound == key and otherGUID ~= guid then
                return key .. " (" .. guid .. ")"
            end
        end
    end
    return key
end

-- The two supplied saves establish ownership of these otherwise unqualified
-- records. Never infer ownership of a blank-realm profile from its name alone.
function GDS_Characters.RecoverSplit(root, key, canonical)
    if not canonical or canonical.emptyRealmRecovered then return canonical end
    local split = GDS_Characters.VerifiedSplit(root, key)
    if not split then return canonical end
    local function lastLogin(profile)
        local latest = 0
        for _, row in ipairs(profile.loginHistory or {}) do
            latest = math.max(latest, row.ended or row.started or 0)
        end
        return latest
    end
    local newer, older = split, canonical
    if lastLogin(canonical) > lastLogin(split) then newer, older = canonical, split end
    local merged = CopyTable(newer)
    for field, value in pairs(older) do
        if merged[field] == nil and field ~= "activeSession" and field ~= "activePartySession"
            and field ~= "dungeonUndo" then
            merged[field] = type(value) == "table" and CopyTable(value) or value
        end
    end
    for _, field in ipairs({"priceOverrides", "profiles", "dungeonHistoryExpanded"}) do
        for id, value in pairs(older[field] or {}) do
            if merged[field][id] == nil then
                merged[field][id] = type(value) == "table" and CopyTable(value) or value
            end
        end
    end
    -- These two buckets were initialized with independent history and counters.
    for _, field in ipairs({"sessions", "dungeonRuns", "loginHistory"}) do
        local rows = CopyTable(newer[field] or {})
        for _, row in ipairs(older[field] or {}) do
            local index = #rows + 1
            local stamp = row.date or row.started
            while index > 1 and stamp and (rows[index-1].date or rows[index-1].started or stamp) < stamp do
                index = index - 1
            end
            table.insert(rows, index, CopyTable(row))
        end
        merged[field] = rows
    end
    for _, field in ipairs({"questTotals", "pvpTotals"}) do
        merged[field] = CopyTable(newer[field] or {})
        for stat, value in pairs(older[field] or {}) do
            if type(value) == "number" then
                merged[field][stat] = (merged[field][stat] or 0) + value
            end
        end
    end
    merged.emptyRealmRecovered = true
    root.characters[key] = merged
    return merged
end

function GDS_Characters.Activate(key)
    local root = GrindTrackerDB
    root.characters = type(root.characters)=="table" and root.characters or {}
    GDS_Characters.key = key
    -- Bind the profile actually opened, including a choice made by the restore addon.
    local guid = UnitGUID and UnitGUID("player")
    if guid then
        root.characterKeysByGUID = root.characterKeysByGUID or {}
        root.characterKeysByGUID[guid] = key
        local backup = root.characterBackups and root.characterBackups[guid]
        if backup and backup.key == key and type(backup.profile) == "table" then
            local live = root.characters[key]
            if type(live) ~= "table" then
                root.characters[key] = CopyTable(backup.profile)
            else
                for _, field in ipairs({"sessions", "dungeonRuns", "loginHistory"}) do
                    if type(live[field]) ~= "table" and type(backup.profile[field]) == "table" then
                        live[field] = CopyTable(backup.profile[field])
                    end
                end
            end
        end
    end
    local data = GDS_Characters.RecoverSplit(root, key, root.characters[key])
    if type(data) ~= "table" then
        data = {}
        -- Carry over appearance and options, but NEVER another character's runs.
        local privateKeys = {
            experimentalAnalytics=true, characters=true, characterBackups=true, characterKeysByGUID=true, characterHistoryOwner=true, sessions=true, loginHistory=true,
            dungeonRuns=true, activeSession=true, activePartySession=true,
            questTotals=true, pvpTotals=true, partyKBLifetime=true,
            partyKBSerial=true, partyKBStamp=true,
            drownedCityHistoryCorrectedV1=true, scarletHistoryCorrectedV1=true,
            dungeonHistoryExpanded=true, dungeonUndo=true,
        }
        for field, value in pairs(root) do
            if not privateKeys[field] then
                data[field] = type(value)=="table" and CopyTable(value) or value
            end
        end
        if not root.characterHistoryOwner then
            -- First upgrade: preserve all existing history for THIS character.
            data.loginHistory=CopyTable(root.loginHistory or {})
            data.sessions=CopyTable(root.sessions or {})
            data.dungeonRuns=CopyTable(root.dungeonRuns or {})
            data.activeSession=type(root.activeSession)=="table" and CopyTable(root.activeSession) or nil
            data.activePartySession=type(root.activePartySession)=="table" and CopyTable(root.activePartySession) or nil
            data.questTotals=CopyTable(root.questTotals or {xp=0,gold=0})
            data.pvpTotals=CopyTable(root.pvpTotals or {hk=0,kb=0})
            data.partyKBLifetime=CopyTable(root.partyKBLifetime or {})
            data.partyKBSerial=root.partyKBSerial or 0
            data.partyKBStamp=root.partyKBStamp
            data.drownedCityHistoryCorrectedV1=root.drownedCityHistoryCorrectedV1
            data.dungeonHistoryExpanded=CopyTable(root.dungeonHistoryExpanded or {})
            data.dungeonUndo=type(root.dungeonUndo)=="table" and CopyTable(root.dungeonUndo) or nil
            root.characterHistoryOwner=key
        else
            data.sessions={}
            data.dungeonRuns={}
            data.questTotals={xp=0,gold=0}
            data.pvpTotals={hk=0,kb=0}
            data.partyKBLifetime={}
            data.partyKBSerial=0
            data.dungeonHistoryExpanded={}
        end
        root.characters[key]=data
    end
    -- SavedVariables now contains independent profile-free settings and history
    -- for each character; a relog or /reload reloads this character's own table.
    return data
end

-------------------------------------------------------------------------------
function GDS_Characters.Checkpoint(profile)
    local guid = UnitGUID and UnitGUID("player")
    local key = GDS_Characters.key
    if not guid or not key or GrindTrackerDB.characters[key] ~= profile then return end
    GrindTrackerDB.characterBackups = GrindTrackerDB.characterBackups or {}
    GrindTrackerDB.characterBackups[guid] = {key=key, profile=CopyTable(profile)}
end

-- Optional repair accounting and remote durability status.
-- No new Lua chunk locals: the addon is near WoW's 200-local limit.
-------------------------------------------------------------------------------
GDS_Repairs = GDS_Repairs or {}
GDS_Repairs.merchant = nil

function GDS_Repairs.ReadDurability()
    if type(GetInventoryItemDurability) ~= "function" then return nil end
    local current, maximum, lowest, broken = 0, 0, 1, false
    for slot=1,19 do
        local ok, cur, max = pcall(GetInventoryItemDurability, slot)
        if ok and type(cur)=="number" and type(max)=="number" and max>0 then
            -- Midnight/Forever may mark some values secret during restricted UI.
            if not (issecretvalue and (issecretvalue(cur) or issecretvalue(max))) then
                current=current+math.max(0,cur)
                maximum=maximum+max
                lowest=math.min(lowest, cur/max)
                if cur<=0 then broken=true end
            end
        end
    end
    if maximum<=0 then return nil end
    return math.floor(current/maximum*100+.5), math.floor(lowest*100+.5), broken
end

-- Calculation runs ONLY while hovering the optional main-row indicator.
-- A tooltip repairCost is preferable because it is supplied by the client;
-- otherwise use an intentionally approximate equipment-level/quality model.
function GDS_Repairs.EstimateRepair()
    if type(GetInventoryItemDurability)~="function" then return nil,"unavailable" end
    local usable, damaged = 0, 0
    local summed = 0
    local exactSlots = 0
    local estimatedSlots = 0
    local tooltip = GDS_Repairs.scanTooltip
    for slot=1,19 do
        local ok,cur,max = pcall(GetInventoryItemDurability, slot)
        if ok and type(cur)=="number" and type(max)=="number"
            and not (issecretvalue and (issecretvalue(cur) or issecretvalue(max)))
            and max>0 then
            usable=usable+1
            if cur<max then
            damaged=damaged+1
            local gotCost=nil
            if C_TooltipInfo and type(C_TooltipInfo.GetInventoryItem)=="function" then
                local success, info=pcall(C_TooltipInfo.GetInventoryItem,"player",slot)
                if success and type(info)=="table" and type(info.repairCost)=="number"
                    and not (issecretvalue and issecretvalue(info.repairCost))
                    and info.repairCost>0 then
                    gotCost=info.repairCost
                end
            end
            if not gotCost and type(CreateFrame)=="function" then
                if not tooltip then
                    local success, frame=pcall(CreateFrame,"GameTooltip", "GDS_RepairScanTooltip",UIParent,"GameTooltipTemplate")
                    if success then tooltip=frame; GDS_Repairs.scanTooltip=frame end
                end
                if tooltip and type(tooltip.SetInventoryItem)=="function" then
                    local success,_,__,cost=pcall(tooltip.SetInventoryItem, tooltip, "player",slot)
                    if success and type(cost)=="number" and cost>0
                        and not (issecretvalue and issecretvalue(cost)) then gotCost=cost end
                    if type(tooltip.ClearLines)=="function" then pcall(tooltip.ClearLines,tooltip) end
                end
            end
            if gotCost then
                exactSlots=exactSlots+1
                summed=summed+gotCost
            else
                local link
                if type(GetInventoryItemLink)=="function" then
                    local success, value=pcall(GetInventoryItemLink,"player",slot)
                    if success and type(value)=="string" and not (issecretvalue and issecretvalue(value)) then link=value end
                end
                local ilvl,quality,equipLoc
                if link then
                    local info=GDS_ItemCompat and GDS_ItemCompat.GetInfo or GetItemInfo
                    if type(info)=="function" then
                        local success,_,__,q,level,____,_____,______,_______,loc=pcall(info,link)
                        if success and type(level)=="number" and type(q)=="number"
                            and not (issecretvalue and (issecretvalue(level) or issecretvalue(q))) then
                            ilvl,quality,equipLoc=level,q,loc
                        end
                    end
                end
                if ilvl then
                    -- Approximate copper per missing durability point; intentionally
                    -- conservative, not a reimplementation of Blizzard repair DBC.
                    local qualityScale=({[0]=.6,[1]=.8,[2]=1,[3]=1.25,[4]=2.5,[5]=3})[quality] or 1
                    local slotScale=(slot==16 or slot==17 or slot==18) and .75 or 1
                    if equipLoc=="INVTYPE_2HWEAPON" then slotScale=1.45 end
                    local perPoint=math.max(2,(ilvl-25)*1.65+3)
                    summed=summed+math.floor((max-cur)*perPoint*qualityScale*slotScale+.5)
                    estimatedSlots=estimatedSlots+1
                end
            end
            end
        end
    end
    if usable==0 then return nil,"unavailable" end
    if damaged==0 then return 0,"no damage" end
    if exactSlots+estimatedSlots<damaged then
        -- Missing item metadata must not be presented as a complete price.
        return nil,"incomplete"
    end
    return math.floor(summed+.5),estimatedSlots==0 and "item tooltip" or "approximate"
end

function GDS_Repairs.RefreshLabel()
    if not settingsFrame or not settingsFrame.repairStatus then return end
    if not DB then return end
    local spent = (S and S.repairCosts) or 0
    settingsFrame.repairStatus:SetText(DB.repairTracking and
        ("Repairs paid: " .. CoinShort(spent) .. " / session") or "Repair logging: OFF")
end

function GDS_Repairs.GetMerchantCost()
    if type(GetRepairAllCost)~="function" then return nil end
    local ok, cost, canRepair = pcall(GetRepairAllCost)
    if not ok or not canRepair or type(cost)~="number" then return nil end
    if issecretvalue and issecretvalue(cost) then return nil end
    return math.max(0, math.floor(cost))
end

function GDS_Repairs.OnToggle()
    -- Avoid claiming part of a merchant transaction when tracking was toggled
    -- halfway through the payment. Re-snapshot on the next merchant opening.
    GDS_Repairs.merchant=nil
    if DB and DB.repairTracking and merchantOpen then GDS_Repairs.OnMerchantShow() end
end

function GDS_Repairs.OnMerchantShow()
    GDS_Repairs.merchant=nil
    if not DB or DB.repairTracking~=true then return end
    local cost=GDS_Repairs.GetMerchantCost()
    if cost==nil then return end
    GDS_Repairs.merchant={cost=cost, money=GetMoney(), started=GetTime(), generation=0}
end

function GDS_Repairs.RecordCost(copper)
    if not DB or DB.repairTracking~=true then return end
    copper=math.max(0, math.floor(tonumber(copper) or 0))
    if copper==0 then return end
    DB.repairsLifetime=(tonumber(DB.repairsLifetime) or 0)+copper
    if S and S.running then S.repairCosts=(S.repairCosts or 0)+copper end
    local a=GDS_PartySession and GDS_PartySession.active
    if a and a.running then a.repairs=(a.repairs or 0)+copper end
    if GDS_LoginLog.ExperimentalRepair then GDS_LoginLog.ExperimentalRepair(copper) end
    GDS_Repairs.RefreshLabel()
    if RefreshStats then RefreshStats() end -- update Repairs Paid immediately
end

function GDS_Repairs.CheckMerchant(force)
    local state=GDS_Repairs.merchant
    if not state then return end
    local cost=GDS_Repairs.GetMerchantCost()
    if cost==nil then return end
    local money=GetMoney()
    local costDrop=math.max(0,(state.cost or 0)-cost)
    local moneyDrop=math.max(0,(state.money or 0)-money)
    if costDrop>0 and moneyDrop>0 then
        -- Both the NPC repair bill and cash balance actually decreased.
        -- Cap attribution to the smaller verified change, excluding vendor
        -- purchases and guild-funded repairs from invented repair expense.
        GDS_Repairs.RecordCost(math.min(costDrop,moneyDrop))
        state.cost,state.money,state.started=cost,money,GetTime()
        return
    end
    if force or (GetTime()-(state.started or 0))>2 then
        -- Vendor sales, purchases, guild repairs and equipment swaps reset the
        -- baseline without generating fictional repair expenses.
        state.cost,state.money,state.started=cost,money,GetTime()
    elseif costDrop>0 or moneyDrop>0 then
        GDS_Repairs.QueueCheck(0.7)
    elseif cost>state.cost or money>state.money then
        state.cost,state.money,state.started=cost,money,GetTime()
    end
end

function GDS_Repairs.QueueCheck(delay)
    local state=GDS_Repairs.merchant
    if not state then return end
    state.generation=(state.generation or 0)+1
    local generation=state.generation
    C_Timer.After(delay or .25,function()
        if GDS_Repairs.merchant~=state or state.generation~=generation then return end
        GDS_Repairs.CheckMerchant(false)
    end)
end

function GDS_Repairs.OnMerchantClosed()
    GDS_Repairs.CheckMerchant(true)
    GDS_Repairs.merchant=nil
    GDS_Repairs.RefreshLabel()
end

-------------------------------------------------------------------------------
-- Optional Tracking Status + Live Dungeon (presentation/diagnostics only).
-- Keep these in the global GDS_ namespace to avoid Lua's chunk-local limit.
-- No new event registrations, money accounting, or dungeon write paths.
-------------------------------------------------------------------------------
GDS_Health = GDS_Health or {}
GDS_Health.monitored = {"PLAYER_XP_UPDATE", "CHAT_MSG_LOOT", "CHAT_MSG_MONEY", "PLAYER_MONEY"}
GDS_Health.names = {
    PLAYER_XP_UPDATE="XP events", CHAT_MSG_LOOT="Loot events",
    CHAT_MSG_MONEY="Coin messages", PLAYER_MONEY="Wallet changes",
}

function GDS_Health.Note(ev, handled)
    if not S or not S.running or S.paused then return end
    if ev ~= "PLAYER_XP_UPDATE" and ev ~= "CHAT_MSG_LOOT"
        and ev ~= "CHAT_MSG_MONEY" and ev ~= "PLAYER_MONEY" then return end
    S.healthEvents = type(S.healthEvents) == "table" and S.healthEvents or {}
    local record = S.healthEvents[ev]
    if type(record) ~= "table" then
        record = {seen=0, handled=0}
        S.healthEvents[ev] = record
    end
    if handled then
        record.handled = (record.handled or 0) + 1
    else
        record.seen = (record.seen or 0) + 1
        record.lastAt = (GetServerTime and GetServerTime()) or time()
    end
end

function GDS_Health.Check()
    if not addonReady then return false, "Waiting for startup" end
    if not GDS_Health.bus then return false, "Event dispatcher missing" end
    for _, ev in ipairs(GDS_Health.monitored) do
        if not GDS_Health.bus:IsEventRegistered(ev) then
            return false, ev .. " listener missing"
        end
    end
    -- Each raw event should complete its handler. An incomplete event that
    -- persists for 3s signals an actual handler interruption, not an idle farm.
    if S and S.running and type(S.healthEvents)=="table" then
        local now = (GetServerTime and GetServerTime()) or time()
        for _, ev in ipairs(GDS_Health.monitored) do
            local rec = S.healthEvents[ev]
            if rec and (rec.seen or 0) > (rec.handled or 0)
                and now-(rec.lastAt or now) >= 3 then
                return false, (GDS_Health.names[ev] or ev) .. " handler incomplete"
            end
        end
    end
    return true
end

function GDS_Health.Refresh()
    if not mainFrame or not mainFrame.gdsHealthButton or not DB then return end
    local button = mainFrame.gdsHealthButton
    button:SetShown(DB.showTrackingHealth ~= false)
    if not button:IsShown() then return end
    local ok = GDS_Health.Check()
    local status = "Healthy"
    if not ok then status = "Check"
    elseif not S or not S.running then status = "Idle"
    elseif S.paused then status = "Paused" end
    button.text:SetText("Tracking: " .. status)
    if not ok then button.text:SetTextColor(1, .55, .35)
    elseif status == "Healthy" then button.text:SetTextColor(.60, .90, .65)
    else SetThemeTextColor(button.text, .82) end
end

function GDS_Health.ShowTooltip(owner)
    GameTooltip:SetOwner(owner, "ANCHOR_TOP")
    GameTooltip:SetText("Grind Don't Stop — Tracking Status")
    local ok, cause = GDS_Health.Check()
    GameTooltip:AddLine(ok and "Event listeners: registered" or ("Check: " .. (cause or "unknown")),
        ok and .55 or 1, ok and .9 or .5, ok and .65 or .4, true)
    GameTooltip:AddLine("Events handled / received this session:", .80,.85,.94)
    local seenSomething = false
    for _, ev in ipairs(GDS_Health.monitored) do
        local rec = S and S.healthEvents and S.healthEvents[ev]
        local seen = rec and (rec.seen or 0) or 0
        local done = rec and (rec.handled or 0) or 0
        if seen > 0 then seenSomething = true end
        local last = rec and rec.lastAt and date("%H:%M:%S", rec.lastAt) or "—"
        GameTooltip:AddLine((GDS_Health.names[ev] or ev) .. ": " .. done .. "/" .. seen .. "  (last " .. last .. ")", 1, 1, 1)
    end
    if not seenSomething then
        GameTooltip:AddLine("No matching events yet; a quiet period is normal.", .7,.75,.8,true)
    end
    GameTooltip:AddLine("Credited this session: " .. CoinShort(S and S.coinGold or 0)
        .. " coin + " .. CoinShort(S and S.itemGold or 0) .. " items", .9,.8,.6)
    GameTooltip:AddLine("Healthy checks event delivery and handler completion, not whether every drop was valued correctly.", .65,.72,.8,true)
    GameTooltip:Show()
end

GDS_LiveDungeon = GDS_LiveDungeon or {}

function GDS_LiveDungeon.Build()
    if GDS_LiveDungeon.frame or not DB then return end
    local f = CreateFrame("Frame", "GDSLiveDungeonMini", UIParent,
        BackdropTemplateMixin and "BackdropTemplate" or nil)
    f:SetSize(290, 30)
    f:SetFrameStrata("DIALOG")
    f:SetMovable(true)
    f:SetClampedToScreen(true)
    f:EnableMouse(true)
    ApplyBackdrop(f)
    local saved = DB.liveDungeonPos
    if type(saved)=="table" and type(saved.x)=="number" and type(saved.y)=="number" then
        f:SetPoint("CENTER", UIParent, "BOTTOMLEFT", saved.x, saved.y)
    else
        f:SetPoint("CENTER", UIParent, "CENTER", 0, 130)
    end
    local header = CreateFrame("Button", nil, f)
    header:SetPoint("TOPLEFT", f, "TOPLEFT", 1, -1)
    header:SetPoint("TOPRIGHT", f, "TOPRIGHT", -1, -1)
    header:SetHeight(27)
    header:RegisterForClicks("LeftButtonUp","RightButtonUp")
    header:RegisterForDrag("LeftButton")
    local label = header:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
    label:SetPoint("LEFT", header, "LEFT", 8, 0)
    label:SetPoint("RIGHT", header, "RIGHT", -21, 0)
    label:SetJustifyH("LEFT")
    TrackThemeText(label, .97)
    local triangle = header:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
    triangle:SetPoint("RIGHT", -7, 0)
    TrackThemeText(triangle, .9)
    header:SetScript("OnClick", function(_, button)
        if button == "RightButton" then
            local run = GDS_LiveDungeon.ActiveRun()
            if run then GDS_LoginLog.OpenItems(run) end
            return
        end
        DB.liveDungeonExpanded = not (DB.liveDungeonExpanded == true)
        GDS_LiveDungeon.Refresh()
    end)
    header:SetScript("OnDragStart", function()
        f:StartMoving()
    end)
    header:SetScript("OnDragStop", function()
        f:StopMovingOrSizing()
        local x,y=f:GetCenter()
        if x and y then DB.liveDungeonPos={x=x,y=y} end
    end)
    header:SetScript("OnEnter", function(self)
        GameTooltip:SetOwner(self, "ANCHOR_RIGHT")
        GameTooltip:SetText("Live Dungeon Run")
        GameTooltip:AddLine("Left-click to expand. Right-click for loot. Drag to move.", .8,.8,.8)
        GameTooltip:AddLine("Best saved run = most coin + item value in this dungeon/wing.", .72,.78,.84,true)
        GameTooltip:AddLine("Saved Dungeon History is unchanged.", .72,.78,.84,true)
        GameTooltip:Show()
    end)
    header:SetScript("OnLeave", function() GameTooltip:Hide() end)

    local detail1 = f:CreateFontString(nil,"OVERLAY","GameFontHighlightSmall")
    detail1:SetPoint("TOPLEFT", 8, -33)
    detail1:SetPoint("RIGHT", -8, 0)
    detail1:SetJustifyH("LEFT")
    TrackThemeText(detail1, .95)
    local detail2 = f:CreateFontString(nil,"OVERLAY","GameFontHighlightSmall")
    detail2:SetPoint("TOPLEFT", 8, -51)
    detail2:SetPoint("RIGHT", -8, 0)
    detail2:SetJustifyH("LEFT")
    TrackThemeText(detail2, .95)
    local detail3 = f:CreateFontString(nil,"OVERLAY","GameFontHighlightSmall")
    detail3:SetPoint("TOPLEFT", 8, -69)
    detail3:SetPoint("RIGHT", -8, 0)
    detail3:SetJustifyH("LEFT")
    TrackThemeText(detail3, .95)
    GDS_LiveDungeon.frame=f
    GDS_LiveDungeon.title=label
    GDS_LiveDungeon.arrow=triangle
    GDS_LiveDungeon.detail1=detail1
    GDS_LiveDungeon.detail2=detail2
    GDS_LiveDungeon.detail3=detail3
    f:Hide()
end

function GDS_LiveDungeon.ActiveRun()
    if S and S.running and type(S.dungeonCurrent)=="table" then
        return S.dungeonCurrent, S.timer or 0, S.coinGold or 0, S.itemGold or 0, "personal"
    end
    local a=GDS_PartySession and GDS_PartySession.active
    if a and a.running and type(a.dungeonCurrent)=="table" then
        return a.dungeonCurrent, a.timer or 0, a.coin or 0, a.items or 0, "party"
    end
    return nil
end

function GDS_LiveDungeon.RunNumber(name, day)
    if not DB or type(DB.dungeonRuns)~="table" then return 1 end
    day = day or date("%Y-%m-%d")
    local count=0
    for _, row in ipairs(DB.dungeonRuns) do
        if row.dungeon==name and type(row.date)=="string"
            and row.date:sub(1,10)==day then count=count+1 end
    end
    return count+1
end

-- Uses saved history only, not the active run, so a new record appears after
-- the run is saved. Wing names remain separate: Cathedral never competes with
-- Armory, Library, Graveyard, or unidentified Scarlet runs.
function GDS_LiveDungeon.BestSavedRun(dungeonName)
    if not DB or type(DB.dungeonRuns)~="table" or type(dungeonName)~="string" then
        return nil
    end
    local bestValue, bestDuration
    for _, record in ipairs(DB.dungeonRuns) do
        if type(record)=="table" and record.dungeon==dungeonName
            and not record.gdsExcludeRunCount then
            local total=math.max(0,tonumber(record.coin) or 0)
                +math.max(0,tonumber(record.items) or 0)
            local duration=math.max(0,tonumber(record.duration) or 0)
            -- Prefer higher total value, then a quicker run on a tie.
            if bestValue==nil or total>bestValue
                or (total==bestValue and duration<(bestDuration or math.huge)) then
                bestValue, bestDuration=total,duration
            end
        end
    end
    return bestValue, bestDuration
end

function GDS_LiveDungeon.Refresh()
    if not DB then return end
    local f=GDS_LiveDungeon.frame
    if not f then return end
    local run, t, coin, items, mode = GDS_LiveDungeon.ActiveRun()
    if not DB.showLiveDungeon or not run then
        f:Hide()
        return
    end
    local expanded=DB.liveDungeonExpanded == true
    f:SetHeight(expanded and 97 or 30)
    GDS_LiveDungeon.detail1:SetShown(expanded)
    GDS_LiveDungeon.detail2:SetShown(expanded)
    GDS_LiveDungeon.detail3:SetShown(expanded)
    GDS_LiveDungeon.arrow:SetText(expanded and "[-]" or "[+]")
    local displayName=GDS_Dungeon.SavedName(run.name, run.wing)
    local day = date("%Y-%m-%d")
    local summary = GDS_LiveDungeon.historySummary
    if not summary or summary.history ~= DB.dungeonRuns or summary.name ~= displayName then
        summary = {history=DB.dungeonRuns, name=displayName}
        GDS_LiveDungeon.historySummary = summary
    end
    if summary.day ~= day then
        summary.runNumber = GDS_LiveDungeon.RunNumber(displayName, day)
        summary.day = day
    end
    local runNumber = summary.runNumber
    GDS_LiveDungeon.title:SetText(tostring(GDS_Dungeon.ShortName(displayName) or "Dungeon") .. "  —  Run " .. runNumber)
    local elapsed=math.max(0, (t or 0) - (run.startTime or 0))
    local earnedItems = mode == "personal" and run.dungeonLootID
        and math.max(0, tonumber(run.dungeonItemValue) or 0)
        or math.max(0, (items or 0) - (run.startItems or 0))
    local earned=math.max(0, (coin or 0) - (run.startCoin or 0)) + earnedItems
    local gph=elapsed>0 and math.floor(earned*3600/elapsed) or 0
    GDS_LiveDungeon.detail1:SetText("Time: "..FormatTime(elapsed).."   Total: "..CoinShort(earned))
    GDS_LiveDungeon.detail2:SetText("GPH: "..CoinShort(gph)
        .."   "..(mode=="party" and "Party-only" or (run.deathRecovery and "Corpse run" or "Personal")))
    if expanded then
        if not summary.bestChecked then
            summary.bestValue, summary.bestDuration = GDS_LiveDungeon.BestSavedRun(displayName)
            summary.bestChecked = true
        end
        local bestValue, bestDuration = summary.bestValue, summary.bestDuration
        if bestValue~=nil then
            local bestGPH=bestDuration and bestDuration>0
                and math.floor(bestValue*3600/bestDuration) or 0
            GDS_LiveDungeon.detail3:SetText("Best saved: "..CoinShort(bestValue)
                .."   GPH: "..CoinShort(bestGPH))
        else
            GDS_LiveDungeon.detail3:SetText("Best saved: No completed runs")
        end
    end
    if not f:IsShown() then f:Show() end
end

-------------------------------------------------------------------------------
-- EVENT HANDLER
-------------------------------------------------------------------------------
local bus = CreateFrame("Frame")
GDS_Health.bus = bus
bus:RegisterEvent("PLAYER_LEAVING_WORLD")
bus:RegisterEvent("PLAYER_LOGIN")
bus:RegisterEvent("CHAT_MSG_ADDON")
bus:RegisterEvent("GROUP_ROSTER_UPDATE")
bus:RegisterEvent("PLAYER_LOGOUT")
bus:RegisterEvent("PLAYER_ENTERING_WORLD")
bus:RegisterEvent("ZONE_CHANGED_NEW_AREA")
bus:RegisterEvent("ZONE_CHANGED")
bus:RegisterEvent("ZONE_CHANGED_INDOORS")
bus:RegisterEvent("PLAYER_DEAD")
bus:RegisterEvent("PLAYER_ALIVE")
bus:RegisterEvent("PLAYER_UNGHOST")
bus:RegisterEvent("CHAT_MSG_SYSTEM")
bus:RegisterEvent("BAG_OPEN")
bus:RegisterEvent("PLAYER_XP_UPDATE")
bus:RegisterEvent("PLAYER_LEVEL_UP")
bus:RegisterEvent("PLAYER_MONEY")
bus:RegisterEvent("QUEST_TURNED_IN")
bus:RegisterEvent("PLAYER_PVP_KILLS_CHANGED")
bus:RegisterEvent("PARTY_KILL")
bus:RegisterEvent("MERCHANT_SHOW")
bus:RegisterEvent("MERCHANT_CLOSED")
bus:RegisterEvent("MERCHANT_UPDATE")
bus:RegisterEvent("UPDATE_INVENTORY_DURABILITY")
bus:RegisterEvent("MAIL_SHOW")
bus:RegisterEvent("MAIL_CLOSED")
bus:RegisterEvent("TRADE_SHOW")
bus:RegisterEvent("TRADE_CLOSED")
bus:RegisterEvent("CHAT_MSG_LOOT")
bus:RegisterEvent("GET_ITEM_INFO_RECEIVED")
bus:RegisterEvent("CHAT_MSG_MONEY")
bus:RegisterEvent("TRADE_SKILL_SHOW")
bus:RegisterEvent("TRADE_SKILL_CLOSE")
bus:RegisterEvent("UNIT_SPELLCAST_START")
bus:RegisterEvent("UNIT_SPELLCAST_SUCCEEDED")
bus:RegisterEvent("UNIT_SPELLCAST_FAILED")
bus:RegisterEvent("UNIT_SPELLCAST_INTERRUPTED")
bus:RegisterEvent("LOOT_READY")
bus:RegisterEvent("LOOT_OPENED")
bus:RegisterEvent("LOOT_CLOSED")
bus:RegisterEvent("PLAYER_TARGET_CHANGED")
bus:RegisterEvent("NAME_PLATE_UNIT_ADDED")
bus:RegisterEvent("NAME_PLATE_UNIT_REMOVED")
bus:RegisterEvent("PLAYER_REGEN_DISABLED")
bus:RegisterEvent("PLAYER_REGEN_ENABLED")
-- Register globally so high-numbered nameplates are covered too. The handler
-- filters immediately to target/nameplate units, keeping the event inexpensive.
bus:RegisterEvent("UNIT_HEALTH")
bus:RegisterEvent("UNIT_FLAGS")

bus:SetScript("OnEvent", function(_, ev, ...)
    GDS_LoginLog.ExperimentalEvent(ev, ...)
    if ev == "PLAYER_LEAVING_WORLD" or ev == "PLAYER_LOGOUT" then
        GDS_LoginLog.worldReady = false
    elseif ev == "PLAYER_ENTERING_WORLD" then
        GDS_ItemCompat.RefreshLootContext()
        GDS_LoginLog.worldReady = true
        local _, isReload = ...
        if not GDS_LoginLog.entryReason then
            GDS_LoginLog.entryReason = isReload and "reload" or "login"
        end
        GDS_LoginLog.StartIfEnabled()
        GDS_LoginLog.WalletSample()
    end
    if DB then
        if ev == "PLAYER_LOGOUT" then
            GDS_LoginLog.Stop(true)
        elseif GDS_LoginLog.row and (ev == "PLAYER_MONEY" or ev == "PLAYER_XP_UPDATE" or ev == "PLAYER_LEVEL_UP") then
            if ev == "PLAYER_MONEY" then GDS_LoginLog.WalletSample() end
            if ev == "PLAYER_LEVEL_UP" then
                local row = GDS_LoginLog.row
                C_Timer.After(.1, function() if GDS_LoginLog.row == row then GDS_LoginLog.Sample() end end)
            else GDS_LoginLog.Sample() end
        end
    end
    if ev == "PLAYER_LOGOUT" then GDS_Characters.leaving = true end
    if ev == "PLAYER_LOGIN" then
        if DB or GDS_Characters.leaving then return end
        local characterKey = GDS_Characters.ResolveKey()
        if not characterKey then
            if not GDS_Characters.retryPending then
                GDS_Characters.retryPending = true
                C_Timer.After(1, function()
                    GDS_Characters.retryPending = false
                    bus:GetScript("OnEvent")(bus, "PLAYER_LOGIN")
                end)
            end
            return
        end
        local priorDesignVersion = GrindTrackerDB.designVersion
        local needsStartupVisibilityMigration = GrindTrackerDB.startupVisibilityVersion == nil
        local defaults = {
            designVersion=2,
            mainW=320, mainH=380, mainPos=nil,
            lootW=400, lootH=420, lootPos=nil,
            miniPos=nil,
            minimapAngle=225,
            minimapHidden=false,
            startOnLogin=false,
            opaque=false,
            startHidden=false,
            startupVisibilityVersion=1,
            autoStartOnOpen=true,
            windowLocked=false,
            partyTracking=false,
            partyKBLifetime={},
            partyKBSerial=0,
            partyKBBoardPos=nil,
            healerManaTracking=false,
            healerManaPos=nil,
            healerManaScale=100,
            healerManaShowPct=10,
            healerManaHidePct=50,
            tankThreatTracking=false,
            tankThreatScale=100,
            tankThreatShowPct=85,
            tankThreatHidePct=95,
            tankThreatPos=nil,
            dpsThreatTracking=false,
            dpsThreatScale=100,
            dpsThreatShowPct=85,
            dpsThreatHidePct=50,
            dpsThreatPos=nil,
            questTracking=false,
            questTotals={xp=0,gold=0},
            pvpTracking=false,
            repairTracking=false,
            showDurability=false,
            showTrackingHealth=true,
            showLiveDungeon=false,
            liveDungeonExpanded=false,
            repairsLifetime=0,
            pvpTotals={hk=0,kb=0},
            partyMiniVisible=false,
            partyMiniPos=nil,
            partyMiniW=326,
            partyMiniH=224,
            sessions={},
            dungeonRuns={},
            show={
                time=true,kills=true,kph=true,
                xp=true,xph=true,lvlt=true,
                coin=true,items=true,gph=true,total=true,
                fish=true,fishph=true,   -- EasyFishing bridge rows
                header=true,footer=true,
            },
            theme=CopyTheme(DEFAULT_THEME),
        }
        for k,v in pairs(defaults) do
            if GrindTrackerDB[k] == nil then GrindTrackerDB[k] = v end
        end
        -- v6.0.4 briefly made startup-hidden the implicit default. Restore the
        -- established launch behavior once, leaving the setting available as opt-in.
        if needsStartupVisibilityMigration then
            GrindTrackerDB.startHidden = false
            GrindTrackerDB.startupVisibilityVersion = 1
        end
        if GrindTrackerDB.show == nil then GrindTrackerDB.show = defaults.show end
        for k,v in pairs(defaults.show) do
            if GrindTrackerDB.show[k] == nil then GrindTrackerDB.show[k] = v end
        end
        -- Header/footer are no longer user-toggleable; force visible.
        GrindTrackerDB.show.header = true
        GrindTrackerDB.show.footer = true
        if GrindTrackerDB.theme == nil then GrindTrackerDB.theme = defaults.theme end
        for k,v in pairs(defaults.theme) do
            if GrindTrackerDB.theme[k] == nil then GrindTrackerDB.theme[k] = v end
        end
        if GrindTrackerDB.sessions == nil then GrindTrackerDB.sessions = {} end
        if priorDesignVersion ~= 2 then
            if (GrindTrackerDB.mainW or 0) <= 240 and (GrindTrackerDB.mainH or 0) <= 300 then
                GrindTrackerDB.mainW = defaults.mainW
                GrindTrackerDB.mainH = defaults.mainH
            end
            GrindTrackerDB.theme = CopyTable(defaults.theme)
            GrindTrackerDB.designVersion = defaults.designVersion
        end
        DB = GDS_Characters.Activate(characterKey)
        GDS_LoginLog.ExperimentalInit(characterKey)
        GDS_LoginLog.Reconcile(DB.loginHistory)
        if DB.loginTracking == nil then
            local latest = DB.loginHistory and DB.loginHistory[1]
            DB.loginTracking = latest ~= nil and latest.continuable == true
        else
            DB.loginTracking = DB.loginTracking == true or DB.loginTracking == 1
        end
        if GDS_LoginLog.entryReason then GDS_LoginLog.StartIfEnabled() end
        C_Timer.After(0, GDS_LoginLog.StartIfEnabled)
        if DB.opaque == nil then DB.opaque = false end
        if DB.repairTracking == nil then DB.repairTracking = false end
        if DB.showDurability == nil then DB.showDurability = false end
        DB.repairsLifetime = math.max(0, tonumber(DB.repairsLifetime) or 0)
        -- Before v6.4.0 Beta 2, right-click HID the minimap icon. Make the
        -- repurposed shortcut button visible once on upgrade. Users may still
        -- hide/show it later with /gt minimap, and that choice then persists.
        if DB.minimapControlsVersion ~= 2 then
            DB.minimapHidden = false
            DB.minimapControlsVersion = 2
        end
        GDS_Dungeon.CorrectScarletHistory()
        -- Unique event IDs survive reloads and PvP-stat resets. This is only
        -- created once per SavedVariables installation.
        if not DB.partyKBStamp then
            DB.partyKBStamp = math.floor((GetServerTime and GetServerTime()) or time())
        end
        if GDS_PvP then GDS_PvP.ResetBaseline(true) end
        GDS_PartySession.EnsureInviteFrame()
        if type(DB.activePartySession)=="table" and DB.activePartySession.id then
            GDS_PartySession.active=DB.activePartySession
            GDS_PartySession.active.lastXP=UnitXP("player") or 0
            GDS_PartySession.active.lastXPMax=UnitXPMax("player") or 1
            GDS_PartySession.active.lastLevel=UnitLevel("player") or 1
            -- Preserve previously filtered quest XP when upgrading mid-party-run.
            GDS_PartySession.active.questXPExcluded = GDS_PartySession.active.questXPExcluded
                or GDS_PartySession.active.questXP or 0
        end
        if C_ChatInfo and C_ChatInfo.RegisterAddonMessagePrefix then
            C_ChatInfo.RegisterAddonMessagePrefix(PARTY_PREFIX)
        elseif RegisterAddonMessagePrefix then
            RegisterAddonMessagePrefix(PARTY_PREFIX)
        end
        C_Timer.NewTicker(0.5, function()
            if addonReady and GTUpdateHealerManaAlert then GTUpdateHealerManaAlert() end
            if addonReady and GTUpdateThreatAlerts then GTUpdateThreatAlerts() end
        end)
        C_Timer.NewTicker(3, function()
            if addonReady and GDS_PvP then GDS_PvP.OnHonorChanged(false) end
        end)
        C_Timer.NewTicker(1, function()
            if addonReady and GDS_PartySession.active then
                if GDS_PartySession.Active() then
                    GDS_PartySession.active.timer=GDS_PartySession.active.timer+1
                else
                    -- A paused session must not accumulate XP in the background.
                    GDS_PartySession.OnXP()
                end
            end
            -- Also refresh when only an independent party session is running.
            if addonReady and GDS_LiveDungeon then GDS_LiveDungeon.Refresh() end
        end)
        C_Timer.NewTicker(3, function()
            if addonReady then
                GDS_Dungeon.UpdateIdentification()
                if GDS_PartySession.active then GDS_PartySession.UpdateDungeon() end
            end
        end)
        C_Timer.NewTicker(10, function()
            if addonReady and PartyAvailable() then
                GDS_PartySession.SendStats()
                SendPartyStats()
                if RefreshPartyStats then RefreshPartyStats() end
            end
        end)
        DB.priceOverrides = DB.priceOverrides or {}
        DB.defaultPriceMode = DB.defaultPriceMode or "vendor"
        if DB.skinMode ~= "default" and DB.skinMode ~= "wow" and DB.skinMode ~= "nightfall"
            and DB.skinMode ~= "wowlook" and DB.skinMode ~= "classicstone"
            and DB.skinMode ~= "classicleather" and DB.skinMode ~= "tooltipframe"
            and DB.skinMode ~= "authenticvanilla" and DB.skinMode ~= "custom" then
            DB.skinMode = ThemesMatch(DB.theme, DEFAULT_THEME) and "default" or "custom"
        end
        DB.customTheme = CopyTheme(DB.customTheme or DB.theme or DEFAULT_THEME)
        if DB.skinMode == "default" then DB.theme = CopyTheme(DEFAULT_THEME)
        elseif DB.skinMode == "wow" then DB.theme = CopyTheme(WOW_THEME)
        elseif DB.skinMode == "nightfall" then DB.theme = CopyTheme(GDS_NIGHTFALL_THEME)
        elseif DB.skinMode == "wowlook" then DB.theme = CopyTheme(GDS_WOWLOOK_THEME)
        elseif DB.skinMode == "classicstone" then DB.theme = CopyTheme(GDS_CLASSIC_STONE_THEME)
        elseif DB.skinMode == "classicleather" then DB.theme = CopyTheme(GDS_CLASSIC_LEATHER_THEME)
        elseif DB.skinMode == "tooltipframe" then DB.theme = CopyTheme(GDS_TOOLTIP_FRAME_THEME)
        elseif DB.skinMode == "authenticvanilla" then DB.theme = CopyTheme(GDS_AUTHENTIC_VANILLA_THEME)
        else DB.theme = CopyTheme(DB.customTheme) end
        -- Manual profile UI and autoload are retired. Direct character settings
        -- persist normally; archived legacy profiles remain in SavedVariables.

        C_Timer.After(0, function()
            C_Timer.After(0, function()
                BuildMainFrame()
                BuildMinimapButton()
                GDS_TabSwitcher.UpdateEdgeButton()
                GDS_LiveDungeon.Build()
                ApplyVisibility()
                C_Timer.After(0, function()
                    local resumed = RestoreActiveSession()
                    GDS_ItemCompat.RestorePrices()
                    if resumed then RepriceCurrentLoot(true) end
                    addonReady = true
                    GDS_Health.Refresh()
                    GDS_LiveDungeon.Refresh()
                    PartyRosterChanged()
                    if GTUpdateHealerManaAlert then GTUpdateHealerManaAlert() end
                    if DB.partyMiniVisible then SetPartyMiniVisible(true) end
                    InstallManualBagClicks()
                    -- EasyFishing bridge: refresh the Fish / Fish/h rows whenever
                    -- EasyFishing's session numbers change, even with no GT session.
                    if _G.EasyFishing and EasyFishing.RegisterCallback then
                        EasyFishing.RegisterCallback(function()
                            if S and S.running and mainFrame and mainFrame:IsShown() then
                                RefreshStats()
                            end
                        end)
                    end
                    -- Startup checkbox is OFF by default. Restore an old
                    -- running session in the background, but do not open the UI
                    -- unless this player opted in to Start on Login.
                    if mainFrame then
                        if DB.startOnLogin == true then
                            loginWindowShow = true
                            mainFrame:Show()
                            loginWindowShow = false
                            if S and not S.running then BeginSession() end
                        elseif GDS_Characters.openWhenReady then
                            mainFrame:Show()
                        else
                            mainFrame:Hide()
                        end
                    end
                    DEFAULT_CHAT_FRAME:AddMessage(
                        "|cFFD8DDE6Grind Dont Stop|r v"..VERSION.."  |cFFAAAAAA/gt|r to open."
                        .. (resumed and " |cFF77DD77Session restored.|r" or ""))
                end)
            end)
        end)

    elseif not addonReady then return
    end

    -- Observe raw event delivery separately from the existing filters. A raw
    -- money/loot event is NOT assumed to be legitimate farming income.
    if GDS_Health then GDS_Health.Note(ev, false) end

    if ev == "CHAT_MSG_ADDON" then OnPartyMessage(...)
    elseif ev == "CHAT_MSG_SYSTEM" then GDS_Dungeon.OnSystemMessage((...))
    elseif ev == "PLAYER_DEAD" then GDS_Dungeon.MarkDeath()
    elseif ev == "PLAYER_ALIVE" or ev == "PLAYER_UNGHOST" then
        -- A resurrection INSIDE the dungeon clears any pending ghost-exit flag.
        C_Timer.After(0.3, function()
            UpdateDungeonRun()
            GDS_PartySession.UpdateDungeon()
        end)
    elseif ev == "GROUP_ROSTER_UPDATE" then
        PartyRosterChanged()
        if GTUpdateHealerManaAlert then GTUpdateHealerManaAlert() end
        if GTUpdateThreatAlerts then GTUpdateThreatAlerts() end
    elseif ev == "PLAYER_LOGOUT" then
        -- /reload also fires PLAYER_LOGOUT. Keep the active dungeon run and
        -- all session data intact instead of closing it as a new run.
        DB.activeSession = S and S or nil
        DB.activePartySession = GDS_PartySession.active
        if DB.activePartySession then
            local pending = {}
            for _, award in ipairs(GDS_ItemCompat.pending) do
                if award.party == DB.activePartySession then
                    pending[#pending+1] = {id=award.id, qty=award.qty, total=award.originalTotal}
                end
            end
            DB.activePartySession.pendingPrices = pending
        end
        GDS_Characters.Checkpoint(DB)
    elseif ev == "PLAYER_ENTERING_WORLD" or ev == "ZONE_CHANGED_NEW_AREA" then
        -- Zone data can briefly report the previous instance during loading.
        C_Timer.After(0.3, function()
            UpdateDungeonRun()
            GDS_PartySession.UpdateDungeon()
            GDS_Dungeon.UpdateIdentification()
        end)
    elseif ev == "ZONE_CHANGED" or ev == "ZONE_CHANGED_INDOORS" then
        -- Subzone hints update inside a wing without changing instance ID.
        GDS_Dungeon.UpdateIdentification()
    elseif ev == "BAG_OPEN" then InstallManualBagClicks()
    elseif ev == "PLAYER_XP_UPDATE"       then OnXPUpdate(); GDS_Health.Note(ev, true)
    elseif ev == "PLAYER_LEVEL_UP"        then OnLevelUp()
    elseif ev == "MERCHANT_SHOW" then
        merchantOpen = true
        moneyBaseline = GetMoney()
        GDS_Repairs.OnMerchantShow()
    elseif ev == "MERCHANT_UPDATE" then
        GDS_Repairs.QueueCheck()
    elseif ev == "MERCHANT_CLOSED" then
        GDS_Repairs.OnMerchantClosed()
        merchantOpen = false
        moneyBaseline = GetMoney()
    elseif ev == "UPDATE_INVENTORY_DURABILITY" then
        GDS_Repairs.RefreshLabel()
        if DB and DB.showDurability then RefreshStats() end
    elseif ev == "MAIL_SHOW" then
        mailboxOpen = true
        GDS_Coin.lastLootAt, GDS_Coin.lastLootAmount = -100, nil
        -- Snapshot before collecting mail so it cannot inflate farming income.
        moneyBaseline = GetMoney()
        recentMoneyGain = nil
    elseif ev == "MAIL_CLOSED" then
        mailboxOpen = false
        mailboxClosedAt = GetTime()
        GDS_Coin.lastLootAt, GDS_Coin.lastLootAmount = -100, nil
        -- A delayed PLAYER_MONEY event may follow MAIL_CLOSED; its delta is
        -- also suppressed by IgnoreMailboxLoot until the grace period expires.
        moneyBaseline = GetMoney()
        recentMoneyGain = nil
    elseif ev == "TRADE_SHOW" then
        GDS_Trade.OnShow()
    elseif ev == "TRADE_CLOSED" then
        GDS_Trade.OnClosed()
    elseif ev == "PLAYER_MONEY"           then
        GDS_Repairs.QueueCheck()
        OnMoneyChanged()
        GDS_Health.Note(ev, true)
    elseif ev == "QUEST_TURNED_IN"         then OnQuestTurnedIn(...)
    elseif ev == "PLAYER_PVP_KILLS_CHANGED" then GDS_PvP.OnHonorChanged(true)
    elseif ev == "PARTY_KILL"               then GDS_PvP.OnPartyKill(...)
    elseif ev == "TRADE_SKILL_SHOW" then
        professionWindowOpen = true
    elseif ev == "TRADE_SKILL_CLOSE" then
        professionWindowOpen = false
        professionClosedAt = GetTime()
    elseif ev == "UNIT_SPELLCAST_START" or ev == "UNIT_SPELLCAST_SUCCEEDED" or ev == "UNIT_SPELLCAST_FAILED" or ev == "UNIT_SPELLCAST_INTERRUPTED" or ev == "LOOT_READY" or ev == "LOOT_OPENED" or ev == "LOOT_CLOSED" then
        if ev == "LOOT_READY" or ev == "LOOT_OPENED" then GDS_ItemCompat.CheckLootSource() end
        GDS_ItemCompat.DisenchantEvent(ev, ...)
    elseif ev == "CHAT_MSG_MONEY"         then GDS_Coin.OnLootMessage((...)); GDS_Health.Note(ev, true)
    elseif ev == "CHAT_MSG_LOOT"          then OnLoot((...), (select(12, ...))); GDS_Health.Note(ev, true)
    elseif ev == "GET_ITEM_INFO_RECEIVED" then GDS_ItemCompat.Resolve((...))
    elseif ev == "PLAYER_TARGET_CHANGED"  then
        OnTargetChanged()
        if GTUpdateThreatAlerts then GTUpdateThreatAlerts() end
    elseif ev == "UNIT_HEALTH" or ev == "UNIT_FLAGS" then
        local unit = (...)
        if unit == "target" or (type(unit) == "string" and unit:match("^nameplate%d+$")) then
            OnUnitHealth(unit)
        end
    elseif ev == "NAME_PLATE_UNIT_ADDED"  then TrackUnit((...))
    elseif ev == "NAME_PLATE_UNIT_REMOVED" then
        local unit = (...)
        OnUnitHealth(unit)
        watchedUnits[unit] = nil
    elseif ev == "PLAYER_REGEN_DISABLED"  then
        -- Preserve the pre-combat target registration so a one-hit kill can be
        -- counted on its first (and possibly only) health/death-state event.
        TrackUnit("target")
    elseif ev == "PLAYER_REGEN_ENABLED"   then
        for unit in pairs(watchedUnits) do
            if not UnitExists(unit) then watchedUnits[unit] = nil end
        end
        OnTargetChanged()
    end
end)

-------------------------------------------------------------------------------
-- MINIMAP BUTTON
-------------------------------------------------------------------------------
local GT_minimapShapes = {
    ["ROUND"]               = {true,  true,  true,  true },
    ["SQUARE"]              = {false, false, false, false},
    ["CORNER-TOPLEFT"]      = {false, false, false, true },
    ["CORNER-TOPRIGHT"]     = {false, false, true,  false},
    ["CORNER-BOTTOMLEFT"]   = {false, true,  false, false},
    ["CORNER-BOTTOMRIGHT"]  = {true,  false, false, false},
    ["SIDE-LEFT"]           = {false, true,  false, true },
    ["SIDE-RIGHT"]          = {true,  false, true,  false},
    ["SIDE-TOP"]            = {false, false, true,  true },
    ["SIDE-BOTTOM"]         = {true,  true,  false, false},
    ["TRICORNER-TOPLEFT"]   = {false, true,  true,  true },
    ["TRICORNER-TOPRIGHT"]  = {true,  false, true,  true },
    ["TRICORNER-BOTTOMLEFT"]  = {true, true, false, true },
    ["TRICORNER-BOTTOMRIGHT"] = {true, true, true,  false},
}

local function UpdateMinimapPos(position)
    local rad, cos, sin, sqrt, max, min = math.rad, math.cos, math.sin, math.sqrt, math.max, math.min
    local angle = rad(position or 225)
    local x, y, q = cos(angle), sin(angle), 1
    if x < 0 then q = q + 1 end
    if y > 0 then q = q + 2 end
    local shape = GetMinimapShape and GetMinimapShape() or "ROUND"
    local quad  = GT_minimapShapes[shape] or GT_minimapShapes["ROUND"]
    local w = (Minimap:GetWidth()  / 2) + 5
    local h = (Minimap:GetHeight() / 2) + 5
    if quad[q] then
        x, y = x * w, y * h
    else
        local dw = sqrt(2 * w^2) - 10
        local dh = sqrt(2 * h^2) - 10
        x = max(-w, min(x * dw, w))
        y = max(-h, min(y * dh, h))
    end
    minimapBtn:ClearAllPoints()
    minimapBtn:SetPoint("CENTER", Minimap, "CENTER", x, y)
end

BuildMinimapButton = function()
    if minimapBtn then return end

    minimapBtn = CreateFrame("Button", "GTMinimapButton", Minimap)
    minimapBtn:SetSize(31, 31)
    minimapBtn:SetFrameStrata("MEDIUM")
    minimapBtn:SetFrameLevel(8)
    minimapBtn:SetMovable(true)
    minimapBtn:RegisterForDrag("LeftButton")

    -- The existing draggable minimap button now uses a stock coin icon.
    -- No extra textures or TOC changes are required.
    local icon = minimapBtn:CreateTexture(nil, "ARTWORK")
    icon:SetSize(20, 20)
    icon:SetPoint("TOPLEFT", minimapBtn, "TOPLEFT", 7, -5)
    icon:SetTexture("Interface\\Icons\\INV_Misc_Coin_01")
    icon:SetTexCoord(0.08, 0.92, 0.08, 0.92)

    -- Circular mask to round the icon corners
    if icon.AddMaskTexture and minimapBtn.CreateMaskTexture then
        local mask = minimapBtn:CreateMaskTexture(nil, "ARTWORK")
        mask:SetTexture("Interface\\CharacterFrame\\TempPortraitAlphaMask",
            "CLAMPTOBLACKADDITIVE", "CLAMPTOBLACKADDITIVE")
        mask:SetSize(22, 22)
        mask:SetPoint("CENTER", icon, "CENTER")
        icon:AddMaskTexture(mask)
    end

    -- Border ring — anchored TOPLEFT so the 53×53 texture overhangs correctly
    local border = minimapBtn:CreateTexture(nil, "OVERLAY")
    border:SetTexture("Interface\\Minimap\\MiniMap-TrackingBorder")
    border:SetSize(53, 53)
    border:SetPoint("TOPLEFT", minimapBtn, "TOPLEFT", 0, 0)

    -- Highlight
    local hl = minimapBtn:CreateTexture(nil, "HIGHLIGHT")
    hl:SetPoint("CENTER", icon, "CENTER")
    hl:SetSize(20, 20)
    hl:SetColorTexture(1, 1, 1, 0.18)

    minimapBtn:RegisterForClicks("LeftButtonUp", "RightButtonUp")

    -- Four shortcuts, prioritized so Shift+click never triggers regular click.
    -- These call the existing session and party-screen functions; dungeon and
    -- personal-session logging remain unchanged.
    minimapBtn:SetScript("OnClick", function(_, btn)
        if not addonReady then return end
        local shifted = IsShiftKeyDown and IsShiftKeyDown()
        if shifted and btn == "LeftButton" then
            -- Same 3-second start countdown as the main Start button. A paused
            -- session resumes; an already-running session is not interrupted.
            if S and mainFrame and mainFrame.startBtn and mainFrame.startBtn:IsEnabled()
                and (not S.running or S.paused) then
                TogglePause()
            end
        elseif shifted and btn == "RightButton" then
            -- End only the PERSONAL session and save it to Full Sessions.
            -- Independent cooperative party sessions continue uninterrupted.
            if S and S.running then EndSession() end
        elseif btn == "LeftButton" then
            -- Toggle the main tracker. Do not affect the running session.
            GDS_TabSwitcher.ToggleMain()
        elseif btn == "RightButton" then
            -- Toggle the compact "Party Grind Don't Stop" leaderboard, not
            -- the larger Party Stats/Settings panel. Keep the saved compact
            -- window visibility and its Settings checkbox in sync.
            local open = partyMiniFrame and partyMiniFrame:IsShown()
            SetPartyMiniVisible(not open)
            if not open and partyMiniFrame then partyMiniFrame:Raise() end
        end
    end)

    -- Drag to reposition around the minimap ring
    minimapBtn:SetScript("OnDragStart", function(self)
        self:SetScript("OnUpdate", function()
            local scale  = Minimap:GetEffectiveScale()
            local cx, cy = Minimap:GetCenter()
            local px, py = GetCursorPosition()
            local pos    = math.deg(math.atan2(py / scale - cy, px / scale - cx)) % 360
            DB.minimapAngle = pos
            UpdateMinimapPos(pos)
        end)
    end)
    minimapBtn:SetScript("OnDragStop", function(self)
        self:SetScript("OnUpdate", nil)
        UpdateMinimapPos(DB.minimapAngle or 225)
    end)

    -- Tooltip
    minimapBtn:SetScript("OnEnter", function(self)
        GameTooltip:SetOwner(self, "ANCHOR_LEFT")
        GameTooltip:SetText("Grind Don't Stop  |cFFBDA66Ev" .. VERSION .. "|r", 1, 1, 1)
        GameTooltip:AddLine("Left-click: Open / close main tracker", 0.8, 0.8, 0.8)
        GameTooltip:AddLine("Right-click: Open / close Party Grind Don't Stop", 0.8, 0.8, 0.8)
        GameTooltip:AddLine("Shift + Left-click: Start / resume session", 0.8, 0.8, 0.8)
        GameTooltip:AddLine("Shift + Right-click: End and save session", 1, 0.76, 0.45)
        GameTooltip:AddLine("Drag: Reposition around minimap", 0.65, 0.68, 0.75)
        GameTooltip:Show()
    end)
    minimapBtn:SetScript("OnLeave", function()
        GameTooltip:Hide()
    end)

    UpdateMinimapPos(DB.minimapAngle or 225)

    if DB.minimapHidden then
        minimapBtn:Hide()
    end
end

-------------------------------------------------------------------------------
-- SLASH COMMANDS
-------------------------------------------------------------------------------
SLASH_GRINDTRACKER1 = "/gt"
SLASH_GRINDTRACKER2 = "/grind"
SLASH_GRINDTRACKER3 = "/gtr"
SLASH_GRINDTRACKER4 = "/grindtracker"
SlashCmdList["GRINDTRACKER"] = function(raw)
    -- Copy this line into support reports to identify the addon and client.
    if type(raw) == "string" and raw:match("^%s*(.-)%s*$"):lower() == "version" then
        local getMetadata = (C_AddOns and C_AddOns.GetAddOnMetadata) or GetAddOnMetadata
        local installedVersion = VERSION -- code build; TOC metadata may be older
        local clientVersion, clientBuild = "unknown", "unknown"
        if type(GetBuildInfo) == "function" then clientVersion, clientBuild = GetBuildInfo() end
        print("Grind Dont Stop " .. tostring(installedVersion) .. " | WoW " .. tostring(clientVersion) .. " (build " .. tostring(clientBuild) .. ")")
        return
    end

    local cmd = (raw or ""):lower():match("^%s*(.-)%s*$")

    if not addonReady then
        if cmd == "" then GDS_Characters.openWhenReady = true end
        print(DB and "GrindTracker is loading." or "GrindTracker is waiting for your character and realm.")
        return
    end

    if cmd == "experimental" or cmd == "loginanalytics" then
        GDS_LoginLog.ExperimentalShow(cmd == "experimental")
        return
    end
    if cmd == "logins" or cmd:match("^logins%s+%d+$") then
        GDS_LoginLog.Report(tonumber(cmd:match("%d+$")))
        return
    end
    if cmd == "dropalert" or cmd:match("^dropalert%s") then
        local arg = cmd:match("^dropalert%s+(.+)$")
        local gold = arg and tonumber(arg)
        if arg == "off" then DB.dropAlertGold = nil
        elseif gold and gold > 0 and gold < math.huge then DB.dropAlertGold = gold
        elseif arg then print("Use /gt dropalert <gold> or /gt dropalert off"); return end
        print("GrindTracker drop alert: " .. (DB.dropAlertGold and (DB.dropAlertGold .. "g per stack") or "off"))
        return
    end
    if cmd == "reset" then
        ResetSession()
        DEFAULT_CHAT_FRAME:AddMessage("|cFFD8DDE6Grind Dont Stop|r session reset.")

    elseif cmd == "skin" or cmd == "rescue" or cmd == "safe" or cmd:match("^skin%s+") then
        -- Emergency command must work even if the main UI is hidden/covered.
        -- "rescue" aliases bypass the selector and restore stock Original.
        local requested = (cmd == "rescue" or cmd == "safe") and "original"
            or cmd:match("^skin%s+(.+)$")
        local modes = {
            ["original"]="default", ["default"]="default",
            ["vanilla"]="wow", ["vanilla wow"]="wow", ["forever"]="wow",
            ["nightfall"]="nightfall",
            ["authentic"]="authenticvanilla", ["authentic vanilla"]="authenticvanilla",
            ["classic ui"]="authenticvanilla", ["blizzard"]="authenticvanilla",
            ["wow experimental"]="wowlook", ["experimental"]="wowlook",
            ["wow look"]="wowlook", ["wowlook"]="wowlook", ["look"]="wowlook",
            ["stone"]="classicstone", ["classic stone"]="classicstone", ["classicstone"]="classicstone",
            ["leather"]="classicleather", ["classic leather"]="classicleather", ["classicleather"]="classicleather",
            ["tooltip"]="tooltipframe", ["tooltip frame"]="tooltipframe", ["tooltipframe"]="tooltipframe",
        }
        local mode = modes[requested or ""]
        if mode then
            SetSkinMode(mode)
            if GDS_Skins.Refresh then GDS_Skins.Refresh() end
            DEFAULT_CHAT_FRAME:AddMessage("|cFFFFD27DGrind Dont Stop|r Skin changed to " .. requested .. ".")
        else
            DEFAULT_CHAT_FRAME:AddMessage("|cFFFFD27DGrind Dont Stop|r Use /gt skin authentic, stone, leather, tooltip, original, or experimental; /gt rescue resets appearance.")
        end

    elseif cmd=="wing" or cmd:match("^wing%s+") then
        local name,kind=GetInstanceInfo()
        local wingText=cmd:match("^wing%s+(.+)$")
        local choices={gy="Graveyard",graveyard="Graveyard",lib="Library",
            library="Library",arm="Armory",armory="Armory",
            cath="Cathedral",cathedral="Cathedral"}
        local choice=wingText and choices[wingText] or nil
        if not choice then
            local detected=kind=="party" and GDS_Dungeon.DetectWing(name) or nil
            DEFAULT_CHAT_FRAME:AddMessage("|cFFD8DDE6Grind Dont Stop|r Scarlet wing: "
                .. (detected or "unidentified") .. ". Use /gt wing cathedral|armory|library|graveyard while inside.")
        elseif GDS_Dungeon.ManualWing(choice) then
            DEFAULT_CHAT_FRAME:AddMessage("|cFFD8DDE6Grind Dont Stop|r Current Scarlet Monastery run set to "..choice..".")
        else
            DEFAULT_CHAT_FRAME:AddMessage("|cFFFFAA55Grind Dont Stop|r Start tracking inside Scarlet Monastery first.")
        end

    elseif cmd == "dungeonnew" or cmd == "dungeonreset" then
        if GDS_Dungeon.MarkNewRun() then
            DEFAULT_CHAT_FRAME:AddMessage(
                "|cFFD8DDE6Grind Dont Stop|r New dungeon copy marked. Your overall session keeps running.")
        else
            DEFAULT_CHAT_FRAME:AddMessage(
                "|cFFFFAA55Grind Dont Stop|r No active dungeon run to split.")
        end

    elseif cmd == "loot" then
        if lootFrame then ToggleLootLog() end

    elseif cmd == "minimap" then
        if minimapBtn then
            if minimapBtn:IsShown() then
                minimapBtn:Hide()
                DB.minimapHidden = true
                DEFAULT_CHAT_FRAME:AddMessage("|cFFD8DDE6Grind Dont Stop|r Minimap button hidden.")
            else
                minimapBtn:Show()
                DB.minimapHidden = false
                DEFAULT_CHAT_FRAME:AddMessage("|cFFD8DDE6Grind Dont Stop|r Minimap button shown.")
            end
        end

    elseif cmd == "debug" then
        debugMode = not debugMode
        DEFAULT_CHAT_FRAME:AddMessage(
            "|cFFD8DDE6Grind Dont Stop|r Debug "..
            (debugMode and "|cFF00FF00ON|r — price source shown per item"
                       or "|cFFFF4444OFF|r"))
        if debugMode then
            local api = _G.AuctionCompanionAPI
            DEFAULT_CHAT_FRAME:AddMessage("|cFF00FFFF[GT]|r Auction Companion API: " .. (type(api)=="table" and type(api.GetPriceByItemID)=="function" and "ready" or "unavailable"))
        end

    elseif cmd == "ahtest" or cmd:match("^ahtest%s+") then
        local id = tonumber(cmd:match("^ahtest%s+(%d+)$"))
        if not id then
            DEFAULT_CHAT_FRAME:AddMessage("GT: Usage: /gt ahtest <itemID>")
            return
        end
        local price, source, stamp = GDS_ItemCompat.MarketQuote(id)
        DEFAULT_CHAT_FRAME:AddMessage("GT: AC item " .. id .. " price=" .. tostring(price) .. " copper; source=" .. tostring(source) .. "; timestamp=" .. tostring(stamp))

    elseif cmd == "partyaccept" then
        GDS_PartySession.Respond(true)
    elseif cmd == "partydecline" then
        GDS_PartySession.Respond(false)
    elseif cmd == "partystart" then
        GDS_PartySession.Start()
    elseif cmd == "partyend" then
        GDS_PartySession.Stop()
    elseif cmd == "party" or cmd == "partystatus" then
        GDS_PartySync.PrintStatus()

    elseif cmd == "pvp" then
        local totals = DB and DB.pvpTotals or {}
        local lifetime = GDS_PvP and GDS_PvP.ReadLifetimeHK and GDS_PvP.ReadLifetimeHK()
        DEFAULT_CHAT_FRAME:AddMessage("|cFFD8DDE6Grind Dont Stop PvP|r  Session: "
            .. FmtNum(S and S.pvpHK or 0) .. " HK / " .. FmtNum(S and S.pvpKB or 0) .. " KB")
        DEFAULT_CHAT_FRAME:AddMessage("|cFFD8DDE6Grind Dont Stop PvP|r  All-time WoW HKs: "
            .. (lifetime and FmtNum(lifetime) or "Loading...")
            .. "  |  All-time tracked KBs: " .. FmtNum(totals.kb or 0))

    elseif cmd == "history" then
        ToggleHistory()
    elseif cmd == "note" or cmd == "name" or cmd == "details" then
        GDS_SessionMeta.Open(S)

    elseif cmd == "profiles" or cmd == "profile" or cmd:match("^profile%s+") then
        DEFAULT_CHAT_FRAME:AddMessage("|cFFD8DDE6Grind Dont Stop|r Profiles are retired. Settings and history now save automatically per character.")

    elseif cmd == "help" then
        DEFAULT_CHAT_FRAME:AddMessage("|cFFD8DDE6Grind Dont Stop|r v"..VERSION)
        DEFAULT_CHAT_FRAME:AddMessage("  /gt, /gtr     — show/hide window")
        DEFAULT_CHAT_FRAME:AddMessage("  /gt reset     — reset session (no save)")
        DEFAULT_CHAT_FRAME:AddMessage("  /gt loot      — toggle loot log (left-click items to change pricing)")
        DEFAULT_CHAT_FRAME:AddMessage("  Pricing default is in Settings; item overrides persist across reloads")
        DEFAULT_CHAT_FRAME:AddMessage("  /gt history   — toggle session history")
        DEFAULT_CHAT_FRAME:AddMessage("  /gt note      — edit current session name and note")
        DEFAULT_CHAT_FRAME:AddMessage("  /gt dungeonnew — mark a confirmed new dungeon copy (fallback)")
        DEFAULT_CHAT_FRAME:AddMessage("  /gt wing cathedral|armory|library|graveyard — set current SM wing if needed")
        DEFAULT_CHAT_FRAME:AddMessage("  /gt pvp       — session and all-time HK / KB counts")
        DEFAULT_CHAT_FRAME:AddMessage("  /gt partystart / partyend — independent shared run")
        DEFAULT_CHAT_FRAME:AddMessage("  /gt partyaccept / partydecline — answer session invite")
        DEFAULT_CHAT_FRAME:AddMessage("  /gt partystatus — test party addon connection")
        DEFAULT_CHAT_FRAME:AddMessage("  /gt skin stone | leather | tooltip — Blizzard art-based skins")
        DEFAULT_CHAT_FRAME:AddMessage("  /gt skin experimental — try the carved-gold WoW Experimental skin")
        DEFAULT_CHAT_FRAME:AddMessage("  /gt skin original — immediately restore Original appearance")
        DEFAULT_CHAT_FRAME:AddMessage("  /gt rescue   — emergency restore (no UI required)")
        DEFAULT_CHAT_FRAME:AddMessage("  /gt minimap   — show/hide minimap button (if hidden)")
        DEFAULT_CHAT_FRAME:AddMessage("  Minimap: left=main, right=compact Party window, Shift+left=start, Shift+right=end")
        DEFAULT_CHAT_FRAME:AddMessage("  Settings and history save automatically per character")
        DEFAULT_CHAT_FRAME:AddMessage("  /gt debug     — toggle debug output")
        DEFAULT_CHAT_FRAME:AddMessage("  /gt dropalert <gold|off> — valuable drop alerts")
        DEFAULT_CHAT_FRAME:AddMessage("  /gt help      — this list")

    else
        if mainFrame then
            if mainFrame:IsShown() then mainFrame:Hide()
            else mainFrame:Show() end
        end
    end
end

-------------------------------------------------------------------------------
-- Interface Options registration
-------------------------------------------------------------------------------
do
    local reg = CreateFrame("Frame")
    reg:RegisterEvent("ADDON_LOADED")
    reg:SetScript("OnEvent", function(self, event, arg1)
        if arg1 ~= "GrindTracker" then return end
        self:UnregisterAllEvents()

        local panel = CreateFrame("Frame")
        panel.name = "Grind Dont Stop"

        local title = panel:CreateFontString(nil, "ARTWORK", "GameFontNormalLarge")
        title:SetPoint("TOPLEFT", 16, -16)
        TrackThemeText(title)
        title:SetText("Grind Dont Stop")

        local desc = panel:CreateFontString(nil, "ARTWORK", "GameFontHighlight")
        desc:SetPoint("TOPLEFT", title, "BOTTOMLEFT", 0, -8)
        TrackThemeText(desc)
        desc:SetText("Session tracker for kills, XP, loot value, and history.")

        local openBtn = CreateFrame("Button", nil, panel, "UIPanelButtonTemplate")
        openBtn:SetSize(160, 26)
        openBtn:SetPoint("TOPLEFT", 16, -70)
        openBtn:SetText("Open Grind Dont Stop")
        openBtn:SetScript("OnClick", function() SlashCmdList["GRINDTRACKER"]("") end)

        local cmds = panel:CreateFontString(nil, "ARTWORK", "GameFontHighlightSmall")
        cmds:SetPoint("TOPLEFT", openBtn, "BOTTOMLEFT", 0, -10)
        TrackThemeText(cmds)
        cmds:SetText("/gt, /gtr  \124  /gt reset  \124  /gt loot  \124  /gt history  \124  /gt help")

        -- ── Appearance ────────────────────────────────────────────────────────
        local appHdr = panel:CreateFontString(nil, "ARTWORK", "GameFontNormalLarge")
        appHdr:SetPoint("TOPLEFT", 16, -130)
        TrackThemeText(appHdr)
        appHdr:SetText("Appearance")

        local appRule = panel:CreateTexture(nil, "ARTWORK")
        appRule:SetPoint("TOPLEFT", 16, -152); appRule:SetPoint("TOPRIGHT", -16, -152)
        appRule:SetHeight(1); appRule:SetColorTexture(0.5, 0.5, 0.5, 0.5)

        -- Swatch refs so we can refresh them when the panel is shown
        local swatchUpdaters = {}
        local customControls = {}
        local skinButtons = {}

        local function RefreshSkinControls()
            local mode = DB and DB.skinMode or "default"
            for key, button in pairs(skinButtons) do
                button:SetEnabled(key ~= mode)
            end
            local enabled = mode == "custom"
            for _, control in ipairs(customControls) do
                control:SetAlpha(enabled and 1 or 0.38)
                if control.Enable and control.Disable then
                    if enabled then control:Enable() else control:Disable() end
                end
            end
        end

        local skinLabel = panel:CreateFontString(nil, "ARTWORK", "GameFontHighlight")
        skinLabel:SetPoint("LEFT", appHdr, "RIGHT", 24, 0)
        TrackThemeText(skinLabel); skinLabel:SetText("Skin:")

        local previousModeButton
        local function MakeModeButton(mode, text)
            local button = CreateFrame("Button", nil, panel, "UIPanelButtonTemplate")
            button:SetSize(78, 24); button:SetText(text)
            if previousModeButton then button:SetPoint("LEFT", previousModeButton, "RIGHT", 5, 0)
            else button:SetPoint("LEFT", skinLabel, "RIGHT", 8, 0) end
            previousModeButton = button
            skinButtons[mode] = button
            button:SetScript("OnClick", function()
                SetSkinMode(mode)
                for _, fn in ipairs(swatchUpdaters) do fn() end
                RefreshSkinControls()
            end)
        end
        MakeModeButton("default", "Default")
        MakeModeButton("wow", "Forever")
        MakeModeButton("custom", "Custom")

        -- Helper: open WoW's built-in color picker
        -- opacity in SetupColorPickerAndShow: 0=opaque, 1=transparent
        -- GetColorAlpha() returns: 0=transparent, 1=opaque  →  alpha = GetColorAlpha()
        local function OpenPicker(r, g, b, a, hasAlpha, onChange, onCancel)
            if not ColorPickerFrame then
                return
            end

            local function ApplyColor()
                local nr, ng, nb = ColorPickerFrame:GetColorRGB()
                local opacityValue
                if ColorPickerFrame.GetColorAlpha then
                    opacityValue = ColorPickerFrame:GetColorAlpha()
                elseif OpacitySliderFrame and OpacitySliderFrame.GetValue then
                    opacityValue = OpacitySliderFrame:GetValue()
                else
                    opacityValue = 0
                end
                local na = hasAlpha and (1 - opacityValue) or (a or 1)
                onChange(nr, ng, nb, na)
            end

            if ColorPickerFrame.SetupColorPickerAndShow then
                local info = {
                    r = r, g = g, b = b,
                    hasOpacity = hasAlpha,
                    opacity    = hasAlpha and (1 - (a or 1)) or nil,
                    swatchFunc = ApplyColor,
                    cancelFunc = function()
                        onCancel(r, g, b, a)
                    end,
                }
                if hasAlpha then
                    info.opacityFunc = ApplyColor
                end
                ColorPickerFrame:SetupColorPickerAndShow(info)
                return
            end

            ColorPickerFrame.hasOpacity = hasAlpha and true or false
            ColorPickerFrame.opacity = hasAlpha and (1 - (a or 1)) or 0
            ColorPickerFrame.previousValues = { r, g, b, hasAlpha and (1 - (a or 1)) or 0 }
            ColorPickerFrame.func = ApplyColor
            ColorPickerFrame.opacityFunc = hasAlpha and ApplyColor or nil
            ColorPickerFrame.cancelFunc = function(previousValues)
                if previousValues then
                    local pa = hasAlpha and (1 - (previousValues[4] or 0)) or (a or 1)
                    onCancel(previousValues[1], previousValues[2], previousValues[3], pa)
                else
                    onCancel(r, g, b, a)
                end
            end
            ColorPickerFrame:SetColorRGB(r, g, b)
            ColorPickerFrame:Hide()
            ColorPickerFrame:Show()
        end

        -- Helper: build one color-picker row
        local function MakeColorRow(anchorY, labelText, hasAlpha, getColor, setColor)
            local lbl = panel:CreateFontString(nil, "ARTWORK", "GameFontHighlight")
            lbl:SetPoint("TOPLEFT", 16, anchorY)
            lbl:SetWidth(130); lbl:SetJustifyH("LEFT")
            TrackThemeText(lbl)
            lbl:SetText(labelText)

            local hint = panel:CreateFontString(nil, "ARTWORK", "GameFontHighlightSmall")
            hint:SetPoint("LEFT", lbl, "RIGHT", 4, 0)
            TrackThemeText(hint)
            hint:SetText(hasAlpha and "(color + opacity)" or "(color)")

            -- Outer swatch frame with border
            local swatchFrame = CreateFrame("Frame", nil, panel)
            swatchFrame:SetSize(44, 22)
            swatchFrame:SetPoint("TOPLEFT", 16, anchorY - 22)

            local swBorder = swatchFrame:CreateTexture(nil, "BACKGROUND")
            swBorder:SetAllPoints(); swBorder:SetColorTexture(0.6, 0.6, 0.6, 1)

            local swInner = swatchFrame:CreateTexture(nil, "ARTWORK")
            swInner:SetPoint("TOPLEFT", 1, -1); swInner:SetPoint("BOTTOMRIGHT", -1, 1)

            local function UpdateSwatch()
                local r, g, b = getColor()
                swInner:SetColorTexture(r, g, b, 1)  -- always full alpha so you can see the color
            end
            table.insert(swatchUpdaters, UpdateSwatch)

            local clickBtn = CreateFrame("Button", nil, panel)
            clickBtn:SetAllPoints(swatchFrame)
            clickBtn:SetScript("OnEnter", function() swBorder:SetColorTexture(1,1,1,1) end)
            clickBtn:SetScript("OnLeave", function() swBorder:SetColorTexture(0.6,0.6,0.6,1) end)
            clickBtn:SetScript("OnClick", function()
                if not DB or not DB.theme then return end
                local r, g, b, a = getColor()
                OpenPicker(r, g, b, a, hasAlpha,
                    function(nr, ng, nb, na)
                        setColor(nr, ng, nb, na)
                        if DB and DB.skinMode == "custom" then DB.customTheme = CopyTheme(DB.theme) end
                        PersistAppearance()
                        UpdateSwatch()
                        ApplyTheme()
                    end,
                    function(pr, pg, pb, pa)
                        setColor(pr, pg, pb, pa)
                        if DB and DB.skinMode == "custom" then DB.customTheme = CopyTheme(DB.theme) end
                        PersistAppearance()
                        UpdateSwatch()
                        ApplyTheme()
                    end)
            end)
            clickBtn:SetScript("OnEnter", function()
                swBorder:SetColorTexture(1,1,1,1)
                GameTooltip:SetOwner(clickBtn, "ANCHOR_RIGHT")
                GameTooltip:SetText("Click to choose color" .. (hasAlpha and "\nIncludes opacity slider" or ""))
                GameTooltip:Show()
            end)
            clickBtn:SetScript("OnLeave", function()
                swBorder:SetColorTexture(0.6,0.6,0.6,1)
                GameTooltip:Hide()
            end)

            table.insert(customControls, clickBtn)
            table.insert(customControls, swatchFrame)
            table.insert(customControls, lbl)
            table.insert(customControls, hint)

            UpdateSwatch()
        end

        MakeColorRow(-162, "Background:", true,
            function()
                local t = DB and DB.theme
                return (t and t.bgR or 0.025),(t and t.bgG or 0.033),(t and t.bgB or 0.043),(t and t.bgA or 0.92)
            end,
            function(r,g,b,a)
                if not DB or not DB.theme then return end
                DB.theme.bgR=r; DB.theme.bgG=g; DB.theme.bgB=b; DB.theme.bgA=a
            end)

        MakeColorRow(-212, "Border:", false,
            function()
                local t = DB and DB.theme
                return (t and t.borderR or 0.22),(t and t.borderG or 0.31),(t and t.borderB or 0.40),1
            end,
            function(r,g,b,a)
                if not DB or not DB.theme then return end
                DB.theme.borderR=r; DB.theme.borderG=g; DB.theme.borderB=b
            end)

        MakeColorRow(-262, "Accent / Text:", false,
            function()
                local t = DB and DB.theme
                return (t and t.accentR or 0.88),(t and t.accentG or 0.92),(t and t.accentB or 0.96),1
            end,
            function(r,g,b,a)
                if not DB or not DB.theme then return end
                DB.theme.accentR=r; DB.theme.accentG=g; DB.theme.accentB=b
            end)

        MakeColorRow(-312, "Header:", true,
            function()
                local t = DB and DB.theme
                return (t and t.headerR or 0.045),(t and t.headerG or 0.06),(t and t.headerB or 0.078),(t and t.headerA or 0.84)
            end,
            function(r,g,b,a)
                if not DB or not DB.theme then return end
                DB.theme.headerR=r; DB.theme.headerG=g; DB.theme.headerB=b; DB.theme.headerA=a
            end)

        MakeColorRow(-362, "Footer:", true,
            function()
                local t = DB and DB.theme
                return (t and t.footerR or 0.045),(t and t.footerG or 0.06),(t and t.footerB or 0.078),(t and t.footerA or 0.84)
            end,
            function(r,g,b,a)
                if not DB or not DB.theme then return end
                DB.theme.footerR=r; DB.theme.footerG=g; DB.theme.footerB=b; DB.theme.footerA=a
            end)

        -- Reset custom colors button
        local resetBtn = CreateFrame("Button", nil, panel, "UIPanelButtonTemplate")
        resetBtn:SetSize(130, 26)
        resetBtn:SetPoint("TOPLEFT", 16, -418)
        resetBtn:SetText("Reset Custom Colors")
        resetBtn:SetScript("OnClick", function()
            if not DB then return end
            DB.skinMode = "custom"
            DB.customTheme = CopyTheme(DEFAULT_THEME)
            DB.theme = CopyTheme(DB.customTheme)
            ApplyTheme()
            PersistAppearance()
            for _, fn in ipairs(swatchUpdaters) do fn() end
            RefreshSkinControls()
        end)
        table.insert(customControls, resetBtn)

        -- Manual profile management removed. Per-character settings auto-save.
        panel:SetScript("OnShow", function()
            for _, fn in ipairs(swatchUpdaters) do fn() end
            RefreshSkinControls()
        end)

        if Settings and Settings.RegisterCanvasLayoutCategory then
            local cat = Settings.RegisterCanvasLayoutCategory(panel, "Grind Dont Stop", "Grind Dont Stop")
            Settings.RegisterAddOnCategory(cat)
        elseif InterfaceOptions_AddCategory then
            InterfaceOptions_AddCategory(panel)
        end
    end)
end


-------------------------------------------------------------------------------
-- v6.5.11: WoW-native Escape close behavior
-------------------------------------------------------------------------------
-- The game already checks UISpecialFrames when Escape is pressed. Registering
-- these named, closeable windows lets Blizzard consume that Escape press and
-- only display the game menu when no special window remains. No key capture,
-- global keyboard hooks, or protected ToggleGameMenu overrides are needed.
-- Names are safe to register before the lazily-created frames exist: the game's
-- lookup simply skips windows that have not been constructed or are hidden.
-- Deliberately exclude always-on minis, the dungeon overlay, and combat alerts:
-- they are HUD displays, not dismissible dialogs, and their visibility is
-- controlled separately by the user's options.
function GDS_RegisterEscapeWindows()
    if type(UISpecialFrames) == "table" then
        for _, name in ipairs({
            "GTMainFrame",
            "GTLootFrame",
            "GTHistoryFrame",
            "GTSessionNoteFrame",
            "GTSettingsFrame",
            "GTSettingsOptionsPanel",
            "GTPartyStatsFrame",
            "GTSkinsFrame",
            "GTGphGraphFrame",
            "GTPastAnalyticsFrame",
            "GTSessionComparisonFrame",
            "GTComparisonGraphsFrame",
            "GDSLifetimeKBBoard",
            "GDSDungeonExportWindow",
            "GDSPartySessionInvitation",
        }) do
            local registered = false
            for i = 1, #UISpecialFrames do
                if UISpecialFrames[i] == name then
                    registered = true
                    break
                end
            end
            if not registered then
                UISpecialFrames[#UISpecialFrames + 1] = name
            end
        end
    end
end
GDS_RegisterEscapeWindows()

-- Experimental analytics use their own SavedVariables namespace and never
-- feed the manual or legacy login ledgers.
do
(function()
    local log = GDS_LoginLog
    local key, state, active, frame
    local world, reload, clock, zone, afk, xp, xpMax, level, money, honor
    local dialog, turnedIn, seenLines, deCast, deLoot
    local diagnostic, recent, recentAt = {}, {}, {}
    local allCharacters, detailTab, detailSearch, detailSort, combined, detailPage = false, "Summary", "", 1, false, 1
    local detailTabs = {"Summary", "Loot", "Quests", "Reputation", "Currency", "Disenchant", "Zones", "Review"}
    local zoneFilter, qualityFilter, sourceFilter, classFilter, characterFilter = "", nil, "", "", ""
    local perPage = 8
    local ascending = false
    local primary = {"Overview","Login Sessions","Breakdown","Quest History","Settings"}
    local statuses = {active="Recording",left="Completed",interrupted="Interrupted",disabled="Partial · recording turned off"}
    local groups = {"Currency","Loot","Experience","Quests","Reputation","Disenchant","Zones"}
    local group = "Currency"
    local viewPages = {}
    local editing = false
    local preferenceLoaded = false
    local cashWindow, evidenceWindow, cashTimer, pendingItems
    local pendingCount = 0
    local buyback, resumePrices
    local options = {
        {"enabled", "Enable automatic recording"}, {"login", "Record login sessions"},
        {"quest", "Quest completions and reward candidates"}, {"vendor", "Quest reward vendor estimates"},
        {"forecast", "Expected disenchant estimates"}, {"results", "Disenchant result candidates"},
        {"gold", "Gold transaction details"}, {"activity", "Zone, dungeon and AFK time"},
    }
    local modes = {"Vendor", "Disenchant", "Auction", "Highest", "Manual"}
    local ranges = {"Today", "Yesterday", "Last 7 days", "Last 30 days", "All time", "This week", "Last week", "This month"}
    local categories = {"Uncategorized", "Loot", "Quest", "Vendor", "Auction", "Repair", "Flight", "Training", "Transfer", "Other", "Vendor sale", "Vendor purchase", "Auction sale", "Auction purchase"}
    local changeSetting
    local tab, range, page, selected, transaction, search, sort = "Overview", 5, 1, nil, 1, "", 1

    local function number(value)
        if issecretvalue and issecretvalue(value) then return end
        if type(value) == "number" and value == value and math.abs(value) < math.huge then return value end
    end

    local function enabled(option)
        return state and state.settings.enabled == true and state.settings[option] == true
    end

    local function observed(label, status)
        status = status or "Working"
        local now = GetTime()
        if diagnostic[label] == status and now - (recentAt[label] or -100) < .5 then return end
        diagnostic[label], recentAt[label] = status, now
        recent[#recent+1] = date("%I:%M:%S %p") .. "  " .. label .. "  " .. diagnostic[label]
        if #recent > 24 then table.remove(recent, 1) end
    end

    local function record(entry)
        if not active then return end
        active.details = active.details or {}
        active.sequence = (active.sequence or #active.details) + 1
        entry.eventID, entry.at, entry.zone = active.sequence, time(), zone
        table.insert(active.details, entry)
        return entry
    end

    local function safeRow(row)
        for _, field in ipairs({"seconds","income","spent","xp","quests","loot","afk","reputation","last","hk","kb","deaths",
            "disenchant","questCopper","questVendor","firstMoney","lastMoney"}) do
            if row[field] ~= nil and not number(row[field]) then return false end
        end
        for _, field in ipairs({"name","notes","character"}) do
            if row[field] ~= nil and type(row[field]) ~= "string" then return false end
        end
        for _, field in ipairs({"zones","details","archivedCash","zoneXP","zoneAFK"}) do
            if row[field] ~= nil and type(row[field]) ~= "table" then return false end
        end
        return true
    end
    local function normalize(row)
        for _, field in ipairs({"seconds","income","spent","xp","deaths","hk","quests","questCopper",
            "loot","disenchant","estimated","afk","levels","kb","reputation","questVendor"}) do
            if number(row[field]) == nil then row[field] = 0 end
        end
        if type(row.zones) ~= "table" then row.zones = {} end
    end

    local function safeText(value)
        if (not issecretvalue or not issecretvalue(value)) and type(value) == "string" and value ~= "" then return value end
    end

    function log.ExperimentalGrind(entry)
        if active then record({kind="grind", name=safeText(entry.sessionName) or entry.zone, duration=entry.duration, grindDate=entry.date}) end
    end

    local function sampleClock()
        if not active then return end
        local now = GetTime()
        local seconds = math.max(0, now - clock)
        clock = now
        active.seconds = active.seconds + seconds
        active.last = time()
        if enabled("activity") then
            if zone then active.zones[zone] = (active.zones[zone] or 0) + seconds end
            if afk then
                active.afk = active.afk + seconds
                if zone then
                    active.zoneAFK = active.zoneAFK or {}
                    active.zoneAFK[zone] = (active.zoneAFK[zone] or 0) + seconds
                end
            end
        end
        if not world or not enabled("activity") then return end
        local place, instance = GetInstanceInfo()
        local location = safeText(place)
        local wing = instance == "party" and location and GDS_Dungeon.DetectWing(location)
        local nextZone = instance == "party" and location and ("Dungeon: " .. location .. (wing and (" — " .. wing) or ""))
            or safeText(GetRealZoneText())
        if nextZone and zone ~= nextZone then
            zone = nextZone
            active.zones[zone] = active.zones[zone] or 0
            observed(instance == "party" and "Dungeon location" or "Zone location")
        end
        local isAFK = UnitIsAFK("player")
        afk = (not issecretvalue or not issecretvalue(isAFK)) and isAFK and true or false
    end

    local function matchCash(now, force)
        for _, cash in ipairs(cashWindow) do
            local matched, count = nil, 0
            for _, evidence in ipairs(evidenceWindow) do
                if evidence.amount == cash.entry.amount and math.abs(evidence.at-cash.at) <= .6 then
                    matched, count = evidence, count+1
                end
            end
            if count == 1 and (force or now - math.max(cash.at, matched.at) >= .6)
                and not matched.used and not cash.entry.category then
                local alternatives = 0
                for _, other in ipairs(cashWindow) do
                    if other.entry.amount == matched.amount and math.abs(other.at-matched.at) <= .6 then
                        alternatives = alternatives+1
                    end
                end
                if alternatives == 1 then
                    cash.entry.category, matched.used = matched.category, true
                    if matched.item then
                        cash.entry.item = matched.item
                        observed("Vendor sale evidence")
                    end
                    observed("Currency attribution")
                end
            end
        end
    end

    local function reconcileCash()
        local row = active
        if cashTimer or not row or not C_Timer or not C_Timer.After then return end
        local token = {}
        cashTimer = token
        C_Timer.After(1, function()
            if cashTimer ~= token then return end
            cashTimer = nil
            if active ~= row then return end
            local now = GetTime()
            matchCash(now)
            for i = #cashWindow, 1, -1 do
                if now-cashWindow[i].at >= 1.2 then table.remove(cashWindow,i) end
            end
            for i = #evidenceWindow, 1, -1 do
                if now-evidenceWindow[i].at >= 1.2 then table.remove(evidenceWindow,i) end
            end
            if #cashWindow > 0 or #evidenceWindow > 0 then reconcileCash() end
        end)
    end

    local function hint(amount, category, item)
        if not enabled("gold") or not amount or amount == 0 or IgnoreMailboxLoot()
            or GDS_Trade.IgnoreIncoming() then return end
        if #evidenceWindow >= 64 then return end
        table.insert(evidenceWindow, {amount=amount, category=category, item=item, at=GetTime()})
        reconcileCash()
    end

    local function scanBuyback()
        if not enabled("gold") or not GetNumBuybackItems or not GetBuybackItemInfo or not GetBuybackItemLink then return end
        local count = number(GetNumBuybackItems())
        if not count or count < 0 or count > 24 then return end
        local snapshot = {}
        for index = 1, count do
            local link = safeText(GetBuybackItemLink(index))
            local name, _, price, qty = GetBuybackItemInfo(index)
            price, qty = number(price), number(qty)
            if not link or not price or not qty then return end
            local signature = link .. ":" .. price .. ":" .. qty
            local item = snapshot[signature]
            if item then item.count = item.count + 1
            else snapshot[signature] = {name=safeText(name), link=link, price=price, qty=qty, count=1} end
        end
        local prior = buyback
        buyback = snapshot
        if not prior then return end
        local added, additions = nil, 0
        for signature, item in pairs(snapshot) do
            local increase = item.count - (prior[signature] and prior[signature].count or 0)
            if increase > 0 then added, additions = item, additions + increase end
        end
        if additions == 1 then
            hint(added.price, "Vendor sale", {name=added.name, link=added.link, qty=added.qty})
        end
    end

    function log.ExperimentalRepair(copper)
        if active and world then hint(-copper, "Repair") end
    end

    local function sampleMoney()
        if not active or not world then return end
        local balance = number(GetMoney())
        if not balance or balance < 0 then return end
        active.firstMoney = active.firstMoney or balance
        active.lastMoney = balance
        if money then
            local delta = balance - money
            if delta > 0 then active.income = active.income + delta end
            if delta < 0 then active.spent = active.spent - delta end
            if enabled("gold") and delta ~= 0 then
                local entry = record({kind="cash", amount=delta})
                if IgnoreMailboxLoot() then entry.context = "Mail window"
                elseif GDS_Trade.IgnoreIncoming() then entry.context = "Trade window"
                elseif merchantOpen then entry.context = "Merchant window" end
                observed("Currency sampling")
                if #cashWindow < 64 and not IgnoreMailboxLoot() and not GDS_Trade.IgnoreIncoming() then
                    table.insert(cashWindow, {entry=entry, at=GetTime()})
                    reconcileCash()
                end
            end
        end
        money = balance
    end

    local function sampleXP()
        if not active or not world then return end
        local current, cap, currentLevel = number(UnitXP("player")), number(UnitXPMax("player")), number(UnitLevel("player"))
        if not current or not cap or not currentLevel then return end
        local before = active.xp
        if xp and currentLevel == level and current >= xp then
            active.xp = active.xp + current - xp
            if current > xp then observed("XP sampling") end
        elseif xp and currentLevel == level + 1 and xpMax >= xp then
            active.xp = active.xp + xpMax - xp + current
            active.levels = active.levels + 1
            observed("XP sampling")
        elseif xp and currentLevel == level then
            return -- Wait for XP and level APIs to agree.
        elseif xp then
            observed("XP sampling", "Counter reset")
        end
        if active.xp > before and zone then
            active.zoneXP = active.zoneXP or {}
            active.zoneXP[zone] = (active.zoneXP[zone] or 0) + active.xp - before
        end
        active.startLevel = active.startLevel or currentLevel
        active.endLevel = currentLevel
        xp, xpMax, level = current, cap, currentLevel
    end

    local function walletReset()
        money, xp, xpMax, level, honor = nil, nil, nil, nil, nil
    end

    local function start(resume)
        if active or not world or not enabled("login") then return end
        local previous = state.sessions[1]
        if resume and type(previous) == "table" and safeRow(previous) and (previous.status == "left" or previous.status == "active") then
            active = previous
            observed("Reload continuity")
            active.details = active.details or {}
        else
            local now = time()
            active = {started=now, last=now, seconds=0, income=0, spent=0, xp=0, deaths=0,
                hk=0, quests=0, questCopper=0, loot=0, disenchant=0, estimated=0, afk=0,
                zones={}, details={}, character=key}
            table.insert(state.sessions, 1, active)
        end
        normalize(active)
        local _, class = UnitClass("player")
        active.class = active.class or safeText(class)
        active.status = "active"
        observed("Login sampling")
        clock = GetTime()
        seenLines = {index=0, queue={}}
        cashWindow, evidenceWindow, pendingItems, pendingCount = {}, {}, {}, 0
        walletReset()
        sampleClock()
        sampleMoney()
        sampleXP()
        if resume then resumePrices() end
        honor = GetPVPLifetimeStats and number(GetPVPLifetimeStats())
    end

    local function stop(status)
        if not active then return end
        sampleMoney()
        sampleXP()
        if world then sampleClock() end
        matchCash(GetTime(), true)
        active.status = status
        observed("Logout checkpoint")
        cashTimer = nil
        cashWindow, evidenceWindow, pendingItems = nil, nil, nil
        active = nil
        dialog, turnedIn, deCast, deLoot, seenLines = nil, nil, nil, nil, nil
        buyback = nil
        walletReset()
    end

    local function questSnapshot()
        local function read(kind, count)
            local items = {}
            if not GetQuestItemLink or not GetQuestItemInfo then return items end
            for index = 1, math.min(40, number(count) or 0) do
                local link = GetQuestItemLink(kind, index)
                local id = safeText(link) and tonumber(link:match("item:(%d+)"))
                local name, _, qty, _, _, itemID = GetQuestItemInfo(kind, index)
                id = id or number(itemID)
                qty = number(qty)
                if id and qty and qty > 0 then
                    if items[id] then items[id].ambiguous = true
                    else items[id] = {name=safeText(name), qty=qty} end
                end
            end
            return items
        end
        if not GetQuestID then return end
        local id = number(GetQuestID())
        if not id or id <= 0 then return end
        dialog = {id=id, name=GetTitleText and GetTitleText(),
            guaranteed=read("reward", GetNumQuestRewards and GetNumQuestRewards() or 0),
            choice=read("choice", GetNumQuestChoices and GetNumQuestChoices() or 0),
            receipts={}, at=GetTime()}
    end

    local function price(entry)
        local name, link, quality, _, _, category, _, _, _, icon, vendor, class, _, bind = GDS_ItemCompat.GetInfo(entry.id)
        if not safeText(name) then return end
        entry.name, entry.link = name, entry.link or safeText(link)
        entry.quality, entry.itemCategory, entry.icon = number(quality), safeText(category), number(icon)
        entry.vendor = number(vendor)
        if entry.kind == "reward" and entry.sourceKind == "Quest" then
            entry.estimate = entry.vendor and entry.vendor > 0 and entry.vendor * entry.qty or nil
            entry.method = entry.estimate and "Vendor" or nil
            entry.pending = nil
            if entry.estimate and entry.vendorEnabled and class ~= 12 and entry.status == "Matched reward" then
                entry.autoVendor = entry.estimate
                active.questVendor = active.questVendor + entry.autoVendor
            end
            return true
        end
        local mode = entry.mode
        if entry.forecast and (class == 2 or class == 4) and (bind == 0 or bind == 1 or bind == 2 or bind == 3) then
            local ok, value = pcall(GDS_ItemCompat.ForeverDE, entry.id, "item:" .. entry.id)
            if ok then entry.de = number(value) end
        end
        -- BindType 2 is Bind on Equip. Even then a cache quote is informational.
        if bind == 0 or bind == 2 then
            local value, source, stamp = GDS_ItemCompat.MarketQuote(entry.id)
            if number(value) then observed("Pricing quote") end
            entry.auction, entry.source, entry.quoteTime = number(value),
                type(source) == "string" and source or nil, number(stamp)
        end
        local selectedValue = entry.vendorEnabled and entry.vendor or nil
        local method = selectedValue and "Vendor" or nil
        if mode == "Disenchant" or mode == "Highest" then
            if entry.de and (mode == "Disenchant" or not selectedValue or entry.de > selectedValue) then
                selectedValue, method = entry.de, "Disenchant"
            end
        end
        if mode == "Auction" or mode == "Highest" then
            if entry.auction and (mode == "Auction" or not selectedValue or entry.auction > selectedValue) then
                selectedValue, method = entry.auction, "Auction Companion cache"
            end
        end
        if mode == "Manual" then selectedValue, method = nil, nil end
        entry.estimate = selectedValue and math.floor(selectedValue * entry.qty + .5) or nil
        entry.method = method
        entry.pending = nil
        return true
    end

    local function estimate(entry)
        if not entry.at then record(entry) end
        local ok, ready = pcall(price,entry)
        if not ok then observed("Item pricing","Error"); ready = nil end
        if not ready and entry.pending and pendingCount < 512 then
            local waiting = pendingItems[entry.id] or {}
            pendingItems[entry.id] = waiting
            pendingCount = pendingCount + 1
            table.insert(waiting,entry)
        end
    end

    resumePrices = function()
        local details = active.details
        for i = math.max(1,#details-127), #details do
            local entry = details[i]
            if type(entry)=="table" and entry.pending and number(entry.id) and (entry.kind == "reward" or entry.kind == "loot" and entry.status ~= "Review") then
                if entry.kind == "reward" then entry.vendorEnabled = entry.vendorEnabled and enabled("vendor") end
                estimate(entry)
            end
        end
    end

    local function candidate(snapshot, id, qty)
        local guaranteed, choice = snapshot.guaranteed[id], snapshot.choice[id]
        local award = guaranteed or choice
        if not award or award.used or award.ambiguous or (guaranteed and choice)
            or qty ~= award.qty or (not guaranteed and snapshot.choiceUsed) then return end
        return award
    end

    local function grindAtReceipt()
        if S and S.running and not S.paused and DB and DB.questTracking then return S, S.timer end
    end

    local function addGrindReward(entry, owner, receivedAt)
        if not owner or owner ~= S or not owner.running or not DB.questTracking then return end
        local name, link, quality, _, _, _, _, _, _, _, vendor = GDS_ItemCompat.GetInfo(entry.id)
        vendor = number(vendor)
        local unit = math.max(0,vendor or 0)
        local row = {questReceipt=entry.quest, time=receivedAt or owner.timer, itemID=entry.id, qty=entry.qty,
            name=safeText(name) or entry.name or ("Item:"..entry.id), link=safeText(link) or entry.link,
            quality=number(quality) or entry.quality, vendorPrice=vendor, unitPrice=unit,
            total=unit*entry.qty, receiptZone=entry.zone, source="quest"}
        table.insert(owner.loot,row)
        GDS_QuestItems.Credit(row.total)
        if not vendor then GDS_ItemCompat.Queue(entry.id,entry.qty,row,owner,nil,0) end
        if RefreshStats then RefreshStats() end
        if RefreshLootLog then RefreshLootLog() end
    end

    local function reward(snapshot, entry, owner, receivedAt)
        local award = candidate(snapshot, entry.id, entry.qty)
        if not award then return false end
        award.used = true
        if not snapshot.guaranteed[entry.id] then snapshot.choiceUsed = true end
        entry.kind, entry.quest, entry.questEvent = "reward", snapshot.id, snapshot.eventID
        entry.sourceKind, entry.status = "Quest", "Matched reward"
        entry.pending, entry.forecast, entry.vendorEnabled = true, false, enabled("vendor")
        estimate(entry)
        local ok = pcall(addGrindReward,entry,owner,receivedAt)
        if not ok then observed("Grind reward posting","Error") end
        observed("Quest reward matching")
        return true
    end

    local function captureReceipt(msg, lineID, guid)
        if not active or not world or not GDS_ItemCompat.LootKind(msg, guid, IsOwnLoot)
            or IsCraftedLoot(msg) then return end
        lineID = number(lineID)
        if lineID and lineID > 0 then
            if seenLines[lineID] then
                log.experimentalQuestReceipt = seenLines[lineID] == "quest"
                observed("Loot-line deduplication")
                return
            end
            local index = seenLines.index % 256 + 1
            local previous = seenLines.queue[index]
            if previous then seenLines[previous] = nil end
            seenLines.index, seenLines.queue[index], seenLines[lineID] = index, lineID, true
        end
        local id = tonumber(msg:match("|Hitem:(%d+)"))
        if not id then return end
        local name = msg:match("|Hitem:%d+[^|]*|h%[([^|%]]+)")
        local qty = tonumber(msg:match("|h%|r%s*x(%d+)") or msg:match("|h%s*x(%d+)")) or 1
        local link = msg:match("(|c%x%x%x%x%x%x%x%x|Hitem:[^|]+|h%[[^|]+%]|h|r)")
            or msg:match("(|Hitem:[^|]+|h%[[^|]+%]|h)")
        local entry = {kind="loot", id=id, name=name, qty=qty, link=link, pending=true,
            quality=tonumber(msg:match("|cnIQ(%d+):")), vendorEnabled=true,
            mode=modes[state.settings.mode or 1] or modes[1], forecast=enabled("forecast")}
        if IgnoreMailboxLoot() then entry.sourceKind = "Mail receipt"
        elseif GDS_Trade.IgnoreIncoming() then entry.sourceKind = "Trade receipt"
        elseif IgnoreProfessionLoot() then entry.sourceKind = "Profession context"
        elseif merchantOpen then entry.sourceKind = "Merchant receipt" end
        local now = GetTime()
        if not entry.sourceKind and enabled("results") and deLoot and now <= deLoot.untilTime
            and (deLoot.items[id] or 0) >= qty then
            deLoot.items[id] = deLoot.items[id] - qty
            if not deLoot.entry then
                active.disenchant = active.disenchant + 1
                deLoot.entry = record({kind="de", status="Unmatched source", materials={}})
            end
            local materials = deLoot.entry.materials
            local material = materials[id]
            if not material then
                local value, source, stamp = GDS_ItemCompat.MarketQuote(id)
                material = {id=id, name=name, qty=0, unit=number(value),
                    source=type(source) == "string" and source or nil, quoteTime=number(stamp)}
                materials[id] = material
            end
            material.qty = material.qty + qty
            observed("Disenchant receipts")
            return
        end
        if not entry.sourceKind then active.loot = active.loot + qty end
        local pushed = false
        for _, template in pairs({LOOT_ITEM_PUSHED_SELF, LOOT_ITEM_PUSHED_SELF_MULTIPLE}) do
            local prefix = type(template) == "string" and template:match("^(.-)%%")
            if prefix and prefix ~= "" and msg:sub(1,#prefix) == prefix then pushed = true; break end
        end
        if not pushed then pushed = msg:match("^You receive item%s*:") ~= nil end
        if pushed and not entry.sourceKind and not merchantOpen and enabled("quest") then
            local owner, receivedAt = grindAtReceipt()
            if turnedIn and now - turnedIn.completed <= 2 and reward(turnedIn, entry, owner, receivedAt) then
                log.experimentalQuestReceipt = true
            elseif dialog and now - dialog.at <= 60 and candidate(dialog, id, qty) then
                entry.sourceKind, entry.status = "Pushed receipt", "Review"
                record(entry)
                local prior = dialog.receipts[id]
                if prior then prior.ambiguous = true else dialog.receipts[id] = {at=now, entry=entry, owner=owner, receivedAt=receivedAt} end
                log.experimentalQuestReceipt = true
            end
        end
        if log.experimentalQuestReceipt and lineID and lineID > 0 then seenLines[lineID] = "quest" end
        if entry.kind == "loot" and not entry.at then
            entry.sourceKind = entry.sourceKind or (pushed and "Pushed receipt" or "Loot")
            estimate(entry)
        end
        observed("Loot receipts")
    end

    local function captureDELoot()
        if not deCast or not deCast.succeeded or deLoot or GetTime() > deCast.untilTime
            or not GetLootSourceInfo or not GetLootSlotLink or not GetNumLootItems or not GetLootSlotInfo then return end
        local items, lootSource = {}, nil
        local count = number(GetNumLootItems()) or 0
        for slot = 1, count do
            local source = GetLootSourceInfo(slot)
            -- Only item-sourced loot is a candidate. Creature and unknown
            -- sources never enter the conversion ledger.
            if (issecretvalue and issecretvalue(source)) or type(source) ~= "string"
                or not source:match("^Item%-") or (lootSource and source ~= lootSource) then return end
            lootSource = source
            local link = GetLootSlotLink(slot)
            local id = safeText(link) and tonumber(link:match("item:(%d+)"))
            local qty = number(select(3, GetLootSlotInfo(slot)))
            if not id or not GDS_ItemCompat.IsDEMaterial(id) or not qty or qty < 1 then return end
            items[id] = (items[id] or 0) + qty
        end
        if next(items) then deLoot = {items=items, untilTime=GetTime()+5} end
    end

    local function onEvent(event, ...)
        if event == "PLAYER_ENTERING_WORLD" then
            local _, isReload = ...
            world = true
            reload = not key and isReload == true or reload
            if active then
                clock = GetTime()
                sampleClock()
                sampleMoney()
                sampleXP()
                honor = GetPVPLifetimeStats and number(GetPVPLifetimeStats())
            else
                start(reload or isReload == true)
            end
            if key then reload = nil end
        elseif event == "PLAYER_LEAVING_WORLD" then
            if active and world then sampleMoney(); sampleXP(); sampleClock() end
            world, zone, afk = false, nil, nil
            dialog, turnedIn, deCast, deLoot = nil, nil, nil, nil
        elseif event == "PLAYER_LOGOUT" then
            stop("left")
        elseif not active or not world then
            return
        elseif event == "MERCHANT_SHOW" then
            buyback = nil
            scanBuyback()
        elseif event == "MERCHANT_UPDATE" then
            if buyback then scanBuyback() end
        elseif event == "MERCHANT_CLOSED" then
            buyback = nil
        elseif event == "PLAYER_MONEY" then
            sampleMoney()
        elseif event == "PLAYER_XP_UPDATE" or event == "PLAYER_LEVEL_UP" then
            sampleXP()
            if event == "PLAYER_LEVEL_UP" and C_Timer then
                local row = active
                C_Timer.After(.1, function() if active == row then sampleXP() end end)
            end
        elseif event == "QUEST_FINISHED" then
            -- A closed quest frame can precede delayed receipts or turn-in.
            if dialog then dialog.at = math.min(dialog.at, GetTime() - 58) end
        elseif event == "CHAT_MSG_COMBAT_FACTION_CHANGE" then
            local msg = safeText((...))
            if not msg then return end
            local faction, amount = msg:match("^Reputation with (.-) increased by ([%d,]+)%.?$")
            local sign = 1
            if not faction then
                faction, amount = msg:match("^Reputation with (.-) decreased by ([%d,]+)%.?$")
                sign = -1
            end
            if not faction then observed("Reputation receipts", "Unparsed message"); return end
            local value = number(tonumber((amount:gsub(",", ""))))
            if not value then return end
            local delta = value * sign
            active.reputation = active.reputation + delta
            record({kind="rep", name=faction, amount=delta})
            observed("Reputation receipts")
        elseif event == "PARTY_KILL" then
            local attacker, victim = ...
            attacker, victim = safeText(attacker), safeText(victim)
            if attacker and victim and victim:match("^Player%-")
                and attacker == safeText(UnitGUID("player")) then active.kb = active.kb + 1 end
        elseif event == "PLAYER_DEAD" then
            active.deaths = active.deaths + 1
        elseif event == "PLAYER_PVP_KILLS_CHANGED" then
            local count = GetPVPLifetimeStats and number(GetPVPLifetimeStats())
            if count and honor and count > honor then active.hk = active.hk + count - honor end
            honor = count
        elseif event == "ZONE_CHANGED" or event == "ZONE_CHANGED_NEW_AREA" or event == "ZONE_CHANGED_INDOORS"
            or event == "PLAYER_FLAGS_CHANGED" then
            sampleMoney()
            sampleXP()
            sampleClock()
        elseif event == "QUEST_COMPLETE" and enabled("quest") then
            questSnapshot()
        elseif event == "QUEST_TURNED_IN" then
            local id, questXP, copper = ...
            id, questXP, copper = number(id), number(questXP), number(copper)
            if not id or id <= 0 then return end
            hint(copper, "Quest")
            if not enabled("quest") then return end
            local snapshot = dialog and dialog.id == id and dialog or nil
            dialog, turnedIn = nil, snapshot
            local name = snapshot and snapshot.name
            if not name and C_QuestLog and C_QuestLog.GetTitleForQuestID then name = C_QuestLog.GetTitleForQuestID(id) end
            active.quests, active.questCopper = active.quests + 1, active.questCopper + (copper or 0)
            local quest = record({kind="quest", id=id, name=safeText(name), xp=questXP, copper=copper})
            observed("Quest completions")
            if snapshot then
                snapshot.completed, snapshot.eventID = GetTime(), quest.eventID
                for _, receipt in pairs(snapshot.receipts) do
                    if not receipt.ambiguous and snapshot.completed - receipt.at <= 2 then reward(snapshot, receipt.entry, receipt.owner, receipt.receivedAt) end
                end
            end
        elseif event == "CHAT_MSG_MONEY" then
            local msg = ...
            if enabled("gold") and GDS_Coin.IsOwnLootMessage(msg) then hint(GDS_Coin.ParseLootAmount(msg), "Loot") end
        elseif event == "CHAT_MSG_LOOT" then
            captureReceipt((...), select(11, ...), select(12, ...))
        elseif event == "GET_ITEM_INFO_RECEIVED" then
            local id, success = ...
            id = number(id)
            local waiting = id and pendingItems[id]
            if waiting then
                pendingItems[id] = nil
                pendingCount = pendingCount - #waiting
                for _, entry in ipairs(waiting) do
                    if success and entry.pending then
                        entry.forecast = entry.forecast and enabled("forecast")
                        if entry.kind == "reward" then entry.vendorEnabled = entry.vendorEnabled and enabled("vendor") end
                        local ok = pcall(price,entry)
                        if not ok then observed("Item pricing","Error") end
                    end
                end
            end
        elseif enabled("results") then
            if event == "LOOT_READY" or event == "LOOT_OPENED" then captureDELoot()
            elseif event == "LOOT_CLOSED" then
                deCast = nil
                if deLoot then deLoot.untilTime = math.min(deLoot.untilTime, GetTime() + 1) end
            elseif event:find("^UNIT_SPELLCAST_") then
                local unit, guid, spell = ...
                unit, guid = safeText(unit), safeText(guid)
                if unit ~= "player" or number(spell) ~= 13262 then return end
                if event == "UNIT_SPELLCAST_START" then deCast, deLoot = {guid=guid}, nil
                elseif event == "UNIT_SPELLCAST_SUCCEEDED" then
                    deCast, deLoot = {guid=guid, succeeded=true, untilTime=GetTime()+5}, nil
                elseif deCast and deCast.guid == guid then deCast, deLoot = nil, nil end
            end
        end
    end

    local function refreshEvents()
        for _, event in ipairs({"QUEST_COMPLETE", "QUEST_FINISHED", "CHAT_MSG_COMBAT_FACTION_CHANGE"}) do
            local needed = enabled("login") and (event == "CHAT_MSG_COMBAT_FACTION_CHANGE" or enabled("quest"))
            if needed then
                if not pcall(bus.RegisterEvent, bus, event) then diagnostic[event] = "Unavailable" end
            else bus:UnregisterEvent(event) end
        end
        if enabled("login") and enabled("activity") then pcall(bus.RegisterEvent, bus, "PLAYER_FLAGS_CHANGED")
        else bus:UnregisterEvent("PLAYER_FLAGS_CHANGED") end
    end

    function log.ExperimentalInit(characterKey)
        key = characterKey
        local root = GrindTrackerDB
        local namespace = root.experimentalAnalytics
        if namespace == nil then return end -- Allocate only when settings are changed.
        if type(namespace) ~= "table" or namespace.schema ~= 1 or type(namespace.characters) ~= "table" then return end
        local candidate = namespace.characters[key]
        if type(candidate) == "table" and type(candidate.settings) == "table" and type(candidate.sessions) == "table" then
            state = candidate
            local previous = state.sessions[1]
            if type(previous) == "table" and previous.status == "active" and not reload then previous.status = "interrupted" end
            state.revision = 2
            if not candidate.defaultsApplied then
                -- Alpha.8 required enabling each collector independently.
                -- Preserve explicit false choices and default omitted collectors on.
                for _, option in ipairs(options) do
                    if option[1] ~= "forecast" and candidate.settings[option[1]] == nil then
                        candidate.settings[option[1]] = option[1] ~= "enabled"
                    end
                end
                candidate.defaultsApplied = true
            end
            refreshEvents()
            start(reload)
        end
        reload = nil
    end

    function log.ExperimentalEvent(event, ...)
        log.experimentalQuestReceipt = nil
        if state or event == "PLAYER_ENTERING_WORLD" or event == "PLAYER_LEAVING_WORLD" then
            local ok, err = pcall(onEvent, event, ...)
            if not ok then diagnostic[event] = "Error: " .. tostring(err):sub(1, 180) end
        end
    end

    local function settings()
        if state then return state.settings end
        if not key then return end
        local root = GrindTrackerDB
        if root.experimentalAnalytics == nil then root.experimentalAnalytics = {schema=1, characters={}} end
        local namespace = root.experimentalAnalytics
        if type(namespace) ~= "table" or namespace.schema ~= 1 or type(namespace.characters) ~= "table"
            or namespace.characters[key] ~= nil then return end
        state = {settings={login=true, quest=true, vendor=true, results=true, gold=true, activity=true},
            sessions={}, revision=2, defaultsApplied=true}
        namespace.characters[key] = state
        return state.settings
    end

    local function coin(value)
        value = math.floor(math.abs(value))
        local g, s, c = math.floor(value/10000), math.floor(value/100)%100, value%100
        local suffix = "|TInterface\\MoneyFrame\\UI-%sIcon:11:11:2:0|t"
        return (g > 0 and (g .. suffix:format("Gold") .. " ") or "") ..
            (s > 0 and (s .. suffix:format("Silver") .. " ") or "") .. c .. suffix:format("Copper")
    end

    local function signed(value)
        if value < 0 then return "|cffff8585−" .. coin(value) .. "|r" end
        if value > 0 then return "|cff8af6a4+" .. coin(value) .. "|r" end
        return coin(value)
    end

    local function primaryZone(row)
        local name, seconds = "Location not recorded", -1
        for location, elapsed in pairs(type(row.zones) == "table" and row.zones or {}) do
            if type(location) == "string" and number(elapsed) and elapsed > seconds then name, seconds = location, elapsed end
        end
        return name
    end

    local function inRange(row)
        if range == 5 then return true end
        local today = date("*t")
        today.hour, today.min, today.sec = 0, 0, 0
        if range == 1 then return row.started >= time(today) end
        if range == 8 then today.day = 1; return row.started >= time(today) end
        if range == 6 or range == 7 then
            today.day = today.day - (today.wday + 5) % 7
            local monday = time(today)
            if range == 6 then return row.started >= monday end
            today.day = today.day - 7
            return row.started >= time(today) and row.started < monday
        end
        local upper = time(today)
        today.day = today.day - ({[2]=1,[3]=6,[4]=29})[range]
        return row.started >= time(today) and (range ~= 2 or row.started < upper)
    end

    local function valueText(entry)
        if entry.kind == "cash" then
            return signed(entry.amount) .. "   " .. (entry.category or "Unidentified") ..
                (entry.item and ("   " .. (entry.item.name or "Item") .. " x" .. entry.item.qty) or "") ..
                (entry.context and ("   (" .. entry.context .. ")") or "")
        elseif entry.kind == "quest" then
            return (entry.name or "Quest #"..entry.id) .. "  #" .. entry.id .. "   " ..
                CoinShort(entry.copper or 0) .. " reported cash   " .. (entry.xp or 0) .. " XP"
        elseif entry.kind == "rep" then
            return entry.name .. "   " .. (entry.amount > 0 and "+" or "") .. entry.amount
        elseif entry.kind == "zone" then
            return entry.name .. "   " .. FormatTime(math.floor(entry.duration)) ..
                "   Net " .. signed(entry.net or 0) .. "   Quests " .. (entry.quests or 0) ..
                "   Item receipts " .. (entry.loot or 0) .. "   Rep " .. (entry.rep or 0)
        elseif entry.kind == "grind" then
            return "Manual grind   " .. (entry.name or entry.grindDate or "Saved session") ..
                "   " .. FormatTime(math.floor(entry.duration or 0))
        elseif entry.kind == "de" then
            local materials = {}
            for id, item in pairs(entry.materials or {}) do
                materials[#materials+1] = (item.name or "#" .. id) .. " x" .. item.qty ..
                    (item.unit and (" (" .. CoinShort(item.unit * item.qty) .. " " .. (item.source or "cached") .. ")") or " (unpriced)")
            end
            table.sort(materials)
            return table.concat(materials, ", ") .. "   Original item unresolved"
        end
        local estimated = entry.estimate or entry.vendor and entry.vendor * entry.qty
        return (entry.name or ("Item #"..entry.id)) .. " x" .. entry.qty ..
            "   " .. (entry.sourceKind or "Receipt") .. (entry.quest and (" #" .. entry.quest) or "") ..
            (entry.vendor and ("   Vendor " .. CoinShort(entry.vendor) .. "/ea") or "") ..
            (entry.auction and ("   AH " .. CoinShort(entry.auction) .. "/ea") or "") ..
            (estimated and ("   Est. " .. CoinShort(estimated)) or "") ..
            (entry.status and ("   " .. entry.status) or "")
    end

    local function stamp(value)
        return value and date("%m/%d/%y %I:%M %p", value) or "—"
    end

    local function rate(amount, seconds, fmt)
        return seconds > 0 and fmt(math.floor(amount * 3600 / seconds)) or "—"
    end

    local function sessions()
        local rows = {}
        local namespace = GrindTrackerDB and GrindTrackerDB.experimentalAnalytics
        if type(namespace) ~= "table" or type(namespace.characters) ~= "table" then return rows end
        for owner, bucket in pairs(namespace.characters) do
            if (allCharacters or owner == key) and type(bucket) == "table" and type(bucket.sessions) == "table" then
                for _, row in ipairs(bucket.sessions) do
                    if type(row) == "table" and number(row.started) and safeRow(row) then rows[#rows+1] = row end
                end
            end
        end
        return rows
    end

    local function contains(text, term)
        return (text or ""):lower():find(term, 1, true) ~= nil
    end

    local function net(row)
        return (row.income or 0) - (row.spent or 0)
    end

    local function sessionRows()
        local rows = {}
        for _, row in ipairs(sessions()) do
            local words = table.concat({row.name or "", row.notes or "", row.character or "", primaryZone(row), stamp(row.started)}, " ")
            local zoneMatch = zoneFilter == ""
            for name in pairs(type(row.zones) == "table" and row.zones or {}) do
                if contains(name, zoneFilter) then zoneMatch = true; break end
            end
            if inRange(row) and zoneMatch and contains(row.character, characterFilter) and contains(words, search) then
                rows[#rows+1] = row
            end
        end
        local fields = {"started","character","seconds","net","xp","quests","loot","reputation"}
        local field = fields[sort]
        table.sort(rows, function(a,b)
            local av, bv
            if field == "net" then av,bv = net(a),net(b)
            elseif field == "character" then av,bv = a.character or "",b.character or ""
            else av,bv = a[field] or 0,b[field] or 0 end
            if av ~= bv then
                if ascending then return av < bv end
                return av > bv
            end
            return a.started > b.started
        end)
        return rows
    end

    local function validEntry(entry)
        if type(entry) ~= "table" then return false end
        if entry.kind == "cash" or entry.kind == "rep" then
            return number(entry.amount) ~= nil and (entry.kind ~= "rep" or type(entry.name)=="string")
                and (entry.category == nil or type(entry.category)=="string")
        end
        if entry.kind == "loot" or entry.kind == "reward" then return number(entry.id) and number(entry.qty) end
        if entry.kind == "quest" then return number(entry.id) end
        if entry.kind == "de" then return type(entry.materials)=="table" end
        return entry.kind == "grind"
    end

    local function detailIterator(row)
        local list = type(row.details)=="table" and row.details or {}
        local index = 0
        return function()
            while index < #list do
                index=index+1
                if validEntry(list[index]) then return index,list[index] end
            end
        end
    end

    local function totals(row)
        local cash, factions, earned, expense = {}, {}, 0, 0
        for category, amount in pairs(row.archivedCash or {}) do cash[category] = amount end
        for _, entry in detailIterator(row) do
            if entry.kind == "cash" then
                local category = entry.category or "Unidentified"
                cash[category] = (cash[category] or 0) + entry.amount
                if (category == "Quest" or category == "Loot" or category == "Vendor sale" or category == "Auction sale")
                    and entry.amount > 0 then earned = earned + entry.amount end
                if (category == "Repair" or category == "Vendor purchase" or category == "Auction purchase")
                    and entry.amount < 0 then expense = expense - entry.amount end
            elseif entry.kind == "rep" then
                factions[entry.name] = (factions[entry.name] or 0) + entry.amount
            end
        end
        return cash, factions, earned, expense
    end

    local function detailRows(row)
        local entries, groups = {}, {}
        local kinds = {Loot="loot", Quests="quest", Reputation="rep", Currency="cash", Disenchant="de"}
        for _, entry in detailIterator(row) do
            local include = entry.kind == kinds[detailTab]
                or detailTab == "Loot" and entry.kind == "reward"
                or detailTab == "Quests" and entry.kind == "reward" and entry.sourceKind == "Quest"
                or detailTab == "Zones" and entry.kind == "grind"
                or detailTab == "Review" and (entry.kind == "cash" and not entry.category
                    or entry.status == "Review" or entry.kind == "de") and not entry.reviewIgnored
            if include and contains(valueText(entry) .. " " .. (entry.zone or ""), detailSearch)
                and (detailTab ~= "Loot" or (not qualityFilter or entry.quality == qualityFilter)
                    and contains(entry.sourceKind, sourceFilter) and contains(entry.itemCategory, classFilter)) then
                if detailTab == "Loot" and combined then
                    local identity = (entry.link or tostring(entry.id)) .. ":" .. (entry.sourceKind or "") .. ":" .. (entry.quest or "")
                    local group = groups[identity]
                    if not group then
                        group = {kind=entry.kind,id=entry.id,name=entry.name,qty=0,link=entry.link,icon=entry.icon,
                            quality=entry.quality, vendor=entry.vendor, sourceKind=entry.sourceKind,quest=entry.quest,aggregate=true}
                        groups[identity] = group
                        entries[#entries+1] = group
                    end
                    group.qty = group.qty + entry.qty
                    if group.vendor ~= entry.vendor then group.vendor = nil end
                else entries[#entries+1] = entry end
            end
        end
        if detailTab == "Zones" then
            local locations = {}
            for name, duration in pairs(row.zones or {}) do
                if contains(name, detailSearch) then
                    local place = {kind="zone",name=name,duration=duration,xp=row.zoneXP and row.zoneXP[name],
                        activeTime=row.zoneAFK and math.max(0,duration-(row.zoneAFK[name] or 0))}
                    entries[#entries+1], locations[name] = place, place
                end
            end
            for _, entry in detailIterator(row) do
                local place = locations[entry.zone]
                if place then
                    if entry.kind == "cash" then place.net = (place.net or 0) + entry.amount
                    elseif entry.kind == "quest" then place.quests = (place.quests or 0) + 1
                    elseif entry.kind == "loot" or entry.kind == "reward" then place.loot = (place.loot or 0) + entry.qty
                    elseif entry.kind == "rep" then place.rep = (place.rep or 0) + entry.amount end
                end
            end
        end
        table.sort(entries, function(a,b)
            if detailSort == 2 then return (a.name or valueText(a)) < (b.name or valueText(b)) end
            if detailSort == 3 then return (a.qty or a.amount or a.duration or 0) > (b.qty or b.amount or b.duration or 0) end
            if (a.at or 0) == (b.at or 0) then return (a.eventID or 0) > (b.eventID or 0) end
            return (a.at or 0) > (b.at or 0)
        end)
        return entries
    end

    local redraw
    local function selectSession(row)
        tab, editing = "Session", false
        if selected == row then return end
        selected, detailTab, detailPage, transaction = row, "Summary", 1, nil
        detailSearch, qualityFilter, sourceFilter, classFilter = "", nil, "", ""
    end

    local function categoryName(entry)
        if entry.kind == "cash" then return entry.category or "Unclassified" end
        if entry.kind == "quest" then return entry.name or ("Quest #" .. entry.id) end
        if entry.kind == "grind" then return entry.name or entry.grindDate or "Manual grind" end
        if entry.kind == "de" then
            local names={}
            for id,item in pairs(entry.materials or {}) do names[#names+1]=(item.name or ("#"..id)).." ×"..item.qty end
            table.sort(names)
            return #names>0 and table.concat(names,", ") or "Disenchant"
        end
        return entry.name or (entry.id and ("Item #" .. entry.id)) or "Activity"
    end

    local function detailCells(entry)
        local label = categoryName(entry)
        local when = stamp(entry.at)
        if entry.kind == "cash" then return {label,signed(entry.amount),entry.zone or "—",when} end
        if entry.kind == "quest" then return {label,(entry.xp or 0) .. " XP",coin(entry.copper or 0),when} end
        if entry.kind == "rep" then return {label, (entry.amount > 0 and "+" or "") .. entry.amount,entry.zone or "—",when} end
        if entry.kind == "loot" or entry.kind == "reward" then
            local colors = {[0]="ff9d9d9d",[1]="ffffffff",[2]="ff1eff00",[3]="ff0070dd",[4]="ffa335ee",[5]="ffff8000"}
            if colors[entry.quality] then label = "|c"..colors[entry.quality]..label.."|r" end
            local vendor = entry.vendor and coin(entry.vendor*entry.qty) or "—"
            return {label,entry.qty,entry.sourceKind or "Unknown",vendor}
        end
        if entry.kind == "zone" then return {label,FormatTime(math.floor(entry.duration)),entry.xp or "—",signed(entry.net or 0)} end
        if entry.kind == "group" then return {label,entry.amount,entry.secondary or "",entry.extra or ""} end
        if entry.kind == "de" then
            local value, count, priced=0,0,0
            for _, item in pairs(entry.materials) do
                if type(item)=="table" and number(item.qty) then
                    count=count+1
                    if number(item.unit) then value,priced=value+item.unit*item.qty,priced+1 end
                end
            end
            return {label,count>0 and priced==count and coin(value) or "—",entry.zone or "—",when}
        end
        return {label,entry.duration and FormatTime(math.floor(entry.duration)) or "—",entry.zone or "—",when}
    end

    local sessionWidths = {175,136,88,102,77,69,69,75}
    local detailWidths = {300,100,181,185}
    local sectionCount = 0
    local function section(title, fields)
        sectionCount = sectionCount + 1
        local panel = frame.sections[sectionCount]
        panel:ClearAllPoints()
        panel:SetPoint("TOPLEFT",frame.content,"TOPLEFT",0,-frame.sectionHeight)
        panel.title:SetText(title)
        for i, cell in ipairs(panel.values) do
            local field = fields[i]
            if field then
                cell.name:SetText(field[1])
                cell.value:SetText(field[2] == nil and "—" or field[2])
                cell.tip = field[3]
                cell:Show()
            else cell:Hide() end
        end
        local height = 37+math.ceil(#fields/4)*42
        panel:SetHeight(height)
        panel:Show()
        frame.sectionHeight = frame.sectionHeight+height+8
    end

    local function showOverview(rows, stats, finance, gameplay, previous)
        local overview=frame.overview
        overview:Show()
        for i, metric in ipairs(overview.metrics) do
            metric.name:SetText(stats[i][1]); metric.value:SetText(stats[i][2])
        end
        for i, column in ipairs(overview.columns) do
            local fields=i==1 and finance or gameplay
            for j, cell in ipairs(column) do
                local field=fields[j]
                cell.name:SetText(field and field[1] or "")
                cell.value:SetText(field and field[2] or "")
                cell.tip=field and field[3]
            end
        end
        for i, button in ipairs(overview.recent) do
            local row=i==1 and rows[1] or previous
            button.entry=row
            if row then
                button.name:SetText(row==active and "|cff8af6a4● Current login|r" or stamp(row.started))
                button.context:SetText((row.name or primaryZone(row)).." · "..(row.seconds and FormatTime(math.floor(row.seconds)) or "—"))
                button.amount:SetText(signed(net(row)).."   ›")
            else
                button.name:SetText(i==1 and "No matching login" or "")
                button.context:SetText(""); button.amount:SetText("")
            end
            button:SetShown(row~=nil or i==1)
        end
    end

    local function showRows(rows, index, mode, labels)
        local detail = mode ~= "sessions"
        local widths = detail and detailWidths or sessionWidths
        local offset = 0
        for col, header in ipairs(frame.headers) do
            local label = labels[col]
            if label and (detail or allCharacters or col ~= 2) then
                local width = widths[col] + ((not detail and not allCharacters and col == 1) and widths[2] or 0)
                header:ClearAllPoints()
                header:SetPoint("TOPLEFT",frame,"TOPLEFT",17+offset,-129)
                header:SetWidth(width-1)
                header.label:SetText(label .. (not detail and sort == col and (ascending and " ▲" or " ▼") or ""))
                header:Show()
                offset = offset + width
            end
        end
        for i, button in ipairs(frame.rows) do
            local row = rows[(index-1)*perPage+i]
            button.entry, button.mode = row, mode
            if row then
                local values
                if detail then values = detailCells(row)
                else
                    values = {stamp(row.started),row.character or "—",FormatTime(math.floor(row.seconds or 0)),
                        signed(net(row)),row.xp or 0,row.quests or 0,row.loot or 0,row.reputation or "—"}
                    if row == active then values[1] = "|cff8af6a4▶|r " .. values[1] end
                end
                local icon = detail and row.icon
                if icon then button.icon:SetTexture(icon); button.icon:Show() else button.icon:Hide() end
                offset = 0
                for col, cell in ipairs(button.cells) do
                    if values[col] ~= nil and (detail or allCharacters or col ~= 2) then
                        local width = widths[col] + ((not detail and not allCharacters and col == 1) and widths[2] or 0)
                        local inset = col == 1 and icon and 28 or 8
                        cell:ClearAllPoints(); cell:SetPoint("LEFT",offset+inset,0); cell:SetWidth(width-inset-6)
                        cell:SetText(values[col]); cell:Show()
                        offset = offset+width
                    end
                end
                button.selected:SetShown(row == transaction)
                button:Show()
            end
        end
    end

    local function elapsed(seconds)
        return seconds and FormatTime(math.floor(seconds)) or "—"
    end

    local function dashboard(rows, single)
        local n, seconds, afkTime, afkKnown, income, spent, earned, costs, xpTotal, quests, loot, de, rep, hk, kb, deaths, questCash, questEstimate =
            0,0,0,false,0,0,0,0,0,0,0,0,0,0,0,0,0,0
        local best, longest, previous, busy, busyTime
        local zoneTimes = {}
        for _, row in ipairs(rows) do
            local _,_,revenue,expenses = totals(row)
            n,seconds = n+1,seconds+(row.seconds or 0)
            income,spent = income+(row.income or 0),spent+(row.spent or 0)
            earned,costs = earned+revenue,costs+expenses
            xpTotal,quests,loot = xpTotal+(row.xp or 0),quests+(row.quests or 0),loot+(row.loot or 0)
            de,rep,hk,kb,deaths = de+(row.disenchant or 0),rep+(row.reputation or 0),hk+(row.hk or 0),
                kb+(row.kb or 0),deaths+(row.deaths or 0)
            questCash,questEstimate = questCash+(row.questCopper or 0),questEstimate+(row.questVendor or 0)
            if row.afk then afkTime,afkKnown = afkTime+row.afk,true end
            if not best or net(row)>net(best) then best=row end
            if not longest or (row.seconds or 0)>(longest.seconds or 0) then longest=row end
            if row ~= active and (not previous or row.started>previous.started) then previous=row end
            for zone, duration in pairs(type(row.zones)=="table" and row.zones or {}) do
                if type(zone)=="string" and number(duration) then
                    zoneTimes[zone]=(zoneTimes[zone] or 0)+duration
                    if not busyTime or zoneTimes[zone]>busyTime then busy,busyTime=zone,zoneTimes[zone] end
                end
            end
        end
        if single then
            section("Session",{{"Login",stamp(single.started)},{"End",single == active and "In progress" or stamp(single.last)},
                {"Status",statuses[single.status] or "Status unavailable"},{"Duration",elapsed(seconds)},
                {"Non-AFK",afkKnown and elapsed(math.max(0,seconds-afkTime)) or "—"},{"AFK",afkKnown and elapsed(afkTime) or "—"},
                {"Starting level",single.startLevel},{"Ending level",single.endLevel}})
        end
        local finance = {{"Money received",coin(income)},{"Money spent",coin(spent)},
            {"Wallet net",signed(income-spent),"All observed balance changes, including unidentified transactions."},
            {"Wallet net / hour",rate(income-spent,seconds,signed)},{"Verified earnings",coin(earned)},
            {"Classified expenses",coin(costs)},{"Quest cash",coin(questCash),"Reported by quest turn-ins."},
            {"Quest reward estimate",coin(questEstimate),"Estimated vendor value of matched reward receipts."}}
        if single then
            finance[#finance+1]={"Opening wallet",single.firstMoney and coin(single.firstMoney)}
            finance[#finance+1]={"Closing wallet",single.lastMoney and coin(single.lastMoney)}
        end
        if not single then
            local latest
            for _, row in ipairs(rows) do if not latest or row.started>latest.started then latest=row end end
            showOverview({latest},
                {{"Playtime",elapsed(seconds)},{"Login sessions",n},{"Net gold",signed(income-spent)},
                    {"Experience",xpTotal},{"Quests completed",quests},{"Reputation",rep}},
                {finance[1],finance[2],finance[4],finance[5],finance[6],finance[7],finance[8]},
                {{"Item receipts",loot},{"Disenchants",de},{"Honorable kills",hk},{"Killing blows",kb},
                    {"Deaths",deaths},{"XP / hour",rate(xpTotal,seconds,tostring)},{"Most played zone",busy or "—"}},
                previous~=latest and previous or nil)
            frame.highlights:SetText("Longest  " .. (longest and elapsed(longest.seconds) or "—") ..
                "     Highest wallet net  " .. (best and signed(net(best)) or "—") ..
                "     AFK  " .. (afkKnown and elapsed(afkTime) or "—"))
            return
        end
        section("Financial activity",finance)
        if single then section("Progression",{{"Experience",xpTotal},{"Experience / hour",rate(xpTotal,seconds,tostring)},
            {"Quests",quests},{"Net reputation",rep}}) end
        section("Gameplay",{{"Item receipts",loot},{"Disenchants",de},{"Honorable kills",hk},{"Killing blows",kb},
            {"Deaths",deaths},{"Non-AFK time",afkKnown and elapsed(math.max(0,seconds-afkTime)) or "—"},
            {"AFK time",afkKnown and elapsed(afkTime) or "—"},{"Most time spent",busy}})
        if single then
            local locations={}
            for name,duration in pairs(zoneTimes) do locations[#locations+1]={name,elapsed(duration)} end
            table.sort(locations,function(a,b) return a[1]<b[1] end)
            for first=1,#locations,12 do
                if sectionCount >= #frame.sections-1 then break end
                local batch={}
                for i=first,math.min(first+11,#locations) do batch[#batch+1]=locations[i] end
                section("Zone time",batch)
            end
            section("Notes",{{"Session notes",single.notes or "—",single.notes}})
        else
            section("Session highlights",{{"Current login",active and primaryZone(active) or "Inactive"},
                {"Previous login",previous and stamp(previous.started)},{"Highest wallet net",best and signed(net(best))},
                {"Longest login",longest and elapsed(longest.seconds)}})
        end
    end

    local function aggregate(rows)
        local entries, byName = {}, {}
        local function add(name, amount, format, context)
            local existing = byName[name]
            if not existing then
                existing={kind="group",name=name,total=0,format=format,secondary=context}
                byName[name]=existing; entries[#entries+1]=existing
            end
            existing.total=existing.total+amount
        end
        for _, row in ipairs(rows) do
            if group == "Experience" then add("Total XP",row.xp or 0,tostring) end
            if group == "Currency" then
                add("Actual wallet income",row.income or 0,coin)
                add("Actual wallet spending",row.spent or 0,coin)
            end
            if group == "Zones" then
                for name, seconds in pairs(row.zones or {}) do if number(seconds) then add(name,seconds,elapsed) end end
            end
            for _, event in detailIterator(row) do
                if group=="Currency" and event.kind=="cash" then
                    local category=event.category or "Unclassified"
                    add(category .. (event.amount>0 and " · received" or " · spent"),event.amount,signed)
                elseif group=="Loot" and event.kind=="loot" then
                    add(categoryName(event),event.qty,tostring,event.sourceKind)
                elseif group=="Quests" and event.kind=="quest" then add(categoryName(event),1,tostring,"Turn-ins")
                elseif group=="Reputation" and event.kind=="rep" then add(event.name,event.amount,tostring)
                elseif group=="Disenchant" and event.kind=="de" then
                    for id,item in pairs(event.materials or {}) do add(item.name or ("Item #"..id),item.qty,tostring) end
                end
            end
        end
        for _, entry in ipairs(entries) do entry.amount=entry.format(entry.total) end
        table.sort(entries,function(a,b) return a.total==b.total and a.name<b.name or a.total>b.total end)
        return entries
    end

    local detailLabels = {
        Loot={"Item","Quantity","Acquisition","Vendor estimate"},Quests={"Quest / reward","XP / quantity","Cash / acquisition","Completed / estimate"},
        Currency={"Classification","Amount","Zone","Time"},Disenchant={"Materials received","Estimate","Zone","Time"},
        Reputation={"Faction","Change","Zone","Time"},Zones={"Zone / activity","Time","XP","Wallet change"},
        Review={"Activity","Amount / quantity","Context","Time / estimate"},
    }

    redraw = function()
        if not frame then return end
        if active and world then sampleClock(); sampleMoney(); sampleXP() end
        for _, button in ipairs(frame.controls) do button:Hide() end
        for _, row in ipairs(frame.rows) do
            row:Hide(); row.entry=nil
            for _, cell in ipairs(row.cells) do cell:Hide() end
        end
        for _, panel in ipairs(frame.sections) do panel:Hide() end
        for _, box in ipairs(frame.inputs) do box:Hide() end
        for name, button in pairs(frame.primary) do
            local selectedTab = name==tab or name=="Login Sessions" and tab=="Session" or name=="Settings" and tab=="Diagnostics"
            button.indicator:SetShown(selectedTab)
            button.label:SetText((selectedTab and "▶  " or "")..name)
        end
        for _, button in pairs(frame.details) do
            button.indicator:SetShown(button.section==detailTab)
            button.label:SetText((button.section==detailTab and "▶ " or "") .. button.section)
        end
        sectionCount,frame.sectionHeight=0,0
        frame.status:SetText(active and "|cff8af6a4●  Recording|r" or "|cffc8bba4○  Inactive|r")
        frame.caption:SetText("")
        frame.overview:Hide()
        frame.scroll:ClearAllPoints()
        frame.scroll:SetPoint("TOPLEFT",17,-128)
        frame.scroll:SetPoint("BOTTOMRIGHT",-35,editing and 78 or 48)
        local function show(button,text)
            if text then button.label:SetText(text) end
            button:Show()
        end
        local function paging(count,pageIndex)
            if pageIndex>1 then show(frame.previous) end
            if pageIndex*perPage<count then show(frame.next) end
            return count .. " matching · Page " .. pageIndex .. "/" .. math.max(1,math.ceil(count/perPage))
        end
        local function filters()
            show(frame.action,ranges[range])
            show(frame.scope,allCharacters and "All characters" or "This character")
        end
        local cfg=state and state.settings or {}
        if tab=="Settings" then
            frame.caption:SetText("Recording and valuation")
            for i,option in ipairs(options) do
                show(frame.settingButtons[i],(cfg[option[1]] and "✓  " or "○  ") .. option[2])
            end
            show(frame.settingButtons[9],"Valuation · "..(modes[cfg.mode or 1] or modes[1]))
            show(frame.sortPreference,"Default sort · "..({"Newest","Character","Duration","Net gold","XP","Quests","Items","Reputation"})[cfg.sessionSort or 1])
            show(frame.groupPreference,"Default loot · "..(cfg.groupLoot==false and "Individual events" or "Grouped"))
            show(frame.diagnostics)
        elseif tab=="Diagnostics" then
            frame.caption:SetText("Diagnostics · events observed by this client")
            show(frame.back,"Back to Settings")
            local fields, report = {}, {"GrindTracker "..VERSION}
            for _, label in ipairs({"Login sampling","Logout checkpoint","Reload continuity","Loot receipts","Currency sampling",
                "Currency attribution","Vendor sale evidence","Quest completions","Quest reward matching","Disenchant receipts",
                "XP sampling","Reputation receipts","Zone location","Dungeon location","Loot-line deduplication","Pricing quote","Item pricing","Grind reward posting"}) do
                local status=diagnostic[label] or "Not yet observed"
                fields[#fields+1]={label,status}
                report[#report+1]=label.." · "..status
            end
            for label,status in pairs(diagnostic) do
                if status:match("^Error") or status=="Unavailable" then report[#report+1]=label.." · "..status end
            end
            for _,entry in ipairs(recent) do report[#report+1]=entry end
            frame.report=table.concat(report," | ")
            section("Recording checks",fields)
            show(frame.apply,"Copy diagnostics")
        elseif tab=="Overview" then
            filters()
            frame.caption:SetText(ranges[range] .. "  ·  " .. (allCharacters and "All characters" or "This character"))
            dashboard(sessionRows())
        elseif tab=="Breakdown" then
            filters()
            show(frame.group,"Category · "..group)
            local entries=aggregate(sessionRows())
            detailPage=math.min(detailPage,math.max(1,math.ceil(#entries/perPage)))
            frame.caption:SetText(group.." · "..paging(#entries,detailPage))
            showRows(entries,detailPage,"aggregate",{"Activity","Total","Source",""})
        elseif tab=="Login Sessions" then
            filters()
            local rows=sessionRows()
            page=math.min(page,math.max(1,math.ceil(#rows/perPage)))
            frame.caption:SetText(#rows==0 and "No matching sessions" or paging(#rows,page))
            showRows(rows,page,"sessions",{"Login time","Character","Duration","Net gold","XP","Quests","Items","Rep"})
            frame.edit:Show(); frame.zone:Show()
            if allCharacters then frame.character:Show() end
            show(frame.apply,"Search")
            if state and (state.deleted or type(state.deletedRows)=="table" and #state.deletedRows>0) then show(frame.third,"Restore deleted") end
        elseif tab=="Quest History" then
            filters()
            local entries={}
            for _, row in ipairs(sessionRows()) do
                for _, entry in detailIterator(row) do
                    if entry.kind=="quest" and contains(valueText(entry).." "..(row.character or ""),detailSearch) then
                        entries[#entries+1]=entry
                    end
                end
            end
            table.sort(entries,function(a,b)
                if detailSort==2 then return categoryName(a)<categoryName(b) end
                if detailSort==3 then return (a.copper or 0)>(b.copper or 0) end
                return (a.at or 0)>(b.at or 0)
            end)
            detailPage=math.min(detailPage,math.max(1,math.ceil(#entries/perPage)))
            frame.caption:SetText("Completed quests · "..paging(#entries,detailPage))
            showRows(entries,detailPage,"event",{"Quest","Experience","Reported cash","Completed"})
            show(frame.third,"Sort · "..({"Time","Name","Cash"})[detailSort])
            frame.edit:Show(); show(frame.apply,"Search")
        elseif tab=="Session" and selected then
            show(frame.back,"Back to Sessions")
            for _,button in pairs(frame.details) do button:Show() end
            local reviewCount=0
            for _,entry in detailIterator(selected) do
                if not entry.reviewIgnored and (entry.status=="Review" or entry.kind=="de" or entry.kind=="cash" and not entry.category) then
                    reviewCount=reviewCount+1
                end
            end
            if reviewCount>0 or detailTab=="Review" then show(frame.review,"Review ("..reviewCount..")") end
            local heading=(selected.name or primaryZone(selected)) .. " · " .. (selected.character or "—")
            if detailTab=="Summary" then
                frame.caption:SetText(heading)
                dashboard({selected},selected)
                show(frame.rename,editing and "Save changes" or "Edit name & notes")
                if editing then frame.name:Show(); frame.notes:Show() end
                if state and selected.character==key and selected~=active then show(frame.third,"Delete session") end
            else
                local entries=detailRows(selected)
                detailPage=math.min(detailPage,math.max(1,math.ceil(#entries/perPage)))
                frame.caption:SetText(heading.."  ·  "..paging(#entries,detailPage))
                showRows(entries,detailPage,"event",detailLabels[detailTab])
                show(frame.action,"Sort · "..({"Time","Name","Amount"})[detailSort])
                if detailTab=="Loot" then show(frame.scope,combined and "Grouped loot" or "Individual events") end
                frame.edit:Show()
                show(frame.apply,detailTab=="Review" and "Apply review" or "Search")
            end
        end
        local panelMode=sectionCount>0
        frame.scroll:SetShown(panelMode and tab~="Overview")
        frame.highlights:SetShown(tab=="Overview")
        frame.content:SetHeight(math.max(1,frame.sectionHeight))
        if frame.lastTab~=tab then frame.scroll:SetVerticalScroll(0); frame.lastTab=tab end
    end

    changeSetting = function(index)
        local cfg = settings()
        if not cfg then return end
        if active and world then sampleClock() end
        local option = options[index]
        if option then cfg[option[1]] = not cfg[option[1]]
        else cfg.mode = ((cfg.mode or 1) % #modes) + 1 end
        refreshEvents()
        if not enabled("login") then stop("disabled") else start(false) end
        if active and not enabled("gold") then cashTimer, cashWindow, evidenceWindow = nil, {}, {} end
        if not enabled("quest") then dialog, turnedIn = nil, nil end
        if not enabled("results") then deCast, deLoot = nil, nil end
        redraw()
    end

    local function apply()
        if tab == "Diagnostics" then
            frame.edit:Show()
            frame.edit:SetText(frame.report or "")
            frame.edit:SetFocus(); frame.edit:HighlightText()
            return
        end
        local input = frame.edit:GetText():match("^%s*(.-)%s*$")
        local command, value = input:match("^(%S+)%s*(.*)$")
        if tab == "Login Sessions" then
            if command == "zone" then zoneFilter = value:lower()
            elseif command == "character" then characterFilter = value:lower()
            else search = input:lower() end
            page = 1
        elseif tab == "Quest History" then
            detailSearch, detailPage = input:lower(), 1
        elseif tab == "Session" and selected then
            local entry = transaction
            if detailTab == "Summary" and command == "name" then selected.name = value ~= "" and value:sub(1,80) or nil
            elseif detailTab == "Summary" and command == "note" then selected.notes = value:sub(1,500)
            elseif detailTab == "Loot" and command == "quality" then qualityFilter = tonumber(value)
            elseif detailTab == "Loot" and command == "source" then sourceFilter = value:lower()
            elseif detailTab == "Loot" and command == "class" then classFilter = value:lower()
            elseif entry and not entry.aggregate and command == "category" and entry.kind == "cash" then
                for _, category in ipairs(categories) do
                    if category:lower() == value:lower() then entry.category = category; break end
                end
            elseif entry and not entry.aggregate and command == "ignore" then
                entry.reviewIgnored = true
            elseif entry and not entry.aggregate and command == "attach" then
                entry.reviewAssociation = value:sub(1,100)
            elseif entry and not entry.aggregate and (entry.kind == "reward" or entry.kind == "loot")
                and (command == "resolve" or command == "confirm" or command == "value") then
                local amount = number(tonumber(value))
                if command == "confirm" then amount = entry.estimate end
                if command == "resolve" or (amount and amount >= 0 and amount <= 10^12) then
                    selected.estimated = (selected.estimated or 0) - (entry.included or 0)
                    selected.questVendor = (selected.questVendor or 0) - (entry.autoVendor or 0)
                    entry.included, entry.autoVendor, entry.pending = nil, nil, nil
                    if command == "resolve" then entry.status = "Resolved / excluded"
                    else
                        entry.estimate = math.floor(amount)
                        if command == "value" then entry.method = "Manual" end
                        entry.status = "Reviewed unsold"
                        if entry.kind == "reward" and entry.sourceKind == "Quest" then
                            entry.autoVendor = entry.estimate
                            selected.questVendor = selected.questVendor + entry.estimate
                        else
                            entry.included = entry.estimate
                            selected.estimated = selected.estimated + entry.estimate
                        end
                    end
                end
            elseif detailTab ~= "Summary" then detailSearch, detailPage = input:lower(), 1 end
        end
        frame.edit:SetText(""); frame.edit:ClearFocus()
        redraw()
    end

    local function recoverable(value)
        return type(value)=="table" and type(value.row)=="table" and number(value.row.started) ~= nil
    end

    local function deleteOrRestore()
        if tab == "Quest History" then detailSort=detailSort%3+1; detailPage=1; redraw(); return end
        if not state then return end
        if tab == "Login Sessions" then
            local recovered
            if type(state.deletedRows)=="table" then
                for i=#state.deletedRows,1,-1 do
                    if recoverable(state.deletedRows[i]) then recovered=table.remove(state.deletedRows,i); break end
                end
            end
            if not recovered and recoverable(state.deleted) then recovered,state.deleted=state.deleted,nil end
            if recovered then
                local at=#state.sessions+1
                for i,row in ipairs(state.sessions) do
                    if row~=active and type(row)=="table" and number(row.started) and row.started<recovered.row.started then
                        at=i
                        break
                    end
                end
                table.insert(state.sessions,at,recovered.row)
            end
        elseif tab == "Session" and selected and selected ~= active and selected.character == key then
            if not IsShiftKeyDown() then
                frame.status:SetText("|cffffc766Shift-click Delete to confirm|r")
                return
            end
            for i, row in ipairs(state.sessions) do
                if row == selected then
                    if state.deletedRows == nil then state.deletedRows = {} end
                    if type(state.deletedRows)~="table" then
                        frame.status:SetText("|cffffc766Delete unavailable · invalid recovery data|r")
                        return
                    end
                    state.deletedRows[#state.deletedRows+1] = {row=table.remove(state.sessions,i)}
                    selected, tab = nil, "Login Sessions"
                    break
                end
            end
        end
        redraw()
    end

    function log.ExperimentalShow(settingsFirst)
        if not key then return end
        if not preferenceLoaded then
            local cfg=state and state.settings or {}
            sort=math.max(1,math.min(8,math.floor(number(cfg.sessionSort) or 1)))
            combined=cfg.groupLoot~=false
            preferenceLoaded=true
        end
        if not frame then
            frame=CreateFrame("Frame","GTExperimentalAnalytics",UIParent)
            frame:SetSize(804,516); frame:SetPoint("CENTER"); frame:SetFrameStrata("DIALOG")
            frame:SetClampedToScreen(true); frame:EnableMouse(true); frame:SetMovable(true)
            frame:RegisterForDrag("LeftButton"); frame:SetScript("OnDragStart",frame.StartMoving)
            frame:SetScript("OnDragStop",frame.StopMovingOrSizing)
            local function fill(parent,r,g,b,a)
                local texture=parent:CreateTexture(nil,"BACKGROUND")
                texture:SetAllPoints(); texture:SetColorTexture(r,g,b,a)
                return texture
            end
            local function text(parent,font,x,y,value)
                local label=parent:CreateFontString(nil,"OVERLAY",font)
                label:SetPoint("TOPLEFT",x,y); label:SetJustifyH("LEFT"); label:SetText(value or "")
                return label
            end
            local function tooltip(self,heading,body)
                if not body then return end
                GameTooltip:SetOwner(self,"ANCHOR_RIGHT")
                GameTooltip:SetText(heading); GameTooltip:AddLine(body,.85,.85,.85,true); GameTooltip:Show()
            end
            fill(frame,.045,.040,.031,1)
            text(frame,"GameFontNormalLarge",18,-13,"Login Analytics")
            text(frame,"GameFontDisableSmall",143,-16,VERSION)
            frame.caption=text(frame,"GameFontHighlight",18,-106)
            frame.caption:SetWidth(630); frame.caption:SetHeight(20); frame.caption:SetWordWrap(false)
            frame.status=frame:CreateFontString(nil,"OVERLAY","GameFontNormalSmall")
            frame.status:SetPoint("TOPRIGHT",-45,-17)
            local footer=frame:CreateFontString(nil,"OVERLAY","GameFontNormalSmall")
            footer:SetPoint("BOTTOMRIGHT",-14,13); footer:SetText("RIP Shady")
            frame.controls,frame.rows,frame.headers,frame.sections,frame.inputs={},{},{},{},{}
            frame.primary,frame.details,frame.settingButtons={},{},{}
            local function button(label,w,x,y,callback,kind)
                local b=CreateFrame("Button",nil,frame)
                b:SetSize(w,kind=="primary" and 28 or 23)
                b:SetPoint(y<0 and "TOPLEFT" or "BOTTOMLEFT",x,y)
                local bg=fill(b,kind=="primary" and .16 or .10,.085,.057,1)
                b.label=b:CreateFontString(nil,"OVERLAY","GameFontHighlightSmall")
                b.label:SetAllPoints(); b.label:SetText(label)
                b:SetScript("OnEnter",function() bg:SetColorTexture(.25,.17,.08,1) end)
                b:SetScript("OnLeave",function() bg:SetColorTexture(kind=="primary" and .16 or .10,.085,.057,1) end)
                b:SetScript("OnClick",callback)
                if kind=="primary" or kind=="secondary" then
                    b.indicator=b:CreateTexture(nil,"BORDER")
                    b.indicator:SetPoint("BOTTOMLEFT",0,0); b.indicator:SetPoint("BOTTOMRIGHT",0,0)
                    b.indicator:SetHeight(kind=="primary" and 4 or 2)
                    b.indicator:SetColorTexture(1,.74,.29,1)
                end
                if kind~="primary" and kind~="persistent" then frame.controls[#frame.controls+1]=b end
                return b
            end
            button("×",23,767,-8,function() frame:Hide() end,"persistent")
            for i,name in ipairs(primary) do
                local target=name
                frame.primary[name]=button(name,148,17+(i-1)*154,-38,function()
                    viewPages[tab]=detailPage
                    tab,editing=target,false
                    detailPage=viewPages[target] or 1
                    redraw()
                end,"primary")
            end
            for i,name in ipairs(detailTabs) do
                if name~="Review" then
                    local target=name
                    local b=button(name,89,17+(i-1)*94,-74,function()
                        if detailTab~=target then detailTab,detailPage,transaction,detailSearch=target,1,nil,"" end
                        redraw()
                    end,"secondary")
                    b.section=name; frame.details[name]=b
                end
            end
            frame.review=button("Review",107,678,-74,function() detailTab,detailPage,transaction,detailSearch="Review",1,nil,""; redraw() end)
            frame.back=button("Back",120,666,-102,function()
                tab=tab=="Diagnostics" and "Settings" or "Login Sessions"; editing=false; redraw()
            end)
            frame.scroll=CreateFrame("ScrollFrame",nil,frame,"UIPanelScrollFrameTemplate")
            frame.scroll:SetPoint("TOPLEFT",17,-128); frame.scroll:SetPoint("BOTTOMRIGHT",-35,78)
            local child=CreateFrame("Frame",nil,frame.scroll)
            child:SetSize(752,1); frame.scroll:SetScrollChild(child); frame.content=child
            local overview=CreateFrame("Frame",nil,frame)
            overview:SetPoint("TOPLEFT",17,-128); overview:SetSize(766,335)
            overview.metrics,overview.columns,overview.recent={},{},{}
            frame.overview=overview
            frame.highlights=text(frame,"GameFontDisableSmall",18,-472)
            for i=1,6 do
                local tile=CreateFrame("Frame",nil,overview)
                tile:SetSize(249,45); tile:SetPoint("TOPLEFT",(i-1)%3*257,-math.floor((i-1)/3)*51)
                fill(tile,.102,.087,.063,1)
                overview.metrics[i]={name=text(tile,"GameFontHighlightSmall",10,-7),value=text(tile,"GameFontNormal",10,-24)}
            end
            for i, title in ipairs({"Financial activity","Gameplay activity"}) do
                local column={}
                overview.columns[i]=column
                local offset=(i-1)*389
                text(overview,"GameFontNormal",offset,-109,title)
                for j=1,7 do
                    local line=CreateFrame("Frame",nil,overview)
                    line:SetSize(374,16); line:SetPoint("TOPLEFT",offset,-129-(j-1)*17)
                    line:EnableMouse(true)
                    line.name=text(line,"GameFontHighlightSmall",0,0)
                    line.value=line:CreateFontString(nil,"OVERLAY","GameFontHighlightSmall")
                    line.value:SetPoint("TOPRIGHT",0,0); line.value:SetWidth(170); line.value:SetJustifyH("RIGHT")
                    line:SetScript("OnEnter",function(self) tooltip(self,self.name:GetText(),self.tip) end)
                    line:SetScript("OnLeave",function() GameTooltip:Hide() end)
                    column[j]=line
                end
            end
            text(overview,"GameFontNormal",0,-253,"Recent login sessions")
            for i=1,2 do
                local recent=CreateFrame("Button",nil,overview)
                recent:SetSize(766,31); recent:SetPoint("TOPLEFT",0,-272-(i-1)*34)
                fill(recent,.102,.087,.063,1)
                recent.name=text(recent,"GameFontHighlightSmall",8,-4)
                recent.context=text(recent,"GameFontDisableSmall",8,-17)
                recent.amount=recent:CreateFontString(nil,"OVERLAY","GameFontHighlightSmall")
                recent.amount:SetPoint("RIGHT",-10,0)
                recent:SetScript("OnClick",function(self) if self.entry then selectSession(self.entry); redraw() end end)
                overview.recent[i]=recent
            end
            for i=1,8 do
                local panel=CreateFrame("Frame",nil,child)
                panel:SetSize(752,100)
                fill(panel,.077,.066,.050,1)
                panel.title=text(panel,"GameFontNormal",10,-8)
                panel.values={}
                for n=1,16 do
                    local cell=CreateFrame("Frame",nil,panel)
                    cell:SetSize(176,37); cell:SetPoint("TOPLEFT",10+(n-1)%4*184,-30-math.floor((n-1)/4)*42)
                    cell:EnableMouse(true)
                    cell.name=text(cell,"GameFontNormalSmall",0,0); cell.name:SetWidth(176)
                    cell.value=text(cell,"GameFontHighlight",0,-15); cell.value:SetWidth(176); cell.value:SetHeight(21)
                    cell:SetScript("OnEnter",function(self) tooltip(self,self.name:GetText(),self.tip) end)
                    cell:SetScript("OnLeave",function() GameTooltip:Hide() end)
                    panel.values[n]=cell
                end
                frame.sections[i]=panel
            end
            for i=1,8 do
                local index=i
                frame.headers[i]=button("",100,17,-129,function()
                    if tab~="Login Sessions" then return end
                    if sort==index then ascending=not ascending else sort,ascending=index,false end
                    page=1; redraw()
                end)
            end
            for i=1,perPage do
                local row=CreateFrame("Button",nil,frame)
                row:SetSize(766,29); row:SetPoint("TOPLEFT",17,-154-(i-1)*30)
                local shade=i%2==0 and .096 or .070
                fill(row,shade,shade*.87,shade*.68,1)
                row.selected=row:CreateTexture(nil,"ARTWORK")
                row.selected:SetPoint("TOPLEFT"); row.selected:SetPoint("BOTTOMLEFT")
                row.selected:SetWidth(4); row.selected:SetColorTexture(1,.75,.25,1)
                row.icon=row:CreateTexture(nil,"ARTWORK")
                row.icon:SetPoint("LEFT",6,0); row.icon:SetSize(17,17)
                row.cells={}
                for col=1,8 do
                    local cell=row:CreateFontString(nil,"OVERLAY","GameFontHighlightSmall")
                    cell:SetJustifyH("LEFT"); cell:SetJustifyV("MIDDLE"); cell:SetHeight(15)
                    cell:SetWordWrap(false)
                    row.cells[col]=cell
                end
                row:SetScript("OnClick",function(self)
                    local entry=self.entry
                    if not entry then return end
                    if self.mode=="sessions" then selectSession(entry)
                    elseif self.mode=="event" then
                        local link=entry.link or entry.item and entry.item.link
                        if link and IsShiftKeyDown() and HandleModifiedItemClick then HandleModifiedItemClick(link)
                        else transaction=entry end
                    end
                    redraw()
                end)
                row:SetScript("OnEnter",function(self)
                    local entry=self.entry
                    if not entry then return end
                    if self.mode=="sessions" then
                        tooltip(self,entry.name or primaryZone(entry),table.concat({entry.character or "—",
                            statuses[entry.status] or "Status unavailable","End  "..(entry==active and "In progress" or stamp(entry.last)),
                            "Wallet net / hour  "..rate(net(entry),entry.seconds or 0,signed)}, "\n"))
                    elseif self.mode=="event" then
                        local link=entry.link or entry.item and entry.item.link
                        local extra=(entry.zone and ("\n"..entry.zone) or "")..(entry.at and ("\n"..stamp(entry.at)) or "")
                        if entry.kind=="quest" and selected and tab=="Session" and entry.eventID then
                            for _, reward in detailIterator(selected) do
                                if reward.kind=="reward" and reward.questEvent==entry.eventID then
                                    extra=extra.."\n"..valueText(reward)
                                end
                            end
                        end
                        if entry.kind=="zone" then extra=extra.."\nNon-AFK  "..elapsed(entry.activeTime).."   XP  "..(entry.xp or "—") end
                        if link then
                            GameTooltip:SetOwner(self,"ANCHOR_RIGHT"); GameTooltip:SetHyperlink(link)
                            GameTooltip:AddLine(valueText(entry)..extra,.85,.85,.85,true); GameTooltip:Show()
                        else tooltip(self,categoryName(entry),valueText(entry)..extra) end
                    end
                end)
                row:SetScript("OnLeave",function() GameTooltip:Hide() end)
                frame.rows[i]=row
            end
            for i=1,#options+1 do
                local index=i
                frame.settingButtons[i]=button("",350,17+(i-1)%2*380,-133-math.floor((i-1)/2)*31,function() changeSetting(index) end)
            end
            frame.sortPreference=button("",350,17,-302,function()
                local cfg=settings(); if not cfg then return end
                cfg.sessionSort=(math.floor(number(cfg.sessionSort) or 1)%8)+1
                sort,ascending,page=cfg.sessionSort,false,1; redraw()
            end)
            frame.groupPreference=button("",350,397,-302,function()
                local cfg=settings(); if not cfg then return end
                cfg.groupLoot=cfg.groupLoot==false
                combined=cfg.groupLoot; redraw()
            end)
            frame.diagnostics=button("Advanced diagnostics",170,17,-350,function() tab="Diagnostics"; redraw() end)
            local function input(hint,w,x,limit)
                local box=CreateFrame("EditBox",nil,frame,"InputBoxTemplate")
                box:SetSize(w,23); box:SetPoint("BOTTOMLEFT",x,46)
                box:SetMaxLetters(limit); box:SetAutoFocus(false)
                local placeholder=text(box,"GameFontDisableSmall",5,-5,hint)
                box:SetScript("OnEscapePressed",function(self) self:ClearFocus(); frame:Hide() end)
                local function update(self) placeholder:SetShown(self:GetText()=="") end
                box:SetScript("OnTextChanged",update); box:SetScript("OnShow",update)
                frame.inputs[#frame.inputs+1]=box
                return box
            end
            frame.edit=input("Search or review command",288,23,12000)
            frame.zone=input("Zone filter",145,327,80)
            frame.character=input("Character filter",140,488,80)
            frame.name=input("Session name",222,23,80)
            frame.notes=input("Session notes",376,263,500)
            local function submit()
                if tab=="Login Sessions" then
                    search,zoneFilter,characterFilter=frame.edit:GetText():lower(),frame.zone:GetText():lower(),frame.character:GetText():lower()
                    page=1
                    for _,box in ipairs(frame.inputs) do box:ClearFocus() end
                    redraw()
                else apply() end
            end
            for _,box in ipairs({frame.edit,frame.zone,frame.character}) do box:SetScript("OnEnterPressed",submit) end
            frame.apply=button("Search",130,649,46,submit)
            frame.rename=button("Edit name & notes",130,649,46,function()
                if not selected then return end
                if editing then
                    local name=frame.name:GetText():match("^%s*(.-)%s*$")
                    selected.name=name~="" and name or nil
                    selected.notes=frame.notes:GetText()
                else
                    frame.name:SetText(selected.name or "")
                    frame.notes:SetText(selected.notes or "")
                end
                editing=not editing; redraw()
            end)
            local function turn(direction)
                if tab=="Login Sessions" then page=math.max(1,page+direction)
                else detailPage=math.max(1,detailPage+direction) end
                redraw()
            end
            frame.previous=button("Previous",63,17,10,function() turn(-1) end)
            frame.next=button("Next",52,85,10,function() turn(1) end)
            frame.action=button("Range",130,150,10,function()
                if tab=="Session" then detailSort=detailSort%3+1
                else range=range%#ranges+1 end
                page,detailPage=1,1; redraw()
            end)
            frame.scope=button("This character",125,286,10,function()
                if tab=="Session" then combined=not combined; transaction=nil
                else allCharacters=not allCharacters end
                page,detailPage=1,1; redraw()
            end)
            frame.third=button("History",128,418,10,deleteOrRestore)
            frame.group=button("Category",150,418,10,function()
                for index,name in ipairs(groups) do if name==group then group=groups[index%#groups+1]; break end end
                detailPage=1; redraw()
            end)
            if UISpecialFrames then table.insert(UISpecialFrames,frame:GetName()) end
        end
        if settingsFirst then tab="Settings" end
        frame:Show(); redraw()
    end
end)()
end
