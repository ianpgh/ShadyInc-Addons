local _, ac = ...
local eligible
-- Safe, short-lived reagent checklist and guided purchase queue.
-- Each AH order needs a fresh, user-initiated click and Blizzard confirmation.
-- No automatic Next/Buy/Confirm calls are made in event handlers.

local function remaining(row)
    if not row then return 0 end
    return math.max(0,(tonumber(row.toBuy) or 0)-(tonumber(row.acBought) or 0))
end

function ac.BatchRemaining(row)
    return remaining(row)
end

function ac.BatchCount()
    local count=0
    for _,row in ipairs(ac.session.rows or {}) do
        if row.acSelected and not row.output and remaining(row)>0 and eligible(row) then count=count+1 end
    end
    return count
end

function ac.ClearBatch()
    if not ac.IsAtAH() and ac.DiscardPurchase then ac.DiscardPurchase() end
    ac.batch=nil
    -- Intentionally retain per-row session purchases, never persist to Auction Peek.
    if ac.Notify then ac.Notify() end
end

function ac.BatchSelectAll()
    if ac.pendingPurchase or (ac.batch and ac.batch.waiting) then return false,"Confirm or cancel the current purchase first" end
    ac.batch=nil
    local count=0
    for _,row in ipairs(ac.session.rows or {}) do
        row.acSelected = not row.output and remaining(row)>0 and not row.vendorPreferred and eligible(row)
        if row.acSelected then count=count+1 end
    end
    ac.Notify()
    return count>0,count
end

function ac.BatchToggle(row)
    if not row or row.output or remaining(row)<=0 then return false,"No missing reagent to select" end
    if ac.batch then return false,"Stop the buying queue before changing selections" end
    row.acSelected=not row.acSelected
    ac.Notify()
    return true
end

eligible=function(row)
    return not ac.session.buyList or (not ac.session.buyListInvalid and ac.BuyListReview(row) > 0)
end

local function nextPending(batch)
    for i, entry in ipairs(batch.entries) do
        if not entry.finished and remaining(entry.row)>0 then return i,entry.row end
    end
end

local function buyListSummary(batch)
    local bought, skipped, outstanding = 0, 0, 0
    for _, entry in ipairs(batch.entries) do
        local confirmed = math.max(0, entry.row.acBought - entry.startBought)
        local left = math.max(0, entry.wanted - confirmed)
        bought = bought + confirmed
        if entry.reason then skipped = skipped + left
        else outstanding = outstanding + left end
    end
    return ("Bought %d | %s %s | Skipped %d | Remaining %d"):format(bought,
        batch.estimated and "Est. spent" or "Spent", ac.money(batch.spent or 0), skipped, outstanding)
end

local function reportBuyList(batch)
    ac.announce(buyListSummary(batch))
    for _, entry in ipairs(batch.entries) do
        if entry.reason then ac.announce(entry.row.name .. ": " .. entry.reason) end
    end
end

function ac.StopBuyListQueue()
    local batch = ac.batch
    if not batch then return end
    ac.ClearBatch()
    if batch.buyList then reportBuyList(batch) end
    ac.Status(buyListSummary(batch) .. (ac.pendingPurchase and " | Blizzard confirmation still open." or " | Stopped."))
end

function ac.SkipBuyListOrder(reason)
    local batch = ac.batch
    if not batch or not batch.buyList or ac.pendingPurchase then return end
    local index = nextPending(batch)
    if not index then return end
    batch.entries[index].finished = true
    batch.entries[index].reason = reason or "Skipped manually."
    batch.pendingRow = nil
    local summary = buyListSummary(batch)
    if not nextPending(batch) then ac.batch = nil; reportBuyList(batch) end
    ac.Status(summary .. " | " .. (reason or "Order skipped."))
end

function ac.BatchBeginOrNext(selection, buyList)
    if ac.pendingPurchase then return false,"Finish Blizzard's purchase confirmation first." end
    if buyList and (not ac.session.buyList or ac.session.buyListInvalid) then
        return false, "Scan the selected list before buying."
    end
    if not buyList and ac.session.buyList then return false, "Buy saved items on the Buy List tab." end
    if buyList and ac.batch and not ac.batch.buyList then return false, "Finish the AC search queue first." end
    if not ac.IsAtAH() then return false,"Open the Auction House first" end
    if ac.session.mode~="done" then return false,"Wait until the recipe search is complete" end
    if not ac.batch then
        local entries={}
        for _,row in ipairs(ac.session.rows or {}) do
            local selected = selection and selection[row.itemID] or (not selection and row.acSelected)
            if selected and not row.output and remaining(row)>0 and (buyList or eligible(row)) then
                entries[#entries+1]={row=row, startBought=row.acBought, wanted=remaining(row)}
            end
        end
        if #entries==0 then return false,"Select missing reagents first" end
        ac.batch={entries=entries,waiting=false,buyList=buyList}
    end
    local batch=ac.batch
    if batch.waiting then return false,"Finish Blizzard's purchase confirmation first" end
    while true do
        local index,row=nextPending(batch)
        if not row then
            ac.batch=nil
            if batch.buyList then
                reportBuyList(batch)
                ac.Status(buyListSummary(batch))
            else
                ac.Status("Reagent queue complete. Check your mail for purchased items.")
            end
            return true
        end
        local _, _, reason
        if batch.buyList then _, _, reason = ac.BuyListReview(row) end
        if reason then
            local entry = batch.entries[index]
            entry.finished = true
            if reason ~= "Stocked" and reason ~= "Purchased" then entry.reason = reason
            else entry.wanted = row.acBought - entry.startBought end
        else
            for i, entry in ipairs(ac.session.rows) do
                if entry == row then ac.session.selected = i; break end
            end
            local qty = remaining(row)
            if ac.SetBatchQuantity then ac.SetBatchQuantity(qty) end
            batch.waiting, batch.pendingRow = true, row
            local ok, result, skip = ac.Buy(row, qty, true)
            if ok then
                if ac.pendingPurchase then
                    ac.Status("Step "..index.."/"..#batch.entries..": Confirm "..row.name.." with Blizzard.")
                end
                return true
            end
            batch.waiting, batch.pendingRow = false, nil
            if not skip then return false, result end
            batch.entries[index].finished, batch.entries[index].reason = true, result
        end
    end
end

function ac.OnBatchPurchase(row, quote)
    local batch=ac.batch
    if not batch or not batch.waiting or batch.pendingRow~=row then return false end
    batch.waiting=false
    batch.pendingRow=nil
    if batch.buyList then
        batch.spent = (batch.spent or 0) + quote.total
        batch.estimated = batch.estimated or quote.type == "commodity"
        local _, nextRow = nextPending(batch)
        local summary = buyListSummary(batch)
        if not nextRow then ac.batch = nil; reportBuyList(batch) end
        ac.Status(summary .. (nextRow and " | Press Buy Next." or " | Check mail for delivery."))
        return true
    end
    local index,nextRow=nextPending(batch)
    if nextRow then
        ac.Status("Bought "..tostring(row.name)..". Next: "..tostring(nextRow.name)..". Press Buy Next to continue.")
    else
        ac.batch=nil
        ac.Status("Selected reagents purchased. Check mail for delivery.")
    end
    return true
end

ac.api.GetBatchStatus=function()
    local batch=ac.batch
    return {active=batch~=nil,waiting=batch and batch.waiting or false,remaining=ac.BatchCount()}
end
