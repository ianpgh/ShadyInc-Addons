Auction Companion 1.2.0 for WoW Forever (Interface 16001)

- Open the Buy List tab beside AC. Use the arrows to switch saved lists.
  The name field supports New, Rename and Copy. Delete takes two clicks.
- Add an item by ID or link. For a name, use Add Item to search, then
  right-click the intended result in AC. Add Reagents saves missing auction
  reagents from the current AC recipe search into the active list.
- Edit Qty or Max / unit and press Enter to save. Max accepts prices such as
  2g 15s 5c. A blank maximum leaves the price uncapped.
- Fixed Qty purchases up to the saved quantity. Restock targets that quantity
  using carried bags and confirmed purchases credited for the AH visit.
- Select rows, scan, review the combined estimate, and choose Buy Selected or
  Buy All Selected. Each Buy Next click opens a new Blizzard confirmation.
  Purchased items stay on the list. Partial orders leave the saved target intact.
- Review Blizzard's final price before confirming commodities. AC enforces the
  reviewed plan and cap at the point it requests the native dialog. The client
  and server control any later requote and mail delivery.
- If an order is unresolved, close the AH, check mail and auction activity, and
  use /ac resolve only after reconciling it. Recovery clears a lock, not an order.
- Keep AuctionCompanionDB in SavedVariables. The addon reads existing named
  lists and migrates older flat lists without changing the database identifier.
- Buy List prices stay in the shopping session. AC Live Scan, Full Scan and
  normal tooltip pricing use their existing paths. API contract stays version 1.

Previous releases
-----------------

v1.0.0 — Named Buy Lists, copied legacy flat list data, editable per-item caps,
and per-visit confirmed purchase accounting.

v0.1.24 — Buy List for repeat purchases.
- In the AC tab, select a search result and open Buy List > Add Selected.
- Edit quantities with Save or Enter. X removes an item. Saved quantities are per trip.
- Search List runs the usual live search. Buy and Buy All use Blizzard's purchase confirmations.
- One account-wide list is saved in AuctionCompanionDB. Prices and purchases are session-only.

v0.1.23 — Standalone AC Search button in native profession windows, enabled by default.
- Uses existing SearchRecipe(recipeID, 1); no new AH scanner, cache or purchase behavior.
- Profession AIO's visible integrated button takes priority; no required AIO dependency.
- AC tab > Settings > Show AC Search in profession windows toggles AC's fallback only.
- Native selected-schematic support (including direct enchants), with no searches until clicked at the AH. Linked/guild/NPC recipes are excluded.
- Replace AuctionCompanion only; keep SavedVariables. Native client layout and all supported professions require in-game verification.

v0.1.22 — 456 personal Auctionator vendor purchase observations bundled for tooltip use only; retained AC merchant observations take priority. Reference prices may reflect reputation discounts. No external requests or Auctionator dependency.
v0.1.21 — Known vendor purchase tooltip (gray Vendor Sells); limited stock observations isolated from material costs.

v0.1.15 — Tab and money-display polish
- AC standalone bottom tab now registers through Blizzard tab selection and matches native minimum width/spacing.
- All Auction Companion monetary values use Blizzard coin icons (or equivalent native texture fallback).
- Keeps v0.1.14 item-ID-safe Vendor Archive scan API, full scan, AH-price tooltips and Auctionator coexistence.

Auction Companion v0.1.14 — Unified Vendor Scan + AH Tooltips
- MERGE: Preserves v0.1.13 ItemListScanStart and GetItemListScanQuote APIs, for Auction Peek Vendor Archive's item-ID-aware scan (up to 750 targets).
- MERGE: Adds v0.1.13 tooltip feature from the other development branch as Tooltip.lua (loads once, after Tabs.lua).
- Adds one compact AH-only Auction line from the AC scoped price cache on supported item tooltips. If Auctionator is loaded, the AC line is cyan; no Auctionator edits.
- No vendor prices or historical estimates are substituted as Auction House prices. Missing prices do not get a line.
- AC Full Scan, Writ This's name scan, and Auction Peek's targeted vendor list scan are preserved.
- Existing SavedVariables and Auction Peek remain unchanged. Replace AuctionCompanion addon folder and /reload.

v0.1.13 — Vendor Archive Live Scan API
- Adds AuctionCompanionAPI.StartItemListScan({{itemID=...,name=...}, ...}, label).
- Item-ID-keyed scanner supports up to 750 unique targets in one controlled live browse queue; identical names with different item IDs remain separate.
- GetItemListScanQuote(itemID) returns verified quotes or explicit pending/unverified states, with 30-minute targeted-quote lifetime.
- Read-only scans; respects AH throttling and does not run AC's market-wide Full Scan.
- Existing Writ This StartNameScan / GetNameScanQuote contracts are preserved.

Auction Companion v0.1.5 (WoW Forever)

Changes from v0.1.3:
- Reagent rows with missing quantities are checked and green-highlighted by default.
- Click a row checkbox to include/exclude it; All reselects missing ingredients.
- Buy All starts a guided queue. Each transaction requires a NEW click on Buy Next
  and the standard Blizzard confirmation. No unattended or automatic purchases.
- On purchase success the queue advances to the next selected ingredient, but
  never purchases the next ingredient by itself.
- Already-owned reagents stay visible as Owned and are excluded from buying.
- Profession AIO v1.1.32 moves AC Search to the recipe header above reagents.
- Original standalone Buy button remains for purchasing an individual result.

INSTALL: Replace AuctionCompanion and ProfessionAIO addon folders. Keep
Auctionator installed; all three addons coexist. Backup SavedVariables.

SUPPORTED: Selected recipe ingredient auction searches and in-tab buying.
NOT included: full scan, background bidding, automatic bulk purchases.

NOTES: In-game WoW Forever testing required, especially Blizzard confirmation
events and item auctions sold as stacks. A non-commodity listing may fill only
part of the requested amount; the queue will leave the remainder pending.

Commands: /ac, /ac status, /ac cancel.

0.1.5: recipe profit estimate above search results (all material market values, approx. 5% AH sale fee), widened one-line item names and moved Buy All controls to the search bar. Added a manual Full Scan button on Blizzard's Buy page. Scan uses C_AuctionHouse.ReplicateItems; results are processed across frames and atomically committed to this addon's own SavedVariables only when the whole snapshot is readable. A server cooldown (commonly ~15m across all addons on the account) may prevent a scan immediately after Auctionator. Inspect status with /ac status; read API.GetScannedPrice(itemID) and API.GetScanStatus(). Scan quality and actual purchase results need verification in-game.


v0.1.7: Scan completion dialog reports total auction listings and unique item IDs.
Scan in either the AC header or the Buy page. The shared AH replication cooldown
still applies to AHledger and Auctionator. AC now exposes a read-only per-item
price lookup to Profession AIO; live searched prices expire after 30 minutes,
while completed snapshots remain separate and timestamped.
All-in-one direction: replace the user's desired shopping/market insights from
Auctionator and AHledger incrementally. Existing addons are not yet replaced.

0.1.7: Nonstackable item buyout fix. Previous AC scan prices for nonstackable items
are ignored if they lack the updated format; run an AC recipe search for fresh
prices, then full-scan when the shared AH cooldown allows. Item buyout totals
are separate from commodity per-unit prices.


v0.1.9 Vendor/AH crafting cost setting:
- AC Search > Prices (compact inline toggle). Use vendor prices when cheaper defaults ON.
- AH price search and scan data are never overwritten by a vendor reference.
- Unlimited vendor thread/dye reference list plus player-specific merchant-observed costs.
- The Buy All queue excludes vendor-cheaper reagents by default; manually check one to buy from AH anyway.
- Reference prices may differ due to faction reputation; merchant visits refresh actual price.

0.1.10: Full Scan shared-cooldown and timeout fixes:
- Set up AC's scan state BEFORE calling ReplicateItems to catch synchronous responses.
- Recognize other addons' successful replication updates without reading their prices.
- Read-only check of Auctionator's replication timestamp when Auctionator is loaded.
- Optionally observe other addons' ReplicateItems requests via secure post-hook.
- Never treat a timed-out request as a successful scan or overwrite saved prices.
- Show clear shared-cooldown and no-response diagnostics via /ac scanstatus; /ac scan starts a scan.
- Keep the AC Search, Buy, Buy All and vendor pricing behavior unchanged.
- Real WoW Forever server scan required; addon cannot override the server cooldown.

0.1.11: Full Scan next-available countdown on both the Blizzard Buy and AC tab buttons.
- Buttons are dimmed/disabled while an observed shared cooldown or retry guard remains.
- Button reads Next M:SS and updates automatically, returning to Full Scan when the estimate reaches zero.
- While requesting/processing a scan, buttons remain disabled (Waiting... / Scan NN%).
- Tooltips include an estimated 12-hour ready time and known cooldown source.
- This countdown is based on observed data and cannot see an old scan from AHledger if AC never observed it.
- No changes to buying, pricing, Full Scan requests, or SavedVariables structure.

0.1.12: Standalone auction tab self-anchor fix:
- Select a valid Blizzard tab anchor before creating the AC tab.
- Never anchor AuctionCompanionAHSearchTab to itself.
- Reuse an existing AC button if tab initialization was interrupted.
- No changes to AC Search, prices, purchases, scans, or SavedVariables.
- This fix specifically targets standalone AC usage after Auctionator is disabled.

Auction Companion 1.2.0 changes
------------------------------
- Added graphical selection marks, gold/silver/copper maximum fields, and
  dedicated buying controls below the Buy List table. Press Enter to save a
  row. Tab and Shift-Tab move between quantity and the three price fields.
- Add beside Buy List saves the item ID and typed quantity to the active
  list. Re-adding an item updates its quantity and keeps its copper cap.
- Buy All uses all reviewed rows. Buy Selected uses marked rows. Each
  order still requires a player click and Blizzard confirmation.
- The queue skips unavailable, over-cap, stale, and oversized orders.
  Eligible partial orders use whole fixed-price stacks or available units
  from uncapped commodity listings. Fixed stacks are planned greedily.
- Capped commodities display Cap unavailable and are skipped. The native
  commodity confirmation can reprice without enforcing AC's per-unit cap.
- Queue summaries use confirmed quantities. Commodity spending is estimated
  from the pre-confirmation quote. Review final Blizzard prices and mail.
