local _, ac = ...
-- Read-only, name-verified AH browse scanner for Writ This.
-- Does not buy, bid, post, mutate Auctionator data, or interpret missing listings
-- as a zero-cost item. Uses a single sequential query queue and server throttling.
local AH = C_AuctionHouse
local run, ticker, nextRunID = nil, nil, 0
local lastSent = 0
local MAX_TARGETS = 500
local MAX_ITEM_TARGETS = 750 -- vendor archive list, keyed by item ID
local MAX_RESULTS = 6000
local MAX_PAGES = 35
local QUERY_TIMEOUT = 12
local GAP = .45
local function uptime() return type(GetTime)=='function' and GetTime() or 0 end
local function epoch() return type(time)=='function' and time() or 0 end
local function normalize(name)
    if type(name)~='string' then return nil end
    name=name:gsub('|c%x%x%x%x%x%x%x%x',''):gsub('|r','')
       :gsub('’',"'"):gsub('`',"'"):gsub('^%s+',''):gsub('%s+$',''):gsub('%s+',' ')
    if #name<2 or #name>110 then return nil end
    return name:lower()
end
local function safe(fn,...)
    if type(fn)~='function' then return nil end
    local ok,result=pcall(fn,...)
    if ok then return result end
end
local function bump(message)
    ac.priceRevision=(ac.priceRevision or 0)+1
    if run and message then
        run.message=message
        if ac.session then ac.session.status=message end
        if ac.Notify then ac.Notify() end
    end
end
local function market() return ac.GetMarketScope and ac.GetMarketScope() or nil end
local function active() return run and run.phase=='running' end
ac.IsNameScanBusy=active
local function summary()
    if not run then return nil end
    return {id=run.id,scope=run.scope,label=run.label,phase=run.phase,
        total=run.total,done=run.done,verified=run.verified,
        missing=run.missing,failed=run.failed,
        message=run.message,active=run.active and run.active.phrase or nil,
        startedAt=run.startedAt,completedAt=run.completedAt}
end
local function markResult(target,price,id)
    if not target or not price or price<=0 then return end
    local existing=target.quote
    if existing and existing.price<=price then return end
    local wasMissing=not existing
    target.quote={price=math.floor(price+.5),itemID=id,observedAt=epoch()}
    target.state='verified'
    if wasMissing then
        run.verified=run.verified+1
        run.done=run.done+1
    end
    -- AC's existing scoped live-price store is reused; its normal 30-minute
    -- freshness handling remains unchanged for non-name-scan integrations.
    if type(ac.PublishPrice)=='function' then
        ac.PublishPrice({itemID=id,minUnit=price,minListing=price,state='Ready'})
    end
    bump()
end
local function record(results)
    if type(results)~='table' then return end
    for _,info in ipairs(results) do
        local item=type(info)=='table' and info.itemKey
        local id=type(item)=='table' and tonumber(item.itemID)
        local price=type(info)=='table' and tonumber(info.minPrice)
        local qty=type(info)=='table' and tonumber(info.totalQuantity)
        if id and id>0 and price and price>0 and price<100000000000 and (not qty or qty>0) then
            local n=type(info.itemKeyInfo)=='table' and info.itemKeyInfo.itemName
            if not n and type(GetItemInfo)=='function' then n=safe(GetItemInfo,id) end
            if not n and AH and type(AH.GetItemKeyInfo)=='function' then
                local detail=safe(AH.GetItemKeyInfo,item)
                n=type(detail)=='table' and detail.itemName or nil
            end
            local wanted=normalize(n)
            local keys=wanted and run.byName and run.byName[wanted]
            if keys then
                for _,targetKey in ipairs(keys) do
                    local target=run.targets[targetKey]
                    -- Same-name variants can have different IDs; never borrow
                    -- another variant's price when scanning the vendor list.
                    if run.active.key == targetKey or
                        (run.active.broad and wanted:find("craftsman's writ:",1,true)==1) then
                        if target.itemID==nil or target.itemID==id then
                            local candidates=run.active.candidates
                            local match=candidates[targetKey]
                            if match and match.id~=id then
                                match.ambiguous=true
                            elseif not match or price<match.price then
                                candidates[targetKey]={price=price,id=id,ambiguous=match and match.ambiguous}
                            end
                        else
                            target.mismatch=true
                        end
                    end
                end
            end
        end
    end
end
local function finishTask(reason)
    local task=run and run.active
    if not task then return end
    if task.key then
        local target=run.targets[task.key]
        if target and not target.state then
            if target.mismatch then
                target.state='id-mismatch';run.failed=run.failed+1
            elseif reason=='full' then
                target.state='not-listed';run.missing=run.missing+1
            else
                target.state='unverified';run.failed=run.failed+1
            end
            run.done=run.done+1
        end
    end
    run.active=nil
    run.index=run.index+1
    run.waitingSince=uptime()
    bump(("AC live scan: %d/%d checked (%d priced, %d unresolved)"):format(
        run.done,run.total,run.verified,run.failed))
end
local function finishJob(phase,message)
    if not run then return end
    run.phase=phase
    run.completedAt=epoch()
    run.active=nil
    if ticker then ticker:Cancel();ticker=nil end
    if ac.session and ac.session.mode=='name-scan' then ac.session.mode='done' end
    bump(message)
end
function ac.StopNameScan(message)
    if not active() then return false end
    -- Prices already verified remain visible, but incomplete targets stay
    -- missing rather than falling back to stale quotes within this run.
    for _,t in pairs(run.targets) do
        if not t.state then t.state='cancelled';run.done=run.done+1;run.failed=run.failed+1 end
    end
    finishJob('cancelled',message or 'AC Live Scan cancelled; unverified prices remain missing.')
    return true
end
local function ready()
    if not AH or type(AH.SendBrowseQuery)~='function' then return false end
    if type(AH.IsThrottledMessageSystemReady)=='function' then
        local x=safe(AH.IsThrottledMessageSystemReady)
        if x~=true then return false end
    end
    return uptime()-lastSent>=GAP
end
local function sendTask(task)
    lastSent=uptime()
    task.sent=lastSent
    task.lastCount=-1
    task.lastEvent=lastSent
    task.pages=0
    task.requestedMore=false
    return pcall(AH.SendBrowseQuery,{
        searchString=task.phrase,sorts={},filters={},itemClassFilters={}})
end
local function process()
    if not active() then return end
    if not ac.IsAtAH() then ac.StopNameScan('Auction House closed; partial scan retained.');return end
    local task=run.active
    if not task then return end
    local rows=safe(AH.GetBrowseResults)
    if type(rows)~='table' then return end
    if #rows>MAX_RESULTS then finishTask('truncated');return end
    record(rows)
    local full=safe(AH.HasFullBrowseResults)
    if full==true then
        for key, match in pairs(task.candidates) do
            if not match.ambiguous then markResult(run.targets[key],match.price,match.id)
            else run.targets[key].mismatch=true end
        end
        finishTask('full')
        return
    end
    if #rows~=task.lastCount then
        task.lastCount=#rows
        task.lastEvent=uptime()
        task.requestedMore=false
    end
    -- Some Forever builds cannot report whether their result page is complete.
    -- Never infer an empty market from a partial page. Prices that match an
    -- exact name remain valid, while unresolved names will stay unverified.
    if full==false and type(AH.RequestMoreBrowseResults)=='function' and
        #rows>0 and task.pages<MAX_PAGES and not task.requestedMore and ready() then
        local ok=pcall(AH.RequestMoreBrowseResults)
        if ok then
            task.pages=task.pages+1
            task.requestedMore=true
            lastSent=uptime()
        end
    end
end
local function poll()
    if not active() then
        if ticker then ticker:Cancel();ticker=nil end
        return
    end
    if not ac.IsAtAH() then ac.StopNameScan('Auction House closed; scan interrupted.');return end
    local task=run.active
    if task then
        if uptime()-task.sent>QUERY_TIMEOUT then
            -- Timeout/partial/unsupported pagination is never "no listing".
            finishTask('timeout')
        elseif task.sent and task.requestedMore and uptime()-task.lastEvent>5 then
            finishTask('partial')
        elseif task.lastCount and task.lastCount>=0 and not task.requestedMore and ready() then
            -- Additional pages must be requested once the client throttle clears;
            -- that usually happens AFTER the browse-results event has fired.
            process()
        end
        return
    end
    while run.index<=#run.tasks do
        task=run.tasks[run.index]
        if task.key and run.targets[task.key].state=='verified' then
            run.index=run.index+1
        else break end
    end
    if run.index>#run.tasks then
        local phase=run.failed>0 and 'partial' or 'complete'
        finishJob(phase,("AC Live Scan %s: %d/%d price matches, %d not listed, %d unverified."):
            format(phase,run.verified,run.total,run.missing,run.failed))
        return
    end
    if not ready() then
        if uptime()-run.waitingSince>25 then
            for _, target in pairs(run.targets) do
                if not target.state then
                    target.state='unverified'
                    run.failed=run.failed+1
                    run.done=run.done+1
                end
            end
            finishJob('partial','AC Live Scan stopped waiting for the server. Verified quotes were retained.')
        end
        return
    end
    task=run.tasks[run.index]
    -- Set current task before sending, since the AH can fire synchronous events.
    run.active=task
    task.candidates={}
    task.sent=uptime()
    local ok,err=sendTask(task)
    if not ok then
        finishTask('error')
        bump('AC browse rejected: '..tostring(err))
    else
        bump(("AC Live Scan %d/%d: %s"):format(run.done,run.total,task.phrase))
    end
end
local frame=CreateFrame('Frame')
for _,event in ipairs({'AUCTION_HOUSE_BROWSE_RESULTS_UPDATED','AUCTION_HOUSE_BROWSE_RESULTS_ADDED',
    'AUCTION_HOUSE_BROWSE_FAILURE','AUCTION_HOUSE_CLOSED'}) do
    pcall(frame.RegisterEvent,frame,event)
end
frame:SetScript('OnEvent',function(_,event)
    if not active() then return end
    if event=='AUCTION_HOUSE_CLOSED' then ac.StopNameScan('Auction House closed; scan cancelled.');return end
    if not run.active then return end
    if event=='AUCTION_HOUSE_BROWSE_FAILURE' then finishTask('error');return end
    process()
end)

local function startNameScan(names,label,byItemID)
    if not ac.IsAtAH() then return false,'Open the Auction House first.' end
    if not AH or type(AH.SendBrowseQuery)~='function' or type(AH.GetBrowseResults)~='function' then
        return false,'This client does not support AH name browse searches.'
    end
    if active() then return false,'An AC Live Scan is already running.' end
    if ac.session and (ac.session.mode=='searching' or ac.session.mode=='browse') then
        return false,'Finish the current AC search first.'
    end
    if ac.scanState and (ac.scanState.phase=='requesting' or ac.scanState.phase=='receiving') then
        return false,'Wait for AC Full Scan to finish.'
    end
    if ac.pendingPurchase or ac.batch then return false,'Finish the pending AH purchase first.' end
    if type(names)~='table' then return false,'Expected a list of item names.' end
    local targets,order,byName={},{},{}
    for _,entry in ipairs(names) do
        local name=type(entry)=='table' and entry.name or entry
        local normalized=normalize(name)
        local id=type(entry)=='table' and tonumber(entry.itemID) or nil
        if byItemID and (not id or id<=0 or id~=math.floor(id)) then
            return false,'Vendor scan requires a valid item ID for each name.'
        end
        local key=byItemID and id and ('id:'..id) or normalized
        if normalized and key and not targets[key] then
            targets[key]={name=name,itemID=id and id>0 and id or nil}
            byName[normalized]=byName[normalized] or {}
            byName[normalized][#byName[normalized]+1]=key
            order[#order+1]=key
            local limit=byItemID and MAX_ITEM_TARGETS or MAX_TARGETS
            if #order>limit then return false,('Scan limited to %d items. Narrow the vendor list filters.'):format(limit) end
        end
    end
    if #order==0 then return false,'No valid item names.' end
    nextRunID=nextRunID+1
    local tasks,sharedWrit={},0
    for _,key in ipairs(order) do
        if key:find("craftsman's writ:",1,true)==1 then sharedWrit=sharedWrit+1 end
    end
    -- One broad prefix search can cover many writs. Request all result pages;
    -- then search any unresolved writs individually to avoid a first-page bias.
    if not byItemID and sharedWrit>=10 then
        tasks[#tasks+1]={phrase="Craftsman's Writ:",broad=true}
    end
    for _,key in ipairs(order) do
        tasks[#tasks+1]={phrase=targets[key].name,key=key}
    end
    run={id=nextRunID,label=tostring(label or 'Name price scan'),scope=market(),
        phase='running',targets=targets,byName=byName,byItemID=byItemID==true,
        tasks=tasks,index=1,total=#order,
        done=0,verified=0,missing=0,failed=0,startedAt=epoch(),waitingSince=uptime(),message='Queued'}
    ac.session={rows={},mode='name-scan',label=run.label,
        selected=nil,status=("AC Live Scan queued: %d names"):format(#order)}
    bump(ac.session.status)
    if ticker then ticker:Cancel() end
    if C_Timer and type(C_Timer.NewTicker)=='function' then
        ticker=C_Timer.NewTicker(.2,poll)
    else
        -- Fallback for custom clients without C_Timer.NewTicker.
        frame:SetScript('OnUpdate',function(self,elapsed)
            self.elapsed=(self.elapsed or 0)+(elapsed or 0)
            if self.elapsed>=.2 then self.elapsed=0;poll() end
            if not active() then self:SetScript('OnUpdate',nil) end
        end)
    end
    poll()
    return true
end
function ac.NameScanStart(names,label) return startNameScan(names,label,false) end
function ac.ItemListScanStart(items,label) return startNameScan(items,label,true) end
ac.api.StartNameScan=ac.NameScanStart
-- Item-ID-safe, bounded live scan for external vendor archives. This uses
-- only the supplied list; it does NOT invoke AC's market-wide Full Scan.
ac.api.StartItemListScan=ac.ItemListScanStart
ac.api.GetItemListScanQuote=function(itemID)
    local id=tonumber(itemID)
    local key=id and 'id:'..id
    if not run or not run.byItemID or not key or not run.targets[key] or run.scope~=market() then
        return nil,nil,nil,'not-in-scan'
    end
    if run.completedAt and epoch()>run.completedAt+1800 then
        return nil,id,nil,'not-in-scan'
    end
    local target=run.targets[key]
    if target.quote then
        return target.quote.price,id,target.quote.observedAt,'verified'
    end
    return nil,id,nil,target.state or 'pending'
end
ac.api.CancelNameScan=ac.StopNameScan
ac.api.GetNameScanStatus=summary
ac.api.GetNameScanQuote=function(name)
    local key=normalize(name)
    if not run or not key or not run.targets[key] or run.scope~=market() then
        return nil,nil,nil,'not-in-scan'
    end
    -- A previous name-scan cannot supersede a newer AC snapshot forever.
    -- After 30 minutes, callers revert to their regular AC cached-price policy.
    if run.completedAt and epoch()>run.completedAt+1800 then
        return nil,nil,nil,'not-in-scan'
    end
    local t=run.targets[key]
    if t.quote then
        return t.quote.price,t.quote.itemID,t.quote.observedAt,'verified'
    end
    return nil,t.itemID,nil,t.state or 'pending'
end
ac.api.GetNameScanTargets=function()
    if not run then return nil end
    local counts={}
    for _,t in pairs(run.targets) do
        local key=t.state or 'pending'; counts[key]=(counts[key] or 0)+1
    end
    return counts
end
