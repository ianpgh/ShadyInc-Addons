local _, ac = ...

local MAX_ITEMS = 60
local MAX_LISTS = 30
local trips = {}

local function integer(value, maximum)
    local number = tonumber(value)
    if number and number >= 1 and number <= maximum and number == math.floor(number) then
        return number
    end
end

local function entriesFrom(saved)
    local entries, seen = {}, {}
    if type(saved) ~= "table" then return entries end
    local positions = {}
    for position in pairs(saved) do
        if type(position) == "number" and position >= 1 and position == math.floor(position) then
            positions[#positions + 1] = position
        end
    end
    table.sort(positions)
    for _, position in ipairs(positions) do
        local entry = saved[position]
        if type(entry) == "table" then
            local id = integer(entry.itemID, 9999999)
            local quantity = integer(entry.required, 99999)
            if id and quantity and not seen[id] then
                local copy = {}
                for k, v in pairs(entry) do copy[k] = v end
                copy.itemID, copy.required = id, quantity
                copy.maxUnit = integer(entry.maxUnit, 9999999999)
                entries[#entries + 1] = copy
                seen[id] = true
                if #entries == MAX_ITEMS then break end
            end
        end
    end
    return entries
end

function ac.InitBuyLists()
    if not ac.db then return end
    local saved = ac.db.shoppingLists
    if type(saved) ~= "table" then
        saved = {}
        ac.db.shoppingLists = saved
    end
    local positions, activeIndex = {}, nil
    for position, list in pairs(saved) do
        if integer(position, 99999999) and type(position) == "number" and type(list) == "table" then
            positions[#positions + 1] = position
        end
    end
    table.sort(positions)
    if #positions == 0 then
        if next(saved) and ac.db.legacyShoppingLists == nil then ac.db.legacyShoppingLists = saved end
        if next(saved) then saved = {}; ac.db.shoppingLists = saved end
        saved[1] = {name = "Buy List", items = entriesFrom(ac.db.buyList)}
    else
        local active = tonumber(ac.db.activeShoppingList)
        local compact = false
        for index, position in ipairs(positions) do
            if index ~= position then compact = true end
            if position == active then activeIndex = index end
        end
        if compact or #positions ~= #saved then
            -- Retain the original sparse records, including malformed values, for recovery.
            if ac.db.legacyShoppingLists == nil then ac.db.legacyShoppingLists = saved end
            local repaired = {}
            for key, value in pairs(saved) do
                if type(key) ~= "number" then repaired[key] = value end
            end
            for index, position in ipairs(positions) do repaired[index] = saved[position] end
            ac.db.shoppingLists = repaired
        end
    end
    ac.db.activeShoppingList = activeIndex or 1
    -- The existing named-list schema stays in place. Missing mode preserves v1.0 restocking.
    ac.db.buyListRestock = ac.db.buyListRestock ~= false
    if ac.db.unresolvedPurchase ~= true then ac.db.unresolvedPurchase = nil end
end

function ac.BuyListNames()
    local names = {}
    for i, list in ipairs(ac.db.shoppingLists) do
        names[i] = type(list) == "table" and type(list.name) == "string" and list.name or ("List " .. i)
    end
    return names, ac.db.activeShoppingList
end

function ac.BuyListBusy()
    return ac.batch or ac.pendingPurchase or
        (ac.session.buyList and ac.session.mode == "searching")
end

local function invalidateScan()
    if ac.session.buyList then ac.session.buyListInvalid = true end
    trips = {}
end

function ac.SetBuyListRestock(restock)
    if ac.BuyListBusy() then return end
    ac.db.buyListRestock = restock == true
    invalidateScan()
end

function ac.SelectBuyList(index)
    if ac.BuyListBusy() then return end
    invalidateScan()
    ac.db.activeShoppingList = integer(index, #ac.db.shoppingLists) or ac.db.activeShoppingList
end

local function activeList()
    local index = ac.db.activeShoppingList
    local list = ac.db.shoppingLists[index]
    if type(list) ~= "table" then
        list = {name = "List " .. index, items = {}}
        ac.db.shoppingLists[index] = list
    end
    return list
end

function ac.EditBuyList(action, name)
    if ac.BuyListBusy() then return nil, "Finish the current operation first." end
    local lists = ac.db.shoppingLists
    local active = ac.db.activeShoppingList
    if action == "delete" then
        invalidateScan()
        table.remove(lists, active)
        if #lists == 0 then lists[1] = {name = "Buy List", items = {}} end
        ac.db.activeShoppingList = math.min(active, #lists)
        return true
    end
    name = type(name) == "string" and name:match("^%s*(.-)%s*$") or ""
    if name == "" or #name > 40 or name:find("|", 1, true) then
        return nil, "Enter a list name of 1–40 bytes without a pipe."
    end
    for i, existing in ipairs(ac.BuyListNames()) do
        if existing:lower() == name:lower() and (action ~= "rename" or i ~= active) then
            return nil, "That list name is already in use."
        end
    end
    if action == "rename" then
        activeList().name = name
        if ac.session.buyList then ac.session.label = name end
    else
        if action ~= "new" and action ~= "duplicate" then return nil, "Unknown list action." end
        if #lists >= MAX_LISTS then return nil, "You can save up to 30 lists." end
        local copy = {name = name, items = {}}
        if action == "duplicate" then
            for key, value in pairs(activeList()) do
                if key ~= "name" and key ~= "items" then copy[key] = value end
            end
            local items = activeList().items
            if type(items) == "table" then
                for key, entry in pairs(items) do
                    if type(entry) == "table" then
                        local entryCopy = {}
                        for field, value in pairs(entry) do entryCopy[field] = value end
                        copy.items[key] = entryCopy
                    else copy.items[key] = entry end
                end
            end
        end
        lists[#lists + 1] = copy
        ac.db.activeShoppingList = #lists
        invalidateScan()
    end
    return true
end

function ac.GetBuyList()
    if not ac.db then return {} end
    return entriesFrom(activeList().items)
end

function ac.BuyListOwned(itemID)
    local count = GetItemCount or (C_Item and C_Item.GetItemCount)
    if type(count) ~= "function" then return nil end
    local ok, value = pcall(count, itemID, false, false, false)
    if ok and type(value) == "number" and value >= 0 and value < math.huge then
        return math.floor(value)
    end
end

-- Confirmed AH purchases may be in mail. Until mail attribution is available,
-- conservatively count the larger of actual bags and the visit's covered stock.
function ac.RestockNeed(required, owned, trip)
    if owned == nil then return nil end
    local covered = owned
    if trip and trip.confirmed > 0 then
        covered = math.max(owned, trip.startingOwned + trip.confirmed)
    end
    return math.max(0, required - covered)
end

function ac.BuyListTargetNeed(entry, owned)
    if not ac.db.buyListRestock then return entry.required end
    local trip = trips[activeList()]
    return ac.RestockNeed(entry.required, owned, trip and trip[entry.itemID])
end

function ac.SaveBuyListItem(itemID, quantity, maxUnit, onlyNew)
    if not ac.db then return nil, "Buy List is unavailable." end
    if ac.BuyListBusy() then return nil, "Finish the current operation first." end
    if type(itemID) == "string" then itemID = itemID:match("|Hitem:(%d+)") or itemID end
    itemID = integer(itemID, 9999999)
    if not itemID then return nil, "Enter an item ID or paste an item link." end
    quantity = integer(quantity, 99999)
    if not quantity then return nil, "Enter a quantity from 1 to 99,999." end
    if maxUnit ~= nil and maxUnit ~= "" then
        maxUnit = integer(maxUnit, 9999999999)
        if not maxUnit then return nil, "Enter the maximum unit price in copper." end
    else
        maxUnit = nil
    end
    local entries = ac.GetBuyList()
    local index
    for i, entry in ipairs(entries) do
        if entry.itemID == itemID then index = i; break end
    end
    if index and onlyNew then return index end
    if not index and #entries >= MAX_ITEMS then return nil, "Buy List holds up to 60 items." end
    index = index or (#entries + 1)
    local saved = activeList().items
    if type(saved) ~= "table" then saved = {}; activeList().items = saved end
    local position
    for key, value in pairs(saved) do
        if type(key) == "number" and type(value) == "table" and tonumber(value.itemID) == itemID and
            (not position or key < position) then position = key end
    end
    if not position then
        position = 1
        for key in pairs(saved) do
            if type(key) == "number" and key >= position and key == math.floor(key) and key < math.huge then
                position = key + 1
            end
        end
        saved[position] = {}
    end
    saved[position].itemID, saved[position].required, saved[position].maxUnit = itemID, quantity, maxUnit
    invalidateScan()
    return index
end

function ac.AddSearchItemToBuyList(itemID, quantity)
    for _, entry in ipairs(ac.GetBuyList()) do
        if entry.itemID == itemID then
            return ac.SaveBuyListItem(itemID, quantity, entry.maxUnit)
        end
    end
    return ac.SaveBuyListItem(itemID, quantity)
end

function ac.RemoveBuyListItem(itemID)
    if ac.BuyListBusy() then return end
    local saved = activeList().items
    if type(saved) ~= "table" then return end
    for key, value in pairs(saved) do
        if type(key) == "number" and type(value) == "table" and tonumber(value.itemID) == itemID then
            saved[key] = nil
        end
    end
    invalidateScan()
end

function ac.SaveRecipeToBuyList()
    if ac.BuyListBusy() then return nil, "Finish the current operation first." end
    if not ac.session.recipe or ac.session.mode ~= "done" then return nil, "Search for a recipe first." end
    local entries, byID = ac.GetBuyList(), {}
    for _, entry in ipairs(entries) do byID[entry.itemID] = entry end
    local added = 0
    for _, row in ipairs(ac.session.rows) do
        if not row.output and ac.BatchRemaining(row) > 0 and not row.vendorPreferred then
            local entry = byID[row.itemID]
            if entry then
                entry.required = math.max(entry.required, row.required)
            else
                if #entries >= MAX_ITEMS then return nil, "This recipe exceeds the 60-item list limit." end
                entry = {itemID = row.itemID, required = row.required}
                entries[#entries + 1] = entry
                byID[row.itemID] = entry
            end
            added = added + 1
        end
    end
    if added == 0 then return nil, "No missing auction reagents." end
    for _, entry in ipairs(entries) do
        ac.SaveBuyListItem(entry.itemID, entry.required, entry.maxUnit)
    end
    return added
end

function ac.ClearShoppingTrips()
    trips = {}
end

function ac.RecordShoppingPurchase(row, quantity, coveredBefore)
    if row.trip then
        if coveredBefore then row.trip.startingOwned = math.max(0, coveredBefore - row.trip.confirmed) end
        row.trip.confirmed = row.trip.confirmed + quantity
    end
end

function ac.SearchBuyList(selection)
    if ac.BuyListBusy() or ac.session.mode == "searching" or ac.session.mode == "browse" then return false, "Finish or stop the current buying queue first." end
    local entries = {}
    local list = activeList()
    local trip = trips[list] or {}
    for _, entry in ipairs(ac.GetBuyList()) do
        if selection == nil or selection[entry.itemID] then
            entry.restock = ac.db.buyListRestock
            entry.owned = 0
            if entry.restock then
                entry.owned = ac.BuyListOwned(entry.itemID)
                if entry.owned == nil then return false, "Could not read bag quantity for " .. ac.itemName(entry.itemID) .. "." end
            end
            entry.trip = trip[entry.itemID] or {startingOwned = entry.owned, confirmed = 0}
            if entry.trip.confirmed == 0 then entry.trip.startingOwned = entry.owned end
            trip[entry.itemID] = entry.trip
            entries[#entries + 1] = entry
        end
    end
    if #entries == 0 then return false, "Select saved items to scan." end
    local names, index = ac.BuyListNames()
    local ok, reason = ac.SearchItems(entries, names[index], true)
    if ok then
        trips[list] = trip
        if ac.SetBatchQuantity then ac.SetBatchQuantity(ac.BatchRemaining(ac.session.rows[1])) end
    end
    return ok, reason
end
