local _, ac = ...
-- Uses the shared LibAHTab contract when present (including with Auctionator).
-- A standalone Blizzard tab is used when the shared library is not installed.
-- Neither path alters Auctionator source or SavedVariables.
local TAB_ID = "AuctionCompanion_RecipeSearch"
local tab, buyTab, sharedLib, hooked, lastHouse
local BUY_TAB_ID = "AuctionCompanion_BuyList"

local function getSharedLib()
    if not LibStub then return nil end
    local ok, lib = pcall(LibStub, "LibAHTab-1-0", true)
    if ok and type(lib)=="table" and type(lib.CreateTab)=="function" and
        type(lib.SetSelected)=="function" then return lib end
end

local function deselect(tabButton)
    if tabButton and type(PanelTemplates_DeselectTab)=="function" then
        PanelTemplates_DeselectTab(tabButton)
    end
end

local function select(tabButton)
    if tabButton and type(PanelTemplates_SelectTab)=="function" then
        PanelTemplates_SelectTab(tabButton)
    end
end

-- Blizzard selects tabs by their parent index, not merely by setting a
-- highlight on one button.  Registering our standalone tab fixes the old
-- state where Buy remained yellow while the AC page was visible.
local function registerStandaloneTab(ah, ownTab)
    if not (ah and type(ah.Tabs)=="table" and ownTab) then return nil end
    local index
    for i,candidate in ipairs(ah.Tabs) do
        if candidate==ownTab then index=i;break end
    end
    if not index then
        index=#ah.Tabs+1
        ah.Tabs[index]=ownTab
    end
    if type(ownTab.SetID)=="function" then ownTab:SetID(index) end
    if type(PanelTemplates_SetNumTabs)=="function" then
        PanelTemplates_SetNumTabs(ah,#ah.Tabs)
    end
    return index
end

-- Find the last valid tab without ever choosing our own tab as its anchor.
-- Some Forever AH templates register a new tab in ah.Tabs during CreateFrame,
-- so selecting ah.Tabs[#ah.Tabs] AFTER creation may select the new tab itself.
local function findStandaloneAnchor(ah, ownTab)
    if type(ah.Tabs)=="table" then
        for i=#ah.Tabs,1,-1 do
            local candidate=ah.Tabs[i]
            if candidate and candidate~=ownTab and candidate~=ah and
                (not candidate.IsObjectType or candidate:IsObjectType("Button")) then
                return candidate
            end
        end
    end
    if ah.AuctionsTab and ah.AuctionsTab~=ownTab then return ah.AuctionsTab end
    if ah.SellTab and ah.SellTab~=ownTab then return ah.SellTab end
    if ah.BuyTab and ah.BuyTab~=ownTab then return ah.BuyTab end
end

-- Blizzard integration for users who later uninstall Auctionator.
local function selectStandalone(showBuyList)
    local ah = AuctionHouseFrame
    if not (ah and tab and ac.window) then return false end
    if InCombatLockdown and InCombatLockdown() then
        ac.announce("Auction tab unavailable during combat.")
        return false
    end
    if type(ah.SetDisplayMode)=="function" then
        ah:SetDisplayMode({})
        ah.displayMode=nil
    end
    local target = showBuyList and buyTab or tab
    local index=registerStandaloneTab(ah,target)
    if index and type(PanelTemplates_SetTab)=="function" then
        PanelTemplates_SetTab(ah,index)
    else
        for _,native in ipairs(ah.Tabs or {}) do deselect(native) end
        select(target)
    end
    deselect(showBuyList and tab or buyTab)
    if type(ah.SetTitle)=="function" then
        ah:SetTitle(showBuyList and "Auction Companion - Buy List" or "Auction Companion - Search")
    end
    ac.window:SetShown(not showBuyList)
    if ac.buyWindow then ac.buyWindow:SetShown(showBuyList == true) end
    return true
end

local function attachSearchTab()
    local ah=AuctionHouseFrame
    if not ah or not ah.Tabs or #ah.Tabs==0 then return false end
    if not ac.window and not ac.BuildUI() then return false end
    -- If an earlier initialization failed while anchoring, keep the tab and
    -- repair it rather than constructing a second named UI object.
    if tab and lastHouse==ah and (not tab.GetNumPoints or tab:GetNumPoints()>0) then
        return true
    end

    local lib=getSharedLib()
    if lib then
        local ok, err=pcall(function()
            if not (lib.DoesIDExist and lib:DoesIDExist(TAB_ID)) then
                lib:CreateTab(TAB_ID, ac.window, "AC", "Auction Companion - Search")
            end
            tab=lib:GetButton(TAB_ID)
            -- Native tab height/texture/font is inherited from LibAHTab.
            -- Keep a narrow label because Forever has crowded AH tab rows.
            if tab and type(PanelTemplates_TabResize)=="function" then
                PanelTemplates_TabResize(tab,0,nil,86)
            end
        end)
        if ok and tab then
            sharedLib=lib
            lastHouse=ah
            tab:SetScript("OnEnter",function(self)
                GameTooltip:SetOwner(self,"ANCHOR_TOP")
                GameTooltip:AddLine("Auction Companion",1,.82,.28)
                GameTooltip:AddLine("Auction searches and Profession AIO reagents",.88,.88,.88)
                GameTooltip:Show()
            end)
            tab:SetScript("OnLeave",function()GameTooltip:Hide()end)
            return true
        end
        ac.announce("Shared auction tab registration failed: " .. tostring(err))
        return false
    end

    -- Capture the anchor BEFORE constructing the new tab: the template can
    -- append the new tab to ah.Tabs synchronously.
    local anchor=findStandaloneAnchor(ah, tab)
    if not anchor then
        ac.announce("Cannot attach AC tab: no Blizzard auction tab anchor found.")
        return false
    end
    local existing=_G.AuctionCompanionAHSearchTab
    if existing and (not existing.GetParent or existing:GetParent()~=ah) then
        ac.announce("Cannot attach AC tab: an old tab belongs to another frame.")
        return false
    end
    tab=existing or CreateFrame("Button", "AuctionCompanionAHSearchTab", ah,"AuctionHouseFrameDisplayModeTabTemplate")
    -- Re-check after CreateFrame in case the UI registered the tab immediately.
    if anchor==tab then anchor=findStandaloneAnchor(ah,tab) end
    if not anchor or anchor==tab then
        ac.announce("Cannot attach AC tab: invalid auction tab anchor.")
        return false
    end
    tab:SetText("AC")
    -- Native tabs have a consistent minimum size.  Preserve the short label
    -- but give AC the same clickable width as neighboring Blizzard tabs.
    if type(PanelTemplates_TabResize)=="function" then PanelTemplates_TabResize(tab,0,nil,86) end
    tab:ClearAllPoints()
    local spacing=-10
    -- Use the previous Blizzard tab-to-tab spacing where possible.
    if type(anchor.GetPoint)=="function" then
        local _,_,relativePoint,x = anchor:GetPoint(1)
        if (relativePoint=="TOPRIGHT" or relativePoint=="RIGHT") and type(x)=="number" then
            spacing=x
        end
    end
    tab:SetPoint("TOPLEFT",anchor,"TOPRIGHT",spacing,0)
    registerStandaloneTab(ah,tab)
    tab:SetScript("OnClick",function() selectStandalone(false) end)
    tab:SetScript("OnEnter",function(self)
        GameTooltip:SetOwner(self,"ANCHOR_TOP")
        GameTooltip:AddLine("Auction Companion",1,.82,.28)
        GameTooltip:AddLine("Recipe materials and auction search",.88,.88,.88)
        GameTooltip:Show()
    end)
    tab:SetScript("OnLeave",function()GameTooltip:Hide()end)
    deselect(tab)
    sharedLib=nil
    lastHouse=ah
    if not hooked and type(ah.SetDisplayMode)=="function" and hooksecurefunc then
        hooksecurefunc(ah,"SetDisplayMode",function(_,mode)
            if mode ~= nil and (type(mode)~="table" or next(mode)~=nil) then
                if ac.window then ac.window:Hide() end
                deselect(tab)
                if ac.buyWindow then ac.buyWindow:Hide() end
                deselect(buyTab)
            end
        end)
        hooked=true
    end
    return true
end

function ac.AttachTab()
    if not attachSearchTab() then return false end
    if buyTab then return true end
    local ah = AuctionHouseFrame
    local panel = ac.BuildBuyList()
    if sharedLib then
        local ok, err = pcall(function()
            if not (sharedLib.DoesIDExist and sharedLib:DoesIDExist(BUY_TAB_ID)) then
                sharedLib:CreateTab(BUY_TAB_ID, panel, "Buy List", "Auction Companion - Buy List")
            end
            buyTab = sharedLib:GetButton(BUY_TAB_ID)
        end)
        if not ok then ac.announce("Buy List tab registration failed: " .. tostring(err)) end
        return buyTab ~= nil
    end
    buyTab = CreateFrame("Button", "AuctionCompanionAHBuyListTab", ah, "AuctionHouseFrameDisplayModeTabTemplate")
    buyTab:SetText("Buy List")
    if PanelTemplates_TabResize then PanelTemplates_TabResize(buyTab,0,nil,86) end
    local _, _, _, spacing = tab:GetPoint(1)
    buyTab:ClearAllPoints()
    buyTab:SetPoint("TOPLEFT", tab, "TOPRIGHT", spacing or -10, 0)
    registerStandaloneTab(ah,buyTab)
    buyTab:SetScript("OnClick", function() selectStandalone(true) end)
    deselect(buyTab)
    return true
end

function ac.SelectBuyTab()
    if not ac.IsAtAH() or not ac.AttachTab() then return false end
    if sharedLib then
        local ok, err = pcall(sharedLib.SetSelected, sharedLib, BUY_TAB_ID)
        if not ok then ac.announce("Cannot select Buy List: " .. tostring(err)) end
        return ok
    end
    return selectStandalone(true)
end

function ac.SelectTab()
    if not attachSearchTab() then
        ac.announce("Auction Companion tab is not ready.")
        return false
    end
    if sharedLib then
        local ok, err=pcall(sharedLib.SetSelected,sharedLib,TAB_ID)
        if not ok then ac.announce("Cannot select search tab: "..tostring(err)); return false end
        return true
    end
    return selectStandalone()
end
