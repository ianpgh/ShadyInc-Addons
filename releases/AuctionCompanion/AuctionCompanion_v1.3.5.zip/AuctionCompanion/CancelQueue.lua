local _, ac = ...
-- Native All Auctions enhancement. Session-only; never writes another addon's data.
local selected, queue, pending, anchor = {}, nil, nil, nil
local confirmed, skipped, message, fresh = 0, 0, "", false
local panel, list, controls, boxes, timer = nil, nil, nil, {}, 0
local diagnostic = "Waiting for owned auctions."
local function readable(v)
    return not (issecretvalue and issecretvalue(v))
end
local function call(fn, ...)
    if type(fn) ~= "function" then return nil end
    local ok, v = pcall(fn, ...)
    if ok and readable(v) then return v end
end
local function now() return GetTime() end
local function ah() return C_AuctionHouse end
local function idOf(row)
    if not readable(row) or type(row) ~= "table" then return end
    local id = row.auctionID
    if readable(id) and type(id)=="number" and id>0 then return id end
end
local function keyOf(row)
    local k = row.itemKey
    if not readable(k) or type(k)~="table" then return end
    local parts = {k.itemID,k.itemLevel,k.itemSuffix,k.battlePetSpeciesID}
    if not readable(parts[1]) or type(parts[1])~="number" then return end
    for i=1,4 do
        if not readable(parts[i]) then return end
        parts[i]=tostring(parts[i] or 0)
    end
    return table.concat(parts,":")
end
local function statusOf(row)
    if not readable(row) or type(row)~="table" or not readable(row.status) then return nil end
    return row.status
end
local function active(row)
    local status = Enum and Enum.AuctionStatus and Enum.AuctionStatus.Active or 0
    return idOf(row)~=nil and statusOf(row)==status
end
local function sold(row)
    local status = Enum and Enum.AuctionStatus and Enum.AuctionStatus.Sold or 1
    return statusOf(row)==status
end
local function eligible(row)
    if not active(row) then return false end
    -- Bid-bearing auctions may have a cancellation fee; leave them to the
    -- original Blizzard button/confirmation. Near-expiry returns are ambiguous.
    if not readable(row.bidAmount) or (row.bidAmount~=nil and type(row.bidAmount)~="number")
        or (row.bidAmount or 0)>0 then return false end
    if not readable(row.bidder) or (row.bidder~=nil and row.bidder~="" and row.bidder~=false) then return false end
    if not readable(row.timeLeftSeconds) or (type(row.timeLeftSeconds)=="number" and row.timeLeftSeconds<=60) then return false end
    local A=ah()
    return A and call(A.CanCancelAuction,idOf(row))==true
end
local function owned()
    local A=ah()
    if not A then diagnostic="Auction API unavailable."; return end
    local full=call(A.HasFullOwnedAuctionResults)
    if not fresh and full~=true then diagnostic="Waiting for auction data; click Refresh."; return end
    local map, order, blocked = {}, {}, {}
    local ignored, invalid = 0, 0
    local function add(row)
        -- Sold/payment rows are not cancellable, and may have no usable ID.
        if sold(row) then ignored=ignored+1; return end
        local id=idOf(row)
        if not id or not active(row) then invalid=invalid+1; return end
        if map[id] or blocked[id] then
            map[id]=nil; blocked[id]=true; invalid=invalid+1; return
        end
        map[id]=row; order[#order+1]=id
    end
    -- Use the same indexed provider as Blizzard's All Auctions list.
    -- The bulk table need not contain exactly the same rows or ordering.
    local n=call(A.GetNumOwnedAuctions)
    local source="indexed"
    if type(n)=="number" and n>=0 and n==math.floor(n) and type(A.GetOwnedAuctionInfo)=="function" then
        for i=1,n do add(call(A.GetOwnedAuctionInfo,i)) end
    else
        source="bulk"
        local rows=call(A.GetOwnedAuctions)
        if type(rows)~="table" then diagnostic="Owned-auction data unavailable; click Refresh."; return end
        for _,row in ipairs(rows) do add(row) end
    end
    local clean={}
    for _,id in ipairs(order) do if map[id] then clean[#clean+1]=id end end
    -- A full, readable list is required to infer absence after cancellation.
    local complete=full==true and invalid==0
    diagnostic=("%s: %d active, %d sold, %d unreadable; full=%s"):format(source,#clean,ignored,invalid,tostring(full))
    return map,clean,complete
end
local function shown()
    return panel and list and panel:IsVisible() and list:IsVisible()
        and panel.CancelAuctionButton and panel.CancelAuctionButton:IsVisible()
        and ac.IsAtAH()
end
local function count()
    local n=0; for _ in pairs(selected) do n=n+1 end; return n
end
local function clear(msg)
    selected,queue,anchor={},nil,nil
    message=msg or ""; confirmed,skipped=0,0
end
local function stop(msg)
    queue=nil; selected={}; anchor=nil
    message=msg or "Stopped."
end
local function busy()
    local mode=ac.session and ac.session.mode
    return ac.pendingPurchase or ac.batch or mode=="searching" or mode=="browse" or mode=="name-scan"
        or (ac.scanState and (ac.scanState.phase=="requesting" or ac.scanState.phase=="receiving"))
end
local function ready()
    local A=ah()
    return A and type(A.CancelAuction)=="function" and type(A.CanCancelAuction)=="function"
        and (not A.IsThrottledMessageSystemReady or call(A.IsThrottledMessageSystemReady)==true)
        and not (InCombatLockdown and InCombatLockdown()) and not busy()
end
local function settle(map,complete)
    if not pending or not pending.confirmed or not pending.updated or not map or not complete then return end
    local row=map[pending.id]
    if row and active(row) then return end
    selected[pending.id]=nil
    pending=nil; confirmed=confirmed+1
    message=("%d confirmed; %d skipped"):format(confirmed,skipped)
    if queue and #queue==0 then queue=nil; message=message..". Done." end
end
local function prune(map,complete)
    if not map or not complete or queue or pending then return end
    for id in pairs(selected) do if not map[id] or not active(map[id]) then selected[id]=nil end end
end
local function selectRows(id, checked, range, matching)
    if not shown() or queue or pending then return end
    local map,order=owned(); if not map or not map[id] or not eligible(map[id]) then return end
    if matching then
        local key=keyOf(map[id]); if not key then return end
        for _,other in ipairs(order) do
            if eligible(map[other]) and keyOf(map[other])==key then selected[other]=checked and true or nil end
        end
    elseif range and anchor then
        local a,b
        for i,other in ipairs(order) do if other==anchor then a=i end; if other==id then b=i end end
        if a and b then
            for i=math.min(a,b),math.max(a,b) do
                local other=order[i]
                if eligible(map[other]) then selected[other]=checked and true or nil end
            end
        else selected[id]=checked and true or nil end
    else selected[id]=checked and true or nil end
    anchor=id; message=""
end
local function all()
    if not shown() or queue or pending then return end
    local map,order=owned(); if not map then return end
    local n=0; for _,id in ipairs(order) do if eligible(map[id]) then n=n+1 end end
    local check=count()~=n
    selected={}; anchor=nil
    if check then for _,id in ipairs(order) do if eligible(map[id]) then selected[id]=true end end end
    message=""
end
local function nextClick()
    if not shown() or pending then return end
    local map,order,complete=owned(); if not map or not complete then message="Waiting for complete auction list; click Refresh."; return end
    if not queue then
        queue={}; confirmed,skipped=0,0
        for _,id in ipairs(order) do if selected[id] and eligible(map[id]) then queue[#queue+1]=id end end
        if #queue==0 then stop("No eligible auctions selected."); return end
        local armed={}
        for _,id in ipairs(queue) do armed[id]=true end
        selected=armed
        message="Queue armed. Click Cancel Next to cancel one at a time."
        return -- explicit review/arming click; no transaction yet
    end
    if not ready() then message="Wait for the auction house to be ready."; return end
    while #queue>0 do
        local id=table.remove(queue,1)
        if map[id] and eligible(map[id]) then
            pending={id=id,started=now(),updated=false,confirmed=false}
            message="Waiting for Blizzard confirmation..."
            local ok,result=pcall(ah().CancelAuction,id)
            if not ok or result==false then
                -- No automatic retry, even if the request could have reached the server.
                stop("Cancellation rejected. Refresh/reopen AH before trying again.")
                if pending then pending.failed=true end
            end
            return -- exactly one API call per physical click
        else
            selected[id]=nil; skipped=skipped+1
        end
    end
    queue=nil; message=("%d confirmed; %d skipped. Done."):format(confirmed,skipped)
end
local function eachRow(fn)
    local scroll=list and list.ScrollBox
    if not scroll then return end
    if type(scroll.ForEachFrame)=="function" then scroll:ForEachFrame(fn)
    elseif type(scroll.GetFrames)=="function" then
        local frames=scroll:GetFrames()
        if type(frames)=="table" then for _,row in pairs(frames) do fn(row) end end
    end
end
local function rowData(row)
    -- Native table-builder rows expose rowData; elementData may only be an index.
    if idOf(row.rowData) then return row.rowData end
    local data=call(row.GetRowData,row)
    if idOf(data) then return data end
    data=call(row.GetElementData,row)
    if idOf(data) then return data end
end
local function button(parent,text,width,relative,x,callback)
    local b=CreateFrame("Button",nil,parent,"UIPanelButtonTemplate")
    b:SetSize(width,22); b:SetPoint("RIGHT",relative,"LEFT",x,0); b:SetText(text); b:SetScript("OnClick",callback)
    return b
end
local function refresh()
    if not controls then return end
    if not shown() then
        controls:Hide(); for _,b in pairs(boxes) do b:Hide() end; return
    end
    controls:Show()
    local map,order,complete=owned()
    settle(map,complete); prune(map,complete)
    if pending and not pending.failed and now()-pending.started>15 then
        pending.failed=true; stop("No confirmation. Stop: refresh/reopen AH and inspect mail.")
    end
    local seen={}
    local eligibleCount,visibleCount=0,0
    for _,id in ipairs(order or {}) do if eligible(map[id]) then eligibleCount=eligibleCount+1 end end
    eachRow(function(row)
        local data=rowData(row); local id=idOf(data)
        if not row:IsVisible() or not id or not map or not map[id] or not eligible(map[id]) then return end
        local scroll=list.ScrollBox
        local top,bottom=row:GetTop(),row:GetBottom()
        local center=top and bottom and (top+bottom)/2
        if not center or not scroll:GetTop() or not scroll:GetBottom()
            or center+9>scroll:GetTop()+1 or center-9<scroll:GetBottom()-1 then return end
        local b=boxes[row]
        if not b then
            b=CreateFrame("CheckButton",nil,controls,"UICheckButtonTemplate")
            b:SetSize(19,19); b:SetPoint("RIGHT",row,"LEFT",1,0)
            b:SetFrameLevel(math.max(controls:GetFrameLevel(),row:GetFrameLevel())+10)
            b:SetScript("OnClick",function(self)
                local current=idOf(rowData(row))
                if current~=self.acID then self:SetChecked(false); return end
                selectRows(current,self:GetChecked()==true,IsShiftKeyDown and IsShiftKeyDown(),IsControlKeyDown and IsControlKeyDown())
                refresh()
            end)
            b:SetScript("OnEnter",function(self)
                GameTooltip:SetOwner(self,"ANCHOR_RIGHT")
                GameTooltip:AddLine("AC: select auction")
                GameTooltip:AddLine("Shift-click: range | Ctrl-click: matching item",1,1,1)
                GameTooltip:Show()
            end)
            b:SetScript("OnLeave",function() GameTooltip:Hide() end)
            boxes[row]=b
        end
        visibleCount=visibleCount+1
        b.acID=id; b:SetChecked(selected[id]==true); b:SetEnabled(not queue and not pending); b:Show(); seen[row]=true
    end)
    for row,b in pairs(boxes) do if not seen[row] then b.acID=nil; b:Hide() end end
    local n=count()
    controls.all:SetEnabled(eligibleCount>0 and not queue and not pending)
    controls.cancel:SetText(queue and ("Cancel Next ("..#queue..")") or ("Cancel Selected ("..n..")"))
    if pending then controls.cancel:SetText(pending.failed and "Check AH / Mail" or "Waiting...") end
    controls.cancel:SetEnabled(complete and not pending and ((queue and #queue>0 and ready()) or (not queue and n>0)))
    controls.stop:SetEnabled(queue~=nil or (n>0 and not pending))
    local status=message
    if status=="" then
        if not map then status=diagnostic
        elseif eligibleCount==0 then status="No eligible auctions | /accanceldebug"
        elseif not complete then status=n.." selected | Refresh to enable cancellation"
        elseif visibleCount==0 then status=eligibleCount.." eligible | Select All | /accanceldebug"
        else status=n.." selected | Ctrl: same item" end
    end
    controls.status:SetText(status)
    controls.debugText=diagnostic..("; eligible=%d; visible checkboxes=%d"):format(eligibleCount,visibleCount)
end
local function attach()
    local p=AuctionHouseFrame and AuctionHouseFrame.AuctionsFrame
    local l=p and p.AllAuctionsList
    if not p or not l or not l.ScrollBox or not p.CancelAuctionButton then return end
    if controls then return end -- native frame persists for the session
    panel,list=p,l
    controls=CreateFrame("Frame",nil,p)
    controls:SetAllPoints(p); controls:SetFrameLevel(math.max(p:GetFrameLevel(),l:GetFrameLevel())+12)
    controls:EnableMouse(false)
    controls.cancel=button(controls,"Cancel Selected (0)",155,p.CancelAuctionButton,-5,function() nextClick();refresh() end)
    controls.stop=button(controls,"Stop",55,controls.cancel,-4,function() stop();refresh() end)
    controls.all=button(controls,"Select All",86,controls.stop,-4,function() all();refresh() end)
    controls.status=controls:CreateFontString(nil,"OVERLAY","GameFontHighlightSmall")
    controls.status:SetPoint("BOTTOMRIGHT",l,"TOPRIGHT",-40,6)
    controls.status:SetJustifyH("RIGHT")
    controls.status:SetWidth(385)
    controls:Hide()
    refresh()
end
local events=CreateFrame("Frame")
for _,event in ipairs({"AUCTION_HOUSE_SHOW","AUCTION_HOUSE_CLOSED","OWNED_AUCTIONS_UPDATED","AUCTION_CANCELED","AUCTION_HOUSE_AUCTIONS_EXPIRED","AUCTION_HOUSE_THROTTLED_SYSTEM_READY","ADDON_ACTION_BLOCKED","ADDON_ACTION_FORBIDDEN"}) do
    pcall(events.RegisterEvent,events,event)
end
events:SetScript("OnEvent",function(_,event,...)
    if event=="AUCTION_HOUSE_SHOW" then
        fresh=false; pending=nil; clear(); attach()
        if C_Timer and C_Timer.After then C_Timer.After(.3,function() if ac.IsAtAH() then attach();refresh() end end) end
    elseif event=="AUCTION_HOUSE_CLOSED" then
        fresh=false; pending=nil; clear(); if controls then controls:Hide() end
    elseif event=="OWNED_AUCTIONS_UPDATED" then
        if ac.IsAtAH() then fresh=true; if pending then pending.updated=true end; attach() end
    elseif event=="AUCTION_CANCELED" then
        local id=...
        if pending and readable(id) and id==pending.id then pending.confirmed=true end
    elseif event=="AUCTION_HOUSE_AUCTIONS_EXPIRED" then
        local id=...
        if pending and readable(id) and id==pending.id and not pending.confirmed then
            pending.failed=true; stop("Auction expired during request. Inspect AH and mail.")
        end
    elseif event=="ADDON_ACTION_BLOCKED" or event=="ADDON_ACTION_FORBIDDEN" then
        local addon=...
        if pending and addon=="AuctionCompanion" then pending.failed=true;stop("Blizzard blocked cancellation. Use native Cancel Auction.") end
    end
    refresh()
end)
events:SetScript("OnUpdate",function(_,elapsed)
    if not controls or not panel:IsVisible() then return end
    timer=timer+elapsed; if timer<.12 then return end; timer=0
    refresh()
end)

SLASH_ACCANCELDEBUG1="/accanceldebug"
SlashCmdList.ACCANCELDEBUG=function()
    if controls then refresh() end
    print("AC cancellation: "..(controls and controls.debugText or diagnostic))
    print("AC cancellation: "..(message~="" and message or "No request pending."))
end
