local _, ac = ...
-- Independent manual AH replication. No Auctionator hooks, no writes to other addons,
-- and no changes to price history until an entire replicated snapshot is processed.
local AH = C_AuctionHouse
local scan, scanButton
local scanButtons={}
local THROTTLE_SECONDS = 15 * 60
local RESPONSE_TIMEOUT_SECONDS = 45
local RETRY_AFTER_TIMEOUT_SECONDS = 90
local CHUNK = 350
local f = CreateFrame("Frame")
local state = {phase="idle", status="Full Scan has not been run this session.", processed=0, total=0}
ac.scanState = state

local function now()
    return type(time)=="function" and time() or 0
end
local function clock()
    return type(GetTime)=="function" and GetTime() or 0
end
local function scope()
    local realm = type(GetRealmName)=="function" and GetRealmName() or "Unknown Realm"
    local faction = type(UnitFactionGroup)=="function" and UnitFactionGroup("player") or "Unknown"
    -- Data for different AHs must not be silently mixed. Neutral-house detection
    -- is not universally available on Forever; callers can inspect the scope.
    local ahHouse = faction
    if AH and type(AH.IsNeutralAuctionHouse)=="function" then
        local ok, neutral=pcall(AH.IsNeutralAuctionHouse)
        if ok and neutral then ahHouse="Neutral" end
    end
    return tostring(realm).."|"..tostring(ahHouse)
end
local function stored()
    if not ac.db then return nil end
    if type(ac.db.scan)~="table" then ac.db.scan={} end
    return ac.db.scan
end
-- Separate scan-control metadata from the actual price snapshot. A failed or
-- throttled request must never overwrite valid prices.
local function at(record,key)
    return type(record)=="table" and record[key] or nil
end
local function control()
    if not ac.db then return nil end
    if type(ac.db.scanControl)~="table" then ac.db.scanControl={} end
    return ac.db.scanControl
end
local function freshStamp(value)
    local t=tonumber(value)
    if not t or now()<=0 or t<=0 or t>now() then return nil end
    return t
end
local function cooldown()
    local ctl=control()
    local best,source
    local function consider(stamp,label)
        stamp=freshStamp(stamp)
        if stamp and (not best or stamp>best) then best,source=stamp,label end
    end
    if ctl then
        consider(ctl.lastOwnResponseAt,"AC's previous Full Scan")
        consider(ctl.lastExternalResponseAt,"another addon's completed Full Scan")
    end
    local previous=stored()
    local record=at(previous,scope())
    if type(record)~="table" then record=nil end
    consider(record and record.completedAt,"AC's saved snapshot")
    -- Auctionator exposes its last replication request in a SavedVariable.
    -- READ ONLY: never modify Auctionator's data or call its scanning methods.
    local auctionator=_G.AUCTIONATOR_SAVEDVARS
    if type(auctionator)=="table" then
        consider(auctionator.TimeOfLastReplicateScan,"Auctionator's Full Scan request")
    end
    if best then
        local remain=THROTTLE_SECONDS-(now()-best)
        if remain>0 then return remain,source end
    end
    -- Other addons' *attempts* may be refused by Blizzard. Don't assume an
    -- unsuccessful request consumed a full 15-minute cooldown.
    if ctl then
        local last=freshStamp(ctl.lastExternalRequestAt)
        if last and now()-last<20 then
            return 20-(now()-last),"another addon's Full Scan request is in progress"
        end
        local timeout=freshStamp(ctl.lastTimeoutAt)
        if timeout and now()-timeout<RETRY_AFTER_TIMEOUT_SECONDS then
            return RETRY_AFTER_TIMEOUT_SECONDS-(now()-timeout),"AC's unanswered request (retry guard)"
        end
    end
    return 0,nil
end
ac.GetFullScanCooldown=cooldown

-- Observes replication requests without intercepting or changing them. When
-- AHledger or Auctionator starts a scan while AC is loaded, AC can tell the
-- user that another scan is being attempted. The response EVENT below is the
-- stronger evidence that the server actually supplied a fresh snapshot.
local issuingOwnRequest=false
if type(hooksecurefunc)=="function" and AH and type(AH.ReplicateItems)=="function" then
    pcall(hooksecurefunc,AH,"ReplicateItems",function()
        local ctl=control()
        if not ctl then return end
        if issuingOwnRequest then ctl.lastOwnRequestAt=now()
        else ctl.lastExternalRequestAt=now() end
    end)
end
-- Both Full Scan buttons share one cooldown clock. This is an estimated
-- readiness timer based on observed server responses, Auctionator's saved
-- timestamp, and AC's short retry guard; it is not a way around Blizzard's
-- shared throttle and cannot detect an unobserved pre-login AHledger scan.
local function buttonAppearance()
    if state.phase=="requesting" then return "Waiting...",false end
    if state.phase=="receiving" then
        local pct=0
        if state.total and state.total>0 then
            pct=math.min(100,math.floor((state.processed or 0)*100/state.total))
        end
        return ("Scan %d%%"):format(pct),false
    end
    local left=cooldown()
    if left and left>0 then
        local seconds=math.max(1,math.ceil(left))
        return ("Next %d:%02d"):format(math.floor(seconds/60),seconds%60),false
    end
    return "Full Scan",true
end
local function updateButtons()
    local value,enabled=buttonAppearance()
    for button in pairs(scanButtons) do
        if button._acRootScan then
            local covered = (ac.window and ac.window:IsShown()) or (ac.buyWindow and ac.buyWindow:IsShown())
            button:SetShown(not covered)
        end
        -- These values only change on a new second or a state transition.
        if button._acScanText~=value then
            button:SetText(value)
            button._acScanText=value
        end
        if button._acScanEnabled~=enabled then
            button:SetEnabled(enabled)
            button._acScanEnabled=enabled
            -- Make the unavailable state obvious even with custom Blizzard skins.
            if type(button.SetAlpha)=="function" then
                button:SetAlpha(enabled and 1 or .58)
            end
        end
    end
end
function ac.RegisterScanButton(button)
    if not button then return end
    scanButtons[button]=true
    updateButtons()
end
function ac.RefreshFullScanButtons()
    updateButtons()
end
-- Dedicated low-frequency timer: the scan-processing frame has its own
-- OnUpdate that must NEVER be replaced by a visual countdown.
local cooldownFrame=CreateFrame("Frame")
local elapsedSinceRefresh=0
cooldownFrame:RegisterEvent("AUCTION_HOUSE_SHOW")
cooldownFrame:RegisterEvent("AUCTION_HOUSE_CLOSED")
cooldownFrame:SetScript("OnEvent",function(self,event)
    self:SetShown(event=="AUCTION_HOUSE_SHOW")
end)
cooldownFrame:Hide()
cooldownFrame:SetScript("OnUpdate",function(self,elapsed)
    elapsedSinceRefresh=elapsedSinceRefresh+(elapsed or 0)
    if elapsedSinceRefresh<.25 then return end
    elapsedSinceRefresh=0
    if ac.IsAtAH and ac.IsAtAH() then updateButtons() end
end)

local function status(phase, message)
    state.phase=phase
    state.status=message
    updateButtons()
    if ac.Status then ac.Status(message) end
end
local function abort(reason)
    scan=nil
    f:SetScript("OnUpdate",nil)
    status("error",reason or "Scan stopped. Previous prices remain untouched.")
end

function ac.FullScanStart()
    if ac.IsNameScanBusy and ac.IsNameScanBusy() then
        return false,'Finish or cancel AC Live Scan All first.'
    end
    if not ac.IsAtAH() then return false,"Open the Auction House first." end
    if state.phase=="requesting" or state.phase=="receiving" then return false,"Scan already active." end
    if ac.pendingPurchase or ac.batch then return false,"Finish the pending purchase first." end
    if AuctionHouseFrame and AuctionHouseFrame.BuyDialog and
       AuctionHouseFrame.BuyDialog.IsShown and AuctionHouseFrame.BuyDialog:IsShown() then
        return false,"Close Blizzard's purchase confirmation before scanning."
    end
    if ac.session and (ac.session.mode=="searching" or ac.session.mode=="browse") then
        return false,"Finish or stop the item search first."
    end
    if not AH or type(AH.ReplicateItems)~="function" or
        type(AH.GetNumReplicateItems)~="function" or
        type(AH.GetReplicateItemInfo)~="function" then
        return false,"This client does not expose the full-scan API."
    end
    local remaining,source=cooldown()
    if remaining>0 then
        local minutes=math.ceil(remaining/60)
        return false,("Full Scan unavailable for about %d more minute%s (%s). Shared with Auctionator/AHledger."):
            format(minutes,minutes==1 and "" or "s",source or "server cooldown")
    end
    local key=scope()
    if type(AH.IsThrottledMessageSystemReady)=="function" then
        local ok,ready=pcall(AH.IsThrottledMessageSystemReady)
        if ok and ready==false then return false,"Auction queries are throttled. Try again later." end
    end
    -- Set the state BEFORE asking the server for listings. On some clients
    -- REPLICATE_ITEM_LIST_UPDATE can fire during ReplicateItems itself.
    scan={phase="requesting", requestedAt=clock(), requestedAtEpoch=now(), key=key}
    local ctl=control()
    if ctl then ctl.lastOwnRequestAt=now() end
    state.total=0
    state.processed=0
    status("requesting","Full Scan requested. Awaiting Blizzard's snapshot...")
    f:SetScript("OnUpdate",function(self,elapsed)
        if not scan then self:SetScript("OnUpdate",nil); return end
        if not ac.IsAtAH() then abort("Auction House closed during scan. Previous prices preserved."); return end
        if scan.phase=="requesting" then
            if clock()-scan.requestedAt>RESPONSE_TIMEOUT_SECONDS then
                local ctl=control()
                if ctl then ctl.lastTimeoutAt=now() end
                abort("No Full Scan response after 45 seconds. The shared Auctionator/AHledger cooldown may be active. Previous prices preserved; use /ac scanstatus.")
            end
            return
        end
        if scan.phase~="receiving" then return end
        local limit=math.min(scan.count, scan.nextIndex+CHUNK)
        for i=scan.nextIndex,limit-1 do
            -- This API returns eighteen positional fields (not a result table).
            local success,name,texture,qty,quality,usable,level,levelType,minBid,minIncrement,
                buyout,bidAmount,highBidder,bidderFullName,owner,ownerFullName,saleStatus,id,hasAllInfo =
                pcall(AH.GetReplicateItemInfo,i)
            if success then
                id=tonumber(id)
                qty=tonumber(qty)
                buyout=tonumber(buyout)
                if id and id>0 and qty and qty>0 then
                    local entry=scan.prices[id]
                    if not entry then
                        entry={listingCount=0,quantity=0}
                        scan.prices[id]=entry
                        scan.unique=scan.unique+1
                    end
                    entry.listingCount=entry.listingCount+1
                    entry.quantity=entry.quantity+(ac.IsUnstackable(id) and 1 or qty)
                    if buyout and buyout>0 then
                        if not entry.minListing or buyout<entry.minListing then
                            entry.minListing=buyout
                        end
                        local unit=ac.UnitFromListing(id,buyout,qty)
                        if unit then
                            unit=math.floor(unit+.5)
                            if not entry.minUnit or unit<entry.minUnit then entry.minUnit=unit end
                        end
                        entry.buyoutListings=(entry.buyoutListings or 0)+1
                    end
                else
                    scan.incomplete=scan.incomplete+1
                end
            else
                scan.incomplete=scan.incomplete+1
            end
        end
        scan.nextIndex=limit
        state.processed=limit
        if clock()-scan.updatedAt > .6 or limit>=scan.count then
            scan.updatedAt=clock()
            local percent=math.floor(100*limit/scan.count)
            updateButtons()
            state.status=("Scanning %d / %d listings (%d items)"):format(limit,scan.count,scan.unique)
            if ac.Status then ac.Status(state.status) end
        end
        if limit>=scan.count then
            local done=scan
            scan=nil
            self:SetScript("OnUpdate",nil)
            if done.incomplete>0 or done.unique==0 then
                status("error",("Scan incomplete (%d unreadable listings). Previous prices preserved."):format(done.incomplete))
                return
            end
            local records=stored()
            if not records then status("error","Scan data storage unavailable; no changes saved."); return end
            -- Atomic handoff: only complete snapshots replace a previous price set.
            records[done.key]={completedAt=now(),prices=done.prices,priceFormat=2,
                auctionCount=done.count,itemCount=done.unique,scope=done.key}
            local summary=("Full Scan complete: %s auctions, %s unique items."):
                format(tostring(done.count),tostring(done.unique))
            state.lastCount=done.count
            state.lastUnique=done.unique
            ac.priceRevision=(ac.priceRevision or 0)+1
            status("done",summary.." Prices saved for "..done.key..".")
            ac.announce(summary)
            if StaticPopupDialogs and type(StaticPopup_Show)=="function" then
                StaticPopupDialogs["AUCTIONCOMPANION_SCAN_COMPLETE"]={
                    text="Auction Companion - Full Scan complete!\n\n"
                        .."Auction listings scanned: %s\nUnique item IDs: %s\n\n"
                        .."The snapshot was saved for this auction house.",
                    button1=OKAY or "OK", timeout=0, whileDead=1, hideOnEscape=1,
                    preferredIndex=3,
                }
                StaticPopup_Show("AUCTIONCOMPANION_SCAN_COMPLETE",tostring(done.count),tostring(done.unique))
            end
        end
    end)
    issuingOwnRequest=true
    local ok,err=pcall(AH.ReplicateItems)
    issuingOwnRequest=false
    if not ok then
        abort("Full Scan request failed: "..tostring(err)..". Previous prices preserved.")
        return false,"Full Scan request failed: "..tostring(err)
    end
    -- On a synchronous response, scan.phase is already 'receiving'; do not
    -- accidentally reset it to 'requesting' after the API returns.
    return true
end

local function onReplicateList()
    if not scan then
        -- Another enabled AH addon received the server's full-scan response.
        -- Record ONLY the completed response; never ingest its data into AC.
        local ctl=control()
        if ctl then ctl.lastExternalResponseAt=now() end
        if ac.IsAtAH() then
            local msg="Another addon completed Full Scan. AC shares its ~15-minute cooldown; no AC prices were changed."
            state.status=msg
            updateButtons()
            if ac.Status then ac.Status(msg) end
        end
        return
    end
    if scan.phase~="requesting" then return end
    local ctl=control()
    if ctl then ctl.lastOwnResponseAt=scan.requestedAtEpoch; ctl.lastTimeoutAt=nil end
    local ok,count=pcall(AH.GetNumReplicateItems)
    if not ok or type(count)~="number" or count<1 then
        abort("Full scan returned no listings. Previous prices preserved.")
        return
    end
    if count>2000000 then abort("Scan count exceeds safety limit. Previous prices preserved."); return end
    scan.phase="receiving"
    scan.count=math.floor(count)
    scan.nextIndex=0 -- GetReplicateItemInfo accepts 0 through (count - 1).
    scan.prices={}
    scan.unique=0
    scan.incomplete=0
    scan.updatedAt=clock()
    state.total=scan.count
    status("receiving",("Scanning %d auction listings in small batches..."):format(scan.count))
end
f:RegisterEvent("REPLICATE_ITEM_LIST_UPDATE")
f:RegisterEvent("AUCTION_HOUSE_CLOSED")
f:SetScript("OnEvent",function(self,event)
    if event=="REPLICATE_ITEM_LIST_UPDATE" then onReplicateList()
    elseif event=="AUCTION_HOUSE_CLOSED" and scan then
        abort("Auction House closed during scan. Previous prices preserved.")
    end
end)

function ac.AttachScannerButton()
    if scanButton then return end
    local ah=AuctionHouseFrame
    if not ah then return end
    local parent=ah.BrowseResultsFrame or ah.BrowseFrame or ah.BuyFrame or ah
    scanButton=CreateFrame("Button","AuctionCompanionFullScanButton",parent,"UIPanelButtonTemplate")
    scanButton:SetSize(105,23)
    -- On Blizzard Buy the category column's lower free space is safer than
    -- the top search controls. The AC tab also has its own Full Scan button.
    scanButton:SetPoint("BOTTOMLEFT",ah,"BOTTOMLEFT",27,74)
    scanButton:SetText("Full Scan")
    scanButton:SetFrameLevel(parent:GetFrameLevel()+10)
    scanButton:SetScript("OnClick",function()
        local ok,err=ac.FullScanStart()
        if not ok and err then
            ac.announce(err)
            state.status=err
        end
    end)
    scanButton:SetScript("OnEnter",function(self)
        GameTooltip:SetOwner(self,"ANCHOR_TOP")
        GameTooltip:AddLine("Auction Companion - Full Scan",1,.82,.28)
        GameTooltip:AddLine("Manually request Blizzard's entire auction snapshot.",.85,.85,.85,true)
        local left,source=cooldown()
        if left>0 then
            local sec=math.ceil(left)
            GameTooltip:AddLine(("Next scan in %d:%02d (%s)"):format(math.floor(sec/60),sec%60,source or "shared cooldown"),1,.5,.35,true)
            if type(date)=="function" then
                GameTooltip:AddLine("Estimated ready: "..date("%I:%M %p",now()+sec),.8,.8,.8,true)
            end
        else
            GameTooltip:AddLine("Ready to request; an unobserved server cooldown is still possible.",.7,.85,.65,true)
        end
        GameTooltip:AddLine("Successful snapshots are saved separately from Auctionator and Auction Peek.",.65,.82,.95,true)
        if state.status then GameTooltip:AddLine(state.status,1,.86,.45,true) end
        GameTooltip:Show()
    end)
    scanButton:SetScript("OnLeave",function()GameTooltip:Hide()end)
    scanButton._acRootScan = parent==ah
    ac.RegisterScanButton(scanButton)
end

ac.GetMarketScope=scope
ac.api.StartFullScan=ac.FullScanStart
ac.api.GetScanStatus=function()
    local db=stored()
    local ctl=control()
    local record=at(db,scope())
    if type(record)~="table" then record=nil end
    local remain,source=cooldown()
    return {phase=state.phase,status=state.status,processed=state.processed,total=state.total,
        scope=scope(),lastCompleted=record and record.completedAt or nil,
        auctionCount=record and record.auctionCount or nil,itemCount=record and record.itemCount or nil,
        lastRunAuctionCount=state.lastCount,lastRunItemCount=state.lastUnique,
        cooldownSeconds=math.ceil(remain),cooldownSource=source,
        lastOwnRequest=ctl and ctl.lastOwnRequestAt or nil,
        lastExternalRequest=ctl and ctl.lastExternalRequestAt or nil,
        lastExternalResponse=ctl and ctl.lastExternalResponseAt or nil,
        lastTimeout=ctl and ctl.lastTimeoutAt or nil}
end
ac.api.GetScannedPrice=function(itemID)
    local db=stored()
    local record=at(db,scope())
    if type(record)~="table" then record=nil end
    local entry=at(record and record.prices,tonumber(itemID))
    if type(entry)~="table" then return nil end
    if not entry or not entry.minUnit then return nil end
    -- Old AC scans sometimes divided one-piece bag buyouts by a bad quantity.
    -- Keep the record for rollback, but do not return that incorrect valuation.
    if ac.IsUnstackable(itemID) then
        if (tonumber(record.priceFormat) or 1)<2 then return nil end
        return entry.minListing or entry.minUnit,record.completedAt,entry.listingCount,entry.quantity,record.scope
    end
    return entry.minUnit,record.completedAt,entry.listingCount,entry.quantity,record.scope
end
-- Read-only AC market price service. Search quotes expire, and neither searches
-- nor scans modify another addon's SavedVariables. Scans remain usable offline.
ac.api.GetPriceRevision=function()return ac.priceRevision or 0 end
ac.api.GetPriceByItemID=function(itemID)
    itemID=tonumber(itemID)
    if not itemID then return nil end
    local key=scope()
    local live=at(at(ac.db and ac.db.livePrices,key),itemID)
    if type(live)~="table" then live=nil end
    local snapshot=at(stored(),key)
    if type(snapshot)~="table" then snapshot=nil end
    local scanned=at(snapshot and snapshot.prices,itemID)
    if type(scanned)~="table" then scanned=nil end
    local livePrice=live and tonumber(live.minUnit)
    local liveAt=live and tonumber(live.observedAt)
    local scanAt=snapshot and tonumber(snapshot.completedAt)
    -- Return the listing total for nonstackable items. Keeping both totals and
    -- units lets cached item information load AFTER a full scan without a
    -- stale per-unit valuation making a bag appear much cheaper than it is.
    if ac.IsUnstackable(itemID) then
        if live and live.minListing then livePrice=tonumber(live.minListing) end
        if scanned and scanned.minListing then
            scanned={minUnit=tonumber(scanned.minListing)}
        end
    end
    -- Reject legacy unstackable prices calculated with the old quantity logic.
    if ac.IsUnstackable(itemID) then
        if (tonumber(live and live.priceFormat) or 1)<2 then livePrice=nil end
        if (tonumber(snapshot and snapshot.priceFormat) or 1)<2 then scanned=nil end
    end
    local nowTime=now()
    local isFresh=livePrice and livePrice>0 and liveAt and nowTime>=liveAt and nowTime-liveAt<=1800
    if isFresh and (not scanAt or liveAt>=scanAt) then
        return livePrice,"search",liveAt
    end
    local scanPrice=scanned and tonumber(scanned.minUnit)
    if scanPrice and scanPrice>0 then
        return scanPrice,"scan",scanAt
    end
    if isFresh then return livePrice,"search",liveAt end
end
function ac.PublishPrice(row)
    if not ac.db or not row or row.state~="Ready" then return end
    local itemID=tonumber(row.itemID)
    local price=tonumber(row.minUnit)
    if not itemID or not price or price<=0 then return end
    local market=scope()
    ac.db.livePrices=type(ac.db.livePrices)=="table" and ac.db.livePrices or {}
    local prices=ac.db.livePrices[market]
    if type(prices)~="table" then prices={};ac.db.livePrices[market]=prices end
    prices[itemID]={minUnit=price,minListing=tonumber(row.minListing),
        observedAt=now(),priceFormat=2}
    ac.priceRevision=(ac.priceRevision or 0)+1
end
