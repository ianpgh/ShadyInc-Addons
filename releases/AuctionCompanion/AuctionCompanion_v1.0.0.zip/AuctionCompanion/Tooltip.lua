local _, ac = ...
-- WoW Forever: compact AH and known vendor purchase values.
-- Never substitutes vendor purchase prices, vendor sell values or historical
-- estimates. If Auctionator is present, each addon retains its own line.
local function auctionatorLoaded()
    if C_AddOns and type(C_AddOns.IsAddOnLoaded)=='function' then
        local ok,loaded=pcall(C_AddOns.IsAddOnLoaded,'Auctionator')
        if ok then return not not loaded end
    end
    if type(IsAddOnLoaded)=='function' then
        local ok,loaded=pcall(IsAddOnLoaded,'Auctionator')
        if ok then return not not loaded end
    end
    return false
end
local function tooltipAllowed(tip)
    if not tip then return false end
    if tip~=GameTooltip and tip~=ItemRefTooltip and tip~=GameTooltipTooltip then return false end
    if type(tip.IsForbidden)=='function' and tip:IsForbidden() then return false end
    return true
end
local function idFromTooltip(tip, data)
    local id=tonumber(data and (data.id or data.itemID))
    if id and id>0 then return id end
    local link=data and (data.hyperlink or data.itemLink)
    if not link and type(tip.GetItem)=='function' then
        local _,value=tip:GetItem()
        link=value
    end
    if type(link)=='string' then
        id=tonumber(link:match('item:(%d+)'))
        if id and id>0 then return id end
        if C_Item and type(C_Item.GetItemInfoInstant)=='function' then
            local ok,itemID=pcall(C_Item.GetItemInfoInstant,link)
            if ok and tonumber(itemID) then return tonumber(itemID) end
        end
    end
end
local function addAuctionLine(tip,itemID)
    if not ac.db or not itemID or not ac.api or type(ac.api.GetPriceByItemID)~='function' then return end
    if type(tip.AddDoubleLine)~='function' then return end
    local ok,price=pcall(ac.api.GetPriceByItemID,itemID)
    price=ok and tonumber(price) or nil
    if not price or price<=0 or price>=math.huge then return end
    -- Auctionator uses the regular white auction price; AC uses bright cyan
    -- when both addons are loaded for immediately visible differentiation.
    if auctionatorLoaded() then
        tip:AddDoubleLine('Auction',ac.money(price),.24,1,1,.24,1,1)
    else
        tip:AddDoubleLine('Auction',ac.money(price),1,.84,.36,1,1,1)
    end
end
local function onItem(tip,data)
    if not tooltipAllowed(tip) then return end
    if data and data.excludeLines then return end
    local id=idFromTooltip(tip,data)
    if id and type(ac.VendorTooltipPrice)=='function' and type(tip.AddDoubleLine)=='function' then
        local price=ac.VendorTooltipPrice(id)
        if type(price)=='number' and price>0 and price<math.huge then
            -- Keep the native/other-addon Vendor line intact. Insert above it
            -- when it is a plain double line; otherwise append safely.
            tip:AddDoubleLine('Vendor Sells',ac.money(price),.65,.65,.65,.65,.65,.65)
            local name=tip.GetName and tip:GetName()
            local n=tip.NumLines and tip:NumLines() or 0
            if name and n>1 then
                local function line(i,side) return _G[name..'Text'..side..i] end
                local target
                for i=n-1,2,-1 do
                    local l,r=line(i,'Left'),line(i,'Right')
                    if l and r and l:GetText()=='Vendor' and r:GetText() and r:GetText()~='' then target=i; break end
                end
                if target then
                    local rows={}
                    for i=target,n do
                        local l,r=line(i,'Left'),line(i,'Right')
                        if not l or not r or not r:IsShown() or not r:GetText() or r:GetText()=='' then rows=nil;break end
                        rows[#rows+1]={{l:GetText(),l:GetTextColor()},{r:GetText(),r:GetTextColor()}}
                    end
                    if rows then
                        for i=target,n do
                            local row=rows[i==target and #rows or i-target]
                            for j,side in ipairs({'Left','Right'}) do
                                local f=line(i,side); local v=row[j]
                                f:SetText(v[1]);f:SetTextColor(v[2],v[3],v[4],v[5])
                            end
                        end
                    end
                end
            end
        end
    end
    addAuctionLine(tip,id)
end

-- New tooltip API handles bag, merchant, trade-skill, and item-link hovers with
-- one callback. Do not also hook legacy item events: that duplicates lines.
local modern=TooltipDataProcessor and type(TooltipDataProcessor.AddTooltipPostCall)=='function'
    and Enum and Enum.TooltipDataType and Enum.TooltipDataType.Item
if modern then
    TooltipDataProcessor.AddTooltipPostCall(Enum.TooltipDataType.Item,onItem)
else
    local function legacyHook(tip)
        if not tip or type(tip.HookScript)~='function' then return end
        tip:HookScript('OnTooltipSetItem',function(self)
            onItem(self)
        end)
    end
    legacyHook(GameTooltip)
    legacyHook(ItemRefTooltip)
end
