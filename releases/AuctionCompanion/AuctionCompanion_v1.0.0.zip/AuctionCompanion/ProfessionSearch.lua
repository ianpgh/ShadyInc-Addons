local addonName, ac = ...
-- Standalone native recipe launcher. All auction work stays in Search.lua.
-- Profession AIO's existing launcher wins whenever it is visible.
local button, attached, ticker, queued, layoutKey
local hookedFrames = setmetatable({}, {__mode = 'k'})
local hookedAIO = setmetatable({}, {__mode = 'k'})
local refresh, schedule

local function trade(method, ...)
    local fn = C_TradeSkillUI and C_TradeSkillUI[method]
    if type(fn) ~= 'function' then return end
    local ok, value = pcall(fn, ...)
    if ok then return value end
end

function ac.ProfessionSearchEnabled()
    local s = ac.db and ac.db.settings
    return type(s) ~= 'table' or s.professionSearch ~= false
end
function ac.SetProfessionSearchEnabled(enabled)
    if type(ac.db) ~= 'table' then return false end
    ac.db.settings = type(ac.db.settings) == 'table' and ac.db.settings or {}
    ac.db.settings.professionSearch = not not enabled
    refresh()
    return true
end

local function visible(frame)
    if not frame then return false end
    if frame.IsVisible then return frame:IsVisible() end
    return frame.IsShown and frame:IsShown()
end
local function nativeFrame()
    if visible(ProfessionsFrame) then return ProfessionsFrame end
    if visible(TradeSkillFrame) then return TradeSkillFrame end
    return ProfessionsFrame or TradeSkillFrame
end
local function selected(native)
    local page = native and native.CraftingPage
    local form = page and page.SchematicForm
    if not visible(native) or not visible(form) or not form.GetRecipeInfo then return end
    -- AIO's mini mode can leave the native window shown but transparent.
    if native.GetEffectiveAlpha and native:GetEffectiveAlpha() <= 0 then return end
    if trade('IsDataSourceChanging') or trade('IsTradeSkillLinked') or
        trade('IsTradeSkillGuild') or trade('IsNPCCrafting') then return end
    local ok, info = pcall(form.GetRecipeInfo, form)
    local id = ok and type(info) == 'table' and tonumber(info.recipeID)
    if id and id > 0 then return form, id, info end
end
local function hide()
    if button then button:Hide() end
end
local function aioOwnsButton()
    local other = _G.ProfessionAIOAuctionSearchButton
    if not other then return false end
    if not hookedAIO[other] and other.HookScript then
        hookedAIO[other] = true
        other:HookScript('OnShow', hide)
        other:HookScript('OnHide', function() schedule() end)
    end
    return visible(other)
end
local function enchanting(native, info)
    local profession = Enum and Enum.Profession and Enum.Profession.Enchanting or 9
    local function match(v)
        if type(v) == 'string' then return v:lower():match('^%s*enchanting[%s%p%d]*$') ~= nil end
        if type(v) ~= 'table' then return false end
        return v.professionID == 333 or v.skillLineID == 333 or v.parentProfessionID == 333 or
            v.profession == profession or v.professionName == 'Enchanting' or v.name == 'Enchanting'
    end
    return match(trade('GetBaseProfessionInfo')) or match(trade('GetChildProfessionInfo')) or
        match(info) or match(trade('GetTradeSkillLine')) or
        match(native.GetTitleText and native:GetTitleText()) or
        match(native.TitleText and native.TitleText.GetText and native.TitleText:GetText())
end
local function reagentHeading(frame, depth)
    if not visible(frame) or depth < 0 then return end
    if frame.GetRegions then
        for _, region in ipairs({frame:GetRegions()}) do
            if region.GetText and visible(region) then
                local raw = region:GetText()
                if not (issecretvalue and issecretvalue(raw)) and type(raw) == 'string' then
                    local label = raw:match('^%s*(.-)%s*$')
                    if label == 'Reagents:' or label == 'Reagents' or label == 'Materials:' or label == 'Materials' then return region end
                end
            end
        end
    end
    if frame.GetChildren then
        for _, child in ipairs({frame:GetChildren()}) do
            local found = reagentHeading(child, depth - 1)
            if found then return found end
        end
    end
end
local function createButton(form)
    button = CreateFrame('Button', 'AuctionCompanionProfessionSearchButton', form, 'UIPanelButtonTemplate')
    button:SetSize(96, 22)
    button:SetText('AC Search')
    button:Hide()
    button:SetScript('OnClick', function()
        if not ac.ProfessionSearchEnabled() or aioOwnsButton() then hide(); return end
        local _, id = selected(nativeFrame()) -- always read current recipe, not cached selection
        if not id then ac.announce('Select a recipe first.'); return end
        if not ac.IsAtAH() then ac.announce('Open the Auction House to search this recipe with AC.'); return end
        local ok, err = ac.api.SearchRecipe(id, 1)
        if not ok then ac.announce(err or 'Search unavailable') end
    end)
    button:SetScript('OnEnter', function(self)
        GameTooltip:SetOwner(self, 'ANCHOR_TOP')
        GameTooltip:AddLine('Auction Companion recipe search', 1, .82, .3)
        GameTooltip:AddLine('Search the selected recipe output (when auctionable) and fixed reagents. Craft quantity: 1.', .9, .9, .9, true)
        if not ac.IsAtAH() then GameTooltip:AddLine('Open the Auction House to run the search.', 1, .73, .32, true) end
        GameTooltip:Show()
    end)
    button:SetScript('OnLeave', function() GameTooltip:Hide() end)
    button:SetScript('OnHide', function(self)
        if GameTooltip and GameTooltip.IsOwned and GameTooltip:IsOwned(self) then GameTooltip:Hide() end
    end)
end
local function place(native, form, info)
    if not button then createButton(form) end
    if attached ~= form then
        attached, layoutKey = form, nil
        button:SetParent(form)
        if form.GetFrameStrata then button:SetFrameStrata(form:GetFrameStrata()) end
        button:SetFrameLevel(form:GetFrameLevel()+12)
    end
    local key, x, y = 'normal', -23, -75
    if enchanting(native, info) then
        -- Enchant descriptions move the native reagent header. Mirror AIO's
        -- dynamic placement; do not cover descriptions if layout isn't ready.
        local heading = reagentHeading(form, 6)
        local top = heading and heading.GetTop and heading:GetTop()
        local formTop = form.GetTop and form:GetTop()
        if not top or not formTop then layoutKey = nil; return false end
        x, y = -14, top - formTop + 5
        key = 'enchant:' .. tostring(heading) .. ':' .. tostring(math.floor(y + .5))
    end
    if key ~= layoutKey then
        button:ClearAllPoints()
        button:SetPoint('TOPRIGHT', form, 'TOPRIGHT', x, y)
        layoutKey = key
    end
    return true
end
local function stopTicker()
    if ticker then ticker:Cancel(); ticker = nil end
end
local function hookNative(frame)
    if not frame or hookedFrames[frame] or not frame.HookScript then return end
    hookedFrames[frame] = true
    frame:HookScript('OnShow', function() schedule() end)
    frame:HookScript('OnHide', function() hide(); stopTicker(); schedule() end)
end
refresh = function()
    local native = nativeFrame()
    hookNative(ProfessionsFrame)
    hookNative(TradeSkillFrame)
    if not ac.db or not ac.ProfessionSearchEnabled() or not visible(native) then
        hide(); stopTicker(); return
    end
    -- Only while the native window is open: the Forever client can update
    -- its selected schematic/layout without a reliable recipe event. Never
    -- poll the AH or request prices here. Stop immediately on window close.
    if not ticker and C_Timer and C_Timer.NewTicker then ticker = C_Timer.NewTicker(.75, refresh) end
    local form, _, info = selected(native)
    if not form or aioOwnsButton() then hide(); return end
    if place(native, form, info) then button:Show() else hide() end
end
schedule = function()
    if queued then return end
    if C_Timer and C_Timer.After then
        queued = true
        C_Timer.After(0, function() queued = false; refresh() end)
    else refresh() end
end
local events = CreateFrame('Frame')
for _, event in ipairs({'ADDON_LOADED', 'PLAYER_LOGIN', 'TRADE_SKILL_SHOW', 'TRADE_SKILL_CLOSE',
    'TRADE_SKILL_LIST_UPDATE', 'TRADE_SKILL_DATA_SOURCE_CHANGED', 'TRADE_SKILL_DETAILS_UPDATE',
    'AUCTION_HOUSE_SHOW', 'AUCTION_HOUSE_CLOSED'}) do
    pcall(events.RegisterEvent, events, event) -- optional events vary by client
end
events:SetScript('OnEvent', function(_, event, arg)
    if event == 'ADDON_LOADED' and arg ~= addonName and arg ~= 'ProfessionAIO' and
        arg ~= 'Blizzard_Professions' and arg ~= 'Blizzard_TradeSkillUI' then return end
    if event == 'TRADE_SKILL_CLOSE' then hide(); stopTicker(); schedule(); return end
    schedule()
end)
