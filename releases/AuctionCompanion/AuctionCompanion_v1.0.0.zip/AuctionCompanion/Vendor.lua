local _, ac = ...
-- v0.1.9: Crafting-cost vendor alternatives. Never confuse vendor buy cost
-- with the vendor SELL value from item info/tooltips.
-- Base costs are prices observed for unlimited-stock common trade vendors on
-- WoW Forever. They are reference prices, NOT guaranteed reputation discounts.
-- Only the merchant API can provide the character's actual price.
local BASE = {
    [2320]=10,     -- Coarse Thread
    [2321]=100,    -- Fine Thread
    [4291]=500,    -- Silken Thread
    [8343]=2000,   -- Heavy Silken Thread
    [14341]=5000,  -- Rune Thread
    [2324]=25,     -- Bleach
    [2325]=1000,   -- Black Dye
    [4340]=350,    -- Gray Dye
    [4341]=500,    -- Yellow Dye
    [4342]=2500,   -- Purple Dye
    [6260]=50,     -- Blue Dye
    [6261]=1000,   -- Orange Dye
    [10290]=2500,  -- Pink Dye
}
local NAMES = {
    [2320]='Coarse Thread', [2321]='Fine Thread', [4291]='Silken Thread',
    [8343]='Heavy Silken Thread', [14341]='Rune Thread', [2324]='Bleach',
    [2325]='Black Dye', [4340]='Gray Dye', [4341]='Yellow Dye',
    [4342]='Purple Dye', [6260]='Blue Dye', [6261]='Orange Dye',
    [10290]='Pink Dye',
}
local IDS = {}
for id,name in pairs(NAMES) do IDS[name]=id end

local function characterKey()
    if type(UnitGUID)=='function' then
        local ok,guid=pcall(UnitGUID,'player')
        if ok and type(guid)=='string' and guid~='' then return guid end
    end
    local player=type(UnitName)=='function' and UnitName('player') or 'player'
    local realm=type(GetRealmName)=='function' and GetRealmName() or 'unknown'
    return tostring(player)..'-'..tostring(realm)
end
local function observedPrices()
    if type(ac.db)~='table' then return nil end
    ac.db.vendorPrices=type(ac.db.vendorPrices)=='table' and ac.db.vendorPrices or {}
    local key=characterKey()
    ac.db.vendorPrices[key]=type(ac.db.vendorPrices[key])=='table' and ac.db.vendorPrices[key] or {}
    return ac.db.vendorPrices[key]
end
local function settings()
    if type(ac.db)~='table' then return nil end
    ac.db.settings=type(ac.db.settings)=='table' and ac.db.settings or {}
    return ac.db.settings
end
function ac.PreferVendor()
    local s=settings()
    -- Default on; explicit false means AH-only estimates.
    return s==nil or s.preferVendor~=false
end
local function finite(v)
    return type(v)=='number' and v>0 and v<math.huge
end
function ac.VendorPrice(itemID)
    itemID=tonumber(itemID)
    if not itemID then return nil end
    local characterPrices=observedPrices()
    local observed=characterPrices and characterPrices[itemID]
    if type(observed)=='table' and finite(observed.unit) then
        local sampled=tonumber(observed.at) or 0
        local t=type(time)=='function' and time() or 0
        -- Character-specific vendor prices may change with faction reputation;
        -- don't treat a months-old vendor visit as the current discounted price.
        if sampled>0 and t>=sampled and t-sampled<7*86400 then
            return observed.unit,'merchant',sampled
        end
    end
    local base=BASE[itemID]
    if finite(base) then return base,'reference',nil end
end
-- Tooltip-only observations include limited-stock goods; never feed them into crafting costs.
function ac.VendorTooltipPrice(itemID)
    itemID=tonumber(itemID)
    if not itemID or not ac.db then return nil end
    local records=ac.db.vendorTooltipPrices
    local row=records and records[characterKey()] and records[characterKey()][itemID]
    -- Last observed character-specific prices remain useful reference prices.
    -- Choose the newest observation if both caches contain this item.
    local prices=observedPrices()
    local regular=prices and prices[itemID]
    if type(regular)=='table' and finite(regular.unit) and
        (type(row)~='table' or not finite(row.unit) or
         (tonumber(regular.at) or 0)>(tonumber(row.at) or 0)) then
        row=regular
    end
    if type(row)=='table' and finite(row.unit) then return row.unit end
    local imported=ac.vendorReferencePrices and ac.vendorReferencePrices[itemID]
    if finite(imported) then return imported end
    return ac.VendorPrice(itemID)
end
ac.api.GetVendorPrice=function(id)return ac.VendorPrice(id)end
ac.api.IsVendorPricingEnabled=function()return ac.PreferVendor()end

-- The regular GetPriceByItemID API intentionally stays AH-only so other addons
-- can distinguish actual market prices from crafting expense assumptions.
ac.api.GetMaterialCost=function(itemID)
    itemID=tonumber(itemID)
    if not itemID then return nil,'unknown' end
    local ah,origin,observedAt
    if type(ac.api.GetPriceByItemID)=='function' then
        ah,origin,observedAt=ac.api.GetPriceByItemID(itemID)
    end
    ah=tonumber(ah)
    local vendor,kind=ac.VendorPrice(itemID)
    if ac.PreferVendor() and vendor and (not ah or ah<=0 or vendor<ah) then
        return vendor,'vendor',kind,ah,vendor
    end
    if finite(ah) then return ah,'auction',origin,ah,vendor end
    return nil,'missing',nil,ah,vendor
end

function ac.SetPreferVendor(enabled)
    if ac.batch then return false,'Stop the reagent buying queue before changing pricing settings' end
    local s=settings()
    if not s then return false,'Auction Companion settings are not loaded' end
    s.preferVendor=not not enabled
    -- Settings affect crafting costs, never the underlying AH cache.
    for _,row in ipairs(ac.session.rows or {}) do
        if not row.output and (tonumber(row.toBuy) or 0)>0 then
            local _,kind,_,ah,vendor=ac.api.GetMaterialCost(row.itemID)
            local isVendor=kind=='vendor' and vendor and (not ah or vendor<ah)
            row.vendorPreferred=not not isVendor
            row.acSelected=not isVendor
        end
    end
    ac.priceRevision=(ac.priceRevision or 0)+1
    ac.Notify()
    return true
end

-- Account for dynamic merchant cost and pack size, but never store limited
-- stock, currencies, extended costs, non-purchasable offers or a sell value.
local function capture()
    if not ac.db then return end
    local getCount=type(GetMerchantNumItems)=='function' and GetMerchantNumItems or
        (C_MerchantFrame and C_MerchantFrame.GetNumItems)
    if type(getCount)~='function' then return end
    local ok,n=pcall(getCount)
    if not ok or type(n)~='number' then return end
    local characterPrices=observedPrices()
    if not characterPrices then return end
    ac.db.vendorTooltipPrices=type(ac.db.vendorTooltipPrices)=='table' and ac.db.vendorTooltipPrices or {}
    local key=characterKey()
    ac.db.vendorTooltipPrices[key]=type(ac.db.vendorTooltipPrices[key])=='table' and ac.db.vendorTooltipPrices[key] or {}
    local tooltipPrices=ac.db.vendorTooltipPrices[key]
    local changed=false
    for i=1,math.min(n,250) do
        local info
        if C_MerchantFrame and type(C_MerchantFrame.GetItemInfo)=='function' then
            local valid,v=pcall(C_MerchantFrame.GetItemInfo,i)
            if valid and type(v)=='table' then info=v end
        end
        if not info and type(GetMerchantItemInfo)=='function' then
            local okLegacy,name,_,price,quantity,available,usable,extended=pcall(GetMerchantItemInfo,i)
            if okLegacy then
                info={name=name,price=price,stackCount=quantity,numAvailable=available,
                    isPurchasable=usable,hasExtendedCost=extended}
            end
        end
        if info and finite(tonumber(info.price)) and
            info.hasExtendedCost~=true and info.isPurchasable~=false then
            local itemID
            local link
            if type(GetMerchantItemLink)=='function' then
                local good,v=pcall(GetMerchantItemLink,i)
                if good then link=v end
            end
            if not link and C_MerchantFrame and type(C_MerchantFrame.GetItemLink)=='function' then
                local good,v=pcall(C_MerchantFrame.GetItemLink,i)
                if good then link=v end
            end
            if type(link)=='string' then itemID=tonumber(link:match('item:(%d+)')) end
            -- Some Forever merchant UIs expose only a name in GetItemInfo.
            if not itemID and type(info.name)=='string' then itemID=IDS[info.name] end
            if itemID then
                local units=math.max(1,math.floor(tonumber(info.stackCount) or 1))
                local unit=tonumber(info.price)/units
                if finite(unit) then
                    tooltipPrices[itemID]={unit=unit,at=type(time)=='function' and time() or 0}
                end
                if finite(unit) and info.numAvailable==-1 then
                    local previous=characterPrices[itemID]
                    if not previous or previous.unit~=unit then changed=true end
                    characterPrices[itemID]={unit=unit,at=type(time)=='function' and time() or 0}
                end
            end
        end
    end
    if changed then
        ac.priceRevision=(ac.priceRevision or 0)+1
        ac.Notify()
    end
end
local merchant=CreateFrame('Frame')
merchant:RegisterEvent('MERCHANT_SHOW')
merchant:RegisterEvent('MERCHANT_UPDATE')
merchant:SetScript('OnEvent',function()
    if C_Timer and type(C_Timer.After)=='function' then C_Timer.After(.1,capture) else capture() end
end)
