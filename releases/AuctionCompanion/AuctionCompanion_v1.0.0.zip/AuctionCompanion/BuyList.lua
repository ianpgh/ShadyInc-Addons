local _, ac = ...

local MAX_ITEMS = 60
local MAX_LISTS = 30
local trips = {}

local function integer(value, maximum)
    local number = tonumber(value)
    if number and number >= 1 and number <= maximum and number == math.floor(number) then
        return number
    end
end

local function entriesFrom(saved)
    local entries, seen = {}, {}
    if type(saved) ~= "table" then return entries end
    local positions = {}
    for position in pairs(saved) do
        if type(position) == "number" and position >= 1 and position == math.floor(position) then
            positions[#positions + 1] = position
        end
    end
    table.sort(positions)
    for _, position in ipairs(positions) do
        local entry = saved[position]
        if type(entry) == "table" then
            local id = integer(entry.itemID, 9999999)
            local quantity = integer(entry.required, 99999)
            if id and quantity and not seen[id] then
                entries[#entries + 1] = {
                    itemID = id, required = quantity,
                    maxUnit = integer(entry.maxUnit, 9999999999),
                }
                seen[id] = true
                if #entries == MAX_ITEMS then break end
            end
        end
    end
    return entries
end

function ac.InitBuyLists()
    if not ac.db then return end
    if type(ac.db.shoppingLists) ~= "table" or #ac.db.shoppingLists == 0 then
        ac.db.shoppingLists = {{name = "Buy List", items = entriesFrom(ac.db.buyList)}}
    end
    ac.db.activeShoppingList = integer(ac.db.activeShoppingList, #ac.db.shoppingLists) or 1
end

function ac.BuyListNames()
    local names = {}
    for i, list in ipairs(ac.db.shoppingLists) do
        names[i] = type(list) == "table" and type(list.name) == "string" and list.name or ("List " .. i)
    end
    return names, ac.db.activeShoppingList
end

function ac.SelectBuyList(index)
    ac.db.activeShoppingList = integer(index, #ac.db.shoppingLists) or ac.db.activeShoppingList
end

local function activeList()
    local index = ac.db.activeShoppingList
    local list = ac.db.shoppingLists[index]
    if type(list) ~= "table" then
        list = {name = "List " .. index, items = {}}
        ac.db.shoppingLists[index] = list
    end
    return list
end

function ac.EditBuyList(action, name)
    local lists = ac.db.shoppingLists
    local active = ac.db.activeShoppingList
    if action == "delete" then
        trips[lists[active]] = nil
        table.remove(lists, active)
        if #lists == 0 then lists[1] = {name = "Buy List", items = {}} end
        ac.db.activeShoppingList = math.min(active, #lists)
        return true
    end
    name = type(name) == "string" and name:match("^%s*(.-)%s*$") or ""
    if name == "" or #name > 40 or name:find("|", 1, true) then
        return nil, "Enter a list name of 1–40 bytes without a pipe."
    end
    for i, existing in ipairs(ac.BuyListNames()) do
        if existing:lower() == name:lower() and (action ~= "rename" or i ~= active) then
            return nil, "That list name is already in use."
        end
    end
    if action == "rename" then
        activeList().name = name
    else
        if #lists >= MAX_LISTS then return nil, "You can save up to 30 lists." end
        lists[#lists + 1] = {name = name, items = action == "duplicate" and ac.GetBuyList() or {}}
        ac.db.activeShoppingList = #lists
    end
    return true
end

function ac.GetBuyList()
    if not ac.db then return {} end
    return entriesFrom(activeList().items)
end

function ac.BuyListOwned(itemID)
    local count = GetItemCount or (C_Item and C_Item.GetItemCount)
    if type(count) ~= "function" then return 0 end
    local ok, value = pcall(count, itemID, false, false)
    return ok and math.max(0, tonumber(value) or 0) or 0
end

function ac.SaveBuyListItem(itemID, quantity, maxUnit, onlyNew)
    if not ac.db then return nil, "Buy List is unavailable." end
    if type(itemID) == "string" then itemID = itemID:match("|Hitem:(%d+)") or itemID end
    itemID = integer(itemID, 9999999)
    if not itemID then return nil, "Enter an item ID or paste an item link." end
    quantity = integer(quantity, 99999)
    if not quantity then return nil, "Enter a quantity from 1 to 99,999." end
    if maxUnit ~= nil and maxUnit ~= "" then
        maxUnit = integer(maxUnit, 9999999999)
        if not maxUnit then return nil, "Enter the maximum unit price in copper." end
    else
        maxUnit = nil
    end
    local entries = ac.GetBuyList()
    local index
    for i, entry in ipairs(entries) do
        if entry.itemID == itemID then index = i; break end
    end
    if index and onlyNew then return index end
    if not index and #entries >= MAX_ITEMS then return nil, "Buy List holds up to 60 items." end
    index = index or (#entries + 1)
    entries[index] = {itemID = itemID, required = quantity, maxUnit = maxUnit}
    activeList().items = entries
    return index
end

function ac.RemoveBuyListItem(itemID)
    local entries = ac.GetBuyList()
    for index, entry in ipairs(entries) do
        if entry.itemID == itemID then
            table.remove(entries, index)
            activeList().items = entries
            return
        end
    end
end

function ac.SaveRecipeToBuyList()
    if not ac.session.recipe or ac.session.mode ~= "done" then return nil, "Search for a recipe first." end
    local entries, byID = ac.GetBuyList(), {}
    for _, entry in ipairs(entries) do byID[entry.itemID] = entry end
    local added = 0
    for _, row in ipairs(ac.session.rows) do
        if not row.output and ac.BatchRemaining(row) > 0 and not row.vendorPreferred then
            local entry = byID[row.itemID]
            if entry then
                entry.required = math.max(entry.required, row.required)
            else
                if #entries >= MAX_ITEMS then return nil, "This recipe exceeds the 60-item list limit." end
                entries[#entries + 1] = {itemID = row.itemID, required = row.required}
            end
            added = added + 1
        end
    end
    if added == 0 then return nil, "No missing auction reagents." end
    activeList().items = entries
    return added
end

function ac.ClearShoppingTrips()
    trips = {}
end

function ac.RecordShoppingPurchase(row, quantity)
    if row.trip then row.trip.confirmed = row.trip.confirmed + quantity end
end

function ac.SearchBuyList(itemID)
    if ac.batch or ac.pendingPurchase then return false, "Finish or stop the current buying queue first." end
    local entries = {}
    local list = activeList()
    local trip = trips[list] or {}
    for _, entry in ipairs(ac.GetBuyList()) do
        if not itemID or entry.itemID == itemID then
            entry.owned = ac.BuyListOwned(entry.itemID)
            entry.trip = trip[entry.itemID] or {startingOwned = entry.owned, confirmed = 0}
            if entry.trip.confirmed == 0 then entry.trip.startingOwned = entry.owned end
            trip[entry.itemID] = entry.trip
            entries[#entries + 1] = entry
        end
    end
    if #entries == 0 then return false, "Add an item to Buy List first." end
    local names, index = ac.BuyListNames()
    local ok, reason = ac.SearchItems(entries, names[index], true)
    if ok then
        trips[list] = trip
        if ac.SetBatchQuantity then ac.SetBatchQuantity(ac.BatchRemaining(ac.session.rows[1])) end
    end
    return ok, reason
end
