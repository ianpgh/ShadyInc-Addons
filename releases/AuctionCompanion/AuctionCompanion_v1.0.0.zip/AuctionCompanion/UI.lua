local _, ac = ...
-- v0.1.7: price normalization for one-piece crafted outputs.
-- Blizzard's built-in confirmation UI remains responsible for transactions.
local ui, rows, page, qtyBox, buyButton, buyAllButton, selectAllButton, searchBox, statusText, titleText, versionText
local profitText, profitHint
local priceSettingsPanel, vendorCheckbox, professionCheckbox
local buyListPanel
local preview = {}
local ROW_COUNT = 9
local TIER_COUNT = 5
local paging = {}
local resultSort, descending, onlyNeeded, lastSession
local order, sortedRows = {}, {}
local sortLabels = {name="ITEM", price="LOWEST", need="TO BUY"}

local function label(parent, value, size, color)
    local f = parent:CreateFontString(nil, "OVERLAY", size or "GameFontHighlightSmall")
    f:SetJustifyH("LEFT")
    f:SetText(value or "")
    if color then f:SetTextColor(unpack(color)) end
    return f
end
local GOLD = {1,.82,.37}
local LIGHT = {.92,.86,.75}
local MUTED = {.70,.68,.60}
local function at(f, x, y, relative)
    f:SetPoint("TOPLEFT", relative or f:GetParent(), "TOPLEFT", x, y)
    return f
end
local function button(parent, text, width, height, callback)
    local b = CreateFrame("Button", nil, parent, "UIPanelButtonTemplate")
    b:SetSize(width, height)
    b:SetText(text)
    b:SetScript("OnClick", callback)
    return b
end
local function inset(parent)
    -- InsetFrameTemplate4 is used by Blizzard's classic AH UI and is already
    -- present on the Forever client. Fallback keeps Companion standalone.
    local ok, f = pcall(CreateFrame, "Frame", nil, parent, "InsetFrameTemplate4")
    if not ok or not f then
        f = CreateFrame("Frame", nil, parent, "BackdropTemplate")
        if f.SetBackdrop then
            f:SetBackdrop({bgFile="Interface\\Buttons\\WHITE8X8", edgeFile="Interface\\Tooltips\\UI-Tooltip-Border",edgeSize=12,insets={left=4,right=4,top=4,bottom=4}})
            f:SetBackdropColor(.12,.10,.08,.72)
            f:SetBackdropBorderColor(.35,.31,.25,.8)
        end
    end
    f:EnableMouse(true)
    return f
end
local function displayMoney(value)
    if not value or value<=0 then return "--" end
    return ac.money(value)
end
local function money0(value)
    return ac.money(value or 0)
end
-- A profitability estimate always values ALL reagents, including those already owned.
-- Only current, successful item searches are used here; missing prices are not
-- silently treated as zero and scanned historical values are not mixed in.
local function recipeProfit(session)
    local output, cost, outlay, missing = nil, 0, 0, 0
    local reagents, vendorUsed = 0, 0
    for _, r in ipairs(session.rows or {}) do
        if r.output then
            if not output then output=r end
        else
            reagents = reagents+1
            local effective,source
            if ac.api.GetMaterialCost then effective,source=ac.api.GetMaterialCost(r.itemID) end
            -- Fallback to this completed live result, but never treat an
            -- incomplete AH response as a verified cheap auction price.
            if (not effective) and r.minUnit and r.minUnit>0 and r.state=="Ready" then
                effective,source=r.minUnit,'auction'
            end
            if not effective or effective<=0 then
                missing=missing+1
            else
                if source=='vendor' then vendorUsed=vendorUsed+1 end
                cost=cost+(tonumber(r.required) or 0)*effective
                outlay=outlay+math.max(0,(tonumber(r.required) or 0)-(tonumber(r.owned) or 0))*effective
            end
        end
    end
    if not output or reagents==0 then return nil, "Search a profession recipe for a profit estimate." end
    if not output.minUnit or output.minUnit<=0 or output.state=="Partial" or output.state=="Timed out" then missing=missing+1 end
    if session.mode~="done" then return nil, "Profit calculates after the recipe search completes." end
    if missing>0 then return nil, ("%d missing/incomplete auction price%s; profit unavailable."):format(missing, missing==1 and "" or "s") end
    local yield=math.max(1,tonumber(output.outputQuantity) or 1)
    local sale=output.minUnit*yield
    -- The current AH's actual cut may vary (e.g. neutral AH): this is an estimate.
    local fee=math.floor(sale*0.05+0.5)
    local profit=math.floor(sale-fee-cost+0.5)
    return profit, ("Sell %s | Mats %s | Buy %s | %d vendor-priced | 5%% AH cut (est.)"):format(
        money0(sale),money0(math.floor(cost+0.5)),money0(math.floor(outlay+0.5)), vendorUsed)
end
local function quantity()
    return math.max(1, math.min(99999, math.floor(tonumber(qtyBox and qtyBox:GetText()) or 1)))
end
local function chosen()
    return ac.session.rows and ac.session.rows[ac.session.selected or 0]
end

-- Purchases are routed through Blizzard's native in-frame confirmation logic,
-- implemented in Purchase.lua. Never programmatically click its Buy buttons.
local function itemIcon(id)
    if not tonumber(id) then return "Interface\\Icons\\INV_Misc_QuestionMark" end
    if type(GetItemIcon)=="function" then
        local icon=GetItemIcon(id)
        if icon then return icon end
    end
    if C_Item and type(C_Item.GetItemIconByID)=="function" then
        local ok,icon=pcall(C_Item.GetItemIconByID,id)
        if ok and icon then return icon end
    end
    if C_AuctionHouse and C_AuctionHouse.MakeItemKey and C_AuctionHouse.GetItemKeyInfo then
        local ok,key=pcall(C_AuctionHouse.MakeItemKey,id)
        if ok and key then
            local okInfo,info=pcall(C_AuctionHouse.GetItemKeyInfo,key)
            if okInfo and info and info.iconFileID then return info.iconFileID end
        end
    end
    return "Interface\\Icons\\INV_Misc_QuestionMark"
end

local function estimate(row, wanted)
    if not row or not row.minUnit then return nil,nil end
    if row.source=="item" then
        local listing=row.cheapestListing
        if listing then
            return listing.buyout,("Purchases one listing (stack of %d)"):format(listing.quantity or 1)
        end
        return nil,"One listing at a time; search again to confirm price"
    end
    if row.source=="commodity" and wanted==row.requirementQuantity then
        return row.requirementCost,"Estimate only - Blizzard checks final price"
    end
    if row.source=="commodity" and row.withinCap and wanted>row.withinCap then
        return nil, row.maxUnit and "Not enough units at or below your maximum" or "Quantity exceeds available listings"
    end
    local need=wanted
    local total=0
    local tiers=row.tiers
    if row.source=="commodity" and tiers and #tiers>0 then
        if row.available and row.available < wanted then
            return nil,"Quantity exceeds available listings"
        end
        for _,t in ipairs(tiers) do
            local use=math.min(need,t.quantity or 0)
            total=total+(t.unitPrice or 0)*use
            need=need-use
            if need<=0 then break end
        end
        if need>0 then return nil,"Price preview incomplete; Buy requotes live" end
        return total,"Estimate only - Blizzard checks final price"
    end
    return wanted*row.minUnit,"Estimate only - Blizzard checks final price"
end

local function closeOnEscape(frame, name)
    if type(UISpecialFrames) == "table" then table.insert(UISpecialFrames, name) end
    frame:EnableMouse(true)
end

local function buildBuyList(parent)
    local PAGE_SIZE = 7
    local panel = CreateFrame("Frame", "AuctionCompanionBuyList", parent)
    closeOnEscape(panel, "AuctionCompanionBuyList")
    panel:SetSize(544, 374)
    panel:SetPoint("CENTER", parent, "CENTER")
    panel:SetFrameLevel(parent:GetFrameLevel() + 50)
    panel:EnableMouse(true)
    local background = panel:CreateTexture(nil, "BACKGROUND")
    background:SetAllPoints()
    background:SetColorTexture(.095, .075, .055, 1)

    local heading = at(label(panel, "", "GameFontNormalLarge", GOLD), 16, -14)
    heading:SetWidth(370)
    heading:SetMaxLines(1)
    at(button(panel, "Close", 65, 22, function() panel:Hide() end), 463, -10)
    local listRows, listPage = {}, 1
    local refreshList
    local function input(parentFrame, width, x, y, limit, numeric)
        local box = at(CreateFrame("EditBox", nil, parentFrame, "InputBoxTemplate"), x, y)
        box:SetSize(width, 22)
        box:SetAutoFocus(false)
        box:SetMaxLetters(limit)
        if numeric then box:SetNumeric(true) end
        box:SetScript("OnEscapePressed", function(self) self:ClearFocus(); panel:Hide() end)
        return box
    end
    local function switch(direction)
        local names, index = ac.BuyListNames()
        ac.SelectBuyList((index - 1 + direction) % #names + 1)
        listPage = 1
        refreshList()
    end
    at(button(panel, "<", 26, 22, function() switch(-1) end), 383, -10)
    at(button(panel, ">", 26, 22, function() switch(1) end), 417, -10)
    local listName = input(panel, 180, 16, -43, 40)
    local deletePending
    local function edit(action)
        local ok, err = ac.EditBuyList(action, listName:GetText())
        if ok then listName:SetText(""); listName:ClearFocus(); listPage = 1 end
        refreshList(err)
    end
    for i, operation in ipairs({{"New", "new"}, {"Rename", "rename"}, {"Copy", "duplicate"}}) do
        local action = operation[2]
        at(button(panel, operation[1], 69, 22, function() edit(action) end), 208 + (i - 1) * 78, -43)
    end
    at(button(panel, "Delete", 69, 22, function()
        local _, index = ac.BuyListNames()
        if deletePending == index then edit("delete")
        else
            refreshList("Click Delete again to confirm.")
            deletePending = index
        end
    end), 442, -43)
    local itemInput = input(panel, 180, 16, -75, 255)
    local message = at(label(panel, "", "GameFontHighlightSmall", MUTED), 16, -102)
    message:SetWidth(510)
    local function addID()
        local index, err = ac.SaveBuyListItem(itemInput:GetText(), 1, nil, true)
        if index then
            listPage = math.ceil(index / PAGE_SIZE)
            itemInput:SetText("")
            itemInput:ClearFocus()
        end
        refreshList(err)
    end
    at(button(panel, "Add ID / Link", 104, 22, addID), 208, -75)
    itemInput:SetScript("OnEnterPressed", addID)
    local add = at(button(panel, "Add Selected", 102, 22), 318, -75)
    local reagents = at(button(panel, "Add Reagents", 102, 22, function()
        local count, err = ac.SaveRecipeToBuyList()
        refreshList(count and ("%d recipe reagents saved."):format(count) or err)
    end), 425, -75)
    local qtyHeader = at(label(panel, "Qty     Max copper / unit", "GameFontNormalSmall", GOLD), 235, -122)

    local prev = at(button(panel, "<", 28, 23, function()
        listPage = listPage - 1
        refreshList()
    end), 16, -338)
    local pageText = at(label(panel, "", "GameFontHighlightSmall", LIGHT), 54, -344)
    local nextPage = at(button(panel, ">", 28, 23, function()
        listPage = listPage + 1
        refreshList()
    end), 114, -338)
    local function searchFor(itemID)
        local ok, err = ac.SearchBuyList(itemID)
        if ok then panel:Hide() else message:SetText(err) end
    end
    local search = at(button(panel, "Scan List", 112, 23, function() searchFor() end), 415, -338)

    for i = 1, PAGE_SIZE do
        local line = CreateFrame("Frame", nil, panel)
        line:SetSize(510, 27)
        at(line, 16, -137 - (i - 1) * 28)
        local icon = line:CreateTexture(nil, "ARTWORK")
        icon:SetSize(18,18)
        at(icon, 0, -4)
        local name = at(label(line, "", "GameFontHighlight", LIGHT), 24, -6)
        name:SetWidth(184)
        name:SetMaxLines(1)
        name:SetWordWrap(false)

        local amount = input(line, 46, 219, -1, 5, true)
        local cap = input(line, 91, 275, -1, 10, true)
        local function save()
            local index, err = ac.SaveBuyListItem(line.itemID, amount:GetText(), cap:GetText())
            if index then refreshList() else message:SetText(err) end
        end
        at(button(line, "Save", 44, 21, save), 375, -2)
        at(button(line, "Scan", 47, 21, function() searchFor(line.itemID) end), 426, -2)
        at(button(line, "X", 24, 21, function()
            ac.RemoveBuyListItem(line.itemID)
            refreshList()
        end), 482, -2)
        amount:SetScript("OnEnterPressed", save)
        cap:SetScript("OnEnterPressed", save)
        listRows[i] = {frame = line, name = name, icon = icon, amount = amount, cap = cap}
    end

    refreshList = function(status)
        deletePending = nil
        local names, index = ac.BuyListNames()
        heading:SetText(("%s  (%d/%d)"):format(names[index], index, #names))
        local entries = ac.GetBuyList()
        local pages = math.max(1, math.ceil(#entries / PAGE_SIZE))
        listPage = math.max(1, math.min(listPage, pages))
        for i, row in ipairs(listRows) do
            local entry = entries[(listPage - 1) * PAGE_SIZE + i]
            row.amount:ClearFocus()
            row.cap:ClearFocus()
            row.frame:SetShown(entry ~= nil)
            if entry then
                row.frame.itemID = entry.itemID
                row.name:SetText(ac.itemName(entry.itemID))
                row.icon:SetTexture(itemIcon(entry.itemID))
                row.amount:SetText(tostring(entry.required))
                row.cap:SetText(entry.maxUnit and tostring(entry.maxUnit) or "")
            end
        end
        pageText:SetText(("%d / %d"):format(listPage, pages))
        prev:SetEnabled(listPage > 1)
        nextPage:SetEnabled(listPage < pages)
        search:SetEnabled(#entries > 0)
        qtyHeader:SetShown(#entries > 0)
        panel:RefreshSelection()
        message:SetText(status or (#entries == 0 and "Add an item by ID, item link, or selected result." or "Blank maximum means no price limit."))
    end

    function panel:RefreshSelection()
        local row = chosen()
        add:SetEnabled(row ~= nil and row.itemID ~= nil and ac.session.mode == "done")
        reagents:SetEnabled(ac.session.recipe == true and ac.session.mode == "done")
    end
    add:SetScript("OnClick", function()
        local row = chosen()
        if not row then return end
        for index, entry in ipairs(ac.GetBuyList()) do
            if entry.itemID == row.itemID then
                listPage = math.ceil(index / PAGE_SIZE)
                refreshList()
                listRows[(index - 1) % PAGE_SIZE + 1].amount:SetFocus()
                return
            end
        end
        local index, err = ac.SaveBuyListItem(row.itemID, quantity())
        if index then listPage = math.ceil(index / PAGE_SIZE) end
        refreshList(err)
    end)
    panel:SetScript("OnShow", function() refreshList() end)
    panel:SetScript("OnHide", function()
        deletePending = nil
        listName:ClearFocus()
        itemInput:ClearFocus()
        for _, row in ipairs(listRows) do row.amount:ClearFocus(); row.cap:ClearFocus() end
    end)
    panel:Hide()
    return panel
end

local function refreshPreview()
    if not ui then return end
    local r=chosen()
    local has=r~=nil
    local busy=ac.session.mode~="done"
    local auctionItem=has and r.source=="item"
    preview.name:SetText(has and (r.name or ac.itemName(r.itemID)) or "Select an item")
    preview.icon:SetTexture(has and itemIcon(r.itemID) or "Interface\\Icons\\INV_Misc_QuestionMark")
    preview.icon:SetShown(has)
    preview.type:SetText(has and (r.role or r.output and "Finished item" or r.source=="browse" and "Search result" or ac.session.buyList and "Saved item" or "Recipe reagent") or "Select a result on the left for buy details.")
    preview.need:SetText(has and (r.output and "Compare" or tostring(ac.BatchRemaining(r))) or "--")
    preview.owned:SetText(has and tostring(r.owned or 0) or "--")
    local available = has and r.available and tostring(r.available) or "--"
    if has and r.maxUnit and r.withinCap then
        available = ("%d at max or less (%d total)"):format(r.withinCap, r.available)
    end
    preview.available:SetText(available)
    preview.unit:SetText(has and displayMoney(auctionItem and r.cheapestListing and r.cheapestListing.buyout or r.minUnit) or "--")
    preview.priceLabel:SetText(auctionItem and "Listing price" or "Lowest / unit")
    qtyBox:SetEnabled(not auctionItem)
    preview.quantityLabel:SetText(auctionItem and "One listing" or "Quantity")
    preview.note:SetText(has and r.maxUnit and
        "Check Blizzard's final quote against your maximum before confirming." or
        "Blizzard confirms the live price before buying.")
    local cost, explanatory=estimate(r, quantity())
    preview.total:SetText(cost and ac.money(cost) or "--")
    if has and r.maxUnit and r.minUnit then
        explanatory = r.minUnit and r.minUnit > r.maxUnit and "Over maximum / unit" or
            ("Max / unit " .. ac.money(r.maxUnit))
    end
    preview.estimate:SetText(has and (explanatory or r.state or "No valid buyout observed") or "")
    preview.estimate:SetShown(has)
    local canBuy=has and not busy and r.minUnit~=nil and r.source~="browse"
    if canBuy and ac.session.buyList then
        local remaining = ac.BatchRemaining(r)
        local amount = auctionItem and 1 or quantity()
        canBuy = remaining>=amount and (not r.maxUnit or r.minUnit<=r.maxUnit) and
            (auctionItem or not r.withinCap or r.withinCap>=amount)
    end
    buyButton:SetEnabled(canBuy and not ac.pendingPurchase and not (ac.batch and ac.batch.waiting) and
        not (r.source=="commodity" and tonumber(r.available or 0)<quantity()))
    local tiers=has and r.tiers or nil
    local height=ui.right and ui.right:GetHeight() or 0
    local showTiers=height>=415 and tiers and #tiers>0
    preview.tiersHeading:SetShown(not not showTiers)
    for i=1,TIER_COUNT do
        local t=showTiers and tiers[i] or nil
        local line=preview.tierLines[i]
        local maxVisible=math.max(0,math.floor((height-386)/19))
        line:SetShown(t~=nil and i<=maxVisible)
        if t then
            line.price:SetText(ac.money(t.unitPrice))
            line.available:SetText("x"..tostring(t.quantity or 0))
            line.note:SetText(r.source=="commodity" and "per item" or "per listing")
        end
    end
end

local function updateLayout()
    if not ui then return end
    local w = math.max(730,ui:GetWidth())
    local leftWidth = math.floor(w*.515)
    local rightWidth = math.max(250, w-leftWidth-18)
    if profitHint then
        profitHint:SetWidth(math.max(240,w-405))
        profitHint:SetMaxLines(2)
        profitHint:SetWordWrap(true)
    end
    if statusText then statusText:SetWidth(math.max(420,w-132)) end
    if titleText then titleText:SetWidth(math.max(180,leftWidth-38)) end
    if preview and preview.name then preview.name:SetWidth(math.max(190,rightWidth-120)) end
    if preview and preview.estimate then preview.estimate:SetWidth(math.max(250,rightWidth-42)) end
    if preview and preview.note then preview.note:SetWidth(math.max(250,rightWidth-42)) end
    if preview and preview.queueNote then preview.queueNote:SetWidth(math.max(250,leftWidth-22)) end
    ui.left:ClearAllPoints()
    ui.left:SetPoint("TOPLEFT",ui,"TOPLEFT",7,-79)
    ui.left:SetPoint("BOTTOMLEFT",ui,"BOTTOMLEFT",7,54)
    ui.left:SetWidth(leftWidth-9)
    ui.right:ClearAllPoints()
    ui.right:SetPoint("TOPLEFT",ui,"TOPLEFT",leftWidth+5,-79)
    ui.right:SetPoint("BOTTOMRIGHT",ui,"BOTTOMRIGHT",-7,54)
    for _,r in ipairs(rows) do
        -- Coin textures need more horizontal space than abbreviated g/s/c.
        r.name:SetWidth(leftWidth-266)
        r.price:ClearAllPoints()
        r.price:SetPoint("TOPRIGHT",r,"TOPRIGHT",-53,-5)
        r.price:SetWidth(113)
        r.need:ClearAllPoints()
        r.need:SetPoint("TOPRIGHT",r,"TOPRIGHT",-7,-5)
        r.need:SetWidth(42)
    end
end

local function visibleResults(session)
    if lastSession ~= session then
        lastSession = session
        onlyNeeded = false
        page = 1
    end
    for i = #sortedRows, 1, -1 do
        order[sortedRows[i]] = nil
        sortedRows[i] = nil
    end
    for index, row in ipairs(session.rows) do
        if not onlyNeeded or ac.BatchRemaining(row) > 0 then
            sortedRows[#sortedRows + 1] = row
            order[row] = index
        end
    end
    if resultSort then
        table.sort(sortedRows, function(a, b)
            local field = resultSort
            local av, bv
            if field == "name" then
                av, bv = a.name:lower(), b.name:lower()
            elseif field == "price" then
                av, bv = a.minUnit or math.huge, b.minUnit or math.huge
                if a.minUnit == nil and b.minUnit ~= nil then return false end
                if a.minUnit ~= nil and b.minUnit == nil then return true end
            else
                av, bv = ac.BatchRemaining(a), ac.BatchRemaining(b)
            end
            if av == bv then return order[a] < order[b] end
            if descending then return av > bv end
            return av < bv
        end)
    end
    return sortedRows
end

local function refresh()
    if not ui or not ui:IsShown() then return end
    local session=ac.session
    if buyListPanel and buyListPanel:IsShown() then buyListPanel:RefreshSelection() end
    titleText:SetText((session.label and session.label~="") and session.label or "Search results")
    if vendorCheckbox then vendorCheckbox:SetChecked(ac.PreferVendor and ac.PreferVendor() or false) end
    if professionCheckbox then professionCheckbox:SetChecked(ac.ProfessionSearchEnabled()) end
    if profitText then
        local gain,explanation=recipeProfit(session)
        if session.shopping then
            gain=nil
            explanation='Writ shopping: select a row to buy; Buy All requires individual Blizzard confirmations.'
        end
        profitText:SetText(session.buyList and 'Buy List shopping' or session.shopping and 'Writ shopping' or
            (gain and ((gain>=0 and "Profit: +" or "Profit: -")..money0(math.abs(gain))) or "Profit: --"))
        profitText:SetTextColor(gain==nil and .92 or gain>=0 and .28 or 1,
            gain==nil and .80 or gain>=0 and 1 or .35,
            gain==nil and .40 or gain>=0 and .42 or .35)
        if session.buyList then
            local total, remaining, confirmed, unknown = 0, 0, 0, 0
            for _, row in ipairs(session.rows) do
                local need = ac.BatchRemaining(row)
                remaining = remaining + need
                confirmed = confirmed + (row.acBought or 0)
                if need > 0 then
                    local cost = row.state == "Ready" and estimate(row, need)
                    if row.source == "item" and (not row.cheapestListing or row.cheapestListing.quantity ~= need) then cost = nil end
                    if cost and row.maxUnit and cost / need > row.maxUnit then cost = nil end
                    if cost then total = total + cost else unknown = unknown + 1 end
                end
            end
            profitText:SetText("Est. AH: " .. (unknown > 0 and total == 0 and "--" or ac.money(total)))
            explanation = ("%d left, %d confirmed%s"):format(remaining, confirmed,
                unknown > 0 and (", " .. unknown .. " unquoted") or "")
        end
        profitHint:SetText(explanation)
    end
    if ac.batch then
        buyAllButton:SetText(ac.batch.waiting and "Confirm in WoW" or ("Buy Next (%d)"):format(ac.BatchCount()))
        buyAllButton:SetEnabled(not ac.batch.waiting)
        selectAllButton:SetText("Stop")
    else
        buyAllButton:SetText(("Buy All (%d)"):format(ac.BatchCount()))
        buyAllButton:SetEnabled(session.mode=="done" and ac.BatchCount()>0)
        selectAllButton:SetText("All")
    end
    statusText:SetText(session.status or "")
    local results=visibleResults(session)
    local total=#results
    ui.needFilter:SetText(onlyNeeded and "Show All" or "To Buy Only")
    ui.needFilter:SetEnabled(session.mode=="done" and not not (session.buyList or session.recipe or session.shopping))
    for key, header in pairs(ui.sortHeaders) do
        header:SetText(sortLabels[key] .. (resultSort==key and (descending and " -" or " +") or ""))
    end
    page=math.max(1,math.min(page,math.max(1,math.ceil(total/ROW_COUNT))))
    for i, b in ipairs(rows) do
        local row=results[(page-1)*ROW_COUNT+i]
        b.data=row
        b:SetShown(row~=nil)
        if row then
            if row.itemID then
                local n=ac.itemName(row.itemID)
                if n~=("Item #"..tostring(row.itemID)) and n~="Unknown" then row.name=n end
            end
            b.icon:SetTexture(itemIcon(row.itemID))
            b.name:SetText((row.output and "|cff80c6ff" or "|cfffff0d4")..
                tostring(row.name or row.itemID).."|r")
            local price = displayMoney(row.minUnit)
            if session.buyList then
                if row.minUnit and row.maxUnit and row.minUnit > row.maxUnit then price = "Over max"
                elseif not row.minUnit then price = row.state or "--"
                elseif row.state == "Partial" then price = "~ " .. price end
            end
            b.price:SetText(price)
            local left=ac.BatchRemaining(row)
            b.need:SetText(row.output and "--" or left==0 and "OK" or tostring(left))
            local checkable=not row.output and left>0
            b.check:SetShown(not row.output)
            b.check:SetText(left==0 and "OK" or row.acSelected and "[X]" or "[ ]")
            b.check:SetTextColor(left==0 and .7 or row.acSelected and .5 or 1,
                left==0 and .75 or row.acSelected and 1 or .85,
                left==0 and .7 or row.acSelected and .35 or .65)
            local selected=row==chosen()
            if row.acSelected and checkable then
                b.highlight:SetColorTexture(.17,.40,.12,selected and .75 or .44)
            else
                b.highlight:SetColorTexture(selected and .40 or .11,selected and .32 or .09,
                    selected and .14 or .07,selected and .80 or (i%2==0 and .31 or .13))
            end
        end
    end
    paging.label:SetText(("%d / %d"):format(page,math.max(1,math.ceil(total/ROW_COUNT))))
    if preview.queueNote then
        preview.queueNote:SetText(ac.batch and (ac.batch.waiting and
            "Confirm the pending purchase in Blizzard's dialog." or
            "Queue ready: press Buy Next to continue.") or
            "Selected items are green. Click their boxes to toggle Buy All.")
    end
    paging.prev:SetEnabled(page>1)
    paging.next:SetEnabled(page*ROW_COUNT<total)
    ui.stop:SetShown(session.mode=="searching" or session.mode=="browse" or
        session.mode=="name-scan" or ac.pendingPurchase~=nil)
    refreshPreview()
end

function ac.BuildUI()
    if ui then return ui end
    local ah=AuctionHouseFrame
    if not ah then return nil end
    ui=CreateFrame("Frame","AuctionCompanionFrame",ah)
    ac.window=ui
    -- Borrow Blizzard's existing AH background: no competing black backdrop,
    -- thick gold border, artificial title bar, or stand-alone window.
    ui:SetPoint("TOPLEFT",ah,"TOPLEFT",4,-103)
    ui:SetPoint("BOTTOMRIGHT",ah,"BOTTOMRIGHT",-4,27)
    ui:SetFrameLevel(ah:GetFrameLevel()+3)
    ui:EnableMouse(true)
    ui:SetScript("OnShow",refresh)
    ui:SetScript("OnHide", function()
        if buyListPanel then buyListPanel:Hide() end
        if priceSettingsPanel then priceSettingsPanel:Hide() end
    end)
    ui:Hide()

    local searchLabel=label(ui,"Search Term:","GameFontNormal",GOLD)
    at(searchLabel,28,-15)
    searchBox=CreateFrame("EditBox",nil,ui,"InputBoxTemplate")
    searchBox:SetPoint("TOPLEFT",ui,"TOPLEFT",128,-7)
    searchBox:SetSize(291,22)
    searchBox:SetAutoFocus(false)
    searchBox:SetMaxLetters(80)
    searchBox:SetScript("OnEscapePressed",function(self)self:ClearFocus()end)
    local function doTextSearch()
        searchBox:ClearFocus()
        local ok,err=ac.SearchText(searchBox:GetText())
        if not ok then ac.Status(err) end
    end
    searchBox:SetScript("OnEnterPressed",doTextSearch)
    button(ui,"Search",98,23,doTextSearch):SetPoint("TOPLEFT",ui,"TOPLEFT",435,-6)
    button(ui,"Clear",74,23,function()
        ac.Cancel("Cleared")
        if ac.ClearBatch then ac.ClearBatch() end
        ac.session={rows={},mode="idle",label="",selected=nil,status="Ready for another search."}
        searchBox:SetText("")
        qtyBox:SetText("1")
        ac.Notify()
    end):SetPoint("TOPLEFT",ui,"TOPLEFT",542,-6)
    local scanTop=button(ui,"Full Scan",105,23,function()
        if not ac.FullScanStart then ac.Status("Scanner is unavailable");return end
        local ok,err=ac.FullScanStart()
        if not ok then ac.Status(err or "Unable to start scan");ac.announce(err or "Unable to start scan") end
    end)
    scanTop:SetPoint("TOPRIGHT",ui,"TOPRIGHT",-16,-6)
    if ac.RegisterScanButton then ac.RegisterScanButton(scanTop) end
    scanTop:SetScript("OnEnter",function(self)
        GameTooltip:SetOwner(self,"ANCHOR_TOP")
        GameTooltip:AddLine("Auction Companion Full Scan",1,.82,.3)
        local remaining,source=ac.GetFullScanCooldown and ac.GetFullScanCooldown()
        if remaining and remaining>0 then
            local sec=math.ceil(remaining)
            GameTooltip:AddLine(("Next scan in %d:%02d"):format(math.floor(sec/60),sec%60),1,.5,.35)
            GameTooltip:AddLine(tostring(source or "shared server cooldown"),.8,.8,.8,true)
            if type(date)=="function" then
                GameTooltip:AddLine("Estimated ready: "..date("%I:%M %p",time()+sec),.8,.8,.8)
            end
        else
            GameTooltip:AddLine("Ready to request; an unobserved cooldown may still apply.",.75,.85,.7,true)
        end
        GameTooltip:AddLine("Shares its full-scan cooldown with Auctionator and AHledger.",.9,.9,.9,true)
        GameTooltip:Show()
    end)
    scanTop:SetScript("OnLeave",function()GameTooltip:Hide()end)

    profitText=label(ui,"Profit: --","GameFontNormal",GOLD)
    profitText:SetPoint("TOPLEFT",ui,"TOPLEFT",29,-39)
    profitText:SetWidth(245)
    profitHint=label(ui,"Select a recipe to estimate profit.","GameFontHighlightSmall",MUTED)
    profitHint:SetPoint("TOPLEFT",ui,"TOPLEFT",280,-40)
    -- Reserve space on the second row for one compact settings toggle.
    profitHint:SetWidth(math.max(210,ui:GetWidth()-405))
    local pricesButton=button(ui,'Settings',78,20,function()
        if priceSettingsPanel then
            priceSettingsPanel:SetShown(not priceSettingsPanel:IsShown())
        end
    end)
    pricesButton:SetPoint('TOPRIGHT',ui,'TOPRIGHT',-16,-34)
    priceSettingsPanel=CreateFrame("Frame","AuctionCompanionSettings",ui)
    closeOnEscape(priceSettingsPanel,"AuctionCompanionSettings")
    local settingsBackground=priceSettingsPanel:CreateTexture(nil,"BACKGROUND")
    settingsBackground:SetAllPoints()
    settingsBackground:SetColorTexture(.095,.075,.055,1)
    priceSettingsPanel:SetSize(332,131)
    at(label(priceSettingsPanel,"RIP Shady","GameFontHighlightSmall",GOLD),16,-110)
    priceSettingsPanel:SetPoint('TOPRIGHT',pricesButton,'BOTTOMRIGHT',0,-3)
    priceSettingsPanel:SetFrameLevel(ui:GetFrameLevel()+40)
    vendorCheckbox=CreateFrame('CheckButton',nil,priceSettingsPanel,'UICheckButtonTemplate')
    vendorCheckbox:SetSize(26,26)
    vendorCheckbox:SetPoint('TOPLEFT',priceSettingsPanel,'TOPLEFT',10,-10)
    vendorCheckbox:SetChecked(ac.PreferVendor and ac.PreferVendor() == true)
    local vendorLabel=label(priceSettingsPanel,'Use vendor prices when cheaper','GameFontNormal',GOLD)
    vendorLabel:SetPoint('LEFT',vendorCheckbox,'RIGHT',2,1)
    vendorCheckbox:SetScript('OnClick',function(self)
        if type(ac.SetPreferVendor)~='function' then return end
        local ok,err=ac.SetPreferVendor(self:GetChecked())
        if not ok then self:SetChecked(ac.PreferVendor());ac.Status(err) end
    end)
    local vendorNote=label(priceSettingsPanel,
        'Crafting estimates only. AH search prices are unchanged.',
        'GameFontHighlightSmall',MUTED)
    vendorNote:SetPoint('TOPLEFT',priceSettingsPanel,'TOPLEFT',16,-47)
    vendorNote:SetWidth(300)
    professionCheckbox=CreateFrame('CheckButton',nil,priceSettingsPanel,'UICheckButtonTemplate')
    professionCheckbox:SetSize(26,26)
    professionCheckbox:SetPoint('TOPLEFT',priceSettingsPanel,'TOPLEFT',10,-75)
    professionCheckbox:SetChecked(ac.ProfessionSearchEnabled())
    local professionLabel=label(priceSettingsPanel,'Show AC Search in profession windows','GameFontNormal',GOLD)
    professionLabel:SetPoint('LEFT',professionCheckbox,'RIGHT',2,1)
    professionCheckbox:SetScript('OnClick',function(self)
        if not ac.SetProfessionSearchEnabled(self:GetChecked()) then
            self:SetChecked(ac.ProfessionSearchEnabled())
        end
    end)
    priceSettingsPanel:Hide()
    profitHint:SetMaxLines(2)
    profitHint:SetWordWrap(true)

    ui.left=inset(ui)
    ui.right=inset(ui)
    titleText=label(ui.left,"Search results","GameFontNormal",GOLD)
    at(titleText,15,-13)
    selectAllButton=button(ui.left,"All",45,20,function()
        if ac.batch then
            ac.ClearBatch()
            ac.Status("Reagent queue stopped. If Blizzard's purchase dialog is still open, close it separately.")
        else
            ac.BatchSelectAll()
        end
    end)
    selectAllButton:SetPoint("BOTTOMLEFT",ui.left,"BOTTOMLEFT",15,12)
    buyAllButton=button(ui.left,"Buy All",119,21,function()
        local ok,err=ac.BatchBeginOrNext()
        if not ok and err then ac.Status(err) end
    end)
    buyAllButton:SetPoint("LEFT",selectAllButton,"RIGHT",8,0)
    titleText:SetWidth(175)
    titleText:SetMaxLines(1)
    titleText:SetWordWrap(false)
    ui.needFilter=button(ui.left,"To Buy Only",76,19,function()
        onlyNeeded=not onlyNeeded
        page=1
        refresh()
    end)
    ui.needFilter:SetPoint("TOPRIGHT",ui.left,"TOPRIGHT",-12,-8)
    ui.sortHeaders={}
    local function makeHeader(field, width)
        local header = CreateFrame("Button",nil,ui.left)
        header:SetSize(width,18)
        header:SetNormalFontObject(GameFontNormalSmall)
        header:SetHighlightFontObject(GameFontHighlightSmall)
        header:SetScript("OnClick",function()
            descending = resultSort==field and not descending or false
            resultSort=field
            page=1
            refresh()
        end)
        ui.sortHeaders[field]=header
        header:SetText(sortLabels[field])
        return header
    end
    at(makeHeader("name",58),10,-33)
    makeHeader("price",74):SetPoint("TOPRIGHT",ui.left,"TOPRIGHT",-60,-33)
    makeHeader("need",58):SetPoint("TOPRIGHT",ui.left,"TOPRIGHT",-4,-33)
    rows={}
    for i=1,ROW_COUNT do
        local r=CreateFrame("Button",nil,ui.left)
        r:SetPoint("TOPLEFT",ui.left,"TOPLEFT",12,-58-(i-1)*26)
        r:SetPoint("TOPRIGHT",ui.left,"TOPRIGHT",-12,-58-(i-1)*26)
        r:SetHeight(25)
        r.highlight=r:CreateTexture(nil,"BACKGROUND")
        r.highlight:SetAllPoints()
        r.icon=r:CreateTexture(nil,"ARTWORK")
        r.icon:SetPoint("TOPLEFT",r,"TOPLEFT",27,-4)
        r.check=label(r,"[ ]","GameFontHighlightSmall",GOLD)
        r.check:SetPoint("TOPLEFT",r,"TOPLEFT",1,-6)
        r.check:SetSize(26,18)
        r.icon:SetSize(18,18)
        r.name=label(r,"","GameFontHighlight",LIGHT)
        at(r.name,51,-4)
        r.name:SetMaxLines(1)
        r.name:SetWordWrap(false)
        r.name:SetNonSpaceWrap(false)
        r.price=label(r,"","GameFontHighlight",LIGHT)
        r.price:SetJustifyH("RIGHT")
        r.need=label(r,"","GameFontHighlight",GOLD)
        r.need:SetJustifyH("RIGHT")
        r:SetScript("OnClick",function(self,mouseButton)
            local selected=self.data
            if not selected then return end
            if ac.session.mode=="searching" or ac.session.mode=="browse" then return end
            if selected.source=="browse" then
                local ok,err=ac.SearchOne(selected.itemID,1)
                if not ok then ac.Status(err) end
            else
                for n,item in ipairs(ac.session.rows) do
                    if item==selected then ac.session.selected=n; break end
                end
                qtyBox:SetText(tostring(selected.source=="item" and 1 or
                    (ac.BatchRemaining(selected)>0 and ac.BatchRemaining(selected) or 1)))
                ac.Notify()
            end
        end)
        local toggle=CreateFrame("Button",nil,r)
        toggle:SetPoint("TOPLEFT",r,"TOPLEFT",0,0)
        toggle:SetSize(28,25)
        toggle:SetScript("OnClick",function()
            local ok,err=ac.BatchToggle(r.data)
            if not ok and err then ac.Status(err) end
        end)
        r.toggle=toggle
        r:SetScript("OnEnter",function(self)
            if not (self.data and self.data.itemID) then return end
            GameTooltip:SetOwner(self,"ANCHOR_RIGHT")
            if type(GameTooltip.SetItemByID)=="function" then GameTooltip:SetItemByID(self.data.itemID)
            else GameTooltip:AddLine(ac.itemName(self.data.itemID),1,.82,.25) end
            GameTooltip:AddLine(self.data.source=="browse" and "Click to inspect listings" or
                "Click item for details; checkbox selects it for Buy All",1,.82,.25,true)
            local observed = self.data.observedAt
            if observed and observed > 0 and type(date) == "function" then
                GameTooltip:AddLine("Observed " .. date("%I:%M %p", observed) ..
                    (self.data.state=="Partial" and " (partial results)" or ""),.9,.8,.6)
            end
            if not self.data.output and ac.api.GetMaterialCost then
                local selected,source,kind,ah,vendor=ac.api.GetMaterialCost(self.data.itemID)
                if vendor then
                    GameTooltip:AddLine('Vendor buy: '..ac.money(vendor)..
                        (kind=='reference' and ' (standard reference)' or ' (merchant observed)'),.55,1,.48)
                    GameTooltip:AddLine('AH observed: '..(ah and ac.money(ah) or 'not available'),.9,.8,.6)
                    GameTooltip:AddLine('Crafting cost: '..(selected and ac.money(selected) or 'unknown')..' ('..source..')',1,.82,.3)
                    if source=='vendor' then
                        GameTooltip:AddLine('Excluded from Buy All by default; click checkbox to override.',.72,.92,.6,true)
                    end
                end
            end
            GameTooltip:Show()
        end)
        r:SetScript("OnLeave",function()GameTooltip:Hide()end)
        r:Hide()
        rows[i]=r
    end
    paging.prev=button(ui.left,"<",26,20,function()page=page-1;refresh()end)
    paging.prev:SetPoint("BOTTOMRIGHT",ui.left,"BOTTOMRIGHT",-94,12)
    paging.label=label(ui.left,"1 / 1","GameFontHighlightSmall",MUTED)
    paging.label:SetWidth(58)
    paging.label:SetJustifyH("CENTER")
    paging.label:SetPoint("BOTTOMRIGHT",ui.left,"BOTTOMRIGHT",-34,18)
    paging.next=button(ui.left,">",26,20,function()page=page+1;refresh()end)
    paging.next:SetPoint("BOTTOMRIGHT",ui.left,"BOTTOMRIGHT",-9,12)

    local p=ui.right
    preview.heading=label(p,"BUY DETAILS","GameFontNormal",GOLD)
    at(preview.heading,17,-12)
    local buyListButton = button(p, "Buy List", 84, 22, function()
        if not buyListPanel then buyListPanel = buildBuyList(ui) end
        buyListPanel:SetShown(not buyListPanel:IsShown())
    end)
    buyListButton:SetPoint("TOPRIGHT", p, "TOPRIGHT", -12, -7)
    preview.icon=p:CreateTexture(nil,"ARTWORK")
    preview.icon:SetPoint("TOPLEFT",p,"TOPLEFT",19,-38)
    preview.icon:SetSize(39,39)
    preview.name=label(p,"Select an item","GameFontNormalLarge",LIGHT)
    at(preview.name,67,-40)
    preview.name:SetMaxLines(1)
    preview.name:SetWordWrap(false)
    preview.type=label(p,"","GameFontHighlightSmall",MUTED)
    at(preview.type,67,-66)

    preview.quantityLabel=label(p,"Quantity","GameFontNormal",GOLD)
    preview.quantityLabel:SetPoint("TOPLEFT",p,"TOPLEFT",27,-103)
    qtyBox=CreateFrame("EditBox",nil,p,"InputBoxTemplate")
    qtyBox:SetSize(88,23)
    qtyBox:SetPoint("TOPLEFT",p,"TOPLEFT",155,-96)
    qtyBox:SetNumeric(true)
    qtyBox:SetMaxLetters(5)
    qtyBox:SetText("1")
    qtyBox:SetAutoFocus(false)
    qtyBox:SetScript("OnEscapePressed",function(self)self:ClearFocus()end)
    qtyBox:SetScript("OnEnterPressed",function(self)self:ClearFocus()end)
    qtyBox:SetScript("OnTextChanged",function() if ui and ui:IsShown() then refreshPreview() end end)

    -- Keep the entire purchase section inside Blizzard's shorter AH panes.
    for _,s in ipairs({{"Required",-132,"need"},{"Owned",-154,"owned"},
        {"Available",-176,"available"},{"Lowest / unit",-199,"unit"},
        {"Est. total",-224,"total"}}) do
        local name=label(p,s[1],"GameFontNormal",GOLD)
        name:SetPoint("TOPLEFT",p,"TOPLEFT",27,s[2])
        if s[3]=="unit" then preview.priceLabel=name end
        local val=label(p,"--","GameFontHighlight",LIGHT)
        val:SetPoint("TOPLEFT",p,"TOPLEFT",155,s[2])
        val:SetWidth(230)
        preview[s[3]]=val
    end
    preview.estimate=label(p,"","GameFontHighlightSmall",MUTED)
    preview.estimate:SetPoint("TOPLEFT",p,"TOPLEFT",27,-246)
    preview.estimate:SetMaxLines(1)
    preview.estimate:SetWordWrap(false)
    preview.queueNote=label(ui,"","GameFontHighlightSmall",MUTED)
    preview.queueNote:SetPoint("BOTTOMLEFT",ui.left,"BOTTOMLEFT",12,-18)

    buyButton=button(p,"Buy",156,26,function()
        local ok,err=ac.Buy(chosen(),quantity())
        if not ok then ac.Status(err or "Unable to start purchase") end
    end)
    buyButton:SetPoint("TOPLEFT",p,"TOPLEFT",151,-266)
    local note=label(p,"Blizzard confirms the live price before buying.","GameFontHighlightSmall",MUTED)
    note:SetPoint("TOPLEFT",p,"TOPLEFT",27,-299)
    note:SetMaxLines(1)
    note:SetWordWrap(false)
    note:SetWidth(420)
    preview.note = note

    preview.tiersHeading=label(p,"RECENT PRICE LEVELS","GameFontNormalSmall",GOLD)
    preview.tiersHeading:SetPoint("TOPLEFT",p,"TOPLEFT",27,-356)
    preview.tierLines={}
    for i=1,TIER_COUNT do
        local line={}
        local y=-376-(i-1)*19
        line.price=label(p,"","GameFontHighlightSmall",LIGHT)
        line.price:SetPoint("TOPLEFT",p,"TOPLEFT",40,y)
        line.price:SetWidth(102)
        line.available=label(p,"","GameFontHighlightSmall",LIGHT)
        line.available:SetPoint("TOPLEFT",p,"TOPLEFT",163,y)
        line.available:SetWidth(62)
        line.note=label(p,"","GameFontHighlightSmall",MUTED)
        line.note:SetPoint("TOPLEFT",p,"TOPLEFT",240,y)
        line.note:SetWidth(145)
        function line:SetShown(visible)
            self.price:SetShown(visible)
            self.available:SetShown(visible)
            self.note:SetShown(visible)
        end
        preview.tierLines[i]=line
    end

    statusText=label(ui,"Ready to search","GameFontHighlightSmall",MUTED)
    statusText:SetPoint("BOTTOMLEFT",ui,"BOTTOMLEFT",13,22)
    statusText:SetWidth(680)
    ui.stop=button(ui,"Stop",68,21,function()
        local pending = ac.pendingPurchase ~= nil
        ac.Cancel("Stopped")
        ac.Status(pending and "Tracking cleared. Close Blizzard’s purchase dialog if it is still open." or "Stopped.")
    end)
    ui.stop:SetPoint("BOTTOMRIGHT",ui,"BOTTOMRIGHT",-10,13)
    local footer=label(ui,"RIP Shady","GameFontHighlightSmall",MUTED)
    footer:SetPoint("BOTTOMLEFT",ui,"BOTTOMLEFT",13,3)
    footer:SetWidth(70)
    versionText=label(ui,"v"..tostring(ac.version or "?"),"GameFontHighlightSmall",MUTED)
    versionText:SetPoint("LEFT",footer,"RIGHT",6,0)
    versionText:SetWidth(72)
    ui:SetScript("OnSizeChanged",updateLayout)
    ac.Subscribe(refresh)
    page=1
    updateLayout()
    return ui
end
function ac.SetBatchQuantity(amount)
    if qtyBox then qtyBox:SetText(tostring(math.max(1,math.floor(tonumber(amount) or 1)))) end
end
function ac.Open()
    if not ac.IsAtAH() then ac.announce("Open the Auction House first."); return false end
    if not ui then ac.BuildUI() end
    if not ui then return false end
    return ac.SelectTab and ac.SelectTab() or false
end
ac.api.Open=ac.Open
