local _, ac = ...
-- All transactions are initiated by a human pressing AC's Buy button.
-- Blizzard retains its own price/auction confirmation and handles the purchase.
-- No simulated clicks, automatic confirmations, or reparented protected frames.
local AH = C_AuctionHouse

local function get(fn, ...)
    if type(fn) ~= "function" then return nil end
    local ok, result = pcall(fn, ...)
    if ok then return result end
end

local function requested(amount)
    local n=tonumber(amount)
    if not n or n~=n or n<1 or n>99999 then return nil end
    return math.floor(n)
end

local function findCommodityQuote(id, qty, maxUnit)
    if type(AH.GetNumCommoditySearchResults)~="function" or
        type(AH.GetCommoditySearchResultInfo)~="function" then
        return nil, "Commodity buying isn't supported by this client"
    end
    local count=get(AH.GetNumCommoditySearchResults,id)
    if type(count)~="number" or count<1 then
        return nil, "Listings unavailable. Run the search again."
    end
    local levels={}
    for i=1, math.min(1000,count) do
        local t=get(AH.GetCommoditySearchResultInfo,id,i)
        if type(t)=="table" and not t.containsOwnerItem then
            local price=tonumber(t.unitPrice)
            local available=tonumber(t.quantity)
            if price and price>0 and available and available>0 then
                levels[#levels+1]={unit=price,amount=math.floor(available)}
            end
        end
    end
    table.sort(levels,function(a,b)return a.unit<b.unit end)
    local total, need=0,qty
    for _, level in ipairs(levels) do
        if maxUnit and level.unit > maxUnit then break end
        local amount=math.min(need,level.amount)
        total=total+amount*level.unit
        need=need-amount
        if need==0 then break end
    end
    if need>0 then return nil, maxUnit and "Not enough units at or below your maximum." or "Not enough current listings. Search again." end
    if #levels==0 then return nil,"No purchasable listings available" end
    return {unit=levels[1].unit,total=total,quantity=qty,type="commodity"}
end

local function findItemQuote(row, qty)
    local key=row.itemKey
    if type(key)~="table" or tonumber(key.itemID)~=tonumber(row.itemID) then
        if type(AH.MakeItemKey)=="function" then key=get(AH.MakeItemKey,row.itemID) end
    end
    if type(key)~="table" or type(AH.GetNumItemSearchResults)~="function" or
        type(AH.GetItemSearchResultInfo)~="function" then
        return nil,"Auction details unavailable. Run the search again."
    end
    local count=get(AH.GetNumItemSearchResults,key)
    if type(count)~="number" or count<1 then return nil,"No current buyout listings. Search again." end
    local best
    for i=1,math.min(1000,count) do
        local item=get(AH.GetItemSearchResultInfo,key,i)
        if type(item)=="table" and not item.containsOwnerItem then
            local auctionID=tonumber(item.auctionID)
            local buyout=tonumber(item.buyoutAmount)
            local unit,stack=ac.UnitFromListing(row.itemID,buyout,item.quantity)
            if auctionID and auctionID>0 and unit and
                (not row.maxUnit or unit<=row.maxUnit) and (not qty or stack<=qty) and
                (not best or buyout<best.total) then
                best={auctionID=auctionID,total=buyout,unit=buyout/stack,quantity=stack,type="item"}
            end
        end
    end
    if not best then return nil, qty and "No listing fits the remaining quantity and price limit." or "No current buyout listings. Search again." end
    return best
end

-- Returns a fresh quote from game results; never use saved/cached prices to submit a purchase.
function ac.GetLiveQuote(row, qty)
    if not row or not tonumber(row.itemID) or row.source=="browse" then
        return nil,"Select a searched item to buy"
    end
    if not AH then return nil,"Auction House API unavailable" end
    if row.source=="commodity" then
        qty=requested(qty)
        if not qty then return nil,"Enter a valid quantity" end
        return findCommodityQuote(row.itemID,qty,row.maxUnit)
    elseif row.source=="item" then
        return findItemQuote(row, ac.session.buyList and ac.BatchRemaining(row) or nil)
    end
    return nil,"Wait until the item search is complete"
end

function ac.Buy(row, qty)
    if not ac.IsAtAH() then return false,"Open the Auction House first" end
    if ac.pendingPurchase then return false,"Finish or clear the pending purchase first." end
    if ac.session.buyList and (not row or ac.BatchRemaining(row) == 0 or
        (row.source == "commodity" and (tonumber(qty) or 0) > ac.BatchRemaining(row))) then
        return false,"Choose a quantity within the amount remaining."
    end
    if ac.session.mode~="done" then return false,"Wait for the search to finish" end
    if type(InCombatLockdown)=="function" and InCombatLockdown() then
        return false,"Buying is unavailable during combat"
    end
    local quote,err=ac.GetLiveQuote(row,qty)
    if not quote then return false,err end
    local frame=AuctionHouseFrame
    if not frame then return false,"Auction House is unavailable" end
    if type(GetMoney)=="function" and GetMoney()<quote.total then
        return false,"Not enough gold for "..ac.money(quote.total)
    end
    local pending = {row=row, quote=quote, session=ac.session}
    if quote.type=="commodity" then
        -- Blizzard shows its in-frame BuyDialog, requotes prices, and controls confirmation.
        if type(frame.StartCommoditiesPurchase)~="function" or not frame.BuyDialog then
            return false,"Blizzard's buying dialog is unavailable"
        end
        ac.pendingPurchase=pending
        local ok, reason=pcall(frame.StartCommoditiesPurchase, frame,
            row.itemID, quote.quantity, quote.unit, quote.total)
        if not ok then ac.pendingPurchase=nil; return false,"Blizzard rejected Buy: "..tostring(reason) end
        ac.Status("Confirm "..quote.quantity.." x "..(row.name or ac.itemName(row.itemID))..
            " in Blizzard's buying dialog.")
    else
        -- A single non-commodity listing has a fixed stack size and a fixed buyout.
        -- Calling Blizzard's StartItemBuyout opens its standard confirmation popup.
        if type(frame.StartItemBuyout)~="function" then
            return false,"Blizzard's item buyout dialog is unavailable"
        end
        ac.pendingPurchase=pending
        local ok, reason=pcall(frame.StartItemBuyout, frame,quote.auctionID,quote.total)
        if not ok then ac.pendingPurchase=nil; return false,"Blizzard rejected Buy: "..tostring(reason) end
        ac.Status("Confirm listing ("..quote.quantity.." items) for "..
            ac.money(quote.total).." in Blizzard's buying dialog.")
    end
    if C_Timer and C_Timer.After then
        C_Timer.After(45, function()
            if ac.pendingPurchase == pending then
                ac.DiscardPurchase("Purchase confirmation timed out. Check your mail before retrying.")
            end
        end)
    end
    return true,quote
end

function ac.DiscardPurchase(message)
    if not ac.pendingPurchase then return end
    ac.pendingPurchase=nil
    if ac.batch then ac.batch.waiting=false end
    if message then ac.Status(message) end
end

local confirmHooked = false
if AH and hooksecurefunc and type(AH.ConfirmCommoditiesPurchase) == "function" then
    confirmHooked = pcall(hooksecurefunc, AH, "ConfirmCommoditiesPurchase", function(itemID, quantity)
        local pending = ac.pendingPurchase
        if pending and pending.quote.type == "commodity" then
            pending.submitted = tonumber(itemID) == pending.row.itemID and tonumber(quantity) == pending.quote.quantity
        end
    end)
end
if AH and hooksecurefunc and type(AH.CancelCommoditiesPurchase) == "function" then
    pcall(hooksecurefunc, AH, "CancelCommoditiesPurchase", function()
        local pending = ac.pendingPurchase
        if pending and pending.quote.type == "commodity" and not pending.submitted then
            ac.DiscardPurchase("Purchase cancelled.")
        end
    end)
end

if AH and hooksecurefunc and type(AH.PlaceBid) == "function" then
    pcall(hooksecurefunc, AH, "PlaceBid", function(auctionID, copper)
        local pending = ac.pendingPurchase
        if pending and pending.quote.type == "item" then
            pending.submitted = tonumber(auctionID) == pending.quote.auctionID and tonumber(copper) == pending.quote.total
        end
    end)
end

local events=CreateFrame("Frame")
for _,name in ipairs({"COMMODITY_PURCHASE_SUCCEEDED","ITEM_PURCHASED",
    "COMMODITY_PURCHASE_FAILED","AUCTION_HOUSE_PURCHASE_COMPLETED"}) do
    pcall(events.RegisterEvent,events,name)
end
events:SetScript("OnEvent",function(self,event,...)
    local pending=ac.pendingPurchase
    if not pending or pending.session~=ac.session or not ac.IsAtAH() then return end
    local quote,row=pending.quote,pending.row
    local eventID=tonumber((...))
    if quote.type=="commodity" then
        if event~="COMMODITY_PURCHASE_SUCCEEDED" and event~="COMMODITY_PURCHASE_FAILED" then return end
        if eventID and eventID~=row.itemID then return end
        if event=="COMMODITY_PURCHASE_FAILED" then
            ac.DiscardPurchase("Purchase failed. Recheck the listings before retrying.")
            return
        end
        if not eventID and (not confirmHooked or not pending.submitted) then return end
    elseif event=="AUCTION_HOUSE_PURCHASE_COMPLETED" then
        if eventID~=quote.auctionID then return end
    elseif event=="ITEM_PURCHASED" then
        if not pending.submitted and eventID~=quote.auctionID then return end
        if eventID~=row.itemID and eventID~=quote.auctionID then return end
    else
        return
    end
    ac.pendingPurchase=nil
    row.acBought=(row.acBought or 0)+quote.quantity
    if ac.RecordShoppingPurchase then ac.RecordShoppingPurchase(row,quote.quantity) end
    if ac.session.buyList and ac.SetBatchQuantity and ac.session.rows[ac.session.selected]==row then
        ac.SetBatchQuantity(ac.BatchRemaining(row))
    end
    if ac.BatchRemaining(row)<=0 then row.acSelected=false end
    if ac.OnBatchPurchase and ac.OnBatchPurchase(row) then return end
    ac.Status(("Confirmed %d × %s. Check your mail for delivery."):format(quote.quantity,row.name or ac.itemName(row.itemID)))
end)
