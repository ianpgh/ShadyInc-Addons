local _, ac = ...
-- All transactions are initiated by a human pressing AC's Buy button.
-- Blizzard retains its own price/auction confirmation and handles the purchase.
-- No simulated clicks, automatic confirmations, or reparented protected frames.
local AH = C_AuctionHouse

local function get(fn, ...)
    if type(fn) ~= "function" then return nil end
    local ok, result = pcall(fn, ...)
    if ok then return result end
end

local function requested(amount)
    local n=tonumber(amount)
    if not n or n~=n or n<1 or n>99999 then return nil end
    return math.floor(n)
end

local function findCommodityQuote(id, qty, maxUnit, allowPartial)
    if type(AH.GetNumCommoditySearchResults)~="function" or
        type(AH.GetCommoditySearchResultInfo)~="function" then
        return nil, "Commodity buying isn't supported by this client"
    end
    local count=get(AH.GetNumCommoditySearchResults,id)
    if type(count)~="number" or count<1 then
        return nil, "Listings unavailable. Run the search again."
    end
    local levels={}
    for i=1, math.min(1000,count) do
        local t=get(AH.GetCommoditySearchResultInfo,id,i)
        if type(t)=="table" and not t.containsOwnerItem then
            local price=tonumber(t.unitPrice)
            local available=tonumber(t.quantity)
            if price and price>0 and available and available>0 then
                levels[#levels+1]={unit=price,amount=math.floor(available)}
            end
        end
    end
    table.sort(levels,function(a,b)return a.unit<b.unit end)
    local total, need, highest=0,qty,nil
    for _, level in ipairs(levels) do
        if maxUnit and level.unit > maxUnit then break end
        local amount=math.min(need,level.amount)
        total=total+amount*level.unit
        highest=level.unit
        need=need-amount
        if need==0 then break end
    end
    if need>0 and (not allowPartial or need==qty) then return nil, maxUnit and "Not enough units at or below your maximum." or "Not enough current listings. Search again." end
    if #levels==0 then return nil,"No purchasable listings available" end
    return {unit=levels[1].unit,total=total,highest=highest,quantity=qty-need,type="commodity"}
end

local function findItemQuote(row, qty)
    local key=row.itemKey
    if type(key)~="table" or tonumber(key.itemID)~=tonumber(row.itemID) then
        if type(AH.MakeItemKey)=="function" then key=get(AH.MakeItemKey,row.itemID) end
    end
    if type(key)~="table" or type(AH.GetNumItemSearchResults)~="function" or
        type(AH.GetItemSearchResultInfo)~="function" then
        return nil,"Auction details unavailable. Run the search again."
    end
    local count=get(AH.GetNumItemSearchResults,key)
    if type(count)~="number" or count<1 then return nil,"No current buyout listings. Search again." end
    local best
    for i=1,math.min(1000,count) do
        local item=get(AH.GetItemSearchResultInfo,key,i)
        if type(item)=="table" and not item.containsOwnerItem and
            (not item.itemKey or tonumber(item.itemKey.itemID) == row.itemID) then
            local auctionID=tonumber(item.auctionID)
            local buyout=tonumber(item.buyoutAmount)
            local unit,stack=ac.UnitFromListing(row.itemID,buyout,item.quantity)
            if ac.session.buyList and (not tonumber(item.quantity) or item.quantity ~= stack) then unit = nil end
            local reviewed = row.reviewedAuctions and row.reviewedAuctions[auctionID]
            if auctionID and auctionID>0 and unit and
                not (row.purchasedAuctions and row.purchasedAuctions[auctionID]) and
                (not row.reviewedAuctions or (reviewed and stack == reviewed.quantity and unit <= reviewed.unitPrice)) and
                (not row.maxUnit or unit<=row.maxUnit) and (not qty or stack<=qty) and
                (not best or (row.reviewedAuctions and unit<best.unit) or
                    ((not row.reviewedAuctions or unit==best.unit) and buyout<best.total)) then
                best={auctionID=auctionID,total=buyout,unit=buyout/stack,quantity=stack,type="item"}
            end
        end
    end
    if not best then return nil, qty and "No listing fits the remaining quantity and price limit." or "No current buyout listings. Search again." end
    return best
end

-- Returns a fresh quote from game results; never use saved/cached prices to submit a purchase.
function ac.GetLiveQuote(row, qty)
    if not row or not tonumber(row.itemID) or row.source=="browse" then
        return nil,"Select a searched item to buy"
    end
    if not AH then return nil,"Auction House API unavailable" end
    if row.source=="commodity" then
        qty=requested(qty)
        if not qty then return nil,"Enter a valid quantity" end
        return findCommodityQuote(row.itemID,qty,row.maxUnit)
    elseif row.source=="item" then
        return findItemQuote(row, (ac.session.buyList or ac.batch) and ac.BatchRemaining(row) or nil)
    end
    return nil,"Wait until the item search is complete"
end

function ac.BuyListPlan(row, wanted, offset, auctions)
    local units, total, highest = 0, 0, nil
    offset = offset or 0
    for _, tier in ipairs(row.tiers or {}) do
        local quantity = tier.quantity
        if row.source == "commodity" then
            local used = math.min(offset, quantity)
            offset, quantity = offset - used, quantity - used
            quantity = math.min(wanted - units, quantity)
        elseif row.purchasedAuctions and row.purchasedAuctions[tier.auctionID] then
            quantity = 0
        end
        if quantity > 0 and quantity <= wanted - units and (not row.maxUnit or tier.unitPrice <= row.maxUnit) then
            if auctions and tier.auctionID then auctions[tier.auctionID] = tier end
            units, total, highest = units + quantity, total + (tier.buyout or quantity * tier.unitPrice), tier.unitPrice
        end
        if units >= wanted then break end
    end
    return units, total, highest
end

function ac.BuyListRemaining(row)
    local wanted = ac.BatchRemaining(row)
    if row.restock then
        local owned = ac.BuyListOwned(row.itemID)
        if owned == nil then return 0, "Bags unavailable" end
        local incoming = row.trip and row.trip.startingOwned + row.trip.confirmed or owned
        wanted = math.min(wanted, math.max(0, row.required - math.max(owned, incoming)))
    end
    return wanted
end

function ac.BuyListReview(row)
    local wanted, failure = ac.BuyListRemaining(row)
    if failure then return 0, nil, failure end
    if wanted == 0 then return 0, nil, row.acBought > 0 and "Purchased" or "Stocked" end
    if row.observedAt and type(time) == "function" and time() - row.observedAt > 180 then
        return 0, nil, "Rescan"
    end
    if row.state ~= "Ready" and row.state ~= "Partial" then
        return 0, nil, row.state == "No listings" and "No Stock" or row.state
    end
    if row.available == 0 then return 0, nil, "No Stock" end
    if row.maxUnit and (row.withinCap or 0) == 0 then return 0, nil, "Over Max" end
    local units, total, highest = ac.BuyListPlan(row, wanted, row.acBought - (row.scanBought or 0))
    if units == 0 then return 0, nil, "No fitting stack" end
    -- Capped commodities can be reviewed and purchased after a live tier check.
    -- Blizzard's subsequent confirmation can still reprice; warn at confirmation.
    return units, total, nil, highest
end

function ac.SmartRefreshEnabled()
    return not ac.db or ac.db.smartRefresh ~= false
end
function ac.RecoverPurchase(row, reason)
    if not ac.SmartRefreshEnabled() or not row or not ac.RefreshRows then return false end
    if (row.recoveryAttempts or 0)>=2 then return false end
    local ok=ac.RefreshRows({row},true)
    if ok then
        row.recoveryAttempts=(row.recoveryAttempts or 0)+1
        -- Never launch or confirm another purchase asynchronously; the next click
        -- is an explicit review of the updated market and keeps existing caps.
        ac.Status(reason .. " Refreshing only " .. tostring(row.name) .. "; review and click Buy again.")
        return true
    end
    return false
end
function ac.Buy(row, qty, fromQueue)
    if not ac.IsAtAH() then return false,"Open the Auction House first" end
    if ac.pendingPurchase or (ac.batch and not fromQueue) then return false,"Finish the pending purchase or queue first." end
    if ac.db and ac.db.unresolvedPurchase == true then
        return false, ac.purchaseLockMessage
    end
    if (ac.IsNameScanBusy and ac.IsNameScanBusy()) or
        (ac.scanState and (ac.scanState.phase == "requesting" or ac.scanState.phase == "receiving")) then
        return false, "Wait for the active scan to finish."
    end
    if AH and type(AH.IsThrottledMessageSystemReady) == "function" and not get(AH.IsThrottledMessageSystemReady) then
        return false, "Auction House is busy. Wait and try again."
    end
    if ac.session.buyList and (not row or ac.BatchRemaining(row) == 0 or
        (row.source == "commodity" and (tonumber(qty) or 0) > ac.BatchRemaining(row))) then
        return false,"Choose a quantity within the amount remaining."
    end
    if ac.session.mode~="done" then return false,"Wait for the search to finish" end
    if type(InCombatLockdown)=="function" and InCombatLockdown() then
        return false,"Buying is unavailable during combat"
    end
    if not row then return false, "Select an item to buy." end
    local buyList = ac.session.buyList
    if row.refreshed and (not row.minUnit or (row.state~="Ready" and row.state~="Partial")) then
        return false,"No verified buyout after refresh. Refresh this item again.",fromQueue and true or false
    end
    if buyList and not fromQueue then return false, "Review and buy saved items on the Buy List tab." end
    local cost, highest
    if buyList then
        if ac.session.buyListInvalid then return false, "Scan this item again." end
        local reason
        qty, cost, reason, highest = ac.BuyListReview(row)
        if reason then
            if reason=="Rescan" and ac.RecoverPurchase(row,reason) then return false,ac.session.status end
            return false, reason, true
        end
        if row.source == "item" then
            row.reviewedAuctions = {}
            ac.BuyListPlan(row, ac.BuyListRemaining(row), nil, row.reviewedAuctions)
        end
    end
    local quote,err
    if buyList and row.source == "item" then
        quote,err = findItemQuote(row, ac.BuyListRemaining(row))
    elseif buyList and row.source == "commodity" then
        -- An explicit saved maximum is the user's price limit, not the older
        -- estimate. Uncapped orders retain the reviewed-price protection.
        quote,err = findCommodityQuote(row.itemID, qty, row.maxUnit or highest, true)
    else
        quote,err = ac.GetLiveQuote(row,qty)
    end
    row.reviewedAuctions = nil
    if not quote then
        if row.source=="item" or (row.source=="commodity" and requested(qty)) then
            if ac.RecoverPurchase(row,err or "Listings changed.") then return false,ac.session.status end
        end
        return false,err,buyList or (fromQueue and row.refreshed and (row.recoveryAttempts or 0)>=2)
    end
    if buyList and quote.type == "commodity" and not row.maxUnit and quote.total > cost then
        if ac.RecoverPurchase(row,"Price increased above the reviewed estimate.") then return false,ac.session.status end
        return false, "Price increased above the reviewed estimate.", true
    end
    if not buyList then
        if quote.type == "item" and row.cheapestListing and quote.total > row.cheapestListing.buyout then
            if ac.RecoverPurchase(row,"Listing price increased.") then return false,ac.session.status end
            return false, "Listing price increased. Refresh this item before buying."
        elseif quote.type == "commodity" then
            local reviewedQty, reviewedCost, reviewedTop = ac.BuyListPlan(row, quote.quantity)
            local shownCost = quote.quantity == row.requirementQuantity and row.requirementCost
            if (shownCost and quote.total > shownCost) or
                (reviewedQty == quote.quantity and (quote.total > reviewedCost or quote.highest > reviewedTop)) then
                if ac.RecoverPurchase(row,"Price increased above the search estimate.") then return false,ac.session.status end
                return false, "Price increased above the search estimate. Refresh this item."
            end
        end
    end
    -- Defensive check immediately before opening the native dialog.
    if quote.type == "commodity" and row.maxUnit and
        (not quote.highest or quote.highest > row.maxUnit or quote.total > quote.quantity * row.maxUnit) then
        return false, "Over Max", fromQueue and true or false
    end
    local frame=AuctionHouseFrame
    if not frame then return false,"Auction House is unavailable" end
    if type(GetMoney)=="function" and GetMoney()<quote.total then
        return false,"Not enough gold for "..ac.money(quote.total),buyList
    end
    if frame.BuyDialog and frame.BuyDialog.IsShown and frame.BuyDialog:IsShown() then
        return false, "Close the existing Blizzard buy dialog first."
    end
    local pending = {row=row, quote=quote, session=ac.session}
    if quote.type=="commodity" then
        -- Blizzard shows its in-frame BuyDialog, requotes prices, and controls confirmation.
        if type(frame.StartCommoditiesPurchase)~="function" or not frame.BuyDialog then
            return false,"Blizzard's buying dialog is unavailable"
        end
        ac.pendingPurchase=pending
        if ac.db then ac.db.unresolvedPurchase = true end
        local ok, reason=pcall(frame.StartCommoditiesPurchase, frame,
            row.itemID, quote.quantity, quote.unit, quote.total)
        if not ok or reason == false then
            ac.DiscardPurchase()
            return false,"Blizzard could not start Buy: "..tostring(reason)..". Check mail if uncertain."
        end
        if row.maxUnit then
            local message = "Check final price: "..quote.quantity.." x "..(row.name or ac.itemName(row.itemID))..
                " | Max/unit "..ac.money(row.maxUnit).." | Max total "..ac.money(quote.quantity * row.maxUnit)..
                ". Cancel if price exceeds cap; Blizzard can reprice."
            pending.capWarning = message
            ac.Status(message)
            ac.announce(message)
        else
            ac.Status("Confirm "..quote.quantity.." x "..(row.name or ac.itemName(row.itemID))..
                " in Blizzard's buying dialog.")
        end
    else
        -- A single non-commodity listing has a fixed stack size and a fixed buyout.
        -- Calling Blizzard's StartItemBuyout opens its standard confirmation popup.
        if type(frame.StartItemBuyout)~="function" then
            return false,"Blizzard's item buyout dialog is unavailable"
        end
        ac.pendingPurchase=pending
        if ac.db then ac.db.unresolvedPurchase = true end
        local ok, reason=pcall(frame.StartItemBuyout, frame,quote.auctionID,quote.total)
        if not ok or reason == false then
            ac.DiscardPurchase()
            return false,"Blizzard could not start Buy: "..tostring(reason)..". Check mail if uncertain."
        end
        ac.Status("Confirm listing ("..quote.quantity.." items) for "..
            ac.money(quote.total).." in Blizzard's buying dialog.")
    end
    if C_Timer and C_Timer.After then
        C_Timer.After(45, function()
            if ac.pendingPurchase == pending then
                ac.DiscardPurchase("Purchase timed out. Close the dialog, check mail, then use /ac resolve.")
            end
        end)
    end
    return true,quote
end

function ac.DiscardPurchase(message, resolved)
    if not ac.pendingPurchase then return end
    local pending = ac.pendingPurchase
    ac.pendingPurchase=nil
    if resolved and ac.db then ac.db.unresolvedPurchase = nil end
    if ac.batch then
        ac.batch.waiting=false
        ac.batch.pendingRow=nil
        if not resolved then ac.batch=nil end
    end
    ac.purchaseDiagnostic = (resolved and "Resolved: " or "Unresolved: ") .. tostring(pending.row.name or pending.row.itemID) .. (pending.submitted and " (submission observed)" or " (submission not observed)") .. " - " .. (message or "purchase flow interrupted")
    if message then ac.Status(message) elseif not resolved then ac.Notify() end
end

local confirmHooked = false
if AH and hooksecurefunc and type(AH.ConfirmCommoditiesPurchase) == "function" then
    confirmHooked = pcall(hooksecurefunc, AH, "ConfirmCommoditiesPurchase", function(itemID, quantity)
        local pending = ac.pendingPurchase
        if pending and pending.quote.type == "commodity" then
            if tonumber(itemID) == pending.row.itemID and tonumber(quantity) == pending.quote.quantity then
                pending.submitted = true
            end
        end
    end)
end
if AH and hooksecurefunc and type(AH.CancelCommoditiesPurchase) == "function" then
    pcall(hooksecurefunc, AH, "CancelCommoditiesPurchase", function()
        local pending = ac.pendingPurchase
        if pending and pending.quote.type == "commodity" and not pending.submitted then
            ac.DiscardPurchase("Purchase cancelled.", true)
        end
    end)
end

if AH and hooksecurefunc and type(AH.PlaceBid) == "function" then
    pcall(hooksecurefunc, AH, "PlaceBid", function(auctionID, copper)
        local pending = ac.pendingPurchase
        if pending and pending.quote.type == "item" then
            if tonumber(auctionID) == pending.quote.auctionID and tonumber(copper) == pending.quote.total then
                pending.submitted = true
            end
        end
    end)
end

local events=CreateFrame("Frame")
for _,name in ipairs({"COMMODITY_PURCHASE_SUCCEEDED","ITEM_PURCHASED",
    "COMMODITY_PURCHASE_FAILED","AUCTION_HOUSE_PURCHASE_COMPLETED"}) do
    pcall(events.RegisterEvent,events,name)
end
events:SetScript("OnEvent",function(self,event,...)
    local pending=ac.pendingPurchase
    if not pending or pending.session~=ac.session or not ac.IsAtAH() then return end
    local quote,row=pending.quote,pending.row
    local eventID=tonumber((...))
    if quote.type=="commodity" then
        if event~="COMMODITY_PURCHASE_SUCCEEDED" and event~="COMMODITY_PURCHASE_FAILED" then return end
        if eventID and eventID~=row.itemID then return end
        if event=="COMMODITY_PURCHASE_FAILED" then
            if not pending.submitted then return end
            ac.DiscardPurchase(nil, true)
            if not ac.RecoverPurchase(row,"Purchase failed.") then
                if ac.batch and ac.batch.buyList then
                    ac.SkipBuyListOrder("Purchase failed. Recheck listings before retrying.")
                else
                    ac.Status("Purchase failed. Refresh this item before retrying.")
                end
            end
            return
        end
        if not pending.submitted and (confirmHooked or not eventID) then return end
    elseif event=="AUCTION_HOUSE_PURCHASE_COMPLETED" then
        if eventID~=quote.auctionID then return end
    elseif event=="ITEM_PURCHASED" then
        if not pending.submitted and eventID~=quote.auctionID then return end
        if eventID~=row.itemID and eventID~=quote.auctionID then return end
    else
        return
    end
    ac.pendingPurchase=nil
    if ac.db then ac.db.unresolvedPurchase = nil end
    ac.purchaseDiagnostic = "Confirmed: " .. tostring(row.name or row.itemID) .. " via " .. event
    if quote.auctionID then
        row.purchasedAuctions = row.purchasedAuctions or {}
        row.purchasedAuctions[quote.auctionID] = true
    end
    row.recoveryAttempts=nil
    row.acBought=(row.acBought or 0)+quote.quantity
    if ac.RecordShoppingPurchase then ac.RecordShoppingPurchase(row,quote.quantity) end
    if ac.session.buyList and ac.SetBatchQuantity and ac.session.rows[ac.session.selected]==row then
        ac.SetBatchQuantity(ac.BatchRemaining(row))
    end
    if ac.BatchRemaining(row)<=0 then row.acSelected=false end
    if ac.OnBatchPurchase and ac.OnBatchPurchase(row, quote) then return end
    ac.Status(("Confirmed %d × %s. Check your mail for delivery."):format(quote.quantity,row.name or ac.itemName(row.itemID)))
end)
