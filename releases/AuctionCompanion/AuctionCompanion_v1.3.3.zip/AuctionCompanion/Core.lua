local addonName, ac = ...
-- Independent addon: never modifies Auctionator or other addons' SavedVariables.
_G.AuctionCompanionAPI = { version = 1 }
ac.api = _G.AuctionCompanionAPI
ac.version = "1.3.3"
-- Phase 1: AC has no incoming SPE reader. This persisted gate is the
-- contract for future reference-price integration; raw scan APIs stay local.
function ac.AcceptsSPEPrices()
    return ac.db ~= nil and ac.db.acceptSPEPrices == true
end
function ac.SetAcceptSPEPrices(enabled)
    if not ac.db then return end
    ac.db.acceptSPEPrices = enabled == true
    ac.priceRevision = (ac.priceRevision or 0) + 1
    ac.Notify()
end
ac.api.AcceptsSPEPrices = ac.AcceptsSPEPrices
ac.purchaseLockMessage = "Purchase locked: close AH, check mail and auction activity, then /ac resolve."
function ac.HasPurchaseLock()
    return ac.db and ac.db.unresolvedPurchase == true and not ac.pendingPurchase
end
ac.session = {rows = {}, mode = "idle", label = "", selected = nil, status = "Open the Auction House to search."}
ac.listeners = {}

function ac.Notify()
    for callback in pairs(ac.listeners) do
        local ok, err = pcall(callback, ac.session)
        if not ok then geterrorhandler()(err) end
    end
end
function ac.Subscribe(callback)
    if type(callback) == "function" then ac.listeners[callback] = true end
end
function ac.IsAtAH()
    if AuctionHouseFrame and AuctionHouseFrame.IsShown and AuctionHouseFrame:IsShown() then return true end
    if C_AuctionHouse and type(C_AuctionHouse.IsAuctionHouseOpen) == "function" then
        local ok, active = pcall(C_AuctionHouse.IsAuctionHouseOpen)
        return ok and active == true
    end
    return false
end
-- Money shown in AC uses the same gold/silver/copper coin icons as
-- Blizzard's auction UI.  Keep this centralized: prices, buy previews,
-- tooltips, recipe profit and vendor comparisons must use one renderer.
local function coinIcon(kind)
    return "|TInterface\\MoneyFrame\\UI-" .. kind .. "Icon:12:12:0:0|t"
end
function ac.money(value)
    if type(value) ~= "number" or value ~= value or value < 0 or value == math.huge then return "--" end
    value = math.floor(value + .5)
    -- Prefer Blizzard's own formatter where available; some Forever clients
    -- do not expose this function, so retain a texture-based fallback.
    if type(GetCoinTextureString)=="function" then
        local ok, result = pcall(GetCoinTextureString,value,12)
        if ok and type(result)=="string" and result:find("|T",1,true) then
            return result
        end
    end
    local gold=math.floor(value/10000)
    local silver=math.floor(value/100)%100
    local copper=value%100
    local parts={}
    if gold>0 then parts[#parts+1]=gold..coinIcon("Gold") end
    if gold>0 or silver>0 then parts[#parts+1]=silver..coinIcon("Silver") end
    -- Show copper for small values and nonzero remainders; never print "c".
    if copper>0 or (gold==0 and silver==0) then
        parts[#parts+1]=copper..coinIcon("Copper")
    end
    return table.concat(parts," ")
end
-- Auction buyout amounts represent entire non-commodity listings. For items
-- that cannot stack (bags, equipment, etc.), do not divide by a spurious
-- reported quantity; that caused e.g. 60s Mageweave Bag to read as 2s.
-- For genuinely stackable listings, use price per item for craft comparisons.
local knownStacks = {}
function ac.MaxStack(itemID)
    itemID=tonumber(itemID)
    if not itemID then return nil end
    if knownStacks[itemID] then return knownStacks[itemID] end
    if type(GetItemInfo)=="function" then
        local amount=tonumber((select(8,GetItemInfo(itemID))))
        if amount and amount>=1 then
            knownStacks[itemID]=amount
            return amount
        end
    end
    return nil -- Do not guess if item data has not loaded yet.
end
function ac.UnitFromListing(itemID,buyout,quantity)
    buyout=tonumber(buyout)
    if not buyout or buyout<=0 then return nil,nil end
    quantity=math.max(1,math.floor(tonumber(quantity) or 1))
    local maxStack=ac.MaxStack(itemID)
    if maxStack==1 then quantity=1 end
    return buyout/quantity,quantity
end
function ac.IsUnstackable(itemID)
    return ac.MaxStack(itemID)==1
end
function ac.itemName(id)
    if not id then return "Unknown" end
    if type(GetItemInfo) == "function" then
        local name = GetItemInfo(id)
        if name then return name end
    end
    return "Item #" .. tostring(id)
end
function ac.announce(msg)
    if DEFAULT_CHAT_FRAME then DEFAULT_CHAT_FRAME:AddMessage("|cffffc34dAuction Companion:|r " .. tostring(msg)) end
end
function ac.Status(message)
    ac.session.status = tostring(message or "")
    ac.Notify()
end
local houseVisit = 0
local frame = CreateFrame("Frame")
ac.events = frame
frame:RegisterEvent("ADDON_LOADED")
frame:RegisterEvent("AUCTION_HOUSE_SHOW")
frame:RegisterEvent("AUCTION_HOUSE_CLOSED")
frame:SetScript("OnEvent", function(self, event, ...)
    if event == "ADDON_LOADED" then
        if (...) == addonName then
            AuctionCompanionDB = type(AuctionCompanionDB) == "table" and AuctionCompanionDB or {}
            ac.db = AuctionCompanionDB
            if ac.InitBuyLists then ac.InitBuyLists() end
            ac.Status("Ready. Open the Auction House to search.")
            -- UI is created only when the Auction House frame exists.
        end
        return
    end
    houseVisit = houseVisit + 1
    if event == "AUCTION_HOUSE_CLOSED" then
        if ac.DiscardPurchase then ac.DiscardPurchase() end
        if ac.Cancel then ac.Cancel("Auction House closed") end
        if ac.ClearShoppingTrips then ac.ClearShoppingTrips() end
        ac.session = {rows={}, mode="idle", label="", status="Open the Auction House to search."}
        if ac.window then ac.window:Hide() end
        if ac.buyWindow then ac.buyWindow:Hide() end
    elseif event == "AUCTION_HOUSE_SHOW" then
        ac.Status(ac.HasPurchaseLock() and ac.purchaseLockMessage or "Ready for searches. Full Scan is available on the Buy tab.")
        if C_Timer and C_Timer.After then
            -- Let Blizzard and other AH addons finish creating their frames first.
            local visit = houseVisit
            C_Timer.After(.25, function()
                if visit == houseVisit and ac.IsAtAH() then
                    if ac.AttachTab then ac.AttachTab() end
                    if ac.AttachScannerButton then ac.AttachScannerButton() end
                end
            end)
        end
    end
end)

SLASH_AUCTIONCOMPANION1 = "/ac"
SLASH_AUCTIONCOMPANION2 = "/auctioncompanion"
SlashCmdList.AUCTIONCOMPANION = function(msg)
    msg = (msg or ""):match("^%s*(.-)%s*$") or ""
    if msg == "pricing" or msg == "pricing off" or msg == "pricing on" then
        if msg ~= "pricing" then ac.SetAcceptSPEPrices(msg == "pricing on") end
        ac.announce(ac.AcceptsSPEPrices() and "SPE permission ON (integration not installed; AC prices remain local)." or "AC Only: incoming SPE pricing blocked.")
        return
    end
    if msg == "cancel" then if ac.Cancel then ac.Cancel("Cancelled") end; return end
    if msg == "resolve" then
        if not ac.db or not ac.db.unresolvedPurchase then ac.announce("No unresolved order."); return end
        if ac.pendingPurchase or ac.batch or ac.IsAtAH() then
            ac.announce("Stop the queue and close the Auction House before resolving an order.")
            return
        end
        ac.db.unresolvedPurchase = nil
        ac.purchaseDiagnostic = nil
        ac.Status("Purchase lock cleared. Reopen AH and scan again.")
        ac.announce("Purchase lock cleared. Reopen AH and scan again.")
        return
    end
    if msg == "scan" then
        local ok,reason=ac.FullScanStart and ac.FullScanStart()
        if not ok then ac.announce(reason or "Full Scan unavailable") end
        return
    end
    if msg == "status" or msg == "scanstatus" then
        if msg=="status" then
            ac.announce("Search: "..tostring(ac.session.status))
            local pending = ac.pendingPurchase
            ac.announce("Purchase: " .. (pending and (pending.submitted and "submitted; awaiting result" or "awaiting confirmation") or (ac.HasPurchaseLock() and "unresolved; recovery required" or "ready")))
            if ac.purchaseDiagnostic then ac.announce(ac.purchaseDiagnostic) end
        end
        local s=ac.api.GetScanStatus and ac.api.GetScanStatus()
        if s then
            ac.announce(("Full Scan: %s - %s"):format(tostring(s.phase),tostring(s.status)))
            if s.cooldownSeconds and s.cooldownSeconds>0 then
                ac.announce(("Next request: ~%d min (%s)"):format(math.ceil(s.cooldownSeconds/60),tostring(s.cooldownSource or "server cooldown")))
            end
            if s.lastCompleted then
                ac.announce(("Last saved scan: %s listings / %s items; timestamp %s"):
                    format(tostring(s.auctionCount or "?"),tostring(s.itemCount or "?"),date and date("%Y-%m-%d %I:%M %p",s.lastCompleted) or tostring(s.lastCompleted)))
            end
        end
        return
    end
    if ac.Open then ac.Open() end
end
