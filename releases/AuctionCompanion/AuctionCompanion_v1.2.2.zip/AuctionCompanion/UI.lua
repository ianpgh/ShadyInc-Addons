local _, ac = ...
-- v0.1.7: price normalization for one-piece crafted outputs.
-- Blizzard's built-in confirmation UI remains responsible for transactions.
local ui, rows, page, qtyBox, buyButton, buyAllButton, selectAllButton, searchBox, statusText, titleText, versionText
local profitText, profitHint
local priceSettingsPanel, vendorCheckbox, professionCheckbox, smartRefreshCheckbox
local preview = {}
local ROW_COUNT = 9
local TIER_COUNT = 5
local paging = {}
local resultSort, descending, onlyNeeded, lastSession
local order, sortedRows = {}, {}
local sortLabels = {name="ITEM", price="LOWEST", need="TO BUY"}

local function label(parent, value, size, color)
    local f = parent:CreateFontString(nil, "OVERLAY", size or "GameFontHighlightSmall")
    f:SetJustifyH("LEFT")
    f:SetText(value or "")
    if color then f:SetTextColor(unpack(color)) end
    return f
end
local GOLD = {1,.82,.37}
local LIGHT = {.92,.86,.75}
local MUTED = {.70,.68,.60}
local function at(f, x, y, relative)
    f:SetPoint("TOPLEFT", relative or f:GetParent(), "TOPLEFT", x, y)
    return f
end
local function button(parent, text, width, height, callback)
    local b = CreateFrame("Button", nil, parent, "UIPanelButtonTemplate")
    b:SetSize(width, height)
    b:SetText(text)
    b:SetScript("OnClick", callback)
    return b
end
local function refreshButton(parent, callback)
    local b=button(parent,"R",20,20,callback)
    b:SetScript("OnEnter",function(self)
        GameTooltip:SetOwner(self,"ANCHOR_RIGHT")
        GameTooltip:AddLine("Refresh this item")
        GameTooltip:AddLine("Keep selections, quantities and purchases.",1,1,1,true)
        GameTooltip:Show()
    end)
    b:SetScript("OnLeave",function() GameTooltip:Hide() end)
    return b
end
local function selectionMark(parent)
    local mark = CreateFrame("Frame", nil, parent)
    mark:SetSize(16, 16)
    mark:SetPoint("CENTER")
    if not mark.CreateLine then
        local check = mark:CreateTexture(nil, "OVERLAY")
        check:SetAllPoints()
        check:SetTexture("Interface\\Buttons\\UI-CheckBox-Check")
        check:SetVertexColor(.25, 1, .25)
        local cross = label(mark, "X", "GameFontNormal", {1,.22,.22})
        cross:SetPoint("CENTER")
        function mark:SetSelected(selected)
            check:SetShown(selected)
            cross:SetShown(not selected)
        end
        return mark
    end
    local function stroke(x1, y1, x2, y2, r, g, b)
        local line = mark:CreateLine(nil, "OVERLAY")
        line:SetStartPoint("BOTTOMLEFT", mark, x1, y1)
        line:SetEndPoint("BOTTOMLEFT", mark, x2, y2)
        line:SetThickness(3)
        line:SetColorTexture(r, g, b, 1)
        return line
    end
    local check1 = stroke(2, 7, 6, 3, .25, 1, .25)
    local check2 = stroke(6, 3, 14, 13, .25, 1, .25)
    local cross1 = stroke(3, 3, 13, 13, 1, .22, .22)
    local cross2 = stroke(3, 13, 13, 3, 1, .22, .22)
    function mark:SetSelected(selected)
        check1:SetShown(selected)
        check2:SetShown(selected)
        cross1:SetShown(not selected)
        cross2:SetShown(not selected)
    end
    return mark
end
local function inset(parent)
    -- InsetFrameTemplate4 is used by Blizzard's classic AH UI and is already
    -- present on the Forever client. Fallback keeps Companion standalone.
    local ok, f = pcall(CreateFrame, "Frame", nil, parent, "InsetFrameTemplate4")
    if not ok or not f then
        f = CreateFrame("Frame", nil, parent, "BackdropTemplate")
        if f.SetBackdrop then
            f:SetBackdrop({bgFile="Interface\\Buttons\\WHITE8X8", edgeFile="Interface\\Tooltips\\UI-Tooltip-Border",edgeSize=12,insets={left=4,right=4,top=4,bottom=4}})
            f:SetBackdropColor(.12,.10,.08,.72)
            f:SetBackdropBorderColor(.35,.31,.25,.8)
        end
    end
    f:EnableMouse(true)
    return f
end
local function displayMoney(value)
    if not value or value<=0 then return "--" end
    return ac.money(value)
end
local function money0(value)
    return ac.money(value or 0)
end
-- A profitability estimate always values ALL reagents, including those already owned.
-- Only current, successful item searches are used here; missing prices are not
-- silently treated as zero and scanned historical values are not mixed in.
local function recipeProfit(session)
    local output, cost, outlay, missing = nil, 0, 0, 0
    local reagents, vendorUsed = 0, 0
    for _, r in ipairs(session.rows or {}) do
        if r.output then
            if not output then output=r end
        else
            reagents = reagents+1
            local effective,source
            if ac.api.GetMaterialCost then effective,source=ac.api.GetMaterialCost(r.itemID) end
            -- Fallback to this completed live result, but never treat an
            -- incomplete AH response as a verified cheap auction price.
            if (not effective) and r.minUnit and r.minUnit>0 and r.state=="Ready" then
                effective,source=r.minUnit,'auction'
            end
            if not effective or effective<=0 then
                missing=missing+1
            else
                if source=='vendor' then vendorUsed=vendorUsed+1 end
                cost=cost+(tonumber(r.required) or 0)*effective
                outlay=outlay+math.max(0,(tonumber(r.required) or 0)-(tonumber(r.owned) or 0))*effective
            end
        end
    end
    if not output or reagents==0 then return nil, "Search a profession recipe for a profit estimate." end
    if not output.minUnit or output.minUnit<=0 or output.state=="Partial" or output.state=="Timed out" then missing=missing+1 end
    if session.mode~="done" then return nil, "Profit calculates after the recipe search completes." end
    if missing>0 then return nil, ("%d missing/incomplete auction price%s; profit unavailable."):format(missing, missing==1 and "" or "s") end
    local yield=math.max(1,tonumber(output.outputQuantity) or 1)
    local sale=output.minUnit*yield
    -- The current AH's actual cut may vary (e.g. neutral AH): this is an estimate.
    local fee=math.floor(sale*0.05+0.5)
    local profit=math.floor(sale-fee-cost+0.5)
    return profit, ("Sell %s | Mats %s | Buy %s | %d vendor-priced | 5%% AH cut (est.)"):format(
        money0(sale),money0(math.floor(cost+0.5)),money0(math.floor(outlay+0.5)), vendorUsed)
end
local function quantity()
    return math.max(1, math.min(99999, math.floor(tonumber(qtyBox and qtyBox:GetText()) or 1)))
end
local function chosen()
    return ac.session.rows and ac.session.rows[ac.session.selected or 0]
end

-- Purchases are routed through Blizzard's native in-frame confirmation logic,
-- implemented in Purchase.lua. Never programmatically click its Buy buttons.
local function itemIcon(id)
    if not tonumber(id) then return "Interface\\Icons\\INV_Misc_QuestionMark" end
    if type(GetItemIcon)=="function" then
        local icon=GetItemIcon(id)
        if icon then return icon end
    end
    if C_Item and type(C_Item.GetItemIconByID)=="function" then
        local ok,icon=pcall(C_Item.GetItemIconByID,id)
        if ok and icon then return icon end
    end
    if C_AuctionHouse and C_AuctionHouse.MakeItemKey and C_AuctionHouse.GetItemKeyInfo then
        local ok,key=pcall(C_AuctionHouse.MakeItemKey,id)
        if ok and key then
            local okInfo,info=pcall(C_AuctionHouse.GetItemKeyInfo,key)
            if okInfo and info and info.iconFileID then return info.iconFileID end
        end
    end
    return "Interface\\Icons\\INV_Misc_QuestionMark"
end

local function estimate(row, wanted)
    if not row or not row.minUnit then return nil,nil end
    if row.source=="item" then
        local listing=row.cheapestListing
        if listing then
            return listing.buyout,("Purchases one listing (stack of %d)"):format(listing.quantity or 1)
        end
        return nil,"One listing at a time; search again to confirm price"
    end
    if row.source=="commodity" and wanted==row.requirementQuantity then
        return row.requirementCost,"Estimate only - Blizzard checks final price"
    end
    if row.source=="commodity" and row.withinCap and wanted>row.withinCap then
        return nil, row.maxUnit and "Not enough units at or below your maximum" or "Quantity exceeds available listings"
    end
    local need=wanted
    local total=0
    local tiers=row.tiers
    if row.source=="commodity" and tiers and #tiers>0 then
        if row.available and row.available < wanted then
            return nil,"Quantity exceeds available listings"
        end
        for _,t in ipairs(tiers) do
            local use=math.min(need,t.quantity or 0)
            total=total+(t.unitPrice or 0)*use
            need=need-use
            if need<=0 then break end
        end
        if need>0 then return nil,"Price preview incomplete; Buy requotes live" end
        return total,"Estimate only - Blizzard checks final price"
    end
    return wanted*row.minUnit,"Estimate only - Blizzard checks final price"
end

local function closeOnEscape(frame, name)
    if type(UISpecialFrames) == "table" then table.insert(UISpecialFrames, name) end
    frame:EnableMouse(true)
end

function ac.BuildBuyList()
    if ac.buyWindow then return ac.buyWindow end
    local ah = AuctionHouseFrame
    local surface = CreateFrame("Frame", "AuctionCompanionBuyList", ah)
    ac.buyWindow = surface
    surface:Hide()
    surface:SetPoint("TOPLEFT", ah, "TOPLEFT", 4, -103)
    surface:SetPoint("BOTTOMRIGHT", ah, "BOTTOMRIGHT", -4, 27)
    surface:SetFrameLevel(ah:GetFrameLevel() + 3)
    closeOnEscape(surface, "AuctionCompanionBuyList")
    local panel = CreateFrame("Frame", nil, surface)
    panel:SetPoint("TOP", surface, "TOP", 0, 0)
    panel:SetSize(780, 395)
    local function fit()
        local width, height = surface:GetWidth(), surface:GetHeight()
        if width > 0 and height > 0 then
            panel:SetScale(math.min(1, width / 780, height / 395))
        end
    end
    surface:SetScript("OnSizeChanged", fit)
    panel:EnableMouseWheel(true)
    local PAGE_SIZE = 8
    local listRows, selection, controls = {}, {}, {}
    local listPage, sortKey, reverse = 1, "name", false
    local deletePending, refresh
    local function input(parent, width, x, y, limit)
        local box = at(CreateFrame("EditBox", nil, parent, "InputBoxTemplate"), x, y)
        box:SetSize(width, 21)
        box:SetAutoFocus(false)
        box:SetMaxLetters(limit)
        box:SetScript("OnEscapePressed", function(self) self:ClearFocus() end)
        return box
    end
    local function control(text, width, x, y, callback, editable)
        local b = at(button(panel, text, width, 22, callback), x, y)
        if editable then controls[#controls + 1] = b end
        return b
    end
    local heading = at(label(panel, "", "GameFontNormal", GOLD), 71, -10)
    heading:SetSize(160, 18)
    heading:SetWordWrap(false)
    local listName = input(panel, 130, 248, -7, 40)
    local function reset()
        listPage, selection = 1, {}
    end
    local function switch(offset)
        local names, index = ac.BuyListNames()
        ac.SelectBuyList((index - 1 + offset) % #names + 1)
        reset()
        refresh("Scan this list to review current prices.")
    end
    control("<", 23, 14, -7, function() switch(-1) end, true)
    control(">", 23, 40, -7, function() switch(1) end, true)
    local function edit(action)
        local ok, err = ac.EditBuyList(action, listName:GetText())
        if ok then
            listName:SetText("")
            listName:ClearFocus()
            if action ~= "rename" then reset() end
        end
        refresh(err or "List saved.")
    end
    for i, operation in ipairs({{"New","new"}, {"Rename","rename"}, {"Copy","duplicate"}}) do
        local action = operation[2]
        control(operation[1], 60, 389 + (i-1)*63, -7, function() edit(action) end, true)
    end
    control("Delete", 58, 578, -7, function()
        local _, index = ac.BuyListNames()
        if deletePending == index then edit("delete")
        else
            refresh("Click Delete again to remove this saved list.")
            deletePending = index
        end
    end, true)
    local mode = control("Restock", 122, 644, -7, function()
        ac.SetBuyListRestock(not ac.db.buyListRestock)
        refresh("Mode changed. Scan again before buying.")
    end, true)
    local itemInput = input(panel, 224, 16, -36, 255)
    local function addItem()
        local raw = itemInput:GetText():match("^%s*(.-)%s*$")
        if raw ~= "" and not tonumber(raw) and not raw:find("|Hitem:", 1, true) then
            local ok, err = ac.SearchText(raw)
            if ok then
                itemInput:ClearFocus()
                ac.Status("Right-click the matching search result to add its item ID to Buy List.")
            else refresh(err) end
            return
        end
        local index, err = ac.SaveBuyListItem(raw, 1, nil, true)
        if index then itemInput:SetText(""); itemInput:ClearFocus() end
        refresh(index and "Item saved." or err)
    end
    itemInput:SetScript("OnEnterPressed", addItem)
    itemInput:SetScript("OnEditFocusGained", function(self)
        self:HighlightText()
    end)
    control("Add Item", 80, 250, -36, addItem, true)
    control("Add Reagents", 108, 335, -36, function()
        local count, err = ac.SaveRecipeToBuyList()
        refresh(count and ("%d recipe reagents saved."):format(count) or err)
    end, true)
    local function selectAll()
        local all = true
        for _, item in ipairs(ac.GetBuyList()) do
            if not selection[item.itemID] then all = false; break end
        end
        selection = {}
        if not all then
            for _, item in ipairs(ac.GetBuyList()) do selection[item.itemID] = true end
        end
        refresh()
    end
    local selecting = control("Select All", 95, 451, -36, selectAll, true)
    control("Remove Selected", 115, 552, -36, function()
        for id in pairs(selection) do ac.RemoveBuyListItem(id) end
        selection = {}
        refresh("Selected items removed.")
    end, true)
    local function scan(selected)
        local ok, err = ac.SearchBuyList(selected and selection or nil)
        if not ok then refresh(err) end
    end
    control("Scan List", 82, 16, -65, function() scan(false) end, true)
    control("Scan Selected", 105, 103, -65, function() scan(true) end, true)
    local refreshSelected=control("Refresh Selected",128,214,-65,function()
        if not ac.session.buyList or ac.session.buyListInvalid then return end
        local targets={}
        for _,row in ipairs(ac.session.rows) do if selection[row.itemID] then targets[#targets+1]=row end end
        local ok,err=ac.RefreshRows(targets)
        if not ok then refresh(err) end
    end)
    local buy = control("Buy Selected", 112, 642, -344, function()
        local ok, err = ac.BatchBeginOrNext(selection, true)
        if not ok then refresh(err) end
    end)
    local buyAll = control("Buy All", 92, 544, -344, function()
        local all = {}
        for _, item in ipairs(ac.GetBuyList()) do all[item.itemID] = true end
        local ok, err = ac.BatchBeginOrNext(all, true)
        if not ok then refresh(err) end
    end)
    local stop = control("Stop", 48, 440, -344, function()
        if ac.batch and ac.batch.buyList then ac.StopBuyListQueue()
        elseif ac.session.buyList and ac.session.mode == "searching" then ac.Cancel("Buy List scan stopped.") end
    end)
    local skip = control("Skip", 44, 494, -344, function() ac.SkipBuyListOrder() end)
    local combined = at(label(panel, "", "GameFontHighlightSmall", GOLD), 16, -350)
    local tableFrame = inset(panel)
    at(tableFrame, 9, -91)
    tableFrame:SetPoint("BOTTOMRIGHT", panel, "BOTTOMRIGHT", -9, 59)
    tableFrame:EnableMouseWheel(true)
    local function sort(key)
        if sortKey == key then reverse = not reverse else sortKey, reverse = key, false end
        listPage = 1
        refresh()
    end
    local columns = {
        {"Item", 40, 142, "name"}, {"Qty", 191, 44}, {"Bags", 242, 41, "owned"},
        {"AH Qty", 284, 51, "available"}, {"Lowest / unit", 339, 103, "price"},
        {"Max / unit", 450, 126}, {"Est. total", 586, 77, "cost"}, {"Status", 670, 86},
    }
    for _, col in ipairs(columns) do
        if col[4] then
            local key = col[4]
            local header = at(CreateFrame("Button", nil, tableFrame), col[2], -10)
            header:SetSize(col[3], 17)
            at(label(header, col[1], "GameFontNormalSmall", GOLD), 0, 0)
            header:SetScript("OnClick", function() sort(key) end)
        else
            at(label(tableFrame, col[1], "GameFontNormalSmall", GOLD), col[2], -10)
        end
    end
    for i = 1, PAGE_SIZE do
        local line = at(CreateFrame("Button", nil, tableFrame), 4, -27 - (i-1)*25)
        line:SetSize(752, 24)
        local stripe = line:CreateTexture(nil, "BACKGROUND")
        stripe:SetAllPoints()
        stripe:SetColorTexture(.35, .26, .12, i%2 == 0 and .20 or .08)
        local check = at(button(line, "", 27, 21, function()
            local id = line.item.itemID
            selection[id] = not selection[id] or nil
            refresh()
        end), 2, -1)
        local mark = selectionMark(check)
        local icon = line:CreateTexture(nil, "ARTWORK")
        icon:SetSize(17,17)
        at(icon, 34, -3)
        local name = at(label(line, "", "GameFontHighlightSmall", LIGHT), 54, -5)
        name:SetSize(128, 16)
        name:SetWordWrap(false)
        name:SetMaxLines(1)
        name:SetNonSpaceWrap(false)
        local amount = input(line, 41, 188, -1, 5)
        amount:SetNumeric(true)
        local caps = {}
        for j, currency in ipairs({{"g", 450, 33, 6}, {"s", 496, 24, 3}, {"c", 533, 24, 3}}) do
            local box = input(line, currency[3], currency[2], -1, currency[4])
            box:SetNumeric(true)
            caps[j] = box
            at(label(line, currency[1], "GameFontHighlightSmall", GOLD), currency[2]+currency[3]+1, -5)
        end
        local edits = {amount, unpack(caps)}
        local function save()
            local maxUnit = (tonumber(caps[1]:GetText()) or 0)*10000 +
                (tonumber(caps[2]:GetText()) or 0)*100 + (tonumber(caps[3]:GetText()) or 0)
            local result, err = ac.SaveBuyListItem(line.item.itemID, amount:GetText(), maxUnit > 0 and maxUnit or nil)
            for _, box in ipairs(edits) do box:ClearFocus() end
            refresh(result and "Item saved. Scan again before buying." or err)
        end
        for j, box in ipairs(edits) do
            box:SetScript("OnEnterPressed", save)
            box:SetScript("OnTabPressed", function()
                local direction = IsShiftKeyDown() and -1 or 1
                edits[(j-1+direction)%#edits+1]:SetFocus()
            end)
        end
        local fields = {}
        for key, pos in pairs({owned=240, available=282, price=335, cost=582, status=666}) do
            fields[key] = at(label(line, "", "GameFontHighlightSmall", LIGHT), pos, -5)
            fields[key]:SetSize((key == "owned" or key == "available") and 46 or key == "status" and 86 or key == "cost" and 81 or 100, 16)
            fields[key]:SetWordWrap(false)
        end
        local recheck=refreshButton(line,function()
            local item=line.item
            if not item or not item.quote then return end
            local ok,err=ac.RefreshRows({item.quote})
            if not ok then refresh(err) end
        end)
        recheck:SetPoint("TOPRIGHT",line,"TOPRIGHT",0,-1)
        fields.status:SetWidth(64)
        line:SetScript("OnEnter", function()
            local item = line.item
            GameTooltip:SetOwner(line, "ANCHOR_RIGHT")
            if GameTooltip.SetItemByID then GameTooltip:SetItemByID(item.itemID)
            else GameTooltip:AddLine(item.name) end
            if item.quote and item.quote.observedAt and date then
                GameTooltip:AddLine("Observed " .. date("%I:%M:%S %p", item.quote.observedAt))
            end
            if item.status == "Cap unavailable" then
                GameTooltip:AddLine("Commodity confirmation can reprice without an enforceable cap.", 1, .78, .3, true)
            end
            GameTooltip:AddLine("Press Enter to save. A 0g 0s 0c maximum means unlimited.")
            GameTooltip:Show()
        end)
        line:SetScript("OnLeave", function() GameTooltip:Hide() end)
        listRows[i] = {frame=line, check=check, mark=mark, stripe=stripe, icon=icon, name=name, edits=edits, fields=fields, recheck=recheck}
    end
    local message = at(label(panel, "", "GameFontHighlightSmall", LIGHT), 16, -321)
    message:SetWidth(745)
    message:SetMaxLines(2)
    message:SetWordWrap(true)
    local footer = label(panel, "|cffa68036RIP Shady|r   v" .. ac.version, "GameFontHighlightSmall", MUTED)
    footer:SetPoint("BOTTOMLEFT", panel, "BOTTOMLEFT", 16, 8)
    local prev = button(panel, "<", 26, 20, function() listPage=listPage-1; refresh() end)
    prev:SetPoint("BOTTOMRIGHT", panel, "BOTTOMRIGHT", -112, 5)
    local pagesText = label(panel, "", "GameFontHighlightSmall", LIGHT)
    pagesText:SetPoint("BOTTOMRIGHT", panel, "BOTTOMRIGHT", -54, 8)
    local nextPage = button(panel, ">", 26, 20, function() listPage=listPage+1; refresh() end)
    nextPage:SetPoint("BOTTOMRIGHT", panel, "BOTTOMRIGHT", -16, 5)
    local function scroll(_, delta)
        listPage = listPage - delta
        refresh()
    end
    panel:SetScript("OnMouseWheel", scroll)
    tableFrame:SetScript("OnMouseWheel", scroll)
    refresh = function(status)
        if not surface:IsShown() then return end
        deletePending = nil
        local names, index = ac.BuyListNames()
        heading:SetText(("%s (%d/%d)"):format(names[index], index, #names))
        mode:SetText(ac.db.buyListRestock and "Mode: Restock" or "Mode: Fixed Qty")
        local session = ac.session
        local valid = session.buyList and not session.buyListInvalid
        local quotes, total, selected, eligible, unscanned, covered = {}, 0, 0, 0, 0, 0
        if valid then for _, row in ipairs(session.rows) do quotes[row.itemID] = row end end
        local entries = ac.GetBuyList()
        for _, item in ipairs(entries) do
            local quote = quotes[item.itemID]
            item.quote = quote
            item.name, item.owned = ac.itemName(item.itemID), ac.BuyListOwned(item.itemID)
            item.status = quote and quote.state or "Not Scanned"
            if quote then
                item.price, item.available = quote.minUnit, quote.available
                local units, cost, reason = ac.BuyListReview(quote)
                item.status = reason or (units < ac.BuyListRemaining(quote) and ("Partial " .. units) or "Ready")
                if units > 0 then item.cost = cost end
            end
            if ac.pendingPurchase and ac.pendingPurchase.row == quote then item.status = "Buying" end
            if selection[item.itemID] then
                selected = selected + 1
                if item.cost then eligible, total = eligible + 1, total + item.cost end
                if not quote or item.status == "Rescan" then unscanned = unscanned + 1 end
            end
            if quote and item.status ~= "Rescan" then covered = covered + 1 end
        end
        table.sort(entries, function(a,b)
            local x,y = a[sortKey],b[sortKey]
            if x == y then return a.itemID < b.itemID end
            if x == nil then return false end
            if y == nil then return true end
            if reverse then return x > y end
            return x < y
        end)
        local pages = math.max(1, math.ceil(#entries/PAGE_SIZE))
        listPage = math.min(pages, math.max(1, listPage))
        local busy = ac.BuyListBusy()
        for i, row in ipairs(listRows) do
            local item = entries[(listPage-1)*PAGE_SIZE+i]
            local same = item and row.frame.item and row.frame.item.itemID == item.itemID
            row.frame.item = item
            row.frame:SetShown(item ~= nil)
            if item then
                local checked = selection[item.itemID] == true
                row.mark:SetSelected(checked)
                row.stripe:SetColorTexture(checked and .17 or .35, checked and .40 or .26,
                    .12, checked and .52 or (i%2 == 0 and .20 or .08))
                row.check:SetEnabled(not busy)
                row.recheck:SetEnabled(not not (valid and item.quote~=nil and ac.CanRefreshRows()))
                row.icon:SetTexture(itemIcon(item.itemID))
                row.name:SetText(item.name)
                local cap = item.maxUnit or 0
                local values = {item.required, math.floor(cap/10000), math.floor(cap/100)%100, cap%100}
                local editing = false
                for _, box in ipairs(row.edits) do editing = editing or box:HasFocus() end
                for j, box in ipairs(row.edits) do
                    if busy or not same then box:ClearFocus() end
                    if busy or not same or not editing then box:SetText(tostring(values[j])) end
                    box:SetEnabled(not busy)
                end
                for key, field in pairs(row.fields) do
                    local value = item[key]
                    if key=="price" or key=="cost" then value = displayMoney(value) end
                    field:SetText(value or "–")
                end
            end
        end
        prev:SetEnabled(listPage>1)
        nextPage:SetEnabled(listPage<pages)
        pagesText:SetText(("%d / %d"):format(listPage,pages))
        for _, b in ipairs(controls) do b:SetEnabled(not busy) end
        selecting:SetText(selected>0 and selected==#entries and "Deselect All" or "Select All")
        local queue = ac.batch and ac.batch.buyList
        local canStart = not busy and session.mode == "done" and valid
        local locked = ac.HasPurchaseLock()
        buy:SetText(locked and "Purchase locked" or (queue and "Buy Next" or "Buy Selected"))
        refreshSelected:SetEnabled(not not (valid and selected>0 and ac.CanRefreshRows()))
        buy:SetEnabled(not locked and not ac.pendingPurchase and ((queue and not ac.batch.waiting and session.mode=="done") or
            (canStart and selected>0 and unscanned==0)))
        buyAll:SetEnabled(not locked and canStart and #entries>0 and covered==#entries)
        stop:SetEnabled(queue or (valid and session.mode=="searching"))
        skip:SetEnabled(queue and not ac.pendingPurchase)
        combined:SetText(("Selected %d   Eligible %d   Est. %s%s"):format(selected, eligible,
            eligible > 0 and ac.money(total) or "--", unscanned > 0 and " (scan needed)" or ""))
        message:SetText(ac.HasPurchaseLock() and ac.purchaseLockMessage or status or (valid and session.status) or
            "Enter a name, item ID, or link. Max price is optional. Press Enter to save row edits.")
    end
    surface:SetScript("OnShow", function() fit(); refresh() end)
    surface:SetScript("OnHide", function()
        deletePending = nil
        listName:ClearFocus()
        itemInput:ClearFocus()
        for _, row in ipairs(listRows) do
            for _, box in ipairs(row.edits) do box:ClearFocus() end
        end
    end)
    ac.Subscribe(function() refresh() end)
    panel:RegisterEvent("BAG_UPDATE_DELAYED")
    panel:SetScript("OnEvent", function() refresh() end)
    return surface
end

local function refreshPreview()
    if not ui then return end
    local r=chosen()
    local has=r~=nil
    local busy=ac.session.mode~="done"
    local auctionItem=has and r.source=="item"
    preview.name:SetText(has and (r.name or ac.itemName(r.itemID)) or "Select an item")
    preview.icon:SetTexture(has and itemIcon(r.itemID) or "Interface\\Icons\\INV_Misc_QuestionMark")
    preview.icon:SetShown(has)
    preview.type:SetText(has and (r.role or r.output and "Finished item" or r.source=="browse" and "Search result" or ac.session.buyList and "Saved item" or "Recipe reagent") or "Select a result on the left for buy details.")
    preview.need:SetText(has and (r.output and "Compare" or tostring(ac.BatchRemaining(r))) or "--")
    preview.owned:SetText(has and tostring(r.owned or 0) or "--")
    local available = has and r.available and tostring(r.available) or "--"
    if has and r.maxUnit and r.withinCap then
        available = ("%d at max or less (%d total)"):format(r.withinCap, r.available)
    end
    preview.available:SetText(available)
    preview.unit:SetText(has and displayMoney(auctionItem and r.cheapestListing and r.cheapestListing.buyout or r.minUnit) or "--")
    preview.priceLabel:SetText(auctionItem and "Listing price" or "Lowest / unit")
    qtyBox:SetEnabled(has and not ac.session.buyList and not ac.BuyListBusy())
    preview.add:SetEnabled(has and r.itemID ~= nil and not busy and not ac.session.buyList and not ac.BuyListBusy())
    preview.quantityLabel:SetText(auctionItem and "List quantity" or "Quantity")
    local cost, explanatory=estimate(r, quantity())
    preview.total:SetText(cost and ac.money(cost) or "--")
    if has and r.maxUnit and r.minUnit then
        explanatory = r.minUnit and r.minUnit > r.maxUnit and "Over maximum / unit" or
            ("Max / unit " .. ac.money(r.maxUnit))
    end
    preview.estimate:SetText(has and (explanatory or r.state or "No valid buyout observed") or "")
    preview.estimate:SetShown(has)
    local canBuy=has and not busy and r.minUnit~=nil and r.source~="browse"
    if ac.session.buyList then canBuy = false end
    buyButton:SetEnabled(canBuy and not ac.HasPurchaseLock() and not ac.pendingPurchase and not ac.batch and
        not (r.source=="commodity" and tonumber(r.available or 0)<quantity()))
    local tiers=has and r.tiers or nil
    local height=ui.right and ui.right:GetHeight() or 0
    local showTiers=height>=439 and tiers and #tiers>0
    preview.tiersHeading:SetShown(not not showTiers)
    for i=1,TIER_COUNT do
        local t=showTiers and tiers[i] or nil
        local line=preview.tierLines[i]
        local maxVisible=math.max(0,math.floor((height-420)/19))
        line:SetShown(t~=nil and i<=maxVisible)
        if t then
            line.price:SetText(ac.money(t.unitPrice))
            line.available:SetText("x"..tostring(t.quantity or 0))
            line.note:SetText(r.source=="commodity" and "per item" or "per listing")
        end
    end
end

local function updateLayout()
    if not ui then return end
    local w = math.max(730,ui:GetWidth())
    local leftWidth = math.floor(w*.515)
    local rightWidth = math.max(250, w-leftWidth-18)
    if profitHint then
        profitHint:SetWidth(math.max(240,w-405))
        profitHint:SetMaxLines(2)
        profitHint:SetWordWrap(true)
    end
    if statusText then statusText:SetWidth(math.max(420,w-132)) end
    if titleText then titleText:SetWidth(math.max(80,leftWidth-210)) end
    if preview and preview.name then preview.name:SetWidth(math.max(190,rightWidth-120)) end
    if preview and preview.estimate then preview.estimate:SetWidth(math.max(250,rightWidth-42)) end
    if preview and preview.queueNote then preview.queueNote:SetWidth(math.max(250,leftWidth-22)) end
    ui.left:ClearAllPoints()
    ui.left:SetPoint("TOPLEFT",ui,"TOPLEFT",7,-79)
    ui.left:SetPoint("BOTTOMLEFT",ui,"BOTTOMLEFT",7,54)
    ui.left:SetWidth(leftWidth-9)
    ui.right:ClearAllPoints()
    ui.right:SetPoint("TOPLEFT",ui,"TOPLEFT",leftWidth+5,-79)
    ui.right:SetPoint("BOTTOMRIGHT",ui,"BOTTOMRIGHT",-7,54)
    for _,r in ipairs(rows) do
        -- Coin textures need more horizontal space than abbreviated g/s/c.
        r.name:SetWidth(leftWidth-284)
        r.price:ClearAllPoints()
        r.price:SetPoint("TOPRIGHT",r,"TOPRIGHT",-71,-5)
        r.price:SetWidth(113)
        r.need:ClearAllPoints()
        r.need:SetPoint("TOPRIGHT",r,"TOPRIGHT",-25,-5)
        r.need:SetWidth(42)
    end
end

local function visibleResults(session)
    if lastSession ~= session then
        lastSession = session
        onlyNeeded = false
        page = 1
    end
    for i = #sortedRows, 1, -1 do
        order[sortedRows[i]] = nil
        sortedRows[i] = nil
    end
    for index, row in ipairs(session.rows) do
        if not onlyNeeded or ac.BatchRemaining(row) > 0 then
            sortedRows[#sortedRows + 1] = row
            order[row] = index
        end
    end
    if resultSort then
        table.sort(sortedRows, function(a, b)
            local field = resultSort
            local av, bv
            if field == "name" then
                av, bv = a.name:lower(), b.name:lower()
            elseif field == "price" then
                av, bv = a.minUnit or math.huge, b.minUnit or math.huge
                if a.minUnit == nil and b.minUnit ~= nil then return false end
                if a.minUnit ~= nil and b.minUnit == nil then return true end
            else
                av, bv = ac.BatchRemaining(a), ac.BatchRemaining(b)
            end
            if av == bv then return order[a] < order[b] end
            if descending then return av > bv end
            return av < bv
        end)
    end
    return sortedRows
end

local function refresh()
    if not ui or not ui:IsShown() then return end
    local session=ac.session
    titleText:SetText((session.label and session.label~="") and session.label or "Search results")
    if vendorCheckbox then vendorCheckbox:SetChecked(ac.PreferVendor and ac.PreferVendor() or false) end
    if professionCheckbox then professionCheckbox:SetChecked(ac.ProfessionSearchEnabled()) end
    if smartRefreshCheckbox then smartRefreshCheckbox:SetChecked(ac.SmartRefreshEnabled()) end
    if profitText then
        local gain,explanation=recipeProfit(session)
        if session.shopping then
            gain=nil
            explanation='Writ shopping: select a row to buy; Buy All requires individual Blizzard confirmations.'
        end
        profitText:SetText(session.buyList and 'Buy List shopping' or session.shopping and 'Writ shopping' or
            (gain and ((gain>=0 and "Profit: +" or "Profit: -")..money0(math.abs(gain))) or "Profit: --"))
        profitText:SetTextColor(gain==nil and .92 or gain>=0 and .28 or 1,
            gain==nil and .80 or gain>=0 and 1 or .35,
            gain==nil and .40 or gain>=0 and .42 or .35)
        if session.buyList then
            local total, remaining, confirmed, unknown = 0, 0, 0, 0
            for _, row in ipairs(session.rows) do
                local need = ac.BatchRemaining(row)
                remaining = remaining + need
                confirmed = confirmed + (row.acBought or 0)
                if need > 0 then
                    local cost = row.state == "Ready" and estimate(row, need)
                    if row.source == "item" and (not row.cheapestListing or row.cheapestListing.quantity ~= need) then cost = nil end
                    if cost and row.maxUnit and cost / need > row.maxUnit then cost = nil end
                    if cost then total = total + cost else unknown = unknown + 1 end
                end
            end
            profitText:SetText("Est. AH: " .. (unknown > 0 and total == 0 and "--" or ac.money(total)))
            explanation = ("%d left, %d confirmed%s"):format(remaining, confirmed,
                unknown > 0 and (", " .. unknown .. " unquoted") or "")
        end
        profitHint:SetText(explanation)
    end
    if ac.batch then
        buyAllButton:SetText(ac.batch.waiting and "Confirm in WoW" or ("Buy Next (%d)"):format(ac.BatchCount()))
        buyAllButton:SetEnabled(not session.buyList and session.mode=="done" and not ac.batch.waiting and not ac.pendingPurchase)
        selectAllButton:SetText("Stop")
    else
        buyAllButton:SetText(("Buy All (%d)"):format(ac.BatchCount()))
        buyAllButton:SetEnabled(not session.buyList and session.mode=="done" and ac.BatchCount()>0 and not ac.pendingPurchase)
        selectAllButton:SetText("All")
    end
    if ac.HasPurchaseLock() then
        buyAllButton:SetText("Purchase locked")
        buyAllButton:SetEnabled(false)
    end
    statusText:SetText(ac.HasPurchaseLock() and ac.purchaseLockMessage or session.status or "")
    local results=visibleResults(session)
    local refreshReady=not session.buyList and ac.CanRefreshRows()
    local refreshCount=0
    for _,row in ipairs(session.rows) do if row.acSelected and ac.CanRefreshRow(row) then refreshCount=refreshCount+1 end end
    ui.refreshSelected:SetEnabled(refreshReady and refreshCount>0)
    local total=#results
    ui.needFilter:SetText(onlyNeeded and "Show All" or "To Buy Only")
    ui.needFilter:SetEnabled(session.mode=="done" and not not (session.buyList or session.recipe or session.shopping))
    for key, header in pairs(ui.sortHeaders) do
        header:SetText(sortLabels[key] .. (resultSort==key and (descending and " -" or " +") or ""))
    end
    page=math.max(1,math.min(page,math.max(1,math.ceil(total/ROW_COUNT))))
    for i, b in ipairs(rows) do
        local row=results[(page-1)*ROW_COUNT+i]
        b.data=row
        b:SetShown(row~=nil)
        if row then
            if row.itemID then
                local n=ac.itemName(row.itemID)
                if n~=("Item #"..tostring(row.itemID)) and n~="Unknown" then row.name=n end
            end
            b.icon:SetTexture(itemIcon(row.itemID))
            b.name:SetText((row.output and "|cff80c6ff" or "|cfffff0d4")..
                tostring(row.name or row.itemID).."|r")
            local price = displayMoney(row.minUnit)
            if session.buyList then
                if row.minUnit and row.maxUnit and row.minUnit > row.maxUnit then price = "Over max"
                elseif not row.minUnit then price = row.state or "--"
                elseif row.state == "Partial" then price = "~ " .. price end
            end
            if ac.IsRefreshingRows() and (row.state=="Refresh queued" or row.state=="Searching...") then price="Refreshing" end
            b.price:SetText(price)
            b.recheck:SetEnabled(refreshReady and not not ac.CanRefreshRow(row))
            b.toggle:SetEnabled(session.mode=="done" and not ac.batch)
            local left=ac.BatchRemaining(row)
            b.need:SetText(row.output and "--" or left==0 and "OK" or tostring(left))
            local checkable=not row.output and left>0
            b.check:SetSelected(checkable and row.acSelected == true)
            b.check:SetShown(checkable)
            local selected=row==chosen()
            if row.acSelected and checkable then
                b.highlight:SetColorTexture(.17,.40,.12,selected and .75 or .44)
            else
                b.highlight:SetColorTexture(selected and .40 or .11,selected and .32 or .09,
                    selected and .14 or .07,selected and .80 or (i%2==0 and .31 or .13))
            end
        end
    end
    paging.label:SetText(("%d / %d"):format(page,math.max(1,math.ceil(total/ROW_COUNT))))
    if preview.queueNote then
        preview.queueNote:SetText(ac.HasPurchaseLock() and "Previous purchase needs reconciliation." or ac.batch and (ac.batch.waiting and
            "Confirm the pending purchase in Blizzard's dialog." or
            "Queue ready: press Buy Next to continue.") or
            "Click the check or X to change Buy All selection.")
    end
    paging.prev:SetEnabled(page>1)
    paging.next:SetEnabled(page*ROW_COUNT<total)
    ui.stop:SetShown(session.mode=="searching" or session.mode=="browse" or
        session.mode=="name-scan" or ac.pendingPurchase~=nil)
    refreshPreview()
end

function ac.BuildUI()
    if ui then return ui end
    local ah=AuctionHouseFrame
    if not ah then return nil end
    ui=CreateFrame("Frame","AuctionCompanionFrame",ah)
    ac.window=ui
    -- Borrow Blizzard's existing AH background: no competing black backdrop,
    -- thick gold border, artificial title bar, or stand-alone window.
    ui:SetPoint("TOPLEFT",ah,"TOPLEFT",4,-103)
    ui:SetPoint("BOTTOMRIGHT",ah,"BOTTOMRIGHT",-4,27)
    ui:SetFrameLevel(ah:GetFrameLevel()+3)
    ui:EnableMouse(true)
    ui:SetScript("OnShow",refresh)
    ui:SetScript("OnHide", function()
        if priceSettingsPanel then priceSettingsPanel:Hide() end
    end)
    ui:Hide()

    local searchLabel=label(ui,"Search Term:","GameFontNormal",GOLD)
    at(searchLabel,28,-15)
    searchBox=CreateFrame("EditBox",nil,ui,"InputBoxTemplate")
    searchBox:SetPoint("TOPLEFT",ui,"TOPLEFT",128,-7)
    searchBox:SetSize(291,22)
    searchBox:SetAutoFocus(false)
    searchBox:SetMaxLetters(80)
    searchBox:SetScript("OnEscapePressed",function(self)self:ClearFocus()end)
    local function doTextSearch()
        searchBox:ClearFocus()
        local ok,err=ac.SearchText(searchBox:GetText())
        if not ok then ac.Status(err) end
    end
    searchBox:SetScript("OnEnterPressed",doTextSearch)
    button(ui,"Search",98,23,doTextSearch):SetPoint("TOPLEFT",ui,"TOPLEFT",435,-6)
    button(ui,"Clear",74,23,function()
        if ac.pendingPurchase then ac.Status("Finish the Blizzard purchase before clearing results."); return end
        if ac.batch and ac.batch.buyList then ac.Status("Stop the queue on Buy List first."); return end
        ac.Cancel("Cleared")
        ac.session={rows={},mode="idle",label="",selected=nil,status="Ready for another search."}
        searchBox:SetText("")
        qtyBox:SetText("1")
        ac.Notify()
    end):SetPoint("TOPLEFT",ui,"TOPLEFT",542,-6)
    local scanTop=button(ui,"Full Scan",105,23,function()
        if not ac.FullScanStart then ac.Status("Scanner is unavailable");return end
        local ok,err=ac.FullScanStart()
        if not ok then ac.Status(err or "Unable to start scan");ac.announce(err or "Unable to start scan") end
    end)
    scanTop:SetPoint("TOPRIGHT",ui,"TOPRIGHT",-16,-6)
    if ac.RegisterScanButton then ac.RegisterScanButton(scanTop) end
    scanTop:SetScript("OnEnter",function(self)
        GameTooltip:SetOwner(self,"ANCHOR_TOP")
        GameTooltip:AddLine("Auction Companion Full Scan",1,.82,.3)
        local remaining,source=ac.GetFullScanCooldown and ac.GetFullScanCooldown()
        if remaining and remaining>0 then
            local sec=math.ceil(remaining)
            GameTooltip:AddLine(("Next scan in %d:%02d"):format(math.floor(sec/60),sec%60),1,.5,.35)
            GameTooltip:AddLine(tostring(source or "shared server cooldown"),.8,.8,.8,true)
            if type(date)=="function" then
                GameTooltip:AddLine("Estimated ready: "..date("%I:%M %p",time()+sec),.8,.8,.8)
            end
        else
            GameTooltip:AddLine("Ready to request; an unobserved cooldown may still apply.",.75,.85,.7,true)
        end
        GameTooltip:AddLine("Shares its full-scan cooldown with Auctionator and AHledger.",.9,.9,.9,true)
        GameTooltip:Show()
    end)
    scanTop:SetScript("OnLeave",function()GameTooltip:Hide()end)

    profitText=label(ui,"Profit: --","GameFontNormal",GOLD)
    profitText:SetPoint("TOPLEFT",ui,"TOPLEFT",29,-39)
    profitText:SetWidth(245)
    profitHint=label(ui,"Select a recipe to estimate profit.","GameFontHighlightSmall",MUTED)
    profitHint:SetPoint("TOPLEFT",ui,"TOPLEFT",280,-40)
    -- Reserve space on the second row for one compact settings toggle.
    profitHint:SetWidth(math.max(210,ui:GetWidth()-405))
    local pricesButton=button(ui,'Settings',78,20,function()
        if priceSettingsPanel then
            priceSettingsPanel:SetShown(not priceSettingsPanel:IsShown())
        end
    end)
    pricesButton:SetPoint('TOPRIGHT',ui,'TOPRIGHT',-16,-34)
    priceSettingsPanel=CreateFrame("Frame","AuctionCompanionSettings",ui)
    closeOnEscape(priceSettingsPanel,"AuctionCompanionSettings")
    local settingsBackground=priceSettingsPanel:CreateTexture(nil,"BACKGROUND")
    settingsBackground:SetAllPoints()
    settingsBackground:SetColorTexture(.095,.075,.055,1)
    priceSettingsPanel:SetSize(332,163)
    at(label(priceSettingsPanel,"RIP Shady","GameFontHighlightSmall",GOLD),16,-142)
    priceSettingsPanel:SetPoint('TOPRIGHT',pricesButton,'BOTTOMRIGHT',0,-3)
    priceSettingsPanel:SetFrameLevel(ui:GetFrameLevel()+40)
    vendorCheckbox=CreateFrame('CheckButton',nil,priceSettingsPanel,'UICheckButtonTemplate')
    vendorCheckbox:SetSize(26,26)
    vendorCheckbox:SetPoint('TOPLEFT',priceSettingsPanel,'TOPLEFT',10,-10)
    vendorCheckbox:SetChecked(ac.PreferVendor and ac.PreferVendor() == true)
    local vendorLabel=label(priceSettingsPanel,'Use vendor prices when cheaper','GameFontNormal',GOLD)
    vendorLabel:SetPoint('LEFT',vendorCheckbox,'RIGHT',2,1)
    vendorCheckbox:SetScript('OnClick',function(self)
        if type(ac.SetPreferVendor)~='function' then return end
        local ok,err=ac.SetPreferVendor(self:GetChecked())
        if not ok then self:SetChecked(ac.PreferVendor());ac.Status(err) end
    end)
    local vendorNote=label(priceSettingsPanel,
        'Crafting estimates only. AH search prices are unchanged.',
        'GameFontHighlightSmall',MUTED)
    vendorNote:SetPoint('TOPLEFT',priceSettingsPanel,'TOPLEFT',16,-47)
    vendorNote:SetWidth(300)
    professionCheckbox=CreateFrame('CheckButton',nil,priceSettingsPanel,'UICheckButtonTemplate')
    professionCheckbox:SetSize(26,26)
    professionCheckbox:SetPoint('TOPLEFT',priceSettingsPanel,'TOPLEFT',10,-75)
    professionCheckbox:SetChecked(ac.ProfessionSearchEnabled())
    local professionLabel=label(priceSettingsPanel,'Show AC Search in profession windows','GameFontNormal',GOLD)
    professionLabel:SetPoint('LEFT',professionCheckbox,'RIGHT',2,1)
    professionCheckbox:SetScript('OnClick',function(self)
        if not ac.SetProfessionSearchEnabled(self:GetChecked()) then
            self:SetChecked(ac.ProfessionSearchEnabled())
        end
    end)
    smartRefreshCheckbox=CreateFrame('CheckButton',nil,priceSettingsPanel,'UICheckButtonTemplate')
    smartRefreshCheckbox:SetSize(26,26)
    smartRefreshCheckbox:SetPoint('TOPLEFT',priceSettingsPanel,'TOPLEFT',10,-105)
    smartRefreshCheckbox:SetChecked(ac.SmartRefreshEnabled())
    local smartLabel=label(priceSettingsPanel,'Refresh changed listings before retry','GameFontNormal',GOLD)
    smartLabel:SetPoint('LEFT',smartRefreshCheckbox,'RIGHT',2,1)
    smartRefreshCheckbox:SetScript('OnClick',function(self)
        if ac.db then ac.db.smartRefresh=self:GetChecked()==true end
    end)
    priceSettingsPanel:Hide()
    profitHint:SetMaxLines(2)
    profitHint:SetWordWrap(true)

    ui.left=inset(ui)
    ui.right=inset(ui)
    titleText=label(ui.left,"Search results","GameFontNormal",GOLD)
    at(titleText,15,-13)
    selectAllButton=button(ui.left,"All",45,20,function()
        if ac.batch then
            if ac.batch.buyList then ac.Status("Stop the queue on Buy List."); return end
            ac.ClearBatch()
            ac.Status("Queue stopped. Complete or cancel any open Blizzard confirmation.")
        else
            ac.BatchSelectAll()
        end
    end)
    selectAllButton:SetPoint("BOTTOMLEFT",ui.left,"BOTTOMLEFT",15,12)
    buyAllButton=button(ui.left,"Buy All",119,21,function()
        local ok,err=ac.BatchBeginOrNext()
        if not ok and err then ac.Status(err) end
    end)
    buyAllButton:SetPoint("LEFT",selectAllButton,"RIGHT",8,0)
    titleText:SetWidth(175)
    titleText:SetMaxLines(1)
    titleText:SetWordWrap(false)
    ui.needFilter=button(ui.left,"To Buy Only",76,19,function()
        onlyNeeded=not onlyNeeded
        page=1
        refresh()
    end)
    ui.needFilter:SetPoint("TOPRIGHT",ui.left,"TOPRIGHT",-12,-8)
    ui.refreshSelected=button(ui.left,"Refresh Sel.",84,19,function()
        local ok,err=ac.RefreshSelectedRows()
        if not ok then ac.Status(err) end
    end)
    ui.refreshSelected:SetPoint("RIGHT",ui.needFilter,"LEFT",-4,0)
    ui.sortHeaders={}
    local function makeHeader(field, width)
        local header = CreateFrame("Button",nil,ui.left)
        header:SetSize(width,18)
        header:SetNormalFontObject(GameFontNormalSmall)
        header:SetHighlightFontObject(GameFontHighlightSmall)
        header:SetScript("OnClick",function()
            descending = resultSort==field and not descending or false
            resultSort=field
            page=1
            refresh()
        end)
        ui.sortHeaders[field]=header
        header:SetText(sortLabels[field])
        return header
    end
    at(makeHeader("name",58),10,-33)
    makeHeader("price",74):SetPoint("TOPRIGHT",ui.left,"TOPRIGHT",-78,-33)
    makeHeader("need",58):SetPoint("TOPRIGHT",ui.left,"TOPRIGHT",-22,-33)
    rows={}
    for i=1,ROW_COUNT do
        local r=CreateFrame("Button",nil,ui.left)
        r:SetPoint("TOPLEFT",ui.left,"TOPLEFT",12,-58-(i-1)*26)
        r:SetPoint("TOPRIGHT",ui.left,"TOPRIGHT",-12,-58-(i-1)*26)
        r:SetHeight(25)
        r.highlight=r:CreateTexture(nil,"BACKGROUND")
        r.highlight:SetAllPoints()
        r.icon=r:CreateTexture(nil,"ARTWORK")
        r.icon:SetPoint("TOPLEFT",r,"TOPLEFT",27,-4)
        r.icon:SetSize(18,18)
        r.name=label(r,"","GameFontHighlight",LIGHT)
        at(r.name,51,-4)
        r.name:SetMaxLines(1)
        r.name:SetWordWrap(false)
        r.name:SetNonSpaceWrap(false)
        r.price=label(r,"","GameFontHighlight",LIGHT)
        r.price:SetJustifyH("RIGHT")
        r.need=label(r,"","GameFontHighlight",GOLD)
        r.need:SetJustifyH("RIGHT")
        r:RegisterForClicks("LeftButtonUp", "RightButtonUp")
        r:SetScript("OnClick",function(self,mouseButton)
            local selected=self.data
            if not selected then return end
            if mouseButton == "RightButton" then
                local index, err = ac.SaveBuyListItem(selected.itemID, 1, nil, true)
                ac.Status(index and (ac.itemName(selected.itemID) .. " is on the active Buy List.") or err)
                return
            end
            if ac.session.mode=="searching" or ac.session.mode=="browse" then return end
            if selected.source=="browse" then
                local ok,err=ac.SearchOne(selected.itemID,1)
                if not ok then ac.Status(err) end
            else
                for n,item in ipairs(ac.session.rows) do
                    if item==selected then ac.session.selected=n; break end
                end
                qtyBox:SetText(tostring(selected.source=="item" and 1 or
                    (ac.BatchRemaining(selected)>0 and ac.BatchRemaining(selected) or 1)))
                ac.Notify()
            end
        end)
        local toggle=CreateFrame("Button",nil,r)
        toggle:SetPoint("TOPLEFT",r,"TOPLEFT",0,0)
        toggle:SetSize(28,25)
        toggle:SetScript("OnClick",function()
            local ok,err=ac.BatchToggle(r.data)
            if not ok and err then ac.Status(err) end
        end)
        r.toggle=toggle
        r.check=selectionMark(toggle)
        r.recheck=refreshButton(r,function()
            if not r.data then return end
            local ok,err=ac.RefreshRows({r.data})
            if not ok then ac.Status(err) end
        end)
        r.recheck:SetPoint("TOPRIGHT",r,"TOPRIGHT",0,-2)
        r:SetScript("OnEnter",function(self)
            if not (self.data and self.data.itemID) then return end
            GameTooltip:SetOwner(self,"ANCHOR_RIGHT")
            if type(GameTooltip.SetItemByID)=="function" then GameTooltip:SetItemByID(self.data.itemID)
            else GameTooltip:AddLine(ac.itemName(self.data.itemID),1,.82,.25) end
            GameTooltip:AddLine(self.data.source=="browse" and "Click to inspect listings" or
                "Click item for details; checkbox selects it for Buy All",1,.82,.25,true)
            GameTooltip:AddLine("Right-click: Add to Buy List",1,.9,.35)
            local observed = self.data.observedAt
            if observed and observed > 0 and type(date) == "function" then
                GameTooltip:AddLine("Observed " .. date("%I:%M %p", observed) ..
                    (self.data.state=="Partial" and " (partial results)" or ""),.9,.8,.6)
            end
            if not self.data.output and ac.api.GetMaterialCost then
                local selected,source,kind,ah,vendor=ac.api.GetMaterialCost(self.data.itemID)
                if vendor then
                    GameTooltip:AddLine('Vendor buy: '..ac.money(vendor)..
                        (kind=='reference' and ' (standard reference)' or ' (merchant observed)'),.55,1,.48)
                    GameTooltip:AddLine('AH observed: '..(ah and ac.money(ah) or 'not available'),.9,.8,.6)
                    GameTooltip:AddLine('Crafting cost: '..(selected and ac.money(selected) or 'unknown')..' ('..source..')',1,.82,.3)
                    if source=='vendor' then
                        GameTooltip:AddLine('Excluded from Buy All by default; click checkbox to override.',.72,.92,.6,true)
                    end
                end
            end
            GameTooltip:Show()
        end)
        r:SetScript("OnLeave",function()GameTooltip:Hide()end)
        r:Hide()
        rows[i]=r
    end
    paging.prev=button(ui.left,"<",26,20,function()page=page-1;refresh()end)
    paging.prev:SetPoint("BOTTOMRIGHT",ui.left,"BOTTOMRIGHT",-94,12)
    paging.label=label(ui.left,"1 / 1","GameFontHighlightSmall",MUTED)
    paging.label:SetWidth(58)
    paging.label:SetJustifyH("CENTER")
    paging.label:SetPoint("BOTTOMRIGHT",ui.left,"BOTTOMRIGHT",-34,18)
    paging.next=button(ui.left,">",26,20,function()page=page+1;refresh()end)
    paging.next:SetPoint("BOTTOMRIGHT",ui.left,"BOTTOMRIGHT",-9,12)

    local p=ui.right
    preview.heading=label(p,"BUY DETAILS","GameFontNormal",GOLD)
    at(preview.heading,17,-12)
    local buyListButton = button(p, "Buy List", 84, 22, function() ac.SelectBuyTab() end)
    buyListButton:SetPoint("TOPRIGHT", p, "TOPRIGHT", -12, -7)
    preview.add = button(p, "Add", 50, 22, function()
        local row = chosen()
        if not row or not row.itemID or ac.session.mode ~= "done" or ac.session.buyList then return end
        local amount = tonumber(qtyBox:GetText())
        local saved, err = ac.AddSearchItemToBuyList(row.itemID, amount)
        ac.Status(saved and ("%d x %s added to Buy List."):format(amount, row.name or ac.itemName(row.itemID)) or err)
    end)
    preview.add:SetPoint("RIGHT", buyListButton, "LEFT", -4, 0)
    preview.icon=p:CreateTexture(nil,"ARTWORK")
    preview.icon:SetPoint("TOPLEFT",p,"TOPLEFT",19,-38)
    preview.icon:SetSize(39,39)
    preview.name=label(p,"Select an item","GameFontNormalLarge",LIGHT)
    at(preview.name,67,-40)
    preview.name:SetMaxLines(1)
    preview.name:SetWordWrap(false)
    preview.type=label(p,"","GameFontHighlightSmall",MUTED)
    at(preview.type,67,-66)

    preview.quantityLabel=label(p,"Quantity","GameFontNormal",GOLD)
    preview.quantityLabel:SetPoint("TOPLEFT",p,"TOPLEFT",27,-103)
    qtyBox=CreateFrame("EditBox",nil,p,"InputBoxTemplate")
    qtyBox:SetSize(88,23)
    qtyBox:SetPoint("TOPLEFT",p,"TOPLEFT",155,-96)
    qtyBox:SetNumeric(true)
    qtyBox:SetMaxLetters(5)
    qtyBox:SetText("1")
    qtyBox:SetAutoFocus(false)
    qtyBox:SetScript("OnEscapePressed",function(self)self:ClearFocus()end)
    qtyBox:SetScript("OnEnterPressed",function(self)self:ClearFocus()end)
    qtyBox:SetScript("OnTextChanged",function() if ui and ui:IsShown() then refreshPreview() end end)

    -- Keep the entire purchase section inside Blizzard's shorter AH panes.
    for _,s in ipairs({{"Required",-132,"need"},{"Owned",-154,"owned"},
        {"Available",-176,"available"},{"Lowest / unit",-199,"unit"},
        {"Est. total",-224,"total"}}) do
        local name=label(p,s[1],"GameFontNormal",GOLD)
        name:SetPoint("TOPLEFT",p,"TOPLEFT",27,s[2])
        if s[3]=="unit" then preview.priceLabel=name end
        local val=label(p,"--","GameFontHighlight",LIGHT)
        val:SetPoint("TOPLEFT",p,"TOPLEFT",155,s[2])
        val:SetWidth(230)
        preview[s[3]]=val
    end
    preview.estimate=label(p,"","GameFontHighlightSmall",MUTED)
    preview.estimate:SetPoint("TOPLEFT",p,"TOPLEFT",27,-246)
    preview.estimate:SetMaxLines(1)
    preview.estimate:SetWordWrap(false)
    preview.queueNote=label(ui,"","GameFontHighlightSmall",MUTED)
    preview.queueNote:SetPoint("BOTTOMLEFT",ui.left,"BOTTOMLEFT",12,-18)

    buyButton=button(p,"Buy",156,26,function()
        local ok,err=ac.Buy(chosen(),quantity())
        if not ok then ac.Status(err or "Unable to start purchase") end
    end)
    buyButton:SetPoint("BOTTOMRIGHT",p,"BOTTOMRIGHT",-15,10)
    preview.tiersHeading=label(p,"RECENT PRICE LEVELS","GameFontNormalSmall",GOLD)
    preview.tiersHeading:SetPoint("TOPLEFT",p,"TOPLEFT",27,-356)
    preview.tierLines={}
    for i=1,TIER_COUNT do
        local line={}
        local y=-376-(i-1)*19
        line.price=label(p,"","GameFontHighlightSmall",LIGHT)
        line.price:SetPoint("TOPLEFT",p,"TOPLEFT",40,y)
        line.price:SetWidth(102)
        line.available=label(p,"","GameFontHighlightSmall",LIGHT)
        line.available:SetPoint("TOPLEFT",p,"TOPLEFT",163,y)
        line.available:SetWidth(62)
        line.note=label(p,"","GameFontHighlightSmall",MUTED)
        line.note:SetPoint("TOPLEFT",p,"TOPLEFT",240,y)
        line.note:SetWidth(145)
        function line:SetShown(visible)
            self.price:SetShown(visible)
            self.available:SetShown(visible)
            self.note:SetShown(visible)
        end
        preview.tierLines[i]=line
    end

    statusText=label(ui,"Ready to search","GameFontHighlightSmall",MUTED)
    statusText:SetPoint("BOTTOMLEFT",ui,"BOTTOMLEFT",13,22)
    statusText:SetWidth(680)
    ui.stop=button(ui,"Stop",68,21,function()
        local pending = ac.pendingPurchase ~= nil
        ac.Cancel("Stopped")
        ac.Status(pending and "Stopped. Complete or cancel the open Blizzard purchase." or "Stopped.")
    end)
    ui.stop:SetPoint("BOTTOMRIGHT",ui,"BOTTOMRIGHT",-10,13)
    local footer=label(ui,"RIP Shady","GameFontHighlightSmall",MUTED)
    footer:SetPoint("BOTTOMLEFT",ui,"BOTTOMLEFT",13,3)
    footer:SetWidth(70)
    versionText=label(ui,"v"..tostring(ac.version or "?"),"GameFontHighlightSmall",MUTED)
    versionText:SetPoint("LEFT",footer,"RIGHT",6,0)
    versionText:SetWidth(132)
    ui:SetScript("OnSizeChanged",updateLayout)
    ac.Subscribe(refresh)
    page=1
    updateLayout()
    return ui
end
function ac.SetBatchQuantity(amount)
    if qtyBox then qtyBox:SetText(tostring(math.max(1,math.floor(tonumber(amount) or 1)))) end
end
function ac.Open()
    if not ac.IsAtAH() then ac.announce("Open the Auction House first."); return false end
    if not ui then ac.BuildUI() end
    if not ui then return false end
    return ac.SelectTab and ac.SelectTab() or false
end
ac.api.Open=ac.Open
