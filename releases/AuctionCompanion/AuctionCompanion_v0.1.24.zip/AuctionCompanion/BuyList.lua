local _, ac = ...

local MAX_ITEMS = 60

local function integer(value, maximum)
    local number = tonumber(value)
    if number and number >= 1 and number <= maximum and number == math.floor(number) then
        return number
    end
end

-- Keep only item IDs and desired quantities. Auction results and purchases
-- belong to the current search session and never alter the saved list.
function ac.GetBuyList()
    local entries, seen = {}, {}
    local saved = ac.db and ac.db.buyList
    if type(saved) ~= "table" then return entries end
    for _, entry in ipairs(saved) do
        if type(entry) == "table" then
            local id = integer(entry.itemID, 9999999)
            local quantity = integer(entry.required, 99999)
            if id and quantity and not seen[id] then
                entries[#entries + 1] = {itemID = id, required = quantity}
                seen[id] = true
                if #entries == MAX_ITEMS then break end
            end
        end
    end
    return entries
end

function ac.SaveBuyListItem(itemID, quantity)
    if not ac.db then return nil, "Buy List is unavailable" end
    itemID = integer(itemID, 9999999)
    if not itemID then return nil, "Select a search result first" end
    quantity = integer(quantity, 99999)
    if not quantity then return nil, "Enter a quantity from 1 to 99,999" end

    local entries = ac.GetBuyList()
    for index, entry in ipairs(entries) do
        if entry.itemID == itemID then
            entry.required = quantity
            ac.db.buyList = entries
            return index
        end
    end
    if #entries == MAX_ITEMS then return nil, "Buy List holds up to 60 items" end
    entries[#entries + 1] = {itemID = itemID, required = quantity}
    ac.db.buyList = entries
    return #entries
end

function ac.RemoveBuyListItem(itemID)
    if not ac.db then return end
    local entries = ac.GetBuyList()
    for index, entry in ipairs(entries) do
        if entry.itemID == itemID then
            table.remove(entries, index)
            ac.db.buyList = entries
            return
        end
    end
end

function ac.SearchBuyList()
    if ac.batch then return false, "Finish or stop the current buying queue first" end
    local entries = ac.GetBuyList()
    if #entries == 0 then return false, "Add an item to Buy List first" end
    local ok, reason = ac.SearchItems(entries, "Buy List", true)
    if ok and ac.SetBatchQuantity then ac.SetBatchQuantity(entries[1].required) end
    return ok, reason
end
