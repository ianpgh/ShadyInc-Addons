local _, ac = ...
local AH = C_AuctionHouse
local current, serial, lastSent = nil, 0, 0
local function safe(fn, ...)
    if type(fn) ~= "function" then return nil end
    local ok, value = pcall(fn, ...)
    if ok then return value end
end
local function key(id)
    local made = AH and safe(AH.MakeItemKey, id)
    if type(made) == "table" then return made end
    return {itemID=id, itemLevel=0, itemSuffix=0, battlePetSpeciesID=0}
end
local function normalize(data)
    local result, used = {}, {}
    if type(data) ~= "table" then return nil, "Expected an array of items" end
    for _, entry in ipairs(data) do
        local id = type(entry) == "table" and tonumber(entry.itemID or entry.id) or tonumber(entry)
        if id and id > 0 and id == math.floor(id) and id < 10000000 then
            local required = type(entry) == "table" and tonumber(entry.required or entry.quantity or 1) or 1
            local owned = type(entry) == "table" and tonumber(entry.owned or 0) or 0
            required = math.max(0,math.min(99999,math.floor(required or 1)))
            owned = math.max(0, math.min(99999,math.floor(owned or 0)))
            if used[id] then
                -- Duplicate recipe reagents add requirements, but should not double-count inventory.
                local row = result[used[id]]
                row.required = math.min(99999,row.required+required)
                row.owned = math.max(row.owned,owned)
                if entry.output then row.output = true end
            else
                local row = {itemID=id, name=(type(entry)=="table" and entry.name) or ac.itemName(id),
                    required=required, owned=owned, output=type(entry)=="table" and entry.output == true or false,
                    outputQuantity=type(entry)=="table" and tonumber(entry.outputQuantity) or nil,
                    state="Queued", minUnit=nil, available=nil, source="none"}
                used[id] = #result+1
                result[#result+1] = row
            end
        end
    end
    if #result == 0 then return nil, "No valid item IDs supplied" end
    if #result > 60 then return nil, "Search limited to 60 items per request" end
    for _, row in ipairs(result) do
        row.toBuy = row.output and 0 or math.max(0,row.required-row.owned)
        -- Only missing reagents are preselected; owned reagents remain visible.
        row.acSelected = not row.output and row.toBuy > 0
        row.acBought = 0
    end
    return result
end
local function endSession(status)
    current = nil
    ac.session.mode = "done"
    ac.session.status = status or "Search complete"
    ac.Notify()
end
function ac.Cancel(message)
    if ac.StopNameScan then ac.StopNameScan(message or 'AC search cancelled') end
    if ac.ClearBatch then ac.ClearBatch() end
    serial = serial + 1
    current = nil
    if ac.session.mode == "searching" or ac.session.mode == "browse" then
        ac.session.mode = "idle"
        ac.session.status = message or "Search cancelled"
        ac.Notify()
    end
end
local function queryReady()
    if not AH or type(AH.SendSearchQuery) ~= "function" then return false end
    if type(AH.IsThrottledMessageSystemReady) == "function" and not safe(AH.IsThrottledMessageSystemReady) then return false end
    return true
end
local function nextQuery()
    if not current or current.mode ~= "items" then return end
    if not ac.IsAtAH() then ac.Cancel("Auction House closed"); return end
    if current.active then return end
    if not queryReady() or GetTime()-lastSent < .4 then return end
    local index = current.index
    local row = current.rows[index]
    if not row then endSession(("Search complete: %d items"):format(#current.rows)); return end
    -- Display searches use item IDs when known; unknown IDs use an exact-name
    -- browse query, retaining both items in the AC results list. Live Scan All
    -- uses an entirely separate read-only queue and is not slowed by this path.
    local byName=row.searchByName==true
    local itemKey=not byName and key(row.itemID) or nil
    local started=GetTime()
    current.active={row=row,itemKey=itemKey,sent=started,tries=1,browse=byName,pages=0,
        requestedMore=false,lastCount=-1,lastChange=started,gotEvent=false}
    row.state="Searching..."
    local ok,err
    if byName then
        if not AH or type(AH.SendBrowseQuery)~="function" then
            ok=false;err="Browse search unavailable"
        else
            ok,err=pcall(AH.SendBrowseQuery,{searchString=row.name,sorts={},filters={},itemClassFilters={}})
        end
    else
        ok,err=pcall(AH.SendSearchQuery,itemKey,{},true)
    end
    if not ok then
        row.state="Query failed";row.detail=tostring(err)
        current.active=nil;current.index=index+1
        ac.Notify();return
    end
    lastSent=GetTime()
    ac.session.status=("Searching %d / %d: %s"):format(index,#current.rows,row.name)
    ac.Notify()
end
local function readResults(isCommodity)
    if not current or not current.active then return end
    local active = current.active
    local row = active.row
    local itemID = row.itemID
    local count = isCommodity and safe(AH.GetNumCommoditySearchResults,itemID)
        or safe(AH.GetNumItemSearchResults,active.itemKey)
    if type(count) ~= "number" then return false end
    count = math.max(0, math.min(1000, math.floor(count)))
    local minPrice, amount = nil, 0
    local tiers={}
    local cheapestListing
    local lowestListingBuyout
    for i = 1, count do
        local info = isCommodity and safe(AH.GetCommoditySearchResultInfo,itemID,i)
            or safe(AH.GetItemSearchResultInfo,active.itemKey,i)
        if type(info) == "table" then
            local q = math.max(1, tonumber(info.quantity) or 1)
            local price
            if isCommodity then
                price=tonumber(info.unitPrice)
            else
                -- Item buyoutAmount is the price for the listing, not a
                -- guaranteed per-item price. Single-stack crafts (bags, gear)
                -- are always valued at the complete buyout, even if this
                -- Forever client reports an anomalous quantity.
                price,q=ac.UnitFromListing(itemID,info.buyoutAmount,q)
                -- Recipe outputs are valued as a complete purchasable listing
                -- when the item's max stack size has not loaded yet.
                if row.output and not ac.MaxStack(itemID) then
                    price=tonumber(info.buyoutAmount)
                    q=1
                end
            end
            if price and price > 0 then
                if not minPrice or price < minPrice then minPrice = price end
                if #tiers < 30 then
                    -- Snapshot price levels for display, never for an unconfirmed purchase.
                    tiers[#tiers+1]={unitPrice=math.floor(price+.5), quantity=q}
                end
                if not isCommodity then
                    local buyout=tonumber(info.buyoutAmount)
                    local auctionID=tonumber(info.auctionID)
                    if buyout and buyout>0 and (not lowestListingBuyout or buyout<lowestListingBuyout) then
                        lowestListingBuyout=buyout
                    end
                    if auctionID and buyout and buyout>0 and
                        (not cheapestListing or buyout < cheapestListing.buyout) then
                        cheapestListing={auctionID=auctionID,buyout=buyout,quantity=q}
                    end
                end
            end
            amount = amount + q
        end
    end
    row.source = isCommodity and "commodity" or "item"
    row.minUnit = minPrice
    row.minListing = lowestListingBuyout
    row.available = amount
    row.tiers=tiers
    row.itemKey=active.itemKey
    row.cheapestListing=cheapestListing
    row.observedAt = minPrice and (type(time)=="function" and time() or 0) or nil
    local isFull = isCommodity and safe(AH.HasFullCommoditySearchResults,itemID)
        or safe(AH.HasFullItemSearchResults,active.itemKey)
    -- A zero-row event is *not* proof of an empty market; keep it distinguishable.
    row.state = minPrice and (isFull == false and "Partial" or "Ready") or (count == 0 and "No listings" or "No buyout")
    if ac.PublishPrice then ac.PublishPrice(row) end
    if not row.output and type(ac.api.GetMaterialCost)=='function' then
        local _,source,_,ah,vendor=ac.api.GetMaterialCost(itemID)
        if source=='vendor' and vendor and (not ah or vendor<ah) then
            row.vendorPreferred=true
            -- The AH offer is still visible and purchasable manually, but do
            -- not silently queue above-vendor AH orders as a default.
            row.acSelected=false
        else
            row.vendorPreferred=false
        end
    end
    current.active = nil
    current.index = current.index + 1
    ac.Notify()
    return true
end

-- Exact-name result handling for Writ This's interactive "Search Both".
-- It never borrows cached prices from the Live Scan All catalogue.
local function nameKey(name)
    if type(name)~="string" then return "" end
    return name:gsub("|c%x%x%x%x%x%x%x%x",""):gsub("|r","")
        :gsub("’","'"):gsub("`","'"):match("^%s*(.-)%s*$"):lower()
end
local function ownedFor(id)
    if not id or type(GetItemCount)~='function' then return 0 end
    local amount=safe(GetItemCount,id,false,false)
    return math.max(0,math.min(99999,math.floor(tonumber(amount) or 0)))
end
local function finishBrowseRow(full)
    local a=current and current.active
    if not a or not a.browse then return end
    local r=a.row
    -- Interactive Writ shopping MUST resolve names to item IDs and then
    -- query live item listings before any Buy/Buy All control can be used.
    -- A browse price is never itself a purchasable quote.
    if r.shopping and r.matchIDs and r.matchIDs > 1 then
        r.state='Ambiguous name - verify item manually'
        r.minUnit=nil
        r.source='none'
        current.active=nil
        current.index=current.index+1
        ac.Notify()
        return
    end
    if r.shopping and r.itemID then
        r.searchByName=false
        r.browseWasPartial=full~=true
        r.owned=ownedFor(r.itemID)
        r.toBuy=math.max(0,r.required-r.owned)
        r.acSelected=r.toBuy>0
        r.minUnit=nil
        r.available=nil
        r.source='none'
        r.state='ID found; checking live listings...'
        current.active=nil -- Next poll reuses the SAME queue row with its ID.
        ac.Notify()
        return
    end
    r.source="browse"
    r.state=r.minUnit and (full==true and "Ready" or "Partial") or
        (full==true and "No listings" or "Unverified")
    r.observedAt=r.minUnit and (type(time)=="function" and time() or nil) or nil
    -- Publish only complete, exact-name matches. The user still has to
    -- select a row to inspect purchasable listings in AC.
    if r.state=="Ready" and r.itemID and ac.PublishPrice then
        ac.PublishPrice({itemID=r.itemID,minUnit=r.minUnit,minListing=r.minUnit,
            state="Ready",observedAt=r.observedAt})
    end
    current.active=nil
    current.index=current.index+1
    ac.Notify()
end
local function readNamedBrowse()
    local a=current and current.active
    if not a or not a.browse then return end
    local results=safe(AH.GetBrowseResults)
    if type(results)~="table" then return end
    local r=a.row
    local wanted=nameKey(r.name)
    for _,info in ipairs(results) do
        local item=type(info)=="table" and info.itemKey
        local id=item and tonumber(item.itemID)
        if id and id>0 then
            local n=info.itemKeyInfo and info.itemKeyInfo.itemName
            if not n and type(GetItemInfo)=="function" then n=safe(GetItemInfo,id) end
            if not n and AH and type(AH.GetItemKeyInfo)=="function" then
                local details=safe(AH.GetItemKeyInfo,item)
                n=type(details)=="table" and details.itemName or nil
            end
            if nameKey(n)==wanted then
                if r.shopping then
                    r.matchIDSet=r.matchIDSet or {}
                    if not r.matchIDSet[id] then
                        r.matchIDSet[id]=true
                        r.matchIDs=(r.matchIDs or 0)+1
                    end
                end
                local price=tonumber(info.minPrice)
                local qty=tonumber(info.totalQuantity)
                -- An item can be identified by exact name even if its
                -- browse summary has no buyout; direct search decides buyability.
                if r.shopping and r.matchIDs==1 then r.itemID=id end
                if price and price>0 and (not qty or qty>0) and
                    (not r.minUnit or price<r.minUnit) then
                    r.minUnit=price;r.itemID=id;r.available=qty
                end
            end
        end
    end
    local full=safe(AH.HasFullBrowseResults)
    if full==true then finishBrowseRow(true);return end
    if #results~=a.lastCount then
        a.lastCount=#results;a.lastChange=GetTime();a.requestedMore=false
    end
    if full==false and #results>0 and not a.requestedMore and a.pages<35 and
        type(AH.RequestMoreBrowseResults)=="function" and queryReady() and
        GetTime()-lastSent>=.4 then
        local ok=pcall(AH.RequestMoreBrowseResults)
        if ok then
            a.requestedMore=true;a.pages=a.pages+1;lastSent=GetTime()
        end
    end
    -- Some Forever clients never provide a full-results flag. Rather than
    -- claim complete prices, display an exact match as Partial after a short
    -- quiet period; an empty response remains unverified until timeout.
    if full==nil and r.minUnit and GetTime()-a.lastChange>=1.5 then
        finishBrowseRow(false)
    end
end
local function searchNames(items,label,shopping)
    if ac.IsNameScanBusy and ac.IsNameScanBusy() then
        return false,'Finish AC Live Scan All first; it is not interrupted.'
    end
    if not ac.IsAtAH() then return false,"Open the Auction House first" end
    if not AH or type(AH.SendBrowseQuery)~="function" or type(AH.SendSearchQuery)~="function" then
        return false,"This client does not support AC auction searches"
    end
    if type(items)~="table" then return false,"Invalid items" end
    local rows,used={},{}
    for _,entry in ipairs(items) do
        local name=type(entry)=="table" and entry.name or entry
        local nk=nameKey(name)
        if #nk>=2 and not used[nk] then
            used[nk]=true
            local id=type(entry)=="table" and tonumber(entry.itemID) or nil
            if id and (id<1 or id>9999999 or id~=math.floor(id)) then id=nil end
            -- Reject known ID/name mismatches instead of displaying a different
            -- item under the requested label. No guessed IDs are generated.
            if id and type(GetItemInfo)=="function" then
                local resolved=safe(GetItemInfo,id)
                if resolved and nameKey(resolved)~=nk then id=nil end
            end
            local required=shopping and tonumber(type(entry)=='table' and entry.required) or 0
            required=math.max(0,math.min(99999,math.floor(required or 0)))
            -- An externally supplied owned count could be stale. Query bags
            -- here and recheck when a name-only row resolves to an item ID.
            local owned=shopping and ownedFor(id) or 0
            local toBuy=math.max(0,required-owned)
            rows[#rows+1]={name=name,itemID=id,searchByName=not id,
                required=required,owned=owned,toBuy=toBuy,
                acSelected=shopping and toBuy>0 or false,acBought=0,
                output=false,role=shopping and type(entry)=='table' and entry.role or nil,
                shopping=shopping==true,
                minUnit=nil,available=nil,source="none",state="Queued"}
        end
        if #rows>60 then return false,"Limit 60 distinct names per search" end
    end
    if #rows==0 then return false,"No valid item names" end
    ac.Cancel("New display search")
    ac.session={rows=rows,label=tostring(label or "Named item search"),mode="searching",
        shopping=shopping==true,selected=shopping and 1 or nil,
        status=("Queued %d %s"):format(#rows,shopping and "shopping items" or "named items")}
    serial=serial+1
    current={mode="items",rows=rows,index=1,token=serial}
    ac.Notify()
    if not ac.Open or not ac.Open() then
        current=nil;ac.session.mode="idle";ac.Status("AC tab could not be opened")
        return false,"AC tab could not be opened"
    end
    -- Reset any previously entered profession shopping quantity so starting
    -- a Writ search can never inherit e.g. a 20-reagent quantity.
    if shopping and ac.SetBatchQuantity then ac.SetBatchQuantity(1) end
    nextQuery()
    if shopping then
        -- Some Forever AH builds switch back to the Blizzard Buy/Browse pane
        -- as soon as SendSearchQuery/SendBrowseQuery is dispatched. Open AC
        -- AFTER the request, not just before it. This applies only to
        -- interactive shopping; Live Scan All never opens an AH window.
        if ac.Open then ac.Open() end
        -- One delayed, guarded correction for client-side tab transitions.
        -- Never repeatedly steal tab focus if the player navigates away.
        if C_Timer and type(C_Timer.After)=="function" then
            local launchSerial=serial
            C_Timer.After(.2,function()
                if serial~=launchSerial or not ac.session or
                    ac.session.shopping~=true then return end
                if ac.window and not ac.window:IsShown() and ac.IsAtAH() and ac.Open then
                    ac.Open()
                end
            end)
        end
    end
    return true
end
function ac.SearchNamesForDisplay(items,label)
    return searchNames(items,label,false)
end
-- Profession AIO's same native Buy/Buy All interface, but supports writs
-- whose item IDs still need to be resolved with an exact-name browse search.
function ac.SearchShoppingItems(items,label)
    return searchNames(items,label,true)
end

function ac.SearchItems(items, label)
    if ac.IsNameScanBusy and ac.IsNameScanBusy() then return false,'Finish or cancel AC Live Scan All first' end
    if not ac.IsAtAH() then return false, "Open the Auction House first" end
    if not AH or type(AH.SendSearchQuery) ~= "function" then return false, "Modern auction API unavailable" end
    local rows, err = normalize(items)
    if not rows then return false, err end
    ac.Cancel("New search")
    ac.session = {rows=rows, label=tostring(label or "Item search"), mode="searching",
        selected=1, status=("Queued %d items"):format(#rows)}
    serial = serial+1
    current={mode="items",rows=rows,index=1,token=serial}
    ac.Notify()
    if ac.Open then ac.Open() end
    nextQuery()
    return true
end

-- Text search uses the retail/Forever browse query and only reads the first returned page.
-- This is intentionally not an all-item/"full" scan.
function ac.SearchText(phrase)
    if ac.IsNameScanBusy and ac.IsNameScanBusy() then return false,'Finish or cancel AC Live Scan All first' end
    if not ac.IsAtAH() then return false, "Open the Auction House first" end
    if not AH or type(AH.SendBrowseQuery) ~= "function" then return false, "Browse API unavailable" end
    phrase = type(phrase)=="string" and phrase:match("^%s*(.-)%s*$") or ""
    if #phrase < 2 then return false, "Enter at least two characters" end
    if #phrase > 80 then return false, "Search text is too long" end
    ac.Cancel("New search")
    ac.session = {rows={}, mode="browse", label=phrase, selected=nil, status="Waiting for auction search..."}
    current = {mode="browse",phrase=phrase,started=GetTime(),sent=false,token=serial}
    ac.Notify()
    if ac.Open then ac.Open() end
    return true
end
local function readBrowse()
    if not current or current.mode ~= "browse" or not current.sent then return end
    local results = safe(AH.GetBrowseResults)
    if type(results) ~= "table" then return end
    local rows = {}
    for _, info in ipairs(results) do
        local item = info.itemKey
        local id = item and tonumber(item.itemID)
        if id and id > 0 then
            rows[#rows+1] = {itemID=id, name=(info.itemKeyInfo and info.itemKeyInfo.itemName) or ac.itemName(id),
                required=0, owned=0, toBuy=0, output=false, state="Browse",source="browse",
                minUnit=tonumber(info.minPrice),available=tonumber(info.totalQuantity)}
        end
        if #rows >= 60 then break end
    end
    ac.session.rows=rows
    ac.session.mode="done"
    ac.session.status=("Browse results: %d rows (first page)"):format(#rows)
    current=nil
    ac.Notify()
end
function ac.SearchOne(itemID, quantity)
    itemID = tonumber(itemID)
    if not itemID then return false,"Invalid item ID" end
    return ac.SearchItems({{itemID=itemID, required=quantity or 1}},ac.itemName(itemID))
end

function ac.SearchRecipe(recipeID, count)
    if not C_TradeSkillUI or type(C_TradeSkillUI.GetRecipeSchematic) ~= "function" then return false,"Profession API unavailable" end
    recipeID=tonumber(recipeID)
    if not recipeID then return false,"Select a recipe first" end
    local ok, schematic=pcall(C_TradeSkillUI.GetRecipeSchematic, recipeID, false)
    if not ok or type(schematic)~="table" then return false,"Recipe data unavailable" end
    local info = safe(C_TradeSkillUI.GetRecipeInfo, recipeID)
    count = math.max(1,math.min(999,math.floor(tonumber(count) or 1)))
    local items={}
    local outputID=tonumber(schematic.outputItemID)
    if outputID then
        items[#items+1]={itemID=outputID,required=0,owned=0,output=true,
            outputQuantity=tonumber(schematic.quantityMin) or 1,
            name=(info and info.name) or ac.itemName(outputID)}
    end
    local slots=schematic.reagentSlotSchematics
    if type(slots)=="table" then
        for _, slot in ipairs(slots) do
            local reagents=slot and slot.reagents
            local reagent=type(reagents)=="table" and #reagents==1 and reagents[1]
            local id=reagent and tonumber(reagent.itemID)
            local quantity=slot and tonumber(slot.quantityRequired)
            if id and quantity and quantity > 0 then
                local owned = safe(GetItemCount,id,false,false) or 0
                items[#items+1]={itemID=id,required=quantity*count,owned=owned}
            elseif reagents and #reagents > 1 then
                return false,"Recipe has optional reagent choices; choose ingredients in the profession window first"
            end
        end
    end
    if #items==0 then return false,"No auctionable output or reagents found" end
    return ac.SearchItems(items, ((info and info.name) or "Recipe") .. " x" .. count)
end

local ticker
local function poll()
    if not current then
        if ticker then ticker:Cancel(); ticker=nil end
        return
    end
    if not ac.IsAtAH() then
        if current then ac.Cancel("Auction House closed") end
        return
    end
    if not current then return end
    if current.mode=="browse" then
        if not current.sent and queryReady() and GetTime()-lastSent >= .4 then
            local ok,err=pcall(AH.SendBrowseQuery,{searchString=current.phrase,sorts={},filters={},itemClassFilters={}})
            if ok then current.sent=true; current.started=GetTime(); lastSent=GetTime(); ac.Status("Searching: "..current.phrase)
            else endSession("Browse query failed: "..tostring(err)) end
        elseif current.sent and GetTime()-current.started > 10 then endSession("Browse timed out (results not confirmed)") end
    elseif current.mode=="items" then
        if not current.active then nextQuery(); return end
        local active=current.active
        if GetTime()-active.sent > (active.browse and 12 or 10) then
            if active.browse then finishBrowseRow(false)
            else
                active.row.state="Timed out"
                current.active=nil
                current.index=current.index+1
                ac.Notify()
            end
        elseif active.browse and active.gotEvent then
            -- Wait for the AH's new-result event; do not use older browse results.
            readNamedBrowse()
        end
    end
end
local function ensurePoll()
    if not ticker and C_Timer and C_Timer.NewTicker then ticker = C_Timer.NewTicker(.2,poll) end
end
local previousSearchItems=ac.SearchItems
ac.SearchItems=function(...)
    local ok,err=previousSearchItems(...)
    if ok then ensurePoll() end
    return ok,err
end
local previousSearchText=ac.SearchText
ac.SearchText=function(...)
    local ok,err=previousSearchText(...)
    if ok then ensurePoll() end
    return ok,err
end
local previousSearchNamesForDisplay=ac.SearchNamesForDisplay
ac.SearchNamesForDisplay=function(...)
    local ok,err=previousSearchNamesForDisplay(...)
    if ok then ensurePoll() end
    return ok,err
end
local previousSearchShoppingItems=ac.SearchShoppingItems
ac.SearchShoppingItems=function(...)
    local ok,err=previousSearchShoppingItems(...)
    if ok then ensurePoll() end
    return ok,err
end
local events=CreateFrame("Frame")
for _,event in ipairs({"COMMODITY_SEARCH_RESULTS_UPDATED","COMMODITY_SEARCH_RESULTS_ADDED",
    "ITEM_SEARCH_RESULTS_UPDATED","ITEM_SEARCH_RESULTS_ADDED","AUCTION_HOUSE_BROWSE_RESULTS_UPDATED",
    "AUCTION_HOUSE_BROWSE_RESULTS_ADDED",
    "AUCTION_HOUSE_THROTTLED_SYSTEM_READY"}) do
    pcall(events.RegisterEvent,events,event)
end
events:SetScript("OnEvent",function(self,event,arg,extra)
    if not current then return end
    if event=="AUCTION_HOUSE_BROWSE_RESULTS_UPDATED" or event=="AUCTION_HOUSE_BROWSE_RESULTS_ADDED" then
        if current.mode=="browse" then readBrowse()
        elseif current.mode=="items" and current.active and current.active.browse then
            current.active.gotEvent=true
            readNamedBrowse() end
        return
    end
    if current.mode~="items" or not current.active then return end
    local id=current.active.row.itemID
    if (event=="COMMODITY_SEARCH_RESULTS_UPDATED" or event=="COMMODITY_SEARCH_RESULTS_ADDED")
        and tonumber(arg)==id then readResults(true)
    elseif (event=="ITEM_SEARCH_RESULTS_UPDATED" or event=="ITEM_SEARCH_RESULTS_ADDED")
        and type(arg)=="table" and tonumber(arg.itemID)==id then readResults(false) end
end)

-- Read-only integration contract: callers receive copies, not the mutable search queue.
local function copyRows()
    local copy={}
    for i,row in ipairs(ac.session.rows or {}) do
        copy[i]={itemID=row.itemID, name=row.name, required=row.required, owned=row.owned,
            toBuy=row.toBuy, output=row.output, outputQuantity=row.outputQuantity, minUnit=row.minUnit, available=row.available,
            source=row.source, state=row.state, observedAt=row.observedAt,
            selected=row.acSelected == true, purchasedInSession=row.acBought or 0}
    end
    return copy
end
ac.api.GetResults=copyRows
ac.api.GetObservedPrice=function(id)
    for _,row in ipairs(ac.session.rows or {}) do
        if row.itemID == tonumber(id) and row.minUnit then
            return row.minUnit,row.state,row.observedAt
        end
    end
end
local subscriptions={}
ac.api.Subscribe=function(callback)
    if type(callback)~="function" then return false end
    if subscriptions[callback] then return true end
    local wrapped=function()
        callback(copyRows(),ac.session.status,ac.session.mode)
    end
    subscriptions[callback]=wrapped
    ac.Subscribe(wrapped)
    return true
end
ac.api.Unsubscribe=function(callback)
    local wrapped=subscriptions[callback]
    if not wrapped then return false end
    ac.listeners[wrapped]=nil
    subscriptions[callback]=nil
    return true
end

ac.api.SearchRecipe=function(recipeID,qty) return ac.SearchRecipe(recipeID,qty) end
ac.api.SearchItems=function(items,label) return ac.SearchItems(items,label) end
ac.api.SearchNamesForDisplay=function(items,label) return ac.SearchNamesForDisplay(items,label) end
ac.api.SearchShoppingItems=function(items,label) return ac.SearchShoppingItems(items,label) end
ac.api.SearchItem=function(id,qty) return ac.SearchOne(id,qty) end
ac.api.SearchText=function(text) return ac.SearchText(text) end
ac.api.Cancel=function() return ac.Cancel() end
ac.api.GetStatus=function() return ac.session.status end
ac.api.IsAvailable=function() return ac.IsAtAH() end
