local _, ac = ...
-- Safe, short-lived reagent checklist and guided purchase queue.
-- Each AH order needs a fresh, user-initiated click and Blizzard confirmation.
-- No automatic Next/Buy/Confirm calls are made in event handlers.

local function remaining(row)
    if not row then return 0 end
    return math.max(0,(tonumber(row.toBuy) or 0)-(tonumber(row.acBought) or 0))
end

function ac.BatchRemaining(row)
    return remaining(row)
end

function ac.BatchCount()
    local count=0
    for _,row in ipairs(ac.session.rows or {}) do
        if row.acSelected and not row.output and remaining(row)>0 then count=count+1 end
    end
    return count
end

function ac.ClearBatch()
    ac.batch=nil
    -- Intentionally retain per-row session purchases, never persist to Auction Peek.
    if ac.Notify then ac.Notify() end
end

function ac.BatchSelectAll()
    if ac.batch and ac.batch.waiting then return false,"Confirm or cancel the current purchase first" end
    ac.batch=nil
    local count=0
    for _,row in ipairs(ac.session.rows or {}) do
        row.acSelected = not row.output and remaining(row)>0
        if row.acSelected then count=count+1 end
    end
    ac.Notify()
    return count>0,count
end

function ac.BatchToggle(row)
    if not row or row.output or remaining(row)<=0 then return false,"No missing reagent to select" end
    if ac.batch then return false,"Stop the buying queue before changing selections" end
    row.acSelected=not row.acSelected
    ac.Notify()
    return true
end

local function nextPending(batch)
    for i, entry in ipairs(batch.entries) do
        if remaining(entry.row)>0 then return i,entry.row end
    end
end

function ac.BatchBeginOrNext()
    if not ac.IsAtAH() then return false,"Open the Auction House first" end
    if ac.session.mode~="done" then return false,"Wait until the recipe search is complete" end
    if not ac.batch then
        local entries={}
        for _,row in ipairs(ac.session.rows or {}) do
            if row.acSelected and not row.output and remaining(row)>0 then
                entries[#entries+1]={row=row}
            end
        end
        if #entries==0 then return false,"Select missing reagents first" end
        ac.batch={entries=entries,waiting=false}
    end
    local batch=ac.batch
    if batch.waiting then return false,"Finish Blizzard's purchase confirmation first" end
    local index,row=nextPending(batch)
    if not row then
        ac.batch=nil
        ac.Status("Reagent queue complete. Check your mail for purchased items.")
        return true
    end
    ac.session.selected=nil
    for i,entry in ipairs(ac.session.rows) do
        if entry==row then ac.session.selected=i;break end
    end
    local qty=remaining(row)
    -- Keep the in-tab quantity preview aligned with the pending live order.
    ac.Notify()
    if ac.SetBatchQuantity then ac.SetBatchQuantity(qty) end
    local ok,quoteOrError=ac.Buy(row,qty)
    if not ok then
        ac.Status("Couldn't start "..tostring(row.name or ac.itemName(row.itemID))..": "..tostring(quoteOrError))
        return false,quoteOrError
    end
    batch.waiting=true
    batch.pendingRow=row
    batch.pendingQuote=quoteOrError
    batch.pendingIndex=index
    ac.Status("Step "..index.."/"..#batch.entries..": Confirm "..tostring(row.name or ac.itemName(row.itemID)).." with Blizzard.")
    return true
end

function ac.HandleBatchEvent(event,...)
    local batch=ac.batch
    if not batch or not batch.waiting then return false end
    if event=="COMMODITY_PURCHASE_FAILED" then
        if not(batch.pendingQuote and batch.pendingQuote.type=="commodity") then return false end
        batch.waiting=false
        batch.pendingRow=nil
        batch.pendingQuote=nil
        ac.Status("Purchase failed. Press Buy Next to retry or Stop to cancel.")
        return true
    end
    local quote=batch.pendingQuote
    if not quote then return false end
    if event=="COMMODITY_PURCHASE_SUCCEEDED" and quote.type~="commodity" then return false end
    if event=="ITEM_PURCHASED" and quote.type~="item" then return false end
    if event~="COMMODITY_PURCHASE_SUCCEEDED" and event~="ITEM_PURCHASED" then return false end
    -- If this client provides an item/auction identifier with the event, reject a mismatched one.
    -- Other clients provide no usable identity, in which case only an outstanding order is eligible.
    local eventID=tonumber((...))
    if eventID and batch.pendingRow and batch.pendingRow.itemID and
        eventID~=batch.pendingRow.itemID and eventID~=tonumber(quote.auctionID) then
        return false
    end
    local row=batch.pendingRow
    row.acBought=math.min(tonumber(row.toBuy) or 0,(row.acBought or 0)+(quote.quantity or 1))
    if remaining(row)<=0 then row.acSelected=false end
    batch.waiting=false
    batch.pendingRow=nil
    batch.pendingQuote=nil
    local index,nextRow=nextPending(batch)
    if nextRow then
        ac.Status("Bought "..tostring(row.name)..". Next: "..tostring(nextRow.name)..". Press Buy Next to continue.")
    else
        ac.batch=nil
        ac.Status("Selected reagents purchased. Check mail for delivery.")
    end
    return true
end

ac.api.GetBatchStatus=function()
    local batch=ac.batch
    return {active=batch~=nil,waiting=batch and batch.waiting or false,remaining=ac.BatchCount()}
end
