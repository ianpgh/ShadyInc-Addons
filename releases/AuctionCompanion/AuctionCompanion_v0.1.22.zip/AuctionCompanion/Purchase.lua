local _, ac = ...
-- All transactions are initiated by a human pressing AC's Buy button.
-- Blizzard retains its own price/auction confirmation and handles the purchase.
-- No simulated clicks, automatic confirmations, or reparented protected frames.
local AH = C_AuctionHouse

local function get(fn, ...)
    if type(fn) ~= "function" then return nil end
    local ok, result = pcall(fn, ...)
    if ok then return result end
end

local function requested(amount)
    local n=tonumber(amount)
    if not n or n~=n or n<1 or n>99999 then return nil end
    return math.floor(n)
end

local function findCommodityQuote(id, qty)
    if type(AH.GetNumCommoditySearchResults)~="function" or
        type(AH.GetCommoditySearchResultInfo)~="function" then
        return nil, "Commodity buying isn't supported by this client"
    end
    local count=get(AH.GetNumCommoditySearchResults,id)
    if type(count)~="number" or count<1 then
        return nil, "Listings unavailable. Run the search again."
    end
    local levels={}
    for i=1, math.min(1000,count) do
        local t=get(AH.GetCommoditySearchResultInfo,id,i)
        if type(t)=="table" then
            local price=tonumber(t.unitPrice)
            local available=tonumber(t.quantity)
            if price and price>0 and available and available>0 then
                levels[#levels+1]={unit=price,amount=math.floor(available)}
            end
        end
    end
    table.sort(levels,function(a,b)return a.unit<b.unit end)
    local total, need=0,qty
    for _, level in ipairs(levels) do
        local amount=math.min(need,level.amount)
        total=total+amount*level.unit
        need=need-amount
        if need==0 then break end
    end
    if need>0 then return nil,"Not enough current listings. Search again." end
    if #levels==0 then return nil,"No purchasable listings available" end
    return {unit=levels[1].unit,total=total,quantity=qty,type="commodity"}
end

local function findItemQuote(row)
    local key=row.itemKey
    if type(key)~="table" or tonumber(key.itemID)~=tonumber(row.itemID) then
        if type(AH.MakeItemKey)=="function" then key=get(AH.MakeItemKey,row.itemID) end
    end
    if type(key)~="table" or type(AH.GetNumItemSearchResults)~="function" or
        type(AH.GetItemSearchResultInfo)~="function" then
        return nil,"Auction details unavailable. Run the search again."
    end
    local count=get(AH.GetNumItemSearchResults,key)
    if type(count)~="number" or count<1 then return nil,"No current buyout listings. Search again." end
    local best
    for i=1,math.min(1000,count) do
        local item=get(AH.GetItemSearchResultInfo,key,i)
        if type(item)=="table" then
            local auctionID=tonumber(item.auctionID)
            local buyout=tonumber(item.buyoutAmount)
            local stack=math.max(1,math.floor(tonumber(item.quantity) or 1))
            if auctionID and auctionID>0 and buyout and buyout>0 and
                (not best or buyout<best.total) then
                best={auctionID=auctionID,total=buyout,unit=buyout/stack,quantity=stack,type="item"}
            end
        end
    end
    if not best then return nil,"No current buyout listings. Search again." end
    return best
end

-- Returns a fresh quote from game results; never use saved/cached prices to submit a purchase.
function ac.GetLiveQuote(row, qty)
    if not row or not tonumber(row.itemID) or row.source=="browse" then
        return nil,"Select a searched item to buy"
    end
    if not AH then return nil,"Auction House API unavailable" end
    if row.source=="commodity" then
        qty=requested(qty)
        if not qty then return nil,"Enter a valid quantity" end
        return findCommodityQuote(row.itemID,qty)
    elseif row.source=="item" then
        return findItemQuote(row)
    end
    return nil,"Wait until the item search is complete"
end

function ac.Buy(row, qty)
    if not ac.IsAtAH() then return false,"Open the Auction House first" end
    if ac.session.mode~="done" then return false,"Wait for the search to finish" end
    if type(InCombatLockdown)=="function" and InCombatLockdown() then
        return false,"Buying is unavailable during combat"
    end
    local quote,err=ac.GetLiveQuote(row,qty)
    if not quote then return false,err end
    local frame=AuctionHouseFrame
    if not frame then return false,"Auction House is unavailable" end
    if type(GetMoney)=="function" and GetMoney()<quote.total then
        return false,"Not enough gold for "..ac.money(quote.total)
    end
    if quote.type=="commodity" then
        -- Blizzard shows its in-frame BuyDialog, requotes prices, and controls confirmation.
        if type(frame.StartCommoditiesPurchase)~="function" or not frame.BuyDialog then
            return false,"Blizzard's buying dialog is unavailable"
        end
        local ok, reason=pcall(frame.StartCommoditiesPurchase, frame,
            row.itemID, quote.quantity, quote.unit, quote.total)
        if not ok then return false,"Blizzard rejected Buy: "..tostring(reason) end
        ac.Status("Confirm "..quote.quantity.." x "..(row.name or ac.itemName(row.itemID))..
            " in Blizzard's buying dialog.")
    else
        -- A single non-commodity listing has a fixed stack size and a fixed buyout.
        -- Calling Blizzard's StartItemBuyout opens its standard confirmation popup.
        if type(frame.StartItemBuyout)~="function" then
            return false,"Blizzard's item buyout dialog is unavailable"
        end
        local ok, reason=pcall(frame.StartItemBuyout, frame,quote.auctionID,quote.total)
        if not ok then return false,"Blizzard rejected Buy: "..tostring(reason) end
        ac.Status("Confirm listing ("..quote.quantity.." items) for "..
            ac.money(quote.total).." in Blizzard's buying dialog.")
    end
    return true,quote
end

local events=CreateFrame("Frame")
for _,name in ipairs({"COMMODITY_PURCHASE_SUCCEEDED","ITEM_PURCHASED",
    "COMMODITY_PURCHASE_FAILED"}) do
    pcall(events.RegisterEvent,events,name)
end
events:SetScript("OnEvent",function(self,event,...)
    if ac.HandleBatchEvent and ac.HandleBatchEvent(event,...) then return end
    if ac.IsAtAH() and (event=="COMMODITY_PURCHASE_SUCCEEDED" or event=="ITEM_PURCHASED") then
        ac.Status("Purchase reported by Blizzard. Re-search to update prices and quantities.")
    end
end)
