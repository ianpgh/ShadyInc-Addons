-- Buff Hero 1.6.1 - WoW Forever (Interface 16001)
-- A small, standalone reminder addon. It never uses items automatically.
local ADDON = ...
local VERSION = "1.6.3"
local M = {}
local DB, settings, selected = nil, nil, 1
local preview, offset, nextTick = false, 0, 0
local anchors, listButtons, edits = {}, {}, {}
local picker, pickerItems, pickerButtons, pickerOffset, pickerQuery = nil, {}, {}, 0, ""
local refreshEditor, refreshButtons, refreshList
local toggleSettings -- also used by the minimap launcher
local reminderPage, extraPage, selectedTab = nil, nil, "reminders"
local flashPhase = 0
local flashDemoEnabled = false
local FLASH_SPEEDS = {"slow", "normal", "fast"}
local FLASH_HZ = {slow=0.65, normal=1.05, fast=1.65}
local FLASH_STYLES = {"pulse", "attention"}
local TRANSLUCENT_ALPHA = 0.65


local unpack = unpack or table.unpack
local MAINHAND = INVSLOT_MAINHAND or 16
local OFFHAND = INVSLOT_OFFHAND or 17
local RANGED = INVSLOT_RANGED or 18
local EQUIPEd = {"any", "fishing", "nonfishing", "exact"}
local EQUIP_LABEL = {any="Any equipped item", fishing="Fishing pole only", nonfishing="Normal weapon only", exact="Exact equipped item"}
local SLOT_LABEL = {[MAINHAND]="Main hand", [OFFHAND]="Off hand", [RANGED]="Ranged"}
local TYPE_LABEL = {food="Food / item buff", weapon="Weapon oil / lure", spell="Spell buff"}
local fallbackIcon = {food="Interface\\Icons\\INV_Misc_Food_15", weapon="Interface\\Icons\\INV_Misc_QuestionMark", spell="Interface\\Icons\\Spell_Holy_WordFortitude"}
local CHAT = "|cffffd37bBuff Hero|r: "
local SNOOZE_CHOICES = {5, 10, 15, 20, 25, 30, -1, 0}
local function snoozeLabel(value)
    if value == -1 then return "Permanent" end
    if value == 0 then return "Disabled" end
    return tostring(value or 5) .. " min"
end
local function now()
    if GetServerTime then return GetServerTime() end
    return time()
end
-- True only in designated rest areas (inns and cities), not when the
-- character merely has stored rested XP. Never assume resting on API failure.
local function isRestingArea()
    if type(IsResting) ~= "function" then return false end
    local ok, resting = pcall(IsResting)
    return ok and (not issecretvalue or not issecretvalue(resting)) and resting == true
end
local function isSnoozed(r)
    if r.snoozePermanent then return true end
    if type(r.snoozedUntil) == "number" then
        if r.snoozedUntil > now() then return true end
        r.snoozedUntil = nil
    end
    return false
end
local function clearSnooze(r)
    if not r then return end
    r.snoozePermanent, r.snoozedUntil = nil, nil
end

local function msg(t) print(CHAT .. t) end
local function locked() return InCombatLockdown and InCombatLockdown() end
local function isReadable(v)
    if issecretvalue and issecretvalue(v) then return false end
    return v ~= nil
end
local function clamp(v, low, high)
    v = tonumber(v) or low
    return math.max(low, math.min(high, v))
end
-- Dungeon detection uses actual instance type; arenas/BGs never count.
local function shouldFlashHere()
    if not DB or not DB.flashInDungeons or type(IsInInstance) ~= "function" then return false end
    local ok, inside, kind = pcall(IsInInstance)
    if not ok or not isReadable(inside) or not isReadable(kind) or not inside then return false end
    return kind == "party" or (DB.flashInRaids and kind == "raid")
end
local function setFlashActive(f, active)
    f.flashActive = active == true
    if not f.flashActive and f.flashGlow then
        f.flashGlow:SetAlpha(0)
        f.flashWash:SetAlpha(0)
    end
end
local function flashAlpha()
    local pulse = (math.sin(flashPhase) + 1) / 2
    if DB and DB.flashStyle == "attention" then
        -- More noticeable, but never completely obscures the action icon.
        pulse = pulse * pulse * pulse
    end
    return pulse
end
local function animateFlash(elapsed)
    if not DB then return end
    flashPhase = (flashPhase + elapsed * (2 * math.pi) * (FLASH_HZ[DB.flashSpeed] or FLASH_HZ.normal)) % (2 * math.pi)
    local intensity = flashAlpha()
    for _, f in pairs(anchors) do
        if f.flashActive and f.flashGlow then
            f.flashGlow:SetAlpha(0.12 + intensity * 0.88)
            f.flashWash:SetAlpha((DB.flashStyle == "attention" and 0.38 or 0.18) * intensity)
        end
    end
    if M.flashDemoGlow then
        M.flashDemoGlow:SetAlpha(flashDemoEnabled and (0.12 + intensity * 0.88) or 0)
        M.flashDemoWash:SetAlpha(flashDemoEnabled and ((DB.flashStyle == "attention" and 0.38 or 0.18) * intensity) or 0)
    end
end

local function itemIcon(id)
    id = tonumber(id)
    if not id or id < 1 then return nil end
    if C_Item and C_Item.GetItemIconByID then
        local ok, icon = pcall(C_Item.GetItemIconByID, id)
        if ok and icon then return icon end
    end
    if GetItemIcon then return GetItemIcon(id) end
end
local function itemName(id)
    id = tonumber(id)
    if not id or id < 1 then return nil end
    if C_Item and C_Item.GetItemNameByID then
        local ok, n = pcall(C_Item.GetItemNameByID, id)
        if ok and n then return n end
    end
    if GetItemInfo then return GetItemInfo(id) end
end
local function itemCount(id)
    id = tonumber(id)
    if not id or id < 1 then return 0 end
    if C_Item and C_Item.GetItemCount then
        local ok, n = pcall(C_Item.GetItemCount, id, false)
        if ok and isReadable(n) then return n end
    end
    if GetItemCount then
        local ok, n = pcall(GetItemCount, id)
        if ok and isReadable(n) then return n end
    end
    return 0
end
local function spellInfo(id)
    id = tonumber(id)
    if not id or id < 1 then return nil end
    if C_Spell and C_Spell.GetSpellInfo then
        local ok, data = pcall(C_Spell.GetSpellInfo, id)
        if ok and data then return data end
    end
    return nil
end
local function rIcon(r)
    if r.kind == "spell" then
        local s = spellInfo(r.actionID)
        return (s and s.iconID) or fallbackIcon.spell
    end
    return itemIcon(r.actionID) or fallbackIcon[r.kind]
end
local function equippedID(slot)
    local ok, id = pcall(GetInventoryItemID, "player", slot)
    return ok and isReadable(id) and id or nil
end
local function fishingEquipped()
    local id = equippedID(MAINHAND)
    if not id then return false end
    if C_Item and C_Item.GetItemInfoInstant then
        local ok, _, _, _, equipLoc, _, classID, subID = pcall(C_Item.GetItemInfoInstant, id)
        if ok then
            if equipLoc == "INVTYPE_FISHINGPOLE" then return true end
            if classID == 2 and subID == 20 then return true end
        end
    end
    if GetItemInfoInstant then
        local ok, _, _, _, equipLoc, _, classID, subID = pcall(GetItemInfoInstant, id)
        if ok then
            if equipLoc == "INVTYPE_FISHINGPOLE" then return true end
            if classID == 2 and subID == 20 then return true end
        end
    end
    return false
end
local function equipmentMatches(r)
    if r.kind ~= "weapon" then return true end
    local id = equippedID(r.slot)
    if not id then return false end
    if r.equip == "fishing" then return r.slot == MAINHAND and fishingEquipped() end
    if r.equip == "nonfishing" then return not (r.slot == MAINHAND and fishingEquipped()) end
    if r.equip == "exact" then return tonumber(r.equipID) and tonumber(r.equipID) > 0 and id == tonumber(r.equipID) end
    return true
end

-- Returns "missing", "present", or "unknown", plus remaining seconds.
local function auraStatus(name)
    if type(name) ~= "string" or name == "" then return "missing" end
    if not (C_UnitAuras and C_UnitAuras.GetAuraDataByIndex) then return "unknown" end
    if C_Secrets and C_Secrets.ShouldAurasBeSecret then
        local ok, secret = pcall(C_Secrets.ShouldAurasBeSecret)
        if not ok or not isReadable(secret) or secret then return "unknown" end
    end
    for i = 1, 80 do
        local ok, aura = pcall(C_UnitAuras.GetAuraDataByIndex, "player", i, "HELPFUL")
        if not ok then return "unknown" end
        if not aura then return "missing" end
        if not isReadable(aura) then return "unknown" end
        if not isReadable(aura.name) then return "unknown" end
        if string.lower(aura.name) == string.lower(name) then
            local ends = aura.expirationTime
            if not isReadable(ends) then return "unknown" end
            if ends == 0 then return "present", math.huge end
            return "present", math.max(0, ends - GetTime())
        end
    end
    return "missing"
end

-- Forever can report multiple enchant types on the same weapon.
-- Filter to the temporary enchant to avoid a Shaman imbue concealing a missing oil.
local function enchantStatus(slot)
    if C_Item and C_Item.GetWeaponEnchantInfo and Enum and Enum.WeaponSlot then
        local weaponSlot = slot == MAINHAND and Enum.WeaponSlot.MainHand
            or slot == OFFHAND and Enum.WeaponSlot.OffHand
            or Enum.WeaponSlot.Ranged
        local ok, enchants = pcall(C_Item.GetWeaponEnchantInfo, weaponSlot)
        if ok and type(enchants) == "table" then
            local temporary = Enum.ItemEnchantType and Enum.ItemEnchantType.Temporary
            for _, entry in ipairs(enchants) do
                if not isReadable(entry.hasEnchant) or not isReadable(entry.enchantType) then return "unknown" end
                if entry.hasEnchant and (temporary == nil or entry.enchantType == temporary) then
                    if not isReadable(entry.timeLeft) then return "unknown" end
                    return "present", math.max(0, entry.timeLeft / 1000)
                end
            end
            return "missing"
        end
    end
    if C_PaperDollInfo and C_PaperDollInfo.GetTemporaryEnchantmentInfo then
        local ok, e = pcall(C_PaperDollInfo.GetTemporaryEnchantmentInfo, slot)
        if ok and type(e) == "table" then
            if not isReadable(e.hasExpirationTime) then return "unknown" end
            if e.hasExpirationTime then
                if isReadable(e.expirationTime) then
                    return "present", math.max(0, e.expirationTime - GetTime())
                end
                return "present", math.huge
            end
            return "missing"
        end
    end
    return "unknown"
end

local function formatTime(sec)
    if not sec or sec == math.huge then return "" end
    sec = math.max(0, math.floor(sec))
    if sec >= 3600 then return string.format("%dh", math.ceil(sec / 3600)) end
    if sec >= 60 then return string.format("%dm", math.ceil(sec / 60)) end
    return sec .. "s"
end
local function currentStatus(r)
    if r.kind == "weapon" then return enchantStatus(r.slot) end
    local name = r.buffName
    if r.kind == "spell" and (not name or name == "") then
        local info = spellInfo(r.actionID)
        name = info and info.name
    end
    return auraStatus(name)
end

local function buttonTooltip(button)
    local r = button.reminder
    if not r then return end
    GameTooltip:SetOwner(button, "ANCHOR_RIGHT")
    GameTooltip:AddLine(r.name or "Reminder", 1, 0.82, 0.45)
    if r.kind == "spell" then
        local sp = spellInfo(r.actionID)
        GameTooltip:AddLine("Left click: cast " .. ((sp and sp.name) or "selected spell"), 1, 1, 1)
    else
        GameTooltip:AddLine("Left click: /use " .. (itemName(r.actionID) or "selected item"), 1, 1, 1)
    end
    if r.kind == "weapon" then
        GameTooltip:AddLine("Target: " .. (SLOT_LABEL[r.slot] or "Main hand"), 0.65, 0.9, 1)
        GameTooltip:AddLine("Equipment: " .. (EQUIP_LABEL[r.equip] or "Any"), 0.65, 0.9, 1)
    end
    if DB and (DB.snoozeMinutes or 5) ~= 0 then
        GameTooltip:AddLine("Right click: snooze " .. snoozeLabel(DB.snoozeMinutes or 5), 0.55, 0.9, 0.85)
    end
    GameTooltip:AddLine("/bh - choose and position reminders", 0.55, 0.55, 0.55)
    GameTooltip:Show()
end

local function onDragStart(handle)
    if locked() or not preview then return end
    handle.anchor:StartMoving()
end
local function onDragStop(handle)
    handle.anchor:StopMovingOrSizing()
    if locked() then return end
    local r = handle.reminder
    local x, y = handle.anchor:GetCenter()
    local px, py = UIParent:GetCenter()
    if not x or not px then return end
    r.x, r.y = math.floor(x-px+0.5), math.floor(y-py+0.5)
    if refreshEditor then refreshEditor() end
end
local function createAnchor(r)
    if locked() then return nil end
    local frame = CreateFrame("Frame", nil, UIParent)
    frame:SetMovable(true)
    frame:SetClampedToScreen(true)
    -- Keep reminder buttons underneath standard UI panels (auction house,
    -- inventory, maps, etc.).  LOW is still interactive when unobstructed;
    -- importantly, we never promote these buttons when clicked.
    frame:SetFrameStrata("LOW")
    frame:SetFrameLevel(1)
    frame:SetSize(44, 44)
    frame:SetPoint("CENTER", UIParent, "CENTER", r.x or 0, r.y or 0)

    local button = CreateFrame("Button", "BuffHeroAction" .. r.id, frame, "SecureActionButtonTemplate,BackdropTemplate")
    button:SetAllPoints()
    -- The default client CVar often makes secure buttons act on mouse DOWN.
    -- Explicitly pair mouse-UP registration with useOnKeyDown=false.
    button:RegisterForClicks("LeftButtonUp", "RightButtonUp")
    button:SetAttribute("useOnKeyDown", false)
    -- A right-click is only for the addon snooze; never use the item.
    button:SetAttribute("type2", nil)
    button:SetBackdrop({bgFile="Interface\\Buttons\\WHITE8X8", edgeFile="Interface\\Tooltips\\UI-Tooltip-Border", edgeSize=12, insets={left=2, right=2, top=2, bottom=2}})
    button:SetBackdropColor(0.07, 0.08, 0.11, 0.98)
    button:SetBackdropBorderColor(0.85, 0.63, 0.27, 1)
    local tex = button:CreateTexture(nil, "ARTWORK")
    tex:SetPoint("TOPLEFT", 4, -4)
    tex:SetPoint("BOTTOMRIGHT", -4, 4)
    button.tex = tex
    -- Textures only: alpha animation does not run secure actions or change
    -- protected button attributes, including while already in combat.
    local wash = button:CreateTexture(nil, "OVERLAY", nil, 5)
    wash:SetPoint("TOPLEFT", 4, -4)
    wash:SetPoint("BOTTOMRIGHT", -4, 4)
    wash:SetColorTexture(1, 0.77, 0.25, 1)
    wash:SetBlendMode("ADD")
    wash:SetAlpha(0)
    local glow = button:CreateTexture(nil, "OVERLAY", nil, 6)
    glow:SetTexture("Interface\\Buttons\\UI-ActionButton-Border")
    glow:SetBlendMode("ADD")
    glow:SetPoint("TOPLEFT", -11, 11)
    glow:SetPoint("BOTTOMRIGHT", 11, -11)
    glow:SetVertexColor(1, 0.76, 0.25, 1)
    glow:SetAlpha(0)
    frame.flashGlow, frame.flashWash = glow, wash
    local count = button:CreateFontString(nil, "OVERLAY", "NumberFontNormalSmall")
    count:SetPoint("BOTTOMRIGHT", -1, 2)
    button.count = count
    local time = button:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
    time:SetPoint("TOP", 0, -2)
    button.time = time
    button.reminder = r
    button:SetScript("OnEnter", buttonTooltip)
    button:SetScript("OnLeave", function() GameTooltip:Hide() end)
    -- HookScript keeps the secure action handler intact. Right-click is
    -- intentionally non-secure and never issues a protected item action.
    button:HookScript("OnClick", function(self, mouseButton, down)
        if mouseButton ~= "RightButton" or down then return end
        if not DB or not self.reminder or (DB.snoozeMinutes or 5) == 0 then return end
        if locked() then msg("Snoozing reminders is available out of combat."); return end
        local reminder = self.reminder
        if DB.snoozeMinutes == -1 then
            reminder.snoozePermanent = true
            reminder.snoozedUntil = nil
        else
            reminder.snoozePermanent = nil
            reminder.snoozedUntil = now() + (DB.snoozeMinutes or 5) * 60
        end
        GameTooltip:Hide()
        if refreshButtons then refreshButtons() end
        if refreshList then refreshList() end
        if refreshEditor then refreshEditor() end
    end)

    -- Parenting the move handle to the secure action button also hides the
    -- blue Preview / Move overlay when the combat visibility driver hides it.
    local drag = CreateFrame("Frame", nil, button, "BackdropTemplate")
    drag:SetAllPoints()
    drag:SetFrameLevel(button:GetFrameLevel() + 10)
    drag:EnableMouse(true)
    drag:RegisterForDrag("LeftButton")
    drag:SetBackdrop({bgFile="Interface\\Buttons\\WHITE8X8", edgeFile="Interface\\Tooltips\\UI-Tooltip-Border", edgeSize=12})
    drag:SetBackdropColor(0.1, 0.4, 0.6, 0.32)
    drag:SetBackdropBorderColor(0.3, 0.9, 1, 1)
    local label = drag:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
    label:SetPoint("CENTER", 0, 0)
    label:SetText("MOVE")
    drag:SetScript("OnDragStart", onDragStart)
    drag:SetScript("OnDragStop", onDragStop)
    drag.anchor, drag.reminder = frame, r
    drag:Hide()
    frame.button, frame.drag, frame.r = button, drag, r
    anchors[r.id] = frame
    return frame
end

local function configureAction(f, r)
    if locked() then return end
    local b = f.button
    local id = tonumber(r.actionID)
    -- Left button is always an explicit protected /use or self-buff action.
    -- Macrotext is supported in Forever's secure action template. Using an
    -- item ID avoids localized item names and ambiguous consumable stacks.
    if r.kind == "spell" then
        b:SetAttribute("type1", "spell")
        b:SetAttribute("spell", id and id > 0 and id or nil)
        b:SetAttribute("unit", "player")
        b:SetAttribute("item", nil)
        b:SetAttribute("macrotext", nil)
        b:SetAttribute("target-slot", nil)
    else
        b:SetAttribute("type1", "macro")
        b:SetAttribute("macro", nil)
        b:SetAttribute("macrotext", id and id > 0 and ("/use item:" .. math.floor(id)) or nil)
        b:SetAttribute("item", nil)
        b:SetAttribute("unit", nil)
        b:SetAttribute("spell", nil)
        -- If the /use targets an equipped item, the secure template applies
        -- it to the current slot, without a Lua click or cursor automation.
        b:SetAttribute("target-slot", r.kind == "weapon" and (r.slot or MAINHAND) or nil)
    end
    b:SetAttribute("type", nil)
    b:SetAttribute("type2", nil)
end
local function layoutAnchor(f, r)
    if locked() then return end
    local size = clamp(r.size or 44, 24, 100)
    f:SetSize(size, size)
    f:ClearAllPoints()
    f:SetPoint("CENTER", UIParent, "CENTER", r.x or 0, r.y or 0)
    f.button.tex:SetTexture(rIcon(r))
    f.button.tex:SetDesaturated(false)
    f.button.tex:SetVertexColor(1, 1, 1)
    configureAction(f, r)
end
-- A secure state driver controls the actual click button when combat starts.
-- Hiding the parent anchor from ordinary buff rules still works, while the
-- driver can hide protected buttons during combat without taint or lockdown.
-- This is set/changed ONLY outside combat; secure WoW state handles transitions.
local function syncCombatVisibility(f)
    if locked() or not DB or not f or not f.button then return end
    local rule = DB.hideInCombat and "[combat] hide; show" or "show"
    if f.combatVisibilityRule == rule then return end
    if type(RegisterStateDriver) ~= "function" then
        if not M.combatDriverWarning then
            M.combatDriverWarning = true
            msg("Combat hiding needs WoW's secure state-driver API, which is unavailable.")
        end
        return
    end
    local ok = pcall(RegisterStateDriver, f.button, "visibility", rule)
    if ok then
        f.combatVisibilityRule = rule
    elseif not M.combatDriverWarning then
        M.combatDriverWarning = true
        msg("Could not install secure combat hiding for the reminders.")
    end
end
local function refreshOne(r)
    if locked() then return end
    local f = anchors[r.id] or createAnchor(r)
    if not f then return end
    syncCombatVisibility(f)
    local placementKey = table.concat({tostring(r.size), tostring(r.x), tostring(r.y), tostring(r.kind), tostring(r.actionID), tostring(r.slot)}, ":")
    if f.placementKey ~= placementKey then
        layoutAnchor(f, r)
        f.placementKey = placementKey
    end
    f.drag:SetShown(preview)
    if preview then
        setFlashActive(f, false)
        f.button:SetAlpha(DB.solidReminders and 1 or TRANSLUCENT_ALPHA)
        f.button.count:SetText("")
        f.button.time:SetText("")
        f:Show()
        return
    end
    if DB.remindersPaused or not r.enabled or tonumber(r.actionID or 0) == 0 or not equipmentMatches(r)
        or isSnoozed(r) or ((DB.hideAllWhileResting or r.hideWhileResting) and isRestingArea()) then
        setFlashActive(f, false)
        f:Hide()
        return
    end
    local status, left = currentStatus(r)
    if status == "unknown" then
        -- No false alerts when WoW marks aura/enchant data secret.
        setFlashActive(f, false)
        f:Hide()
        return
    end
    if status == "present" and (not left or left > (tonumber(r.warn) or 60)) then
        setFlashActive(f, false)
        f:Hide()
        return
    end
    f.button:SetAlpha(DB.solidReminders and 1 or TRANSLUCENT_ALPHA)
    f:Show()
    setFlashActive(f, shouldFlashHere())
    local count = r.kind ~= "spell" and itemCount(r.actionID) or 1
    f.button.tex:SetDesaturated(count == 0)
    f.button.tex:SetVertexColor(count == 0 and 0.58 or 1, count == 0 and 0.58 or 1, count == 0 and 0.58 or 1)
    f.button.count:SetText(count > 1 and tostring(count) or (count == 0 and "0" or ""))
    f.button.time:SetText(status == "present" and formatTime(left) or "!")
end
refreshButtons = function()
    if not DB or locked() then return end
    for _, r in ipairs(DB.reminders) do refreshOne(r) end
end

local function makeReminder(kind)
    local id = DB.nextID or 1
    DB.nextID = id + 1
    local count = #DB.reminders
    local r = {
        id=id, kind=kind, enabled=true, hideWhileResting=false, actionID=0, slot=MAINHAND,
        equip="any", equipID=0, warn=60, size=44,
        x=(count - 1) * 54 - 54, y=-130, buffName="",
        name=kind == "food" and "Food" or kind == "spell" and "Spell Buff" or "Weapon Oil",
    }
    if kind == "food" then r.buffName="Well Fed"; r.warn=180 end
    if kind == "weapon" then r.equip="nonfishing"; r.warn=60 end
    table.insert(DB.reminders, r)
    return r
end
local function starter()
    local food = makeReminder("food")
    food.x = -54
    food.name = "Food"
    local oil = makeReminder("weapon")
    oil.x = 0
    oil.name = "Mana Oil"
    local lure = makeReminder("weapon")
    lure.x = 54
    lure.name = "Fishing Lure"
    lure.equip="fishing"
    local sleep = makeReminder("food")
    sleep.name = "Well-Rested"
    sleep.actionID = 211527 -- Cozy Sleeping Bag, WoW Forever
    sleep.buffName = "Well-Rested"
    sleep.warn = 600
    sleep.x = 108
end
local function readDB()
    if type(BuffHeroDB) ~= "table" then BuffHeroDB = {} end
    DB = BuffHeroDB
    if type(DB.reminders) ~= "table" then DB.reminders = {} end
    if DB.snoozeMinutes == nil then DB.snoozeMinutes = 5 end
    -- Opt-in visual alert settings. Existing reminders are never modified.
    if type(DB.flashInDungeons) ~= "boolean" then DB.flashInDungeons = false end
    if type(DB.flashInRaids) ~= "boolean" then DB.flashInRaids = false end
    if not FLASH_HZ[DB.flashSpeed] then DB.flashSpeed = "normal" end
    if DB.flashStyle ~= "attention" then DB.flashStyle = "pulse" end
    -- Existing installations keep fully opaque reminders unless opted out.
    if type(DB.solidReminders) ~= "boolean" then DB.solidReminders = true end
    -- Make the settings panel fully opaque by default, independent of icon alpha.
    if type(DB.solidSettings) ~= "boolean" then DB.solidSettings = true end
    -- Global, opt-in combat visibility. Do not change existing reminder rules.
    if type(DB.hideInCombat) ~= "boolean" then DB.hideInCombat = false end
    -- Global resting toggle adds to, but does not overwrite, each reminder's
    -- existing per-reminder rest preference.
    if type(DB.hideAllWhileResting) ~= "boolean" then DB.hideAllWhileResting = false end
    -- New opt-in minimap launcher: shown initially so it can be discovered,
    -- and always switchable in Extra Settings without deleting the addon.
    if type(DB.showMinimap) ~= "boolean" then DB.showMinimap = true end
    if type(DB.remindersPaused) ~= "boolean" then DB.remindersPaused = false end
    DB.minimapAngle = tonumber(DB.minimapAngle) or 225
    local validSnooze = false
    for _, duration in ipairs(SNOOZE_CHOICES) do
        if duration == DB.snoozeMinutes then validSnooze = true; break end
    end
    if not validSnooze then DB.snoozeMinutes = 5 end
    if not DB.initialized then
        DB.initialized = true
        DB.nextID = 1
        starter()
        DB.schemaVersion = 7
    end
    local highest = 0
    for _, r in ipairs(DB.reminders) do
        -- Preserve existing reminders; the new checkbox is opt-in.
        if r.hideWhileResting == nil then r.hideWhileResting = false end
        r.slot = SLOT_LABEL[r.slot] and r.slot or MAINHAND
        r.equip = EQUIP_LABEL[r.equip] and r.equip or "any"
        r.x = tonumber(r.x) or 0
        r.y = tonumber(r.y) or -130
        highest = math.max(highest, tonumber(r.id) or 0)
    end
    DB.nextID = math.max(tonumber(DB.nextID) or 1, highest + 1)
    -- Add the Forever Sleeping Bag reminder once on upgrade. Never replace
    -- existing user selections, locations, or saved reminder definitions.
    if (tonumber(DB.schemaVersion) or 1) < 2 then
        local found = false
        for _, r in ipairs(DB.reminders) do
            if tonumber(r.actionID) == 211527 or r.buffName == "Well-Rested" then
                found = true; break
            end
        end
        if not found then
            local sleep = makeReminder("food")
            sleep.name = "Well-Rested"
            sleep.actionID = 211527
            sleep.buffName = "Well-Rested"
            sleep.warn = 600
            sleep.x = 108
        end
    end
    DB.schemaVersion = 7
end

-- Independent minimap button: no library/addon dependency. The standard
-- Minimap parent/name lets most minimap-button organizers collect it.
local MINIMAP_ICON = "Interface\\Icons\\Ability_Warrior_StrengthOfArms"
local function syncMinimapButton()
    local button = M.minimapButton
    if not button or not DB then return end
    button:SetShown(DB.showMinimap == true)
    if button.icon then
        button.icon:SetDesaturated(DB.remindersPaused == true)
        button.icon:SetAlpha(DB.remindersPaused and 0.65 or 1)
    end
    if M.pauseButton then
        M.pauseButton:SetText(DB.remindersPaused and "Resume Reminders" or "Pause Reminders")
    end
end
local function toggleRemindersPaused()
    if not DB then return end
    if locked() then
        msg("Pause or resume reminders after combat.")
        return
    end
    DB.remindersPaused = not DB.remindersPaused
    syncMinimapButton()
    refreshButtons()
    msg(DB.remindersPaused and "Reminders paused. Right-click the minimap arm to resume." or "Reminders resumed.")
end
local function updateMinimapPosition(button)
    if not Minimap then return end
    local angle = math.rad(tonumber(DB.minimapAngle) or 225)
    local radius = (math.max(Minimap:GetWidth(), Minimap:GetHeight()) / 2) + 9
    button:ClearAllPoints()
    button:SetPoint("CENTER", Minimap, "CENTER", math.cos(angle) * radius, math.sin(angle) * radius)
end
local function createMinimapButton()
    if not Minimap or M.minimapButton then return end
    local button = CreateFrame("Button", "BuffHeroMinimapButton", Minimap)
    button:SetSize(32, 32)
    button:SetFrameStrata("MEDIUM")
    button:SetFrameLevel((Minimap:GetFrameLevel() or 0) + 5)
    button:EnableMouse(true)
    button:RegisterForClicks("LeftButtonUp", "RightButtonUp")
    button:RegisterForDrag("LeftButton")
    button:SetHighlightTexture("Interface\\Minimap\\UI-Minimap-ZoomButton-Highlight")
    local background = button:CreateTexture(nil, "BACKGROUND")
    background:SetSize(23, 23)
    background:SetPoint("CENTER", 0, 0)
    background:SetTexture("Interface\\Minimap\\UI-Minimap-Background")
    local icon = button:CreateTexture(nil, "ARTWORK")
    icon:SetSize(21, 21)
    icon:SetPoint("CENTER", 0, 0)
    icon:SetTexture(MINIMAP_ICON)
    button.icon = icon
    local ring = button:CreateTexture(nil, "OVERLAY")
    ring:SetTexture("Interface\\Minimap\\MiniMap-TrackingBorder")
    ring:SetSize(53, 53)
    -- MiniMap-TrackingBorder's circle is drawn in the texture's upper-left
    -- corner, not centered in its full 53x53 canvas. Use the Blizzard/
    -- LibDBIcon TOPLEFT anchor so the border surrounds the actual icon.
    ring:SetPoint("TOPLEFT", button, "TOPLEFT", 0, 0)
    button:SetScript("OnMouseDown", function(self) self.wasDragged = false end)
    button:SetScript("OnDragStart", function(self)
        self.wasDragged = true
        self:SetScript("OnUpdate", function(btn)
            local x, y = GetCursorPosition()
            local scale = Minimap:GetEffectiveScale()
            local mx, my = Minimap:GetCenter()
            if not (x and y and scale and scale > 0 and mx and my) then return end
            local dx, dy = x / scale - mx, y / scale - my
            if dx == 0 and dy == 0 then return end
            if math.atan2 then
                DB.minimapAngle = math.deg(math.atan2(dy, dx))
            else
                -- WoW's embedded Lua 5.1 may not expose math.atan2.
                local a = math.deg(math.atan(dy / (dx == 0 and 0.00001 or dx)))
                DB.minimapAngle = dx < 0 and a + 180 or a
            end
            updateMinimapPosition(btn)
        end)
    end)
    button:SetScript("OnDragStop", function(self)
        self:SetScript("OnUpdate", nil)
        updateMinimapPosition(self)
    end)
    button:SetScript("OnClick", function(self, mouse)
        if self.wasDragged then self.wasDragged = false; return end
        if mouse == "RightButton" then
            toggleRemindersPaused()
        elseif mouse == "LeftButton" then
            if toggleSettings then toggleSettings() end
        end
    end)
    -- Separate tooltip avoids global GameTooltip mover/hide hooks.
    local launcherTooltip = CreateFrame("GameTooltip", "BuffHeroLauncherTooltip", UIParent, "GameTooltipTemplate")
    launcherTooltip:SetFrameStrata("TOOLTIP")
    launcherTooltip:EnableMouse(false)
    launcherTooltip:Hide()
    button:SetScript("OnEnter", function(self)
        launcherTooltip:SetOwner(self, "ANCHOR_NONE")
        launcherTooltip:ClearAllPoints()
        launcherTooltip:SetPoint("RIGHT", self, "LEFT", -8, 0)
        launcherTooltip:ClearLines()
        launcherTooltip:AddLine("BuffHero", 1, 0.83, 0.28)
        launcherTooltip:AddLine("Buff and consumable reminders", 0.75, 0.75, 0.75)
        launcherTooltip:AddLine("Left-click: open settings", 1, 1, 1)
        launcherTooltip:AddLine("Right-click: " .. (DB.remindersPaused and "resume" or "pause") .. " reminders", 1, 1, 1)
        launcherTooltip:AddLine("Drag: move around minimap", 0.66, 0.85, 1)
        launcherTooltip:Show()
    end)
    local function hideLauncherTooltip(self)
        launcherTooltip:Hide()
    end
    button:SetScript("OnLeave", hideLauncherTooltip)
    button:SetScript("OnHide", hideLauncherTooltip)
    button:HookScript("OnDragStart", hideLauncherTooltip)
    M.minimapButton = button
    updateMinimapPosition(button)
    syncMinimapButton()
end

local function makeText(parent, text, x, y, font)
    local t = parent:CreateFontString(nil, "OVERLAY", font or "GameFontNormal")
    t:SetPoint("TOPLEFT", parent, "TOPLEFT", x, y)
    t:SetJustifyH("LEFT")
    t:SetText(text)
    return t
end
local function makeButton(parent, text, x, y, w, h, callback)
    local b = CreateFrame("Button", nil, parent, "UIPanelButtonTemplate")
    b:SetPoint("TOPLEFT", parent, "TOPLEFT", x, y)
    b:SetSize(w, h or 24)
    b:SetText(text)
    b:SetScript("OnClick", callback)
    return b
end
local function makeEdit(parent, key, label, y, width, x)
    local labelX = 238
    x = x or 394
    makeText(parent, label, labelX, y-5, "GameFontHighlightSmall")
    local field = CreateFrame("EditBox", nil, parent, "InputBoxTemplate")
    field:SetSize(width or 155, 22)
    field:SetPoint("TOPLEFT", parent, "TOPLEFT", x, y)
    field:SetAutoFocus(false)
    field:SetMaxLetters(90)
    field:SetScript("OnEnterPressed", function(self) self:ClearFocus() end)
    field:SetScript("OnEscapePressed", function(self) self:ClearFocus(); if refreshEditor then refreshEditor() end end)
    field:SetScript("OnEditFocusLost", function(self)
        local r = DB and DB.reminders[selected]
        if not r then return end
        local value = self:GetText()
        if key == "name" then r.name = value ~= "" and value or TYPE_LABEL[r.kind]
        elseif key == "buffName" then r.buffName = value
        elseif key == "actionID" then r.actionID = math.max(0, math.floor(tonumber(value) or 0))
        elseif key == "equipID" then r.equipID = math.max(0, math.floor(tonumber(value) or 0))
        elseif key == "warn" then r.warn = clamp(value, 0, 3600)
        elseif key == "size" then r.size = clamp(value, 24, 100)
        elseif key == "x" then r.x = clamp(value, -4000, 4000)
        elseif key == "y" then r.y = clamp(value, -4000, 4000)
        end
        if refreshList then refreshList() end
        if refreshButtons then refreshButtons() end
        if refreshEditor then refreshEditor() end
    end)
    edits[key] = field
    return field
end
local function selectedReminder()
    return DB and DB.reminders[selected]
end
local function buildSettings()
    settings = CreateFrame("Frame", "BuffHeroSettings", UIParent, "BackdropTemplate")
    settings:SetSize(615, 640)
    settings:SetFrameStrata("DIALOG")
    settings:SetToplevel(true)
    settings:SetClampedToScreen(true)
    settings:EnableMouse(true)
    settings:SetMovable(true)
    settings:RegisterForDrag("LeftButton")
    settings:SetScript("OnDragStart", function(self) if not locked() then self:StartMoving() end end)
    settings:SetScript("OnDragStop", function(self) self:StopMovingOrSizing() end)
    settings:SetPoint("CENTER")
    -- The Blizzard dialog background contains transparency in its texture.
    -- Draw a solid, noninteractive backing beneath that decorative texture.
    -- This makes the SETTINGS window truly opaque without changing text,
    -- controls, layout, reminder buttons or their alpha.
    local solidPanel = settings:CreateTexture(nil, "BACKGROUND", nil, -8)
    solidPanel:SetPoint("TOPLEFT", settings, "TOPLEFT", 9, -9)
    solidPanel:SetPoint("BOTTOMRIGHT", settings, "BOTTOMRIGHT", -9, 9)
    solidPanel:SetColorTexture(0.065, 0.043, 0.029, 1)
    solidPanel:SetShown(DB.solidSettings)
    M.solidSettingsPanel = solidPanel
    settings:SetBackdrop({bgFile="Interface\\DialogFrame\\UI-DialogBox-Background", edgeFile="Interface\\DialogFrame\\UI-DialogBox-Border", tile=true, tileSize=32, edgeSize=32, insets={left=9,right=9,top=9,bottom=9}})
    settings:Hide()
    if UISpecialFrames then table.insert(UISpecialFrames, "BuffHeroSettings") end
    makeText(settings, "Buff Hero", 18, -17, "GameFontNormalLarge")
    makeText(settings, "v" .. VERSION, 125, -20, "GameFontDisableSmall")
    makeText(settings, "Choose a reminder, assign an item, and position its icon.", 18, -47, "GameFontHighlightSmall")
    -- Small, unobtrusive memorial on the bottom border of the settings panel.
    local memorial = settings:CreateFontString(nil, "OVERLAY")
    memorial:SetFont("Fonts\\MORPHEUS.TTF", 11, "OUTLINE")
    memorial:SetPoint("BOTTOM", settings, "BOTTOM", 0, 14)
    memorial:SetTextColor(0.86, 0.69, 0.25, 0.8)
    memorial:SetText("RIP Shady")
    makeButton(settings, "X", 569, -18, 25, 23, function() settings:Hide() end)
    reminderPage = CreateFrame("Frame", nil, settings)
    reminderPage:SetSize(615, 580)
    reminderPage:SetPoint("TOPLEFT", settings, "TOPLEFT", 0, -48)
    extraPage = CreateFrame("Frame", nil, settings)
    extraPage:SetSize(615, 580)
    extraPage:SetPoint("TOPLEFT", settings, "TOPLEFT", 0, -48)
    M.tabReminders = makeButton(settings, "Reminders", 20, -76, 127, 27, function()
        selectedTab = "reminders"
        reminderPage:Show()
        extraPage:Hide()
        M.tabReminders:Disable()
        M.tabExtra:Enable()
        flashDemoEnabled = false
    end)
    M.tabExtra = makeButton(settings, "Extra Settings", 153, -76, 139, 27, function()
        selectedTab = "extra"
        reminderPage:Hide()
        extraPage:Show()
        M.tabReminders:Enable()
        M.tabExtra:Disable()
    end)
    local border = reminderPage:CreateTexture(nil, "ARTWORK")
    border:SetColorTexture(0.65, 0.53, 0.26, 0.35)
    border:SetSize(1, 390)
    border:SetPoint("TOPLEFT", 222, -90)
    makeText(reminderPage, "REMINDERS", 23, -83, "GameFontNormal")
    makeText(reminderPage, "EDIT REMINDER", 238, -83, "GameFontNormal")

    for i = 1, 8 do
        local b = makeButton(reminderPage, "", 19, -107 - (i-1)*31, 189, 27, function()
            local n = offset+i
            if DB.reminders[n] then selected=n; refreshList(); refreshEditor() end
        end)
        listButtons[i] = b
    end
    makeButton(reminderPage, "<", 19, -363, 29, 22, function()
        offset = math.max(0, offset - 8); refreshList()
    end)
    makeButton(reminderPage, ">", 52, -363, 29, 22, function()
        offset = math.min(math.max(0,#DB.reminders - 8), offset+8); refreshList()
    end)
    M.page = makeText(reminderPage, "", 92, -366, "GameFontHighlightSmall")
    makeButton(reminderPage, "+ Food", 19, -399, 91, 24, function() M.add("food") end)
    makeButton(reminderPage, "+ Oil / Lure", 115, -399, 95, 24, function() M.add("weapon") end)
    makeButton(reminderPage, "+ Spell", 19, -430, 91, 24, function() M.add("spell") end)
    M.previewButton = makeButton(reminderPage, "Preview / Move: OFF", 19, -462, 192, 25, function()
        if locked() then msg("You can only arrange reminders out of combat."); return end
        preview = not preview
        M.previewButton:SetText("Preview / Move: " .. (preview and "ON" or "OFF"))
        refreshButtons()
    end)
    makeText(reminderPage, "Preview ON: drag blue icons to move them.", 20, -497, "GameFontDisableSmall")
    makeText(reminderPage, "Right-click snooze", 20, -523, "GameFontHighlightSmall")
    M.snoozeButton = makeButton(reminderPage, "5 min", 120, -515, 90, 23, function()
        if not DB then return end
        local index = 1
        for i, duration in ipairs(SNOOZE_CHOICES) do
            if duration == DB.snoozeMinutes then index = i; break end
        end
        DB.snoozeMinutes = SNOOZE_CHOICES[index % #SNOOZE_CHOICES + 1]
        M.snoozeButton:SetText(snoozeLabel(DB.snoozeMinutes))
        if refreshEditor then refreshEditor() end
    end)
    makeText(reminderPage, "Right-click an icon to hide its reminder.", 20, -551, "GameFontDisableSmall")

    makeEdit(reminderPage, "name", "Label", -111, 174)
    makeEdit(reminderPage, "actionID", "Item / Spell ID", -145, 94)
    M.pickButton = makeButton(reminderPage, "From Bags", 496, -145, 74, 22, function()
        if M.openPicker then M.openPicker() end
    end)
    makeEdit(reminderPage, "buffName", "Buff name to detect", -179, 174)
    M.slotButton = makeButton(reminderPage, "", 391, -215, 178, 24, function()
        local r = selectedReminder()
        if not r or r.kind ~= "weapon" then return end
        local s = r.slot == MAINHAND and OFFHAND or r.slot == OFFHAND and RANGED or MAINHAND
        r.slot=s; refreshEditor(); refreshButtons()
    end)
    makeText(reminderPage, "Target slot", 238, -220, "GameFontHighlightSmall")
    M.equipButton = makeButton(reminderPage, "", 391, -249, 178, 24, function()
        local r = selectedReminder()
        if not r or r.kind ~= "weapon" then return end
        local nextMode="any"
        for i, mode in ipairs(EQUIPEd) do
            if mode == r.equip then nextMode = EQUIPEd[i % #EQUIPEd + 1]; break end
        end
        r.equip = nextMode
        if nextMode == "exact" and (r.equipID or 0) == 0 then r.equipID = equippedID(r.slot) or 0 end
        refreshEditor(); refreshButtons()
    end)
    makeText(reminderPage, "When equipped", 238, -254, "GameFontHighlightSmall")
    makeEdit(reminderPage, "equipID", "Exact item ID", -283, 93, 391)
    M.capture = makeButton(reminderPage, "Use Equipped", 490, -283, 80, 22, function()
        local r = selectedReminder()
        if not r or r.kind ~= "weapon" then return end
        r.equipID = equippedID(r.slot) or 0
        r.equip = "exact"
        if r.equipID == 0 then msg("Equip the item in that slot first.") end
        refreshEditor(); refreshButtons()
    end)
    makeEdit(reminderPage, "warn", "Warn before (seconds)", -319, 80)
    makeEdit(reminderPage, "size", "Icon size (pixels)", -353, 80)
    makeEdit(reminderPage, "x", "X position", -387, 80)
    makeEdit(reminderPage, "y", "Y position", -421, 80)
    M.enabledButton = makeButton(reminderPage, "", 238, -460, 105, 24, function()
        local r = selectedReminder(); if not r then return end
        r.enabled = not r.enabled; refreshEditor(); refreshList(); refreshButtons()
    end)
    M.deleteButton = makeButton(reminderPage, "Delete", 353, -460, 105, 24, function()
        if locked() then msg("Delete reminders out of combat."); return end
        local r = selectedReminder(); if not r then return end
        local f = anchors[r.id]
        if f then f:Hide(); anchors[r.id] = nil end
        table.remove(DB.reminders,selected)
        selected = math.max(1, math.min(selected, #DB.reminders))
        offset = math.min(offset, math.max(0, #DB.reminders-8))
        refreshList(); refreshEditor(); refreshButtons()
    end)
    makeButton(reminderPage, "Reset Position", 466, -460, 102, 24, function()
        local r = selectedReminder(); if not r then return end
        r.x, r.y = 0, -130
        refreshEditor(); refreshButtons()
    end)
    -- Each reminder has its own rest-area filter. Keep this above the snooze
    -- row and separate from Preview mode; preview intentionally shows all.
    M.restCheck = CreateFrame("CheckButton", nil, reminderPage, "UICheckButtonTemplate")
    M.restCheck:SetSize(24, 24)
    M.restCheck:SetPoint("TOPLEFT", reminderPage, "TOPLEFT", 237, -489)
    M.restCheck:SetScript("OnClick", function(self)
        local r = selectedReminder()
        if not r then return end
        r.hideWhileResting = self:GetChecked() and true or false
        refreshButtons()
        refreshEditor()
    end)
    makeText(reminderPage, "Hide while resting (inns / cities)", 267, -493, "GameFontHighlightSmall")
    M.hint = makeText(reminderPage, "", 239, -553, "GameFontDisableSmall")
    makeText(reminderPage, "Snoozed reminder?", 239, -524, "GameFontHighlightSmall")
    M.resumeButton = makeButton(reminderPage, "Resume Selected", 391, -516, 178, 24, function()
        local r = selectedReminder()
        if not r then return end
        if locked() then msg("Resume reminders out of combat."); return end
        clearSnooze(r)
        refreshList(); refreshEditor(); refreshButtons()
    end)
    -- Compact secondary tab: global alert behavior, not additional reminder clutter.
    makeText(extraPage, "DUNGEON ALERTS", 24, -83, "GameFontNormal")
    makeText(extraPage, "Flash icons only while their buff is missing or nearing expiration.", 24, -112, "GameFontHighlightSmall")
    local function extraCheck(label, y, dbKey, x)
        x = x or 26
        local cb = CreateFrame("CheckButton", nil, extraPage, "UICheckButtonTemplate")
        cb:SetSize(26, 26)
        cb:SetPoint("TOPLEFT", extraPage, "TOPLEFT", x, y)
        makeText(extraPage, label, x + 34, y - 5, "GameFontHighlight")
        cb:SetScript("OnClick", function(self)
            if (dbKey == "hideInCombat" or dbKey == "hideAllWhileResting") and locked() then
                self:SetChecked(DB[dbKey] == true)
                msg("Change reminder visibility after combat.")
                return
            end
            DB[dbKey] = self:GetChecked() and true or false
            if dbKey == "showMinimap" then
                syncMinimapButton()
            else
                refreshButtons()
            end
        end)
        cb:SetChecked(DB[dbKey] == true)
        return cb
    end
    M.flashCheck = extraCheck("Flash missing buffs inside dungeons", -153, "flashInDungeons")
    M.raidCheck = extraCheck("Include raid instances", -190, "flashInRaids")
    -- Global visibility, separate from the dungeon visual alert options.
    makeText(extraPage, "COMBAT VISIBILITY", 336, -83, "GameFontNormal")
    M.combatHideCheck = extraCheck("Hide reminders in combat", -153, "hideInCombat", 333)
    makeText(extraPage, "Return automatically after combat.", 367, -191, "GameFontDisableSmall")
    -- Applies to all reminders, without erasing the per-reminder option on
    -- the Reminders tab. IsResting() reports cities/inns, not stored rested XP.
    makeText(extraPage, "RESTING AREAS", 336, -220, "GameFontNormal")
    M.globalRestCheck = extraCheck("Hide all while resting", -261, "hideAllWhileResting", 333)
    makeText(extraPage, "In cities / inns; show again outside.", 367, -299, "GameFontDisableSmall")
    M.solidCheck = extraCheck("Solid reminder icons", -319, "solidReminders")
    -- Separate control for the menu itself. Both options can be toggled live.
    -- Keep this beside the icon checkbox, leaving the preview below intact.
    M.solidSettingsCheck = CreateFrame("CheckButton", nil, extraPage, "UICheckButtonTemplate")
    M.solidSettingsCheck:SetSize(26, 26)
    M.solidSettingsCheck:SetPoint("TOPLEFT", extraPage, "TOPLEFT", 332, -333)
    makeText(extraPage, "Solid settings window", 366, -338, "GameFontHighlight")
    M.solidSettingsCheck:SetChecked(DB.solidSettings)
    M.solidSettingsCheck:SetScript("OnClick", function(self)
        DB.solidSettings = self:GetChecked() and true or false
        if M.solidSettingsPanel then M.solidSettingsPanel:SetShown(DB.solidSettings) end
    end)
    -- Both options preserve the existing reminder layout and click actions.
    makeText(extraPage, "Flash speed", 27, -250, "GameFontHighlightSmall")
    M.flashSpeedButton = makeButton(extraPage, "", 175, -241, 130, 25, function()
        local i = 1
        for n, value in ipairs(FLASH_SPEEDS) do
            if value == DB.flashSpeed then i = n; break end
        end
        DB.flashSpeed = FLASH_SPEEDS[i % #FLASH_SPEEDS + 1]
        M.flashSpeedButton:SetText(DB.flashSpeed:sub(1, 1):upper() .. DB.flashSpeed:sub(2))
    end)
    makeText(extraPage, "Flash style", 27, -294, "GameFontHighlightSmall")
    M.flashStyleButton = makeButton(extraPage, "", 175, -285, 130, 25, function()
        DB.flashStyle = DB.flashStyle == "pulse" and "attention" or "pulse"
        M.flashStyleButton:SetText(DB.flashStyle == "attention" and "Attention Flash" or "Subtle Pulse")
    end)
    makeText(extraPage, "PREVIEW", 24, -358, "GameFontNormal")
    local demo = CreateFrame("Frame", nil, extraPage, "BackdropTemplate")
    demo:SetSize(56, 56)
    demo:SetPoint("TOPLEFT", 29, -398)
    demo:SetBackdrop({bgFile="Interface\\Buttons\\WHITE8X8", edgeFile="Interface\\Tooltips\\UI-Tooltip-Border", edgeSize=12, insets={left=2,right=2,top=2,bottom=2}})
    demo:SetBackdropColor(0.07, 0.08, 0.11, 0.98)
    demo:SetBackdropBorderColor(0.85, 0.63, 0.27, 1)
    local icon = demo:CreateTexture(nil, "ARTWORK")
    icon:SetTexture("Interface\\Icons\\INV_Misc_Food_15")
    icon:SetPoint("TOPLEFT", 4, -4)
    icon:SetPoint("BOTTOMRIGHT", -4, 4)
    local wash = demo:CreateTexture(nil, "OVERLAY", nil, 5)
    wash:SetPoint("TOPLEFT", 4, -4)
    wash:SetPoint("BOTTOMRIGHT", -4, 4)
    wash:SetColorTexture(1, 0.77, 0.25, 1)
    wash:SetBlendMode("ADD")
    wash:SetAlpha(0)
    local glow = demo:CreateTexture(nil, "OVERLAY", nil, 6)
    glow:SetTexture("Interface\\Buttons\\UI-ActionButton-Border")
    glow:SetBlendMode("ADD")
    glow:SetPoint("TOPLEFT", -11, 11)
    glow:SetPoint("BOTTOMRIGHT", 11, -11)
    glow:SetVertexColor(1, 0.76, 0.25, 1)
    glow:SetAlpha(0)
    M.flashDemoGlow, M.flashDemoWash = glow, wash
    M.testFlashButton = makeButton(extraPage, "Test Flash: OFF", 117, -409, 157, 29, function()
        flashDemoEnabled = not flashDemoEnabled
        M.testFlashButton:SetText("Test Flash: " .. (flashDemoEnabled and "ON" or "OFF"))
        if not flashDemoEnabled then
            M.flashDemoGlow:SetAlpha(0)
            M.flashDemoWash:SetAlpha(0)
        end
    end)
    makeText(extraPage, "Shows the effect here without moving or using any items.", 27, -485, "GameFontDisableSmall")
    makeText(extraPage, "Uncheck Solid reminder icons for 65% opacity.", 27, -516, "GameFontDisableSmall")
    makeText(extraPage, "Disabled by default. Never flashes in cities, outdoors, BGs, or arenas.", 27, -543, "GameFontDisableSmall")
    makeText(extraPage, "MINIMAP LAUNCHER", 336, -382, "GameFontNormal")
    M.minimapCheck = extraCheck("Show strength-arm icon", -421, "showMinimap", 333)
    makeText(extraPage, "Drag it around the minimap.", 367, -459, "GameFontDisableSmall")
    makeText(extraPage, "Left-click: settings. Right-click: pause.", 367, -482, "GameFontDisableSmall")
    M.pauseButton = makeButton(extraPage, "Pause Reminders", 366, -505, 162, 25, toggleRemindersPaused)
    syncMinimapButton()
    M.flashSpeedButton:SetText(DB.flashSpeed:sub(1, 1):upper() .. DB.flashSpeed:sub(2))
    M.flashStyleButton:SetText(DB.flashStyle == "attention" and "Attention Flash" or "Subtle Pulse")
    extraPage:Hide()
    M.tabReminders:Disable()

    settings:SetScript("OnHide", function()
        flashDemoEnabled = false
        if M.testFlashButton then M.testFlashButton:SetText("Test Flash: OFF") end
        if M.flashDemoGlow then M.flashDemoGlow:SetAlpha(0); M.flashDemoWash:SetAlpha(0) end
        if preview and not locked() then
            preview = false
            M.previewButton:SetText("Preview / Move: OFF")
            refreshButtons()
        end
    end)
    refreshEditor()
end
refreshList = function()
    if not settings or not DB then return end
    for i, b in ipairs(listButtons) do
        local n = offset+i
        local r = DB.reminders[n]
        b:SetShown(r ~= nil)
        if r then
            b:SetText((n == selected and "> " or "") .. (r.enabled and "" or "[Off] ") .. (isSnoozed(r) and "[Z] " or "") .. (r.name or TYPE_LABEL[r.kind]))
        end
    end
    M.page:SetText(#DB.reminders > 0 and (math.min(offset+1, #DB.reminders) .. "-" .. math.min(offset+8,#DB.reminders) .. " / " .. #DB.reminders) or "None")
end
refreshEditor = function()
    if not settings or not DB then return end
    local r = selectedReminder()
    local have = r ~= nil
    for key, edit in pairs(edits) do
        edit:SetEnabled(have and (key ~= "buffName" or r.kind ~= "weapon") and
            ((key ~= "equipID") or r.kind == "weapon"))
        if not edit:HasFocus() then edit:SetText(have and tostring(r[key] or "") or "") end
    end
    M.slotButton:SetEnabled(have and r.kind == "weapon")
    M.equipButton:SetEnabled(have and r.kind == "weapon")
    M.capture:SetEnabled(have and r.kind == "weapon")
    M.pickButton:SetEnabled(have and r.kind ~= "spell")
    M.slotButton:SetText(have and (SLOT_LABEL[r.slot] or "Main hand") or "-")
    M.equipButton:SetText(have and (EQUIP_LABEL[r.equip] or "Any") or "-")
    M.enabledButton:SetEnabled(have)
    M.deleteButton:SetEnabled(have)
    M.restCheck:SetEnabled(have)
    M.restCheck:SetChecked(have and r.hideWhileResting == true or false)
    M.enabledButton:SetText(have and (r.enabled and "Enabled" or "Disabled") or "-")
    M.snoozeButton:SetText(snoozeLabel(DB.snoozeMinutes or 5))
    M.resumeButton:SetEnabled(have and isSnoozed(r))
    M.hint:SetText(have and (TYPE_LABEL[r.kind] .. (isSnoozed(r) and "  |  Snoozed" or "  |  Changes save automatically.")) or "Add a reminder to begin.")
end
function M.add(kind)
    if locked() then msg("Add reminders out of combat."); return end
    if #DB.reminders >= 24 then msg("Maximum 24 reminders."); return end
    local r = makeReminder(kind)
    if kind == "weapon" and DB.reminders[#DB.reminders - 1] and DB.reminders[#DB.reminders - 1].kind == "weapon" then
        -- New oil/lure rules start as non-fishing; switch to Fishing in the editor if desired.
        r.name = "Weapon Buff"
    end
    selected = #DB.reminders
    offset = math.floor((selected-1)/8) * 8
    refreshList(); refreshEditor(); refreshButtons()
end
-- A tiny in-game inventory picker avoids making the user look up item IDs.
local function bagSlotCount(bag)
    if C_Container and C_Container.GetContainerNumSlots then
        local ok, n = pcall(C_Container.GetContainerNumSlots, bag)
        if ok and isReadable(n) then return n end
    end
    if GetContainerNumSlots then
        local ok, n = pcall(GetContainerNumSlots, bag)
        if ok and isReadable(n) then return n end
    end
    return 0
end
local function bagItemID(bag, slot)
    if C_Container and C_Container.GetContainerItemID then
        local ok, id = pcall(C_Container.GetContainerItemID, bag, slot)
        if ok and isReadable(id) then return id end
    end
    if GetContainerItemID then
        local ok, id = pcall(GetContainerItemID, bag, slot)
        if ok and isReadable(id) then return id end
    end
end
local function collectBags()
    local found, filter = {}, string.lower(pickerQuery or "")
    for bag = 0, (NUM_BAG_SLOTS or 4) do
        for slot = 1, bagSlotCount(bag) do
            local id = bagItemID(bag, slot)
            if id and not found[id] then
                local name = itemName(id) or ("Item #" .. id)
                if filter == "" or string.find(string.lower(name), filter, 1, true) or string.find(tostring(id), filter, 1, true) then
                    found[id] = {id=id, name=name, count=itemCount(id)}
                end
            end
        end
    end
    pickerItems = {}
    for _, entry in pairs(found) do table.insert(pickerItems, entry) end
    table.sort(pickerItems, function(a,b) return a.name:lower() < b.name:lower() end)
end
local function updatePicker()
    if not picker then return end
    collectBags()
    pickerOffset = math.max(0, math.min(pickerOffset, math.max(0,#pickerItems-10)))
    for i, btn in ipairs(pickerButtons) do
        local entry = pickerItems[pickerOffset+i]
        btn:SetShown(entry ~= nil)
        if entry then btn:SetText(entry.name .. "  (" .. entry.count .. ")") end
    end
    picker.page:SetText(#pickerItems > 0 and (math.min(pickerOffset+1,#pickerItems) .. "-" .. math.min(pickerOffset+10,#pickerItems) .. " / " .. #pickerItems) or "No matching items")
end
local function buildPicker()
    picker = CreateFrame("Frame", "BuffHeroBagPicker", UIParent, "BackdropTemplate")
    picker:SetSize(392, 466)
    picker:SetPoint("CENTER")
    picker:SetFrameStrata("TOOLTIP")
    picker:SetToplevel(true)
    picker:EnableMouse(true)
    picker:SetMovable(true)
    picker:RegisterForDrag("LeftButton")
    picker:SetScript("OnDragStart", function(self) self:StartMoving() end)
    picker:SetScript("OnDragStop", function(self) self:StopMovingOrSizing() end)
    picker:SetBackdrop({bgFile="Interface\\DialogFrame\\UI-DialogBox-Background", edgeFile="Interface\\DialogFrame\\UI-DialogBox-Border", tile=true, tileSize=32, edgeSize=32, insets={left=9,right=9,top=9,bottom=9}})
    makeText(picker, "Choose an item from your bags", 18, -22, "GameFontNormalLarge")
    makeButton(picker, "X", 345, -19, 27, 24, function() picker:Hide() end)
    makeText(picker, "Filter", 18, -67, "GameFontHighlightSmall")
    picker.search = CreateFrame("EditBox", nil, picker, "InputBoxTemplate")
    picker.search:SetSize(278, 23)
    picker.search:SetPoint("TOPLEFT", 72, -60)
    picker.search:SetAutoFocus(false)
    picker.search:SetScript("OnTextChanged", function(self)
        pickerQuery = self:GetText()
        pickerOffset = 0
        updatePicker()
    end)
    picker.search:SetScript("OnEscapePressed", function(self) self:ClearFocus() end)
    picker.search:SetScript("OnEnterPressed", function(self) self:ClearFocus() end)
    for i=1,10 do
        pickerButtons[i] = makeButton(picker, "", 19, -102-(i-1)*30, 353, 26, function()
            local entry = pickerItems[pickerOffset+i]
            local r = selectedReminder()
            if not entry or not r then return end
            r.actionID = entry.id
            picker:Hide()
            refreshEditor()
            refreshList()
            refreshButtons()
        end)
    end
    makeButton(picker, "< Previous", 21, -413, 94, 23, function()
        pickerOffset = math.max(0,pickerOffset-10); updatePicker()
    end)
    makeButton(picker, "Next >", 278, -413, 94, 23, function()
        pickerOffset = math.min(math.max(0,#pickerItems-10),pickerOffset+10); updatePicker()
    end)
    picker.page = makeText(picker, "", 158, -419, "GameFontHighlightSmall")
    makeText(picker, "Click an item to assign it to the selected reminder.", 19, -447, "GameFontDisableSmall")
    picker:Hide()
    if UISpecialFrames then table.insert(UISpecialFrames, "BuffHeroBagPicker") end
end
function M.openPicker()
    if locked() then msg("Choose items out of combat."); return end
    local r = selectedReminder()
    if not r or r.kind == "spell" then return end
    if not picker then buildPicker() end
    pickerOffset = 0
    pickerQuery = ""
    picker.search:SetText("")
    updatePicker()
    picker:Show()
end

toggleSettings = function()
    if not settings then return end
    if settings:IsShown() then settings:Hide()
    else refreshList(); refreshEditor(); settings:Show() end
end
SLASH_BUFFHERO1="/bh"
SLASH_BUFFHERO2="/buffhero"
SlashCmdList.BUFFHERO=function(command)
    command = (command or ""):lower()
    if command == "preview" then
        if locked() then msg("Preview is only available out of combat."); return end
        if not settings then return end
        if not settings:IsShown() then settings:Show() end
        preview = not preview
        M.previewButton:SetText("Preview / Move: " .. (preview and "ON" or "OFF"))
        refreshButtons()
    elseif command == "version" then
        msg("Version " .. VERSION)
    elseif command == "help" then
        msg("/bh opens settings, /bh preview lets you position icons, /bh version shows the version.")
    else
        toggleSettings()
    end
end

local core = CreateFrame("Frame")
core:RegisterEvent("PLAYER_LOGIN")
core:RegisterEvent("PLAYER_ENTERING_WORLD")
core:RegisterEvent("PLAYER_UPDATE_RESTING")
core:RegisterEvent("BAG_UPDATE_DELAYED")
core:RegisterEvent("PLAYER_EQUIPMENT_CHANGED")
core:RegisterEvent("UNIT_INVENTORY_CHANGED")
core:RegisterEvent("UNIT_AURA")
core:RegisterEvent("WEAPON_ENCHANT_CHANGED")
core:RegisterEvent("GET_ITEM_INFO_RECEIVED")
core:RegisterEvent("PLAYER_REGEN_ENABLED")
core:SetScript("OnEvent", function(_, event, arg1)
    if event == "PLAYER_LOGIN" then
        readDB()
        buildSettings()
        createMinimapButton()
        refreshList()
        refreshButtons()
        return
    end
    if not DB then return end
    if event == "GET_ITEM_INFO_RECEIVED" then
        for _, f in pairs(anchors) do f.placementKey = nil end
    end
    if event == "UNIT_AURA" or event == "UNIT_INVENTORY_CHANGED" then
        if arg1 ~= "player" then return end
    end
    refreshButtons()
end)
core:SetScript("OnUpdate", function(_, elapsed)
    if not DB then return end
    animateFlash(elapsed)
    if locked() then return end
    nextTick = nextTick + elapsed
    if nextTick >= 2 then nextTick = 0; refreshButtons() end
end)
