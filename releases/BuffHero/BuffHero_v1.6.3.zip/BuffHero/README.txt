Buff Hero v1.6.2 for WoW Forever

INSTALL
Unzip BuffHero into World of Warcraft/_forever_/Interface/AddOns.
Replace your existing BuffHero folder and type /reload.
Do not delete your SavedVariables; existing reminder settings are preserved.

COMMANDS
/bh                  Open or close Buff Hero settings
/bh preview          Move reminder icons (out of combat)
/bh version          Print installed addon version

FIXED IN v1.6.2
- Clear minimap hover tooltip with click and drag instructions.
- Explicit mouse enable and owner-aware tooltip cleanup.

FIXED IN v1.6.1
- Minimap strength-arm icon and its gold ring now align correctly.
  The Blizzard MiniMap-TrackingBorder texture needs a TOPLEFT anchor;
  centering its whole canvas offset the visible ring from the icon.
- Preserves your minimap button position, icon toggle, drag placement,
  left-click to open settings, and right-click to pause/resume reminders.
- No changes to reminder behavior, other settings, or SavedVariables.

CARRIED FORWARD FROM v1.6.0
- Optional minimap button in Extra Settings.
- Global hide-while-resting checkbox alongside per-reminder settings.
- Combat hiding, dungeon flash options, solid settings panel and RIP Shady footer.

TESTING
- Packaging, version consistency, and structural placement checked.
- In-game visual alignment and button behavior remain to be verified on WoW Forever.
