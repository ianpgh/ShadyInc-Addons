local ADDON = ...
local VERSION = "1.1.0"
local db, lastHK, playerGUID, attached, baseHeight, hooked
local ready, retryGeneration = false, 0
local events = CreateFrame("Frame")
local function readable(v, kind)
    if type(issecretvalue)=="function" and issecretvalue(v) then return false end
    return type(v)==kind
end
local function number(v)
    if readable(v,"number") and v>=0 and v<math.huge and v==math.floor(v) then return v end
end
local function readCounter(fn)
    if type(fn)~="function" then return nil end
    local ok,v=pcall(fn)
    if ok then return number(v) end
end
local function say(s) print("|cffffd34dShady Kill Tracker:|r "..s) end
local function border(f)
    f:SetBackdrop({bgFile="Interface\\ChatFrame\\ChatFrameBackground",edgeFile="Interface\\Tooltips\\UI-Tooltip-Border",tile=false,edgeSize=9,insets={left=2,right=2,top=2,bottom=2}})
    f:SetBackdropColor(.02,.03,.06,1)
    f:SetBackdropBorderColor(.68,.59,.31,1)
end
local hud=CreateFrame("Frame","ShadyKillTrackerWindow",UIParent,"BackdropTemplate")
hud:SetFrameStrata("HIGH")
hud:SetClampedToScreen(true)
hud:SetMovable(true)
border(hud)
hud:Hide()
local function font(f, size, r,g,b)
    local t=f:CreateFontString(nil,"OVERLAY","GameFontNormalSmall")
    t:SetFont("Fonts\\FRIZQT__.TTF",size,"OUTLINE")
    t:SetTextColor(r,g,b)
    t:SetJustifyH("CENTER")
    return t
end
local function makeRow(label,isKB)
    local f=CreateFrame("Frame",nil,hud)
    f:SetHeight(25)
    f:EnableMouse(true)
    f:RegisterForDrag("LeftButton")
    local l=font(f,9,1,.9,.58)
    l:SetPoint("TOP",f,"TOP",0,-1); l:SetText(label)
    f.value=font(f,11,isKB and .4 or 1,isKB and 1 or .83,isKB and .45 or .2)
    f.value:SetPoint("TOP",f,"TOP",0,-11)
    f:SetScript("OnEnter",function(self)
        if not db or not GameTooltip then return end
        GameTooltip:SetOwner(self,"ANCHOR_LEFT")
        GameTooltip:AddLine(isKB and "PvP Killing Blows" or "Honorable Kills",1,.83,.22)
        GameTooltip:AddDoubleLine("Session",tostring(isKB and db.kb or db.hk),1,1,1,1,1,1)
        if isKB then
            GameTooltip:AddDoubleLine("All-time tracked",tostring(db.totalKB),1,1,1,1,1,1)
            GameTooltip:AddLine("Since addon installation; older kills unavailable.",.75,.75,.75,true)
        else
            local lifetime=readCounter(GetPVPLifetimeStats)
            GameTooltip:AddDoubleLine("Character lifetime",lifetime and tostring(lifetime) or "Unavailable",1,1,1,1,1,1)
        end
        GameTooltip:AddLine("/skt for settings",.6,.9,1)
        GameTooltip:Show()
    end)
    f:SetScript("OnLeave",function(self) if GameTooltip and GameTooltip:IsOwned(self) then GameTooltip:Hide() end end)
    f:SetScript("OnDragStart",function() if db and not attached and not db.locked then hud:StartMoving() end end)
    f:SetScript("OnDragStop",function()
        if attached or not db then return end
        hud:StopMovingOrSizing()
        local x,y=hud:GetCenter(); local px,py=UIParent:GetCenter()
        if x and y and px and py then db.x,db.y=x-px,y-py end
    end)
    return f
end
local hkRow,kbRow=makeRow("HKs",false),makeRow("KBs",true)
local function refresh()
    if not db then return end
    local function display(row,n)
        local s=tostring(n)
        row.value:SetFont("Fonts\\FRIZQT__.TTF",#s>5 and 8 or (#s>4 and 9 or 11),"OUTLINE")
        row.value:SetText(s)
    end
    display(hkRow,db.hk); display(kbRow,db.kb)
end
local function layout(fromHost)
    if not db then return end
    local host=_G.FrameShiftFPSOverlay
    local useHost=db.dock and host and type(host.SetLayout)=="function" and type(hooksecurefunc)=="function"
    if useHost and hooked~=host then
        local ok=pcall(hooksecurefunc,host,"SetLayout",function(self)
            if db and attached==self then baseHeight=self:GetHeight(); layout(true) end
        end)
        if ok then hooked=host else useHost=false end
    end
    if attached and (not useHost or attached~=host) then
        if baseHeight then attached:SetHeight(baseHeight) end
        attached=nil; baseHeight=nil
    end
    if useHost and attached~=host then
        attached=host; baseHeight=host:GetHeight()
    end
    local height=db.showKB and 50 or 25
    hud:ClearAllPoints()
    if attached then
        hud:SetParent(attached)
        hud:SetBackdropColor(0,0,0,0); hud:SetBackdropBorderColor(0,0,0,0)
        hud:SetFrameLevel(attached:GetFrameLevel()+2)
        hud:SetPoint("TOPLEFT",attached,"TOPLEFT",0,-baseHeight+2)
        hud:SetWidth(attached:GetWidth()); hud:SetHeight(height+1)
        attached:SetHeight(baseHeight+(db.hidden and 0 or height))
    else
        hud:SetParent(UIParent); hud:SetFrameLevel(5); border(hud)
        hud:SetSize(42,height+4)
        if db.x and db.y then hud:SetPoint("CENTER",UIParent,"CENTER",db.x,db.y)
        else hud:SetPoint("TOPRIGHT",UIParent,"TOPRIGHT",-2,-58) end
    end
    hkRow:ClearAllPoints(); hkRow:SetPoint("TOPLEFT",hud,"TOPLEFT",2,-1); hkRow:SetPoint("TOPRIGHT",hud,"TOPRIGHT",-2,-1)
    kbRow:ClearAllPoints(); kbRow:SetPoint("TOPLEFT",hkRow,"BOTTOMLEFT",0,0); kbRow:SetPoint("TOPRIGHT",hkRow,"BOTTOMRIGHT",0,0)
    kbRow:SetShown(db.showKB)
    hud:SetShown(not db.hidden)
    refresh()
end
local function updateHK()
    if not ready then return end
    local v=readCounter(GetPVPSessionStats)
    if v==nil then return end
    if lastHK~=nil and v>lastHK then db.hk=db.hk+v-lastHK end
    lastHK=v; refresh()
end
local function retryHK()
    retryGeneration=retryGeneration+1
    local generation=retryGeneration
    updateHK()
    if C_Timer and C_Timer.After then
        for _,delay in ipairs({.25,1,2}) do C_Timer.After(delay,function() if generation==retryGeneration then updateHK() end end) end
    end
end
local function getGUID()
    local ok,v=pcall(UnitGUID,"player")
    if ok and readable(v,"string") and v~="" then return v end
end
local function countKB(attacker,victim)
    if not ready or not readable(attacker,"string") or not readable(victim,"string") then return end
    playerGUID=playerGUID or getGUID()
    if not playerGUID or attacker~=playerGUID or victim==playerGUID or victim:sub(1,7)~="Player-" then return end
    db.kb=db.kb+1; db.totalKB=db.totalKB+1; refresh()
end
local function reset()
    if not ready then return end
    local v=readCounter(GetPVPSessionStats)
    if v==nil then say("Reset unavailable until HK counter is readable."); return end
    retryGeneration=retryGeneration+1; lastHK=v; db.hk,db.kb=0,0; refresh(); say("Session reset. Lifetime totals preserved.")
end
local panel=CreateFrame("Frame","ShadyKillTrackerSettings",UIParent,"BackdropTemplate")
panel:SetSize(292,218); panel:SetPoint("CENTER"); panel:SetFrameStrata("DIALOG"); panel:EnableMouse(true); border(panel); panel:Hide()
local title=panel:CreateFontString(nil,"OVERLAY","GameFontNormalLarge"); title:SetPoint("TOPLEFT",14,-14); title:SetText("Shady Kill Tracker")
local close=CreateFrame("Button",nil,panel,"UIPanelCloseButton"); close:SetPoint("TOPRIGHT",-3,-3)
close:SetScript("OnClick",function() panel:Hide() end)
local function check(label,key,y,change)
    local b=CreateFrame("CheckButton",nil,panel,"UICheckButtonTemplate"); b:SetPoint("TOPLEFT",12,y)
    local t=panel:CreateFontString(nil,"OVERLAY","GameFontHighlight"); t:SetPoint("LEFT",b,"RIGHT",4,0); t:SetText(label)
    b:SetScript("OnClick",function(self) db[key]=self:GetChecked() and true or false; if change then change() end end)
    return b
end
local kbCheck=check("Show killing blows (KBs)","showKB",-45,layout)
local dockCheck=check("Dock inside FrameShift HUD","dock",-76,layout)
local lockCheck=check("Lock standalone position","locked",-107)
local resetButton=CreateFrame("Button",nil,panel,"UIPanelButtonTemplate"); resetButton:SetSize(120,24); resetButton:SetPoint("TOPLEFT",16,-145); resetButton:SetText("Reset session"); resetButton:SetScript("OnClick",reset)
local showButton=CreateFrame("Button",nil,panel,"UIPanelButtonTemplate"); showButton:SetSize(120,24); showButton:SetPoint("LEFT",resetButton,"RIGHT",12,0); showButton:SetText("Show HUD"); showButton:SetScript("OnClick",function() db.hidden=false; layout() end)
local footer=panel:CreateFontString(nil,"OVERLAY","GameFontDisableSmall"); footer:SetPoint("BOTTOM",0,12); footer:SetText("RIP Shady  |  v"..VERSION)
if type(UISpecialFrames)=="table" then table.insert(UISpecialFrames,"ShadyKillTrackerSettings") end
local function toggleSettings()
    if panel:IsShown() then panel:Hide(); return end
    kbCheck:SetChecked(db.showKB); dockCheck:SetChecked(db.dock); lockCheck:SetChecked(db.locked); panel:Show()
end
SLASH_SHADYKILLTRACKER1="/skt"; SLASH_SHADYKILLTRACKER2="/shadykilltracker"
SlashCmdList.SHADYKILLTRACKER=function(msg)
    if not db then return end
    local cmd=(msg or ""):lower():match("^%s*(.-)%s*$")
    if cmd=="" or cmd=="settings" then toggleSettings()
    elseif cmd=="kb" then db.showKB=not db.showKB; kbCheck:SetChecked(db.showKB); layout()
    elseif cmd=="reset" then reset()
    elseif cmd=="hide" then db.hidden=true; layout()
    elseif cmd=="show" then db.hidden=false; layout()
    elseif cmd=="toggle" then db.hidden=not db.hidden; layout()
    elseif cmd=="lock" then db.locked=true; lockCheck:SetChecked(true)
    elseif cmd=="unlock" then db.locked=false; lockCheck:SetChecked(false)
    elseif cmd=="recenter" then db.dock=false; dockCheck:SetChecked(false); db.x,db.y=0,160; db.hidden=false; layout()
    else say("/skt [kb|reset|show|hide|toggle|lock|unlock|recenter]") end
end
local function load()
    if type(ShadyKillTrackerDB)~="table" then ShadyKillTrackerDB={} end
    db=ShadyKillTrackerDB
    db.hk,db.kb=number(db.hk) or 0,number(db.kb) or 0
    db.totalKB=math.max(number(db.totalKB) or db.kb,db.kb)
    db.showKB=db.showKB==true; db.dock=db.dock~=false; db.hidden=db.hidden==true; db.locked=db.locked==true
    if not readable(db.x,"number") or db.x~=db.x or math.abs(db.x)>10000 then db.x=nil end
    if not readable(db.y,"number") or db.y~=db.y or math.abs(db.y)>10000 then db.y=nil end
    -- Old window position was a large floating panel; docking is now the default.
    if not db.schema110 then db.x,db.y=nil,nil; db.schema110=true end
    layout()
end
local elapsed=0
-- Lightweight late-load detection for FrameShift's lazily-created overlay.
events:SetScript("OnUpdate",function(_,dt)
    if not db or not db.dock or attached then return end
    elapsed=elapsed+dt; if elapsed>=1 then elapsed=0; if _G.FrameShiftFPSOverlay then layout() end end
end)
events:SetScript("OnEvent",function(_,event,...)
    if event=="ADDON_LOADED" then
        if ...==ADDON then load() elseif db and db.dock and not attached then layout() end
    elseif event=="PLAYER_ENTERING_WORLD" and db then
        playerGUID=getGUID(); if not ready then lastHK=readCounter(GetPVPSessionStats); ready=true else updateHK() end; layout()
    elseif event=="PLAYER_PVP_KILLS_CHANGED" then retryHK()
    elseif event=="PARTY_KILL" then countKB(...)
    elseif event=="PLAYER_LOGOUT" then updateHK() end
end)
for _,event in ipairs({"ADDON_LOADED","PLAYER_ENTERING_WORLD","PLAYER_PVP_KILLS_CHANGED","PARTY_KILL","PLAYER_LOGOUT"}) do
    local ok=pcall(events.RegisterEvent,events,event); if not ok then say("Event unavailable: "..event) end
end
