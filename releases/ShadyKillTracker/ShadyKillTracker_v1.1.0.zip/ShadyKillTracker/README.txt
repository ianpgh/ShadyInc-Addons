Shady Kill Tracker 1.1.0 | WoW Forever
Replace the old ShadyKillTracker addon folder; keep SavedVariables.
The HK row docks inside the FrameShift FPS overlay (verified against the
FrameShift 1.1.9 source); the optional KB row is off by default. A small
standalone movable counter is used when FrameShift is unavailable. If the
FrameShift overlay is hidden, its docked rows are hidden with it.
/skt opens settings. /skt kb toggles KBs. /skt reset resets session counts,
not lifetime totals. Session means since the last manual reset, across reloads
and logins. Hover HKs to see Blizzard's character lifetime HK count; hover KBs
for tracked all-time personal PvP KBs (not pre-install history). KB counts
continue while hidden, excluding non-player victims and other attackers.
Existing session counts are migrated; lifetime tracked KBs from v1.0.0 are
limited to the old retained session total. Secret/unavailable data is skipped.
/skt hide, show, toggle, lock, unlock, recenter are also available.
No FrameShift file changes; optional runtime integration only. Live testing
is required for the WoW Forever client and actual kill event availability.
