local addonName = ...
local VERSION = "1.0.0"
local db, lastHK, playerGUID
local ready = false
local events = CreateFrame("Frame")
local window = CreateFrame("Frame", "ShadyKillTrackerWindow", UIParent, "BackdropTemplate")
window:SetSize(210, 76)
window:SetPoint("CENTER", UIParent, "CENTER", 0, 160)
window:SetClampedToScreen(true)
window:SetMovable(true)
window:SetFrameStrata("MEDIUM")
window:SetBackdrop({bgFile="Interface\\Buttons\\WHITE8X8", edgeFile="Interface\\Buttons\\WHITE8X8", edgeSize=1})
window:SetBackdropColor(0.045,0.045,0.055,1)
window:SetBackdropBorderColor(0.32,0.32,0.36,1)
window:Hide()

local function font(parent, template, point, relative, relativePoint, x, y, label)
    local f = parent:CreateFontString(nil,"OVERLAY",template)
    f:SetPoint(point,relative,relativePoint,x,y)
    f:SetText(label or "")
    return f
end
local header = CreateFrame("Frame",nil,window)
header:SetPoint("TOPLEFT",window,"TOPLEFT",0,0)
header:SetPoint("TOPRIGHT",window,"TOPRIGHT",-49,0)
header:SetHeight(25)
header:EnableMouse(true)
header:RegisterForDrag("LeftButton")
local title = font(header,"GameFontNormalSmall","LEFT",header,"LEFT",9,0,"Shady Kill Tracker")
local line = window:CreateTexture(nil,"ARTWORK")
line:SetColorTexture(0.25,0.25,0.29,1)
line:SetPoint("TOPLEFT",window,"TOPLEFT",8,-25)
line:SetPoint("TOPRIGHT",window,"TOPRIGHT",-8,-25)
line:SetHeight(1)
local hkLabel = font(window,"GameFontHighlightSmall","TOPLEFT",window,"TOPLEFT",10,-33,"Honorable Kills")
local kbLabel = font(window,"GameFontHighlightSmall","TOPLEFT",window,"TOPLEFT",10,-53,"PvP Killing Blows")
local hkValue = font(window,"GameFontNormalLarge","TOPRIGHT",window,"TOPRIGHT",-10,-29,"0")
hkValue:SetTextColor(1,0.88,0.24)
local kbValue = font(window,"GameFontNormalLarge","TOPRIGHT",window,"TOPRIGHT",-10,-49,"0")
kbValue:SetTextColor(0.4,1,0.45)
local function refresh()
    if not db then return end
    hkValue:SetText(tostring(db.hk))
    kbValue:SetText(tostring(db.kb))
end
local function readable(v, kind)
    if type(issecretvalue)=="function" and issecretvalue(v) then return false end
    return type(v)==kind
end
local function cleanNumber(v)
    if not readable(v,"number") or v~=v or v<0 or v==math.huge then return 0 end
    return math.floor(v)
end
local function readHK()
    if type(GetPVPSessionStats)~="function" then return nil end
    local ok, value = pcall(GetPVPSessionStats)
    if ok and readable(value,"number") and value>=0 and value<math.huge and value==math.floor(value) then return value end
end
local function updateHK()
    if not ready then return end
    local value = readHK()
    if value==nil then return end
    if lastHK~=nil and value>lastHK then db.hk=db.hk+(value-lastHK) end
    -- A Blizzard session reset establishes a new baseline rather than subtracting kills.
    lastHK=value
    refresh()
end
local retryGeneration=0
local function retryHK()
    retryGeneration=retryGeneration+1
    local generation=retryGeneration
    updateHK()
    if C_Timer and C_Timer.After then
        for _, delay in ipairs({0.25,1,2}) do
            C_Timer.After(delay,function()
                if generation==retryGeneration then updateHK() end
            end)
        end
    end
end
local function readPlayerGUID()
    local ok, guid=pcall(UnitGUID,"player")
    if ok and readable(guid,"string") and guid~="" then return guid end
end
local function countKB(attacker,victim)
    if not ready then return end
    if not readable(attacker,"string") or not readable(victim,"string") then return end
    playerGUID=playerGUID or readPlayerGUID()
    if not playerGUID or attacker~=playerGUID then return end
    if victim:sub(1,7)~="Player-" or victim==playerGUID then return end
    db.kb=db.kb+1
    refresh()
end
local function say(message)
    print("|cffffd34dShady Kill Tracker:|r "..message)
end
local function reset()
    if not ready then return end
    local baseline=readHK()
    if baseline==nil then say("Reset unavailable until the HK counter is readable."); return end
    retryGeneration=retryGeneration+1
    lastHK=baseline
    db.hk,db.kb=0,0
    refresh()
    say("Session reset.")
end
local function savePosition()
    local x,y=window:GetCenter()
    local px,py=UIParent:GetCenter()
    if x and y and px and py then db.x,db.y=x-px,y-py end
end
local function restorePosition()
    window:ClearAllPoints()
    window:SetPoint("CENTER",UIParent,"CENTER",db.x or 0,db.y or 160)
end
header:SetScript("OnDragStart",function()
    if db and not db.locked then window:StartMoving() end
end)
header:SetScript("OnDragStop",function()
    window:StopMovingOrSizing()
    if db then savePosition() end
end)
window:SetScript("OnHide",function()
    window:StopMovingOrSizing()
end)
local function button(label,x,tip,action)
    local b=CreateFrame("Button",nil,window)
    b:SetSize(22,22)
    b:SetPoint("TOPRIGHT",window,"TOPRIGHT",x,-1)
    b:SetNormalFontObject("GameFontHighlightSmall")
    b:SetHighlightFontObject("GameFontNormalSmall")
    b:SetText(label)
    b:SetHighlightTexture("Interface\\Buttons\\UI-Common-MouseHilight","ADD")
    b:SetScript("OnClick",action)
    b:SetScript("OnEnter",function(self)
        GameTooltip:SetOwner(self,"ANCHOR_TOP")
        GameTooltip:SetText(tip)
        GameTooltip:Show()
    end)
    b:SetScript("OnLeave",function(self)
        if GameTooltip:IsOwned(self) then GameTooltip:Hide() end
    end)
    return b
end
button("R",-24,"Shift-click to reset both counters",function()
    if IsShiftKeyDown() then reset() else say("Shift-click R to reset, or use /skt reset.") end
end)
button("X",-2,"Hide tracker (/skt show to reopen)",function()
    if db then db.hidden=true; window:Hide() end
end)
local function show()
    db.hidden=false
    window:Show()
end
SLASH_SHADYKILLTRACKER1="/skt"
SLASH_SHADYKILLTRACKER2="/shadykilltracker"
SlashCmdList.SHADYKILLTRACKER=function(message)
    if not db then return end
    local cmd=(message or ""):lower():match("^%s*(.-)%s*$")
    if cmd=="" or cmd=="toggle" then
        if window:IsShown() then db.hidden=true; window:Hide() else show() end
    elseif cmd=="show" then show()
    elseif cmd=="hide" then db.hidden=true; window:Hide()
    elseif cmd=="reset" then reset()
    elseif cmd=="lock" then db.locked=true; say("Position locked.")
    elseif cmd=="unlock" then db.locked=false; say("Drag the title to move.")
    elseif cmd=="recenter" then db.x,db.y=0,160; restorePosition(); show()
    else say("v"..VERSION.." | /skt show, hide, reset, lock, unlock, recenter, toggle") end
end
local function load()
    if type(ShadyKillTrackerDB)~="table" then ShadyKillTrackerDB={} end
    db=ShadyKillTrackerDB
    db.hk,db.kb=cleanNumber(db.hk),cleanNumber(db.kb)
    if not readable(db.x,"number") or math.abs(db.x)>10000 then db.x=0 end
    if not readable(db.y,"number") or math.abs(db.y)>10000 then db.y=160 end
    if db.x~=db.x then db.x=0 end
    if db.y~=db.y then db.y=160 end
    db.hidden=db.hidden==true
    db.locked=db.locked==true
    restorePosition()
    refresh()
    if not db.hidden then window:Show() end
end
local function register(event)
    local ok=pcall(events.RegisterEvent,events,event)
    if not ok then say("Event unavailable: "..event) end
end
events:SetScript("OnEvent",function(_,event,...)
    if event=="ADDON_LOADED" then
        if ...==addonName then load(); events:UnregisterEvent("ADDON_LOADED") end
    elseif event=="PLAYER_ENTERING_WORLD" and db then
        playerGUID=readPlayerGUID()
        if not ready then lastHK=readHK(); ready=true else updateHK() end
    elseif event=="PLAYER_PVP_KILLS_CHANGED" then retryHK()
    elseif event=="PARTY_KILL" then countKB(...)
    elseif event=="PLAYER_LOGOUT" then updateHK() end
end)
register("ADDON_LOADED")
register("PLAYER_ENTERING_WORLD")
register("PLAYER_PVP_KILLS_CHANGED")
register("PARTY_KILL")
register("PLAYER_LOGOUT")
