Shady Kill Tracker 1.0.0 | WoW Forever (Interface 16001)
Install: extract the ShadyKillTracker folder into _forever_/Interface/AddOns.
Drag the title to move. R (Shift-click) resets both counters; X hides.
/skt toggles; /skt show, hide, reset, lock, unlock, recenter, help.
Counts and position persist per character until manually reset.
HKs: Blizzard GetPVPSessionStats deltas on PLAYER_PVP_KILLS_CHANGED.
KBs: PARTY_KILL with a readable player attacker GUID matching your own
and a player victim GUID. PvP only; pet and party member kills excluded.
Secret/unavailable values are skipped rather than inferred. No combat log,
scoreboard or other addon dependency. Counts may underreport when the client
withholds data; live Forever testing is still required.
