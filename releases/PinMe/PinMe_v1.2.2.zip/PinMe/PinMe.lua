local _, addon = ...
local events = CreateFrame("Frame")
local db, world, canvas, layer, placement
local markers = {}
local lastMap, lastWidth, lastHeight
local graveyardMap, graveyards, graveyardRefreshAt
local classicMap, classicGraveyards
local graveyardButton, graveyardStatus, liveGraveyardCount = nil, "not scanned", 0
local pendingPin, coordinateMapID
local Refresh
local openMapRegistered, openMapDirty, lastStitched, lastArtLevel
local renderedGraveyards, renderer = 0, "Blizzard"

local function OpenMap()
    local om = _G.OpenMapAPI
    if type(om) == "table" and om.major == 1 and type(om.IsStitched) == "function" then return om end
end

local function Stitched(om)
    if not om then return false end
    local ok, value = pcall(om.IsStitched)
    return ok and value == true
end

local function ArtLevel(om)
    if not om or type(om.ArtTopLevel) ~= "function" then return nil end
    local ok, level = pcall(om.ArtTopLevel)
    if ok and type(level) == "number" then return level end
end

local function RegisterOpenMap()
    local om = OpenMap()
    if not om or om == openMapRegistered or type(om.RegisterCallback) ~= "function" then return end
    if openMapRegistered and type(openMapRegistered.UnregisterAllCallbacks) == "function" then
        pcall(openMapRegistered.UnregisterAllCallbacks, events)
    end
    local function Changed() openMapDirty = true end
    local ok = pcall(om.RegisterCallback, events, "OpenMap_ViewChanged", Changed)
    local ok2 = pcall(om.RegisterCallback, events, "OpenMap_StitchedChanged", Changed)
    if ok and ok2 then openMapRegistered = om end
    openMapDirty = true
end

local function Message(text)
    print("|cffffd277Pin Me:|r " .. text)
end

local function Coordinate(value)
    return type(value) == "number"
        and not (issecretvalue and issecretvalue(value))
        and value >= 0 and value <= 1
end

local function ValidMapID(mapID)
    return type(mapID) == "number" and not (issecretvalue and issecretvalue(mapID))
        and mapID > 0 and mapID == math.floor(mapID)
end

local function CloseTooltip(owner)
    if GameTooltip:IsOwned(owner) then GameTooltip:Hide() end
end

local function EditBox(dialog)
    return dialog.GetEditBox and dialog:GetEditBox() or dialog.editBox
end

local function SavePin(name)
    local pin = pendingPin
    pendingPin = nil
    if not pin then return end
    name = name:match("^%s*(.-)%s*$")
    if name == "" then
        Message("Enter a name to save the pin.")
        return
    end
    if pin.record then
        pin.record.name = name
    else
        local pins = db.maps[pin.mapID]
        if not pins then pins = {}; db.maps[pin.mapID] = pins end
        pins[#pins + 1] = {name = name, x = pin.x, y = pin.y, graveyard = pin.graveyard}
    end
    Refresh()
end

StaticPopupDialogs.PINME_NAME = {
    text = "Name this map pin",
    button1 = SAVE or "Save",
    button2 = CANCEL or "Cancel",
    hasEditBox = true,
    maxLetters = 80,
    timeout = 0,
    whileDead = true,
    hideOnEscape = true,
    OnShow = function(self)
        local box = EditBox(self)
        box:SetText(pendingPin and pendingPin.record and pendingPin.record.name or "")
        box:HighlightText()
        box:SetFocus()
    end,
    OnAccept = function(self) SavePin(EditBox(self):GetText()) end,
    EditBoxOnEnterPressed = function(self)
        SavePin(self:GetText())
        StaticPopup_Hide("PINME_NAME")
    end,
    OnHide = function() pendingPin = nil end,
}

StaticPopupDialogs.PINME_DELETE = {
    text = "Delete this Pin Me marker?",
    button1 = DELETE or "Delete",
    button2 = CANCEL or "Cancel",
    timeout = 0,
    whileDead = true,
    hideOnEscape = true,
    OnAccept = function(_, data)
        local pins = db.maps[data.mapID]
        for index, record in ipairs(pins or {}) do
            if record == data.record then
                table.remove(pins, index)
                Refresh()
                break
            end
        end
    end,
}

local function NamePin(pin)
    StaticPopup_Hide("PINME_NAME")
    pendingPin = pin
    if not StaticPopup_Show("PINME_NAME") then
        pendingPin = nil
        Message("Close an open dialog and try again.")
    end
end

local function CoordinateMap()
    if world and world:IsShown() then return world:GetMapID() end
    return C_Map and C_Map.GetBestMapForUnit and C_Map.GetBestMapForUnit("player")
end

local function AddWaypoint(input, mapID)
    local x, y = input:match("^%s*(%d*%.?%d+)%s*,%s*(%d*%.?%d+)%s*$")
    if not x then x, y = input:match("^%s*(%d*%.?%d+)%s+(%d*%.?%d+)%s*$") end
    x, y = tonumber(x), tonumber(y)
    if not x or not y or x > 100 or y > 100 then
        Message("Enter two coordinates from 0 to 100, such as 42.5, 63.2.")
        return false
    end
    if not ValidMapID(mapID) then
        Message("Open a zone map before entering coordinates.")
        return false
    end

    local name = ("Waypoint %.2f, %.2f"):format(x, y)
    StaticPopup_Hide("PINME_NAME")
    pendingPin = {mapID = mapID, x = x / 100, y = y / 100}
    SavePin(name)
    Message("Saved " .. name .. ".")
    return true
end

StaticPopupDialogs.PINME_COORDS = {
    text = "Enter coordinates for this map (e.g. 42.5, 63.2)",
    button1 = "Add Waypoint",
    button2 = CANCEL or "Cancel",
    hasEditBox = true,
    maxLetters = 40,
    timeout = 0,
    whileDead = true,
    hideOnEscape = true,
    OnShow = function(self)
        local box = EditBox(self)
        box:SetText("")
        box:SetFocus()
    end,
    OnAccept = function(self) AddWaypoint(EditBox(self):GetText(), coordinateMapID) end,
    EditBoxOnEnterPressed = function(self)
        if AddWaypoint(self:GetText(), coordinateMapID) then
            StaticPopup_Hide("PINME_COORDS")
        end
    end,
    OnHide = function() coordinateMapID = nil end,
}

local function OpenCoordinates()
    local mapID = CoordinateMap()
    if not ValidMapID(mapID) then
        Message("Open a zone map before entering coordinates.")
        return
    end
    if placement then placement:Hide() end
    StaticPopup_Hide("PINME_COORDS")
    coordinateMapID = mapID
    if not StaticPopup_Show("PINME_COORDS") then
        coordinateMapID = nil
        Message("Close an open dialog and try again.")
    end
end

local function Marker(index)
    if markers[index] then return markers[index] end
    local button = CreateFrame("Button", nil, layer)
    button:SetSize(19, 19)
    button:SetFrameLevel(layer:GetFrameLevel() + 1)
    button:RegisterForClicks("LeftButtonUp", "RightButtonUp")
    local icon = button:CreateTexture(nil, "ARTWORK")
    icon:SetAllPoints()
    button.icon = icon
    button:SetScript("OnEnter", function(self)
        local pin = self.record
        if not pin then return end
        GameTooltip:SetOwner(self, "ANCHOR_RIGHT")
        GameTooltip:SetText(pin.name)
        GameTooltip:AddLine(("%.1f, %.1f"):format(pin.x * 100, pin.y * 100), 1, 1, 1)
        if pin.graveyard then
            GameTooltip:AddLine(pin.classic and "Graveyard (Classic data)" or "Graveyard", 0.75, 0.85, 1)
        end
        if self.custom then GameTooltip:AddLine("Left-click to rename. Right-click to delete.", 0.85, 0.85, 0.85) end
        GameTooltip:Show()
    end)
    button:SetScript("OnLeave", CloseTooltip)
    button:SetScript("OnHide", CloseTooltip)
    button:SetScript("OnClick", function(self, mouseButton)
        if not self.custom then return end
        local data = {mapID = self.mapID, record = self.record}
        if mouseButton == "RightButton" then
            StaticPopup_Show("PINME_DELETE", nil, nil, data)
        else
            NamePin(data)
        end
    end)
    markers[index] = button
    return button
end

-- Read both mixin vectors and plain coordinate tables without propagating client errors.
local function XY(point)
    if not point then return end
    local ok, x, y = pcall(function()
        if point.GetXY then return point:GetXY() end
        return point.x, point.y
    end)
    if ok and type(x) == "number" and type(y) == "number"
        and not (issecretvalue and (issecretvalue(x) or issecretvalue(y)))
        and x == x and y == y then return x, y end
end

local function WorldAt(mapID, x, y)
    if not (C_Map and C_Map.GetWorldPosFromMapPos and CreateVector2D) then return end
    local ok, continent, point = pcall(C_Map.GetWorldPosFromMapPos, mapID, CreateVector2D(x, y))
    if not ok or type(continent) ~= "number" then return end
    local wx, wy = XY(point)
    if wx then return continent, wx, wy end
end

local function ClassicGraveyardsForMap(mapID)
    if classicMap == mapID and #classicGraveyards > 0 then return classicGraveyards end
    classicMap, classicGraveyards = mapID, {}
    local continent, ox, oy = WorldAt(mapID, 0.25, 0.25)
    local c2, rx, ry = WorldAt(mapID, 0.75, 0.25)
    local c3, dx, dy = WorldAt(mapID, 0.25, 0.75)
    local entries = addon.classicGraveyards and addon.classicGraveyards[continent]
    if not entries then
        graveyardStatus = "no Classic data for map/continent " .. tostring(continent)
        return classicGraveyards
    end
    local ax, ay, bx, by, det
    if ox and rx and dx and c2 == continent and c3 == continent then
        ax, ay, bx, by = (rx-ox)*2, (ry-oy)*2, (dx-ox)*2, (dy-oy)*2
        det = ax*by-ay*bx
    end
    for _, entry in ipairs(entries) do
        local wx, wy = entry[2], entry[1]
        local x, y
        -- Invert the map's own world transform rather than requiring the inverse API
        -- to return exactly this UI map ID (it can select a child map instead).
        if det and math.abs(det) > 0.000001 then
            local vx, vy = wx-ox, wy-oy
            x, y = 0.25+(vx*by-vy*bx)/det, 0.25+(ax*vy-ay*vx)/det
        elseif C_Map.GetMapPosFromWorldPos and CreateVector2D then
            local ok, resultMap, point = pcall(C_Map.GetMapPosFromWorldPos,
                continent, CreateVector2D(wx, wy), mapID)
            if ok and resultMap == mapID then x, y = XY(point) end
        end
        if Coordinate(x) and Coordinate(y) then
            classicGraveyards[#classicGraveyards+1] = {
                x=x, y=y, name=entry[3], graveyard=true, classic=true,
            }
        end
    end
    graveyardStatus = (det and math.abs(det)>0.000001 and "map transform" or "inverse API")
        .. "; continent " .. tostring(continent) .. "; " .. #classicGraveyards .. " Classic pins"
    return classicGraveyards
end

local function ReadGraveyards(mapID)
    local result = {}
    if C_DeathInfo and C_DeathInfo.GetGraveyardsForMap then
        local ok, entries = pcall(C_DeathInfo.GetGraveyardsForMap, mapID)
        if ok and type(entries) == "table" then
            for _, entry in ipairs(entries) do
                if type(entry) == "table" then
                    local x, y = XY(entry.position or entry)
                    if Coordinate(x) and Coordinate(y) then
                        result[#result + 1] = {x = x, y = y, name = type(entry.name) == "string" and entry.name or "Graveyard", graveyard = true}
                    end
                end
            end
        end
    end

    local liveCount = #result
    liveGraveyardCount = liveCount
    for _, record in ipairs(ClassicGraveyardsForMap(mapID)) do
        local duplicate = false
        for index = 1, liveCount do
            local live = result[index]
            if (live.x - record.x)^2 + (live.y - record.y)^2 <= 0.008^2 then
                duplicate = true
                break
            end
        end
        if not duplicate then result[#result + 1] = record end
    end
    return result
end

Refresh = function()
    if not layer or not world:IsShown() then return end
    local mapID = world:GetMapID()
    if not ValidMapID(mapID) then mapID = nil end
    local width, height = canvas:GetSize()
    local om = OpenMap()
    local stitched = Stitched(om)
    local art = stitched and ArtLevel(om) or nil
    local targetLevel = math.max(canvas:GetFrameLevel() + 15, art and art + 2 or 0)
    if layer:GetFrameLevel() ~= targetLevel then layer:SetFrameLevel(targetLevel) end
    local projected = stitched and type(om.CanvasFromWorldPos) == "function"
    renderer = stitched and (projected and "OpenMap API" or "OpenMap legacy canvas") or "Blizzard"
    lastStitched, lastArtLevel, openMapDirty = stitched, art, false
    lastMap, lastWidth, lastHeight = mapID, width, height
    local count = 0
    renderedGraveyards = 0
    if graveyardButton then
        graveyardButton:SetText(db.showGraveyards and "GY: ON" or "GY: OFF")
        local fs = graveyardButton:GetFontString()
        if fs then if db.showGraveyards then fs:SetTextColor(0.2,1,0.2) else fs:SetTextColor(1,0.3,0.3) end end
    end
    local function Add(record, custom, px, py)
        if type(record) ~= "table" or type(record.name) ~= "string"
            or not Coordinate(record.x) or not Coordinate(record.y) then return end
        px, py = px or record.x, py or record.y
        if type(px) ~= "number" or type(py) ~= "number" or px ~= px or py ~= py then return end
        count = count + 1
        if record.graveyard and not custom then renderedGraveyards = renderedGraveyards + 1 end
        local marker = Marker(count)
        if marker:GetFrameLevel() ~= targetLevel + 1 then marker:SetFrameLevel(targetLevel + 1) end
        if marker.record ~= record then CloseTooltip(marker) end
        marker.record, marker.mapID, marker.custom = record, mapID, custom
        local atlasName = "poi-graveyard-neutral"
        if record.graveyard and C_Texture and C_Texture.GetAtlasInfo and C_Texture.GetAtlasInfo(atlasName) then
            marker.icon:SetTexCoord(0, 1, 0, 1)
            marker.icon:SetAtlas(atlasName, false)
        else
            marker.icon:SetTexture(record.graveyard and "Interface\\Icons\\Spell_Holy_Resurrection"
                or "Interface\\Icons\\INV_Misc_Map_01")
            marker.icon:SetTexCoord(0.08, 0.92, 0.08, 0.92)
        end
        marker:ClearAllPoints()
        marker:SetPoint("CENTER", layer, "TOPLEFT", px * width, -py * height)
        marker:Show()
    end
    if ValidMapID(mapID) then
        if db.showGraveyards then
            if graveyardMap ~= mapID or GetTime() >= (graveyardRefreshAt or 0) then
                graveyardMap, graveyards, graveyardRefreshAt = mapID, ReadGraveyards(mapID), GetTime() + 10
            end
            -- On the stitched view the underlying map may change as the player pans.
            -- The OpenMap API returns coordinates in that underlying canvas space.
            -- Do not reject a projected point just because it lies beyond the zone.
            for _, record in ipairs(graveyards) do
                local x, y
                if projected then
                    local continent, wx, wy = WorldAt(mapID, record.x, record.y)
                    if continent then
                        local ok, a, b = pcall(om.CanvasFromWorldPos, continent, wx, wy)
                        if ok and type(a) == "number" and type(b) == "number" then x, y = a, b end
                    end
                end
                Add(record, false, x, y)
            end
        end
        local pins = db.maps[mapID]
        if type(pins) == "table" then
            for _, record in ipairs(pins) do
                local x, y
                if projected and type(record) == "table" and Coordinate(record.x) and Coordinate(record.y) then
                    local continent, wx, wy = WorldAt(mapID, record.x, record.y)
                    if continent then
                        local ok, a, b = pcall(om.CanvasFromWorldPos, continent, wx, wy)
                        if ok and type(a) == "number" and type(b) == "number" then x, y = a, b end
                    end
                end
                Add(record, true, x, y)
            end
        end
    end
    for index = count + 1, #markers do markers[index]:Hide() end
end

local function ToggleGraveyards()
    db.showGraveyards = not db.showGraveyards
    graveyardMap, classicMap = nil, nil
    Refresh()
    Message("Graveyard layer " .. (db.showGraveyards and "on." or "off."))
end

local function Attach()
    world = WorldMapFrame
    if layer or not world or not world.GetCanvas or not world.GetMapID then return end
    canvas = world:GetCanvas()
    local scroll = world.ScrollContainer
    if not canvas or not scroll then return end
    layer = CreateFrame("Frame", nil, canvas)
    layer:SetAllPoints(canvas)
    layer:SetFrameLevel(canvas:GetFrameLevel() + 15)

    if scroll.GetNormalizedCursorPosition then
        placement = CreateFrame("Button", nil, world)
        placement:SetAllPoints(scroll)
        placement:SetFrameLevel(scroll:GetFrameLevel() + 100)
        placement:RegisterForClicks("LeftButtonUp", "RightButtonUp")
        placement:Hide()
        placement:SetScript("OnClick", function(self, mouseButton)
            self:Hide()
            if mouseButton ~= "LeftButton" then return end
            local mapID = world:GetMapID()
            local x, y = scroll:GetNormalizedCursorPosition()
            if ValidMapID(mapID) and Coordinate(x) and Coordinate(y) then
                NamePin({mapID = mapID, x = x, y = y})
            else
                Message("Click inside the map to place a pin.")
            end
        end)

        local button = CreateFrame("Button", nil, world, "UIPanelButtonTemplate")
        button:SetSize(70, 22)
        button:SetPoint("BOTTOMLEFT", scroll, "BOTTOMLEFT", 8, 8)
        button:SetFrameLevel(placement:GetFrameLevel() + 1)
        button:SetText("Pin Me")
        button:RegisterForClicks("LeftButtonUp", "RightButtonUp")
        button:SetScript("OnClick", function(_, mouseButton)
            if mouseButton == "RightButton" then
                ToggleGraveyards()
            else
                placement:SetShown(not placement:IsShown())
                if placement:IsShown() then Message("Click the map to place a pin. Right-click the map to cancel.") end
            end
        end)
        button:SetScript("OnEnter", function(self)
            GameTooltip:SetOwner(self, "ANCHOR_TOP")
            GameTooltip:SetText("Pin Me")
            GameTooltip:AddLine("Left-click to place a custom pin.")
            GameTooltip:AddLine("Right-click to toggle the graveyard layer.")
            GameTooltip:Show()
        end)
        button:SetScript("OnLeave", CloseTooltip)
        world:HookScript("OnHide", function() placement:Hide() end)
    end

    local coords = CreateFrame("Button", nil, world, "UIPanelButtonTemplate")
    coords:SetSize(72, 22)
    coords:SetPoint("BOTTOMLEFT", scroll, "BOTTOMLEFT", placement and 82 or 8, 8)
    if placement then coords:SetFrameLevel(placement:GetFrameLevel() + 1) end
    coords:SetText("Coords")
    coords:SetScript("OnClick", OpenCoordinates)

    graveyardButton = CreateFrame("Button", nil, world, "UIPanelButtonTemplate")
    graveyardButton:SetSize(80, 22)
    graveyardButton:SetPoint("LEFT", coords, "RIGHT", 4, 0)
    graveyardButton:SetFrameLevel(coords:GetFrameLevel())
    graveyardButton:SetScript("OnClick", ToggleGraveyards)
    graveyardButton:SetScript("OnEnter", function(self)
        GameTooltip:SetOwner(self, "ANCHOR_TOP")
        GameTooltip:SetText("Graveyard pins")
        GameTooltip:AddLine("Click to toggle automatic graveyards.")
        GameTooltip:AddLine("Current map: " .. (db.showGraveyards and tostring(#(graveyards or {})) .. " pins" or "disabled"))
        local total = 0
        for _, entries in pairs(addon.classicGraveyards or {}) do total = total + #entries end
        GameTooltip:AddLine("Classic database: " .. total .. " locations")
        GameTooltip:AddLine("Renderer: " .. renderer .. "; markers placed: " .. renderedGraveyards)
        GameTooltip:AddLine("Classic locations may differ in Forever.", 1, 0.8, 0.3)
        GameTooltip:Show()
    end)
    graveyardButton:SetScript("OnLeave", CloseTooltip)

    local elapsed = 0
    layer:SetScript("OnUpdate", function(_, delta)
        elapsed = elapsed + delta
        if elapsed < 0.2 then return end
        elapsed = 0
        RegisterOpenMap()
        local om = OpenMap()
        local stitched = Stitched(om)
        local art = stitched and ArtLevel(om) or nil
        local width, height = canvas:GetSize()
        local mapID = world:GetMapID()
        if not ValidMapID(mapID) then mapID = nil end
        if openMapDirty or lastStitched ~= stitched or lastArtLevel ~= art
            or lastMap ~= mapID or lastWidth ~= width or lastHeight ~= height
            or (mapID and db.showGraveyards and GetTime() >= (graveyardRefreshAt or 0)) then Refresh() end
    end)
    layer:SetScript("OnShow", function() RegisterOpenMap(); Refresh() end)
    RegisterOpenMap()
    Refresh()
end

local function PinHere(name, graveyard)
    local mapID = C_Map and C_Map.GetBestMapForUnit and C_Map.GetBestMapForUnit("player")
    local position = ValidMapID(mapID) and C_Map.GetPlayerMapPosition and C_Map.GetPlayerMapPosition(mapID, "player")
    local x, y
    if position then x, y = position:GetXY() end
    if not Coordinate(x) or not Coordinate(y) then
        Message("Your current map position is unavailable.")
        return
    end
    local pin = {mapID = mapID, x = x, y = y, graveyard = graveyard}
    if name == "" then
        NamePin(pin)
    else
        StaticPopup_Hide("PINME_NAME")
        pendingPin = pin
        SavePin(name)
        Message("Saved " .. name .. ".")
    end
end

SLASH_PINME1 = "/pinme"
SlashCmdList.PINME = function(input)
    local action, name = input:match("^%s*(%S*)%s*(.-)%s*$")
    if action == "here" or action == "graveyard" then
        PinHere(name, action == "graveyard")
    elseif action == "graveyards" then
        ToggleGraveyards()
    elseif action == "status" then
        local mapID = CoordinateMap()
        if not db then Message("Not initialized."); return end
        Message("Graveyard layer: " .. (db.showGraveyards and "ON" or "OFF") .. "; map: " .. tostring(mapID) .. "; overlay: " .. (layer and "attached" or "not attached"))
        if ValidMapID(mapID) then
            classicMap, graveyardMap = nil, nil
            local records = ReadGraveyards(mapID)
            Message(#records .. " available pins; " .. liveGraveyardCount .. " client pins; " .. graveyardStatus)
            Refresh()
            Message("Renderer: " .. renderer .. "; graveyard markers placed: " .. renderedGraveyards .. "; art level: " .. tostring(lastArtLevel) .. "; pin layer: " .. tostring(layer and layer:GetFrameLevel()))
        end
    elseif action == "coords" then
        if name == "" then
            OpenCoordinates()
        else
            AddWaypoint(name, CoordinateMap())
        end
    else
        Message("/pinme coords [x, y] | /pinme status")
        Message("/pinme here [name] | /pinme graveyard [name] | /pinme graveyards")
    end
end

events:RegisterEvent("ADDON_LOADED")
events:RegisterEvent("PLAYER_LOGIN")
events:SetScript("OnEvent", function(_, event, name)
    if event == "ADDON_LOADED" and name == "PinMe" then
        PinMeDB = type(PinMeDB) == "table" and PinMeDB or {}
        db = PinMeDB
        db.maps = type(db.maps) == "table" and db.maps or {}
        if type(db.showGraveyards) ~= "boolean" then db.showGraveyards = true end
    end
    if db and (event == "PLAYER_LOGIN" or name == "Blizzard_WorldMap" or name == "OpenMap") then Attach(); RegisterOpenMap(); openMapDirty = true end
end)
