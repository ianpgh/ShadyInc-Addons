local _, suite = ...
local pinTemplate = "ProfessionAIOLearningPinTemplate"
local mapProvider
local pinDestination

local function showMapPin(map, destination)
    if not map or not map.GetMapID or not map.AddDataProvider or not MapCanvasPinMixin
        or not MapCanvasDataProviderMixin or not map.AcquirePin or not map.RemoveAllPinsByTemplate then return false end
    pinDestination = destination
    if not mapProvider then
        ProfessionAIOLearningPinMixin = CreateFromMixins(MapCanvasPinMixin)
        function ProfessionAIOLearningPinMixin:OnAcquired(location)
            self:SetPosition(location[2], location[3])
        end
        local provider = CreateFromMixins(MapCanvasDataProviderMixin)
        function provider:RemoveAllData()
            self:GetMap():RemoveAllPinsByTemplate(pinTemplate)
        end
        function provider:RefreshAllData()
            self:RemoveAllData()
            local canvas = self:GetMap()
            if pinDestination and canvas:GetMapID() == pinDestination[1] then
                canvas:AcquirePin(pinTemplate, pinDestination)
            end
        end
        provider.OnMapChanged = provider.RefreshAllData
        map:AddDataProvider(provider)
        mapProvider = provider
    end
    mapProvider:RefreshAllData()
    return true
end

function suite.openWorldMap(mapID)
    local map = WorldMapFrame
    if map and map.SetMapID then
        if not map:IsShown() then
            if ShowUIPanel then ShowUIPanel(map)
            else map:Show() end
        end
        map:SetMapID(mapID)
        return map:IsShown()
    elseif OpenWorldMap then
        OpenWorldMap(mapID)
        return not WorldMapFrame or WorldMapFrame:IsShown()
    end
    return false
end

function suite.openLearningMap(destination, profession, recipe)
    local mapID, x, y, title = unpack(destination)
    title = title or recipe
    local opened = suite.openWorldMap(mapID)
    local map = WorldMapFrame

    local placed, native
    if C_Map and C_Map.SetUserWaypoint and UiMapPoint and UiMapPoint.CreateFromCoordinates
        and (not C_Map.CanSetUserWaypointOnMap or C_Map.CanSetUserWaypointOnMap(mapID)) then
        local ok, result = pcall(function()
            return C_Map.SetUserWaypoint(UiMapPoint.CreateFromCoordinates(mapID, x, y))
        end)
        native = ok and result ~= false
        placed = native
    end
    if native and C_SuperTrack and C_SuperTrack.SetSuperTrackedUserWaypoint then
        pcall(C_SuperTrack.SetSuperTrackedUserWaypoint, true)
    end
    if not placed and TomTom and TomTom.AddWaypoint then
        local ok, waypoint = pcall(TomTom.AddWaypoint, TomTom, mapID, x, y, {title=title, persistent=false})
        placed = ok and waypoint ~= nil and waypoint ~= false
    end

    if placed then
        pinDestination = nil
        if mapProvider then mapProvider:RemoveAllData() end
    else
        placed = showMapPin(map, destination)
    end
    print(("%s: %s%s (%.1f, %.1f)"):format(profession, placed and "Waypoint set for " or "", title, x*100, y*100))
    return opened
end
