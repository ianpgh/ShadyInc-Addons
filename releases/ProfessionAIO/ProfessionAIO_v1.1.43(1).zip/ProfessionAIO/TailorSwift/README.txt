TAILOR SWIFT v2.0.2 — WOW FOREVER

Install the TailorSwift folder into Interface/AddOns and reload the game.
Open Blizzard Tailoring normally, use /ts, or click the draggable
Tailor Swift minimap icon. Settings and Mini appear inside Tailoring.

Settings
  Show Cheapest ranks skill-up recipes by last scanned Auctionator
  reagent cost per craft, including materials you already own.
  Use Orange, Yellow, Green, All, Trainable, or Upcoming.
  Enable Resale beside the recipe filter to show per-craft profit or
  loss for Vendor, AH, and estimated DE. Hover a row for net proceeds.
  AH and DE include a 5% sale cut. Unavailable prices use a dash.
  Results stay sorted by material cost.
  Hover a row for ingredients and known training or pattern sources.
  Click a learned row to select it in the native recipe pane.
  Click a training or vendor row to open the map when a pin is available.
  Trainable lists unlearned orange or yellow recipes with known color.
  Upcoming lists higher-skill recipes from the bundled trainer catalog
  and known vendor patterns the client exposes.
  Refresh after Auctionator updates its prices.
  WoW Tooltips uses native item tooltips on hover for recipe rows and the
  Mini craft button. When unchecked, Shift-hover still opens the native tooltip.

Mini
  Mini hides the native window's art while keeping Tailoring open.
  Browse by skill-up color. Toggle Cheapest off to browse without prices.
  Enter a quantity or press MAX, then click CRAFT. Hover CRAFT for reagents
  and station requirements. FULL restores the native pane.
  Recipe color countdowns appear in the native pane and Mini where
  reference thresholds agree with the client's current color.

Settings > Legacy > Enable Best Price (off by default)
  Uses the original TailorSwift unit prices, manual overrides, and
  cloth-derived bolt estimates. Results show per-craft profit or loss
  with the best known vendor, AH, or estimated disenchant return.
  Hover to inspect the output. Hold right-click for the resale breakdown.
  Click a learned row to select it for native crafting. Shift-click
  also closes Settings. Existing per-character overrides are retained.
  /ts price 2589 0.0250 sets Linen Cloth to 2s 50c.
  /ts price 2589 reset clears that override.

Commands
  /ts, /ts settings, /ts mini, /ts full, /ts cheapest, /ts minimap
  /tailorswift, /tt, and /tailorthis are aliases for /ts.
