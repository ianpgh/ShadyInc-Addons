local _, suite = ...
local addon = suite.TailorSwift

-- Named sources retained from TailorSwift's supplied recipe reference.
-- Entries without a confirmed map pin still show the source in the tooltip.
local darnall = {1450, .515, .333, "Darnall (Moonglade)"}
addon.vendorSources = {
    ["Runecloth Cloak"] = {skill=235, vendor="Darnall (Moonglade)", waypoint=darnall},
    ["Runecloth Boots"] = {skill=250, vendor="Darnall (Moonglade)", waypoint=darnall},
    ["Runecloth Cuffs"] = {skill=260, vendor="Pexmit (Dae'gun, Mount Hyjal)"},
    ["Wisdom of the Timbermaw"] = {skill=280, vendor="Meilosh (Timbermaw Hold)", waypoint={1448, .657, .028, "Timbermaw Hold entrance (Felwood)"},
        note="Timbermaw Hold - Honored"},
    ["Venomspew Gloves"] = {skill=285, vendor="Mishta (Cenarion Hold, Silithus)", note="Cenarion Circle - Friendly"},
    ["Venomspew Cord"] = {skill=292, vendor="Mishta (Cenarion Hold, Silithus)", note="Cenarion Circle - Honored"},
    ["Venomspew Footpads"] = {skill=299, vendor="Mishta (Cenarion Hold, Silithus)", note="Cenarion Circle - Honored"},
}

-- Default trainers from the WoW Forever Tailoring guide. Scanned sources take priority.
addon.expertTrainers = {
    Alliance={1453, .53, .81, "Georgio Bolero (Stormwind City)"},
    Horde={1458, .71, .31, "Josef Gregorian (Undercity)"},
}
addon.artisanTrainers = {
    Alliance={1445, .66, .52, "Timothy Worthington (Dustwallow Marsh)"},
    Horde={1424, .64, .21, "Daryl Stack (Hillsbrad Foothills)"},
}
