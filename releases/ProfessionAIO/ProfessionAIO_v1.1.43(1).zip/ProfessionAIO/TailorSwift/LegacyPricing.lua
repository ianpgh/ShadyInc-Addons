local ADDON, suite = ...
local addonData = suite.TailorSwift
local floor, max, format, insert = math.floor, math.max, string.format, table.insert
local profile
local recipeOutputs, pendingOutputInfo = {}, {}

local itemNames = {
    [2589] = "Linen Cloth", [2996] = "Bolt of Linen Cloth", [2320] = "Coarse Thread",
    [2592] = "Wool Cloth", [2997] = "Bolt of Woolen Cloth", [2321] = "Fine Thread",
    [4306] = "Silk Cloth", [4305] = "Bolt of Silk Cloth", [6260] = "Blue Dye",
    [3182] = "Spider's Silk", [2324] = "Bleach", [4338] = "Mageweave Cloth",
    [4339] = "Bolt of Mageweave", [7067] = "Elemental Earth", [7070] = "Elemental Water",
    [7068] = "Elemental Fire", [7069] = "Elemental Air", [4291] = "Silken Thread",
    [6261] = "Orange Dye", [8343] = "Heavy Silken Thread", [14047] = "Runecloth",
    [14048] = "Bolt of Runecloth", [14341] = "Rune Thread", [14227] = "Ironweb Spider Silk",
    [8170] = "Rugged Leather", [7076] = "Essence of Earth", [12803] = "Living Essence",
    [14343] = "Small Brilliant Shard", [7082] = "Essence of Air",
    [2604] = "Red Dye", [2605] = "Green Dye", [4340] = "Gray Dye",
    [4341] = "Yellow Dye", [4234] = "Heavy Leather", [4304] = "Thick Leather",
    [2318] = "Light Leather", [2319] = "Medium Leather", [3383] = "Elixir of Wisdom", [3864] = "Citrine",
    [7077] = "Heart of Fire", [7078] = "Essence of Fire", [7080] = "Essence of Water",
    [14342] = "Mooncloth", [14256] = "Felcloth", [20520] = "Dark Rune",
    [12810] = "Enchanted Leather", [12809] = "Guardian Stone", [12360] = "Arcanite Bar",
    [11176] = "Dream Dust", [7910] = "Star Ruby", [7079] = "Globe of Water",
    [11174] = "Lesser Nether Essence", [5500] = "Iridescent Pearl",
    [7075] = "Iron Buckle", [3577] = "Gold Bar", [13926] = "Golden Pearl",
}
local boltRecipes = {
    [2996] = {2589, 2},
    [2997] = {2592, 3},
    [4305] = {4306, 4},
    [4339] = {4338, 5},
    [14048] = {14047, 5},
}
local function itemName(id)
    if C_Item and C_Item.GetItemInfo then
        local ok, name = pcall(C_Item.GetItemInfo, id)
        if ok and type(name)=="string" and name~="" then return name end
    end
    return itemNames[id] or ("Item "..tostring(id))
end
local function moneyText(copper)
    local gold, silver = floor(copper/10000), floor(copper/100)%100
    local remainder = copper%100
    if gold>0 then
        return format("%dg %02ds %02dc",gold,silver,remainder)
    elseif silver>0 then
        return format("%ds %02dc",silver,remainder)
    end
    return format("%dc",remainder)
end

local function auctionQuote(id)
    return suite.auctionQuote(suite.priceAPI(), ADDON, id)
end

local function unitPrice(id, amount)
    local override=profile.unitPrices[id]
    if type(override)=="number" and override>=0 and override<=1000000000 and override==floor(override) then
        return override,"Manual price"
    end
    amount = amount or 1
    local price, basis = suite.craftUnitPrice(id, amount)
    if price then return price, suite.usesACPricing() and "AC material cost" or "Market price" end
    if basis == "insufficient_depth" then return nil end
    local raw=boltRecipes[id]
    if raw then
        local clothPrice=unitPrice(raw[1], amount * raw[2])
        if clothPrice then return clothPrice*raw[2],"Crafted from "..itemName(raw[1]) end
    end
end

function addonData.materials(id)
    local fn=C_TradeSkillUI and C_TradeSkillUI.GetRecipeSchematic
    if type(fn)~="function" then return end
    local ok,info=pcall(fn,id,false)
    if not ok or type(info)~="table" or type(info.reagentSlotSchematics)~="table"
        or (info.recipeType and info.recipeType~=1) or info.isRecraft then return end
    if type(info.outputItemID)=="number" and info.outputItemID>0 then
        local count=type(info.quantityMin)=="number" and max(1,floor(info.quantityMin)) or 1
        recipeOutputs[id]={item=info.outputItemID,count=count,variable=type(info.quantityMax)=="number" and info.quantityMax>count}
    end
    local mats, byItem={},{}
    for _,slot in ipairs(info.reagentSlotSchematics) do
        if slot.required~=false then
            local items=slot.reagents
            local reagent=type(items)=="table" and #items==1 and items[1]
            local item=reagent and reagent.itemID
            local quantity=slot.quantityRequired
            if not item or type(item)~="number" or item<=0 or type(quantity)~="number"
                or quantity<=0 or quantity~=floor(quantity)
                or (slot.variableQuantities and next(slot.variableQuantities)) then return end
            local existing=byItem[item]
            if existing then
                existing[2]=existing[2]+quantity
            else
                local material={item,quantity}
                byItem[item]=material
                insert(mats,material)
            end
        end
    end
    if #mats>0 then
        return mats
    end
end

local function resaleValues(recipeID, craftCost)
    local output=recipeOutputs[recipeID]
    if not output then return end
    local item,count=output.item,output.count
    local getInfo=(C_Item and C_Item.GetItemInfo) or GetItemInfo
    local vendor,auction,disenchant
    local bindKnown,auctionable
    if type(getInfo)=="function" then
        local ok,name,link,quality,level,_,_,_,_,_,_,sellPrice,classID,_,bindType=pcall(getInfo,item)
        if ok and name then
            if type(sellPrice)=="number" and sellPrice>=0 then vendor=sellPrice*count end
            -- Normal tradeable and bind-on-equip results can be auctioned.
            bindKnown=type(bindType)=="number"
            auctionable=bindType==0 or bindType==2
            if addonData and addonData.disenchantValue then
                local value=addonData.disenchantValue({itemID=item,link=link,quality=quality,
                    baseItemLevel=level,classID=classID},auctionQuote)
                if value and value>0 then disenchant=floor(value*count+.5) end
            end
        else
            pendingOutputInfo[item]=true
        end
    end
    if not bindKnown or auctionable then
        local quote=auctionQuote(item)
        if quote then auction=quote*count end
    end
    local best,method=vendor,"Vendor"
    local auctionNet=auction and floor(auction*.95)
    local disenchantNet=disenchant and floor(disenchant*.95)
    if auctionNet and (not best or auctionNet>best) then best,method=auctionNet,"AH" end
    if disenchantNet and (not best or disenchantNet>best) then best,method=disenchantNet,"Disenchant" end
    return {output=output,vendor=vendor,auction=auction,disenchant=disenchant,method=method,
        auctionNet=auctionNet, disenchantNet=disenchantNet, auctionable=auctionable,
        delta=best and craftCost and best-craftCost or nil}
end

local function profitText(values)
    local delta=values and values.delta
    if delta==nil then return "P/L unavailable" end
    if delta>0 then return "|cff8ee68eProfit +"..moneyText(delta).."|r" end
    if delta<0 then return "|cffff9292Loss -"..moneyText(-delta).."|r" end
    return "Break even"
end

local stationByRecipe = {
    ["Dreamweave Circlet"]="wheel",
    ["Dreamweave Gloves"]="wheel",
    ["Dreamweave Vest"]="wheel",
    ["Mooncloth Boots"]="wheel",
    ["Robe of Power"]="wheel",
    ["Flame Leggings"]="wheel",
    ["Pearly Leggings"]="wheel",
    ["Pristine Leggings"]="wheel",
    ["Shadow Leggings"]="wheel",
    ["Shining Leggings"]="wheel",
    ["Silky Leggings"]="wheel",
    ["Black Slippers"]="wheel",
    ["Fiery Slippers"]="wheel",
    ["Frothing Slippers"]="wheel",
    ["Gilded Slippers"]="wheel",
    ["Golden Slippers"]="wheel",
    ["Radiant Slippers"]="wheel",
    ["Black Handwraps"]="wheel",
    ["Fiery Handwraps"]="wheel",
    ["Frothing Handwraps"]="wheel",
    ["Gilded Handwraps"]="wheel",
    ["Golden Handwraps"]="wheel",
    ["Icy Cloak"]="wheel",
    ["Radiant Handwraps"]="wheel",
    ["Black Cord"]="wheel",
    ["Fiery Cord"]="wheel",
    ["Frothing Cord"]="wheel",
    ["Gilded Cord"]="wheel",
    ["Golden Cord"]="wheel",
    ["Radiant Cord"]="wheel",
    ["Netherflame Shoulders"]="wheel",
    ["Netherfroth Shoulders"]="wheel",
    ["Nethergeld Shoulders"]="wheel",
    ["Netherlight Shoulders"]="wheel",
    ["Netherpearl Shoulders"]="wheel",
    ["Nethershine Shoulders"]="wheel",
    ["Netherflame Cuffs"]="wheel",
    ["Netherfroth Cuffs"]="wheel",
    ["Nethergeld Cuffs"]="wheel",
    ["Netherlight Cuffs"]="wheel",
    ["Netherpearl Cuffs"]="wheel",
    ["Nethershine Cuffs"]="wheel",
    ["Black Waistcord"]="wheel",
    ["Fiery Waistcord"]="wheel",
    ["Frothing Waistcord"]="wheel",
    ["Gilded Waistcord"]="wheel",
    ["Golden Waistcord"]="wheel",
    ["Radiant Waistcord"]="wheel",
    ["Black Gloves"]="wheel",
    ["Black Sandals"]="wheel",
    ["Cloak of Fire"]="wheel",
    ["Fiery Gloves"]="wheel",
    ["Fiery Sandals"]="wheel",
    ["Frothing Gloves"]="wheel",
    ["Frothing Sandals"]="wheel",
    ["Gilded Gloves"]="wheel",
    ["Gilded Sandals"]="wheel",
    ["Golden Gloves"]="wheel",
    ["Golden Sandals"]="wheel",
    ["Radiant Gloves"]="wheel",
    ["Radiant Sandals"]="wheel",
    ["Mooncloth Leggings"]="wheel",
    ["Robe of Winter Night"]="wheel",
    ["Argent Boots"]="wheel",
    ["Wisdom of the Timbermaw"]="wheel",
    ["Mooncloth Vest"]="wheel",
    ["Mooncloth Robe"]="wheel",
    ["Mooncloth Shoulders"]="wheel",
    ["Cloak of Warding"]="wheel",
    ["Felcloth Gloves"]="wheel",
    ["Inferno Gloves"]="wheel",
    ["Mooncloth Circlet"]="wheel",
    ["Mooncloth Gloves"]="wheel",
    ["Felcloth Bag"]="wheel",
    ["Venomspew Gloves"]="loom",
    ["Venomspew Cord"]="loom",
    ["Venomspew Footpads"]="loom",
    ["Swarmtender's Gloves"]="loom",
    ["Swarmtender's Cord"]="loom",
    ["Swarmtender's Footpads"]="loom",
    ["Runed Stygian Belt"]="loom",
}
function addonData.station(name,recipeID)
    local listed=stationByRecipe[name]
    if listed=="wheel" then return listed end
    local fn=C_TradeSkillUI and C_TradeSkillUI.GetRecipeRequirements
    if recipeID and type(fn)=="function" then
        local ok,requirements=pcall(fn,recipeID)
        if ok and type(requirements)=="table" then
            for _,requirement in ipairs(requirements) do
                if type(requirement)=="table" and type(requirement.name)=="string"
                    and requirement.name:lower():find("spinning wheel",1,true) then return "wheel" end
            end
        end
    end
    return listed or "none"
end

addonData.legacyUnitPrice = unitPrice

function addonData.initLegacy(db)
    db.characters = type(db.characters) == "table" and db.characters or {}
    local key = ((UnitName and UnitName("player")) or "Player") .. "-" .. ((GetRealmName and GetRealmName()) or "Forever")
    profile = type(db.characters[key]) == "table" and db.characters[key] or {}
    db.characters[key] = profile
    profile.unitPrices = type(profile.unitPrices) == "table" and profile.unitPrices or {}
end

function addonData.setLegacyPrice(arg)
    local id, value = arg:match("^(%d+)%s+(%S+)$")
    id = tonumber(id)
    value = value and value:lower()
    local gold = value and value:match("^%d+%.?%d*$") and tonumber(value)
    if not id or id < 1 or id > 2147483647 or (value ~= "reset" and (not gold or gold > 100000)) then
        print("Tailor Swift: /ts price <itemID> <gold|reset>. Example: /ts price 2589 0.0250")
        return
    end
    local copper = gold and floor(gold * 10000 + .5) or nil
    profile.unitPrices[id] = copper
    print("Tailor Swift: " .. itemName(id) .. (copper and (" set to " .. moneyText(copper) .. " each.") or " manual price cleared."))
end

function addonData.consumeOutputInfo(id)
    if not id or not pendingOutputInfo[id] then return false end
    pendingOutputInfo[id] = nil
    return true
end

-- Per-craft net proceeds and profit/loss use the same valuation as Best Price.
function addonData.compareResale(entry)
    local values = resaleValues(entry.id, entry.craftCost)
    return {
        {label="Vendor", proceeds=values and values.vendor},
        {label="AH", proceeds=values and values.auctionable and values.auctionNet},
        {label="DE", proceeds=values and values.disenchantNet},
    }
end

function addonData.resaleDelta(proceeds, cost)
    if not proceeds or not cost then return "|cff9ca6b3—|r" end
    local delta = proceeds - cost
    if delta == 0 then return "0c" end
    local prefix = delta > 0 and "|cff8ee68e+" or "|cffff9292-"
    return prefix .. moneyText(math.abs(delta)) .. "|r"
end

function addonData.legacyProfit(entry)
    return profitText(resaleValues(entry.id, entry.craftCost))
end

function addonData.showOutputTooltip(self)
    local output = self.entry and recipeOutputs[self.entry.id]
    if not output then return end
    GameTooltip:SetOwner(self, "ANCHOR_RIGHT")
    GameTooltip:SetHyperlink("item:" .. output.item)
    GameTooltip:Show()
    return true
end

function addonData.showResaleTooltip(self)
    local entry = self.entry
    local values = resaleValues(entry.id, entry.craftCost)
    GameTooltip:SetOwner(self, "ANCHOR_CURSOR")
    GameTooltip:SetText(entry.name)
    if not values then
        GameTooltip:AddLine("Crafted item data unavailable", .73, .77, .82)
        GameTooltip:Show()
        return
    end
    local output = values.output
    GameTooltip:AddLine(format("Resale per craft (%s%d item%s)", output.variable and "at least " or "",
        output.count, output.count == 1 and "" or "s"), .73, .77, .82)
    GameTooltip:AddDoubleLine("Vendor sell", values.vendor and moneyText(values.vendor) or "Unavailable")
    GameTooltip:AddDoubleLine("AH scan", values.auction and moneyText(values.auction) or "Unavailable")
    GameTooltip:AddDoubleLine("Disenchant yield (est.)", values.disenchant and moneyText(values.disenchant) or "Unavailable")
    if values.delta ~= nil then
        GameTooltip:AddDoubleLine("Best known route: " .. values.method, profitText(values))
        GameTooltip:AddLine("P/L includes a 5% faction AH cut.", .73, .77, .82)
    end
    GameTooltip:Show()
end
