local name, suite = ...
local addon = suite.TailorSwift
local TAILORING = 197
local db, controls, panel, mini, mainCountdown
local settingsOpen = false
local native, hookFrame
local pending
local miniRecipeID
local rows, page, index = {}, 1, 1
local legacyPanel, legacyButton, legacy
local trainerOpen
local trainable = {}

local function scanTrainer()
    if not trainerOpen or not GetNumTrainerServices or not GetTrainerServiceInfo then return end
    local count = GetNumTrainerServices()
    if type(count) ~= "number" or count == 0 then return end
    local waypoint
    local map = C_Map and C_Map.GetBestMapForUnit and C_Map.GetBestMapForUnit("player")
    local position = map and C_Map.GetPlayerMapPosition and C_Map.GetPlayerMapPosition(map, "player")
    local trainer = UnitName and UnitName("npc")
    if position and trainer then
        local x, y = position:GetXY()
        if x and y then waypoint = {map, x, y, trainer} end
    end
    for i = 1, count do
        local service, _, status = GetTrainerServiceInfo(i)
        if service and status == "available" then
            local cost = GetTrainerServiceCost and GetTrainerServiceCost(i)
            trainable[service] = {cost=type(cost) == "number" and cost or nil,
                trainer=trainer, waypoint=waypoint}
        elseif service and (status == "used" or status == "unavailable") then
            trainable[service] = nil
        end
    end
end
local COLOR = {.055,.082,.108,.98}
local api = suite.tradeSkillAPI

local function tailoringInfo(info)
    return suite.matchesProfession(info, TAILORING, 7, "Tailoring")
end

local function isTailoring()
    return suite.isProfession(native, TAILORING, 7, "Tailoring")
end

local function window(parent) return suite.window(parent, COLOR) end
local label, button, itemName = suite.label, suite.button, suite.itemName

local materials = addon.materials

local function restore() suite.restoreNative(addon) end
local function hideNative() return suite.hideNative(addon, native) end

local function openTailoring()
    if InCombatLockdown() then return end
    if isTailoring() and native and native:IsShown() then return end
    api("OpenTradeSkill", TAILORING)
end

local function craftLimit(entry)
    if not entry or not isTailoring() or InCombatLockdown() then return 0 end
    local info = api("GetRecipeInfo", entry.id)
    if entry.training or not info or not info.learned or info.name ~= entry.name or info.disabled then return 0 end
    for _, req in ipairs(api("GetRecipeRequirements", entry.id) or {}) do
        if req.met == false then return 0 end
    end
    local count = info.canCreateMultiple == false and 1 or 999
    for _, row in ipairs(entry.materials) do
        local bag = C_Item and C_Item.GetItemCount and C_Item.GetItemCount(row[1], false, false, false)
            or (GetItemCount and GetItemCount(row[1], false, false)) or 0
        count = math.min(count, math.floor(bag / row[2]))
    end
    local nativeCount = api("GetCraftableCount", entry.id)
    if type(nativeCount) == "number" then count = math.min(count, math.floor(nativeCount)) end
    return math.max(0, count)
end

local refresh
local function tailoringSkillInfo()
    -- GetProfessions works even with the Tailoring window closed, on clients
    -- which expose the mainline profession listing APIs.
    if type(GetProfessions)=="function" and type(GetProfessionInfo)=="function" then
        local ok,a,b,c,d,e,g=pcall(GetProfessions)
        if ok then
            local indices={a,b,c,d,e,g}
            for i=1,6 do
                local index=indices[i]
                if type(index)=="number" then
                    local good,name,icon,skill,skillMax,_,_,skillLine=pcall(GetProfessionInfo,index)
                    if good and (skillLine==197 or name=="Tailoring") and type(skill)=="number" then
                        return {skillLevel=skill, maxSkillLevel=skillMax}
                    end
                end
            end
        end
    end
    local skill = C_SkillInfo and C_SkillInfo.GetSkillLineInfoByID and C_SkillInfo.GetSkillLineInfoByID(TAILORING)
    if skill and tonumber(skill.rank) and skill.rank > 0 then
        return {skillLevel=skill.rank, maxSkillLevel=skill.maxRank}
    end
    local profession = api("GetBaseProfessionInfo")
    if not tailoringInfo(profession) or not tonumber(profession.skillLevel) then
        profession = api("GetChildProfessionInfo")
    end
    if tailoringInfo(profession) then return profession end
end

local learningWaypoint

local function showTooltip(self)
    local entry = self.entry
    if not entry then return end
    GameTooltip:SetOwner(self, "ANCHOR_RIGHT")
    GameTooltip:SetText(addon.coloredRecipeName(entry.name, entry.difficulty))
    for i, reagent in ipairs(entry.materials) do
        local id, amount = unpack(reagent)
        local value = entry.prices and addon.money(entry.prices[i]) .. " each" or ""
        GameTooltip:AddDoubleLine(("%d × %s"):format(amount, itemName(id)), value)
    end
    if entry.craftCost then
        GameTooltip:AddDoubleLine("Cost per craft", addon.money(entry.craftCost))
    end
    if entry.resale then
        GameTooltip:AddLine("Resale per craft • Net proceeds / Profit or loss", 1, .82, .3)
        for _, route in ipairs(entry.resale) do
            local proceeds = route.proceeds and addon.money(route.proceeds) or "Unavailable"
            GameTooltip:AddDoubleLine(route.label, proceeds .. " / " .. addon.resaleDelta(route.proceeds, entry.craftCost))
        end
        GameTooltip:AddLine("AH and estimated DE proceeds include a 5% auction cut.", .73, .77, .82, true)
    end
    local skill = tailoringSkillInfo()
    local rank = entry.requiredSkill or (skill and tonumber(skill.skillLevel))
    local station = addon.station(entry.name, entry.id)
    if station ~= "none" then GameTooltip:AddLine(station == "wheel" and "Requires a Spinning Wheel" or "Requires a Loom", 1, .76, .42) end
    local live = api("GetRecipeInfo", entry.id)
    local difficulty = live and live.learned and live.relativeDifficulty or entry.difficulty
    local remaining, nextColor, threshold = addon.nextRecipeColor(entry.name, rank, difficulty)
    if remaining then
        local label = entry.requiredSkill and "Next color after learning" or "Next color"
        GameTooltip:AddDoubleLine(label, ("%s at %d (%d skill %s)"):format(nextColor, threshold, remaining,
            remaining == 1 and "point" or "points"))
        if nextColor == "Gray" then GameTooltip:AddLine("Gray recipes give no skill points.", .68, .72, .77) end
    end
    local training = entry.training
    if training then
        local destination = learningWaypoint(entry)
        if training.vendor then
            GameTooltip:AddDoubleLine("Recipe vendor", (destination and destination[4]) or training.vendor)
        end
        if training.trainer or not (training.vendor or training.quest) then
            GameTooltip:AddDoubleLine("Trainer", training.trainer or (destination and destination[4]) or "Tailoring trainer")
        end
        if training.item and training.item > 0 then
            local item = GetItemInfo and GetItemInfo(training.item)
            if item then GameTooltip:AddDoubleLine("Recipe item", item) end
        end
        if training.favor then GameTooltip:AddDoubleLine("Merchant's Favor", tostring(training.favor)) end
        if training.quest then GameTooltip:AddLine(training.quest, 1, 1, 1, true) end
    end
    if entry.trainingCost then GameTooltip:AddDoubleLine("Training fee", addon.money(entry.trainingCost)) end
    if training then
        local destination = learningWaypoint(entry)
        if destination then GameTooltip:AddLine("Click to open map and pin " .. destination[4], .6, .85, 1, true) end
    end
    if legacy and not entry.training then
        GameTooltip:AddLine("Hold right-click for resale estimates.", .6, .85, 1)
    end
    GameTooltip:Show()
end

learningWaypoint = function(entry)
    local training = entry.training
    if not training then return end
    if training.waypoint then return training.waypoint end
    local source = addon.trainerCatalog[entry.id]
    if not source then return end
    local faction = UnitFactionGroup and UnitFactionGroup("player")
    if source.skill > 225 then return addon.artisanTrainers[faction] end
    return addon.expertTrainers[faction]
end

local function setLearningWaypoint(entry)
    local destination = learningWaypoint(entry)
    if not destination then
        local source = entry.training and (entry.training.vendor or entry.training.trainer)
        print("Tailor Swift: " .. (source and (entry.name .. " — " .. source) or ("Ask a Tailoring trainer about " .. entry.name .. ".")))
        return
    end
    suite.openLearningMap(destination, "Tailor Swift", entry.name)
end

local function addCatalogRecipes(recipes, infoByID, offers, rank, upcoming)
    local faction = UnitFactionGroup and UnitFactionGroup("player")
    local level = UnitLevel and UnitLevel("player")
    local bank = Enum and Enum.SpellBookSpellBank and Enum.SpellBookSpellBank.Player
    for id, source in pairs(addon.trainerCatalog) do
        if (rank < source.skill) == upcoming and (not source.faction or source.faction == faction)
            and (not source.level or (level and level >= source.level)) then
            local info = api("GetRecipeInfo", id)
            local spell = C_Spell and C_Spell.GetSpellName and C_Spell.GetSpellName(id)
            local recipe = info and info.name or spell
            if not recipe and C_Spell and C_Spell.RequestLoadSpellData then C_Spell.RequestLoadSpellData(id) end
            local known = (info and info.learned) or (bank and C_SpellBook
                and C_SpellBook.IsSpellKnown and C_SpellBook.IsSpellKnown(id, bank))
            if recipe and not known and (info or (bank and C_SpellBook and C_SpellBook.IsSpellKnown))
                and not (recipes[recipe] and infoByID[recipes[recipe]].learned) then
                local scanned = offers[recipe] or {}
                recipes[recipe] = id
                infoByID[id] = info or {name=recipe, learned=false}
                offers[recipe] = {
                    cost=scanned.cost or source.fee,
                    requiredSkill=upcoming and source.skill or nil,
                    trainer=scanned.trainer, waypoint=scanned.waypoint,
                }
            end
        end
    end
end

local function addVendorRecipes(recipes, infoByID, offers, ids, rank, upcoming)
    for _, id in ipairs(ids) do
        local info = api("GetRecipeInfo", id)
        local source = info and not info.learned and addon.vendorSources[info.name]
        if source and (rank < source.skill) == upcoming and not recipes[info.name] then
            recipes[info.name], infoByID[id] = id, info
            offers[info.name] = {
                vendor=source.vendor, quest=source.note, waypoint=source.waypoint,
                requiredSkill=upcoming and source.skill or nil,
            }
        end
    end
end

local function pickRecipes(color, useLegacy)
    local upcoming = color == "Upcoming"
    local trainingMode = upcoming or color == "Trainable"
    local skill = trainingMode and tailoringSkillInfo()
    local rank = skill and tonumber(skill.skillLevel)
    local cap = skill and tonumber(skill.maxSkillLevel)
    if trainingMode and (not rank or (not upcoming and (rank >= 300 or (cap and rank >= cap)))) then
        return {}, 0
    end
    local ids = api("GetAllRecipeIDs")
    if type(ids) ~= "table" or #ids == 0 then ids = api("GetFilteredRecipeIDs") end
    if type(ids) ~= "table" then ids = {} end
    local learned, infoByID = {}, {}
    for _, id in ipairs(ids) do
        local info = api("GetRecipeInfo", id)
        if info and info.name and not info.isDummyRecipe and not info.isRecraft
            and not info.isGatheringRecipe and not info.isSalvageRecipe
            and (info.learned or (color == "Trainable" and trainable[info.name]))
            and not (learned[info.name] and infoByID[learned[info.name]].learned and not info.learned) then
            learned[info.name] = id
            infoByID[id] = info
        end
    end
    if db.showCheapest or useLegacy then
        local offers
        if trainingMode then
            offers = {}
            if not upcoming then
                for recipe, offer in pairs(trainable) do
                    offers[recipe] = {cost=offer.cost, trainer=offer.trainer, waypoint=offer.waypoint}
                end
            end
            addCatalogRecipes(learned, infoByID, offers, rank, upcoming)
            addVendorRecipes(learned, infoByID, offers, ids, rank, upcoming)
            for recipe, id in pairs(learned) do
                local offer = offers[recipe]
                if offer then
                    local fallback = not upcoming and infoByID[id].relativeDifficulty or nil
                    local difficulty = fallback or addon.recipeDifficulty(recipe, offer.requiredSkill or rank)
                    if upcoming or difficulty == 0 or difficulty == 1 or (useLegacy and difficulty == nil) then
                        offer.difficulty = difficulty
                    else
                        offers[recipe] = nil
                    end
                end
            end
        end
        return addon.rankRecipes(learned, function(id) return infoByID[id] end, materials, color, offers, useLegacy and addon.legacyUnitPrice or nil)
    end
    local options = {}
    for recipe,id in pairs(learned) do
        local reagents = materials(id)
        local difficulty = infoByID[id].relativeDifficulty
        if reagents and addon.matchesColor(difficulty, color) then
            options[#options+1] = {name=recipe, id=id, materials=reagents,
                difficulty=difficulty, rank=type(difficulty) == "number" and difficulty or 4}
        end
    end
    table.sort(options, function(a,b)
        if a.rank ~= b.rank then return a.rank < b.rank end
        return a.name < b.name
    end)
    return options, 0
end

local function recipeCountdown(recipe, profession)
    if not recipe or not recipe.learned then return "" end
    profession = profession or tailoringSkillInfo()
    if not profession then return "" end
    return addon.colorCountdown(recipe.name, tonumber(profession.skillLevel), recipe.relativeDifficulty)
end

local function findProfit(frame, depth)
    if depth < 0 or not frame:IsShown() then return end
    for _, region in ipairs({frame:GetRegions()}) do
        if region.GetText and region:IsShown() then
            local text = region:GetText()
            if issecretvalue and issecretvalue(text) then text = nil end
            if text and text:gsub("|c%x%x%x%x%x%x%x%x", ""):gsub("|r", ""):match("Profit%s*:") then
                return region
            end
        end
    end
    for _, child in ipairs({frame:GetChildren()}) do
        local profit = findProfit(child, depth-1)
        if profit then return profit end
    end
end

-- Compact, click-to-inspect reagent breakdowns (no permanent overlay labels).
-- The five bolt ratios and the three Forever Alchemy dyes below are recipe
-- data, NOT player profession requirements. A tailor can inspect dye materials.
local madeFrom = {
    [2996]   = {name="Bolt of Linen Cloth",   parts={{"Linen Cloth", 2}}},
    [2997]   = {name="Bolt of Woolen Cloth",  parts={{"Wool Cloth", 3}}},
    [4305]   = {name="Bolt of Silk Cloth",    parts={{"Silk Cloth", 4}}},
    [4339]   = {name="Bolt of Mageweave",     parts={{"Mageweave Cloth", 5}}},
    [14048]  = {name="Bolt of Runecloth",     parts={{"Runecloth", 5}}},
    [249409] = {name="Cerulean Dye",          parts={{"Frilled Lichen", 2}, {"Empty Vial", 1}}},
    [249430] = {name="Magenta Dye",           parts={{"Rosecap", 2}, {"Leaded Vial", 1}}},
    [249431] = {name="Viridian Dye",          parts={{"Stranglevine", 2}, {"Crystal Vial", 1}}},
}
local reagentHotspots = {}
local breakdownRecipeID, breakdownMaterials, breakdownForm

local function closeBreakdownTooltip()
    for _, target in ipairs(reagentHotspots) do
        target:Hide()
        if GameTooltip and GameTooltip.IsOwned and GameTooltip:IsOwned(target) then GameTooltip:Hide() end
    end
end

local function breakdownText(self)
    if not self.data or not GameTooltip then return end
    local d = self.data
    if GameTooltip.IsOwned and GameTooltip:IsOwned(self) and GameTooltip:IsShown() then GameTooltip:Hide(); return end
    GameTooltip:SetOwner(self, "ANCHOR_RIGHT")
    GameTooltip:ClearLines()
    GameTooltip:AddLine(("%d %s"):format(d.quantity, d.recipe.name), 1, .83, .27)
    for _, part in ipairs(d.recipe.parts) do
        local total = part[2] * d.quantity
        -- Plain ingredients only. For cloth bolts the per-bolt ratio is useful.
        local line = ("%d %s"):format(total, part[1])
        if #d.recipe.parts == 1 and d.quantity > 1 then
            line = line .. ("  (%d each)"):format(part[2])
        end
        GameTooltip:AddLine(line, 1, 1, 1)
    end
    GameTooltip:Show()
end

local function getHotspot(i)
    if reagentHotspots[i] then return reagentHotspots[i] end
    local hit = CreateFrame("Button", nil, controls)
    hit:SetFrameStrata("DIALOG")
    hit:SetFrameLevel(controls:GetFrameLevel() + 12)
    hit:RegisterForClicks("LeftButtonUp")
    hit:SetHighlightTexture("Interface\\Buttons\\UI-Listbox-Highlight2", "ADD")
    hit:SetScript("OnClick", breakdownText)
    hit:SetScript("OnLeave", function(self)
        if GameTooltip and GameTooltip.IsOwned and GameTooltip:IsOwned(self) then GameTooltip:Hide() end
    end)
    hit:Hide()
    reagentHotspots[i] = hit
    return hit
end

local function findBreakdownNames(frame, remaining, depth, found)
    if depth < 0 or not frame or not frame.IsShown or not frame:IsShown() then return found end
    for _, region in ipairs({frame:GetRegions()}) do
        if region.GetText and region.IsShown and region:IsShown() then
            local raw = region:GetText()
            if not (issecretvalue and issecretvalue(raw)) and type(raw) == "string" then
                local text = raw:gsub("|c%x%x%x%x%x%x%x%x", ""):gsub("|r", ""):gsub("%s+", " "):lower()
                for i=#remaining,1,-1 do
                    local entry = remaining[i]
                    if text:find(entry.recipe.name:lower(), 1, true) then
                        found = found + 1
                        local hit = getHotspot(found)
                        hit.data = entry
                        if hit.anchoredRegion ~= region then
                            hit:ClearAllPoints()
                            hit:SetPoint("TOPLEFT", region, "TOPLEFT", -3, 4)
                            hit.anchoredRegion = region
                        end
                        local width = region.GetStringWidth and region:GetStringWidth() or 105
                        hit:SetSize(math.min(148, math.max(70, width + 9)), 32)
                        hit:Show()
                        table.remove(remaining, i)
                        break
                    end
                end
            end
        end
    end
    if #remaining == 0 then return found end
    for _, child in ipairs({frame:GetChildren()}) do
        found = findBreakdownNames(child, remaining, depth-1, found)
        if #remaining == 0 then break end
    end
    return found
end

local function updateReagentBreakdowns(form, recipeID)
    if not recipeID then
        closeBreakdownTooltip()
        breakdownRecipeID, breakdownMaterials, breakdownForm = nil, nil, nil
        return
    end
    if breakdownRecipeID ~= recipeID or breakdownForm ~= form or not breakdownMaterials then
        closeBreakdownTooltip()
        breakdownRecipeID, breakdownForm = recipeID, form
        breakdownMaterials = materials(recipeID)
    end
    local remaining = {}
    for _, row in ipairs(breakdownMaterials or {}) do
        local recipe = madeFrom[row[1]]
        if recipe and type(row[2]) == "number" and row[2] > 0 then
            remaining[#remaining+1] = {recipe=recipe, quantity=row[2]}
        end
    end
    -- No crafted reagents: don't scan Blizzard's entire schematic tree.
    if #remaining == 0 then
        for _, target in ipairs(reagentHotspots) do target:Hide() end
        return
    end
    -- Positions in Blizzard's form can change when item data loads or the
    -- profession layout changes. Re-anchor each poll, but reuse the hitboxes.
    local displayed = findBreakdownNames(form, remaining, 7, 0)
    for i=displayed+1,#reagentHotspots do reagentHotspots[i]:Hide() end
end

local function updateMainCountdown()
    local crafting = native and native.CraftingPage
    local form = crafting and crafting.SchematicForm
    if not controls:IsShown() or not form or not form:IsVisible() or not form.GetRecipeInfo then
        updateReagentBreakdowns()
        mainCountdown:Hide()
        return
    end
    local selected = form:GetRecipeInfo()
    updateReagentBreakdowns(form, selected and selected.recipeID)
    local recipe = selected and selected.recipeID and api("GetRecipeInfo", selected.recipeID) or selected
    local text = recipeCountdown(recipe)
    if text == "" then mainCountdown:Hide(); return end
    local profit = findProfit(form, 5) or findProfit(crafting, 4)
    if mainCountdown.anchor ~= (profit or form) then
        mainCountdown:ClearAllPoints()
        if profit then mainCountdown:SetPoint("TOPLEFT", profit, "BOTTOMLEFT", 0, -5)
        else mainCountdown:SetPoint("BOTTOMLEFT", form, "BOTTOMLEFT", 25, 49) end
        mainCountdown.anchor = profit or form
    end
    mainCountdown:SetText(text)
    mainCountdown:Show()
end

local function updateAmount()
    local info = tailoringSkillInfo()
    local skill = info and tonumber(info.skillLevel)
    local cap = info and tonumber(info.maxSkillLevel)
    local text = ""
    if skill then
        text = cap and ("Tailoring %d / %d"):format(skill, cap) or ("Tailoring %d"):format(skill)
    end
    mini.skill:SetText(text)
    local limit = craftLimit(mini.current)
    local qty = tonumber(mini.amount:GetText())
    mini.craft:SetText(qty and qty > 0 and "CRAFT " .. qty or "CRAFT")
    mini.craft:SetEnabled(qty ~= nil and qty >= 1 and qty % 1 == 0 and qty <= limit)
    mini.max:SetEnabled(limit > 0)
    local recipe = mini.current and isTailoring() and api("GetRecipeInfo", mini.current.id)
    local countdown = recipeCountdown(recipe, info)
    mini.countdown:SetText(countdown)
    mini.hint:SetText((limit > 0 or countdown ~= "") and (limit .. " craftable")
        or (mini.current and "Check materials or tailoring station." or ""))
end

local function setRankedResults(results, missing, color)
    local recipeGroup = color == "All" and "Skill-up" or color
    rows = results
    local count = #rows
    if mini:IsShown() and miniRecipeID then
        for i, entry in ipairs(rows) do
            if entry.id == miniRecipeID then index = i; break end
        end
    end
    index = math.max(1, math.min(index, count))
    local pages = math.max(1, math.ceil(count / #panel.results))
    page = math.max(1, math.min(page, pages))
    local note
    local info = api("GetBaseProfessionInfo")
    local trainingMode = color == "Trainable" or color == "Upcoming"
    local showPrices = legacy or (db.showCheapest and not legacyPanel:IsShown())
    if not addon.hasCraftPricing() and not trainingMode and not legacy then note = "Enable Auction Companion to show prices."
    elseif showPrices and color ~= "Upcoming" and info and info.skillLevel and info.maxSkillLevel and info.skillLevel >= info.maxSkillLevel then
        note = info.skillLevel >= 300 and "Tailoring 300 reached." or "Train the next Tailoring rank."
        rows, count, pages, page, index = {}, 0, 1, 1, 1
    elseif color == "Trainable" then
        local skill = tailoringSkillInfo()
        local rank = skill and tonumber(skill.skillLevel)
        local cap = skill and tonumber(skill.maxSkillLevel)
        if not rank then note = "Open Tailoring to check your skill."
        elseif rank >= 300 then note = "Tailoring 300 reached."
        elseif cap and rank >= cap then note = "Train the next Tailoring rank."
        elseif count == 0 then note = "No unlearned orange or yellow recipes now."
        else note = "Orange / yellow skill-ups • Cost / craft" end
    elseif color == "Upcoming" then
        note = count > 0 and "Upcoming recipes • Required Tailoring skill"
            or "No upcoming recipes found."
    elseif count == 0 then
        note = missing > 0 and addon.pricingHint() or ("No learned %s recipes."):format(recipeGroup:lower())
    else note = ("%s recipes • Last scan cost / craft%s"):format(recipeGroup, missing > 0 and (" • " .. missing .. " unpriced") or "") end
    local compare = panel:IsShown() and showPrices and not legacy and db.showResale == true
    local rowStep = compare and 37 or 22
    if compare and count > 0 then note = "Cost / craft • Profit or loss by sale route" end
    panel.note:SetText(note)
    for i, btn in ipairs(panel.results) do
        local entry = rows[(page-1)*#panel.results+i]
        btn.entry = entry
        btn:SetShown(showPrices and entry ~= nil)
        btn:ClearAllPoints()
        btn:SetPoint("TOPLEFT", panel, "TOPLEFT", 12, -103-(i-1)*rowStep)
        btn.resaleLine:SetShown(compare and entry ~= nil)
        if entry then
            if compare then
                entry.resale = addon.compareResale(entry)
                local routes = {}
                for j, route in ipairs(entry.resale) do
                    routes[j] = route.label .. " " .. addon.resaleDelta(route.proceeds, entry.craftCost)
                end
                btn.resaleLine:SetText(table.concat(routes, "   •   "))
            end
            local cost = entry.craftCost and addon.money(entry.craftCost) or "No price"
            local requirement = entry.requiredSkill and ("  •  Skill %d"):format(entry.requiredSkill) or ""
            local text = addon.coloredRecipeName(entry.name, entry.difficulty) .. requirement .. "  •  " .. cost
            if legacy and not entry.training then
                text = text .. "  •  " .. addon.legacyProfit(entry)
            end
            btn:SetText(text)
        end
    end
    panel.prev:SetShown(showPrices and page > 1)
    panel.next:SetShown(showPrices and page < pages)
    panel.refresh:SetShown(showPrices)
    panel.note:SetShown(showPrices)
    local footerY = compare and -291 or -216
    for _, control in ipairs({panel.prev, panel.next, panel.refresh}) do
        control:ClearAllPoints()
        control:SetPoint("TOPLEFT", panel, "TOPLEFT", control.footerX, footerY)
    end
    panel:SetHeight(showPrices and (compare and 320 or 245) or 86)

    local entry = rows[index]
    mini.current = entry
    if mini:IsShown() then miniRecipeID = entry and entry.id end
    mini.recipe:SetText(entry and addon.coloredRecipeName(entry.name, entry.difficulty) or (db.showCheapest and note or ("No learned %s recipes."):format(recipeGroup:lower())))
    mini.cost:SetText(entry and (entry.craftCost and ("~" .. addon.money(entry.craftCost) .. " / craft") or (index .. " / " .. count)) or "")
    mini.prev:SetEnabled(index > 1)
    mini.next:SetEnabled(index < count)
    updateAmount()
end

refresh = function()
    native = ProfessionsFrame or TradeSkillFrame
    local visibleTailoring = native and native:IsShown() and isTailoring()
    if native and hookFrame ~= native then
        hookFrame = native
        controls:SetParent(native)
        controls:ClearAllPoints()
        controls:SetPoint("TOPRIGHT", native, "TOPRIGHT", -40, -5)
        controls:SetFrameStrata("DIALOG")
        controls:SetFrameLevel(native:GetFrameLevel()+100)
        panel:SetFrameStrata("DIALOG")
        panel:SetFrameLevel(controls:GetFrameLevel()+5)
        local attached = native
        native:HookScript("OnHide", function()
            if hookFrame ~= attached then return end
            settingsOpen = false
            legacyPanel:Hide()
            controls:Hide()
            mainCountdown:Hide()
            restore()
            mini:Hide()
            panel:Hide()
        end)
        native:HookScript("OnShow", function() C_Timer.After(0, refresh) end)
    end
    if not visibleTailoring then
        legacy = false
        if native and native:IsShown() and not api("IsDataSourceChanging") and not addon.openingSettings then
            settingsOpen = false
            legacyPanel:Hide()
        end
        controls:Hide()
        mainCountdown:Hide()
        restore()
        mini:Hide()
        panel:Hide()
        return
    end
    addon.openingSettings = nil
    local compact = db.mini and not InCombatLockdown() and hideNative()
    if not compact then restore() end
    if compact then settingsOpen = false end
    controls:SetShown(not compact)
    panel:SetShown(not compact and settingsOpen)
    mini:SetShown(compact == true)
    legacy = not compact and settingsOpen and legacyPanel:IsShown() and db.legacyBestPrice == true
    if compact or not settingsOpen then legacyPanel:Hide() end
    legacyButton:SetShown(db.legacyBestPrice == true)
    local color = (compact and db.miniColor or legacy and db.legacyColor or not compact and db.mainColor) or "Orange"
    if compact or (settingsOpen and (db.showCheapest or legacy)) then
        local results, missing = pickRecipes(color, legacy)
        setRankedResults(results, missing, color)
    else setRankedResults({}, 0, color) end
    panel.wowTooltips:SetChecked(db.wowTooltips == true)
    panel.cheapest:SetChecked(db.showCheapest)
    panel.cheapest:SetShown(not legacyPanel:IsShown())
    local showFilters = db.showCheapest and not legacyPanel:IsShown()
    panel.color:SetShown(showFilters)
    panel.resale:SetShown(showFilters)
    panel.resale:SetChecked(db.showResale == true)
    panel.title:SetText(legacyPanel:IsShown() and "Legacy Best Price" or "Tailor Swift")
    mini.cheapest:SetChecked(db.showCheapest)
    updateMainCountdown()
end

local function schedule()
    if pending then return end
    pending = true
    C_Timer.After(.12, function() pending = false; refresh() end)
end

local function preferNativeTooltip()
    return db.wowTooltips == true
end

local function checkbox(parent, caption, x, y, handler)
    local check = CreateFrame("CheckButton", nil, parent, "UICheckButtonTemplate")
    check:SetPoint("TOPLEFT", x, y)
    check:SetSize(23,23)
    check.caption = label(check, 24, -5)
    check.caption:SetText(caption)
    check:SetScript("OnClick", handler)
    return check
end

local function toggleCheapest(self)
    db.showCheapest = self:GetChecked() == true
    page, index, miniRecipeID = 1, 1, nil
    refresh()
end

local function colorDropdown(parent, key, x, y)
    local colorMenu
    local colorButton = button(parent, (db[key] or "Orange") .. " v", x, y, 78, function()
        colorMenu:SetShown(not colorMenu:IsShown())
    end)
    colorMenu = window(parent)
    colorMenu:SetSize(88, key ~= "miniColor" and 144 or 100)
    colorMenu:SetPoint("TOPLEFT", colorButton, "BOTTOMLEFT", -5, -2)
    colorMenu:SetFrameLevel(parent:GetFrameLevel()+10)
    colorMenu:EnableMouse(true)
    colorMenu:Hide()
    local colors = {"Orange", "Yellow", "Green", "All"}
    if key ~= "miniColor" then
        colors[#colors+1] = "Trainable"
        colors[#colors+1] = "Upcoming"
    end
    for i, color in ipairs(colors) do
        button(colorMenu, color, 6, -6-(i-1)*22, 76, function()
            db[key] = color
            page, index, miniRecipeID = 1, 1, nil
            colorButton:SetText(color .. " v")
            colorMenu:Hide()
            refresh()
        end)
    end
    parent:HookScript("OnHide", function() colorMenu:Hide() end)
    return colorButton
end

local function build()
    local metadata = C_AddOns and C_AddOns.GetAddOnMetadata or GetAddOnMetadata
    local currentVersion = metadata and metadata(name, "Version")
    local versionText = currentVersion and ("v" .. currentVersion) or ""
    controls = CreateFrame("Frame", nil, UIParent)
    controls:SetSize(139, 21)
    controls:Hide()
    mainCountdown = label(controls, 0, 0)
    mainCountdown:SetTextColor(1, .82, .3)
    mainCountdown:Hide()
    button(controls, "Settings", 0, 0, 81, function()
        settingsOpen = not settingsOpen
        legacyPanel:Hide()
        refresh()
    end)
    button(controls, "Mini", 85, 0, 54, function()
        if InCombatLockdown() then return end
        settingsOpen = false
        db.mini = true
        refresh()
    end)

    panel = window(controls)
    panel:SetSize(322, 86)
    panel:SetPoint("TOPRIGHT", controls, "BOTTOMRIGHT", 0, -4)
    panel:EnableMouse(true)
    panel:Hide()
    local title = label(panel, 13, -12)
    title:SetTextColor(1,.80,.40)
    title:SetText("Tailor Swift")
    panel.title = title
    button(panel, "X", 283, -7, 26, function()
        settingsOpen = false
        refresh()
    end)
    panel.wowTooltips = checkbox(panel, "WoW Tooltips", 11, -33, function(self)
        db.wowTooltips = self:GetChecked() == true
    end)
    panel.cheapest = checkbox(panel, "Show Cheapest", 11, -57, toggleCheapest)
    panel.color = colorDropdown(panel, "mainColor", 154, -58)
    panel.resale = checkbox(panel, "Resale", 237, -57, function(self)
        db.showResale = self:GetChecked() == true
        refresh()
    end)
    panel.legacy = button(panel, "Legacy", 207, -7, 70, function()
        legacyPanel:SetShown(not legacyPanel:IsShown())
        page, index = 1, 1
        refresh()
    end)
    legacyPanel = CreateFrame("Frame", nil, panel)
    legacyPanel:SetAllPoints()
    legacyPanel:Hide()
    local enabled = checkbox(legacyPanel, "Enable Best Price", 11, -57, function(self)
        db.legacyBestPrice = self:GetChecked() == true
        page, index = 1, 1
        refresh()
    end)
    enabled:SetChecked(db.legacyBestPrice == true)
    legacyButton = colorDropdown(legacyPanel, "legacyColor", 164, -58)

    local tribute = panel:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
    tribute:SetPoint("BOTTOMRIGHT", -12, 11)
    tribute:SetFont("Fonts\\MORPHEUS.TTF", 10, "")
    tribute:SetTextColor(.78,.64,.33)
    tribute:SetText("RIP Shady")
    local settingsVersion = panel:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
    settingsVersion:SetPoint("BOTTOM", panel, "BOTTOM", 22, 11)
    settingsVersion:SetTextColor(.65, .70, .77)
    settingsVersion:SetText(versionText)
    panel.note = label(panel, 13, -85)
    panel.results = {}
    for i = 1, 5 do
        local btn = button(panel, "", 12, -103-(i-1)*22, 298, function(self)
            local entry = self.entry
            if not entry or not isTailoring() or InCombatLockdown() then return end
            if entry.training then
                setLearningWaypoint(entry)
            else
                api("OpenRecipe", entry.id)
                if legacy and IsShiftKeyDown and IsShiftKeyDown() then
                    settingsOpen = false
                    refresh()
                end
            end
        end)
        btn:RegisterForClicks("LeftButtonUp")
        local renderTooltip = suite.bindRecipeTooltip(btn, function(self)
            if not legacy or not addon.showOutputTooltip(self) then showTooltip(self) end
        end, nil, preferNativeTooltip)
        btn:SetScript("OnMouseDown", function(self, mouse)
            if mouse == "RightButton" and legacy and self.entry then addon.showResaleTooltip(self) end
        end)
        btn:SetScript("OnMouseUp", function(self, mouse)
            if mouse == "RightButton" then
                if self:IsMouseOver() then
                    renderTooltip(self)
                else GameTooltip:Hide() end
            end
        end)
        btn.resaleLine = label(btn, 8, -22)
        btn.resaleLine:SetWidth(286)
        btn.resaleLine:SetMaxLines(1)
        btn.resaleLine:SetTextColor(.8, .84, .9)
        btn.resaleLine:Hide()
        panel.results[i] = btn
    end
    panel.prev = button(panel, "<", 12, -216, 27, function() page = page-1; refresh() end)
    panel.next = button(panel, ">", 41, -216, 27, function() page = page+1; refresh() end)
    panel.refresh = button(panel, "REFRESH", 77, -216, 72, refresh)
    panel.prev.footerX, panel.next.footerX, panel.refresh.footerX = 12, 41, 77

    mini = window(UIParent)
    mini:SetSize(409, 170)
    mini:SetPoint("CENTER", UIParent, "CENTER", 0, 70)
    mini:SetFrameStrata("DIALOG")
    mini:SetClampedToScreen(true)
    mini:SetMovable(true)
    mini:EnableMouse(true)
    mini:RegisterForDrag("LeftButton")
    mini:SetScript("OnDragStart", mini.StartMoving)
    mini:SetScript("OnDragStop", mini.StopMovingOrSizing)
    mini:Hide()
    local miniTitle = label(mini, 13, -14)
    miniTitle:SetTextColor(1,.80,.40)
    miniTitle:SetText("Tailor Swift")
    mini.skill = label(mini, 13, -29)
    mini.skill:SetTextColor(.71, .77, .83)
    local version = label(mini, 0, 0)
    version:ClearAllPoints()
    version:SetPoint("BOTTOMLEFT", mini, "BOTTOMLEFT", 13, 9)
    version:SetTextColor(.65, .70, .77)
    version:SetText(versionText)
    local memorial = mini:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
    memorial:SetPoint("BOTTOM", mini, "BOTTOM", 0, 8)
    memorial:SetFont("Fonts\\MORPHEUS.TTF", 10, "")
    memorial:SetTextColor(.78, .64, .33)
    memorial:SetText("RIP Shady")
    mini.cheapest = checkbox(mini, "Cheapest", 126, -8, toggleCheapest)
    colorDropdown(mini, "miniColor", 207, -9)
    button(mini, "FULL", 294, -9, 58, function() db.mini = false; refresh() end)
    button(mini, "X", 363, -9, 32, function()
        if InCombatLockdown() then return end
        restore()
        if native and isTailoring() then
            if HideUIPanel then HideUIPanel(native) else native:Hide() end
        end
        mini:Hide()
    end)
    mini.recipe = label(mini, 46, -48)
    mini.recipe:SetWidth(315)
    mini.recipe:SetMaxLines(1)
    mini.prev = button(mini, "<", 12, -43, 27, function() index = index-1; miniRecipeID = nil; refresh() end)
    mini.next = button(mini, ">", 368, -43, 27, function() index = index+1; miniRecipeID = nil; refresh() end)
    mini.cost = label(mini, 46, -68)
    mini.hint = label(mini, 13, -128)
    mini.countdown = label(mini, 0, 0)
    mini.countdown:ClearAllPoints()
    mini.countdown:SetPoint("TOPRIGHT", mini, "TOPRIGHT", -13, -128)
    mini.countdown:SetJustifyH("RIGHT")
    mini.countdown:SetTextColor(1, .82, .3)
    mini.amount = CreateFrame("EditBox", nil, mini, "InputBoxTemplate")
    mini.amount:SetPoint("TOPLEFT", 55, -91)
    mini.amount:SetSize(42, 25)
    mini.amount:SetAutoFocus(false)
    mini.amount:SetNumeric(true)
    mini.amount:SetMaxLetters(3)
    mini.amount:SetText("1")
    mini.amount:SetScript("OnTextChanged", updateAmount)
    mini.amount:SetScript("OnEscapePressed", function(self) self:ClearFocus() end)
    mini.amount:SetScript("OnEnterPressed", function(self) self:ClearFocus() end)
    local function adjust(delta)
        local n = tonumber(mini.amount:GetText()) or 1
        mini.amount:SetText(tostring(math.max(1, math.min(999, n+delta))))
    end
    button(mini, "-", 12, -93, 30, function() adjust(-1) end)
    button(mini, "+", 110, -93, 30, function() adjust(1) end)
    mini.max = button(mini, "MAX", 148, -93, 48, function()
        local limit = craftLimit(mini.current)
        if limit > 0 then mini.amount:SetText(tostring(limit)) end
    end)
    mini.craft = button(mini, "CRAFT", 209, -93, 186, function()
        local current = mini.current
        local amount = tonumber(mini.amount:GetText())
        if amount and amount % 1 == 0 and amount >= 1 and amount <= craftLimit(current) then
            api("CraftRecipe", current.id, amount)
        end
    end)
    suite.bindRecipeTooltip(mini.craft, showTooltip, function() return mini.current end, preferNativeTooltip)

    local launcher = suite.launcher("TailorSwiftMinimapButton", db, "INV_Fabric_Linen_01", 220, openTailoring)
    addon.launcher = launcher
    launcher:SetShown(not db.hideLauncher)
end

suite.registerModule(function(event, arg)
    if event == "ADDON_LOADED" then
        if arg ~= name then return end
        TailorSwiftDB = type(TailorSwiftDB) == "table" and TailorSwiftDB
            or (type(TailorThisDB) == "table" and TailorThisDB or {})
        TailorSwiftDB.nativeUI = type(TailorSwiftDB.nativeUI) == "table" and TailorSwiftDB.nativeUI or {}
        db = TailorSwiftDB.nativeUI
        local player = ((UnitName and UnitName("player")) or "Player") .. "-" .. ((GetRealmName and GetRealmName()) or "Forever")
        local profile = type(TailorSwiftDB.characters) == "table" and TailorSwiftDB.characters[player]
        if type(profile) == "table" then
            if db.angle == nil then db.angle = tonumber(profile.minimapAngle) end
            if db.hideLauncher == nil then db.hideLauncher = profile.minimapHidden == true end
        end
        if db.legacyBestPrice == nil then db.legacyBestPrice = false end
        addon.initLegacy(TailorSwiftDB)

        build()
        suite.addPoll(function()
            local frame = ProfessionsFrame or TradeSkillFrame
            if frame and frame:IsShown() then
                if frame ~= native or (isTailoring() ~= (controls:IsShown() or mini:IsShown())) then refresh()
                elseif controls:IsShown() then updateMainCountdown() end
            end
        end)
        SLASH_TAILORSWIFT1, SLASH_TAILORSWIFT2 = "/ts", "/tailorswift"
        SLASH_TAILORSWIFT3, SLASH_TAILORSWIFT4 = "/tt", "/tailorthis"
        SlashCmdList.TAILORSWIFT = function(message)
            if InCombatLockdown() then return end
            local command, arg = (message or ""):match("^%s*(%S*)%s*(.-)%s*$")
            command = command:lower()
            if command == "price" then addon.setLegacyPrice(arg); schedule(); return end
            if command == "minimap" then
                db.hideLauncher = not db.hideLauncher
                addon.launcher:SetShown(not db.hideLauncher)
                return
            end
            if command == "help" then
                print("Tailor Swift: /ts [mini | full | settings | cheapest | minimap | price]")
                return
            end
            if command == "mini" then db.mini = true
            elseif command == "full" or command == "settings" or command == "cheapest" then
                db.mini = false
                settingsOpen = command ~= "full"
                legacyPanel:Hide()
                if command == "cheapest" then db.showCheapest = true end
            elseif command ~= "" then return end
            if settingsOpen and not isTailoring() then
                addon.openingSettings = true
                C_Timer.After(2, function() addon.openingSettings = nil end)
            end
            openTailoring()
            if isTailoring() then refresh() end
        end
        return {"TRADE_SKILL_SHOW", "TRADE_SKILL_CLOSE", "TRADE_SKILL_DATA_SOURCE_CHANGED",
            "TRADE_SKILL_LIST_UPDATE", "SKILL_LINES_CHANGED", "BAG_UPDATE_DELAYED", "PLAYER_REGEN_DISABLED",
            "PLAYER_REGEN_ENABLED", "AUCTION_HOUSE_CLOSED", "TRAINER_SHOW", "TRAINER_UPDATE", "TRAINER_CLOSED", "SPELL_DATA_LOAD_RESULT", "GET_ITEM_INFO_RECEIVED", "NEW_RECIPE_LEARNED", "TRADE_SKILL_ITEM_CRAFTED_RESULT"}
    end
    if event == "GET_ITEM_INFO_RECEIVED" and not addon.consumeOutputInfo(arg) then return end
    if event == "TRAINER_SHOW" then
        trainerOpen = true
        scanTrainer()
        C_Timer.After(.15, scanTrainer)
    elseif event == "TRAINER_UPDATE" then
        scanTrainer()
    elseif event == "TRAINER_CLOSED" then
        trainerOpen = false
    elseif event == "TRADE_SKILL_CLOSE" then
        settingsOpen = addon.openingSettings == true
        legacyPanel:Hide()
        restore()
        controls:Hide()
        panel:Hide()
        mini:Hide()
    elseif event == "TRADE_SKILL_DATA_SOURCE_CHANGED" or event == "PLAYER_REGEN_DISABLED" then
        refresh()
    end
    schedule()
end)
