local name, addon = ...

-- Enum.TradeskillRelativeDifficulty values for recipes that can still give skill.
local colorValue = {Orange=0, Yellow=1, Green=2}

function addon.matchesColor(difficulty, color)
    if color == "All" then return difficulty == 0 or difficulty == 1 or difficulty == 2 end
    return difficulty == colorValue[color or "Orange"] and difficulty ~= nil
end

-- AC is authoritative when loaded. Never mix another provider's quotes into AC rankings.
local function acAPI()
    local api = AuctionCompanionAPI
    if type(api) == "table" and type(api.GetPriceByItemID) == "function" then return api end
end

function addon.usesACPricing()
    return acAPI() ~= nil
end

local function acQuote(_, itemID)
    local api = acAPI()
    if api then return api.GetPriceByItemID(itemID) end
end

function addon.priceAPI()
    if acAPI() then return acQuote end
    local api = Auctionator and Auctionator.API and Auctionator.API.v1
    if api and type(api.GetAuctionPriceByItemID) == "function" then return api.GetAuctionPriceByItemID end
end

function addon.hasCraftPricing()
    return acAPI() or (ShadyPriceAPI and type(ShadyPriceAPI.GetBuyCost) == "function") or addon.priceAPI()
end

function addon.pricingHint()
    if acAPI() then return "No complete prices. Run AC Live Scan All." end
    if ShadyPriceAPI then return "No complete prices. Refresh price data." end
    if addon.priceAPI() then return "No complete prices. Scan with Auctionator." end
    return "Enable Auction Companion to show prices."
end

function addon.shadyCraftUnitPrice(itemID, amount)
    if not ShadyPriceAPI or type(ShadyPriceAPI.GetBuyCost) ~= "function" then return end
    local total, basis = ShadyPriceAPI.GetBuyCost(itemID, amount)
    if total then return total / amount, basis end
    return nil, basis
end

function addon.auctionQuote(price, ...)
    if type(price) ~= "function" then return end
    local ok, quote = pcall(price, ...)
    if ok and type(quote) == "number" and quote > 0 and quote < math.huge then return quote end
end

function addon.craftUnitPrice(itemID, amount)
    local api = acAPI()
    if api then
        local value = addon.auctionQuote(api.GetMaterialCost, itemID)
            or addon.auctionQuote(api.GetPriceByItemID, itemID)
        return value, value and "AC" or "ac_missing"
    end
    local value, basis = addon.shadyCraftUnitPrice(itemID, amount)
    if value or basis == "insufficient_depth" then return value, basis end
    return addon.auctionQuote(addon.priceAPI(), name, itemID)
end

function addon.money(copper)
    copper = math.floor(copper + .5)
    if copper >= 10000 then return ("%dg %02ds %02dc"):format(math.floor(copper/10000), math.floor(copper/100)%100, copper%100) end
    if copper >= 100 then return ("%ds %02dc"):format(math.floor(copper/100), copper%100) end
    return ("%dc"):format(copper)
end

function addon.rankRecipes(recipes, getInfo, getMaterials, color, trainable, unitPrice)
    local available = unitPrice or addon.hasCraftPricing()
    local ranked, itemPrices = {}, {}
    local missing = 0
    if not available and color ~= "Trainable" and color ~= "Upcoming" then return ranked, missing end
    for recipe, id in pairs(recipes) do
        local info = getInfo(id)
        local training = trainable and trainable[recipe]
        local eligible = info and (((color == "Trainable" or color == "Upcoming") and training and not info.learned)
            or (info.learned and addon.matchesColor(info.relativeDifficulty, color)))
        if eligible and info.name == recipe and not info.isDummyRecipe and not info.isRecraft then
            local materials = getMaterials(id)
            if materials and available then
                local cost, prices, complete = 0, {}, true
                for index, reagent in ipairs(materials) do
                    local itemID, amount = unpack(reagent)
                    local key = itemID .. ":" .. amount
                    if itemPrices[key] == nil then
                        local value
                        if unitPrice then
                            value = unitPrice(itemID, amount)
                        else
                            value = addon.craftUnitPrice(itemID, amount)
                        end
                        itemPrices[key] = value or false
                    end
                    local unit = itemPrices[key]
                    if unit then
                        prices[index] = unit
                        cost = cost + math.floor(unit * amount + 0.5)
                    else
                        complete = false
                    end
                end
                if complete then
                    ranked[#ranked+1] = {name=recipe, id=id, materials=materials, prices=prices,
                        craftCost=cost, trainingCost=training and training.cost, requiredSkill=training and training.requiredSkill, training=training, difficulty=training and training.difficulty or info.relativeDifficulty}
                else
                    missing = missing + 1
                    if training then
                        ranked[#ranked+1] = {name=recipe, id=id, materials=materials, trainingCost=training.cost, requiredSkill=training.requiredSkill, training=training, difficulty=training and training.difficulty or info.relativeDifficulty}
                    end
                end
            elseif training then
                ranked[#ranked+1] = {name=recipe, id=id, materials=materials or {}, trainingCost=training.cost, requiredSkill=training.requiredSkill, training=training, difficulty=training and training.difficulty or info.relativeDifficulty}
            end
        end
    end
    table.sort(ranked, function(a,b)
        if a.requiredSkill ~= b.requiredSkill then return (a.requiredSkill or 0) < (b.requiredSkill or 0) end
        local aCost, bCost = a.craftCost or math.huge, b.craftCost or math.huge
        if aCost ~= bCost then return aCost < bCost end
        return a.name < b.name
    end)
    return ranked, missing
end
