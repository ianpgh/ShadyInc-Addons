-- Adapted from Disenchantry 1.2.6 by x_Raven_x and Rakuga.
-- See Disenchantry-LICENSE.txt and Disenchantry-NOTICE.txt.
-- Valuation only. The source addon's settings and samples are read-only.
local _, addon = ...
local ns = {App={}}

local Policy = {overrides={}}
ns.ForecastPolicy = Policy
-- Opted-in estimates for these exact new crafts only, not all Forever rares.
-- Craft Ladder Data/Disenchant.lua (2026-11-03), buckets 335/336, guess=true.
-- See Docs/ForeverRareResearch.md. Player observations take precedence.
local lowCraft = {approximate=true,foreverCraftEstimate=true,
    {itemID=10940,chance=80,minQuantity=2,maxQuantity=3},
    {itemID=10938,chance=20,minQuantity=2,maxQuantity=3}}
local midCraft = {approximate=true,foreverCraftEstimate=true,
    {itemID=10940,chance=75,minQuantity=3,maxQuantity=4},
    {itemID=10939,chance=20,minQuantity=2,maxQuantity=3},
    {itemID=10978,chance=5,minQuantity=2,maxQuantity=2}}
for _,id in ipairs({250620,250482,250621,252424,252425,252426,252427,253885,253887}) do
    Policy.overrides[id]=lowCraft
end
for _,id in ipairs({250513,250514,250515,250516,250517,250508,250509,250510,250511,250512,250489,
    252428,252429,252430,252431,252432,252433,252494,252495,252496,252497,252498,252499,
    253889,253891,253893,253895,253897,253899,253901,253903,253905,253907,253909,253911,
    253913,253915,253917,253919,253921,253923}) do
    Policy.overrides[id]=midCraft
end
function Policy.ItemID(item)
    local ref = type(item)=="table" and (item.itemID or item.link) or item
    return type(ref)=="number" and ref or type(ref)=="string" and tonumber(ref:match("item:(%d+)")) or nil
end
function Policy.IsForever()
    return GetBuildInfo and tostring(GetBuildInfo()):match("^1%.60%.")~=nil
end
function Policy.IsUnverified(item)
    if not item then return false end
    local id=Policy.ItemID(item)
    return Policy.IsForever() and item.quality==3 and id and id>=200000 and not Policy.overrides[id] and not Policy.Estimate(item) and not Policy.Observed(item) or false
end
-- User-selected fallback for all new Forever rares, regardless of acquisition.
-- Low-level distributions are estimates; higher brackets use Classic rules.
function Policy.Estimate(item)
    local id=Policy.ItemID(item)
    local level=tonumber(item and item.baseItemLevel)
    if not Policy.IsForever() or not id or id<200000 or item.quality~=3 or not level
        or level<5 or level>99 or (item.classID~=2 and item.classID~=4) then return end
    local rows={approximate=true,foreverCraftEstimate=true}
    local function add(material,chance,minimum,maximum)
        rows[#rows+1]={itemID=material,chance=chance,minQuantity=minimum or 1,maxQuantity=maximum or minimum or 1}
    end
    local weapon=item.classID==2
    if level<=15 then
        add(10940,weapon and 20 or 80,2,3)
        add(10938,weapon and 80 or 20,2,3)
    elseif level<=20 then
        add(10940,weapon and 20 or 75,3,4)
        add(10939,weapon and 75 or 20,2,3)
        add(10978,5,2)
    elseif level<=25 then add(10978,100)
    elseif level<=30 then add(11084,100)
    elseif level<=35 then add(11138,100)
    elseif level<=40 then add(11139,100)
    elseif level<=45 then add(11177,100)
    elseif level<=50 then add(11178,100)
    elseif level<=55 then add(14343,100)
    else add(14344,99.5); add(20725,0.5) end
    return rows
end
function Policy.HasSalvagerBuff()
    if not Policy.IsForever() then return false end
    if C_UnitAuras and C_UnitAuras.GetPlayerAuraBySpellID then
        local ok,aura=pcall(C_UnitAuras.GetPlayerAuraBySpellID,1283701)
        return ok and type(aura)=="table"
    end
    if AuraUtil and AuraUtil.FindAuraBySpellID then return AuraUtil.FindAuraBySpellID(1283701,"player","HELPFUL")~=nil end
    return false
end
function Policy.SalvagerActive()
    if not Policy.IsForever() then return false end
    local settings=ns.App and ns.App.db or {}
    if settings.salvagerMode=="off" then return false end
    if settings.salvagerMode=="on" then return true end
    return Policy.HasSalvagerBuff()
end
local function sampleKey(item, boosted)
    local id=Policy.ItemID(item)
    if not id or type(item)~="table" then return end
    local version,build=GetBuildInfo()
    return table.concat({version or "",build or "",id,item.quality or 0,item.baseItemLevel or 0,item.classID or 0,boosted and "salvager" or "normal"},":")
end
function Policy.Observed(item)
    if not Policy.IsForever() then return end
    local key=sampleKey(item,Policy.SalvagerActive())
    local db=ns.App and ns.App.db
    local sample=key and db and type(db.disenchantSamples)=="table" and db.disenchantSamples[key]
    -- Small samples are collected but never advertised as reliable loot tables.
    if type(sample)~="table" or type(sample.count)~="number" or sample.count<20 or sample.count>10000000 or type(sample.materials)~="table" then return end
    local rows={empirical=true,approximate=true,samples=sample.count}
    for id,data in pairs(sample.materials) do
        if type(id)=="number" and type(data)=="table" and type(data.hits)=="number" and data.hits>0 and data.hits<=sample.count
            and type(data.total)=="number" and data.total>0 and type(data.min)=="number" and type(data.max)=="number" then
            rows[#rows+1]={itemID=id,chance=100*data.hits/sample.count,minQuantity=data.min,maxQuantity=data.max,meanQuantity=data.total/data.hits}
        else return end
    end
    if #rows==0 then return end
    table.sort(rows,function(a,b) return a.itemID<b.itemID end)
    return rows
end
function Policy.BonusPercent()
    if not Policy.SalvagerActive() then return 0 end
    local value=tonumber(ns.App and ns.App.db and ns.App.db.salvagerBonusPercent) or 0
    return value==value and math.max(0,math.min(1000,value)) or 0
end
-- Pre-squish item levels only. Forever uses the mainline project ID, but
-- has its own 1.60.x client version and original-era item levels.
-- Reference: https://warcraft.wiki.gg/wiki/Disenchanting_tables
-- Uncommon: min/max ilvl, dust/essence/shard IDs, armor/weapon chances,
-- dust min/max quantity, essence min/max quantity. Shards always yield one.
local uncommon = {
    {5,15,10940,10938,nil,80,20,20,80,1,2,1,2},
    {16,20,10940,10939,10978,75,20,20,75,2,3,1,2},
    {21,25,10940,10998,10978,75,15,15,75,4,6,1,2},
    {26,30,11083,11082,11084,75,20,20,75,1,2,1,2},
    {31,35,11083,11134,11138,75,20,20,75,2,5,1,2},
    {36,40,11137,11135,11139,75,20,20,75,1,2,1,2},
    {41,45,11137,11174,11177,75,20,20,75,2,5,1,2},
    {46,50,11176,11175,11178,75,20,20,75,1,2,1,2},
    {51,55,11176,16202,14343,75,20,22,75,2,5,1,2},
    {56,60,16204,16203,14344,75,20,22,75,1,2,1,2},
    {61,65,16204,16203,14344,75,20,22,75,2,5,2,3},
}
local rare = {
    {1,25,10978}, {26,30,11084}, {31,35,11138}, {36,40,11139},
    {41,45,11177}, {46,50,11178}, {51,55,14343}, {56,80,14344,20725},
}
local function outcome(id, chance, minQuantity, maxQuantity)
    return {itemID = id, chance = chance, minQuantity = minQuantity or 1, maxQuantity = maxQuantity or minQuantity or 1}
end
local function find(rows, level)
    for _, row in ipairs(rows) do
        if level >= row[1] and level <= row[2] then return row end
    end
end

ns.DisenchantResults = {}
-- Enchanter-crafted wands are exceptions to the quality/item-level tables.
-- Sources and scope: Docs/DisenchantExclusions.md. Use IDs, never localized names.
local noDisenchant = {
    [11287]=true, -- Lesser Magic Wand
    [11288]=true, -- Greater Magic Wand
    [11289]=true, -- Lesser Mystic Wand
    [11290]=true, -- Greater Mystic Wand
}
local foreverNoDisenchant = {
    [247789]=true, -- Novice's Practice Wand
    [249144]=true, -- Twisted Nether Wand
    [249234]=true, -- Dreambough Wand
    [249232]=true, -- Lesser Eternal Wand
    [249237]=true, -- Greater Eternal Wand
    [249385]=true, -- Brilliant Wand
}
local function IsForever()
    local version = GetBuildInfo and GetBuildInfo()
    return type(version) == "string" and version:match("^1%.60%.") ~= nil
end
function ns.DisenchantResults.IsExcluded(reference)
    if type(reference) == "table" then reference = reference.itemID or reference.link end
    local id = type(reference) == "number" and reference
        or type(reference) == "string" and tonumber(reference:match("item:(%d+)") or reference)
    return id ~= nil and (noDisenchant[id] == true or IsForever() and foreverNoDisenchant[id] == true) or false
end
function ns.DisenchantResults.Get(item)
    if not item then return nil end
    if ns.DisenchantResults.IsExcluded(item) then return nil end
    if ns.ForecastPolicy then
        local observed=ns.ForecastPolicy.Observed(item)
        if observed then return observed end
        local override=ns.ForecastPolicy.overrides[ns.ForecastPolicy.ItemID(item)]
        if ns.ForecastPolicy.IsForever() and override then return override end
        local estimate=ns.ForecastPolicy.Estimate(item)
        if estimate then return estimate end
        if ns.ForecastPolicy.IsUnverified(item) then return nil end
    end
    local level, quality = item.baseItemLevel, item.quality
    if type(level)~="number" or level<=0 then return end
    if item.classID ~= 2 and item.classID ~= 4 then return nil end
    if quality == 2 then
        local row = find(uncommon, level)
        if not row then return nil end
        local weapon = item.classID == 2
        local dust, essence = row[weapon and 8 or 6], row[weapon and 9 or 7]
        local essenceID = row[4]
        -- Forever: uncommon weapons ilvl 16-30 all yield Greater Magic Essence
        -- (Wowhead Forever disenchant data); armor keeps the classic essences.
        if weapon and level >= 21 and level <= 30 then essenceID = 10939 end
        local results = {outcome(row[3], dust, row[10], row[11]), outcome(essenceID, essence, row[12], row[13])}
        if row[5] then results[#results + 1] = outcome(row[5], 100 - dust - essence) end
        return results
    elseif quality == 3 then
        local row = find(rare, level)
        if not row then return nil end
        if row[4] then return {outcome(row[3],99.5),outcome(row[4],0.5)} end
        return {outcome(row[3],100)}
    elseif quality == 4 then
        local rows={{40,45,11177,2,4},{46,50,11178,2,4},{51,55,14343,2,4},
            {56,60,20725,1,1},{61,88,20725,1,2}}
        local row = find(rows, level)
        if row then return {outcome(row[3],100,row[4],row[5])} end
    end
end


function addon.disenchantValue(item, quote)
    if not IsForever() then return end
    ns.App.db=type(DisenchantryDB)=="table" and DisenchantryDB or nil
    local outcomes=ns.DisenchantResults.Get(item)
    if not outcomes then return end
    local total=0
    for _, result in ipairs(outcomes) do
        if result.chance>0 then
            local price=quote(result.itemID)
            if not price then return end
            local quantity=result.meanQuantity or (result.minQuantity+result.maxQuantity)/2
            total=total+result.chance/100*quantity*price
        end
    end
    if not outcomes.empirical then total=total*(1+Policy.BonusPercent()/100) end
    return total
end
