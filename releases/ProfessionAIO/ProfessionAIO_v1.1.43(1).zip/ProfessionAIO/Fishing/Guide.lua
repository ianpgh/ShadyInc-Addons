local _, suite = ...

-- Source references are in README.txt. A map-only destination has no coordinates.
local nat = {1445, .586, .601, "Nat Pagle, Tidefury Cove"}
local fishbot = {1434, .273, .769, "Fishbot 5000, Booty Bay"}
local outdoors = {96101, 96604, 96605, 96606, 96607, 96608}
local tournamentWater = {1434, nil, nil, "Stranglethorn Vale"}
local guide = {
    Quests = {
        {name="Expert Fishing: The Bass and You",
            instructions="Buy the book from Old Man Heming in Booty Bay. Read it at Fishing 125 and level 20 to raise your cap to 225.",
            destinations={{1434,.274,.770,"Old Man Heming, Booty Bay"}}},
        {name="Nat Pagle, Angler Extreme", questID=6607, turnIn=1,
            instructions="At Fishing 225 and level 35, accept the quest from Nat before fishing. Catch all four fish in open water in their named subzones, then return to Nat to unlock Artisan Fishing.",
            destinations={nat,{1444,.62,.51,"Feralas Ahi · Verdantis River"},{1435,.90,.72,"Mahi Mahi · Misty Reed Strand"},
                {1443,.25,.77,"Striker · Sar’theris Strand"},{1434,.33,.32,"Blue Sailfin · Savage Coast"}}},
        {name="Camping 101: Fishing (Dun Morogh)", faction="Alliance", questID=96050, prerequisite=96608, turnIn=2,
            instructions="In this starter-zone route, do The Great Outdoors with Eric Brighthammer first. Raise Fishing to 20 and turn in Camping 101: Fishing to Paxton Ganter to learn Fish Bowl.",
            destinations={{1426,.467,.539,"Eric Brighthammer, Dun Morogh"},{1426,.355,.402,"Turn-in: Paxton Ganter"}}},
        {name="Camping 101: Fishing (Mulgore)", faction="Horde", questID=97932, prerequisite=96605, turnIn=2,
            instructions="In this starter-zone route, finish The Great Outdoors before taking Camping 101: Fishing from Kaga Wildhoof. Raise Fishing to 20, then visit Uthan Stillwater in Bloodhoof Village for Fish Bowl.",
            destinations={{1412,.461,.674,"Kaga Wildhoof, Mulgore"},{1412,.442,.638,"Turn-in: Uthan Stillwater"}}},
        {name="Snapjaws, Mon!", faction="Horde", questID=7815, turnIn=1,
            instructions="Pick up Katoom the Angler’s quest in Revantusk Village and hunt the required Saltwater Snapjaws along the coast. Turn in to Katoom for Nat Pagle’s Extreme Angler FC-5000.",
            destinations={{1425,.803,.815,"Katoom the Angler, Revantusk Village"}}},
    },
    Uniques = {
        {name="Stranglethorn Fishing Extravaganza",
            instructions="During the event, catch 40 Speckled Tastyfish from Schools of Tastyfish on the Stranglethorn coast. Bring them to Riggle Bassbait in Booty Bay for the main competition.",
            destinations={tournamentWater,{1434,.276,.776,"Riggle Bassbait, Booty Bay"}}},
        {name="Keefer’s Angelfish",
            instructions="Fish in Schools of Tastyfish during the Extravaganza. Take this rare catch to Fishbot 5000 for the Lucky Fishing Hat.",
            destinations={tournamentWater,fishbot}},
        {name="Brownell’s Blue Striped Racer",
            instructions="Fish in Schools of Tastyfish during the Extravaganza. Take this rare catch to Fishbot 5000 for Nat Pagle’s Extreme Anglin’ Boots.",
            destinations={tournamentWater,fishbot}},
        {name="Dezian Queenfish",
            instructions="Fish in Schools of Tastyfish during the Extravaganza. Take this rare catch to Fishbot 5000 for High Test Eternium Fishing Line.",
            destinations={tournamentWater,fishbot}},
        {name="Big Iron Fishing Pole",
            instructions="Search the Shellfish Traps underwater off Shadowprey Village in Desolace. The pole can also be bought from other players.",
            destinations={{1443,nil,nil,"Shadowprey Village, Desolace"}}},
        {name="Uncommon and rare camp catches",
            instructions="Place a Fishing Rack (140 Fishing) or Fishing Hut (300 Fishing) by a campfire and get its camp buff. The Rack enables uncommon catches and the Hut enables rare catches. Use the buff at your chosen fishing spot.",
            destinations={}},
        {name="Wreckage and floating debris",
            instructions="Cast into floating debris or wreckage pools for a chance at trunks. These are roaming pools, so use the zone map to find the waterways.",
            destinations={{2548,nil,nil,"Riverglades"}}},
    },
}

local function onQuest(log, id)
    if log.IsOnQuest then return log.IsOnQuest(id) end
    return log.GetLogIndexForQuestID and (log.GetLogIndexForQuestID(id) or 0) > 0
end

local function questStatus(entry)
    local id, log = entry.questID, C_QuestLog
    if not id or not log then return nil, 1 end

    local completed = log.IsQuestFlaggedCompleted
    local ready = log.ReadyForTurnIn or log.IsComplete
    if completed and completed(id) then return "Complete" end
    if ready and ready(id) then return "Turn in", entry.turnIn end
    if onQuest(log, id) then return "In progress" end
    if not (log.IsOnQuest or log.GetLogIndexForQuestID) then return nil, 1 end

    if entry.prerequisite then
        if onQuest(log, entry.prerequisite) then return "Prerequisite", 1 end
        for _, prerequisite in ipairs(outdoors) do
            if completed and completed(prerequisite) then return "Quest start", 1 end
        end
        return "Check prerequisite", 1
    end
    return "Quest start", 1
end

function suite.buildFishingGuide(parent, closeWindow, fishingSkill)
    local page = "Quests"
    local refresh
    local function switch(category)
        page = category
        refresh(true)
    end
    local skillText = suite.label(parent, 17, -47)
    local function refreshSkill()
        local rank, _, cap = fishingSkill()
        skillText:SetText(cap > 0 and ("Fishing %d/%d"):format(rank, cap) or "Fishing —")
    end
    suite.button(parent, "Quests", 125, -42, 88, function() switch("Quests") end)
    suite.button(parent, "Uniques", 219, -42, 88, function() switch("Uniques") end)
    local scroll = CreateFrame("ScrollFrame", nil, parent, "UIPanelScrollFrameTemplate")
    scroll:SetPoint("TOPLEFT", 16, -76)
    scroll:SetPoint("BOTTOMRIGHT", parent, "TOPRIGHT", -32, -254)
    local content = CreateFrame("Frame", nil, scroll)
    content:SetSize(498, 1)
    scroll:SetScrollChild(content)
    local heading = suite.label(parent, 17, -265)
    heading:SetTextColor(1,.82,.46)
    local details = suite.label(parent, 17, -286)
    details:SetWidth(509)
    local rows, locations = {}, {}

    local function open(destination)
        local opened
        if destination[2] and destination[3] then
            opened = suite.openLearningMap(destination, "Fishing", destination[4])
        else
            opened = suite.openWorldMap(destination[1])
        end
        if opened then closeWindow() end
    end

    local function selectEntry(entry)
        heading:SetText(entry and entry.name or "")
        details:SetText(entry and entry.instructions or "Choose an entry for directions.")
        for i, button in ipairs(locations) do
            local destination = entry and entry.destinations[i]
            button.destination = destination
            button:SetShown(destination ~= nil)
            if destination then button:SetText(destination[4]) end
        end
    end
    for i = 1, 6 do
        locations[i] = suite.button(parent, "", 16 + ((i-1)%2)*258, -344 - math.floor((i-1)/2)*27, 250,
            function(self) open(self.destination) end)
        locations[i]:Hide()
    end
    refresh = function(reset)
        refreshSkill()
        local count = 0
        local faction = UnitFactionGroup and UnitFactionGroup("player")
        for _, entry in ipairs(guide[page]) do
            if not entry.faction or entry.faction == faction then
                count = count+1
                local row = rows[count]
                if not row then
                    row = suite.button(content, "", 0, -(count-1)*26, 498, function(self)
                        local selected = self.entry
                        selectEntry(selected)
                        local _, index = questStatus(selected)
                        if index and selected.destinations[index] then open(selected.destinations[index]) end
                    end)
                    row:SetScript("OnEnter", function(self)
                        GameTooltip:SetOwner(self, "ANCHOR_RIGHT")
                        GameTooltip:SetText(self.entry.name)
                        GameTooltip:AddLine(self.entry.instructions, 1,1,1,true)
                        GameTooltip:Show()
                    end)
                    row:SetScript("OnLeave", function() GameTooltip:Hide() end)
                    rows[count] = row
                end
                row.entry = entry
                local status = questStatus(entry)
                row:SetText(status and (entry.name .. "  ·  " .. status) or entry.name)
                row:Show()
            end
        end
        for i = count+1, #rows do rows[i]:Hide() end
        content:SetHeight(math.max(1,count*26))
        if reset then
            scroll:SetVerticalScroll(0)
            selectEntry(nil)
        end
    end
    parent:SetScript("OnShow", function() refresh(false) end)
    parent:RegisterEvent("QUEST_LOG_UPDATE")
    parent:RegisterEvent("SKILL_LINES_CHANGED")
    parent:SetScript("OnEvent", function(_, event)
        if not parent:IsShown() then return end
        if event == "SKILL_LINES_CHANGED" then refreshSkill() else refresh(false) end
    end)
    refresh(true)
end
