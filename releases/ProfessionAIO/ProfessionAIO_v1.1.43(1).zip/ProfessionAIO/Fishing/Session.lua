local name, suite = ...
local sessions = {}
suite.fishingSession = sessions
local db, skill
local slots, countedCatch, countedEscape = {}, false, false
local pendingLoot = false
local castStarted

local function now()
    return (GetServerTime and GetServerTime()) or time()
end

function sessions.isBobber(guid)
    return type(guid) == "string" and not (issecretvalue and issecretvalue(guid))
        and guid:match("^GameObject%-%d+%-%d+%-%d+%-%d+%-35591%-") ~= nil
end

function sessions.initialize(character, readSkill)
    db, skill = character, readSkill
end

function sessions.stopCast()
    if not castStarted then return end
    local session = db.currentSession
    session.activeSeconds = session.activeSeconds + math.max(0, GetTime() - castStarted)
    castStarted = nil
end

function sessions.enterWorld(initialLogin, reloading)
    sessions.stopCast()
    if not initialLogin or reloading then return end
    local current = db.currentSession
    if current then
        db.fishingHistory = db.fishingHistory or {}
        table.insert(db.fishingHistory, 1, current)
        while #db.fishingHistory > 30 do table.remove(db.fishingHistory) end
        db.currentSession = nil
    end
end

local function updateSkill(session)
    local rank = skill()
    if rank <= 0 then return end
    session.startSkill = session.startSkill or rank
    session.endSkill = math.max(session.endSkill or rank, rank)
end

function sessions.cast()
    sessions.stopCast()
    local stamp = now()
    local session = db.currentSession
    if not session then
        session = {started=stamp, updated=stamp, casts=0, catches=0, escapes=0, items={}}
        db.currentSession = session
    end
    session.activeSeconds = session.activeSeconds or 0
    castStarted = GetTime()
    session.casts = session.casts + 1
    session.updated = stamp
    countedEscape = false
    updateSkill(session)
end

function sessions.skillChanged()
    if db.currentSession then updateSkill(db.currentSession) end
end

function sessions.escape(message)
    local session = db.currentSession
    if not session or countedEscape or not ERR_FISH_ESCAPED
        or (issecretvalue and issecretvalue(message)) or message ~= ERR_FISH_ESCAPED then return end
    countedEscape = true
    session.escapes = session.escapes + 1
    session.updated = now()
end

function sessions.snapshotLoot()
    if not db.currentSession or not GetLootSourceInfo or not GetLootSlotLink or not GetLootSlotInfo then return end
    if not pendingLoot then
        pendingLoot = true
        countedCatch = false
    end
    for slot = 1, GetNumLootItems() do
        if slots[slot] == nil and sessions.isBobber(GetLootSourceInfo(slot)) then
            local link = GetLootSlotLink(slot)
            local icon, label, count = GetLootSlotInfo(slot)
            if type(link) == "string" and not (issecretvalue and issecretvalue(link)) then
                local id = tonumber(link:match("item:(%d+)"))
                if id and type(count) == "number" and count > 0 then
                    slots[slot] = {id=id, link=link, label=label, icon=icon, count=count}
                end
            end
        end
    end
end

function sessions.lootCleared(slot)
    local item = slots[slot]
    local session = db.currentSession
    if not session or not item then return end
    slots[slot] = false
    if not countedCatch then
        countedCatch = true
        session.catches = session.catches + 1
    end
    local record = session.items[item.id]
    if not record then
        record = {name=item.label, link=item.link, icon=item.icon, count=0}
        session.items[item.id] = record
    end
    record.count = record.count + item.count
    session.latest = item.id
    session.updated = now()
    updateSkill(session)
end

function sessions.closeLoot()
    slots, pendingLoot = {}, false
end

local function heading(parent, text, y)
    local bar = CreateFrame("Frame", nil, parent, "BackdropTemplate")
    bar:SetPoint("TOPLEFT", 16, y)
    bar:SetPoint("TOPRIGHT", -16, y)
    bar:SetHeight(22)
    local texture = bar:CreateTexture(nil, "BACKGROUND")
    texture:SetAllPoints()
    texture:SetColorTexture(.30,.23,.12,.65)
    local label = suite.label(bar, 0, 0)
    label:ClearAllPoints()
    label:SetPoint("CENTER")
    label:SetTextColor(1,.84,.47)
    label:SetText(text)
    return label
end

local function totals(items)
    local vendor, auction, vendorKnown, auctionKnown = 0, 0, 0, 0
    local itemInfo = C_Item and C_Item.GetItemInfo or GetItemInfo
    local getPrice = suite.priceAPI()
    for _, entry in ipairs(items) do
        local id, count = entry.id, entry.record.count
        if itemInfo then
            local sell = select(11, itemInfo(id))
            if type(sell) == "number" then vendor, vendorKnown = vendor + sell*count, vendorKnown + 1 end
        end
        if getPrice then
            local ok, price = pcall(getPrice, name, id)
            if ok and type(price) == "number" and price > 0 and price < math.huge then
                auction, auctionKnown = auction + price*count, auctionKnown + 1
            end
        end
    end
    local function display(value, known)
        if known == 0 then return "—" end
        return suite.money(value) .. (known < #items and " (partial)" or "")
    end
    return display(vendor, vendorKnown), display(auction, auctionKnown)
end

local function duration(seconds)
    seconds = math.floor(seconds)
    return ("%dh %02dm %02ds"):format(math.floor(seconds/3600), math.floor(seconds/60)%60, seconds%60)
end

function sessions.build(container)
    local parent = CreateFrame("Frame", nil, container)
    parent:SetAllPoints()
    local log = CreateFrame("Frame", nil, container)
    log:SetAllPoints()
    log:Hide()
    local page = 0
    local refresh
    local function showLog(open)
        parent:SetShown(not open)
        log:SetShown(open)
        refresh(true)
    end
    suite.button(parent, "Log", 439, -39, 56, function() showLog(true) end)
    suite.button(log, "Back", 467, -39, 65, function() showLog(false) end)
    suite.label(log, 16, -44):SetText("Fishing session log")
    heading(log, "Fishing logins", -67)
    local logScroll = CreateFrame("ScrollFrame", nil, log, "UIPanelScrollFrameTemplate")
    logScroll:SetPoint("TOPLEFT", 16, -101)
    logScroll:SetPoint("BOTTOMRIGHT", -32, 32)
    local logContent = CreateFrame("Frame", nil, logScroll)
    logContent:SetSize(498, 1)
    logScroll:SetScrollChild(logContent)
    local logRows = {}
    local emptyLog = suite.label(logContent, 4, -8)
    emptyLog:SetText("No fishing sessions yet.")

    local function refreshLog(history, resetScroll)
        local index = 0
        for login = 0, #history do
            local entry = login == 0 and db.currentSession or history[login]
            if entry then
                index = index + 1
                local row = logRows[index]
                if not row then
                    row = suite.button(logContent, "", 0, -(index-1)*28, 496, function(self)
                        page = self.login
                        showLog(false)
                    end)
                    row:SetHeight(25)
                    logRows[index] = row
                end
                row.login = login
                local stamp = date("%b %d, %Y %I:%M %p", entry.started)
                if login == 0 then stamp = "Current  ·  " .. stamp end
                row:SetText(("%s    ·    %d casts    ·    %d catches"):format(stamp, entry.casts, entry.catches))
                row:Show()
            end
        end
        for i = index+1, #logRows do logRows[i]:Hide() end
        emptyLog:SetShown(index == 0)
        logContent:SetHeight(math.max(24,index*28))
        if resetScroll then logScroll:SetVerticalScroll(0) end
    end

    local previous = suite.button(parent, "<", 16, -39, 29, function() page = page+1; refresh(true) end)
    local nextSession = suite.button(parent, ">", 503, -39, 29, function() page = page-1; refresh(true) end)
    local period = heading(parent, "", -67)
    local active = heading(parent, "", -92)
    local selected = suite.label(parent, 57, -45)
    local summary = suite.label(parent, 19, -128)
    local skillText = suite.label(parent, 19, -150)
    local value = suite.label(parent, 19, -172)
    local latest = suite.label(parent, 19, -194)
    local catchHeading = heading(parent, "Caught this session", -220)
    local scroll = CreateFrame("ScrollFrame", nil, parent, "UIPanelScrollFrameTemplate")
    scroll:SetPoint("TOPLEFT", 16, -248)
    scroll:SetPoint("BOTTOMRIGHT", -32, 32)
    local content = CreateFrame("Frame", nil, scroll)
    content:SetSize(500, 1)
    scroll:SetScrollChild(content)
    local rows = {}

    local function refreshActive(session)
        if not session then active:SetText(""); return end
        local elapsed = session.activeSeconds
        if castStarted and session == db.currentSession then
            elapsed = elapsed + math.max(0, GetTime() - castStarted)
        end
        active:SetText("Active fishing  " .. (elapsed and duration(elapsed) or "Not recorded"))
    end

    local tick = 0
    parent:SetScript("OnUpdate", function(_, elapsed)
        if not castStarted or page ~= 0 then return end
        tick = tick + elapsed
        if tick < .25 then return end
        tick = 0
        refreshActive(db.currentSession)
    end)

    refresh = function(resetScroll)
        local history = db.fishingHistory or {}
        if log:IsShown() then refreshLog(history, resetScroll); return end
        page = math.max(0, math.min(page, #history))
        local session = page == 0 and db.currentSession or history[page]
        previous:SetEnabled(page < #history)
        nextSession:SetEnabled(page > 0)
        local stamp = session and "  •  " .. date("%b %d, %I:%M %p", session.started) or ""
        selected:SetText((page == 0 and "Current login" or ("Past login " .. page)) .. stamp)
        local items = {}
        refreshActive(session)
        if session then
            local seconds = math.max(0, session.updated - session.started)
            period:SetText("Fishing span  " .. duration(seconds))
            local rate = seconds >= 60 and ("    ·    %.0f catches/hr"):format(session.catches*3600/seconds) or ""
            summary:SetText(("Casts %d    ·    Catches %d    ·    Got away %d%s"):format(session.casts,session.catches,session.escapes,rate))
            local gained = (session.endSkill or 0) - (session.startSkill or 0)
            skillText:SetText(("Fishing skill gained  +%d"):format(gained))
            for id, record in pairs(session.items) do items[#items+1] = {id=id, record=record} end
            table.sort(items, function(a,b)
                if a.record.count ~= b.record.count then return a.record.count > b.record.count end
                return (a.record.name or "") < (b.record.name or "")
            end)
            local vendor, auction = totals(items)
            value:SetText(("Vendor %s    ·    AH estimate %s"):format(vendor, auction))
            local last = session.latest and session.items[session.latest]
            latest:SetText(last and ("Latest catch  " .. (last.link or last.name or "")) or "")
        else
            period:SetText("No fishing this login")
            summary:SetText("Cast a line to start tracking.")
            skillText:SetText("")
            value:SetText("")
            latest:SetText("")
        end

        catchHeading:SetText(#items == 0 and "No catches recorded" or "Caught this session")
        for i, entry in ipairs(items) do
            local item = entry.record
            local row = rows[i]
            if not row then
                row = CreateFrame("Button", nil, content)
                row:SetPoint("TOPLEFT",0,-(i-1)*27)
                row:SetSize(500,27)
                row:SetHighlightTexture("Interface\\QuestFrame\\UI-QuestTitleHighlight")
                row.icon = row:CreateTexture(nil,"ARTWORK")
                row.icon:SetSize(21,21)
                row.icon:SetPoint("LEFT",3,0)
                row.label = suite.label(row,32,-7)
                row.count = suite.label(row,446,-7)
                row:SetScript("OnEnter", function(self)
                    if not self.itemLink then return end
                    GameTooltip:SetOwner(self,"ANCHOR_RIGHT")
                    GameTooltip:SetHyperlink(self.itemLink)
                    GameTooltip:Show()
                end)
                row:SetScript("OnLeave", function() GameTooltip:Hide() end)
                rows[i] = row
            end
            row.itemLink = item.link
            row.icon:SetTexture(item.icon or 134400)
            row.label:SetText(item.link or item.name or ("Item " .. entry.id))
            row.count:SetText("×" .. item.count)
            row:Show()
        end
        for i = #items+1,#rows do rows[i]:Hide() end
        content:SetHeight(math.max(1,#items*27))
        if resetScroll then scroll:SetVerticalScroll(0) end
    end
    return refresh
end
