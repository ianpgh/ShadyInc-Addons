local _, suite = ...
local bobber = {}
suite.fishingBobber = bobber
local db, marker, markedPlate
local colors = {
    {"Gold", 1,.76,.25}, {"Aqua", .20,.95,1}, {"Violet", .75,.45,1},
    {"Green", .42,1,.38}, {"White", 1,1,1},
}
local styles = {"Diamond", "Arrow"}
local sizes = {22, 34, 46}
local sizeNames = {"Small", "Medium", "Large"}

local function choice(options, index, fallback)
    return options[index] and index or fallback
end

local function paint(texture)
    local color = colors[choice(colors, db.bobberColor, 1)]
    local style = styles[choice(styles, db.bobberStyle, 1)]
    local size = sizes[choice(sizes, db.bobberSize, 2)]
    if style == "Arrow" then
        texture:SetTexture("Interface\\Minimap\\MinimapArrow")
        texture:SetRotation(math.pi)
    else
        texture:SetTexture("Interface\\TargetingFrame\\UI-RaidTargetingIcon_3")
        texture:SetRotation(0)
    end
    texture:SetVertexColor(color[2], color[3], color[4])
    texture:SetSize(size, size)
end

function bobber.initialize(settings)
    db = settings
end

function bobber.enabled()
    return db.markBobber == true
end

function bobber.update(active)
    local plate
    if active and bobber.enabled() and C_NamePlate and C_NamePlate.GetNamePlateForUnit
        and UnitGUID and suite.fishingSession.isBobber(UnitGUID("softinteract")) then
        plate = C_NamePlate.GetNamePlateForUnit("softinteract")
    end
    if not plate then
        if marker then marker:Hide() end
        markedPlate = nil
        return
    end
    if not marker then
        marker = CreateFrame("Frame", nil, UIParent)
        marker:SetSize(1,1)
        marker:SetFrameStrata("HIGH")
        marker.icon = marker:CreateTexture(nil, "OVERLAY")
        marker.icon:SetPoint("CENTER")
    end
    if markedPlate ~= plate then
        marker:ClearAllPoints()
        marker:SetPoint("BOTTOM", plate, "TOP", 0, 4)
        markedPlate = plate
    end
    paint(marker.icon)
    marker:Show()
end

function bobber.build(parent, update)
    local title = suite.label(parent, 20, -48)
    title:SetText("Bobber marker")
    title:SetTextColor(1,.82,.43)
    local check = CreateFrame("CheckButton", nil, parent, "UICheckButtonTemplate")
    check:SetPoint("TOPLEFT", 17, -76)
    check:SetSize(24,24)
    check:SetChecked(bobber.enabled())
    suite.label(parent, 45, -82):SetText("Mark the fishing bobber")
    check:SetScript("OnClick", function(self)
        db.markBobber = self:GetChecked() == true
        update()
    end)

    local alert = CreateFrame("CheckButton", nil, parent, "UICheckButtonTemplate")
    alert:SetPoint("TOPLEFT", 263, -76)
    alert:SetSize(24,24)
    alert:SetChecked(db.windowsBobberAlert == true)
    suite.label(parent, 291, -82):SetText("Windows bobber alert")
    local warning = suite.label(parent, 265, -104)
    warning:SetTextColor(1,.78,.25)
    warning:SetText("Requires Bobber Alert Companion. /reload to save changes.")
    warning:SetShown(db.windowsBobberAlert == true)
    alert:SetScript("OnClick", function(self)
        db.windowsBobberAlert = self:GetChecked() == true
        warning:SetShown(db.windowsBobberAlert)
        if db.windowsBobberAlert then
            print("Profession AIO: Windows bobber alerts require Bobber Alert Companion. Use /reload to save this setting.")
        end
    end)

    local box = suite.window(parent, {.025,.10,.15,1})
    box:SetSize(215, 151)
    box:SetPoint("TOPLEFT", 20, -125)
    local icon = box:CreateTexture(nil, "ARTWORK")
    icon:SetPoint("CENTER",0,7)
    local caption = suite.label(box, 0, 0)
    caption:ClearAllPoints()
    caption:SetPoint("BOTTOM",0,14)
    caption:SetText("Preview")
    paint(icon)

    local function selector(label, setting, options, fallback, y)
        suite.label(parent, 265, y-4):SetText(label)
        local index = choice(options, db[setting], fallback)
        local function text()
            local value = options[index]
            return type(value) == "table" and value[1] or value
        end
        local button
        button = suite.button(parent, text(), 365, y, 146, function()
            index = index % #options + 1
            db[setting] = index
            button:SetText(text())
            paint(icon)
            update()
        end)
    end
    selector("Style", "bobberStyle", styles, 1, -129)
    selector("Color", "bobberColor", colors, 1, -169)
    selector("Size", "bobberSize", sizeNames, 2, -209)
    suite.label(parent, 20, -298):SetText("The marker follows the bobber your Interact key targets.")
end
