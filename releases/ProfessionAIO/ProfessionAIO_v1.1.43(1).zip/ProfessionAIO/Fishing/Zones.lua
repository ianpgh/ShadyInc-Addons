local _, suite = ...

-- Reference thresholds are for open water. Some waters within a zone differ.
-- Classic reference: https://wowforever.wclbox.com/en/zhuanye/fishing
-- Forever observations: https://github.com/rynmon/OneCast/blob/main/ZoneLevels.lua
local bands = {
    {1, 25, {"Dun Morogh", "Durotar", "Elwynn Forest", "Mulgore", "Teldrassil", "Tirisfal Glades", "Zephras Isle"}},
    {1, 75, {"Blackfathom Deeps", "Darkshore", "Darnassus", "Ironforge", "Loch Modan", "Orgrimmar",
        "Silverpine Forest", "Stormwind City", "The Deadmines", "Thunder Bluff", "Undercity", "Wailing Caverns", "Westfall"}},
    {1, 100, {"The Barrens"}},
    {55, 150, {"Ashenvale", "Duskwood", "Hillsbrad Foothills", "Redridge Mountains", "Stonetalon Mountains", "Wetlands"}},
    {130, 225, {"Alterac Mountains", "Arathi Highlands", "Desolace", "Dustwallow Marsh",
        "Scarlet Monastery", "Stranglethorn Vale", "Swamp of Sorrows", "Thousand Needles"}},
    {nil, 225, {"City of Dalaran", "Riverglades"}},
    {205, 300, {"Azshara", "Felwood", "Feralas", "Jaguero Isle (Stranglethorn Vale)", "Maraudon",
        "Moonglade", "Sunken Temple", "Tanaris", "The Hinterlands", "Un'Goro Crater", "Western Plaguelands"}},
    {330, 425, {"Bay of Storms (Azshara)", "Burning Steppes", "Deadwind Pass", "Eastern Plaguelands",
        "Hetaera's Clutch (Azshara)", "Jademir Lake (Feralas)", "Scalebeard's Cave (Azshara)", "Scholomance",
        "Silithus", "Stratholme", "Winterspring", "Zul'Gurub"}},
    {nil, nil, {"Excavation Site: Wetlands", "Gilneas", "Mount Hyjal", "Shen'dralas"}},
}
local zones = {}
for _, band in ipairs(bands) do
    for _, area in ipairs(band[3]) do
        zones[#zones+1] = {name=area, minimum=band[1], reliable=band[2]}
    end
end
table.sort(zones, function(a, b) return a.name < b.name end)
suite.fishingZones = zones

-- UiMap IDs from the Forever client. Subzones use their containing map.
local maps = {
    ["Alterac Mountains"]=1416, ["Arathi Highlands"]=1417, Ashenvale=1440, Azshara=1447,
    ["Burning Steppes"]=1428, Darkshore=1439, Darnassus=1457, ["Deadwind Pass"]=1430,
    Desolace=1443, ["Dun Morogh"]=1426, Durotar=1411, Duskwood=1431, ["Dustwallow Marsh"]=1445,
    ["Eastern Plaguelands"]=1423, ["Elwynn Forest"]=1429, Felwood=1448, Feralas=1444,
    ["Hillsbrad Foothills"]=1424, Ironforge=1455, ["Loch Modan"]=1432, Moonglade=1450,
    ["Mount Hyjal"]=2482, Mulgore=1412, Orgrimmar=1454, ["Redridge Mountains"]=1433,
    Riverglades=2548, ["Shen'dralas"]=2652, Silithus=1451, ["Silverpine Forest"]=1421,
    ["Stonetalon Mountains"]=1442, ["Stormwind City"]=1453, ["Stranglethorn Vale"]=1434,
    ["Swamp of Sorrows"]=1435, Tanaris=1446, Teldrassil=1438, ["The Barrens"]=1413,
    ["The Hinterlands"]=1425, ["Thousand Needles"]=1441, ["Thunder Bluff"]=1456,
    ["Tirisfal Glades"]=1420, ["Un'Goro Crater"]=1449, Undercity=1458, ["Western Plaguelands"]=1422,
    Westfall=1436, Wetlands=1437, Winterspring=1452, ["Zephras Isle"]=2521,
}
local fallbackMaps = {
    ["Blackfathom Deeps"]=1440, ["City of Dalaran"]=1416, ["Excavation Site: Wetlands"]=1437,
    Gilneas=1421, Maraudon=1443, ["Scarlet Monastery"]=1420, Scholomance=1422,
    Stratholme=1423, ["Sunken Temple"]=1435, ["The Deadmines"]=1436,
    ["Wailing Caverns"]=1413, ["Zul'Gurub"]=1434,
}
local aliases = {
    ["City of Dalaran"]={"Dalaran City", "Dalaran"},
    ["The Deadmines"]={"Deadmines"},
    ["Wailing Caverns"]={"The Wailing Caverns"},
    ["Sunken Temple"]={"Temple of Atal'Hakkar", "The Temple of Atal'Hakkar"},
}
local clientMaps
local function findClientMap(zoneName)
    if not C_Map or not C_Map.GetMapChildrenInfo then return end
    if not clientMaps then
        local ok, children = pcall(C_Map.GetMapChildrenInfo, 947, nil, true)
        if not ok or type(children) ~= "table" then return end
        clientMaps = {}
        for _, info in ipairs(children) do
            if info.name and info.mapID then clientMaps[info.name] = clientMaps[info.name] or info.mapID end
        end
    end
    if clientMaps[zoneName] then return clientMaps[zoneName] end
    for _, alias in ipairs(aliases[zoneName] or {}) do
        if clientMaps[alias] then return clientMaps[alias] end
    end
end

function suite.fishingZoneMapID(zoneName)
    local parent = zoneName:match("%(([^()]+)%)$")
    return maps[parent or zoneName] or findClientMap(zoneName) or fallbackMaps[zoneName]
end
