local _, suite = ...
local api = suite.tradeSkillAPI
local SKILL_LINE = 356
local crafts = {
    {id=1229745, item=279967, name="Fish Bowl", materials={{6291,1,"Raw Brilliant Smallfish"},{3371,1,"Empty Vial"}}},
    {id=1262990, item=279965, name="Fishing Rack", materials={{4470,2,"Simple Wood"},{8925,1,"Crystal Vial"},{8365,2,"Raw Mithril Head Trout"}}},
    {id=1262998, item=279966, name="Fishing Hut", materials={{4470,5,"Simple Wood"},{14048,2,"Bolt of Runecloth"},{273295,1,"Seasonal Fish Steaks"}}},
}

local function isFishingCraft(frame)
    local profession = Enum and Enum.Profession and Enum.Profession.Fishing or -1
    return frame and frame:IsShown() and (suite.isProfession(frame, SKILL_LINE, profession, "Fishing")
        or suite.isProfession(frame, SKILL_LINE, profession, "Bait and Tackle"))
end

local function bagCount(id)
    local count = C_Item and C_Item.GetItemCount or GetItemCount
    return count and count(id, false, false, false) or 0
end

local function maximum(recipe, ready, counts)
    if not ready or InCombatLockdown() then return 0 end
    local info = api("GetRecipeInfo", recipe.id)
    if not info or not info.learned or info.disabled then return 0 end
    for _, requirement in ipairs(api("GetRecipeRequirements", recipe.id) or {}) do
        if requirement.met == false then return 0 end
    end
    local limit = 999
    for i, material in ipairs(recipe.materials) do
        limit = math.min(limit, math.floor(counts[i] / material[2]))
    end
    local craftable = api("GetCraftableCount", recipe.id)
    if type(craftable) == "number" then limit = math.min(limit, craftable) end
    return math.max(0, limit)
end

local function itemRow(parent, offset, width)
    local row = suite.button(parent, "", 16, offset, width, function() end)
    row:SetHeight(25)
    row:SetScript("OnEnter", function(self)
        if self.itemID then suite.showItemTooltip(self, self.itemID) end
    end)
    row:SetScript("OnLeave", function() GameTooltip:Hide() end)
    return row
end

function suite.buildFishingCraft(parent)
    local popup = suite.window(UIParent, {.055,.082,.108,1})
    popup:SetSize(328, 238)
    popup:SetPoint("CENTER", parent, "CENTER")
    popup:SetFrameStrata("FULLSCREEN_DIALOG")
    popup:SetFrameLevel(parent:GetFrameLevel()+25)
    popup:SetToplevel(true)
    popup:SetClampedToScreen(true)
    popup:SetMovable(true)
    popup:EnableMouse(true)
    popup:RegisterForDrag("LeftButton")
    popup:SetScript("OnDragStart", popup.StartMoving)
    popup:SetScript("OnDragStop", popup.StopMovingOrSizing)
    popup:Hide()
    local index = 1
    local refresh, attached, ownsNative, open
    local title = suite.label(popup, 16, -13)
    title:SetText("Fishing Crafts")
    title:SetTextColor(1,.8,.42)
    suite.button(popup, "X", 288, -8, 25, function() popup:Hide() end)
    suite.button(popup, "<", 16, -38, 29, function() index = (index-2)%#crafts+1; refresh() end)
    suite.button(popup, ">", 283, -38, 29, function() index = index%#crafts+1; refresh() end)
    local output = itemRow(popup, -36, 225)
    output:ClearAllPoints()
    output:SetPoint("TOPLEFT", 51, -36)
    local reagents = {itemRow(popup,-72,296), itemRow(popup,-101,296), itemRow(popup,-130,296)}
    local note = suite.label(popup, 17, -163)

    local quantity = CreateFrame("EditBox", nil, popup, "InputBoxTemplate")
    quantity:SetPoint("TOPLEFT", 51, -194)
    quantity:SetSize(40,22)
    quantity:SetAutoFocus(false)
    quantity:SetNumeric(true)
    quantity:SetMaxLetters(3)
    quantity:SetText("1")
    quantity:SetScript("OnEscapePressed", function(self) self:ClearFocus() end)
    local function amount() return tonumber(quantity:GetText()) or 0 end
    local limit = 0
    suite.button(popup, "-", 16, -195, 25, function()
        quantity:SetText(tostring(math.max(1,amount()-1)))
    end)
    suite.button(popup, "+", 97, -195, 25, function()
        quantity:SetText(tostring(math.min(math.max(1,limit),amount()+1)))
    end)
    local maxButton = suite.button(popup, "Max", 130, -195, 50, function()
        if limit > 0 then quantity:SetText(tostring(limit)) end
    end)
    local craft = suite.button(popup, "Craft", 214, -195, 98, function()
        local requested = amount()
        refresh()
        if requested >= 1 and requested <= limit and requested % 1 == 0 then
            quantity:ClearFocus()
            api("CraftRecipe", crafts[index].id, requested)
        end
    end)

    refresh = function()
        if not popup:IsShown() then return end
        local frame = ProfessionsFrame or TradeSkillFrame
        local fishing = isFishingCraft(frame)
        if attached and (attached ~= frame or not fishing or InCombatLockdown()) then
            suite.restoreNative(popup)
            attached = nil
        end
        if fishing and not InCombatLockdown() and not attached and suite.hideNative(popup, frame) then
            attached = frame
        end
        local recipe = crafts[index]
        output.itemID = recipe.item
        output:SetText(("%s  (%d/%d)"):format(recipe.name,index,#crafts))
        local counts = {}
        for i, row in ipairs(reagents) do
            local material = recipe.materials[i]
            row:SetShown(material ~= nil)
            if material then
                counts[i] = bagCount(material[1])
                row.itemID = material[1]
                local getItemInfo = C_Item and C_Item.GetItemInfo or GetItemInfo
                local label = (getItemInfo and getItemInfo(row.itemID)) or material[3]
                row:SetText(("%s  %d / %d"):format(label,counts[i],material[2]*math.max(1,amount())))
            end
        end
        limit = maximum(recipe, fishing, counts)
        local info = fishing and api("GetRecipeInfo", recipe.id)
        if InCombatLockdown() then note:SetText("Crafting is unavailable in combat.")
        elseif not fishing then note:SetText("Bait and Tackle is closed.")
        elseif not info then note:SetText("Loading recipe data…")
        elseif not info.learned then note:SetText("Recipe not learned.")
        elseif limit == 0 then note:SetText("Requires materials or a crafting requirement.")
        else note:SetText(("Can craft %d"):format(limit)) end
        open:SetShown(not fishing and not InCombatLockdown())
        maxButton:SetEnabled(limit > 0)
        craft:SetEnabled(amount() >= 1 and amount() <= limit)
    end

    open = suite.button(popup, "Open recipes", 197, -158, 115, function()
        if InCombatLockdown() then return end
        ownsNative = not isFishingCraft(ProfessionsFrame or TradeSkillFrame)
        api("OpenTradeSkill", SKILL_LINE)
        refresh()
    end)
    quantity:SetScript("OnTextChanged", refresh)
    popup:SetScript("OnShow", function()
        popup:Raise()
        if not InCombatLockdown() and not isFishingCraft(ProfessionsFrame or TradeSkillFrame) then
            ownsNative = true
            api("OpenTradeSkill", SKILL_LINE)
        end
        refresh()
    end)
    popup:SetScript("OnHide", function()
        suite.restoreNative(popup)
        attached = nil
        local frame = ProfessionsFrame or TradeSkillFrame
        if ownsNative and isFishingCraft(frame) and not InCombatLockdown() and HideUIPanel then
            HideUIPanel(frame)
        end
        ownsNative = nil
    end)
    parent:HookScript("OnHide", function() popup:Hide() end)
    suite.addPoll(refresh)
    return function() popup:SetShown(not popup:IsShown()) end, refresh
end
