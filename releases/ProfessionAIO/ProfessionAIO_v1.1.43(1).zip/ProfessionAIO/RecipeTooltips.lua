local _, suite = ...

function suite.showItemTooltip(owner, itemID)
    GameTooltip:SetOwner(owner, "ANCHOR_RIGHT")
    if GameTooltip.SetItemByID then GameTooltip:SetItemByID(itemID)
    else GameTooltip:SetHyperlink("item:" .. itemID) end
    GameTooltip:Show()
end

local function showRecipeTooltip(owner)
    local entry = owner.entry
    if not entry then return false end
    local schematic = entry.id and suite.tradeSkillAPI("GetRecipeSchematic", entry.id, false)
    local itemID = entry.outputItemID or (schematic and schematic.outputItemID)
    if type(itemID) == "number" and itemID > 0 then
        suite.showItemTooltip(owner, itemID)
    elseif entry.id then
        local link = suite.tradeSkillAPI("GetRecipeItemLink", entry.id)
        GameTooltip:SetOwner(owner, "ANCHOR_RIGHT")
        if type(link) == "string" and link:find("|Hitem:",1,true) then
            GameTooltip:SetHyperlink(link)
        elseif GameTooltip.SetSpellByID then
            GameTooltip:SetSpellByID(entry.id)
        else return false end
        GameTooltip:Show()
    else return false end
    return true
end

local hovered, renderHovered
local events = CreateFrame("Frame")
events:RegisterEvent("MODIFIER_STATE_CHANGED")
events:SetScript("OnEvent", function(_, _, key)
    if hovered and (key == "LSHIFT" or key == "RSHIFT") then renderHovered(hovered) end
end)

function suite.bindRecipeTooltip(button, summary, updateEntry, preferNative, appendNative)
    local function render(owner)
        if updateEntry then owner.entry = updateEntry() end
        local native = (preferNative and preferNative()) or (IsShiftKeyDown and IsShiftKeyDown())
        if native and showRecipeTooltip(owner) then
            if appendNative then
                appendNative(owner)
                GameTooltip:Show()
            end
            return
        end
        summary(owner)
    end
    button:SetScript("OnEnter", function(self)
        hovered, renderHovered = self, render
        render(self)
    end)
    local function leave(self)
        if hovered == self then
            hovered, renderHovered = nil, nil
            GameTooltip:Hide()
        end
    end
    button:SetScript("OnLeave", leave)
    button:HookScript("OnHide", leave)
    return render
end
