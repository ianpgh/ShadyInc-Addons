local name, suite = ...
local addon = suite.EnchantIt

function addon.resaleProceeds(entry, schematic)
    local routes = {{label="Vendor"}, {label="AH"}, {label="DE"}}
    local item = schematic and schematic.outputItemID
    if entry.target or type(item) ~= "number" or item <= 0 then return routes end
    local getInfo = C_Item and C_Item.GetItemInfo or GetItemInfo
    if not getInfo then return routes end
    local itemName, link, quality, level, _, _, _, _, _, _, vendor, classID, _, bind = getInfo(item)
    if not itemName then return routes end
    local count = math.max(1, schematic.quantityMin or 1)
    local getPrice = addon.priceAPI()
    local function quote(id)
        if not getPrice then return end
        local ok, value = pcall(getPrice, name, id)
        if ok and type(value) == "number" and value > 0 and value < math.huge then return value end
    end
    if type(vendor) == "number" and vendor > 0 then routes[1].proceeds = vendor * count end
    if bind == 0 or bind == 2 then
        local auction = quote(item)
        if auction then routes[2].proceeds = math.floor(auction * count * .95) end
    end
    local disenchant = addon.disenchantValue({itemID=item, link=link, quality=quality,
        baseItemLevel=level, classID=classID}, quote)
    if disenchant then routes[3].proceeds = math.floor(disenchant * count * .95) end
    return routes
end

function addon.resaleDelta(proceeds, cost)
    if proceeds == nil or cost == nil then return "|cff9ca6b3—|r" end
    local delta = proceeds - cost
    if delta == 0 then return "0c" end
    local prefix = delta > 0 and "|cff8ee68e+" or "|cffff9292-"
    return prefix .. addon.money(math.abs(delta)) .. "|r"
end
