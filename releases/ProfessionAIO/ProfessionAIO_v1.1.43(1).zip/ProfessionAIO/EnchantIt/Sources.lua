local _, suite = ...
local addon = suite.EnchantIt

-- Sources: Wowhead Forever Enchanting Overview, The Forever Guides source
-- catalog, Zockify’s Forever sources, and WoW Handbook’s dungeon entrances.
local early = {
    Alliance={1453, .430, .642, "Lucan Cordell (Stormwind)"},
    Horde={1454, .538, .384, "Godan (Orgrimmar)"},
}
local expert = {
    Alliance={1429, .648, .706, "Kitta Firewind (Elwynn Forest)"},
    Horde={1442, .492, .572, "Hgarth (Stonetalon Mountains)"},
}
local annora = {1418, .653, .426, "Annora (Uldaman back entrance)"}
local artisanRanks = {
    ["Enchant Chest - Superior Intellect"]=230, ["Enchant Shield - Greater Spirit"]=230,
    ["Enchant Boots - Agility"]=235, ["Enchant 2H Weapon - Greater Impact"]=240,
    ["Enchant Bracer - Greater Strength"]=240, ["Enchant Chest - Stats"]=245,
    ["Enchant Weapon - Greater Striking"]=245, ["Enchant Gloves - Minor Haste"]=250,
    ["Enchanted Leather"]=250, ["Enchanted Thorium Bar"]=250,
}
for recipe, rank in pairs(artisanRanks) do addon.trainerRanks[recipe] = rank end
for recipe, rank in pairs({
    ["Runed Truesilver Rod"]=220, ["Enchant Chest - Superior Stamina"]=220,
    ["Enchant Boots - Minor Speed"]=225, ["Enchant Gloves - Strength"]=225,
    ["Enchant Gloves - Agility"]=210, ["Enchant Bracer - Intellect"]=210, ["Enchant Weapon - Striking"]=195,
}) do addon.trainerRanks[recipe] = rank end

local recipes = {}
local function register(locations, names, note)
    for _, recipe in ipairs(names) do recipes[recipe] = {locations=locations, note=note} end
end
local kithas = {1454, .539, .380, "Kithas (Orgrimmar)"}
local supply = {Alliance={1453,.528,.743,"Jessara Cordell (Stormwind)"}, Horde=kithas}
register(supply, {"Enchant Chest - Minor Intellect", "Minor Wizard Oil", "Minor Mana Oil", "Lesser Wizard Oil"})
register({Horde=kithas}, {"Enchant Chest - Lesser Intellect"}, "Published vendors are Horde. A formula may also be available through other players.")
register({Alliance={1455,.610,.440,"Tilli Thistlefuzz (Ironforge)"}, Horde=kithas},
    {"Enchant 2H Weapon - Lesser Intellect"})
register({Alliance={1440,.351,.521,"Dalria (Ashenvale)"}, Horde={1442,.454,.593,"Kulwia (Stonetalon Mountains)"}},
    {"Enchant Cloak - Minor Agility","Enchant Bracer - Lesser Strength"})
register({Neutral={1424,.554,.347,"Zixil (Hillsbrad Foothills)"},
    Horde={1456,.450,.388,"Nata Dawnstrider (Thunder Bluff)"}}, {"Enchant Boots - Minor Agility"})
register({Alliance={1457,.610,.174,"Mythrin'dir (Darnassus)"}, Horde={1458,.640,.374,"Daniel Bartlett (Undercity)"}},
    {"Enchant Shield - Greater Stamina"})
register({Neutral={1451,.520,.394,"Kania (Silithus)"}}, {"Lesser Mana Oil","Wizard Oil"})
register({Neutral={1452,.612,.372,"Qia (Everlook)"}}, {"Enchant Chest - Major Stamina"})
register({Neutral={1450,.482,.401,"Lorelae Wintersong (Moonglade)"}},
    {"Enchant Cloak - Superior Defense","Runed Arcanite Rod"})
register({Neutral={1448,.657,.028,"Meilosh (Timbermaw Hold entrance)"}},
    {"Enchant 2H Weapon - Agility","Enchant Weapon - Agility"}, "Timbermaw Hold reputation required; check the formula.")
local blackrock = {Neutral={1427,.2715,.7248,"Blackrock Depths entrance"}}
register(blackrock, {"Enchant Weapon - Fiery Weapon"}, "Formula drops from Pyromancer Loregrain inside Blackrock Depths.")
register(blackrock, {"Conductive Shield Coating","Enchant Weapon - Strength","Enchant Weapon - Mighty Spirit","Enchant Weapon - Mighty Intellect"},
    "Lokhtos Darkbargainer is inside Blackrock Depths. Check the formula for reputation requirements.")

local function registerZone(map, zone, recipe, source)
    register({Neutral={map,nil,nil,zone}}, {recipe}, "Drop: " .. source .. ".")
end
registerZone(1422, "Western Plaguelands", "Enchant Weapon - Crusader", "Western Plaguelands (Scarlet Spellbinder)")
registerZone(1430, "Deadwind Pass", "Enchant Bracer - Superior Strength", "Deadwind Pass (Deadwind Warlock)")
registerZone(1423, "Eastern Plaguelands", "Enchant Chest - Major Intellect", "Eastern Plaguelands (Scarlet Enchanter)")
registerZone(1452, "Winterspring", "Enchant Weapon - Icy Chill", "Winterspring (Anguished Highborne)")
registerZone(1423, "Eastern Plaguelands", "Enchant Shield - Superior Spirit", "Eastern Plaguelands (Scarlet Warder)")
registerZone(1428, "Burning Steppes", "Greater Eternal Wand", "Burning Steppes (Flamekin Torcher)")
registerZone(1447, "Azshara", "Enchant Gloves - Greater Agility", "Azshara (Legashi Rogue)")
registerZone(1425, "The Hinterlands", "Enchant Bracer - Greater Intellect", "The Hinterlands (Vilebranch Shadowcaster)")
registerZone(1447, "Azshara", "Enchant Gloves - Advanced Skinning", "Azshara (Spitelash Myrmidon)")
registerZone(1449, "Un'Goro Crater", "Lesser Eternal Wand", "Un'Goro Crater (Muculent Ooze)")
registerZone(1448, "Felwood", "Enchant Bracer - Greater Agility", "Felwood (Deadwood Gardener)")
registerZone(1435, "Swamp of Sorrows", "Enchant Gloves - Advanced Herbalism", "Swamp of Sorrows")
registerZone(1416, "Alterac Mountains", "Enchant Cloak - Lesser Agility", "Alterac Mountains (Syndicate Assassin)")
registerZone(1444, "Feralas", "Enchant 2H Weapon - Lesser Strength", "Feralas (Hatecrest Sorceress)")
registerZone(1434, "Stranglethorn Vale", "Enchant Gloves - Advanced Mining", "Stranglethorn Vale (Venture Co. Strip Miner)")
registerZone(1418, "Badlands", "Dreambough Wand", "Badlands (Dustbelcher Ogre Mage)")
registerZone(1445, "Dustwallow Marsh", "Enchant 2H Weapon - Lesser Agility", "Dustwallow Marsh (Firemane Scout)")
registerZone(1417, "Arathi Highlands", "Enchant Gloves - Skinning", "Arathi Highlands")
registerZone(1443, "Desolace", "Enchant Bracer - Agility", "Desolace (Mage Hunter)")
registerZone(1417, "Arathi Highlands", "Twisted Nether Wand", "Arathi Highlands (Boulderfist Magus)")
registerZone(1437, "Wetlands", "Enchant Gloves - Mining", "Wetlands")
registerZone(1440, "Ashenvale", "Enchant Gloves - Herbalism", "Ashenvale, Stonetalon Mountains")
registerZone(1424, "Hillsbrad Foothills", "Enchant Gloves - Fishing", "Hillsbrad Foothills")
registerZone(1440, "Ashenvale", "Enchant Bracer - Minor Healing Power", "Ashenvale (Dark Strand Cultist)")
register({Alliance={1439,nil,nil,"Darkshore"}, Horde={1421,nil,nil,"Silverpine Forest"}},
    {"Enchant Bracer - Minor Intellect"}, "Drops from Coastal Frenzy in Darkshore or Vile Fin Tidehunter in Silverpine Forest.")

register(blackrock, {"Smoking Heart of the Mountain"}, "Drops from Lord Roccor in Blackrock Depths.")
local spire = {Neutral={1428,.3299,.2517,"Blackrock Spire entrance"}}
register(spire, {"Enchant Weapon - Superior Striking","Enchant Gloves - Greater Strength",
    "Enchant 2H Weapon - Superior Impact"}, "Drops inside Blackrock Spire.")
register(spire, {"Molten Heart of the Mountain"}, "Drops from Pyroguard Emberseer in Upper Blackrock Spire.")
register(spire, {"Dormant Heart of the Mountain","Frozen Heart of the Mountain"},
    "Drops in Lower Blackrock Spire: Mother Smolderweb (Dormant) or Mor Grayhoof (Frozen).")
register({Neutral={1422,.6968,.7341,"Scholomance entrance"}},
    {"Enchant Weapon - Lifestealing","Enchant 2H Weapon - Major Spirit","Enchant 2H Weapon - Strength"},
    "Drops inside Scholomance.")
register({Neutral={1423,.2609,.1044,"Stratholme main entrance"}},
    {"Enchant 2H Weapon - Major Intellect","Enchant Weapon - Unholy Weapon","Enchant Bracer - Superior Agility"},
    "Drops inside Stratholme.")
register({Neutral={1435,.692,.548,"Temple of Atal'Hakkar entrance"}},
    {"Enchant Cloak - Greater Resistance"}, "Drops inside Sunken Temple.")
register({Neutral={1413,.4227,.8987,"Razorfen Kraul entrance"}},
    {"Arcane Salvager"}, "Charlga Razorflank is one source for the blueprint.")
register({Neutral={1439,.3349,.9353,"Blackfathom Deeps entrance"}},
    {"Blackfathom Mana Oil"}, "Visit the altar inside Blackfathom Deeps.")
register({Neutral={1451,.290,.927,"Temple of Ahn'Qiraj entrance"}},
    {"Enchant Gloves - Threat","Enchant Cloak - Subtlety"}, "Drops from the Twin Emperors.")

register({Neutral={1451,.520,.394,"Kania (Silithus)"}},
    {"Enchant Cloak - Greater Fire Resistance","Enchant Cloak - Greater Nature Resistance"})
register({Neutral={1434,.151,.160,"Rin’wosho the Trader (Yojamba Isle)"}},
    {"Brilliant Wizard Oil","Brilliant Mana Oil"}, "Rin'wosho the Trader on Yojamba Isle; Zandalar Tribe reputation required.")
register({Neutral={1423,.718,.502,"Quartermaster Miranda Breechlock"}},
    {"Enchant Bracer - Healing Power","Enchant Bracer - Mana Regeneration"},
    "Argent Dawn quartermasters stock the formula; check your reputation.")

register({Neutral={1449,.290,.715,"Shaper’s Terrace entrance"}},
    {"Arcane Forge"}, "Blueprint drops from Nanaya inside Shaper’s Terrace.")
register({Neutral={1443,.662,.794,"Gorhak (Desolace)"}},
    {"Enchant Bracer - Lesser Agility","Enchant Bracer - Lesser Healing Power"},
    "Check the Mysterious Mysticism quest for access to this formula.")
register({Alliance={1457,.610,.174,"Mythrin’dir (Darnassus)"}, Horde={1435,.440,.560,"Banalash (Stonard)"}},
    {"Enchant Bracer - Deflection"})
register({Alliance={1424,.480,.550,"Micha Yance (Southshore)"}, Horde={1417,.740,.320,"Keena (Hammerfall)"}},
    {"Enchant Bracer - Lesser Deflection"})

register({}, {"Enchant Boots - Greater Stamina","Enchant Boots - Greater Agility",
    "Enchant Bracer - Greater Stamina","Enchant Bracer - Greater Spirit","Enchant Bracer - Superior Spirit",
    "Enchant Bracer - Superior Stamina","Enchant Shield - Frost Resistance",
    "Enchant Weapon - Demonslaying","Enchant Gloves - Riding Skill"},
    "Reported as a broad drop pool in Classic data; no confirmed fixed Forever source.")
register({}, {"Enchant Weapon - Winter's Might"},
    "Reported from Smokywood Pastures Special Gifts during Winter Veil.")

local favor = {Alliance={1433,.112,.714,"Alynsia (Redridge Mountains)"}, Horde={1413,.496,.298,"Beneris (The Barrens)"}}
register(favor, {"Mystic Mushroom","Tenets of the Silver Hand","Polished Driftwood Icon",
    "Enchant Weapon - Insight","Enchant Weapon - Recovery","Enchant Weapon - Revelation",
    "Glimmering Staff","Soulstaff","Orb of Mystic Insight","Orb of Souls","Talons of Wrath",
    "Libram of Invocation","Totem of Ancestral Protection","Enchant Necklace - Strength",
    "Enchant Necklace - Spell Power","Enchant Necklace - Healing Power","Enchant Necklace - Agility",
    "Enchant Necklace - Deflection","Radiant Staff","Dreamstaff","Truesilver Conduit","Twisting Essence Jar",
    "Enchant Chest - Absorption","Brilliant Wand","Enchant 2H Weapon - Mighty Spell Power",
    "Enchant 2H Weapon - Mighty Healing Power","Idol of the Dream","Libram of Holy Alacrity",
    "Totem of Thunder","Enchant Gloves - Natural Power","Enchant Bracer - Superior Intellect",
    "Enchant Bracer - Superior Deflection","Enchant Boots - Speed","Enchant Gloves - Holy Power",
    "Enchant Gloves - Arcane Power","Enchant Off Hand - Wisdom","Enchant Off-Hand - Wisdom",
    "Enchant 2H Weapon - Spellblasting","Enchant Cloak - Agility","Enchant Bracer - Greater Spellpower",
    "Enchant Gloves - Superior Strength"}, "Merchant's Favor vendor. Check the formula's favor and reputation requirements.")

function addon.learningSource(recipe, training, faction)
    if not training then return end
    if training.waypoint then return training.waypoint end
    local source = recipes[recipe]
    if source then
        return source.locations[faction] or source.locations.Neutral, source.note
    end
    if not training.trainerRecipe then return end
    if artisanRanks[recipe] then return annora, "Clear the nearby scorpions inside Uldaman to reveal Annora." end
    if training.minimum >= 155 then return expert[faction] end
    return early[faction]
end
