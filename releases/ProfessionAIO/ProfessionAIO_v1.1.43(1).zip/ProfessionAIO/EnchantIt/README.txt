Enchant It 1.0.1 | WoW Forever

Extract the EnchantIt folder to Interface/AddOns and restart WoW. Open
Enchanting normally, from the minimap icon, or with /enchantit (/eci).
Settings and Mini are inside the Blizzard Enchanting window.

Settings
- Show Cheapest uses Auctionator's cached prices to rank learned skill-up
  recipes by material cost per craft, including materials you already own.
  Run an Auctionator scan and press Refresh to use updated prices.
- With Show Cheapest enabled, check Resale beside the recipe filter.
  Each ranked row shows profit or loss per craft for Vendor, AH and DE.
  Hover for proceeds and profit after material costs. AH and DE estimates
  include a 5% auction cut. Missing or inapplicable routes show a dash,
  including direct gear enchants. When enabled, Mini's craft tooltip also
  shows the comparison for the current priced recipe.
- Trainable and Upcoming show unlearned recipes with known requirements.
  Hover for sources and fees when available. Trainer rows can open the
  map. Formula rows open their native recipe entry.
- Solid Background makes the Settings and Mini backgrounds opaque.

Mini
- Browse recipes with the arrows and filter by Orange, Yellow, Green or All.
- Use quantity or Max for crafts with an item output, such as rods and oils.
- For a gear enchant, press Enchant to restore Blizzard's window and select
  that recipe. Use Blizzard's Enchant button and choose your target there.
- Full restores the profession window. Drag Mini or the minimap icon to
  reposition it. Mini shows skill-up countdowns for matching live colors.

Commands: /enchantit, /enchantit mini, /enchantit full, /enchantit settings

Color thresholds and formula requirements are from the 1.60.1.70959
Enchanting recipe data at https://wow-forever.gg/professions/enchanting/.
Additional trainer requirements are from
https://www.wowforeveraddon.com/professions/enchanting/.
Trainer locations reference the ForeverMastery trainer database and
Method's Forever Enchanting trainer listings. Reagents and learned
recipe state come from the live profession UI.
