local _, suite = ...
local addon = suite.EnchantIt
local thresholds = addon.recipeData

function addon.recipeDifficulty(recipe, rank, fallback)
    local limits = thresholds[recipe]
    if not limits then return fallback end
    local yellow, green, gray = unpack(limits)
    return rank < yellow and 0 or (rank < green and 1 or (rank < gray and 2 or 3))
end

function addon.coloredRecipeName(recipe, difficulty)
    local colors = {[0]="ffff8040", [1]="ffffff00", [2]="ff40c040"}
    local color = colors[difficulty]
    return color and ("|c" .. color .. recipe .. "|r") or recipe
end

function addon.nextRecipeColor(recipe, rank, difficulty)
    local limits = thresholds[recipe]
    if not limits or type(rank) ~= "number" or rank < 1 or rank >= 300 then return end
    local current = addon.recipeDifficulty(recipe, rank)
    if difficulty ~= nil and difficulty ~= current then return end
    if current >= 3 then return end
    local nextRank = limits[current + 1]
    if nextRank > 300 then return end
    local labels = {[1]="Yellow", [2]="Green", [3]="Gray"}
    return nextRank - rank, labels[addon.recipeDifficulty(recipe, nextRank)], nextRank
end

function addon.colorCountdown(recipe, rank, difficulty)
    local limits = thresholds[recipe]
    if not limits or type(rank) ~= "number" or rank < 1 or rank >= 300 then return "" end
    local yellow, green, gray = unpack(limits)
    local current = rank < yellow and 0 or (rank < green and 1 or (rank < gray and 2 or 3))
    -- Skip stale data if the live recipe color disagrees with the snapshot.
    if current ~= difficulty then return "" end
    if current == 0 then
        if yellow > 300 then return "Orange through 300" end
        if green == yellow then return ("%d to %s"):format(yellow-rank, green == gray and "gray" or "green") end
        if green > 300 then return ("%d to yellow"):format(yellow-rank) end
        return ("%d to yellow  •  then %d to %s"):format(yellow-rank, green-yellow, green == gray and "gray" or "green")
    elseif current == 1 and green <= 300 then
        return ("%d skill-ups to %s"):format(green-rank, green == gray and "gray" or "green")
    elseif current == 2 then
        if gray > 300 then return "Green through 300" end
        return ("%d skill-ups to gray"):format(gray-rank)
    end
    return ""
end
