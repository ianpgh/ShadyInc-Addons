local _, suite = ...
local addon = suite.CookItBookIt
local api = suite.tradeSkillAPI

local function salePace(quote)
    local sold = quote and quote.soldPerDay
    if type(sold) ~= "number" then return end
    local listed = quote.quantity or 0
    if listed <= 0 then return sold >= 1 and "Sells fast" or "Barely sells" end
    if sold <= 0 then return "Barely sells" end
    local days = listed / sold
    if days < 1 then return "Sells fast" end
    if days <= 3 then return "Sells steadily" end
    if days <= 14 then return "Sells slowly" end
    return "Barely sells"
end

local function ledgerQuote(item)
    local getPrice = AHledgerAPI and AHledgerAPI.GetPrice
    if type(getPrice) ~= "function" then return end
    local ok, quote = pcall(getPrice, item)
    if ok and type(quote) == "table" then return quote end
end

local function median(quote)
    local value = quote and quote.median
    if type(value) == "number" and value > 0 and value < math.huge then return value end
end

function addon.profitableCooking(getMaterials, craftLimit, includeUnlearned)
    local ids = api("GetAllRecipeIDs")
    if type(ids) ~= "table" or #ids == 0 then ids = api("GetFilteredRecipeIDs") or {} end
    local result, ledger, costs, outputs = {}, {}, {}, {}
    local function lookup(item)
        if ledger[item] == nil then ledger[item] = ledgerQuote(item) or false end
        return ledger[item] or nil
    end
    local function ingredientCost(reagents)
        local total = 0
        for _, reagent in ipairs(reagents) do
            local item, amount = unpack(reagent)
            local key = item .. ":" .. amount
            if costs[key] == nil then
                local unit, basis = addon.craftUnitPrice(item, amount)
                if not unit and not addon.usesACPricing() and basis ~= "insufficient_depth" then unit = median(lookup(item)) end
                costs[key] = unit and math.floor(unit * amount + .5) or false
            end
            if costs[key] == false then return end
            total = total + costs[key]
        end
        return total
    end

    local getItemInfo = (C_Item and C_Item.GetItemInfo) or GetItemInfo
    local getMarket = ShadyPriceAPI and ShadyPriceAPI.GetMarketValue
    local auctionPrice = addon.priceAPI()
    local learnedNames, learnedIDs, learnedOutputs, unlearnedData = {}, {}, {}, {}
    local function priceEntry(entry, item, yield)
        if not item or not entry.materials then return end
        if outputs[item] == nil then
            local _, _, _, _, _, _, _, _, _, _, _, _, _, bind = getItemInfo(item)
            if bind == nil or bind == 0 or bind == 2 then
                if addon.usesACPricing() then
                    outputs[item] = addon.auctionQuote(auctionPrice, "ProfessionAIO", item)
                else
                    outputs[item] = median(lookup(item))
                        or addon.auctionQuote(getMarket, item)
                        or addon.auctionQuote(auctionPrice, "ProfessionAIO", item)
                end
            end
            outputs[item] = outputs[item] or false
        end
        entry.outputItemID = item
        if not outputs[item] then return end
        local cost = ingredientCost(entry.materials)
        if not cost then return end
        entry.cost, entry.yield = cost, yield
        entry.proceeds = math.floor(outputs[item] * yield * .95)
        entry.profit = entry.proceeds - cost
        entry.pace = salePace(lookup(item))
    end
    for _, id in ipairs(ids) do
        local recipe = api("GetRecipeInfo", id)
        if recipe and recipe.name and not recipe.isDummyRecipe and not recipe.isRecraft then
            local schematic = api("GetRecipeSchematic", id, false)
            local output = schematic and schematic.outputItemID
            local item = type(output) == "number" and output > 0 and output or nil
            if recipe.learned then
                learnedNames[recipe.name:lower()], learnedIDs[id] = true, true
                if item then
                    learnedOutputs[item] = true
                    local entry = {id=id, name=recipe.name, materials=getMaterials(id, schematic)}
                    priceEntry(entry, item, math.max(1, schematic.quantityMin or 1))
                    if entry.profit and entry.profit > 0 then
                        entry.count = craftLimit(entry)
                        result[#result + 1] = entry
                    end
                end
            elseif includeUnlearned then
                unlearnedData[recipe.name:lower()] = {id=id, schematic=schematic}
            end
        end
    end
    if includeUnlearned then
        local spellBook = C_SpellBook and C_SpellBook.IsSpellKnown
        local bank = Enum and Enum.SpellBookSpellBank and Enum.SpellBookSpellBank.Player
        for _, row in ipairs(addon.hordeCookingCatalog) do
            local name, id, item = row[1], row[2], row[3]
            local live = unlearnedData[name:lower()]
            id = live and live.id or id
            local info = id and api("GetRecipeInfo", id)
            local known = id and (learnedIDs[id] or (info and info.learned)
                or (spellBook and bank and spellBook(id, bank)))
            if not known and not learnedNames[name:lower()] and not learnedOutputs[item] then
                local schematic = live and live.schematic
                local entry = {id=id, name=name, outputItemID=item, unlearned=true, count=0,
                    requiredSkill=row[4], recipeItem=row[6], source=row[7],
                    materials=(schematic and getMaterials(id, schematic)) or row[8]}
                priceEntry(entry, item, (schematic and schematic.quantityMin) or row[5])
                result[#result + 1] = entry
            end
        end
    end
    table.sort(result, function(a, b)
        local left, right = a.profit or -math.huge, b.profit or -math.huge
        if left ~= right then return left > right end
        if a.name ~= b.name then return a.name < b.name end
        return (a.id or 0) < (b.id or 0)
    end)
    return result
end
