local _, suite = ...
local addon = suite.CookItBookIt

-- WoW Forever acquisition facts from What's Training? 11.4.9.
addon.cookingAcquisitions = {
    [7751] = {skill=1, item=6325, vendors={{12, 0, "Alliance"}, {38, 0, "Alliance"}, {1638, 0, "Horde"}, {85, 0, "Horde"}, {141, 0, "Alliance"}, {1497, 0, "Horde"}, {1519, 0, "Alliance"}, {215, 0, "Horde"}, {1, 0, "Alliance"}, {16593, 0}, }},
    [7752] = {skill=1, item=6326, vendors={{85, 0, "Horde"}, {40, 0, "Alliance"}, {1537, 0, "Alliance"}, {14, 0, "Horde"}, {141, 0, "Alliance"}, {16593, 0}, }},
    [15935] = {skill=1, item=12226, vendors={{85, 0, "Horde"}, }},
    [21143] = {skill=1, item=17200, vendors={{1637, 0, "Horde"}, {1497, 0, "Horde"}, {1638, 0, "Horde"}, {1537, 0, "Alliance"}, {1519, 0, "Alliance"}, {1537, 0, "Alliance"}, }},
    [6412] = {skill=10, item=5482, quests={{141, 1, "Alliance"}, }},
    [6413] = {skill=20, item=5483, faction="Horde", vendors={{14, 0, "Horde"}, {16591, 0, "Horde"}, }},
    [2795] = {skill=25, item=2889, faction="Alliance", vendors={{1519, 0, "Alliance"}, }, quests={{1, 5, "Alliance"}, }},
    [1249963] = {skill=25, item=249885, favor=30, vendors={{17, 0, "Horde"}, {44, 0, "Alliance"}, }},
    [1270633] = {skill=25, item=263511, quests={{16593, 4}, }},
    [6414] = {skill=35, item=5484, vendors={{215, 0, "Horde"}, }},
    [21144] = {skill=35, item=17201, vendors={{1637, 0, "Horde"}, {1497, 0, "Horde"}, {1638, 0, "Horde"}, {1537, 0, "Alliance"}, {1519, 0, "Alliance"}, {1537, 0, "Alliance"}, }},
    [1270635] = {skill=35, item=263513, quests={{16593, 4}, }},
    [8607] = {skill=40, item=6892, vendors={{38, 0, "Alliance"}, {130, 0, "Horde"}, }},
    [2542] = {skill=50, item=2697, vendors={{1519, 0, "Alliance"}, }, quests={{40, 9, "Alliance"}, }},
    [6415] = {skill=50, item=5485, vendors={{148, 0, "Alliance"}, }},
    [6416] = {skill=50, item=5486, vendors={{17, 0, "Horde"}, }, quests={{148, 9, "Alliance"}, }},
    [7753] = {skill=50, item=6328, vendors={{12, 0, "Alliance"}, {38, 0, "Alliance"}, {1638, 0, "Horde"}, {141, 0, "Alliance"}, {1497, 0, "Horde"}, {1537, 0, "Alliance"}, {130, 0, "Horde"}, {215, 0, "Horde"}, {16593, 0}, }},
    [7754] = {skill=50, item=6329, vendors={{38, 0, "Alliance"}, }},
    [7827] = {skill=50, item=6368, vendors={{11, 0, "Alliance"}, {1637, 0, "Horde"}, {17, 0}, {40, 0, "Alliance"}, {148, 0, "Alliance"}, {1497, 0, "Horde"}, {1519, 0, "Alliance"}, {130, 0, "Horde"}, {14, 0, "Horde"}, {141, 0, "Alliance"}, {16591, 0}, }},
    [3371] = {skill=60, item=3679, vendors={{1519, 0, "Alliance"}, }, quests={{38, 7, "Alliance"}, }},
    [9513] = {skill=60, item=18160, vendors={{36, 0}, }, quests={{40, 20, "Alliance"}, {17, 20, "Horde"}, }},
    [2543] = {skill=75, item=728, vendors={{1519, 0, "Alliance"}, }, quests={{40, 9, "Alliance"}, }},
    [1250154] = {skill=75, item=250185, quests={{1637, 24, "Horde"}, }},
    [3370] = {skill=80, item=3678, vendors={{1519, 0, "Alliance"}, }, quests={{38, 10, "Alliance"}, }},
    [25704] = {skill=80, item=21099, vendors={{267, 0, "Alliance"}, {267, 0, "Horde"}, {33, 0}, {1638, 0, "Horde"}, {44, 0, "Alliance"}, {1637, 0, "Horde"}, {1657, 0, "Alliance"}, {141, 0, "Alliance"}, {1497, 0, "Horde"}, {1537, 0, "Alliance"}, {1519, 0, "Alliance"}, {17, 0, "Horde"}, {405, 0, "Horde"}, {47, 0, "Horde"}, {139, 0}, {40, 0}, {17, 0, "Horde"}, {16593, 0}, {36, 0, "Alliance"}, {11, 0}, {44, 0, "Alliance"}, {16591, 0}, {36, 0}, {47, 0}, {16591, 0, "Alliance"}, }},
    [2545] = {skill=85, item=2698, vendors={{1519, 0, "Alliance"}, }},
    [3372] = {skill=90, item=3680, vendors={{1519, 0, "Alliance"}, }, quests={{44, 16, "Alliance"}, }},
    [6417] = {skill=90, item=5487, quests={{17, 15, "Horde"}, }},
    [6501] = {skill=90, item=5528, vendors={{40, 0, "Alliance"}, {148, 0, "Alliance"}, }},
    [2547] = {skill=100, item=2699, vendors={{1519, 0, "Alliance"}, }, quests={{44, 15, "Alliance"}, }},
    [2549] = {skill=100, item=2701, vendors={{1519, 0, "Alliance"}, }, quests={{10, 18, "Alliance"}, }},
    [6418] = {skill=100, item=5488, vendors={{17, 0, "Horde"}, }},
    [7755] = {skill=100, item=6330, vendors={{267, 0, "Alliance"}, {267, 0, "Horde"}, {1638, 0, "Horde"}, {1638, 0, "Horde"}, {17, 0}, {1497, 0, "Horde"}, {1519, 0, "Alliance"}, {16591, 0}, }},
    [1249964] = {skill=100, item=249886, favor=30, vendors={{17, 0, "Horde"}, {44, 0, "Alliance"}, }},
    [2548] = {skill=110, item=2700, vendors={{1519, 0, "Alliance"}, }},
    [3377] = {skill=110, item=3683, vendors={{1519, 0, "Alliance"}, }, quests={{10, 17, "Alliance"}, }},
    [3397] = {skill=110, item=3734, vendors={{331, 0, "Alliance"}, {405, 0}, }, quests={{267, 17, "Horde"}, }},
    [6419] = {skill=110, item=5489, vendors={{331, 0, "Alliance"}, {405, 0}, }},
    [3373] = {skill=120, item=3681, vendors={{1519, 0, "Alliance"}, }, quests={{11, 18, "Alliance"}, }},
    [3398] = {skill=125, item=3735, vendors={{17, 0, "Horde"}, {405, 0}, }, quests={{267, 21, "Horde"}, }},
    [15853] = {skill=125, item=12227, vendors={{405, 0}, }},
    [1249965] = {skill=125, item=249887, favor=30, vendors={{17, 0, "Horde"}, {44, 0, "Alliance"}, }},
    [3376] = {skill=130, item=3682, vendors={{1519, 0, "Alliance"}, {33, 0, "Horde"}, {45, 0, "Horde"}, }, quests={{11, 22, "Alliance"}, }},
    [3399] = {skill=150, item=3736, quests={{267, 30, "Alliance"}, }},
    [24418] = {skill=150, item=20075, vendors={{15, 0, "Horde"}, }},
    [3400] = {skill=175, item=3737, quests={{267, 28, "Alliance"}, {267, 28, "Horde"}, }},
    [4094] = {skill=175, item=4609, vendors={{45, 0, "Alliance"}, {405, 0}, }, quests={{3, 33}, }},
    [7213] = {skill=175, item=6039, vendors={{33, 0}, }},
    [7828] = {skill=175, item=6369, vendors={{267, 0, "Alliance"}, {33, 0}, {11, 0, "Alliance"}, {1637, 0, "Horde"}, {148, 0, "Alliance"}, {1497, 0, "Horde"}, {1537, 0, "Alliance"}, {405, 0, "Horde"}, {331, 0, "Horde"}, }},
    [15855] = {skill=175, item=12228, vendors={{33, 0, "Alliance"}, {33, 0, "Horde"}, {45, 0, "Alliance"}, {45, 0, "Horde"}, {15, 0, "Horde"}, {15, 0, "Alliance"}, {405, 0}, }},
    [15856] = {skill=175, item=12229, vendors={{357, 0, "Alliance"}, {357, 0, "Horde"}, {405, 0}, }},
    [15861] = {skill=175, item=12231, vendors={{33, 0, "Alliance"}, {33, 0, "Horde"}, {405, 0}, }},
    [15863] = {skill=175, item=12232, vendors={{8, 0, "Horde"}, {15, 0, "Horde"}, {405, 0, "Horde"}, {405, 0}, }},
    [15865] = {skill=175, item=12233, vendors={{15, 0, "Alliance"}, {405, 0, "Alliance"}, {405, 0}, }},
    [20916] = {skill=175, item=17062, vendors={{267, 0, "Alliance"}, {33, 0}, {11, 0, "Alliance"}, {1637, 0, "Horde"}, {148, 0, "Alliance"}, {1497, 0, "Horde"}, {1537, 0, "Alliance"}, {405, 0, "Horde"}, {331, 0, "Horde"}, }},
    [25954] = {skill=175, item=21219, vendors={{267, 0, "Alliance"}, {267, 0, "Horde"}, {33, 0}, {1638, 0, "Horde"}, {44, 0, "Alliance"}, {1637, 0, "Horde"}, {1657, 0, "Alliance"}, {141, 0, "Alliance"}, {1497, 0, "Horde"}, {1537, 0, "Alliance"}, {1519, 0, "Alliance"}, {17, 0, "Horde"}, {405, 0, "Horde"}, {47, 0, "Horde"}, {139, 0}, {40, 0}, {17, 0, "Horde"}, {16593, 0}, {36, 0, "Alliance"}, {11, 0}, {44, 0, "Alliance"}, {16591, 0}, {36, 0}, {47, 0}, {16591, 0, "Alliance"}, }},
    [1249966] = {skill=180, item=249888, favor=60, vendors={{17, 0, "Horde"}, {44, 0, "Alliance"}, }},
    [1295834] = {skill=185, item=274977, vendors={{16591, 0, "Horde"}, {16591, 0, "Alliance"}, }, quests={{16591, 38, "Horde"}, }},
    [15906] = {skill=200, item=12239, vendors={{15, 0, "Horde"}, {15, 0, "Alliance"}, {405, 0}, }},
    [15910] = {skill=200, item=12240, vendors={{405, 0, "Alliance"}, {405, 0, "Horde"}, {405, 0}, }},
    [1249967] = {skill=200, item=249889, favor=60, vendors={{17, 0, "Horde"}, {44, 0, "Alliance"}, }},
    [1295805] = {skill=200, item=274972, quests={{16591, 36}}},
    [15915] = {skill=225, item=16111, vendors={{8, 0, "Horde"}, {33, 0, "Horde"}, {40, 0, "Alliance"}, }},
    [15933] = {skill=225, item=16110, vendors={{361, 0, "Alliance"}, {361, 0, "Horde"}, {618, 0}, }},
    [18238] = {skill=225, item=13939, vendors={{440, 0}, }},
    [18239] = {skill=225, item=13940, vendors={{33, 0}, }},
    [18241] = {skill=225, item=13941, vendors={{33, 0}, }},
    [20626] = {skill=225, item=16767, vendors={{440, 0}, {16591, 0}, }},
    [22480] = {skill=225, item=18046, vendors={{47, 0, "Alliance"}, {440, 0}, {440, 0}, {16591, 0}, }},
    [1250142] = {skill=225, item=250173, vendors={{618, 0}, }},
    [18240] = {skill=240, item=13942, vendors={{440, 0}, }},
    [18242] = {skill=240, item=13943, vendors={{33, 0}, }},
    [18243] = {skill=250, item=13945, vendors={{440, 0}, }},
    [18244] = {skill=250, item=13946, vendors={{440, 0}, }},
    [1249968] = {skill=250, item=249890, favor=90, vendors={{17, 0, "Horde"}, {44, 0, "Alliance"}, }},
    [18245] = {skill=275, item=13947, vendors={{357, 0, "Alliance"}, {357, 0, "Horde"}, }},
    [18246] = {skill=275, item=13948, vendors={{357, 0, "Alliance"}, {357, 0, "Horde"}, }},
    [18247] = {skill=275, item=13949, vendors={{357, 0, "Alliance"}, {357, 0, "Horde"}, }},
    [1250148] = {skill=275, item=250179, quests={{616, 54, "Alliance"}, {616, 54, "Horde"}, }},
    [1294014] = {skill=275, item=274415, vendors={{616, 0}, }},
    [24801] = {skill=285, item=0, quests={{1377, 54}, }},
    [470370] = {skill=300, item=232443, vendors={{1377, 0}}}, -- Smoked Redgill
    [25659] = {skill=300, item=21025, quests={{440, 60}, }},
}

-- Seafood vendor routes. One mapped seller per faction, with neutral sellers
-- shared where appropriate. Sources: Forever Cooking catalog and vendor listings.
local function both(map, x, y, name)
    return {Neutral={map, x, y, name}}
end

local starterFish = {
    Alliance={1429, .4182, .6716, "Tharynn Bouden (Goldshire)"},
    Horde={1456, .5580, .4700, "Sewa Mistrunner (Thunder Bluff)"},
}
local codAndTrout = {
    Alliance={1424, .5063, .6095, "Lindea Rabonne (Southshore)"},
    Horde={1454, .6999, .2977, "Shankys (Orgrimmar)"},
    Neutral={1434, .2823, .7434, "Kelsey Yance (Booty Bay)"},
}
local feralas = {
    Alliance={1444, .3130, .4346, "Vivianna (Feathermoon Stronghold)"},
    Horde={1444, .7449, .4273, "Sheendra Tallgrass (Camp Mojache)"},
}
local kelsey = codAndTrout.Neutral
local bootyBay = {Neutral=kelsey}
local steamwheedle = both(1446, .6664, .2208, "Gikkix (Steamwheedle Port)")
local ratchet = both(1413, .6277, .3824, "Kilxx (Ratchet)")
local kendor = {Alliance={1453, .764, .530, "Kendor Kabonka (Stormwind)"}}

addon.seafoodVendors = {
    [7751]=starterFish, -- Brilliant Smallfish
    [7752]={Alliance={1455,.4818,.0651,"Tansy Puddlefizz (Ironforge)"},
        Horde={1411,.5606,.7339,"Zansoa (Sen’jin Village)"}}, -- Slitherskin Mackerel
    [7753]={Alliance=starterFish.Alliance,
        Horde={1456,.5100,.5250,"Naal Mistrunner (Thunder Bluff)"}}, -- Longjaw Mud Snapper
    [7754]={Alliance={1432,.4028,.3928,"Khara Deepwater (Thelsamar)"}}, -- Loch Frenzy Delight
    [7827]=ratchet, -- Rainbow Fin Albacore
    [7755]=ratchet, -- Bristle Whisker Catfish
    [6415]={Alliance={1439,.3677,.4428,"Laird (Auberdine)"}}, -- Fillet of Frenzy
    [25704]=bootyBay, -- Smoked Sagefish
    [2545]=kendor, -- Cooked Crab Claw
    [3372]=kendor, -- Murloc Fin Soup
    [6501]={Alliance={1439,.3697,.5635,"Heldan Galesong (Darkshore)"}}, -- Clam Chowder
    [7213]=bootyBay, -- Giant Clam Scorcho
    [7828]=codAndTrout, -- Rockscale Cod
    [20916]=codAndTrout, -- Mithril Headed Trout
    [25954]=bootyBay, -- Sagefish Delight
    [15915]={Alliance={1436,.3623,.9019,"Kriggon Talsone (Westfall)"},
        Horde={1435,.4477,.5663,"Banalash (Stonard)"}}, -- Spiced Chili Crab
    [18238]=steamwheedle, -- Spotted Yellowtail
    [18239]=bootyBay, -- Cooked Glossy Mightfish
    [18241]=bootyBay, -- Filet of Redgill
    [20626]=both(1446,.6701,.2199,"Jabbey (Steamwheedle Port)"), -- Undermine Clam Chowder
    [18240]=steamwheedle, -- Grilled Squid
    [18242]=bootyBay, -- Hot Smoked Bass
    [18243]=steamwheedle, -- Nightfin Soup
    [18244]=steamwheedle, -- Poached Sunscale Salmon
    [18245]=feralas, -- Lobster Stew
    [18246]=feralas, -- Mightfish Steak
    [18247]=feralas, -- Baked Salmon
    [470370]={Alliance={1451,.333,.511,"Chief Expeditionary Requisitioner Enkles (Silithus)"},
        Horde={1451,.507,.697,"Apothecary Quinard (Silithus)"}}, -- Smoked Redgill
}

function addon.seafoodVendor(id, faction)
    local locations = addon.seafoodVendors[id]
    return locations and (locations[faction] or locations.Neutral)
end
