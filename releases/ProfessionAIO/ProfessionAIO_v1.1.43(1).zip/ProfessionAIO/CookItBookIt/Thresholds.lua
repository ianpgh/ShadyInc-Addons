local _, suite = ...
local addon = suite.CookItBookIt

-- Yellow, green, gray skill thresholds from Forever build 1.60.1.70959.
-- https://wow-forever.gg/professions/cooking/
local thresholds = {
    ["Baked Salmon"] = {315, 335, 355},
    ["Barbecued Buzzard Wing"] = {215, 235, 255},
    ["Basic Campfire"] = {1, 3, 5},
    ["Bat Hachee"] = {280, 295, 310},
    ["Bear Brisket"] = {200, 210, 220},
    ["Bear Bruscitti"] = {280, 295, 310},
    ["Beer Basted Boar Ribs"] = {60, 80, 100},
    ["Big Bear Steak"] = {150, 170, 190},
    ["Blood Sausage"] = {100, 120, 140},
    ["Boiled Clams"] = {90, 110, 130},
    ["Breakfast Omelette"] = {80, 87, 95},
    ["Brilliant Smallfish"] = {45, 65, 85},
    ["Briny Seafood Stew"] = {220, 230, 240},
    ["Bristle Whisker Catfish"] = {140, 160, 180},
    ["Calcified Smoothie"] = {185, 190, 195},
    ["Carrion Surprise"] = {215, 235, 255},
    ["Charred Wolf Meat"] = {45, 65, 85},
    ["Clam Chowder"] = {130, 150, 170},
    ["Clam Linguine"] = {280, 295, 310},
    ["Cooked Crab Claw"] = {125, 145, 165},
    ["Cooked Glossy Mightfish"] = {265, 285, 305},
    ["Cookie's Feast"] = {145, 145, 145},
    ["Coyote Steak"] = {90, 110, 130},
    ["Crab Cake"] = {115, 135, 155},
    ["Crispy Bat Wing"] = {45, 65, 85},
    ["Crispy Lizard Tail"] = {140, 160, 180},
    ["Critter Cookie"] = {80, 82, 85},
    ["Crocolisk Gumbo"] = {160, 180, 200},
    ["Crocolisk Steak"] = {120, 140, 160},
    ["Curiously Tasty Omelet"] = {170, 190, 210},
    ["Darkclaw Bisque"] = {325, 345, 365},
    ["Dig Rat Stew"] = {130, 150, 170},
    ["Dirge's Kickin' Chimaerok Chops"] = {325, 345, 365},
    ["Dragonbreath Chili"] = {240, 260, 280},
    ["Dry Pork Ribs"] = {120, 140, 160},
    ["Egg Nog"] = {75, 95, 115},
    ["Expert Campfire"] = {205, 205, 205},
    ["Filet o' Flank"] = {260, 270, 280},
    ["Filet of Redgill"] = {265, 285, 305},
    ["Fillet of Frenzy"] = {90, 110, 130},
    ["Flank au Poivre"] = {285, 300, 315},
    ["Giant Clam Scorcho"] = {215, 235, 255},
    ["Giant Scrambled Eggs"] = {195, 207, 220},
    ["Gingerbread Cookie"] = {45, 65, 85},
    ["Goblin Deviled Clams"] = {165, 185, 205},
    ["Goldthorn Tea"] = {215, 235, 255},
    ["Gooey Spider Cake"] = {150, 170, 190},
    ["Goretusk Liver Pie"] = {90, 110, 130},
    ["Grand Lobster Banquet"] = {290, 300, 310},
    ["Grilled Squid"] = {280, 300, 320},
    ["Heavy Crocolisk Stew"] = {160, 180, 200},
    ["Heavy Kodo Stew"] = {240, 260, 280},
    ["Herb Baked Egg"] = {45, 65, 85},
    ["Hot Lion Chops"] = {175, 195, 215},
    ["Hot Smoked Bass"] = {280, 300, 320},
    ["Hot Wolf Ribs"] = {215, 235, 255},
    ["Iron Oven"] = {300, 300, 300},
    ["Journeyman Campfire"] = {95, 95, 95},
    ["Jungle Stew"] = {215, 235, 255},
    ["Kaldorei Spider Kabob"] = {50, 70, 90},
    ["Lean Venison"] = {150, 170, 190},
    ["Lean Wolf Steak"] = {165, 185, 205},
    ["Lobster Stew"] = {315, 335, 355},
    ["Loch Frenzy Delight"] = {90, 110, 130},
    ["Longjaw Mud Snapper"] = {90, 110, 130},
    ["Mightfish Steak"] = {315, 335, 355},
    ["Mithril Headed Trout"] = {215, 235, 255},
    ["Monster Omelet"] = {265, 285, 305},
    ["Mrrggl Smrrthle"] = {135, 140, 145},
    ["Murloc Fin Soup"] = {130, 150, 170},
    ["Mystery Stew"] = {215, 235, 255},
    ["Nightfin Soup"] = {290, 310, 330},
    ["Peace Tea"] = {30, 37, 45},
    ["Pincer Bites"] = {40, 47, 55},
    ["Plain Ol' Paletusk"] = {200, 215, 230},
    ["Plated Armorfish"] = {245, 250, 255},
    ["Poached Sunscale Salmon"] = {290, 310, 330},
    ["Prehistoric Pulled Raptor"] = {280, 295, 310},
    ["Prowler Steak"] = {260, 270, 280},
    ["Raging Raptor Ribs"] = {280, 295, 310},
    ["Rainbow Fin Albacore"] = {90, 110, 130},
    ["Raptor Rouladen"] = {230, 237, 245},
    ["Redridge Goulash"] = {135, 155, 175},
    ["Roast Raptor"] = {215, 235, 255},
    ["Roasted Boar Meat"] = {45, 65, 85},
    ["Roasted Kodo Meat"] = {75, 95, 115},
    ["Rockscale Cod"] = {190, 210, 230},
    ["Root Tea"] = {155, 170, 185},
    ["Royal Tea"] = {105, 115, 125},
    ["Runn Tum Tuber Surprise"] = {315, 335, 355},
    ["Sage's Tea"] = {260, 275, 290},
    ["Sagefish Delight"] = {215, 235, 255},
    ["Savory Deviate Delight"] = {125, 145, 165},
    ["Savory Stag Sliders"] = {230, 237, 245},
    ["Savory Turtle Stew"] = {280, 295, 310},
    ["Savory Whimsyfin Delight"] = {125, 145, 165},
    ["Scorpid Surprise"] = {60, 80, 100},
    ["Seasoned Wolf Kabob"] = {140, 160, 180},
    ["Skywall Souffle"] = {30, 37, 45},
    ["Slimy Smoothie"] = {105, 112, 120},
    ["Slitherskin Mackerel"] = {45, 65, 85},
    ["Smoked Bear Meat"] = {80, 100, 120},
    ["Smoked Desert Dumplings"] = {325, 345, 365},
    ["Smoked Redgill"] = {325, 345, 365},
    ["Smoked Sagefish"] = {120, 140, 160},
    ["Soaring Pamplona"] = {280, 295, 310},
    ["Soothing Turtle Bisque"] = {215, 235, 255},
    ["Specklefin Feast"] = {290, 300, 310},
    ["Spiced Chili Crab"] = {265, 285, 305},
    ["Spiced Wolf Meat"] = {50, 70, 90},
    ["Spicy Smoothie"] = {215, 220, 225},
    ["Spider Sausage"] = {240, 260, 280},
    ["Spinefin Halibut"] = {210, 215, 220},
    ["Spotted Yellowtail"] = {265, 285, 305},
    ["Steaming Stag Steak"] = {280, 295, 310},
    ["Strider Stew"] = {90, 110, 130},
    ["Succulent Pork Ribs"] = {130, 150, 170},
    ["Sunny Tea"] = {220, 235, 250},
    ["Sunrise Omelette"] = {260, 270, 280},
    ["Sweetpaw Jam"] = {280, 282, 285},
    ["Swiftstrike Steak"] = {280, 295, 310},
    ["Tasty Lion Steak"] = {190, 210, 230},
    ["Tasty Raptor Bites"] = {35, 55, 75},
    ["Tender Wolf Steak"] = {265, 285, 305},
    ["Thistle Tea"] = {100, 120, 140},
    ["Triage Tea"] = {195, 215, 235},
    ["Twice-Spiced Raptor Slice"] = {115, 132, 150},
    ["Undermine Clam Chowder"] = {265, 285, 305},
    ["Venomous Smoothie"] = {30, 37, 45},
    ["Westfall Stew"] = {115, 135, 155},
    ["Wicked Smoothie"] = {255, 262, 270},
}

function addon.recipeDifficulty(recipe, rank, fallback)
    local limits = thresholds[recipe]
    if not limits then return fallback end
    local yellow, green, gray = unpack(limits)
    return rank < yellow and 0 or (rank < green and 1 or (rank < gray and 2 or 3))
end

function addon.coloredRecipeName(recipe, difficulty)
    local colors = {[0]="ffff8040", [1]="ffffff00", [2]="ff40c040"}
    local color = colors[difficulty]
    return color and ("|c" .. color .. recipe .. "|r") or recipe
end

function addon.nextRecipeColor(recipe, rank, difficulty)
    local limits = thresholds[recipe]
    if not limits or type(rank) ~= "number" or rank < 1 or rank >= 300 then return end
    local current = addon.recipeDifficulty(recipe, rank)
    if difficulty ~= nil and difficulty ~= current then return end
    if current >= 3 then return end
    local nextRank = limits[current + 1]
    if nextRank > 300 then return end
    local labels = {[1]="Yellow", [2]="Green", [3]="Gray"}
    return nextRank - rank, labels[addon.recipeDifficulty(recipe, nextRank)], nextRank
end

function addon.colorCountdown(recipe, rank, difficulty)
    local limits = thresholds[recipe]
    if not limits or type(rank) ~= "number" or rank < 1 or rank >= 300 then return "" end
    local yellow, green, gray = unpack(limits)
    local current = rank < yellow and 0 or (rank < green and 1 or (rank < gray and 2 or 3))
    -- Skip stale data if the live recipe color disagrees with the snapshot.
    if current ~= difficulty then return "" end
    if current == 0 then
        if yellow > 300 then return "Orange through 300" end
        if green == yellow then return ("%d to %s"):format(yellow-rank, green == gray and "gray" or "green") end
        if green > 300 then return ("%d to yellow"):format(yellow-rank) end
        return ("%d to yellow  •  then %d to %s"):format(yellow-rank, green-yellow, green == gray and "gray" or "green")
    elseif current == 1 and green <= 300 then
        return ("%d skill-ups to %s"):format(green-rank, green == gray and "gray" or "green")
    elseif current == 2 then
        if gray > 300 then return "Green through 300" end
        return ("%d skill-ups to gray"):format(gray-rank)
    end
    return ""
end
