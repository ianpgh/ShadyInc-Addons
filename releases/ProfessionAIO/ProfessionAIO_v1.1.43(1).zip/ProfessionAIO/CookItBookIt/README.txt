Cook It, Book It 1.4.5 — WoW Forever

Extract CookItBookIt into Interface/AddOns and reload. Open Blizzard
Cooking normally, with /cibi, or from the movable minimap icon. Cook It,
Book It adds Settings and Mini buttons inside the native Cooking window.
Settings opens an in-window popup with Experimental Proximity and
Show Cheapest, including ranked results when enabled.

Show Cheapest ranks learned Cooking recipes in the chosen skill-up color with complete
Auctionator prices by estimated material cost per craft. Run an
Auctionator scan or search and use Refresh after it updates its cache.
The ranking values all materials, including ones you already own.
Hover a result for the ingredients and cost per craft. Click a result
to open its native Cooking recipe.

Mini conceals the original Cooking panel while keeping the active
session. Browse the cheapest list or turn Cheapest off to browse
learned recipes. Use the Mini color dropdown to filter recipes by orange, yellow,
green, or all three. Mini shows skill points left before orange or yellow
recipes change color. Yellow recipes can take extra crafts. Enter a quantity or use Max, then click Craft. Hover
the Craft button for materials. Full restores the original window.
Commands: /cibi, /cibi mini, /cibi full, /cibi settings.

Experimental Proximity is off by default. When enabled, the shortcut
uses a satisfied Cooking Fire requirement or the Cozy Fire aura.
Some cooking stations may expose neither signal.

The main Cooking recipe pane shows the color countdown below Profit
when its label is available, or near the bottom of the recipe pane.

Trainable uses the WoW Forever trainer recipe catalog from What's
Training? 11.4.9 and includes matching offers seen at an NPC trainer.
It shows unlearned Cooking recipes whose minimum skill you meet, and that can still grant skill at your current rank. Upcoming shows
recipes whose minimum skill is higher than your current skill. Priced recipes sort by material cost per
craft, followed by unpriced recipes. The tooltip shows known training
fees. Check the individual NPC for its actual offers and price.

Click a Trainable recipe to pin its source and open the zone map. The pin may be at
a vendor, trainer, or dungeon entrance. If the native map cannot pin
the destination, the addon uses TomTom if available or prints coordinates.

Trainable and Upcoming include vendor and quest recipe sources from
the Forever catalog. Hover to see the available source details.

Trainable includes only orange and yellow skill-up recipes. Result names
show their difficulty color. Upcoming colors are estimated at unlock.
