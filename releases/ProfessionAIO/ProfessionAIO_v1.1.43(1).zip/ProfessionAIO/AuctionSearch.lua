local addonName, suite = ...
-- AC owns all auction communication. Profession AIO only reads the AC quote
-- cache and asks AC to search a selected recipe when the auction house is open.
local button, attached, costLabel, profitLabel, lastQuoteKey
local lastLayoutKey, lastHeader

local function companion()
    local api = AuctionCompanionAPI
    if type(api) == "table" and type(api.SearchRecipe) == "function" then return api end
end
local function atAH()
    local api = companion()
    return api and type(api.IsAvailable) == "function" and api.IsAvailable() or false
end
-- The standard profession helper is strict about the active profession metadata.
-- On WoW Forever the displayed profession may be named correctly even when the
-- skill-line identifiers returned by the adapted Blizzard frame do not match.
local function isEnchanting(form, recipeID)
    local native = ProfessionsFrame or TradeSkillFrame
    if not native or not native:IsShown() then return false end
    local skill = Enum and Enum.Profession and Enum.Profession.Enchanting or 9
    if suite.isProfession(native, 333, skill, "Enchanting") then return true end

    local function matches(value)
        if type(value) ~= "string" then return false end
        -- The profession header may display "Enchanting 270/300".
        return value:lower():match("^%s*enchanting[%s%p%d]*$") ~= nil
    end
    local base = suite.tradeSkillAPI("GetBaseProfessionInfo")
    local child = suite.tradeSkillAPI("GetChildProfessionInfo")
    if suite.matchesProfession(base, 333, skill, "Enchanting") or
        suite.matchesProfession(child, 333, skill, "Enchanting") then return true end
    if matches(base and (base.professionName or base.name)) or
        matches(child and (child.professionName or child.name)) then return true end

    local info = recipeID and suite.tradeSkillAPI("GetRecipeInfo", recipeID)
    if suite.matchesProfession(info, 333, skill, "Enchanting") then return true end

    local current = suite.tradeSkillAPI("GetTradeSkillLine")
    if matches(current) then return true end
    local title = (native.GetTitleText and native:GetTitleText())
        or (native.TitleText and native.TitleText:GetText())
    if matches(title) then return true end
    local page = native.CraftingPage
    local pageTitle = page and (page.ProfessionName or page.ProfessionTitle or page.Title)
    if pageTitle and pageTitle.GetText and matches(pageTitle:GetText()) then return true end

    -- Do not guess from recipe names: spells and miscellaneous crafted recipes
    -- can contain "Enchant" while another profession is actually open.
    return false
end

local function getSelected()
    local native = ProfessionsFrame or TradeSkillFrame
    local page = native and native.CraftingPage
    local form = page and page.SchematicForm
    if not native or not native:IsShown() or not form or not form:IsShown() or
        not form.GetRecipeInfo then return end
    local ok, info = pcall(form.GetRecipeInfo, form)
    if not ok or type(info) ~= "table" then return end
    local id = tonumber(info.recipeID)
    if not id then return end
    local linked = suite.tradeSkillAPI("IsTradeSkillLinked") or suite.tradeSkillAPI("IsNPCCrafting")
    if linked then return end
    return form, id
end
local function onClick()
    local _, id = getSelected()
    if not id then
        print("|cffffc34dProfession AIO:|r Select a recipe first.")
        return
    end
    if not atAH() then
        print("|cffffc34dProfession AIO:|r Open the Auction House to search its reagents with AC.")
        return
    end
    local api = companion()
    if not api then return end
    local ok, err = api.SearchRecipe(id, 1)
    if not ok then print("|cffffc34dProfession AIO:|r " .. tostring(err or "Search unavailable")) end
end
local function money(value)
    value = tonumber(value)
    if not value or value < 0 then return "--" end
    value = math.floor(value + .5)
    if value >= 10000 then return ("%dg %02ds %02dc"):format(math.floor(value/10000),math.floor(value/100)%100,value%100) end
    if value >= 100 then return ("%ds %02dc"):format(math.floor(value/100),value%100) end
    return tostring(value).."c"
end
local function setHeaderText(label, value)
    label:SetFontObject(GameFontNormal)
    label:SetText(value)
    if label:GetStringWidth() > 156 then label:SetFontObject(GameFontNormalSmall) end
end
local function updateEstimate(id, enchanting)
    if not costLabel or not profitLabel then return end
    local api = companion()
    local getPrice = api and api.GetPriceByItemID
    local getMaterialCost = api and api.GetMaterialCost
    local prefix = "Cost: "
    local schematic = suite.tradeSkillAPI("GetRecipeSchematic", id, false)
    if type(getPrice) ~= "function" or type(schematic) ~= "table" then
        setHeaderText(costLabel, prefix .. "--")
        if not enchanting then setHeaderText(profitLabel, "Profit: --") end
        return
    end
    local cost, unknown = 0, 0
    for _, slot in ipairs(schematic.reagentSlotSchematics or {}) do
        local choices = slot and slot.reagents
        if type(choices) == "table" and #choices == 1 and choices[1].itemID then
            local reagentID = tonumber(choices[1].itemID)
            -- AC returns multiple values (price, source, ...).  Capture only the
            -- first return *before* calling tonumber: tonumber(f()) would pass
            -- the string source as tonumber's numeric-base argument and crash.
            local quote
            if reagentID and type(getMaterialCost) == "function" then
                quote = getMaterialCost(reagentID)
            end
            if not quote and reagentID then quote = getPrice(reagentID) end
            local price = tonumber(quote)
            if price and price > 0 then
                cost = cost + price * (tonumber(slot.quantityRequired) or 0)
            else
                unknown = unknown + 1
            end
        elseif slot and slot.required ~= false then
            unknown = unknown + 1
        end
    end
    if unknown > 0 then
        setHeaderText(costLabel, prefix .. "--")
        if not enchanting then
            setHeaderText(profitLabel, ("Profit: -- (%d missing)"):format(unknown))
            profitLabel:SetTextColor(1, .72, .32)
        end
        costLabel:SetTextColor(1, .72, .32)
        return
    end

    local outID = tonumber(schematic.outputItemID)
    -- GetPriceByItemID also returns (price, origin, timestamp).  Never pass
    -- multiple return values directly to tonumber.
    local outputQuote = outID and getPrice(outID)
    local output = tonumber(outputQuote)
    local yields = math.max(1, tonumber(schematic.quantityMin) or 1)
    local profit = output and output > 0 and math.floor(output * yields * .95 - cost + .5) or nil
    if enchanting then
        -- The reagents row is too narrow for Tailoring's two full-size labels.
        -- Display one compact line; direct enchants have no AH output/profit.
        local label = prefix .. money(cost)
        if profit then
            label = label .. (profit >= 0 and " (+" or " (-") .. money(math.abs(profit)) .. ")"
        end
        setHeaderText(costLabel, label)
        costLabel:SetTextColor(1, .82, .18)
        profitLabel:SetText("")
        return
    end
    setHeaderText(costLabel, prefix .. money(cost))
    costLabel:SetTextColor(1, .82, .18)
    if not profit then
        setHeaderText(profitLabel, "Profit: --")
        profitLabel:SetTextColor(1, .72, .32)
        return
    end
    setHeaderText(profitLabel, ("Profit: %s%s"):format(profit >= 0 and "+" or "-", money(math.abs(profit))))
    profitLabel:SetTextColor(profit >= 0 and .35 or 1, profit >= 0 and .92 or .38, .24)
end

-- Enchanting descriptions can occupy multiple lines between the recipe title
-- and its reagent list. Place the AC controls on the REAGENTS heading row,
-- following the game's own dynamic layout instead of using fixed title offsets.
local function reagentHeading(frame, depth)
    if not frame or depth < 0 or not frame.IsShown or not frame:IsShown() then return end
    for _, region in ipairs({frame:GetRegions()}) do
        if region.GetText and region.IsShown and region:IsShown() then
            local raw = region:GetText()
            if not (issecretvalue and issecretvalue(raw)) and type(raw) == "string" then
                local label = raw:match("^%s*(.-)%s*$")
                if label == "Reagents:" or label == "Reagents" or
                    label == "Materials:" or label == "Materials" then return region end
            end
        end
    end
    if frame.GetChildren then
        for _, child in ipairs({frame:GetChildren()}) do
            local found = reagentHeading(child, depth - 1)
            if found then return found end
        end
    end
end
local function setLayout(form, enchanting)
    if attached ~= form then
        attached = form
        costLabel:SetParent(form)
        profitLabel:SetParent(form)
        button:SetParent(form)
        if form.GetFrameStrata then button:SetFrameStrata(form:GetFrameStrata()) end
        button:SetFrameLevel(form:GetFrameLevel() + 12)
        lastLayoutKey, lastHeader = nil, nil
    end
    if enchanting then
        local heading = reagentHeading(form, 6)
        if heading and heading.GetTop and form.GetTop and heading:GetTop() and form:GetTop() then
            local y = heading:GetTop() - form:GetTop()
            local key = "enchant:" .. tostring(heading) .. ":" .. tostring(math.floor(y + .5))
            if key ~= lastLayoutKey then
                -- Place the cost on the same row as the built-in Reagents
                -- heading, not below the recipe name or description.  A
                -- single-line label avoids colliding with the first reagent.
                costLabel:ClearAllPoints()
                costLabel:SetWidth(math.max(110, math.min(176, form:GetWidth() - 219)))
                costLabel:SetPoint("TOPLEFT", form, "TOPLEFT", 99, y + 1)
                profitLabel:ClearAllPoints()
                profitLabel:SetPoint("TOPLEFT", form, "TOPLEFT", 99, y + 1)
                button:ClearAllPoints()
                button:SetPoint("TOPRIGHT", form, "TOPRIGHT", -14, y + 5)
                lastLayoutKey, lastHeader = key, heading
            end
            return true
        end
        -- Blizzard sometimes updates the heading after the recipe selection.
        -- Hide the AC controls until it is in place rather than covering text.
        lastLayoutKey, lastHeader = nil, nil
        return false
    end
    if lastLayoutKey ~= "normal" then
        costLabel:ClearAllPoints()
        profitLabel:ClearAllPoints()
        button:ClearAllPoints()
        costLabel:SetWidth(156)
        costLabel:SetPoint("TOPLEFT", form, "TOPLEFT", 96, -57)
        profitLabel:SetPoint("TOPLEFT", form, "TOPLEFT", 96, -75)
        button:SetPoint("TOPRIGHT", form, "TOPRIGHT", -23, -75)
        lastLayoutKey, lastHeader = "normal", nil
    end
    return true
end
local function poll()
    local form, id = getSelected()
    local api = companion()
    local enchanting = form and isEnchanting(form, id) or false
    local placed = form and api and setLayout(form, enchanting)
    local show = not not (placed and id)
    if button then
        button:SetShown(show)
        costLabel:SetShown(show)
        profitLabel:SetShown(show and not enchanting)
        if show then
            -- Price quotes are cached by AC and can display away from the AH;
            -- the search button explains that a live search requires the AH.
            local revision = api.GetPriceRevision and api.GetPriceRevision() or 0
            local vendor = api.IsVendorPricingEnabled and api.IsVendorPricingEnabled() or false
            local key = tostring(id) .. "/" .. tostring(revision) .. "/" ..
                tostring(vendor) .. "/" .. tostring(enchanting) .. "/" .. tostring(lastLayoutKey)
            if key ~= lastQuoteKey then
                updateEstimate(id, enchanting)
                lastQuoteKey = key
            end
        else
            lastQuoteKey = nil
        end
    end
end
suite.registerModule(function(event, arg)
    if event ~= "ADDON_LOADED" or arg ~= addonName then return end
    button = CreateFrame("Button", "ProfessionAIOAuctionSearchButton", UIParent, "UIPanelButtonTemplate")
    button:SetSize(96, 22)
    button:SetText("AC Search")
    costLabel = UIParent:CreateFontString(nil, "OVERLAY", "GameFontNormal")
    costLabel:SetWidth(156)
    costLabel:SetJustifyH("LEFT")
    costLabel:SetWordWrap(false)
    setHeaderText(costLabel, "Cost: --")
    costLabel:SetTextColor(1, .82, .18)
    profitLabel = UIParent:CreateFontString(nil, "OVERLAY", "GameFontNormal")
    profitLabel:SetWidth(156)
    profitLabel:SetJustifyH("LEFT")
    profitLabel:SetWordWrap(false)
    setHeaderText(profitLabel, "Profit: --")
    profitLabel:SetTextColor(1, .82, .18)
    button:SetScript("OnClick", onClick)
    button:SetScript("OnEnter", function(self)
        GameTooltip:SetOwner(self, "ANCHOR_TOP")
        GameTooltip:AddLine("Auction Companion recipe search", 1, .82, .30)
        local _, recipeID = getSelected()
        if isEnchanting(attached, recipeID) then
            GameTooltip:AddLine("Search the enchant reagents; direct gear enchants have no auctionable finished item.", .88, .88, .88, true)
        else
            GameTooltip:AddLine("Search the finished item and every fixed reagent. Craft quantity: 1.", .88, .88, .88, true)
        end
        if not atAH() then
            GameTooltip:AddLine("Open the Auction House to run the search. Cached prices are displayed when available.", 1, .73, .32, true)
        else
            GameTooltip:AddLine("Use the AC tab to review missing materials and Buy All in steps.", .68, .77, .86, true)
        end
        GameTooltip:Show()
    end)
    button:SetScript("OnLeave", function() GameTooltip:Hide() end)
    button:Hide()
    costLabel:Hide()
    profitLabel:Hide()
    suite.addPoll(poll)
    return {"AUCTION_HOUSE_SHOW", "AUCTION_HOUSE_CLOSED", "TRADE_SKILL_LIST_UPDATE", "TRADE_SKILL_SHOW", "TRADE_SKILL_CLOSE"}
end)
