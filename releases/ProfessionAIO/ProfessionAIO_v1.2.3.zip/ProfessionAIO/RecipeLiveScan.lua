local _, suite = ...
local api = suite.tradeSkillAPI
local scans, active = {}, nil
local rawCloth = {[2996]=2589,[2997]=2592,[4305]=4306,[4339]=4338,[14048]=14047}
local function now() return time() end
local function acAPI() return AuctionCompanionAPI end
local function supported(ac)
    return ac and type(ac.StartItemListScan)=='function' and type(ac.GetItemListScanQuote)=='function' and type(ac.GetNameScanStatus)=='function'
end
function suite.recipeScanQuote(settings,id)
    local run=scans[settings]
    if not run or run.targets[id]==nil or now()-(run.completed or run.started)>1800 and run.phase~='running' then return false end
    local q=run.quotes[id]
    if q and q[2] and now()-q[2]<=1800 and now()>=q[2] then return true,q[1], 'Live',q[2] end
    return true,false,'Missing'
end
local function update()
    if not active then return end
    local run,ac=active,acAPI()
    local s=supported(ac) and ac.GetNameScanStatus()
    if not s or s.id~=run.id or s.scope~=run.scope then run.phase='interrupted';run.completed=now();active=nil;return end
    run.phase,run.done,run.verified,run.missing,run.failed=s.phase,s.done,s.verified,s.missing,s.failed
    for id in pairs(run.targets) do
        local price,matched,stamp,state=ac.GetItemListScanQuote(id)
        if state=='verified' and matched==id and type(price)=='number' and price>0 and type(stamp)=='number' and stamp>=run.started-2 then
            run.quotes[id]={price,stamp}
        end
    end
    if s.phase~='running' then run.completed=s.completedAt or now(); active=nil end
end
suite.addPoll(update)
function suite.recipeScanStatus(settings)
    local run=scans[settings]
    if not run then return nil end
    run.expired = run.phase ~= "running" and now()-(run.completed or run.started)>1800
    return run
end
function suite.startRecipeScan(settings, title, ids, enchanting)
    update()
    local ac=acAPI()
    if active then
        if active==scans[settings] then
            if ac and ac.CancelNameScan then ac.CancelNameScan();update();return true end
        end
        return false,'Another profession scan is running.'
    end
    if InCombatLockdown() then return false,'Leave combat to scan.' end
    if settings.provider and settings.provider~='Auto' and settings.provider~='Auction Companion' then return false,'Select Auction Companion pricing in Options.' end
    if not supported(ac) then return false,'Requires Auction Companion with item-list scanning (1.2.3).' end
    if not ac.IsAvailable or not ac.IsAvailable() then return false,'Open the Auction House first.' end
    local targets, items, unresolved, skipped={}, {},0,0
    local getInfo=C_Item and C_Item.GetItemInfo or GetItemInfo
    local function add(id)
        id=tonumber(id)
        if not id or id<=0 or targets[id]~=nil then return end
        local name=getInfo(id)
        if not name then targets[id]=false;unresolved=unresolved+1;return end
        targets[id]=true;items[#items+1]={itemID=id,name=name}
    end
    for _,id in ipairs(ids) do
        local info=api('GetRecipeInfo',id)
        if info and info.learned and not info.isDummyRecipe and not info.isRecraft then
            local schematic=api('GetRecipeSchematic',id,false)
            local mats=suite.fixedMaterials(schematic)
            if mats then
                for mat in pairs(mats) do add(mat);if rawCloth[mat] then add(rawCloth[mat]) end end
                local output=schematic and tonumber(schematic.outputItemID)
                if output and output>0 and not enchanting then
                    local item,link,quality,level,_,_,_,_,_,_,_,class,subclass,bind=getInfo(output)
                    if not item or bind==0 or bind==2 then add(output) end
                    if item and quality and level and class and suite.TailorSwift.disenchantValue then
                        suite.TailorSwift.disenchantValue({itemID=output,link=link,quality=quality,baseItemLevel=level,classID=class,subClassID=subclass},function(mat) add(mat);return 1 end)
                    end
                end
            else skipped=skipped+1 end
        end
    end
    if #items==0 then return false,'No ready item names. Wait for item data or change filters.' end
    if #items>750 then return false,'Over 750 items. Use Filtered recipes.' end
    table.sort(items,function(a,b)return a.itemID<b.itemID end)
    local started=now()
    local ok,msg=ac.StartItemListScan(items,'Profession AIO: '..title)
    if not ok then return false,msg or 'AC scan could not start.' end
    local s=ac.GetNameScanStatus()
    if not s then return false,'AC did not return scan status.' end
    local run={id=s.id,scope=s.scope,started=started,phase=s.phase,total=#items,done=0,verified=0,missing=0,failed=0,unresolved=unresolved,skipped=skipped,targets=targets,quotes={}}
    scans[settings]=run;active=run;update();return true
end
