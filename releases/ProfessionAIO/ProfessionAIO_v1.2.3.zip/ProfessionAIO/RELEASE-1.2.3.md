# Profession AIO 1.2.3 — Live Recipe Scan

Baseline: Profession AIO 1.2.2. Integration inspected against Auction Companion 1.2.3. No changes to AC or other addons. Existing SavedVariables and folder names retained.

## Changes
- Live Scan All in Cheapest and Profitable; adjacent scope selector cycles current profession (default), filtered recipes across all pages, or native selected recipe. Click Cancel Scan to stop the scan started by this panel.
- Uses AC's existing item-ID-verified read-only scan, not Full Scan. Deduplicates reagents, tradable outputs, raw cloth fallback and supported disenchant outcomes. Skips unsupported reagent choices and reports uncached names; retry once client item information loads. 750-item cap inherited from AC; use filters for larger lists.
- Progress, verified item count, completion time and tooltip breakdown of missing/unverified/skipped items. Only verified quotes from this run are used for its targeted items; unresolved targets never fall back to older AH quotes during the scan's 30-minute window. Known vendor costs remain available under existing settings. Other items and expired scans use normal provider rules, with cached/undated warnings. AH prices are estimates, not executable depth-aware purchase quotes.
- Cleaned up row spacing, column heading, scan status, version footer, unreadable check/cross glyphs, and Escape propagation. Throttles ranking rebuilds during a live scan to roughly two seconds, with final refresh. Fixed nil Shady provider access.
- Explicit non-AC provider selection is preserved; use Auto or Auction Companion to scan. AC owns throttling and busy checks. No new purchasing automation, no database migration. Cross-profession scanning is deferred because the native recipe API provides the open profession, not a verified complete learned-recipe cache.

## Verification
- All 31 Lua files parsed using installed Lua 5.4 shared library; Lua 5.1 compiler was unavailable.
- Mocked module tests passed: deduplication, output inclusion, missing-name handling, pending/verified prices, ownership, cancellation, expiry, provider guard.
- Native WoW Forever rendering, actual AH event ordering and end-to-end live scans remain untested. Test while AH and profession windows are both open. Verify filtered scope, known vendor prices, cancellation, close AH, switch professions, and scan with AC disabled. Check that the panel fits the screen and Escape closes the appropriate view.

Install by extracting the ProfessionAIO folder into Interface/AddOns after backing up the existing folder and SavedVariables. Roll back by restoring the 1.2.2 folder; no schema changes.
