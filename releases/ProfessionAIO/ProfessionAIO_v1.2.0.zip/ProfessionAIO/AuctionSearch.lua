local _, suite = ...
local api = suite.tradeSkillAPI

function suite.selectedRecipe(native)
    local form = native.CraftingPage and native.CraftingPage.SchematicForm
    if not form or not form:IsVisible() or not form.GetRecipeInfo then return end
    local ok, info = pcall(form.GetRecipeInfo, form)
    if not ok or type(info) ~= "table" or not info.recipeID then return end
    local box = form.QuantityInput
    local quantity = 1
    if box then
        local read = box.GetNumber or (box.EditBox and box.EditBox.GetNumber)
        if read then
            local success, value = pcall(read, box.GetNumber and box or box.EditBox)
            if success then quantity = tonumber(value) or 1 end
        end
    end
    return info.recipeID, math.max(1, math.min(999, math.floor(quantity)))
end

function suite.fixedMaterials(schematic)
    if not schematic or type(schematic.reagentSlotSchematics) ~= "table" then return end
    local totals = {}
    for _, slot in ipairs(schematic.reagentSlotSchematics) do
        if slot.required ~= false then
            local reagents = slot.reagents
            local id = reagents and #reagents == 1 and tonumber(reagents[1].itemID)
            local quantity = tonumber(slot.quantityRequired)
            if not id or id <= 0 or not quantity or quantity < 1 or quantity % 1 ~= 0
                or (slot.variableQuantities and next(slot.variableQuantities)) then return end
            totals[id] = (totals[id] or 0) + quantity
        end
    end
    return totals
end

function suite.inBags(id)
    local count = C_Item and C_Item.GetItemCount or GetItemCount
    return count and count(id, false, false) or 0
end

function suite.searchMissing(recipeID, quantity)
    if InCombatLockdown() then return false, "Leave combat to search for materials." end
    local ac = AuctionCompanionAPI
    if not ac or type(ac.SearchItems) ~= "function" then
        return false, "Enable Auction Companion to buy missing materials."
    end
    if not ac.IsAvailable or not ac.IsAvailable() then
        return false, "Open the Auction House to search with AC."
    end
    local mats = suite.fixedMaterials(api("GetRecipeSchematic", recipeID, false))
    if not mats then return false, "This recipe has unsupported reagent choices." end
    quantity = math.max(1, math.min(999, math.floor(tonumber(quantity) or 1)))
    local items = {}
    for id, amount in pairs(mats) do
        local required, owned = amount*quantity, suite.inBags(id)
        if required > 99999 then return false, "Choose a smaller crafting quantity for AC." end
        if owned < required then
            items[#items + 1] = {itemID=id, required=required, owned=owned}
        end
    end
    if #items == 0 then return false, "All required materials are in your bags." end
    table.sort(items, function(a,b) return a.itemID < b.itemID end)
    local info = api("GetRecipeInfo", recipeID)
    local ok, accepted, message = pcall(ac.SearchItems, items, (info and info.name or "Recipe") .. " ×" .. quantity)
    if not ok then return false, "AC could not start the search." end
    return accepted, message or (accepted and "Search sent. Select reagents in AC to start buying." or "AC did not start the search.")
end
