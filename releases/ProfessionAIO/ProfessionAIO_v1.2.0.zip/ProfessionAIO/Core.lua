local name, suite = ...

-- Keep profession data local to each module while sharing stateless helpers.
for _, id in ipairs({"TailorSwift", "CookItBookIt", "EnchantIt"}) do
    suite[id] = setmetatable({}, {__index = suite})
end

function suite.tradeSkillAPI(method, ...)
    local fn = C_TradeSkillUI and C_TradeSkillUI[method]
    if type(fn) ~= "function" then return end
    local ok, value = pcall(fn, ...)
    if ok then return value end
end

function suite.matchesProfession(info, skillLine, profession, title)
    return type(info) == "table" and (info.professionID == skillLine or info.skillLineID == skillLine
        or info.parentProfessionID == skillLine or info.profession == profession
        or info.professionName == title or info.name == title)
end

function suite.isProfession(native, skillLine, profession, title)
    local api = suite.tradeSkillAPI
    if api("IsDataSourceChanging") or api("IsTradeSkillLinked")
        or api("IsTradeSkillGuild") or api("IsNPCCrafting") then return false end
    local base, child = api("GetBaseProfessionInfo"), api("GetChildProfessionInfo")
    if suite.matchesProfession(base, skillLine, profession, title) or suite.matchesProfession(child, skillLine, profession, title) then return true end
    if type(base) == "table" and (base.professionID or base.professionName
        or base.skillLineID or base.parentProfessionID or base.profession) then return false end
    if native and native:IsShown() then
        local nativeTitle = (native.GetTitleText and native:GetTitleText())
            or (native.TitleText and native.TitleText:GetText())
        return nativeTitle == title
    end
    return false
end

function suite.window(parent, color)
    local frame = CreateFrame("Frame", nil, parent, "BackdropTemplate")
    frame:SetBackdrop({bgFile="Interface\\Buttons\\WHITE8X8", edgeFile="Interface\\DialogFrame\\UI-DialogBox-Border",
        edgeSize=16, insets={left=4,right=4,top=4,bottom=4}})
    frame:SetBackdropColor(unpack(color))
    return frame
end

function suite.label(parent, x, y)
    local label = parent:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
    label:SetPoint("TOPLEFT", x, y)
    label:SetJustifyH("LEFT")
    return label
end

function suite.button(parent, caption, x, y, width, handler)
    local button = CreateFrame("Button", nil, parent, "UIPanelButtonTemplate")
    button:SetPoint("TOPLEFT", x, y)
    button:SetSize(width, 21)
    button:SetText(caption)
    button:SetScript("OnClick", handler)
    return button
end

function suite.escapeCloses(frame, close)
    frame:EnableKeyboard(true)
    frame:SetPropagateKeyboardInput(true)
    frame:SetScript("OnKeyDown", function(self, key)
        if InCombatLockdown() then return end
        self:SetPropagateKeyboardInput(key ~= "ESCAPE")
        if key == "ESCAPE" then close(self) end
    end)
    frame:HookScript("OnShow", function(self)
        if not InCombatLockdown() then self:SetPropagateKeyboardInput(true) end
    end)
end

function suite.rememberMiniPosition(frame, db)
    frame:SetPoint("CENTER", UIParent, "CENTER", tonumber(db.miniX) or 0, tonumber(db.miniY) or 70)
    frame:SetScript("OnDragStop", function(self)
        self:StopMovingOrSizing()
        local x, y = self:GetCenter()
        local uiX, uiY = UIParent:GetCenter()
        if x and y and uiX and uiY then db.miniX, db.miniY = x-uiX, y-uiY end
    end)
end

function suite.itemName(id)
    return GetItemInfo(id) or ("Item " .. id)
end

-- Only the active Mini view may restore the shared native frame.
local suppressed

function suite.restoreNative(owner)
    if not suppressed or suppressed.owner ~= owner then return end
    local old = suppressed
    suppressed = nil
    pcall(old.frame.SetAlpha, old.frame, old.alpha)
    for frame, enabled in pairs(old.mouse) do pcall(frame.EnableMouse, frame, enabled) end
end

local function mute(frame)
    if frame.IsMouseEnabled and frame.EnableMouse then
        local ok, enabled = pcall(frame.IsMouseEnabled, frame)
        if ok and type(enabled) == "boolean" then
            if suppressed.mouse[frame] == nil then suppressed.mouse[frame] = enabled end
            if enabled then pcall(frame.EnableMouse, frame, false) end
        end
    end
    if frame.GetChildren then
        for _, child in ipairs({frame:GetChildren()}) do mute(child) end
    end
end

function suite.hideNative(owner, frame)
    if suppressed and (suppressed.owner ~= owner or suppressed.frame ~= frame) then
        suite.restoreNative(suppressed.owner)
    end
    if not suppressed then
        local alpha = frame:GetAlpha()
        if not pcall(frame.SetAlpha, frame, 0) then return false end
        suppressed = {owner=owner, frame=frame, alpha=alpha, mouse={}}
    end
    mute(frame)
    return true
end

function suite.launcher(frameName, db, texture, defaultAngle, onClick)
    local launcher = CreateFrame("Button", frameName, Minimap)
    launcher:SetSize(31, 31)
    launcher:SetFrameStrata("MEDIUM")
    launcher:SetFrameLevel(Minimap:GetFrameLevel()+10)
    local icon = launcher:CreateTexture(nil, "BACKGROUND")
    icon:SetSize(20, 20)
    icon:SetPoint("TOPLEFT", launcher, "TOPLEFT", 7, -5)
    icon:SetTexture("Interface\\Icons\\" .. texture)
    icon:SetTexCoord(.08, .92, .08, .92)
    local border = launcher:CreateTexture(nil, "OVERLAY")
    border:SetSize(53, 53)
    border:SetPoint("TOPLEFT", launcher, "TOPLEFT")
    border:SetTexture("Interface\\Minimap\\MiniMap-TrackingBorder")
    launcher:SetHighlightTexture("Interface\\Minimap\\UI-Minimap-ZoomButton-Highlight")
    launcher:RegisterForClicks("LeftButtonUp")
    launcher:RegisterForDrag("LeftButton")
    local function position()
        local angle = math.rad(tonumber(db.angle) or defaultAngle)
        launcher:ClearAllPoints()
        launcher:SetPoint("CENTER", Minimap, "CENTER", math.cos(angle)*Minimap:GetWidth()/2, math.sin(angle)*Minimap:GetHeight()/2)
    end
    position()
    Minimap:HookScript("OnSizeChanged", position)
    launcher:SetScript("OnClick", onClick)
    local titles = {
        TailorSwiftMinimapButton = "Tailor Swift",
        EnchantItMinimapButton = "EnchantIt",
        CookItBookItMinimapButton = "Cook It, Book It",
    }
    launcher:SetScript("OnEnter", function(self)
        GameTooltip:SetOwner(self, "ANCHOR_LEFT")
        GameTooltip:SetText(titles[frameName] or "Profession AIO")
        GameTooltip:AddLine("Profession AIO", 0.8, 0.8, 0.8)
        GameTooltip:AddLine("Left-click: Open profession", 1, 1, 1)
        GameTooltip:AddLine("Drag: Move icon", 1, 1, 1)
        GameTooltip:Show()
    end)
    local function hideTooltip(self)
        if GameTooltip:IsOwned(self) then GameTooltip:Hide() end
    end
    launcher:SetScript("OnLeave", hideTooltip)
    launcher:SetScript("OnHide", hideTooltip)
    launcher:SetScript("OnDragStart", function(self)
        hideTooltip(self)
        self:SetScript("OnUpdate", function()
            local x, y = GetCursorPosition()
            local cx, cy = Minimap:GetCenter()
            if not cx or not cy then return end
            local scale = Minimap:GetEffectiveScale()
            db.angle = math.deg(math.atan2(y/scale-cy, x/scale-cx))
            position()
        end)
    end)
    launcher:SetScript("OnDragStop", function(self) self:SetScript("OnUpdate", nil) end)
    return launcher
end

local modules, listeners, polls = {}, {}, {}
local events = CreateFrame("Frame")
events:RegisterEvent("ADDON_LOADED")

function suite.registerModule(handler)
    modules[#modules+1] = handler
end

function suite.addPoll(poll)
    polls[#polls+1] = poll
end

local function run(callback, ...)
    local ok, result = pcall(callback, ...)
    if not ok then geterrorhandler()(result); return end
    return result
end

events:SetScript("OnEvent", function(self, event, ...)
    if event == "ADDON_LOADED" then
        if (...) ~= name then return end
        self:UnregisterEvent(event)
        for _, handler in ipairs(modules) do
            for _, subscription in ipairs(run(handler, event, ...) or {}) do
                if not listeners[subscription] then
                    listeners[subscription] = {}
                    pcall(self.RegisterEvent, self, subscription)
                end
                table.insert(listeners[subscription], handler)
            end
        end
        C_Timer.NewTicker(.75, function()
            for _, poll in ipairs(polls) do run(poll) end
        end)
        return
    end
    for _, handler in ipairs(listeners[event] or {}) do run(handler, event, ...) end
end)
