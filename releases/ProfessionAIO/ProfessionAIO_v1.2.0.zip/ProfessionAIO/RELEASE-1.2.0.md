# Profession AIO v1.2.0 development release

For WoW Forever, interface 16001. Built from the supplied v1.1.44 ZIP.

## What changed

| Profession | Changes |
| --- | --- |
| Tailoring | Recipes, Cheapest and Profitable beside the native window. Compare AH, vendor, disenchant or the best available estimate. The selected-recipe summary shows material cost, quantity, bag shortfall, restrictions and sale routes. Tailor Swift Legacy remains available for manual prices, Best Price and older workflows. |
| Cooking | The same three views and pricing controls as Tailoring. Off-cooldown and reported location filters work on the learned recipe lists. Recipe sources, trainer and vendor lookups, Cooking Proximity and its saved exceptions remain available. |
| Enchanting | Recipes and Cheapest, with difficulty, material cost and craftable counts. Direct enchants do not receive speculative resale quotes. Existing native enchant application, trainer lookups and the opt-in overwrite handling remain in place. |
| Fishing | Session adds current or historical status, active channel time, catch and value rates, unique counts, and a searchable item breakdown with quantities, shares, unit estimates and totals. History opens individual sessions. New catches can be reviewed by zone or subzone. Zones and Settings have separate buttons. Craft, Bobber, and Quests & Uniques remain available. |

Search within Cheapest or Profitable with the field under the tabs. Click a result to open its native recipe details. **Details** collapses the selected-recipe summary. **Options** controls availability of the views, pricing provider, AH commission, known vendor prices, reported location filtering, craftable counts, and background opacity. The existing profession Settings buttons still cover profession-specific options and the original learning tools. Mini has a **Find missing** button and remembers its dragged position.

## Native integration

The dock attaches to the shown profession frame on the side with more room and scales to fit the available width. Recipes keeps the Blizzard list visible, and the ranked views use their own reusable rows. A recipe click uses the same OpenRecipe API as the earlier addon. The native window continues to own search, filters, reagent selection, quantity, Create, Create All, and enchant targets. Professions modes are separate from the native filters. The dock is suppressed for linked or NPC sources and while Mini hides the native window.

## Price and material estimates

The dock uses a single provider per estimate. Auto prefers AC, then Shady Price Engine, Auctionator, and AHledger. A manually selected unavailable provider yields unknown quotes. Known vendor purchase prices come from AC's vendor catalog when enabled. AC timestamps at least 24 hours old are excluded. Providers with no usable timestamp are marked undated. A yellow estimate or unknown marker signals incomplete confidence. Vendor sale values are read from client item data.

AH and disenchant estimates apply a configurable 5% commission to estimated gross proceeds. There is no deposit cost in the estimate. Deposits, auction duration, sale probability, neutral-AH fee differences, and relisting losses need a separate review. Variable recipe yields use the minimum. Most cached prices are reference unit prices, so large orders may cost more. Item metadata must identify the output as tradeable before it receives an AH sale estimate. Disenchant uses the existing Forever forecast and empirical data where present, multiplied by item yield and marked as an estimate.

Duplicate reagent slots combine before valuation and bag deductions. The market estimate retains the known tailoring bolt-to-cloth fallback. Craftable counts use bags and available client constraints. Additional gold estimates cover directly missing reagents. Bank inventory, alternative or quality-tier reagents, and a recursive shopping plan for crafted subcomponents are outside the implemented planner. Cooking's buff-food and fish-based filters were omitted because the supplied addon and client mocks do not establish reliable recipe tags. The location filter uses reported requirement names and the existing Spinning Wheel data. Mini and the Legacy teaching and resale tools keep the v1.1.44 lookups.

The panel shows market estimates. Auction Peek continues to own acquired costs and realized profit. Profession AIO does not write to Auction Peek.

## Auction Companion and Buy Next

The old native hook always sent one craft. The new **Find missing in AC** action reads the native quantity field if recognized or uses one craft. Mini uses its own quantity field. Profession AIO submits fixed, aggregated missing reagents and their bag ownership through AC's public API. The button reports when AC is absent, the AH is closed, a recipe has supported-choice limitations, materials are already covered, or AC declines a request. Receiving materials triggers the existing bag-driven refresh.

Reviewed AC v1.2.2's search, queue, purchase and Buy List code. Search readiness, current purchase confirmation, unresolved purchase locks, active scans and vendor-aware selections can block advancement. AC starts its queue with **Buy All** and exposes **Buy Next** for remaining steps. A vendor-preferred row can be deselected by AC. A partially purchased row still needs its outstanding quantity. AC also owns quote refresh, price-increase checks and native confirmation. This release fixes the AIO handoff and surfaces its errors. It does not modify AC's Buy Next button or persist an in-progress queue across reloads or AH closure. The selected-recipe action does not add items to AC's saved Buy List.

## SavedVariables and migration

The separate supplied ProfessionAIO.lua was read as an account-level SavedVariables snapshot. It contains Tailoring view and Legacy preferences, Cooking proximity exceptions, Enchanting preferences, and Fishing settings. No fishing history or per-character SavedVariables were supplied. The installer contains no SavedVariables.

The TOC retains the same account and per-character identifiers. Existing settings and stored session data are kept. The dock lazily adds a versioned craftViews table to each profession's existing settings. Fishing may add trackSessions and window position to account settings, and location item totals to the current session. Sessions without location data continue to show their aggregate totals and an unavailable location. Old missing active time remains unknown. The new history has no automatic 30-session pruning and shows eight records per page. Fixed-size craft pages and the paged history reuse UI rows.

## Stability and verification

| Verification | Result |
| --- | --- |
| Actual Lua 5.1 compiler through Lupa's Lua 5.1 runtime | Passed all 29 addon Lua files. Lua 5.1 enforced its parser, local and upvalue limits. |
| Mocked clean load and upgrade using the supplied account settings | Passed both, including preserved Cooking exception data and existing Fishing opacity. |
| Mocked crafting and pricing | Passed duplicate and optional reagent handling, multi-output yield, known vendor costs, AH commission, stale and missing quotes, alternate providers, intermediate bolt cost, cooldown detection, and a disenchant expected value. |
| Mocked UI actions | Passed native recipe callback, Cheapest and Profitable selection, difficulty and sale-route controls, switching professions, Fishing navigation, and Escape on the Fishing settings window. |
| AC v1.2.2 code with mocked client and purchase callback | Passed missing-quantity handoff into AC's real search normalizer, search readiness guard, busy retry, pending confirmation state, partial remaining quantity, closed-AH rejection and simulated bag update after mail. |
| Mocked Fishing tracking | Passed bobber attribution, normal loot exclusion, duplicate event handling, two locations, elapsed channel time, idle cap, reload and login archive behavior. |
| Source inspection | Inspected the TOC and modules, native crafting and overwrite pathways, Cooking Proximity, Fishing bindings, Bobber and guides, optional provider lookups, AC purchase and refresh guards, and the account record schema. |
| Live WoW Forever | Pending. Mocks do not measure actual screen layout, items dragging, secure actions or server events. |

Craft quote lookups are cached for each rebuild. The dock skips full ranking on Recipes and while closed, coalesces delayed item metadata, and refreshes on AC revision, bag/recipe events, or a timed fallback. Fish loot refreshes are coalesced; the active timer only redraws metrics. Fishing elapsed time counts channel time, capped at 35 seconds if a stop event is missed. Catch rates count successful loot events, while the breakdown shows shares of item units. Historical value uses quotes available when viewed. An elapsed-rate statistic is unavailable if active time was never recorded or is zero.

## Focused live checklist

1. Open Tailoring, Cooking and Enchanting using both the spellbook and minimap icons. Verify the dock stays clear of native reagents at your UI scale, including when the AH is open. Try closing, reopening, switching and pressing Escape. If the native frame leaves less than 155 UI units on both sides, the dock stays hidden.
2. In Tailoring and Cooking, select results from both ranked views. Check a multiple-output recipe, a missing quote, an intermediate bolt and a timed or station-limited recipe. Change native craft quantity and compare the summary and Create All count with your bags.
3. Check that a direct enchant can be selected and applied through Blizzard's native interface. Test both values of the existing overwrite preference on an expendable target.
4. Open AC v1.2.2 with a partially stocked recipe selected. Submit a quantity greater than one. Verify required, owned and To Buy. Try a vendor-preferred reagent, changed quote, partial fill, canceling Blizzard confirmation and closing the AH mid-queue. Collect the mail and recheck the summary.
5. Drag Mini for each profession, toggle Full and Mini, and reload. Check that Mini's shopping action uses its displayed quantity. Verify Cooking Proximity at a normal fire and at a saved exception.
6. Use Fishing in two locations, take an extended idle break, catch a multi-item result, then loot an ordinary mob. Switch location filters and sort the item breakdown. Verify that reload continues the current session and a fresh login opens the previous one from History. Check Fishing Craft, Zones, Bobber, Quests & Uniques and the fishing key.

## Install and roll back

Exit WoW Forever. Back up your existing Interface/AddOns/ProfessionAIO folder and both the account and per-character ProfessionAIO.lua files under WTF. Replace the addon folder with the single ProfessionAIO folder in this ZIP. Leave your current WTF files in place and keep any standalone copies of the profession modules disabled.

For rollback, exit the client and put your v1.1.44 addon folder back. Keep your current SavedVariables if you want to preserve new fishing catches and settings. Keep a separate copy of those files before reinstalling v1.1.44 because its history cap can prune records on a later login. Restore your pre-upgrade WTF backup only if you want to revert your data to its earlier state.
