local name, suite = ...
local sessions = {}
suite.fishingSession = sessions
local db, skill
local slots, countedCatch, countedEscape = {}, false, false
local pendingLoot = false
local castStarted, castLocation
local maxChannel = 35

local function now()
    return (GetServerTime and GetServerTime()) or time()
end

function sessions.isBobber(guid)
    return type(guid) == "string" and not (issecretvalue and issecretvalue(guid))
        and guid:match("^GameObject%-%d+%-%d+%-%d+%-%d+%-35591%-") ~= nil
end

function sessions.initialize(character, readSkill)
    db, skill = character, readSkill
end

function sessions.stopCast()
    if not castStarted then return end
    local session = db.currentSession
    session.activeSeconds = (session.activeSeconds or 0) + math.min(maxChannel, math.max(0, GetTime() - castStarted))
    castStarted = nil
end

function sessions.enterWorld(initialLogin, reloading)
    sessions.stopCast()
    if not initialLogin or reloading then return end
    local current = db.currentSession
    if current then
        db.fishingHistory = db.fishingHistory or {}
        table.insert(db.fishingHistory, 1, current)
        db.currentSession = nil
    end
end

local function updateSkill(session)
    local rank = skill()
    if rank <= 0 then return end
    session.startSkill = session.startSkill or rank
    session.endSkill = math.max(session.endSkill or rank, rank)
end

function sessions.location()
    local zone = GetZoneText and GetZoneText()
    local subzone = GetSubZoneText and GetSubZoneText()
    if not zone or zone == "" then return "Unknown location" end
    return subzone and subzone ~= "" and subzone ~= zone and (zone .. " / " .. subzone) or zone
end

function sessions.isActive()
    return castStarted and GetTime() - castStarted < maxChannel
end

function sessions.cast()
    sessions.stopCast()
    local stamp = now()
    local session = db.currentSession
    if not session then
        session = {started=stamp, updated=stamp, casts=0, catches=0, escapes=0, items={}}
        db.currentSession = session
    end
    session.activeSeconds = session.activeSeconds or 0
    castStarted, castLocation = GetTime(), sessions.location()
    session.casts = session.casts + 1
    session.updated = stamp
    countedEscape = false
    updateSkill(session)
end

function sessions.skillChanged()
    if db.currentSession then updateSkill(db.currentSession) end
end

function sessions.escape(message)
    local session = db.currentSession
    if not session or not castLocation or countedEscape or not ERR_FISH_ESCAPED
        or (issecretvalue and issecretvalue(message)) or message ~= ERR_FISH_ESCAPED then return end
    countedEscape = true
    session.escapes = session.escapes + 1
    session.updated = now()
end

function sessions.snapshotLoot()
    if not db.currentSession or not GetLootSourceInfo or not GetLootSlotLink or not GetLootSlotInfo then return end
    if not pendingLoot then
        pendingLoot = true
        countedCatch = false
    end
    for slot = 1, GetNumLootItems() do
        if slots[slot] == nil and sessions.isBobber(GetLootSourceInfo(slot)) then
            local link = GetLootSlotLink(slot)
            local icon, label, count = GetLootSlotInfo(slot)
            if type(link) == "string" and not (issecretvalue and issecretvalue(link)) then
                local id = tonumber(link:match("item:(%d+)"))
                if id and type(count) == "number" and count > 0 then
                    slots[slot] = {id=id, link=link, label=label, icon=icon, count=count, location=castLocation or sessions.location()}
                end
            end
        end
    end
end

function sessions.lootCleared(slot)
    local item = slots[slot]
    local session = db.currentSession
    if not session or not item then return end
    slots[slot] = false
    session.locations = session.locations or {}
    local location = session.locations[item.location]
    if not location then location = {catches=0, items={}}; session.locations[item.location] = location end
    if not countedCatch then
        countedCatch = true
        session.catches = session.catches + 1
        location.catches = location.catches + 1
    end
    local function add(items)
        local record = items[item.id]
        if not record then
            record = {name=item.label, link=item.link, icon=item.icon, count=0}
            items[item.id] = record
        end
        record.count = record.count + item.count
    end
    add(session.items)
    add(location.items)
    session.latest = item.id
    session.updated = now()
    updateSkill(session)
end

function sessions.closeLoot()
    slots, pendingLoot = {}, false
end

local function duration(seconds)
    if not seconds then return "—" end
    seconds = math.floor(seconds)
    return ("%dh %02dm %02ds"):format(math.floor(seconds/3600), math.floor(seconds/60)%60, seconds%60)
end

local function activeTime(session)
    local seconds = session.activeSeconds
    if session == db.currentSession and castStarted then
        seconds = (seconds or 0) + math.min(maxChannel, math.max(0, GetTime()-castStarted))
    end
    return seconds
end

local function field(parent, x, y, width)
    local text = suite.label(parent, x, y)
    text:SetWidth(width)
    text:SetWordWrap(false)
    return text
end

local function box(parent, top)
    local scroll = CreateFrame("ScrollFrame", nil, parent, "UIPanelScrollFrameTemplate")
    scroll:SetPoint("TOPLEFT", 16, top)
    scroll:SetPoint("BOTTOMRIGHT", -33, 28)
    local content = CreateFrame("Frame", nil, scroll)
    content:SetSize(497, 1)
    scroll:SetScrollChild(content)
    return scroll, content
end

local function estimates(items)
    local getPrice = suite.priceAPI()
    local rows, total, quantity, priced, vendorTotal, vendorKnown = {}, 0, 0, 0, 0, 0
    local getInfo = C_Item and C_Item.GetItemInfo or GetItemInfo
    for id, item in pairs(items or {}) do
        local unit = suite.auctionQuote(getPrice, name, id)
        local value = unit and unit * item.count
        if value then total, priced = total + value, priced + 1 end
        rows[#rows+1] = {item=item, id=id, unit=unit, total=value}
        quantity = quantity + item.count
        local sell = select(11, getInfo(id))
        if type(sell) == "number" then
            vendorTotal, vendorKnown = vendorTotal+sell*item.count, vendorKnown+1
        end
    end
    return rows, priced > 0 and total or nil, quantity, priced < #rows,
        vendorKnown > 0 and vendorTotal or nil, vendorKnown < #rows
end

local function valueText(value, partial)
    return value and (suite.money(value) .. (partial and " (partial)" or "")) or "—"
end

function sessions.build(container)
    local parent = CreateFrame("Frame", nil, container)
    parent:SetAllPoints()
    local log = CreateFrame("Frame", nil, container)
    log:SetAllPoints()
    log:Hide()
    local page, locationIndex, sortIndex, logPage = 0, 1, 1, 1
    local refresh, refreshMetrics
    local activeData
    local function showLog(open)
        if open then logPage = math.floor(page/8)+1 end
        parent:SetShown(not open)
        log:SetShown(open)
        refresh(true)
    end
    local function navigate(value)
        page, locationIndex = value, 1
        refresh(true)
    end
    local previous = suite.button(parent, "<", 16, -40, 28, function() navigate(page+1) end)
    local following = suite.button(parent, ">", 47, -40, 28, function() navigate(page-1) end)
    local stamp = field(parent, 84, -45, 373)
    suite.button(parent, "History", 460, -40, 71, function() showLog(true) end)
    suite.button(log, "Back", 460, -40, 71, function() showLog(false) end)
    field(log, 17, -45, 420):SetText("Fishing history  •  Select a login")
    local logScroll, logContent = box(log, -95)
    local logPrev = suite.button(log, "<", 17, -67, 29, function() logPage = logPage-1; refresh(true) end)
    local logNext = suite.button(log, ">", 50, -67, 29, function() logPage = logPage+1; refresh(true) end)
    local logStatus = field(log, 88, -72, 356)
    local logRows = {}
    local logEmpty = field(logContent, 4, -7, 480)
    logEmpty:SetText("No fishing sessions yet.")
    local status = field(parent, 17, -69, 509)
    local main = CreateFrame("Frame", nil, parent)
    main:SetAllPoints()
    local timeText = field(main, 17, -92, 255)
    local rateText = field(main, 276, -92, 255)
    local value = field(main, 17, -114, 255)
    local valueRate = field(main, 276, -114, 255)
    local empty = field(parent, 17, -98, 509)
    empty:SetText("Cast a line to start tracking.")
    local zones
    zones = suite.button(main, "All locations", 15, -140, 196, function()
        locationIndex = locationIndex % #activeData.locations + 1
        refresh(true)
    end)
    local query = CreateFrame("EditBox", nil, main, "InputBoxTemplate")
    query:SetSize(122, 21)
    query:SetPoint("TOPLEFT", 224, -140)
    query:SetAutoFocus(false)
    query:SetMaxLetters(64)
    query:SetScript("OnEscapePressed", function(self) self:ClearFocus() end)
    query:SetScript("OnEnterPressed", function(self) self:ClearFocus() end)
    query:SetScript("OnTextChanged", function() refresh(true) end)
    local sortKeys = {"Quantity","Total value","Unit value","Name"}
    local sort = suite.button(main, "", 358, -140, 173, function()
        sortIndex = sortIndex % #sortKeys + 1
        refresh(true)
    end)
    field(main, 19, -172, 200):SetText("Catch  •  Type to search")
    field(main, 245, -172, 52):SetText("Qty")
    field(main, 292, -172, 57):SetText("% items")
    field(main, 347, -172, 82):SetText("Unit est.")
    field(main, 436, -172, 92):SetText("Total est.")
    local scroll, content = box(main, -190)
    local rows = {}
    local catchEmpty = field(content, 4, -7, 480)

    local function refreshLog(history, reset)
        local index = 0
        local pages = math.max(1, math.ceil((#history+1)/8))
        logPage = math.max(1, math.min(logPage,pages))
        logPrev:SetEnabled(logPage>1)
        logNext:SetEnabled(logPage<pages)
        logStatus:SetText(("Page %d/%d"):format(logPage,pages))
        for login = (logPage-1)*8, math.min(#history,logPage*8-1) do
            local session = login == 0 and db.currentSession or history[login]
            if session then
                index = index + 1
                local row = logRows[index]
                if not row then
                    row = CreateFrame("Button", nil, logContent)
                    row:SetPoint("TOPLEFT", 0, -(index-1)*39)
                    row:SetSize(495, 39)
                    row:SetHighlightTexture("Interface\\QuestFrame\\UI-QuestTitleHighlight")
                    row.title = field(row, 3, -4, 486)
                    row.stats = field(row, 3, -21, 486)
                    row:SetScript("OnClick", function(self) page, locationIndex = self.login, 1; showLog(false) end)
                    logRows[index] = row
                end
                local catches, total, _, partial = estimates(session.items)
                local seconds = activeTime(session)
                local area, locations = next(session.locations or {}), 0
                for _ in pairs(session.locations or {}) do locations = locations+1 end
                row.login = login
                row.title:SetText((login == 0 and "Current  •  " or "") .. date("%b %d, %Y %I:%M %p", session.started)
                    .. "  •  " .. (locations > 1 and (locations .. " locations") or area or "Location unavailable"))
                row.stats:SetText(("%s  •  %d catches  •  %d unique  •  %s  •  %s/hr"):format(duration(seconds),
                    session.catches, #catches, valueText(total, partial), seconds and seconds > 0 and
                    ("%.0f"):format(session.catches*3600/seconds) or "—"))
                row:Show()
            end
        end
        for i = index+1, #logRows do logRows[i]:Hide() end
        logEmpty:SetShown(index == 0)
        logContent:SetHeight(math.max(24, index*39))
        if reset then logScroll:SetVerticalScroll(0) end
    end

    refreshMetrics = function()
        if not activeData then return end
        local data = activeData
        local seconds = activeTime(data.session)
        local isActive = page == 0 and sessions.isActive()
        status:SetText((page > 0 and "Completed" or isActive and "|cff64ff74Active fishing|r" or "Idle")
            .. "  •  " .. (page == 0 and sessions.location() or data.place))
        timeText:SetText("Active time  " .. duration(seconds) .. "  •  " .. data.session.catches .. " catches")
        rateText:SetText("Catches/hr  " .. (seconds and seconds > 0 and ("%.0f"):format(data.session.catches * 3600 / seconds) or "—")
            .. "  •  " .. data.unique .. " unique")
        value:SetText("AH " .. valueText(data.total, data.partial) .. "  •  Vendor " .. valueText(data.vendor, data.vendorPartial))
        valueRate:SetText("AH value/hr  " .. valueText(data.total and seconds and seconds > 0 and data.total * 3600 / seconds, data.partial))
    end
    local tick = 0
    parent:SetScript("OnUpdate", function(_, elapsed)
        if not castStarted or page ~= 0 then return end
        tick = tick + elapsed
        if tick >= 1 then tick = 0; refreshMetrics() end
    end)

    refresh = function(reset)
        local history = db.fishingHistory or {}
        if log:IsShown() then refreshLog(history, reset); return end
        page = math.max(0, math.min(page, #history))
        local session = page == 0 and db.currentSession or history[page]
        previous:SetEnabled(page < #history)
        following:SetEnabled(page > 0)
        stamp:SetText((page == 0 and "Current login" or "Historical login") ..
            (session and ("  •  " .. date("%b %d, %Y %I:%M %p", session.started)) or ""))
        empty:SetShown(session == nil)
        main:SetShown(session ~= nil)
        activeData = nil
        if not session then status:SetText(sessions.location()); return end
        local locations = {}
        for place in pairs(session.locations or {}) do locations[#locations+1] = place end
        table.sort(locations)
        local place = #locations > 1 and (#locations .. " locations") or locations[1] or "Location unavailable"
        table.insert(locations, 1, "All locations")
        locationIndex = math.min(locationIndex, #locations)
        local items, total, quantity, partial, vendor, vendorPartial = estimates(session.items)
        activeData = {session=session, total=total, partial=partial, vendor=vendor, vendorPartial=vendorPartial,
            unique=#items, place=place, locations=locations}
        refreshMetrics()
        if locationIndex > 1 then
            local zoneItems, _, zoneQuantity = estimates(session.locations[locations[locationIndex]].items)
            items, quantity = zoneItems, zoneQuantity
        end
        zones:SetText(locations[locationIndex])
        zones:SetEnabled(#locations > 1)
        sort:SetText("Sort: " .. sortKeys[sortIndex])
        local term = query:GetText():lower()
        local filtered = {}
        for _, entry in ipairs(items) do
            entry.title = entry.item.name or suite.itemName(entry.id)
            if entry.title:lower():find(term, 1, true) then filtered[#filtered+1] = entry end
        end
        table.sort(filtered, function(a,b)
            local av,bv
            if sortIndex == 1 then av,bv = a.item.count,b.item.count
            elseif sortIndex == 2 then av,bv = a.total or -1,b.total or -1
            elseif sortIndex == 3 then av,bv = a.unit or -1,b.unit or -1 end
            if av ~= bv then return av > bv end
            if a.title ~= b.title then return a.title < b.title end
            return a.id < b.id
        end)
        for i, entry in ipairs(filtered) do
            local row = rows[i]
            if not row then
                row = CreateFrame("Button", nil, content)
                row:SetPoint("TOPLEFT", 0, -(i-1)*24)
                row:SetSize(497, 24)
                row:SetHighlightTexture("Interface\\QuestFrame\\UI-QuestTitleHighlight")
                row.icon = row:CreateTexture(nil, "ARTWORK")
                row.icon:SetSize(19,19)
                row.icon:SetPoint("LEFT", 2, 0)
                row.label = field(row, 26,-5,196)
                row.count = field(row, 229,-5,45)
                row.share = field(row, 276,-5,51)
                row.unit = field(row, 331,-5,84)
                row.total = field(row, 420,-5,77)
                row:SetScript("OnEnter", function(self)
                    GameTooltip:SetOwner(self, "ANCHOR_RIGHT")
                    if self.item.link then GameTooltip:SetHyperlink(self.item.link) else GameTooltip:SetItemByID(self.itemID) end
                    GameTooltip:Show()
                end)
                row:SetScript("OnLeave", function() GameTooltip:Hide() end)
                rows[i] = row
            end
            local item = entry.item
            row.item, row.itemID = item, entry.id
            row.icon:SetTexture(item.icon or 134400)
            local color = item.link and item.link:match("^(|c%x%x%x%x%x%x%x%x)") or ""
            row.label:SetText(color .. entry.title .. "|r")
            row.count:SetText(item.count)
            row.share:SetText(("%.1f%%"):format(item.count*100/quantity))
            row.unit:SetText(valueText(entry.unit))
            row.total:SetText(valueText(entry.total))
            row:Show()
        end
        for i = #filtered+1,#rows do rows[i]:Hide() end
        catchEmpty:SetShown(#filtered == 0)
        catchEmpty:SetText(term ~= "" and "No matching catches." or "No catches recorded.")
        content:SetHeight(math.max(24,#filtered*24))
        if reset then scroll:SetVerticalScroll(0) end
    end
    return refresh
end
