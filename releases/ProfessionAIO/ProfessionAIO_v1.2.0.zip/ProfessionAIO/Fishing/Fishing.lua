local name, suite = ...
local sessions = suite.fishingSession
local bobber = suite.fishingBobber
local FISHING = 7620
local FISHING_SKILL = 356
local MAIN_HAND, OFF_HAND = 16, 17
local ACTION = "ProfessionAIOFishingAction"
local BINDING = "CLICK " .. ACTION .. ":LeftButton"

local db, character, action, override, panel, refreshWindow
local activeReel, reelEndedAt, tackle
local bindingRepairAttempts, lastBindingRepair, bindingConflictWarned = 0, 0, false
local refreshCraft
local refreshPending
local lootOpen, lootHandled = false, false
local spellName

local function fishingSpell()
    local getName = C_Spell and C_Spell.GetSpellName
    return (getName and getName(FISHING)) or (GetSpellInfo and GetSpellInfo(FISHING)) or "Fishing"
end

local function isPole(itemID)
    if not itemID then return false end
    if character and itemID == character.lastPole then return true end
    local getInfo = C_Item and C_Item.GetItemInfoInstant or GetItemInfoInstant
    if not getInfo then return false end
    local _, _, _, _, _, class, subclass = getInfo(itemID)
    return class == 2 and subclass == 20
end

local function equippedItem(slot)
    local id = GetInventoryItemID("player", slot)
    if id then return id end
    local link = GetInventoryItemLink and GetInventoryItemLink("player", slot)
    if type(link) == "string" and not (issecretvalue and issecretvalue(link)) then
        return tonumber(link:match("item:(%d+)"))
    end
end

local function equippedPole()
    local mainHand = equippedItem(MAIN_HAND)
    if isPole(mainHand) then return mainHand, MAIN_HAND end
    local offHand = equippedItem(OFF_HAND)
    if isPole(offHand) then return offHand, OFF_HAND end
end

local function findBagEquipment(wantedID)
    local bags = C_Container
    if not bags or not bags.GetContainerNumSlots or not bags.GetContainerItemID then return end
    local firstID, firstBag, firstSlot
    for bag = 0, NUM_BAG_SLOTS or 4 do
        for slot = 1, bags.GetContainerNumSlots(bag) do
            local itemID = bags.GetContainerItemID(bag, slot)
            if wantedID then
                if itemID == wantedID then return itemID, bag, slot end
            elseif isPole(itemID) then
                if itemID == character.lastPole then return itemID, bag, slot end
                if not firstID then firstID, firstBag, firstSlot = itemID, bag, slot end
            end
        end
    end
    return firstID, firstBag, firstSlot
end

local function fishingChannel()
    if not UnitChannelInfo then return false end
    local channel, _, _, _, _, _, _, spellID = UnitChannelInfo("player")
    return spellID == FISHING or spellID == 7731 or spellID == 7732 or spellID == 18248
        or (channel ~= nil and channel == spellName)
end

local function getCVar(key)
    local get = C_CVar and C_CVar.GetCVar or GetCVar
    if not get then return end
    local ok, value = pcall(get, key)
    if ok and value ~= nil then return tostring(value) end
end

local function writeCVar(key, value)
    local set = C_CVar and C_CVar.SetCVar or SetCVar
    if set then pcall(set, key, value) end
end

local function temporaryCVar(key, requested)
    local saved = character.cvars
    local current = getCVar(key)
    local change = saved[key]
    if requested and change and current == change.applied and requested ~= change.requested then
        writeCVar(key, requested)
        local applied = getCVar(key)
        if applied then change.applied, change.requested = applied, requested end
    elseif requested and current and not saved[key] and current ~= requested then
        saved[key] = {previous=current, applied=requested, requested=requested}
        writeCVar(key, requested)
        local applied = getCVar(key)
        if applied and (applied == requested or (tonumber(applied) and tonumber(applied) == tonumber(requested))) then
            saved[key].applied = applied
        else
            saved[key] = nil
        end
    elseif not requested and saved[key] then
        local change = saved[key]
        if current == change.applied then writeCVar(key, change.previous) end
        saved[key] = nil
    end
end

local quietChannels = {"Sound_EnableMusic", "Sound_EnableAmbience", "Sound_EnableDialog",
    "Sound_EnablePetSounds", "Sound_EnableEmoteSounds", "Sound_EnableErrorSpeech"}

local function updateCVars(pole, reeling, marking)
    local quiet = pole and db.mute
    temporaryCVar("Sound_EnableAllSound", quiet and "1" or nil)
    temporaryCVar("Sound_EnableSFX", quiet and "1" or nil)
    local volume = tonumber(db.fishingSFX)
    temporaryCVar("Sound_SFXVolume", quiet and volume and tostring(math.min(100, math.max(0, volume))/100) or nil)
    for _, cvar in ipairs(quietChannels) do temporaryCVar(cvar, quiet and "0" or nil) end
    local interact = reeling or marking
    temporaryCVar("SoftTargetInteract", interact and "3" or nil)
    temporaryCVar("SoftTargetInteractArc", interact and "2" or nil)
    temporaryCVar("SoftTargetInteractRange", interact and "30" or nil)
    temporaryCVar("SoftTargetIconGameObject", marking and "1" or nil)
    temporaryCVar("SoftTargetIconInteract", marking and "1" or nil)
end

local function updateAction(event)
    local mainHand = equippedItem(MAIN_HAND)
    local pole = equippedPole()
    if pole then character.lastPole = pole
    elseif mainHand then
        character.lastMainHand = mainHand
        character.lastOffHand = equippedItem(OFF_HAND)
    end
    local combat = event == "PLAYER_REGEN_DISABLED" or InCombatLockdown()
    local key1, key2 = GetBindingKey(BINDING)
    local channel = pole and not combat and fishingChannel()
    local reeling = channel and (key1 ~= nil or key2 ~= nil)
    updateCVars(pole, reeling, channel and bobber.enabled())
    bobber.update(channel)
    if combat then
        activeReel = nil
        return
    end

    if activeReel and not reeling then reelEndedAt = GetTime() end
    -- When WoW loses window focus, key-up and channel-transition input can be
    -- missed. Check the real (override-aware) binding, not only activeReel.
    local staleOverride = reeling and ((key1 and GetBindingAction(key1, true) ~= "INTERACTTARGET")
        or (key2 and GetBindingAction(key2, true) ~= "INTERACTTARGET"))
    local repairing = false
    if event == "FISHING_BINDING_WATCHDOG" and staleOverride then
        if bindingRepairAttempts < 3 and GetTime() - lastBindingRepair >= 2 then
            lastBindingRepair = GetTime()
            bindingRepairAttempts = bindingRepairAttempts + 1
            repairing = true
        elseif bindingRepairAttempts >= 3 and not bindingConflictWarned then
            bindingConflictWarned = true
            print("|cffffd23fProfession AIO Fishing:|r Another addon may be overriding your fishing key. Type /paiofish repair after resolving the conflict.")
        end
    elseif not staleOverride then
        bindingRepairAttempts, bindingConflictWarned = 0, false
    end
    if activeReel ~= reeling or event == "UPDATE_BINDINGS" or event == "PLAYER_REGEN_ENABLED" or repairing then
        ClearOverrideBindings(override)
        if reeling then
            if key1 then SetOverrideBinding(override, true, key1, "INTERACTTARGET") end
            if key2 then SetOverrideBinding(override, true, key2, "INTERACTTARGET") end
        end
        activeReel = reeling
    end

    if reeling or lootOpen or (LootFrame and LootFrame:IsShown()) then
        action:SetAttribute("type", nil)
    elseif pole then
        action:SetAttribute("spell", spellName)
        action:SetAttribute("type", "spell")
    else
        local itemID = findBagEquipment()
        if itemID then character.lastPole = itemID end
        action:SetAttribute("macrotext", itemID and ("/equipslot " .. MAIN_HAND .. " item:" .. itemID) or nil)
        action:SetAttribute("type", itemID and "macro" or nil)
    end
end

local function fastLoot()
    if lootHandled or not db.fastLoot or not equippedPole() or not GetLootSourceInfo or not LootSlot then return end
    local slots = {}
    for slot = 1, GetNumLootItems() do
        if sessions.isBobber(GetLootSourceInfo(slot)) then
            slots[#slots+1] = slot
        end
    end
    if #slots == 0 then return end
    lootHandled = true
    for i = #slots, 1, -1 do LootSlot(slots[i]) end
end

local function fishingSkill()
    if GetProfessions and GetProfessionInfo then
        local index = select(4, GetProfessions())
        if index then
            local _, _, rank, cap, _, _, line, modifier = GetProfessionInfo(index)
            if line == FISHING_SKILL and type(rank) == "number" then
                return rank, rank + (modifier or 0), cap or 0
            end
        end
    end
    if not GetNumSkillLines or not GetSkillLineInfo then return 0, 0, 0 end
    for i = 1, GetNumSkillLines() do
        local skill, header, _, rank, temp, modifier, cap = GetSkillLineInfo(i)
        if not header and skill == spellName and type(rank) == "number" then
            return rank, rank + (temp or 0) + (modifier or 0), cap or 0
        end
    end
    return 0, 0, 0
end

local function toggleWindow()
    panel:SetShown(not panel:IsShown())
end

local function equipFromBag(bag, bagSlot, equipmentSlot)
    if GetCursorInfo() or not C_Container.PickupContainerItem then return false end
    C_Container.PickupContainerItem(bag, bagSlot)
    if GetCursorInfo() ~= "item" then return false end
    PickupInventoryItem(equipmentSlot)
    if GetCursorInfo() then ClearCursor() end
    return true
end

local function restoreOffHand(mainHand, offHand, attempts)
    if InCombatLockdown() or GetCursorInfo() or equippedItem(OFF_HAND) then return end
    if equippedItem(MAIN_HAND) ~= mainHand then
        if attempts > 0 and equippedPole() then
            C_Timer.After(.2, function() restoreOffHand(mainHand, offHand, attempts-1) end)
        end
        return
    end
    local _, bag, slot = findBagEquipment(offHand)
    if bag then equipFromBag(bag, slot, OFF_HAND)
    else print("Fishing: The saved off-hand item is not in your bags.") end
end

local function swapTackleEquipment()
    if InCombatLockdown() then
        print("Fishing: Equipment swap unavailable in combat.")
        return
    end
    if not GetCursorInfo or not ClearCursor or not PickupInventoryItem or GetCursorInfo() then return end
    local mainHand = equippedItem(MAIN_HAND)
    local pole, slot = equippedPole()
    if slot == OFF_HAND then
        print("Fishing: The client reports your pole in the off hand. Unequip it manually to restore main-hand gear.")
        return
    end
    local wanted = pole and character.lastMainHand or nil
    if pole and not wanted then
        print("Fishing: No previous main-hand item saved.")
        return
    end

    local itemID, bag, bagSlot = findBagEquipment(wanted)
    if not itemID then
        print(pole and "Fishing: The saved main-hand item is not in your bags."
            or "Fishing: No fishing pole found in your bags.")
        return
    end
    local previousOffHand = character.lastOffHand
    if not pole then
        character.lastPole = itemID
        if mainHand then character.lastMainHand = mainHand end
        character.lastOffHand = equippedItem(OFF_HAND)
    end
    if equipFromBag(bag, bagSlot, MAIN_HAND) and pole and previousOffHand then
        C_Timer.After(.2, function() restoreOffHand(itemID, previousOffHand, 4) end)
    end
end

local function buildTackleButton()
    local button = CreateFrame("Button", "ProfessionAIOFishingTackleButton", UIParent, "BackdropTemplate")
    button:SetSize(37, 37)
    button:SetFrameStrata("MEDIUM")
    button:SetMovable(true)
    button:SetClampedToScreen(true)
    local saved = character.tacklePosition
    if type(saved) == "table" and type(saved[1]) == "string" and type(saved[2]) == "string" then
        button:SetPoint(saved[1], UIParent, saved[2], tonumber(saved[3]) or 0, tonumber(saved[4]) or 0)
    else
        button:SetPoint("BOTTOMRIGHT", UIParent, "BOTTOMRIGHT", -45, 164)
    end
    button:SetBackdrop({bgFile="Interface\\Buttons\\WHITE8X8",
        edgeFile="Interface\\Tooltips\\UI-Tooltip-Border", edgeSize=11})
    button:SetBackdropColor(.035,.05,.065,1)
    button:SetBackdropBorderColor(.66,.53,.29,1)
    local icon = button:CreateTexture(nil, "ARTWORK")
    icon:SetPoint("TOPLEFT", 4, -4)
    icon:SetPoint("BOTTOMRIGHT", -4, 4)
    icon:SetTexture(466035) -- Blizzard tackle box icon.
    icon:SetTexCoord(.07,.93,.07,.93)
    local highlight = button:CreateTexture(nil, "HIGHLIGHT")
    highlight:SetAllPoints(icon)
    highlight:SetColorTexture(1,.83,.45,.16)
    button:RegisterForClicks("LeftButtonUp", "MiddleButtonUp")
    button:RegisterForDrag("LeftButton")
    button:SetScript("OnClick", function(_, mouseButton)
        if mouseButton == "LeftButton" then
            toggleWindow()
        elseif mouseButton == "MiddleButton" and IsShiftKeyDown() then
            swapTackleEquipment()
        end
    end)
    button:SetScript("OnDragStart", function(self)
        if IsShiftKeyDown() then self:StartMoving(); self.moving = true end
    end)
    button:SetScript("OnDragStop", function(self)
        if not self.moving then return end
        self:StopMovingOrSizing()
        self.moving = false
        local point, _, relativePoint, x, y = self:GetPoint()
        character.tacklePosition = {point, relativePoint, x, y}
    end)
    button:SetScript("OnEnter", function(self)
        GameTooltip:SetOwner(self, "ANCHOR_LEFT")
        GameTooltip:SetText("Fishing")
        GameTooltip:AddLine("Click to open • Shift-drag to move", .83,.83,.83)
        GameTooltip:AddLine("Shift-middle-click to swap pole and previous gear", .83,.83,.83)
        GameTooltip:Show()
    end)
    button:SetScript("OnLeave", function() GameTooltip:Hide() end)
    button:SetShown(db.showTackle ~= false)
    return button
end

local function build()
    panel = suite.window(UIParent, {.055,.082,.108,.98})
    panel:SetSize(548, 458)
    local position = db.position
    panel:SetPoint(position and position.point or "CENTER", UIParent, position and position.relative or "CENTER",
        position and position.x or 0, position and position.y or 0)
    panel:SetFrameStrata("FULLSCREEN_DIALOG")
    panel:SetToplevel(true)
    panel:SetMovable(true)
    panel:SetClampedToScreen(true)
    panel:EnableMouse(true)
    panel:RegisterForDrag("LeftButton")
    panel:SetScript("OnDragStart", panel.StartMoving)
    panel:SetScript("OnDragStop", function(self)
        self:StopMovingOrSizing()
        local point, _, relative, x, y = self:GetPoint()
        db.position = {point=point, relative=relative, x=x, y=y}
    end)
    suite.escapeCloses(panel, function(self) self:Hide() end)
    panel:Hide()
    local title = suite.label(panel, 16, -14)
    title:SetText("Fishing")
    suite.label(panel, 15, -433):SetText("v1.2.0")
    title:SetTextColor(1,.80,.40)
    suite.button(panel, "X", 506, -10, 26, function() panel:Hide() end)

    local options = CreateFrame("Frame", nil, panel)
    options:SetAllPoints()
    local zonePage = CreateFrame("Frame", nil, panel)
    zonePage:SetAllPoints()
    zonePage:Hide()
    local sessionPage = CreateFrame("Frame", nil, panel)
    sessionPage:SetAllPoints()
    sessionPage:Hide()
    local refreshSession = sessions.build(sessionPage)
    local bobberPage = CreateFrame("Frame", nil, panel)
    bobberPage:SetAllPoints()
    bobberPage:Hide()
    bobber.build(bobberPage, updateAction)
    local volume = CreateFrame("Slider", "ProfessionAIOFishingVolumeSlider", bobberPage, "OptionsSliderTemplate")
    volume:SetPoint("TOPLEFT", 23, -365)
    volume:SetSize(235, 17)
    volume:SetMinMaxValues(0, 100)
    volume:SetValueStep(5)
    volume:SetObeyStepOnDrag(true)
    local volumeText = suite.label(bobberPage, 20, -341)
    local function updateVolumeText(value)
        volumeText:SetText(("Fishing effects volume  ·  %d%%"):format(value))
    end
    local initialVolume = tonumber(db.fishingSFX) or (tonumber(getCVar("Sound_SFXVolume")) or 1)*100
    volume:SetValue(initialVolume)
    updateVolumeText(math.floor(initialVolume + .5))
    volume:SetScript("OnValueChanged", function(_, value)
        db.fishingSFX = math.floor(value + .5)
        updateVolumeText(db.fishingSFX)
        updateAction()
    end)
    local volumeNote = suite.label(bobberPage, 20, -396)
    volumeNote:SetText("Quiet audio only. Applies to all effects, including nearby splashes.")
    local guidePage = CreateFrame("Frame", nil, panel)
    guidePage:SetAllPoints()
    suite.buildFishingGuide(guidePage, function() panel:Hide() end, fishingSkill)
    guidePage:Hide()
    local tabs = {}
    local function selectPage(page)
        options:SetShown(page == options)
        zonePage:SetShown(page == zonePage)
        for frame, tab in pairs(tabs) do tab:SetEnabled(frame ~= page) end
        sessionPage:SetShown(page == sessionPage)
        bobberPage:SetShown(page == bobberPage)
        guidePage:SetShown(page == guidePage)
        refreshWindow()
    end
    local toggleCraft
    toggleCraft, refreshCraft = suite.buildFishingCraft(panel)
    tabs[sessionPage] = suite.button(panel, "Session", 67, -10, 62, function() selectPage(sessionPage) end)
    suite.button(panel, "Craft", 131, -10, 49, toggleCraft)
    tabs[zonePage] = suite.button(panel, "Zones", 182, -10, 53, function() selectPage(zonePage) end)
    tabs[options] = suite.button(panel, "Settings", 429, -10, 71, function() selectPage(options) end)
    tabs[bobberPage] = suite.button(panel, "Bobber", 237, -10, 60, function() selectPage(bobberPage) end)
    tabs[guidePage] = suite.button(panel, "Quests & Uniques", 299, -10, 126, function() selectPage(guidePage) end)

    local function checkbox(caption, x, y, setting)
        local check = CreateFrame("CheckButton", nil, options, "UICheckButtonTemplate")
        check:SetPoint("TOPLEFT", x, y)
        check:SetSize(24,24)
        check:SetChecked(setting == "showTackle" and db.showTackle ~= false or db[setting] == true)
        suite.label(options, x+27, y-6):SetText(caption)
        check:SetScript("OnClick", function(self)
            db[setting] = self:GetChecked() == true
            if setting == "trackSessions" and not db.trackSessions then sessions.stopCast() end
            panel:SetBackdropColor(.055,.082,.108,db.solid and 1 or .98)
            if tackle then tackle:SetShown(db.showTackle ~= false) end
            updateAction()
            refreshWindow()
        end)
    end
    checkbox("Quiet audio with pole equipped", 14, -40, "mute")
    checkbox("Fast loot fishing catches", 310, -40, "fastLoot")
    checkbox("Solid background", 14, -66, "solid")
    checkbox("Show tackle button", 310, -66, "showTackle")
    checkbox("Track fishing sessions", 14, -139, "trackSessions")
    panel:SetBackdropColor(.055,.082,.108,db.solid and 1 or .98)

    local bindingText = suite.label(options, 16, -101)
    local bindButton = suite.button(options, "Set fishing key", 333, -94, 125, function() end)
    local clearButton = suite.button(options, "Clear", 464, -94, 68, function()
        if InCombatLockdown() then return end
        for _, key in ipairs({GetBindingKey(BINDING)}) do SetBinding(key) end
        SaveBindings(GetCurrentBindingSet())
        updateAction("UPDATE_BINDINGS")
        refreshWindow()
    end)

    local pendingKey, pendingPhysicalKey, released
    local capture = CreateFrame("Frame", nil, options)
    capture:Hide()
    capture:EnableKeyboard(true)
    capture:SetPropagateKeyboardInput(false)
    bindButton:SetScript("OnClick", function()
        if InCombatLockdown() then return end
        pendingKey, pendingPhysicalKey, released = nil, nil, false
        bindingText:SetText("Press a key combination (Esc cancels)")
        capture:Show()
    end)
    capture:SetScript("OnKeyDown", function(self, key)
        if key == "LSHIFT" or key == "RSHIFT" or key == "LCTRL" or key == "RCTRL"
            or key == "LALT" or key == "RALT" or key == "SHIFT" or key == "CTRL" or key == "ALT" then return end
        if key == "ESCAPE" or InCombatLockdown() then
            self:Hide()
            refreshWindow()
            return
        end
        local physicalKey = key
        key = (IsAltKeyDown() and "ALT-" or "") .. (IsControlKeyDown() and "CTRL-" or "")
            .. (IsShiftKeyDown() and "SHIFT-" or "") .. key
        local assigned = GetBindingAction(key)
        if assigned and assigned ~= "" and assigned ~= BINDING then
            if pendingKey ~= key then
                pendingKey, pendingPhysicalKey, released = key, physicalKey, false
                bindingText:SetText("Press " .. key .. " again to replace its binding.")
                return
            end
            if not released then return end
        end
        self:Hide()
        local oldKeys = {GetBindingKey(BINDING)}
        if SetBindingClick(key, ACTION, "LeftButton") then
            for _, old in ipairs(oldKeys) do if old ~= key then SetBinding(old) end end
            SaveBindings(GetCurrentBindingSet())
            updateAction("UPDATE_BINDINGS")
        end
        refreshWindow()
    end)
    capture:SetScript("OnKeyUp", function(_, key)
        if key == pendingPhysicalKey then released = true end
    end)
    options:SetScript("OnHide", function() capture:Hide() end)

    local skillText = suite.label(zonePage, 16, -46)
    local filters = {"All areas", "Can gain skill", "Reliable skill-ups"}
    local filter = tonumber(db.filter) or 1
    if not filters[filter] then filter = 1 end
    local filterButton = suite.button(zonePage, filters[filter], 394, -40, 138, function()
        filter = filter % #filters + 1
        db.filter = filter
        refreshWindow()
    end)
    local note = suite.label(zonePage, 16, -73)
    note:SetTextColor(.68,.72,.77)
    note:SetText("Zone thresholds are reference values. Bonuses count toward catches.")
    suite.label(zonePage, 16, -99):SetText("Area  ·  Click to open map")
    suite.label(zonePage, 356, -99):SetText("Minimum")
    suite.label(zonePage, 438, -99):SetText("Reliable")

    local scroll = CreateFrame("ScrollFrame", nil, zonePage, "UIPanelScrollFrameTemplate")
    scroll:SetPoint("TOPLEFT", 13, -118)
    scroll:SetPoint("BOTTOMRIGHT", -32, 33)
    local content = CreateFrame("Frame", nil, scroll)
    content:SetSize(502, 1)
    scroll:SetScrollChild(content)
    local rows = {}
    for i, zone in ipairs(suite.fishingZones) do
        local row = CreateFrame("Button", nil, content)
        row:SetSize(502, 19)
        row:SetHighlightTexture("Interface\\QuestFrame\\UI-QuestTitleHighlight")
        row.zoneName = zone.name
        row:SetScript("OnClick", function(self)
            local mapID = suite.fishingZoneMapID(self.zoneName)
            if mapID and suite.openWorldMap(mapID) then
                panel:Hide()
            else
                print("Fishing: World map unavailable for " .. self.zoneName .. ".")
            end
        end)
        row.nameText = suite.label(row, 3, -3)
        row.nameText:SetText(zone.name)
        row.minimum = suite.label(row, 343, -3)
        row.minimum:SetText(zone.minimum or "—")
        row.reliable = suite.label(row, 425, -3)
        row.reliable:SetText(zone.reliable or "—")
        rows[i] = row
    end
    local empty = suite.label(content, 3, -4)
    local tribute = suite.label(panel, 0, 0)
    tribute:ClearAllPoints()
    tribute:SetPoint("BOTTOM", 0, 10)
    tribute:SetFont("Fonts\\MORPHEUS.TTF", 10, "")
    tribute:SetTextColor(.78,.64,.33)
    tribute:SetText("RIP Shady")

    refreshWindow = function()
        if sessionPage:IsShown() then refreshSession(); return end
        if bobberPage:IsShown() or guidePage:IsShown() then return end
        local key = GetBindingKey(BINDING)
        if options:IsShown() and not capture:IsShown() then bindingText:SetText("Equip / Cast / Reel  •  " .. (key or "Unbound")) end
        clearButton:SetEnabled(key ~= nil)
        tackle:SetShown(db.showTackle ~= false)
        panel:SetBackdropColor(.055,.082,.108,db.solid and 1 or .98)
        if not zonePage:IsShown() then return end
        filterButton:SetText(filters[filter])
        local rank, effective, cap = fishingSkill()
        local canLevel = rank > 0 and rank < cap
        if rank == 0 then skillText:SetText("Fishing skill unavailable")
        elseif not canLevel then skillText:SetText(("Fishing %d/%d  •  Effective %d  •  At cap"):format(rank,cap,effective))
        else skillText:SetText(("Fishing %d/%d  •  Effective %d"):format(rank,cap,effective)) end
        local count = 0
        for i, zone in ipairs(suite.fishingZones) do
            local reliable = zone.reliable and effective >= zone.reliable
            local eligible = canLevel and (reliable or (zone.minimum and effective >= zone.minimum))
            local visible = filter == 1 or (eligible and (filter == 2 or reliable))
            local row = rows[i]
            row:SetShown(visible == true)
            if visible then
                row:ClearAllPoints()
                row:SetPoint("TOPLEFT", 0, -count*19)
                if reliable then row.nameText:SetTextColor(.55,.9,.59)
                elseif eligible then row.nameText:SetTextColor(1,.82,.3)
                else row.nameText:SetTextColor(.72,.74,.78) end
                count = count + 1
            end
        end
        empty:SetShown(count == 0)
        empty:SetText(rank == 0 and "Learn Fishing or expand Secondary Skills to read your rank."
            or (not canLevel and "You're at your trained Fishing cap." or "No reference areas match your effective skill."))
        content:SetHeight(math.max(19,count*19))
        if scroll:GetVerticalScroll() > scroll:GetVerticalScrollRange() then
            scroll:SetVerticalScroll(scroll:GetVerticalScrollRange())
        end
    end
    options:Hide()
    sessionPage:Show()
    tabs[sessionPage]:Disable()
    panel:SetScript("OnShow", function(self) self:Raise(); refreshWindow() end)
end

suite.registerModule(function(event, unit, arg, spellID)
    if event == "ADDON_LOADED" then
        if unit ~= name then return end
        ProfessionAIOFishingDB = type(ProfessionAIOFishingDB) == "table" and ProfessionAIOFishingDB or {}
        ProfessionAIOFishingCharacterDB = type(ProfessionAIOFishingCharacterDB) == "table" and ProfessionAIOFishingCharacterDB or {}
        db, character = ProfessionAIOFishingDB, ProfessionAIOFishingCharacterDB
        if db.solid == nil then db.solid = true end
        if db.trackSessions == nil then db.trackSessions = true end
        character.cvars = type(character.cvars) == "table" and character.cvars or {}
        sessions.initialize(character, fishingSkill)
        bobber.initialize(db)
        updateCVars(false, false)
        spellName = fishingSpell()
        action = CreateFrame("Button", ACTION, UIParent, "SecureActionButtonTemplate")
        action:RegisterForClicks("AnyDown", "AnyUp")
        action:HookScript("PreClick", function(self, _, down)
            if InCombatLockdown() or not reelEndedAt then return end
            local secondsSinceReel = GetTime() - reelEndedAt
            reelEndedAt = nil
            if not down and secondsSinceReel < .3 then
                self:SetAttribute("type", nil)
                self.ignoredReelRelease = true
            end
        end)
        action:HookScript("PostClick", function(self)
            if not self.ignoredReelRelease then return end
            self.ignoredReelRelease = nil
            updateAction()
        end)
        override = CreateFrame("Frame", nil, UIParent, "SecureHandlerStateTemplate")
        override:SetAttribute("_onstate-combat", [[if newstate == "combat" then self:ClearBindings() end]])
        RegisterStateDriver(override, "combat", "[combat] combat; safe")
        build()
        tackle = buildTackleButton()
        SLASH_PROFESSIONAIOFISHING1 = "/paiofish"
        SLASH_PROFESSIONAIOFISHING2 = "/professionaiofishing"
        SlashCmdList.PROFESSIONAIOFISHING = function(message)
            if type(message) ~= "string" or not message:lower():match("^%s*repair%s*$") then
                toggleWindow()
                return
            end
            if InCombatLockdown() then
                print("|cffffd23fProfession AIO Fishing:|r Repair is only available out of combat.")
                return
            end
            local key1, key2 = GetBindingKey(BINDING)
            if not key1 and not key2 then
                print("|cffffd23fProfession AIO Fishing:|r No fishing key assigned. Set one in /paiofish.")
                return
            end
            bindingRepairAttempts, lastBindingRepair, bindingConflictWarned = 0, 0, false
            -- Restore the original click binding, clear any stale reel override,
            -- and refresh the current cast/reel state without a full /reload.
            if key1 then SetBindingClick(key1, ACTION, "LeftButton") end
            if key2 then SetBindingClick(key2, ACTION, "LeftButton") end
            ClearOverrideBindings(override)
            activeReel = nil
            updateAction("UPDATE_BINDINGS")
            print("|cff66ff66Profession AIO Fishing:|r Fishing key refreshed.")
        end
        -- Re-use Core.lua's existing 0.75s poll, rather than adding a ticker.
        -- While fishing, this heals a missed STOP event after Alt+Tab and
        -- restores a lost Interact override; outside fishing it does no work.
        suite.addPoll(function()
            if InCombatLockdown() then return end
            if activeReel or equippedPole() then
                updateAction("FISHING_BINDING_WATCHDOG")
            end
        end)
        return {"PLAYER_ENTERING_WORLD", "PLAYER_LOGOUT", "PLAYER_EQUIPMENT_CHANGED", "BAG_UPDATE_DELAYED",
            "UPDATE_BINDINGS", "UNIT_SPELLCAST_CHANNEL_START", "UNIT_SPELLCAST_CHANNEL_STOP",
            "PLAYER_REGEN_DISABLED", "PLAYER_REGEN_ENABLED", "LOOT_OPENED", "LOOT_CLOSED",
            "SKILL_LINES_CHANGED", "SPELLS_CHANGED", "UNIT_INVENTORY_CHANGED",
            "LOOT_READY", "LOOT_SLOT_CLEARED", "UI_ERROR_MESSAGE", "GET_ITEM_INFO_RECEIVED",
            "PLAYER_SOFT_INTERACT_CHANGED", "NAME_PLATE_UNIT_ADDED", "NAME_PLATE_UNIT_REMOVED",
            "TRADE_SKILL_SHOW", "TRADE_SKILL_CLOSE", "TRADE_SKILL_DATA_SOURCE_CHANGED",
            "TRADE_SKILL_LIST_UPDATE", "NEW_RECIPE_LEARNED"}
    end
    if event == "PLAYER_LOGOUT" then
        sessions.stopCast()
        updateCVars(false, false)
        return
    end
    if event:find("^TRADE_SKILL_") or event == "NEW_RECIPE_LEARNED" then
        refreshCraft()
        return
    end
    if event == "BAG_UPDATE_DELAYED" or event == "GET_ITEM_INFO_RECEIVED"
        or event == "PLAYER_REGEN_DISABLED" or event == "PLAYER_REGEN_ENABLED" then
        refreshCraft()
    end
    if event == "PLAYER_SOFT_INTERACT_CHANGED" or event == "NAME_PLATE_UNIT_ADDED"
        or event == "NAME_PLATE_UNIT_REMOVED" then
        if bobber.enabled() then bobber.update(not InCombatLockdown() and fishingChannel()) end
        return
    end
    if (event:find("^UNIT_")) and unit ~= "player" then return end
    if event == "PLAYER_ENTERING_WORLD" then
        sessions.enterWorld(unit, arg)
    elseif event == "UNIT_SPELLCAST_CHANNEL_START" then
        if db.trackSessions and (fishingChannel() or spellID == FISHING or spellID == 7731 or spellID == 7732
            or spellID == 18248) then sessions.cast() end
    elseif event == "UNIT_SPELLCAST_CHANNEL_STOP" then
        sessions.stopCast()
    elseif event == "UI_ERROR_MESSAGE" then
        if db.trackSessions then sessions.escape(arg) end
    elseif event == "SKILL_LINES_CHANGED" then
        sessions.skillChanged()
    elseif event == "LOOT_READY" then
        if db.trackSessions then sessions.snapshotLoot() end
    elseif event == "LOOT_OPENED" then
        lootOpen = true
        if db.trackSessions then sessions.snapshotLoot() end
        fastLoot()
    elseif event == "LOOT_SLOT_CLEARED" then
        if db.trackSessions then sessions.lootCleared(unit) end
    elseif event == "LOOT_CLOSED" then
        lootOpen, lootHandled = false, false
        sessions.closeLoot()
    end
    if event == "UI_ERROR_MESSAGE" or event == "LOOT_READY" or event == "LOOT_SLOT_CLEARED"
        or event == "GET_ITEM_INFO_RECEIVED" then
        if panel:IsShown() and not refreshPending then
            refreshPending = true
            C_Timer.After(.1, function()
                refreshPending = false
                if panel:IsShown() then refreshWindow() end
            end)
        end
        return
    end
    if event == "SPELLS_CHANGED" then spellName = fishingSpell() end
    updateAction(event)
    -- The channel and loot frame state can settle after the event itself.
    if event == "UNIT_SPELLCAST_CHANNEL_STOP" or event == "UNIT_SPELLCAST_CHANNEL_START"
        or event == "LOOT_OPENED" or event == "LOOT_CLOSED" then
        C_Timer.After(0, function() updateAction() end)
    end
    if panel:IsShown() then refreshWindow() end
end)
