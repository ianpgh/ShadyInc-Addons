local name, suite = ...
local addon = suite.EnchantIt
local ENCHANTING = 333
local db, controls, panel, mini, mainCountdown
local settingsOpen = false
local native, hookFrame
local pending
local rows, page, index = {}, 1, 1
local pendingRecipe
local trainerOpen
local trainerOffers


local function scanTrainer()
    if not trainerOpen or not GetNumTrainerServices or not GetTrainerServiceInfo then return end
    local trainer = UnitName and UnitName("npc")
    local map = C_Map and C_Map.GetBestMapForUnit and C_Map.GetBestMapForUnit("player")
    local position = map and C_Map.GetPlayerMapPosition and C_Map.GetPlayerMapPosition(map, "player")
    local waypoint
    if position and trainer then
        local x, y = position:GetXY()
        if x and y then waypoint = {map, x, y, trainer} end
    end
    for i = 1, GetNumTrainerServices() or 0 do
        local service, _, status = GetTrainerServiceInfo(i)
        if service and (status == "available" or status == "unavailable") then
            local skillName, minimum
            if GetTrainerServiceSkillReq then skillName, minimum = GetTrainerServiceSkillReq(i) end
            if skillName == "Enchanting" or addon.trainerRanks[service] then
                trainerOffers[service] = {
                    skill=tonumber(minimum) or addon.trainerRanks[service],
                    cost=GetTrainerServiceCost and GetTrainerServiceCost(i),
                    trainer=trainer,
                    waypoint=waypoint,
                }
            end
        elseif service and status == "used" then
            trainerOffers[service] = nil
        end
    end
end

local COLOR = {.055,.082,.108,.98}
local api = suite.tradeSkillAPI

local function enchantingInfo(info)
    return suite.matchesProfession(info, ENCHANTING, Enum and Enum.Profession and Enum.Profession.Enchanting or 9, "Enchanting")
end

local function isEnchanting()
    return suite.isProfession(native, ENCHANTING, Enum and Enum.Profession and Enum.Profession.Enchanting or 9, "Enchanting")
end

local function window(parent) return suite.window(parent, COLOR) end
local label, button, itemName = suite.label, suite.button, suite.itemName

local function materials(id)
    local schematic = api("GetRecipeSchematic", id, false)
    local slots = schematic and schematic.reagentSlotSchematics
    if type(slots) ~= "table" or #slots == 0 then return end
    local result, seen = {}, {}
    for _, slot in ipairs(slots) do
        local amount = slot.quantityRequired
        if slot.required ~= false and type(amount) == "number" and amount > 0 then
            local reagent = slot.reagents and #slot.reagents == 1 and slot.reagents[1]
            local itemID = reagent and reagent.itemID
            if not itemID then return end
            if seen[itemID] then
                seen[itemID][2] = seen[itemID][2] + amount
            else
                local row = {itemID, amount}
                seen[itemID] = row
                result[#result+1] = row
            end
        end
    end
    return #result > 0 and result or nil
end

local function restore() suite.restoreNative(addon) end
local function hideNative() return suite.hideNative(addon, native) end

local function openEnchanting()
    if InCombatLockdown() then return end
    if isEnchanting() and native and native:IsShown() then return end
    api("OpenTradeSkill", ENCHANTING)
end

local function needsTarget(id, info)
    local schematic = api("GetRecipeSchematic", id, false)
    local enchant = Enum and Enum.TradeskillRecipeType and Enum.TradeskillRecipeType.Enchant
    return (enchant ~= nil and schematic and schematic.recipeType == enchant)
        or (info and type(info.name) == "string" and info.name:match("^Enchant ") ~= nil)
end

local function craftLimit(entry)
    if not entry or not isEnchanting() or InCombatLockdown() then return 0 end
    local info = api("GetRecipeInfo", entry.id)
    if not info or not info.learned or info.name ~= entry.name then return 0 end
    for _, req in ipairs(api("GetRecipeRequirements", entry.id) or {}) do
        if req.met == false then return 0 end
    end
    local count = 999
    for _, row in ipairs(entry.materials) do
        local bag = C_Item and C_Item.GetItemCount and C_Item.GetItemCount(row[1], false, false, false)
            or (GetItemCount and GetItemCount(row[1], false, false)) or 0
        count = math.min(count, math.floor(bag / row[2]))
    end
    local nativeCount = api("GetCraftableCount", entry.id)
    if type(nativeCount) == "number" and not entry.target then count = math.min(count, nativeCount) end
    return math.max(0, entry.target and math.min(1, count) or count)
end

local refresh
local function enchantingSkillInfo()
    local skill = C_SkillInfo and C_SkillInfo.GetSkillLineInfoByID and C_SkillInfo.GetSkillLineInfoByID(ENCHANTING)
    if skill and tonumber(skill.rank) and skill.rank > 0 then
        return {skillLevel=skill.rank, maxSkillLevel=skill.maxRank}
    end
    local profession = api("GetBaseProfessionInfo")
    if not enchantingInfo(profession) or not tonumber(profession.skillLevel) then
        profession = api("GetChildProfessionInfo")
    end
    if enchantingInfo(profession) then return profession end
end

local learningWaypoint

local function showTooltip(self)
    local entry = self.entry
    if not entry then return end
    GameTooltip:SetOwner(self, "ANCHOR_RIGHT")
    GameTooltip:SetText(addon.coloredRecipeName(entry.name, entry.difficulty))
    for i, reagent in ipairs(entry.materials) do
        local id, amount = unpack(reagent)
        local value = entry.prices and addon.money(entry.prices[i]) .. " each" or ""
        GameTooltip:AddDoubleLine(("%d × %s"):format(amount, itemName(id)), value)
    end
    if entry.craftCost then
        GameTooltip:AddDoubleLine("Cost per craft", addon.money(entry.craftCost))
    end
    if db.showResale and db.showCheapest then
        local routes = entry.resale or addon.resaleProceeds(entry, api("GetRecipeSchematic", entry.id, false))
        GameTooltip:AddLine("Sale proceeds / profit after materials", .7, .8, 1)
        for _, route in ipairs(routes) do
            local proceeds = route.proceeds and addon.money(route.proceeds) or "—"
            GameTooltip:AddDoubleLine(route.label, proceeds .. " / " .. addon.resaleDelta(route.proceeds, entry.craftCost))
        end
        if entry.target then
            GameTooltip:AddLine("Gear enchants are applied directly to the target.", .7, .8, 1, true)
        end
    end
    local skill = enchantingSkillInfo()
    local rank = entry.requiredSkill or (skill and tonumber(skill.skillLevel))
    local live = api("GetRecipeInfo", entry.id)
    local difficulty = live and live.learned and live.relativeDifficulty or entry.difficulty
    local remaining, nextColor, threshold = addon.nextRecipeColor(entry.name, rank, difficulty)
    if remaining then
        local label = entry.requiredSkill and "Next color after learning" or "Next color"
        GameTooltip:AddDoubleLine(label, ("%s at %d (%d skill %s)"):format(nextColor, threshold, remaining,
            remaining == 1 and "point" or "points"))
        if nextColor == "Gray" then GameTooltip:AddLine("Gray recipes give no skill points.", .68, .72, .77) end
    end
    local training = entry.training
    if training then
        local destination, note = learningWaypoint(entry)
        if training.source then
            GameTooltip:AddLine(training.source, 1, 1, 1, true)
        end
        if destination then
            GameTooltip:AddDoubleLine("Map destination", destination[4])
            local action = destination[2] and "Click to open the map and set a waypoint." or "Click to open the source zone map."
            GameTooltip:AddLine(action, .6, .85, 1, true)
        elseif training.trainer then
            GameTooltip:AddDoubleLine("Trainer", training.trainer)
        else
            GameTooltip:AddLine("No verified map destination.", .68, .72, .77, true)
        end
        if note then GameTooltip:AddLine(note, .86, .78, .56, true) end
    end
    if entry.trainingCost then GameTooltip:AddDoubleLine("Training fee", addon.money(entry.trainingCost)) end
    if entry.target then GameTooltip:AddLine("Choose the target in Blizzard Enchanting.", .6, .85, 1, true) end
    GameTooltip:Show()
end

learningWaypoint = function(entry)
    local side = UnitFactionGroup and UnitFactionGroup("player")
    return addon.learningSource(entry.name, entry.training, side)
end

local function setLearningWaypoint(entry)
    local destination, note = learningWaypoint(entry)
    if destination then
        if destination[2] and destination[3] then
            suite.openLearningMap(destination, "Enchant It", entry.name)
        else
            suite.openWorldMap(destination[1])
        end
        if note then print("Enchant It: " .. note) end
        return
    end
    local source = note or (entry.training and entry.training.source)
    print("Enchant It: " .. entry.name .. " — " .. (source or "No verified map destination."))
end

local function recipeOffer(id, info, rank, upcoming)
    local recipe = info.name
    local data = addon.recipeData[recipe]
    local scanned = trainerOffers[recipe]
    local minimum = (scanned and scanned.skill) or addon.trainerRanks[recipe] or (data and data[4])
    if not minimum or (rank < minimum) ~= upcoming then return end
    local difficulty = addon.recipeDifficulty(recipe, upcoming and minimum or rank, info.relativeDifficulty)
    if not upcoming and difficulty ~= 0 and difficulty ~= 1 then return end
    return {
        cost=scanned and scanned.cost,
        trainer=scanned and scanned.trainer,
        source=api("GetRecipeSourceText", id) or (data and data[5]),
        trainerRecipe=scanned ~= nil or addon.trainerRanks[recipe] ~= nil,
        waypoint=scanned and scanned.waypoint,
        minimum=minimum,
        requiredSkill=upcoming and minimum or nil,
        difficulty=difficulty,
    }
end

local function pickRecipes(color)
    local upcoming = color == "Upcoming"
    local trainingMode = upcoming or color == "Trainable"
    local skill = trainingMode and enchantingSkillInfo()
    local rank = skill and tonumber(skill.skillLevel)
    local cap = skill and tonumber(skill.maxSkillLevel)
    if trainingMode and (not rank or (not upcoming and (rank >= 300 or (cap and rank >= cap)))) then
        return {}, 0
    end
    local ids = api("GetAllRecipeIDs")
    if type(ids) ~= "table" or #ids == 0 then ids = api("GetFilteredRecipeIDs") or {} end
    local learned, infoByID, offers = {}, {}, {}
    for _, id in ipairs(ids) do
        local info = api("GetRecipeInfo", id)
        if info and info.name and not info.isDummyRecipe and not info.isRecraft then
            local offer = trainingMode and not info.learned and recipeOffer(id, info, rank, upcoming)
            if info.learned or offer then
                if not learned[info.name] or info.learned then
                    learned[info.name] = id
                    infoByID[id] = info
                end
                if offer then offers[info.name] = offer end
            end
        end
    end
    if db.showCheapest then
        local options, missing = addon.rankRecipes(learned, function(id) return infoByID[id] end, materials, color, offers)
        for _, entry in ipairs(options) do entry.target = needsTarget(entry.id, infoByID[entry.id]) end
        return options, missing
    end
    local options = {}
    for recipe,id in pairs(learned) do
        local reagents = materials(id)
        local info = infoByID[id]
        local difficulty = info.relativeDifficulty
        if reagents and addon.matchesColor(difficulty, color) then
            options[#options+1] = {name=recipe, id=id, materials=reagents, difficulty=difficulty,
                target=needsTarget(id, info)}
        end
    end
    table.sort(options, function(a,b)
        if a.difficulty ~= b.difficulty then return a.difficulty < b.difficulty end
        return a.name < b.name
    end)
    return options, 0
end

local function recipeCountdown(recipe)
    if not recipe or not recipe.learned then return "" end
    local profession = enchantingSkillInfo()
    if not profession then return "" end
    return addon.colorCountdown(recipe.name, tonumber(profession.skillLevel), recipe.relativeDifficulty)
end

local function updateMainCountdown()
    local crafting = native and native.CraftingPage
    local form = crafting and crafting.SchematicForm
    if not controls:IsShown() or not form or not form:IsVisible() or not form.GetRecipeInfo then
        mainCountdown:Hide()
        return
    end
    local selected = form:GetRecipeInfo()
    local recipe = selected and selected.recipeID and api("GetRecipeInfo", selected.recipeID) or selected
    local text = recipeCountdown(recipe)
    if text == "" then mainCountdown:Hide(); return end
    -- Keep the skill-up countdown above the recipe header, away from native cooldowns.
    if mainCountdown.anchor ~= form then
        mainCountdown:ClearAllPoints()
        mainCountdown:SetPoint("TOP", form, "TOP", 0, -8)
        mainCountdown.anchor = form
    end
    mainCountdown:SetText(text)
    mainCountdown:Show()
end

local function updateAmount()
    local info = enchantingSkillInfo()
    local skill = info and tonumber(info.skillLevel)
    local cap = info and tonumber(info.maxSkillLevel)
    local text = ""
    if skill then
        text = cap and ("Enchanting %d / %d"):format(skill, cap) or ("Enchanting %d"):format(skill)
    end
    mini.skill:SetText(text)
    local limit = craftLimit(mini.current)
    local qty = tonumber(mini.amount:GetText())
    local targeted = mini.current and mini.current.target
    mini.craft:SetText(targeted and "ENCHANT" or (qty and qty > 0 and "CRAFT " .. qty or "CRAFT"))
    mini.craft:SetEnabled(targeted and not InCombatLockdown() or (not targeted and qty ~= nil and qty >= 1 and qty % 1 == 0 and qty <= limit))
    if targeted then mini.amount:Disable() else mini.amount:Enable() end
    mini.minus:SetEnabled(not targeted)
    mini.plus:SetEnabled(not targeted)
    mini.max:SetEnabled(not targeted and limit > 0)
    local recipe = mini.current and isEnchanting() and api("GetRecipeInfo", mini.current.id)
    local countdown = recipeCountdown(recipe)
    mini.countdown:SetText(countdown)
    mini.hint:SetText(targeted and "Choose an item in the full window." or (limit > 0 or countdown ~= "") and (limit .. " craftable")
        or (mini.current and "Check materials or required tools." or ""))
end

local function setRankedResults(results, missing, color)
    local recipeGroup = color == "All" and "Skill-up" or color
    rows = results
    local count = #rows
    index = math.max(1, math.min(index, count))
    local pages = math.max(1, math.ceil(count / #panel.results))
    page = math.max(1, math.min(page, pages))
    local note
    local info = enchantingSkillInfo()
    local trainingMode = color == "Trainable" or color == "Upcoming"
    local showTraining = db.showCheapest and trainingMode
    if not addon.hasCraftPricing() and not trainingMode then note = "Enable Auction Companion to show prices."
    elseif db.showCheapest and color ~= "Upcoming" and info and info.skillLevel and info.maxSkillLevel and info.skillLevel >= info.maxSkillLevel then
        note = info.skillLevel >= 300 and "Enchanting 300 reached." or "Train the next Enchanting rank."
        rows, count, pages, page, index = {}, 0, 1, 1, 1
    elseif color == "Trainable" then
        local skill = enchantingSkillInfo()
        local rank = skill and tonumber(skill.skillLevel)
        local cap = skill and tonumber(skill.maxSkillLevel)
        if not rank then note = "Open Enchanting to check your skill."
        elseif rank >= 300 then note = "Enchanting 300 reached."
        elseif cap and rank >= cap then note = "Train the next Enchanting rank."
        elseif count == 0 then note = "No unlearned orange or yellow recipes now."
        else note = "Orange / yellow skill-ups • Cost / craft" end
    elseif color == "Upcoming" then
        note = count > 0 and "Upcoming recipes • Required Enchanting skill"
            or "No upcoming recipes found."
    elseif count == 0 then
        note = missing > 0 and addon.pricingHint() or ("No learned %s recipes."):format(recipeGroup:lower())
    else note = ("%s recipes • Last scan cost / craft%s"):format(recipeGroup, missing > 0 and (" • " .. missing .. " unpriced") or "") end
    local compare = db.showCheapest and db.showResale and panel:IsShown()
    if compare and count > 0 then note = "Cost / craft • Profit or loss by sale route" end
    panel.note:SetText(note)
    local rowSpacing = compare and 55 or 38
    for i, btn in ipairs(panel.results) do
        local entry = rows[(page-1)*#panel.results+i]
        btn.entry = entry
        btn:SetShown(showTraining and entry ~= nil)
        btn:ClearAllPoints()
        btn:SetPoint("TOPLEFT", 12, -103-(i-1)*rowSpacing)
        btn.resaleLine:SetShown(compare == true and entry ~= nil)
        if entry then
            if compare then
                entry.resale = addon.resaleProceeds(entry, api("GetRecipeSchematic", entry.id, false))
                local labels = {}
                for j, route in ipairs(entry.resale) do
                    labels[j] = route.label .. " " .. addon.resaleDelta(route.proceeds, entry.craftCost)
                end
                btn.resaleLine:SetText(table.concat(labels, "   •   "))
            end
            local cost = entry.craftCost and addon.money(entry.craftCost) or "No price"
            local requirement = entry.requiredSkill and ("Skill %d  •  "):format(entry.requiredSkill) or ""
            btn.recipeName:SetText(addon.coloredRecipeName(entry.name, entry.difficulty))
            btn.recipeCost:SetText(requirement .. cost)
        end
    end
    panel.prev:SetShown(showTraining and page > 1)
    panel.next:SetShown(showTraining and page < pages)
    panel.refresh:SetShown(showTraining)
    panel.note:SetShown(showTraining)
    local footerY = -106 - #panel.results * rowSpacing
    for _, control in ipairs({panel.prev, panel.next, panel.refresh}) do
        control:ClearAllPoints()
        control:SetPoint("TOPLEFT", control.footerX, footerY)
    end
    panel:SetHeight(showTraining and (-footerY + 29) or 86)

    local entry = rows[index]
    mini.current = entry
    mini.recipe:SetText(entry and addon.coloredRecipeName(entry.name, entry.difficulty) or (db.showCheapest and note or ("No learned %s recipes."):format(recipeGroup:lower())))
    mini.cost:SetText(entry and (entry.craftCost and ("~" .. addon.money(entry.craftCost) .. " / craft") or (index .. " / " .. count)) or "")
    mini.prev:SetEnabled(index > 1)
    mini.next:SetEnabled(index < count)
    updateAmount()
end

refresh = function()
    native = ProfessionsFrame or TradeSkillFrame
    local visibleEnchanting = native and native:IsShown() and isEnchanting()
    if native and hookFrame ~= native then
        hookFrame = native
        controls:SetParent(native)
        controls:ClearAllPoints()
        controls:SetPoint("TOPRIGHT", native, "TOPRIGHT", -40, -5)
        controls:SetFrameStrata("DIALOG")
        controls:SetFrameLevel(native:GetFrameLevel()+100)
        panel:SetFrameStrata("DIALOG")
        panel:SetFrameLevel(controls:GetFrameLevel()+5)
        local attached = native
        native:HookScript("OnHide", function()
            if hookFrame ~= attached then return end
            settingsOpen = false
            controls:Hide()
            mainCountdown:Hide()
            restore()
            mini:Hide()
            panel:Hide()
        end)
        native:HookScript("OnShow", function() C_Timer.After(0, refresh) end)
    end
    if not visibleEnchanting then
        if native and native:IsShown() and not api("IsDataSourceChanging") then settingsOpen = false end
        controls:Hide()
        mainCountdown:Hide()
        restore()
        mini:Hide()
        panel:Hide()
        return
    end
    local compact = db.mini and not InCombatLockdown() and hideNative()
    if not compact then restore() end
    if compact then settingsOpen = false end
    controls:SetShown(not compact)
    panel:SetShown(not compact and settingsOpen)
    mini:SetShown(compact == true)
    local color = (compact and db.miniColor or not compact and db.mainColor) or "Orange"
    if compact or (settingsOpen and db.showCheapest and (color == "Trainable" or color == "Upcoming")) then
        local results, missing = pickRecipes(color)
        setRankedResults(results, missing, color)
    else setRankedResults({}, 0, color) end
    panel:SetBackdropColor(COLOR[1], COLOR[2], COLOR[3], db.solid and 1 or COLOR[4])
    mini:SetBackdropColor(COLOR[1], COLOR[2], COLOR[3], db.solid and 1 or COLOR[4])
    panel.solid:SetChecked(db.solid)
    panel.cheapest:SetChecked(db.showCheapest)
    panel.resale:SetShown(db.showCheapest == true)
    panel.resale:SetChecked(db.showResale == true)
    mini.cheapest:SetChecked(db.showCheapest)
    updateMainCountdown()
    if not compact and pendingRecipe then
        local id = pendingRecipe
        pendingRecipe = nil
        api("OpenRecipe", id)
    end
end

local function schedule()
    if pending then return end
    pending = true
    C_Timer.After(.12, function() pending = false; refresh() end)
end

local function checkbox(parent, caption, x, y, handler)
    local check = CreateFrame("CheckButton", nil, parent, "UICheckButtonTemplate")
    check:SetPoint("TOPLEFT", x, y)
    check:SetSize(23,23)
    label(parent, x+24, y-5):SetText(caption)
    check:SetScript("OnClick", handler)
    return check
end

local function toggleCheapest(self)
    db.showCheapest = self:GetChecked() == true
    page, index = 1, 1
    refresh()
end

local function colorDropdown(parent, key, x, y)
    local colorMenu
    local colorButton = button(parent, (db[key] or "Orange") .. " v", x, y, 78, function()
        colorMenu:SetShown(not colorMenu:IsShown())
    end)
    colorMenu = window(parent)
    colorMenu:SetSize(88, key == "mainColor" and 144 or 100)
    colorMenu:SetPoint("TOPLEFT", colorButton, "BOTTOMLEFT", -5, -2)
    colorMenu:SetFrameLevel(parent:GetFrameLevel()+10)
    colorMenu:EnableMouse(true)
    colorMenu:Hide()
    local colors = {"Orange", "Yellow", "Green", "All"}
    if key == "mainColor" then
        colors[#colors+1] = "Trainable"
        colors[#colors+1] = "Upcoming"
    end
    for i, color in ipairs(colors) do
        button(colorMenu, color, 6, -6-(i-1)*22, 76, function()
            db[key] = color
            page, index = 1, 1
            colorButton:SetText(color .. " v")
            colorMenu:Hide()
            refresh()
        end)
    end
    parent:HookScript("OnHide", function() colorMenu:Hide() end)
end

local function build()
    local metadata = C_AddOns and C_AddOns.GetAddOnMetadata or GetAddOnMetadata
    local currentVersion = metadata and metadata(name, "Version")
    local versionText = currentVersion and ("v" .. currentVersion) or ""
    controls = CreateFrame("Frame", nil, UIParent)
    controls:SetSize(139, 21)
    controls:Hide()
    mainCountdown = label(controls, 0, 0)
    mainCountdown:SetTextColor(1, .82, .3)
    mainCountdown:Hide()
    button(controls, "Settings", 0, 0, 81, function()
        settingsOpen = not settingsOpen
        refresh()
    end)
    button(controls, "Mini", 85, 0, 54, function()
        if InCombatLockdown() then return end
        settingsOpen = false
        db.mini = true
        refresh()
    end)

    panel = window(controls)
    panel:SetSize(322, 86)
    panel:SetPoint("TOPRIGHT", controls, "BOTTOMRIGHT", 0, -4)
    panel:EnableMouse(true)
    suite.escapeCloses(panel, function() settingsOpen = false; refresh() end)
    panel:Hide()
    local title = label(panel, 13, -12)
    title:SetTextColor(1,.80,.40)
    title:SetText("Enchant It")
    button(panel, "X", 283, -7, 26, function()
        settingsOpen = false
        refresh()
    end)
    panel.solid = checkbox(panel, "Solid Background", 11, -33, function(self)
        db.solid = self:GetChecked() == true
        refresh()
    end)
    panel.cheapest = checkbox(panel, "Rank in Mini", 11, -57, toggleCheapest)
    colorDropdown(panel, "mainColor", 154, -58)
    panel.resale = checkbox(panel, "Resale", 237, -57, function(self)
        db.showResale = self:GetChecked() == true
        refresh()
    end)
    local tribute = panel:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
    tribute:SetPoint("BOTTOMRIGHT", -12, 11)
    tribute:SetFont("Fonts\\MORPHEUS.TTF", 10, "")
    tribute:SetTextColor(.78,.64,.33)
    tribute:SetText("RIP Shady")
    local settingsVersion = panel:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
    settingsVersion:SetPoint("BOTTOM", panel, "BOTTOM", 22, 11)
    settingsVersion:SetTextColor(.65, .70, .77)
    settingsVersion:SetText(versionText)
    panel.note = label(panel, 13, -85)
    panel.results = {}
    for i = 1, 5 do
        local btn = button(panel, "", 12, -103-(i-1)*38, 298, function(self)
            local entry = self.entry
            if not entry or not isEnchanting() or InCombatLockdown() then return end
            if entry.training then setLearningWaypoint(entry)
            else api("OpenRecipe", entry.id) end
        end)
        btn:SetHeight(36)
        btn.recipeName = label(btn, 8, -6)
        btn.recipeCost = label(btn, 8, -20)
        for _, line in ipairs({btn.recipeName, btn.recipeCost}) do
            line:SetWidth(282)
            line:SetWordWrap(false)
            line:SetMaxLines(1)
        end
        suite.bindRecipeTooltip(btn, showTooltip)
        btn.resaleLine = label(btn, 8, -38)
        btn.resaleLine:SetWidth(282)
        btn.resaleLine:SetWordWrap(false)
        btn.resaleLine:SetMaxLines(1)
        btn.resaleLine:SetTextColor(.8, .84, .9)
        btn.resaleLine:Hide()
        panel.results[i] = btn
    end
    panel.prev = button(panel, "<", 12, -216, 27, function() page = page-1; refresh() end)
    panel.next = button(panel, ">", 41, -216, 27, function() page = page+1; refresh() end)
    panel.refresh = button(panel, "REFRESH", 77, -216, 72, refresh)
    panel.prev.footerX, panel.next.footerX, panel.refresh.footerX = 12, 41, 77

    mini = window(UIParent)
    mini:SetSize(409, 170)
    suite.rememberMiniPosition(mini, db)
    mini:SetFrameStrata("DIALOG")
    mini:SetClampedToScreen(true)
    mini:SetMovable(true)
    mini:EnableMouse(true)
    mini:RegisterForDrag("LeftButton")
    mini:SetScript("OnDragStart", mini.StartMoving)
    mini:Hide()
    local miniTitle = label(mini, 13, -14)
    miniTitle:SetTextColor(1,.80,.40)
    miniTitle:SetText("Enchant It")
    mini.skill = label(mini, 13, -29)
    mini.skill:SetTextColor(.71, .77, .83)
    local version = label(mini, 0, 0)
    version:ClearAllPoints()
    version:SetPoint("BOTTOMLEFT", mini, "BOTTOMLEFT", 13, 9)
    version:SetTextColor(.65, .70, .77)
    version:SetText(versionText)
    local memorial = mini:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
    memorial:SetPoint("BOTTOM", mini, "BOTTOM", 0, 8)
    memorial:SetFont("Fonts\\MORPHEUS.TTF", 10, "")
    memorial:SetTextColor(.78, .64, .33)
    memorial:SetText("RIP Shady")
    mini.cheapest = checkbox(mini, "Cheapest", 126, -8, toggleCheapest)
    colorDropdown(mini, "miniColor", 207, -9)
    button(mini, "FULL", 294, -9, 58, function() db.mini = false; refresh() end)
    local function closeMini()
        if InCombatLockdown() then return end
        restore()
        if native and isEnchanting() then
            if HideUIPanel then HideUIPanel(native) else native:Hide() end
        end
        mini:Hide()
    end
    button(mini, "X", 363, -9, 32, closeMini)
    suite.escapeCloses(mini, closeMini)
    mini.recipe = label(mini, 46, -48)
    mini.recipe:SetWidth(315)
    mini.recipe:SetMaxLines(1)
    mini.prev = button(mini, "<", 12, -43, 27, function() index = index-1; refresh() end)
    mini.next = button(mini, ">", 368, -43, 27, function() index = index+1; refresh() end)
    mini.cost = label(mini, 46, -68)
    button(mini, "Find missing", 287, -67, 108, function()
        local entry = mini.current
        if not entry or entry.training then print("Profession AIO: Select a learned recipe."); return end
        local quantity = math.max(1, math.min(999, tonumber(mini.amount:GetText()) or 1))
        local _, message = suite.searchMissing(entry.id, quantity)
        print("Profession AIO: " .. message)
    end)
    mini.hint = label(mini, 13, -128)
    mini.hint:SetWidth(205)
    mini.hint:SetMaxLines(1)
    mini.countdown = label(mini, 0, 0)
    mini.countdown:ClearAllPoints()
    mini.countdown:SetPoint("TOPRIGHT", mini, "TOPRIGHT", -13, -128)
    mini.countdown:SetJustifyH("RIGHT")
    mini.countdown:SetTextColor(1, .82, .3)
    mini.amount = CreateFrame("EditBox", nil, mini, "InputBoxTemplate")
    mini.amount:SetPoint("TOPLEFT", 55, -91)
    mini.amount:SetSize(42, 25)
    mini.amount:SetAutoFocus(false)
    mini.amount:SetNumeric(true)
    mini.amount:SetMaxLetters(3)
    mini.amount:SetText("1")
    mini.amount:SetScript("OnTextChanged", updateAmount)
    mini.amount:SetScript("OnEscapePressed", function(self) self:ClearFocus() end)
    mini.amount:SetScript("OnEnterPressed", function(self) self:ClearFocus() end)
    local function adjust(delta)
        local n = tonumber(mini.amount:GetText()) or 1
        mini.amount:SetText(tostring(math.max(1, math.min(999, n+delta))))
    end
    mini.minus = button(mini, "-", 12, -93, 30, function() adjust(-1) end)
    mini.plus = button(mini, "+", 110, -93, 30, function() adjust(1) end)
    mini.max = button(mini, "MAX", 148, -93, 48, function()
        local limit = craftLimit(mini.current)
        if limit > 0 then mini.amount:SetText(tostring(limit)) end
    end)
    mini.craft = button(mini, "CRAFT", 209, -93, 186, function()
        local current = mini.current
        local amount = tonumber(mini.amount:GetText())
        if current and current.target and isEnchanting() and not InCombatLockdown() then
            pendingRecipe = current.id
            db.mini = false
            refresh()
        elseif amount and amount % 1 == 0 and amount >= 1 and amount <= craftLimit(current) then
            api("CraftRecipe", current.id, amount)
        end
    end)
    suite.bindRecipeTooltip(mini.craft, showTooltip, function() return mini.current end)

    suite.launcher("EnchantItMinimapButton", db, "Trade_Engraving", 245, openEnchanting)
end

suite.registerModule(function(event, arg)
    if event == "ADDON_LOADED" then
        if arg ~= name then return end
        EnchantItDB = type(EnchantItDB) == "table" and EnchantItDB or {}
        db = EnchantItDB
        if db.solid == nil then db.solid = true end
        EnchantItCharacterDB = type(EnchantItCharacterDB) == "table" and EnchantItCharacterDB or {}
        trainerOffers = type(EnchantItCharacterDB.trainerOffers) == "table" and EnchantItCharacterDB.trainerOffers or {}
        EnchantItCharacterDB.trainerOffers = trainerOffers
        build()
        schedule()
        suite.addPoll(function()
            local frame = ProfessionsFrame or TradeSkillFrame
            if frame and frame:IsShown() then
                if frame ~= native or (isEnchanting() ~= (controls:IsShown() or mini:IsShown())) then refresh()
                elseif controls:IsShown() then updateMainCountdown() end
            end
        end)
        SLASH_ENCHANTIT1, SLASH_ENCHANTIT2 = "/eci", "/enchantit"
        SlashCmdList.ENCHANTIT = function(msg)
            if InCombatLockdown() then return end
            if msg == "mini" then db.mini = true
            elseif msg == "full" or msg == "settings" then
                db.mini = false
                settingsOpen = msg == "settings"
            end
            openEnchanting()
            if msg ~= "settings" or isEnchanting() then refresh() end
        end
        return {"TRADE_SKILL_SHOW", "TRADE_SKILL_CLOSE", "TRADE_SKILL_DATA_SOURCE_CHANGED",
            "TRADE_SKILL_LIST_UPDATE", "SKILL_LINES_CHANGED", "BAG_UPDATE_DELAYED", "PLAYER_REGEN_DISABLED",
            "PLAYER_REGEN_ENABLED", "AUCTION_HOUSE_CLOSED", "PLAYER_LEAVING_WORLD", "PLAYER_ENTERING_WORLD", "TRAINER_SHOW", "TRAINER_UPDATE", "TRAINER_CLOSED", "GET_ITEM_INFO_RECEIVED"}
    end
    if event == "TRAINER_SHOW" then
        trainerOpen = true
        scanTrainer()
        C_Timer.After(.15, scanTrainer)
    elseif event == "TRAINER_UPDATE" then
        scanTrainer()
    elseif event == "TRAINER_CLOSED" then
        trainerOpen = false
    elseif event == "TRADE_SKILL_CLOSE" then
        settingsOpen = false
        restore()
        controls:Hide()
        panel:Hide()
        mini:Hide()
    elseif event == "TRADE_SKILL_DATA_SOURCE_CHANGED" or event == "PLAYER_REGEN_DISABLED" then
        refresh()
    end
    schedule()
end)
