local name, suite = ...
local api = suite.tradeSkillAPI
local bolts = {[2996]={2589,2}, [2997]={2592,3}, [4305]={4306,4}, [4339]={4338,5}, [14048]={14047,5}}
local day = 86400

function suite.newEstimates(settings)
    local ac = AuctionCompanionAPI
    local aa = Auctionator and Auctionator.API and Auctionator.API.v1
    local shady = ShadyPriceAPI
    local ledger = AHledgerAPI
    local sources = {
        ["Auction Companion"] = ac and ac.GetPriceByItemID,
        Auctionator = aa and aa.GetAuctionPriceByItemID,
        ["Shady Price Engine"] = shady and shady.GetMarketValue,
        AHledger = ledger and ledger.GetPrice,
    }
    local source = settings.provider or "Auto"
    if source == "Auto" then
        for _, candidate in ipairs({"Auction Companion","Shady Price Engine","Auctionator","AHledger"}) do
            if type(sources[candidate]) == "function" then source = candidate; break end
        end
    end
    local market, vendor = {}, {}
    local now = GetServerTime and GetServerTime() or time()
    local function quote(id)
        if market[id] then return unpack(market[id]) end
        local fn = sources[source]
        local ok, value, _, stamp
        if type(fn) == "function" then
            if source == "Auctionator" then ok, value = pcall(fn, name, id)
            else ok, value, _, stamp = pcall(fn, id) end
            if source == "AHledger" and type(value) == "table" then value = value.median end
        end
        if not ok or type(value) ~= "number" or value <= 0 or value >= math.huge then value = false end
        local quality = not value and "Missing"
            or (type(stamp) ~= "number" and "Undated")
            or ((stamp > now or now - stamp >= day) and "Stale")
            or "Dated"
        if quality == "Stale" then value = false end
        market[id] = {value, quality, stamp}
        return value, quality, stamp
    end

    local function material(id, amount)
        local price, quality, stamp = quote(id)
        local vendorEnabled = settings.vendor
        if vendorEnabled == nil and ac and ac.IsVendorPricingEnabled then
            local ok, enabled = pcall(ac.IsVendorPricingEnabled)
            vendorEnabled = ok and enabled
        end
        if vendorEnabled ~= false and ac and ac.GetVendorPrice then
            if vendor[id] == nil then vendor[id] = suite.auctionQuote(ac.GetVendorPrice, id) or false end
            if vendor[id] and (not price or vendor[id] < price) then return vendor[id] * amount, "Vendor" end
        end
        if source == "Shady Price Engine" and shady.GetBuyCost and quality ~= "Stale" then
            local ok, total = pcall(shady.GetBuyCost, id, amount)
            if ok and type(total) == "number" and total > 0 and total < math.huge then return total, "Undated" end
            return nil, "Missing"
        end
        if price then return price * amount, quality, stamp end
        return nil, quality
    end

    local function cost(materials)
        if not materials then return nil, "Unsupported reagents" end
        local total, oldest, undated, unknown = 0
        local requirements, directValues = {}, {}
        for id, quantity in pairs(materials) do
            local value, quality, stamp = material(id, quantity)
            if value then
                total = total + value
                directValues[id] = value
                if stamp then oldest = math.min(oldest or stamp, stamp) end
                undated = undated or quality == "Undated"
            elseif bolts[id] then
                local raw = bolts[id]
                requirements[raw[1]] = (requirements[raw[1]] or 0) + quantity * raw[2]
            else
                unknown = quality == "Stale" and "Stale material prices" or unknown or "Missing material prices"
            end
        end
        if unknown then return nil, unknown end
        for id, quantity in pairs(requirements) do
            local value, quality, stamp = material(id, quantity + (materials[id] or 0))
            if not value then return nil, quality .. " intermediate material prices" end
            total = total + value - (directValues[id] or 0)
            if stamp then oldest = math.min(oldest or stamp, stamp) end
            undated = undated or quality == "Undated"
        end
        return total, undated and "Undated quotes" or nil, oldest
    end

    local function estimate(id, info, enchanting)
        local schematic = api("GetRecipeSchematic", id, false)
        local materials = suite.fixedMaterials(schematic)
        local result = {id=id, name=info.name, icon=info.icon, difficulty=info.relativeDifficulty,
            materials=materials, single=info.canCreateMultiple == false, disabled=info.disabled,
            enchanting=enchanting, yields=schematic and math.max(1, tonumber(schematic.quantityMin) or 1) or 1, routes={}}
        result.cost, result.warning, result.oldest = cost(materials)
        local output = schematic and tonumber(schematic.outputItemID)
        result.output = output and output > 0 and output or nil
        result.variable = schematic and tonumber(schematic.quantityMax) and schematic.quantityMax > result.yields
        local requirements = api("GetRecipeRequirements", id)
        if type(requirements) == "table" then
            for _, requirement in ipairs(requirements) do
                if type(requirement) == "table" then
                    if requirement.met == false then result.blocked = true end
                    if not result.requirement and type(requirement.name) == "string" then
                        result.requirement = requirement.name
                    end
                end
            end
        end
        if not result.requirement and suite.TailorSwift.station(info.name, id) == "wheel" then
            result.requirement = "Spinning Wheel"
        end
        local cooldown = api("GetRecipeCooldown", id)
        result.cooldown = type(cooldown) == "number" and cooldown > 0
        if not result.output or enchanting then return result end
        local getInfo = C_Item and C_Item.GetItemInfo or GetItemInfo
        local item, link, quality, level, _, _, _, _, _, _, sell, class, subclass, bind = getInfo(result.output)
        local factor = settings.fees == false and 1 or .95
        local function route(label, value, net, freshness)
            local row = {name=label, value=value, profit=result.cost and net - result.cost or nil, warning=freshness}
            result.routes[label] = row
            if row.profit and (not result.best or row.profit > result.best.profit) then result.best = row end
        end
        local ah, freshness, stamp = quote(result.output)
        if ah and item and (bind == 0 or bind == 2) then
            route("Auction", ah*result.yields, math.floor(ah*result.yields*factor), freshness == "Undated" and freshness)
            if stamp then result.oldest = math.min(result.oldest or stamp, stamp) end
        elseif freshness == "Stale" then result.auctionWarning = "Stale" end
        if type(sell) == "number" and sell > 0 then route("Vendor", sell*result.yields, sell*result.yields) end
        if item and quality and level and class and suite.TailorSwift.disenchantValue then
            local uncertain
            local value = suite.TailorSwift.disenchantValue({itemID=result.output, link=link, quality=quality,
                baseItemLevel=level, classID=class, subClassID=subclass}, function(materialID)
                local price, age, when = quote(materialID)
                uncertain = uncertain or age == "Undated"
                if when and price then result.oldest = math.min(result.oldest or when, when) end
                return price or nil
            end)
            if value then
                route("Disenchant", value*result.yields, math.floor(value*result.yields*factor), uncertain and "Undated")
            end
        end
        return result
    end
    return estimate, source, material
end

function suite.craftAvailability(entry, quantity)
    if not entry.materials then return end
    local count, missing = math.huge, 0
    for id, amount in pairs(entry.materials) do
        local owned = suite.inBags(id)
        count = math.min(count, math.floor(owned / amount))
        missing = missing + math.max(0, quantity * amount - owned)
    end
    if entry.cooldown or entry.blocked or entry.disabled then return 0, missing end
    if entry.single or (entry.enchanting and not entry.output) then count = math.min(count, 1) end
    if not entry.enchanting or entry.output then
        local nativeCount = api("GetCraftableCount", entry.id)
        if type(nativeCount) == "number" then count = math.min(count, math.max(0, math.floor(nativeCount))) end
    end
    return count < math.huge and count or nil, missing
end

function suite.missingEstimate(entry, quantity, material)
    if not entry.materials then return end
    local total, missing = 0, {}
    for id, amount in pairs(entry.materials) do
        local need = amount * quantity - suite.inBags(id)
        if need > 0 then missing[id] = need end
    end
    for id, amount in pairs(missing) do
        local value = material(id, amount)
        if not value then return end
        total = total + value
    end
    return total
end
