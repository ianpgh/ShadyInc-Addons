local name, suite = ...
local addon = suite.CookItBookIt
local COOKING = 185
local db, controls, panel, mini, nearby, mainCountdown
local settingsOpen = false
local native, hookFrame
local pending, profitView
local rows, page, index = {}, 1, 1
local trainerOpen
local trainable = {}

local function scanTrainer()
    if not trainerOpen or not GetNumTrainerServices or not GetTrainerServiceInfo then return end
    local count = GetNumTrainerServices()
    if type(count) ~= "number" or count == 0 then return end
    local trainer = UnitName and UnitName("npc")
    local map = C_Map and C_Map.GetBestMapForUnit and C_Map.GetBestMapForUnit("player")
    local position = map and C_Map.GetPlayerMapPosition and C_Map.GetPlayerMapPosition(map, "player")
    local waypoint
    if position and trainer then
        local x, y = position:GetXY()
        if x and y then waypoint = {map, x, y, trainer} end
    end
    for i = 1, count do
        local service, _, status = GetTrainerServiceInfo(i)
        if service and status == "available" then
            local cost = GetTrainerServiceCost and GetTrainerServiceCost(i)
            trainable[service] = {cost=type(cost) == "number" and cost or nil,
                trainer=trainer, waypoint=waypoint}
        elseif service and (status == "used" or status == "unavailable") then
            trainable[service] = nil
        end
    end
end
local COLOR = {.055,.082,.108,.98}
local api = suite.tradeSkillAPI

local function cookingInfo(info)
    return suite.matchesProfession(info, COOKING, Enum and Enum.Profession and Enum.Profession.Cooking or 5, "Cooking")
end

local function isCooking()
    return suite.isProfession(native, COOKING, Enum and Enum.Profession and Enum.Profession.Cooking or 5, "Cooking")
end

local function window(parent) return suite.window(parent, COLOR) end
local label, button, itemName = suite.label, suite.button, suite.itemName

local function materials(id, schematic)
    schematic = schematic or api("GetRecipeSchematic", id, false)
    local slots = schematic and schematic.reagentSlotSchematics
    if type(slots) ~= "table" or #slots == 0 then return end
    local result, seen = {}, {}
    for _, slot in ipairs(slots) do
        local reagent = slot.reagents and #slot.reagents == 1 and slot.reagents[1]
        local itemID = reagent and reagent.itemID
        local amount = slot.quantityRequired
        if not itemID or type(amount) ~= "number" or amount < 1 then return end
        if seen[itemID] then seen[itemID][2] = seen[itemID][2] + amount
        else
            local row = {itemID, amount}
            seen[itemID] = row
            result[#result+1] = row
        end
    end
    return result
end

local function restore() suite.restoreNative(addon) end
local function hideNative() return suite.hideNative(addon, native) end

local function openCooking()
    if InCombatLockdown() then return end
    if isCooking() and native and native:IsShown() then return end
    api("OpenTradeSkill", COOKING)
end

local function craftLimit(entry)
    if not entry or not isCooking() or InCombatLockdown() then return 0 end
    local info = api("GetRecipeInfo", entry.id)
    if not info or not info.learned or info.name ~= entry.name then return 0 end
    for _, req in ipairs(api("GetRecipeRequirements", entry.id) or {}) do
        if req.met == false then return 0 end
    end
    local count = 999
    for _, row in ipairs(entry.materials) do
        local bag = C_Item and C_Item.GetItemCount and C_Item.GetItemCount(row[1], false, false, false)
            or (GetItemCount and GetItemCount(row[1], false, false)) or 0
        count = math.min(count, math.floor(bag / row[2]))
    end
    local nativeCount = api("GetCraftableCount", entry.id)
    if type(nativeCount) == "number" then count = math.min(count, nativeCount) end
    return math.max(0, count)
end

local refresh
local function cookingSkillInfo()
    local skill = C_SkillInfo and C_SkillInfo.GetSkillLineInfoByID and C_SkillInfo.GetSkillLineInfoByID(COOKING)
    if skill and tonumber(skill.rank) and skill.rank > 0 then
        return {skillLevel=skill.rank, maxSkillLevel=skill.maxRank}
    end
    local profession = api("GetBaseProfessionInfo")
    if not cookingInfo(profession) or not tonumber(profession.skillLevel) then
        profession = api("GetChildProfessionInfo")
    end
    if cookingInfo(profession) then return profession end
end

local learningWaypoint

local function showTooltip(self)
    local entry = self.entry
    if not entry then return end
    GameTooltip:SetOwner(self, "ANCHOR_RIGHT")
    GameTooltip:SetText(addon.coloredRecipeName(entry.name, entry.difficulty))
    for i, reagent in ipairs(entry.materials) do
        local id, amount = unpack(reagent)
        local value = entry.prices and addon.money(entry.prices[i]) .. " each" or ""
        GameTooltip:AddDoubleLine(("%d × %s"):format(amount, itemName(id)), value)
    end
    if entry.craftCost then
        GameTooltip:AddDoubleLine("Cost per craft", addon.money(entry.craftCost))
    end
    local skill = cookingSkillInfo()
    local rank = entry.requiredSkill or (skill and tonumber(skill.skillLevel))
    local live = api("GetRecipeInfo", entry.id)
    local difficulty = live and live.learned and live.relativeDifficulty or entry.difficulty
    local remaining, nextColor, threshold = addon.nextRecipeColor(entry.name, rank, difficulty)
    if remaining then
        local label = entry.requiredSkill and "Next color after learning" or "Next color"
        GameTooltip:AddDoubleLine(label, ("%s at %d (%d skill %s)"):format(nextColor, threshold, remaining,
            remaining == 1 and "point" or "points"))
        if nextColor == "Gray" then GameTooltip:AddLine("Gray recipes give no skill points.", .68, .72, .77) end
    end
    local training = entry.training
    if training then
        local destination = learningWaypoint(entry)
        if training.vendor then
            GameTooltip:AddDoubleLine("Recipe vendor", (destination and destination[4]) or training.vendor)
        end
        if training.trainer or not (training.vendor or training.quest) then
            GameTooltip:AddDoubleLine("Trainer", training.trainer or (destination and destination[4]) or "Cooking trainer")
        end
        if training.item and training.item > 0 then
            local item = GetItemInfo and GetItemInfo(training.item)
            if item then GameTooltip:AddDoubleLine("Recipe item", item) end
        end
        if training.favor then GameTooltip:AddDoubleLine("Merchant's Favor", tostring(training.favor)) end
        if training.quest then GameTooltip:AddLine(training.quest, 1, 1, 1, true) end
    end
    if entry.trainingCost then GameTooltip:AddDoubleLine("Training fee", addon.money(entry.trainingCost)) end
    if training then
        local destination = learningWaypoint(entry)
        if destination then GameTooltip:AddLine("Click to open map and pin " .. destination[4], .6, .85, 1, true) end
    end
    GameTooltip:Show()
end

-- Recipe spell IDs, minimum Cooking skill, and base fees from the
-- Forever Cooking catalog in What's Training? 11.4.9.
local trainerRecipes = {
    [2539]={10, 50}, [1229737]={20, 100}, [2541]={50, 100},
    [6499]={50, 100}, [2544]={75, 200}, [2546]={80, 150},
    [6500]={125, 300}, [4094]={175, 500}, [13028]={175},
    [21175]={200, 4000},
}

local recipeSources = {
    [4094] = {
        vendor="Recipe vendor",
        quest="Quest: Barbecued Buzzard Wings (Rigglefuzz, Badlands).",
    },
    [13028] = {trainer="Henry Stern (Razorfen Downs)"},
}

local allianceTrainer = {1426, .684, .545, "Cook Ghilm (Dun Morogh)"}
local hordeTrainer = {1411, .5115, .4245, "Cook Torka (Durotar)"}
local recipeWaypoints = {
    [1247741] = {Horde={1454, .575, .537, "Zamja (Orgrimmar)"}},
    [1250158] = {Horde={1447, .698, .844, "Spitelash Enchantress (Azshara)"}},
    [24801] = {Horde={1451, .379, .453, "Sandy Cookbook (Silithus)"}},
    [1295805] = {Neutral={2548, .790, .542, "Fimbo Greasemitz (Riverglades)"}},
    [4094] = {
        Alliance={1417, .450, .460, "Narj Deepslice (Arathi Highlands)"},
        Horde={1443, .400, .790, "Super-Seller 680 route (Desolace)"},
    },
    [13028] = {
        Alliance={1413, .490, .949, "Razorfen Downs entrance (The Barrens)"},
        Horde={1413, .490, .949, "Razorfen Downs entrance (The Barrens)"},
    },
}

learningWaypoint = function(entry)
    if entry.training and entry.training.waypoint then return entry.training.waypoint end
    local faction = UnitFactionGroup and UnitFactionGroup("player")
    local vendor = addon.seafoodVendor(entry.id, faction)
    if vendor then return vendor end
    local sources = recipeWaypoints[entry.id]
    if sources then return sources[faction] or sources.Neutral end
    if trainerRecipes[entry.id] then
        if faction == "Alliance" then return allianceTrainer end
        if faction == "Horde" then return hordeTrainer end
    end
end

local function setLearningWaypoint(entry)
    local destination = learningWaypoint(entry)
    if not destination then
        print("Cook It, Book It: No mapped source for " .. entry.name .. ".")
        return
    end
    suite.openLearningMap(destination, "Cook It, Book It", entry.name)
end

local function addCatalogRecipes(recipes, infoByID, offers, upcoming)
    local profession = cookingSkillInfo()
    local rank = profession and tonumber(profession.skillLevel)
    if not rank then return end
    local spellBook = C_SpellBook and C_SpellBook.IsSpellKnown
    local bank = Enum and Enum.SpellBookSpellBank and Enum.SpellBookSpellBank.Player
    for id, requirements in pairs(trainerRecipes) do
        if (rank < requirements[1]) == upcoming then
            local info = api("GetRecipeInfo", id)
            local spell = C_Spell and C_Spell.GetSpellInfo and C_Spell.GetSpellInfo(id)
            if not spell and C_Spell and C_Spell.RequestLoadSpellData then C_Spell.RequestLoadSpellData(id) end
            local recipe = info and info.name or (spell and spell.name)
                or (C_Spell and C_Spell.GetSpellName and C_Spell.GetSpellName(id))
            local known = (info and info.learned) or (spellBook and bank and spellBook(id, bank))
            if recipe and not known and (info or (spellBook and bank)) and not recipes[recipe] then
                recipes[recipe] = id
                infoByID[id] = info or {name=recipe, learned=false}
                local source = recipeSources[id] or {}
                local scanned = offers[recipe] or {}
                offers[recipe] = {
                    cost=scanned.cost or requirements[2],
                    requiredSkill=upcoming and requirements[1] or nil,
                    trainer=scanned.trainer or source.trainer,
                    waypoint=scanned.waypoint,
                    vendor=source.vendor,
                    quest=source.quest,
                }
            end
        end
    end
end

local function acquisitionAreas(locations, faction, isQuest)
    if not locations then return end
    if #locations == 0 then return "Check recipe source" end
    local areas, seen = {}, {}
    local level = UnitLevel and UnitLevel("player")
    local eligible = false
    for _, location in ipairs(locations) do
        local area, minimumLevel, side = unpack(location)
        if (not side or side == faction) and (not isQuest or not level or level >= minimumLevel) then
            eligible = true
            if not seen[area] and #areas < 3 and C_Map and C_Map.GetAreaInfo and area > 0 then
                local areaName = C_Map.GetAreaInfo(area)
                if type(areaName) == "string" and areaName ~= "" then
                    areas[#areas+1] = areaName
                    seen[area] = true
                end
            end
        end
    end
    if eligible then return #areas > 0 and table.concat(areas, ", ") or "Check recipe source" end
end

-- Named vendors checked against the Forever catalog and recipe listings.
local auditedVendors = {
    [7755] = {Horde="Derak Nightfall (Hillsbrad) or Naal Mistrunner (Thunder Bluff)"},
    [25704] = {Horde="Derak Nightfall (Hillsbrad)"},
    [3376] = {Horde="Keena (Arathi Highlands)", Alliance="Kendor Kabonka (Stormwind)"},
    [15853] = {Horde="Super-Seller 680 (Desolace)", Alliance="Super-Seller 680 (Desolace)"},
    [3398] = {Horde="Zargh (The Barrens) or Vendor-Tron 1000 (Desolace)", Alliance="Vendor-Tron 1000 (Desolace)"},
}

local function addAcquisitionRecipes(recipes, infoByID, offers, rank, upcoming)
    local faction = UnitFactionGroup and UnitFactionGroup("player")
    local spellBook = C_SpellBook and C_SpellBook.IsSpellKnown
    local bank = Enum and Enum.SpellBookSpellBank and Enum.SpellBookSpellBank.Player
    for id, source in pairs(addon.cookingAcquisitions) do
        if (rank < source.skill) == upcoming and (not source.faction or source.faction == faction) then
            local info = api("GetRecipeInfo", id)
            if not ((info and info.learned) or (spellBook and bank and spellBook(id, bank))) then
                local recipe = info and info.name or (C_Spell and C_Spell.GetSpellName and C_Spell.GetSpellName(id))
                if recipe and (info or (spellBook and bank)) then
                    local vendor = acquisitionAreas(source.vendors, faction, false)
                    local quest = acquisitionAreas(source.quests, faction, true)
                    if vendor or quest then
                        local offer = offers[recipe] or {requiredSkill=upcoming and source.skill or nil}
                        local named = auditedVendors[id]
                        local mapped = addon.seafoodVendor(id, faction)
                        offer.vendor = offer.vendor or (mapped and mapped[4]) or (vendor and named and named[faction]) or vendor
                        offer.quest = offer.quest or (quest and ("Quest source: " .. quest))
                        offer.item, offer.favor = source.item, source.favor
                        offers[recipe] = offer
                        recipes[recipe] = recipes[recipe] or id
                        infoByID[id] = info or {name=recipe, learned=false}
                    end
                elseif C_Spell and C_Spell.RequestLoadSpellData then
                    C_Spell.RequestLoadSpellData(id)
                end
            end
        end
    end
end

local function pickRecipes(color)
    local upcoming = color == "Upcoming"
    local trainingMode = upcoming or color == "Trainable"
    local skill = trainingMode and cookingSkillInfo()
    local rank = skill and tonumber(skill.skillLevel)
    if trainingMode and not rank then
        return {}, 0
    end
    local ids = api("GetAllRecipeIDs")
    if type(ids) ~= "table" or #ids == 0 then ids = api("GetFilteredRecipeIDs") or {} end
    local learned, infoByID = {}, {}
    for _, id in ipairs(ids) do
        local info = api("GetRecipeInfo", id)
        if info and info.name and not info.isDummyRecipe and not info.isRecraft
            and (info.learned or (color == "Trainable" and trainable[info.name])) then
            learned[info.name] = id
            infoByID[id] = info
        end
    end
    if db.showCheapest then
        local offers
        if trainingMode then
            offers = {}
            if not upcoming then
                for recipe, offer in pairs(trainable) do offers[recipe] = offer end
            end
            addCatalogRecipes(learned, infoByID, offers, upcoming)
            addAcquisitionRecipes(learned, infoByID, offers, rank, upcoming)
            for recipe, id in pairs(learned) do
                local offer = offers[recipe]
                if offer then
                    local difficulty = addon.recipeDifficulty(recipe, offer.requiredSkill or rank, infoByID[id].relativeDifficulty)
                    if upcoming or difficulty == 0 or difficulty == 1 then
                        offer.difficulty = difficulty
                    else
                        offers[recipe] = nil
                    end
                end
            end
        end
        return addon.rankRecipes(learned, function(id) return infoByID[id] end, materials, color, offers)
    end
    local options = {}
    for recipe,id in pairs(learned) do
        local reagents = materials(id)
        local difficulty = infoByID[id].relativeDifficulty
        if reagents and addon.matchesColor(difficulty, color) then
            options[#options+1] = {name=recipe, id=id, materials=reagents,
                rank=type(difficulty) == "number" and difficulty or 4}
        end
    end
    table.sort(options, function(a,b)
        if a.rank ~= b.rank then return a.rank < b.rank end
        return a.name < b.name
    end)
    return options, 0
end

local function recipeCountdown(recipe)
    if not recipe or not recipe.learned then return "" end
    local profession = cookingSkillInfo()
    if not profession then return "" end
    return addon.colorCountdown(recipe.name, tonumber(profession.skillLevel), recipe.relativeDifficulty)
end

local function updateMainCountdown()
    local crafting = native and native.CraftingPage
    local form = crafting and crafting.SchematicForm
    if not controls:IsShown() or not form or not form:IsVisible() or not form.GetRecipeInfo then
        mainCountdown:Hide()
        return
    end
    local selected = form:GetRecipeInfo()
    local recipe = selected and selected.recipeID and api("GetRecipeInfo", selected.recipeID) or selected
    local text = recipeCountdown(recipe)
    if text == "" then mainCountdown:Hide(); return end
    -- Keep the skill-up countdown above the recipe header, away from native cooldowns.
    if mainCountdown.anchor ~= form then
        mainCountdown:ClearAllPoints()
        mainCountdown:SetPoint("TOP", form, "TOP", 0, -8)
        mainCountdown.anchor = form
    end
    mainCountdown:SetText(text)
    mainCountdown:Show()
end

local function updateAmount()
    local info = cookingSkillInfo()
    local skill = info and tonumber(info.skillLevel)
    local cap = info and tonumber(info.maxSkillLevel)
    local text = ""
    if skill then
        text = cap and ("Cooking %d / %d"):format(skill, cap) or ("Cooking %d"):format(skill)
    end
    mini.skill:SetText(text)
    local limit = craftLimit(mini.current)
    local qty = tonumber(mini.amount:GetText())
    mini.craft:SetText(qty and qty > 0 and "CRAFT " .. qty or "CRAFT")
    mini.craft:SetEnabled(qty ~= nil and qty >= 1 and qty % 1 == 0 and qty <= limit)
    mini.max:SetEnabled(limit > 0)
    local recipe = mini.current and isCooking() and api("GetRecipeInfo", mini.current.id)
    local countdown = recipeCountdown(recipe)
    mini.countdown:SetText(countdown)
    mini.hint:SetText((limit > 0 or countdown ~= "") and (limit .. " craftable")
        or (mini.current and "Check materials or cooking station." or ""))
end

local function setRankedResults(results, missing, color)
    local recipeGroup = color == "All" and "Skill-up" or color
    rows = results
    local count = #rows
    index = math.max(1, math.min(index, count))
    local pages = math.max(1, math.ceil(count / #panel.results))
    page = math.max(1, math.min(page, pages))
    local note
    local info = api("GetBaseProfessionInfo")
    local trainingMode = color == "Trainable" or color == "Upcoming"
    if not addon.hasCraftPricing() and not trainingMode then note = "Enable Auction Companion to show prices."
    elseif not trainingMode and info and info.skillLevel and info.maxSkillLevel and info.skillLevel >= info.maxSkillLevel then
        note = info.skillLevel >= 300 and "Cooking 300 reached." or "Train the next Cooking rank."
        rows, count, pages, page, index = {}, 0, 1, 1, 1
    elseif color == "Trainable" then
        local skill = cookingSkillInfo()
        local rank = skill and tonumber(skill.skillLevel)
        local cap = skill and tonumber(skill.maxSkillLevel)
        if not rank then note = "Open Cooking to check your skill."
        elseif count > 0 and (rank >= 300 or (cap and rank >= cap)) then note = "At skill cap • Click a recipe for its source"
        elseif count == 0 then note = "No unlearned orange or yellow recipes now."
        else note = "Orange / yellow skill-ups • Cost / craft" end
    elseif color == "Upcoming" then
        note = count > 0 and "Upcoming recipes • Required Cooking skill"
            or "No upcoming trainer recipes found."
    elseif count == 0 then
        note = missing > 0 and addon.pricingHint() or ("No learned %s recipes."):format(recipeGroup:lower())
    else note = ("%s recipes • Last scan cost / craft%s"):format(recipeGroup, missing > 0 and (" • " .. missing .. " unpriced") or "") end
    panel.note:SetText(note)
    for i, btn in ipairs(panel.results) do
        local entry = rows[(page-1)*#panel.results+i]
        btn.entry = entry
        btn:SetShown(db.showCheapest and entry ~= nil)
        if entry then
            local cost = entry.craftCost and addon.money(entry.craftCost) or "No price"
            local requirement = entry.requiredSkill and ("  •  Skill %d"):format(entry.requiredSkill) or ""
            btn:SetText(addon.coloredRecipeName(entry.name, entry.difficulty) .. requirement .. "  •  " .. cost)
        end
    end
    panel.prev:SetShown(db.showCheapest and page > 1)
    panel.next:SetShown(db.showCheapest and page < pages)
    panel.refresh:SetShown(db.showCheapest)
    panel.note:SetShown(db.showCheapest)
    panel:SetHeight(db.showCheapest and 245 or 86)

    local entry = rows[index]
    mini.current = entry
    mini.recipe:SetText(entry and entry.name or (db.showCheapest and note or ("No learned %s recipes."):format(recipeGroup:lower())))
    mini.cost:SetText(entry and (entry.craftCost and ("~" .. addon.money(entry.craftCost) .. " / craft") or (index .. " / " .. count)) or "")
    mini.prev:SetEnabled(index > 1)
    mini.next:SetEnabled(index < count)
    updateAmount()
end

refresh = function()
    native = ProfessionsFrame or TradeSkillFrame
    local visibleCooking = native and native:IsShown() and isCooking()
    if native and hookFrame ~= native then
        hookFrame = native
        controls:SetParent(native)
        controls:ClearAllPoints()
        controls:SetPoint("TOPRIGHT", native, "TOPRIGHT", -40, -5)
        controls.profit:ClearAllPoints()
        controls.profit:SetPoint("TOPLEFT", native, "TOPLEFT", 15, -48)
        controls:SetFrameStrata("DIALOG")
        controls:SetFrameLevel(native:GetFrameLevel()+100)
        panel:SetFrameStrata("DIALOG")
        panel:SetFrameLevel(controls:GetFrameLevel()+5)
        profitView:SetFrameLevel(controls:GetFrameLevel()+6)
        local attached = native
        native:HookScript("OnHide", function()
            if hookFrame ~= attached then return end
            settingsOpen = false
            profitView:Hide()
            controls:Hide()
            mainCountdown:Hide()
            restore()
            mini:Hide()
            panel:Hide()
        end)
        native:HookScript("OnShow", function() C_Timer.After(0, refresh) end)
    end
    if not visibleCooking then
        if native and native:IsShown() and not api("IsDataSourceChanging") then settingsOpen = false end
        profitView:Hide()
        controls:Hide()
        mainCountdown:Hide()
        restore()
        mini:Hide()
        panel:Hide()
        return
    end
    local compact = db.mini and not InCombatLockdown() and hideNative()
    if not compact then restore() end
    if compact or InCombatLockdown() then profitView:Hide() end
    if compact then settingsOpen = false end
    controls:SetShown(not compact)
    panel:SetShown(not compact and settingsOpen)
    mini:SetShown(compact == true)
    local color = (compact and db.miniColor or not compact and db.mainColor) or "Orange"
    if compact or (settingsOpen and db.showCheapest) then
        local results, missing = pickRecipes(color)
        setRankedResults(results, missing, color)
    else setRankedResults({}, 0, color) end
    panel.proximity:SetChecked(db.proximity)
    panel.cheapest:SetChecked(db.showCheapest)
    mini.cheapest:SetChecked(db.showCheapest)
    updateMainCountdown()
    if profitView:IsShown() then profitView:UpdateCounts() end
end

local function schedule()
    if pending then return end
    pending = true
    C_Timer.After(.12, function() pending = false; refresh() end)
end

local nearbySince
local cookingFireRecipes = {2538, 6499, 7751} -- Charred Wolf Meat, Boiled Clams, Brilliant Smallfish
local nearbyResumeAt = 0

local function resetNearby()
    nearbySince = nil
    nearby:Hide()
end

local function currentArea(subzone)
    local zone = GetRealZoneText and GetRealZoneText()
    if not zone or zone == "" then return end
    if subzone then
        local area = GetSubZoneText and GetSubZoneText()
        if not area or area == "" or area == zone then return end
        return zone .. " — " .. area
    end
    return zone
end

local SPOT_RADIUS = 12
local function playerSpot()
    if not UnitPosition then return end
    local x, y, z, map = UnitPosition("player")
    for _, value in ipairs({x, y, z, map}) do
        if issecretvalue and issecretvalue(value) then return end
    end
    if type(x) == "number" and type(y) == "number" and type(z) == "number" and type(map) == "number" then
        return x, y, z, map
    end
end

local function insideSpot(exceptions)
    local x, y, z, map = playerSpot()
    if not map then return false end
    for _, spot in pairs(exceptions) do
        if type(spot) == "table" and spot.map == map
            and (x-spot.x)^2 + (y-spot.y)^2 + (z-spot.z)^2 <= SPOT_RADIUS^2 then return true end
    end
    return false
end

local function proximityExcluded()
    local exceptions = db.proximityExceptions
    if type(exceptions) ~= "table" then return false end
    return exceptions[currentArea(false)] == true or exceptions[currentArea(true)] == true or insideSpot(exceptions)
end

local function saveCurrentSpot()
    local x, y, z, map = playerSpot()
    if not map then
        print("Cook It, Book It: Location unavailable here.")
        return false
    end
    if type(db.proximityExceptions) ~= "table" then db.proximityExceptions = {} end
    if insideSpot(db.proximityExceptions) then return true end
    local area = currentArea(true) or currentArea(false) or "Cooking"
    local id = 1
    while db.proximityExceptions[area .. " · Spot " .. id] do id = id+1 end
    db.proximityExceptions[area .. " · Spot " .. id] = {map=map, x=x, y=y, z=z}
    return true
end

local function updateNearby()
    if not nearby then return end
    local now = GetTime()
    if now < nearbyResumeAt or not db.proximity or InCombatLockdown() or proximityExcluded()
        or (native and native:IsShown() and isCooking()) then
        resetNearby()
        return
    end
    local title
    local focus = Enum and Enum.RecipeRequirementType and Enum.RecipeRequirementType.SpellFocus or 0
    for _, recipeID in ipairs(cookingFireRecipes) do
        for _, req in ipairs(api("GetRecipeRequirements", recipeID) or {}) do
            if req.type == focus and req.met == true then title = "Cooking Fire"; break end
        end
        if title then break end
    end
    if not title then
        local function hasAura(aura)
            if C_UnitAuras and C_UnitAuras.GetAuraDataBySpellName
                and C_UnitAuras.GetAuraDataBySpellName("player", aura, "HELPFUL") then return true end
            return AuraUtil and AuraUtil.FindAuraByName and AuraUtil.FindAuraByName(aura, "player", "HELPFUL")
        end
        if hasAura("Cozy Fire") then title = "Cooking Fire" end
    end
    if not title then
        resetNearby()
        return
    end
    nearbySince = nearbySince or now
    if now - nearbySince >= 1 then
        nearby:SetText(title .. " • Cook")
        nearby:Show()
    end
end

local ticker
local function proximity()
    if ticker then ticker:Cancel(); ticker = nil end
    if db.proximity then ticker = C_Timer.NewTicker(.5, updateNearby) end
    updateNearby()
end

local function buildExceptions(parent)
    local list = window(parent)
    list:SetSize(322, 250)
    list:SetPoint("TOPRIGHT", parent, "BOTTOMRIGHT", 0, -4)
    list:SetClampedToScreen(true)
    list:SetFrameLevel(parent:GetFrameLevel()+10)
    list:EnableMouse(true)
    list:Hide()
    parent:HookScript("OnHide", function() list:Hide() end)
    label(list, 13, -13):SetText("Cooking Proximity Exceptions")
    button(list, "X", 283, -8, 26, function() list:Hide() end)
    local hint = label(list, 13, -88)
    hint:SetText("Click a saved area to remove it.")
    local scroll = CreateFrame("ScrollFrame", nil, list, "UIPanelScrollFrameTemplate")
    scroll:SetPoint("TOPLEFT", 11, -108)
    scroll:SetPoint("BOTTOMRIGHT", -30, 13)
    local content = CreateFrame("Frame", nil, scroll)
    content:SetSize(279, 1)
    scroll:SetScrollChild(content)
    local rows = {}
    local refreshList

    local function add(subzone)
        local area = currentArea(subzone)
        if not area then return end
        if type(db.proximityExceptions) ~= "table" then db.proximityExceptions = {} end
        db.proximityExceptions[area] = true
        updateNearby()
        refreshList()
    end

    local zoneButton = button(list, "Add current zone", 12, -34, 143, function() add(false) end)
    local subzoneButton = button(list, "Add current subzone", 159, -34, 151, function() add(true) end)
    button(list, "Ignore this spot (12 yd)", 12, -59, 298, function()
        if saveCurrentSpot() then updateNearby(); refreshList() end
    end)
    refreshList = function()
        local areas = {}
        for area, enabled in pairs(type(db.proximityExceptions) == "table" and db.proximityExceptions or {}) do
            if (enabled == true or type(enabled) == "table") and type(area) == "string" then areas[#areas+1] = area end
        end
        table.sort(areas)
        zoneButton:SetEnabled(currentArea(false) ~= nil)
        subzoneButton:SetEnabled(currentArea(true) ~= nil)
        hint:SetText(#areas > 0 and "Click a saved area to remove it." or "No exceptions saved.")
        for i, area in ipairs(areas) do
            local row = rows[i]
            if not row then
                row = button(content, "", 0, -(i-1)*23, 279, function(self)
                    db.proximityExceptions[self.area] = nil
                    updateNearby()
                    refreshList()
                end)
                row:GetFontString():SetWordWrap(false)
                rows[i] = row
            end
            row.area = area
            row:SetText(area)
            row:Show()
        end
        for i = #areas+1, #rows do rows[i]:Hide() end
        content:SetHeight(math.max(1, #areas*23))
        scroll:SetVerticalScroll(math.min(scroll:GetVerticalScroll(), scroll:GetVerticalScrollRange()))
    end
    list:SetScript("OnShow", refreshList)
    local zoneEvents = CreateFrame("Frame", nil, list)
    zoneEvents:RegisterEvent("ZONE_CHANGED")
    zoneEvents:RegisterEvent("ZONE_CHANGED_INDOORS")
    zoneEvents:RegisterEvent("ZONE_CHANGED_NEW_AREA")
    zoneEvents:SetScript("OnEvent", function()
        updateNearby()
        if list:IsVisible() then refreshList() end
    end)
    return list
end

local function checkbox(parent, caption, x, y, handler)
    local check = CreateFrame("CheckButton", nil, parent, "UICheckButtonTemplate")
    check:SetPoint("TOPLEFT", x, y)
    check:SetSize(23,23)
    label(parent, x+24, y-5):SetText(caption)
    check:SetScript("OnClick", handler)
    return check
end

local function toggleCheapest(self)
    db.showCheapest = self:GetChecked() == true
    page, index = 1, 1
    refresh()
end

local function colorDropdown(parent, key, x, y)
    local colorMenu
    local colorButton = button(parent, (db[key] or "Orange") .. " v", x, y, 78, function()
        colorMenu:SetShown(not colorMenu:IsShown())
    end)
    colorMenu = window(parent)
    colorMenu:SetSize(88, key == "mainColor" and 144 or 100)
    colorMenu:SetPoint("TOPLEFT", colorButton, "BOTTOMLEFT", -5, -2)
    colorMenu:SetFrameLevel(parent:GetFrameLevel()+10)
    colorMenu:EnableMouse(true)
    colorMenu:Hide()
    local colors = {"Orange", "Yellow", "Green", "All"}
    if key == "mainColor" then
        colors[#colors+1] = "Trainable"
        colors[#colors+1] = "Upcoming"
    end
    for i, color in ipairs(colors) do
        button(colorMenu, color, 6, -6-(i-1)*22, 76, function()
            db[key] = color
            page, index = 1, 1
            colorButton:SetText(color .. " v")
            colorMenu:Hide()
            refresh()
        end)
    end
    parent:HookScript("OnHide", function() colorMenu:Hide() end)
end

local function showProfitRecipeSource(entry)
    local destination = entry.id and learningWaypoint(entry)
    local acquisition = entry.id and addon.cookingAcquisitions[entry.id]
    local generic = entry.source and (entry.source:match("^Horde or neutral") or entry.source == "Horde-accessible quest")
    if destination then
        GameTooltip:AddLine(("%s (%.1f, %.1f)"):format(destination[4], destination[2] * 100,
            destination[3] * 100), .82, .88, .94, true)
    end
    if generic and acquisition then
        local vendor = acquisitionAreas(acquisition.vendors, "Horde", false)
        local quest = acquisitionAreas(acquisition.quests, "Horde", false)
        if vendor and not destination then GameTooltip:AddLine("Vendor areas: " .. vendor, 1, 1, 1, true) end
        if quest then GameTooltip:AddLine("Quest areas: " .. quest, 1, 1, 1, true) end
        if not (destination or vendor or quest) then GameTooltip:AddLine(entry.source, 1, 1, 1, true) end
    elseif entry.source then
        GameTooltip:AddLine(entry.source, 1, 1, 1, true)
    end
    if entry.recipeItem then GameTooltip:AddDoubleLine("Recipe item", itemName(entry.recipeItem)) end
    if destination then GameTooltip:AddLine("Click to pin the source", .6, .85, 1) end
end

local function buildProfitView()
    controls.profit = button(controls, "Profitable", 0, 0, 92, function()
        if not isCooking() or InCombatLockdown() then return end
        profitView:SetShown(not profitView:IsShown())
    end)

    profitView = window(controls)
    profitView:SetBackdropColor(.055, .082, .108, 1)
    profitView:SetPoint("TOPLEFT", controls.profit, "BOTTOMLEFT", 0, -12)
    profitView:SetSize(318, 369)
    profitView:SetFrameLevel(controls:GetFrameLevel() + 6)
    profitView:EnableMouse(true)
    profitView:Hide()

    local title = label(profitView, 12, -12)
    title:SetText("Est. AH profit per craft")
    title:SetTextColor(1, .82, .3)
    button(profitView, "X", 282, -7, 24, function() profitView:Hide() end)

    local currentPage, results = 1, {}
    local note = label(profitView, 12, -49)
    local recipeRows = {}
    local draw
    local unlearned
    local craftable = checkbox(profitView, "Craftable Now", 9, -25, function(self)
        currentPage = 1
        if self:GetChecked() and unlearned:GetChecked() then
            unlearned:SetChecked(false)
            profitView:Refresh()
        else draw() end
    end)
    unlearned = checkbox(profitView, "Unlearned", 151, -25, function(self)
        currentPage = 1
        if self:GetChecked() then craftable:SetChecked(false) end
        profitView:Refresh()
    end)
    for i = 1, 8 do
        local row = button(profitView, "", 10, -69 - (i - 1) * 32, 298, function(self)
            local entry = self.entry
            if not entry or not isCooking() or InCombatLockdown() then return end
            if entry.unlearned then
                local destination = entry.id and learningWaypoint(entry)
                if destination then suite.openLearningMap(destination, "Cook It, Book It", entry.name) end
            else api("OpenRecipe", entry.id) end
        end)
        row:SetHeight(30)
        local caption = label(row, 8, -4)
        caption:SetWidth(196)
        caption:SetWordWrap(false)
        row.caption = caption
        row.summary = label(row, 8, -17)
        row.amount = row:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
        row.amount:SetPoint("RIGHT", -8, 0)
        row.amount:SetTextColor(.56, 1, .6)
        suite.bindRecipeTooltip(row, function(self)
            local entry = self.entry
            if not entry then return end
            GameTooltip:SetOwner(self, "ANCHOR_RIGHT")
            GameTooltip:SetText(entry.name)
            if entry.unlearned then
                GameTooltip:AddLine("Unlearned", 1, .82, .3)
                if entry.requiredSkill then GameTooltip:AddDoubleLine("Requires Cooking", tostring(entry.requiredSkill)) end
                showProfitRecipeSource(entry)
            end
            if entry.profit then
                GameTooltip:AddDoubleLine("Ingredients per craft", addon.money(entry.cost))
                GameTooltip:AddDoubleLine(("AH proceeds after cut (%d made)"):format(entry.yield), addon.money(entry.proceeds))
                local sign = entry.profit < 0 and "-" or "+"
                GameTooltip:AddDoubleLine("Est. AH profit per craft", sign .. addon.money(math.abs(entry.profit)))
            else GameTooltip:AddLine("Price estimate unavailable", .75, .75, .75) end
            if entry.pace then GameTooltip:AddLine(entry.pace, .85, .85, .85) end
            GameTooltip:AddLine("Hold Shift for the crafted item", .72, .78, .85)
            GameTooltip:Show()
        end, nil, nil, function(self)
            if self.entry and self.entry.unlearned then
                GameTooltip:AddLine(" ")
                showProfitRecipeSource(self.entry)
            end
        end)
        recipeRows[i] = row
    end

    local prev = button(profitView, "<", 12, -337, 28, function()
        currentPage = currentPage - 1
        draw()
    end)
    local nextPage = button(profitView, ">", 44, -337, 28, function()
        currentPage = currentPage + 1
        draw()
    end)
    local pageText = label(profitView, 82, -342)
    button(profitView, "Refresh", 230, -337, 76, function() profitView:Refresh() end)

    draw = function()
        local visible = results
        if craftable:GetChecked() then
            visible = {}
            for _, entry in ipairs(results) do
                if entry.count > 0 then visible[#visible + 1] = entry end
            end
        end
        local pageCount = math.max(1, math.ceil(#visible / #recipeRows))
        currentPage = math.max(1, math.min(currentPage, pageCount))
        note:SetText(#visible > 0 and ("%d %s"):format(#visible, unlearned:GetChecked() and "recipes" or "profitable recipes")
            or (craftable:GetChecked() and #results > 0 and "No profitable recipes craftable now."
                or "No profitable recipes with complete prices."))
        pageText:SetText(("%d / %d"):format(currentPage, pageCount))
        prev:SetEnabled(currentPage > 1)
        nextPage:SetEnabled(currentPage < pageCount)
        for i, row in ipairs(recipeRows) do
            local entry = visible[(currentPage - 1) * #recipeRows + i]
            row.entry = entry
            row:SetShown(entry ~= nil)
            if entry then
                row.caption:SetText(entry.name)
                local status = entry.unlearned and ("|cffffd24aUnlearned|r" ..
                    (entry.requiredSkill and ("  •  Cooking " .. entry.requiredSkill) or "")) or (entry.count .. " craftable")
                row.summary:SetText(status .. (not entry.unlearned and entry.pace and ("  •  " .. entry.pace) or ""))
                local profit = entry.profit
                row.amount:SetText(profit and ((profit < 0 and "|cffff9292-" or "|cff8eff99+") ..
                    addon.money(math.abs(profit)) .. "|r") or "|cffb0b0b0No price|r")
            end
        end
    end

    function profitView:UpdateCounts()
        for _, entry in ipairs(results) do
            if not entry.unlearned then entry.count = craftLimit(entry) end
        end
        draw()
    end

    function profitView:Refresh()
        if self:IsVisible() and isCooking() and not InCombatLockdown() then
            local supported = UnitFactionGroup("player") == "Horde" and tostring(GetBuildInfo()):match("^1%.60%.") ~= nil
            unlearned:SetShown(supported)
            if not supported then unlearned:SetChecked(false) end
            results = addon.profitableCooking(materials, craftLimit, unlearned:GetChecked() == true)
            draw()
        end
    end

    profitView:SetScript("OnShow", function(self)
        currentPage = 1
        self:EnableKeyboard(true)
        self:SetPropagateKeyboardInput(true)
        self:Refresh()
    end)
    profitView:SetScript("OnHide", function(self)
        self:EnableKeyboard(false)
        for _, row in ipairs(recipeRows) do
            if GameTooltip:IsOwned(row) then GameTooltip:Hide() end
        end
    end)
    profitView:SetScript("OnKeyDown", function(self, key)
        if InCombatLockdown() then return end
        self:SetPropagateKeyboardInput(key ~= "ESCAPE")
        if key == "ESCAPE" then self:Hide() end
    end)
end

local function build()
    local metadata = C_AddOns and C_AddOns.GetAddOnMetadata or GetAddOnMetadata
    local currentVersion = metadata and metadata(name, "Version")
    local versionText = currentVersion and ("v" .. currentVersion) or ""
    controls = CreateFrame("Frame", nil, UIParent)
    controls:SetSize(139, 21)
    controls:Hide()
    mainCountdown = label(controls, 0, 0)
    mainCountdown:SetTextColor(1, .82, .3)
    mainCountdown:Hide()
    button(controls, "Settings", 0, 0, 81, function()
        settingsOpen = not settingsOpen
        refresh()
    end)
    button(controls, "Mini", 85, 0, 54, function()
        if InCombatLockdown() then return end
        settingsOpen = false
        db.mini = true
        refresh()
    end)

    buildProfitView()

    panel = window(controls)
    panel:SetSize(322, 86)
    panel:SetPoint("TOPRIGHT", controls, "BOTTOMRIGHT", 0, -4)
    panel:EnableMouse(true)
    panel:Hide()
    local title = label(panel, 13, -12)
    title:SetTextColor(1,.80,.40)
    title:SetText("Cook It, Book It")
    button(panel, "X", 283, -7, 26, function()
        settingsOpen = false
        refresh()
    end)
    panel.proximity = checkbox(panel, "Experimental Proximity", 11, -33, function(self)
        db.proximity = self:GetChecked() == true
        proximity()
    end)
    local exceptions = buildExceptions(panel)
    button(panel, "Exceptions", 219, -33, 89, function() exceptions:SetShown(not exceptions:IsShown()) end)
    panel.cheapest = checkbox(panel, "Show Cheapest", 11, -57, toggleCheapest)
    colorDropdown(panel, "mainColor", 154, -58)
    local tribute = panel:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
    tribute:SetPoint("BOTTOMRIGHT", -12, 11)
    tribute:SetFont("Fonts\\MORPHEUS.TTF", 10, "")
    tribute:SetTextColor(.78,.64,.33)
    tribute:SetText("RIP Shady")
    local settingsVersion = panel:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
    settingsVersion:SetPoint("BOTTOM", panel, "BOTTOM", 22, 11)
    settingsVersion:SetTextColor(.65, .70, .77)
    settingsVersion:SetText(versionText)
    panel.note = label(panel, 13, -85)
    panel.results = {}
    for i = 1, 5 do
        local btn = button(panel, "", 12, -103-(i-1)*22, 298, function(self)
            local entry = self.entry
            if not entry or not isCooking() or InCombatLockdown() then return end
            if entry.training then setLearningWaypoint(entry)
            else api("OpenRecipe", entry.id) end
        end)
        suite.bindRecipeTooltip(btn, showTooltip)
        panel.results[i] = btn
    end
    panel.prev = button(panel, "<", 12, -216, 27, function() page = page-1; refresh() end)
    panel.next = button(panel, ">", 41, -216, 27, function() page = page+1; refresh() end)
    panel.refresh = button(panel, "REFRESH", 77, -216, 72, refresh)

    mini = window(UIParent)
    mini:SetSize(409, 170)
    mini:SetPoint("CENTER", UIParent, "CENTER", 0, 70)
    mini:SetFrameStrata("DIALOG")
    mini:SetClampedToScreen(true)
    mini:SetMovable(true)
    mini:EnableMouse(true)
    mini:RegisterForDrag("LeftButton")
    mini:SetScript("OnDragStart", mini.StartMoving)
    mini:SetScript("OnDragStop", mini.StopMovingOrSizing)
    mini:Hide()
    local miniTitle = label(mini, 13, -14)
    miniTitle:SetTextColor(1,.80,.40)
    miniTitle:SetText("Cook It, Book It")
    mini.skill = label(mini, 13, -29)
    mini.skill:SetTextColor(.71, .77, .83)
    local version = label(mini, 0, 0)
    version:ClearAllPoints()
    version:SetPoint("BOTTOMLEFT", mini, "BOTTOMLEFT", 13, 9)
    version:SetTextColor(.65, .70, .77)
    version:SetText(versionText)
    local memorial = mini:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
    memorial:SetPoint("BOTTOM", mini, "BOTTOM", 0, 8)
    memorial:SetFont("Fonts\\MORPHEUS.TTF", 10, "")
    memorial:SetTextColor(.78, .64, .33)
    memorial:SetText("RIP Shady")
    mini.cheapest = checkbox(mini, "Cheapest", 126, -8, toggleCheapest)
    colorDropdown(mini, "miniColor", 207, -9)
    button(mini, "FULL", 294, -9, 58, function() db.mini = false; refresh() end)
    button(mini, "X", 363, -9, 32, function()
        if InCombatLockdown() then return end
        restore()
        if native and isCooking() then
            if HideUIPanel then HideUIPanel(native) else native:Hide() end
        end
        mini:Hide()
    end)
    mini.recipe = label(mini, 46, -48)
    mini.recipe:SetWidth(315)
    mini.recipe:SetMaxLines(1)
    mini.prev = button(mini, "<", 12, -43, 27, function() index = index-1; refresh() end)
    mini.next = button(mini, ">", 368, -43, 27, function() index = index+1; refresh() end)
    mini.cost = label(mini, 46, -68)
    mini.hint = label(mini, 13, -128)
    mini.countdown = label(mini, 0, 0)
    mini.countdown:ClearAllPoints()
    mini.countdown:SetPoint("TOPRIGHT", mini, "TOPRIGHT", -13, -128)
    mini.countdown:SetJustifyH("RIGHT")
    mini.countdown:SetTextColor(1, .82, .3)
    mini.amount = CreateFrame("EditBox", nil, mini, "InputBoxTemplate")
    mini.amount:SetPoint("TOPLEFT", 55, -91)
    mini.amount:SetSize(42, 25)
    mini.amount:SetAutoFocus(false)
    mini.amount:SetNumeric(true)
    mini.amount:SetMaxLetters(3)
    mini.amount:SetText("1")
    mini.amount:SetScript("OnTextChanged", updateAmount)
    mini.amount:SetScript("OnEscapePressed", function(self) self:ClearFocus() end)
    mini.amount:SetScript("OnEnterPressed", function(self) self:ClearFocus() end)
    local function adjust(delta)
        local n = tonumber(mini.amount:GetText()) or 1
        mini.amount:SetText(tostring(math.max(1, math.min(999, n+delta))))
    end
    button(mini, "-", 12, -93, 30, function() adjust(-1) end)
    button(mini, "+", 110, -93, 30, function() adjust(1) end)
    mini.max = button(mini, "MAX", 148, -93, 48, function()
        local limit = craftLimit(mini.current)
        if limit > 0 then mini.amount:SetText(tostring(limit)) end
    end)
    mini.craft = button(mini, "CRAFT", 209, -93, 186, function()
        local current = mini.current
        local amount = tonumber(mini.amount:GetText())
        if amount and amount % 1 == 0 and amount >= 1 and amount <= craftLimit(current) then
            api("CraftRecipe", current.id, amount)
        end
    end)
    suite.bindRecipeTooltip(mini.craft, showTooltip, function() return mini.current end)

    nearby = button(UIParent, "Cook", 0, 0, 156, function(_, mouseButton)
        if mouseButton == "RightButton" then
            if saveCurrentSpot() then
                updateNearby()
                print("Cook It, Book It: Cooking Proximity ignored at this spot.")
            end
        else
            openCooking()
        end
    end)
    nearby:RegisterForClicks("LeftButtonUp", "RightButtonUp")
    nearby:SetScript("OnEnter", function(self)
        GameTooltip:SetOwner(self, "ANCHOR_TOP")
        GameTooltip:SetText("Right-click to ignore this spot.")
        GameTooltip:Show()
    end)
    nearby:SetScript("OnLeave", function() GameTooltip:Hide() end)
    nearby:ClearAllPoints()
    nearby:SetPoint("CENTER", UIParent, "CENTER", 0, -165)
    nearby:Hide()

    suite.launcher("CookItBookItMinimapButton", db, "INV_Misc_Food_15", 190, openCooking)
end

suite.registerModule(function(event, arg)
    if event == "ADDON_LOADED" then
        if arg ~= name then return end
        CookItBookItDB = type(CookItBookItDB) == "table" and CookItBookItDB or {}
        db = CookItBookItDB
        build()
        proximity()
        suite.addPoll(function()
            local frame = ProfessionsFrame or TradeSkillFrame
            if frame and frame:IsShown() then
                if frame ~= native or (isCooking() ~= (controls:IsShown() or mini:IsShown())) then refresh()
                elseif controls:IsShown() then updateMainCountdown() end
            end
        end)
        SLASH_COOKITBOOKIT1, SLASH_COOKITBOOKIT2 = "/cibi", "/cookit"
        SlashCmdList.COOKITBOOKIT = function(msg)
            if InCombatLockdown() then return end
            if msg == "mini" then db.mini = true
            elseif msg == "full" or msg == "settings" then
                db.mini = false
                settingsOpen = msg == "settings"
            end
            openCooking()
            if msg ~= "settings" or isCooking() then refresh() end
        end
        return {"TRADE_SKILL_SHOW", "TRADE_SKILL_CLOSE", "TRADE_SKILL_DATA_SOURCE_CHANGED",
            "TRADE_SKILL_LIST_UPDATE", "NEW_RECIPE_LEARNED", "SKILL_LINES_CHANGED", "BAG_UPDATE_DELAYED", "PLAYER_REGEN_DISABLED",
            "PLAYER_REGEN_ENABLED", "AUCTION_HOUSE_CLOSED", "PLAYER_LEAVING_WORLD", "PLAYER_ENTERING_WORLD", "UNIT_AURA", "TRAINER_SHOW", "TRAINER_UPDATE", "TRAINER_CLOSED", "SPELL_DATA_LOAD_RESULT"}
    end
    if event == "UNIT_AURA" then
        if arg == "player" and db.proximity then updateNearby() end
        return
    end
    if event == "PLAYER_LEAVING_WORLD" then
        nearbyResumeAt = GetTime() + 5
        resetNearby()
    elseif event == "PLAYER_ENTERING_WORLD" then
        nearbyResumeAt = GetTime() + 2
        resetNearby()
    elseif event == "TRAINER_SHOW" then
        trainerOpen = true
        scanTrainer()
        C_Timer.After(.15, scanTrainer)
    elseif event == "TRAINER_UPDATE" then
        scanTrainer()
    elseif event == "TRAINER_CLOSED" then
        trainerOpen = false
    elseif event == "TRADE_SKILL_CLOSE" then
        settingsOpen = false
        profitView:Hide()
        restore()
        controls:Hide()
        panel:Hide()
        mini:Hide()
    elseif event == "TRADE_SKILL_DATA_SOURCE_CHANGED" or event == "PLAYER_REGEN_DISABLED" then
        refresh()
    elseif event == "NEW_RECIPE_LEARNED" and profitView:IsShown() then
        profitView:Refresh()
    end
    updateNearby()
    schedule()
end)
