# Profession AIO 1.2.4 — Side panel minimize

Baseline: Profession AIO 1.2.3, recovered from Library.

- Added a small minus/plus toggle below the native profession close button.
- Collapse hides the Recipes/Cheapest/Profitable/Details/Options dock only; native crafting and compact pricing remain untouched.
- Expand restores the current dock view during the same profession session. Each supported profession remembers its collapsed preference in its existing settings.
- Explicit Cheapest requests reopen the dock. Closing the native window also hides the toggle. The dock skips periodic recipe refreshes while collapsed; existing scan state is not cancelled or changed.
- No SavedVariables identifiers, pricing logic, fishing functionality, or other addons changed.

Validation: all Lua source files parsed with texluac (not the actual WoW Lua compiler). Mocked frame tests passed for default visibility, collapse/expand, suppressed refresh, active-view retention, per-profession preference, explicit Cheapest reopening, and native close/reopen. Actual client placement, layering, and live gameplay remain unverified.

Install: exit the game or reload after replacing the ProfessionAIO folder. Keep existing SavedVariables. Roll back by replacing the folder with 1.2.3.
