Profession AIO v1.2.4

See RELEASE-1.2.4.md for this update and RELEASE-1.2.3.md for the previous live recipe scan update. See RELEASE-1.2.0.md for the changelog, validation results and rollback instructions.
WoW Forever • Interface 16001

Install
1. Exit WoW Forever.
2. Extract the ProfessionAIO folder into Interface/AddOns.
3. Disable the standalone TailorSwift, CookItBookIt, and EnchantIt addons in
   the character selection AddOns list. Enable Profession AIO.
4. Open Tailoring, Cooking, or Enchanting as usual or use its minimap icon.

Shortcuts
Tailor Swift     /ts, /tailorswift, /tt, /tailorthis
Cook It Book It  /cibi, /cookit
Enchant It       /eci, /enchantit
Each supports mini, full, and settings arguments. Tailor Swift also supports
its existing cheapest, minimap, help, and price commands.

Carry over standalone settings (optional)
WoW stores SavedVariables in files named for the addon. Profession AIO uses
the existing variable names, so you can transfer them without editing Lua
values. Close the game before copying and keep your original files.

• In WTF/Account/<account>/SavedVariables, copy the contents of the
  TailorSwift.lua, CookItBookIt.lua, and EnchantIt.lua files that exist into
  one new ProfessionAIO.lua in that same directory. Start each file's
  contents on a new line. Preserve TailorThisDB if present. If you have a
  separate TailorThis.lua, its TailorThisDB assignment can also be copied.
• In WTF/Account/<account>/<realm>/<character>/SavedVariables, do the same
  with the CookItBookIt.lua and EnchantIt.lua files that exist, creating a
  separate ProfessionAIO.lua in that character's directory. Repeat for
  each character whose settings or Enchant It trainer data you want.
• If ProfessionAIO.lua already exists in either location, back it up and
  replace only the assignments you want to import. Keep one assignment per
  variable. The account and character files are separate.

Recipe source maps
Click a Trainable or Upcoming recipe to open the map at its mapped source.
The addon uses a native waypoint or TomTom when possible and otherwise
places a marker on the world map. Sources without coordinates are reported
in chat.

Sources
Tailor Swift 2.0.2, Cook It Book It 1.4.5, Enchant It 1.0.1.
The individual feature notes are in each profession's folder.

The dock has a per-profession pricing provider in Options. Auto prefers Auction
Companion. Mini, trainer and Legacy views retain their original price lookups.

Fishing
Click the tackle-box button or type /paiofish. Shift-drag the button to move
it. Set a keyboard shortcut in the Fishing window. With a pole
in your bags, press once to equip, again to cast, and again to reel after
the bobber splashes. Face the bobber and keep it within interact range.
Quiet audio and Fast loot are optional. Quiet audio suppresses music,
ambience, dialog and auxiliary sound channels with the pole equipped.
Sound effects stay on for the splash, so other effects can still play.
Fast loot takes slots whose source is identified as a fishing bobber.
For a key already in use, press the same combination twice to confirm
reassignment. Clear removes the Fishing binding.
The Bobber tab previews marker style, color and size. The marker is
optional and appears when the Interact target is a fishing bobber.
Zone thresholds are estimates for open water from Classic reference data
and OneCast's documented Forever observations. Some waters vary by spot.
The skill-up filters use effective skill and your current trained cap.

Fishing Session
The Session tab starts tracking on your first cast of a character login.
It survives /reload. On your next login, the prior fishing session moves
to history. Use History or the arrows to browse recorded fishing logins.
A login without any fishing casts creates no entry. Vendor and AH totals
are estimates based on available prices when you view the session.

The Fishing effects volume slider is in the Bobber tab. Setting it
applies a temporary shared effects volume while Quiet audio is active.

Cooking proximity exceptions
Open Cooking Settings > Exceptions to mute the Cook prompt in the current
zone or subzone. Click an entry to remove it. Manual cooking is still available.

Right-click the automatic Cook prompt next to a brazier to ignore the spot
within 12 yards of where you stand. You can also add a spot from Exceptions.
The location is saved by position because proximity reports a generic fire.

Enchant It source audit
Trainer visits take priority. Static references route trainer, fixed vendor,
Merchant's Favor and selected dungeon sources. Dungeon pins mark the approach
or entrance. Unmapped formulas show available source text without a guessed pin.

References
https://www.wowhead.com/forever/guide/professions/enchanting/overview
https://theforeverguides.com/professions/enchanting-recipes/
https://wowhandbook.com/professions/enchanting/trainers/
https://www.method.gg/wow-forever/all-enchanting-recipes-and-best-enchants-in-wow-forever

Fishing Craft
Click Craft beside Session to open the compact Fishing camp recipe picker.
It opens Bait and Tackle when needed and hides its native window while the
picker is open. Use arrows for Fish Bowl, Fishing Rack and Fishing Hut.
Hover the crafted item or an ingredient for its game tooltip.
In Tailoring, Cooking and Enchanting, Shift-hover recipe rows or Mini craft
buttons for the native output item or spell tooltip.

Shift-middle-click the small Fishing tackle-box icon to swap the pole and
previous main- and off-hand items. The shortcut is available out of combat.

Fishing > Quests & Uniques contains a starter set of goals and destinations.
Your Fishing skill and cap appear at the upper left of Quests & Uniques.
Quest rows show progress from the quest log when available. Click for the
start, prerequisite, or turn-in, as appropriate. Active and completed
quests show details and let you choose a destination. Nat Pagle’s four
quest fish have individual fishing waypoints. Roaming pools open the zone map.

Sources:
https://www.wowhead.com/forever/guide/professions/fishing/overview-leveling
https://www.icy-veins.com/wow-forever/fishing
https://questing.wiki/wow-forever/quests/6607/
https://azeroth.wiki/forever/quests/camping-101-fishing
https://zephras.com/forever/enUS/npc/15079/


v1.1.34: AC live cost/profit label beside AC Search. The values update when AC
reads fresh search results or finishes a Full Scan; missing prices display --.


v1.1.35: Position AC To Craft / Profit values beside the recipe icon,
not on top of it. Limit the text width before AC Search, and shrink
the font for unusually long currency values without wrapping.

1.1.36: Tailoring reagents: click a cloth bolt or Forever Alchemy dye name
to show a plain material breakdown with totals for this recipe. Removed
always-on bolt count labels that could overlap neighboring rows.

1.1.37: Fishing key watchdog repairs stale Cast/Interact switching after
Alt+Tab or a missed channel event without requiring /reload.
Use /paiofish repair for a manual key reset (out of combat).
Recovery retries are capped if another addon owns the same key.


v1.1.38: AC crafting header uses AC GetMaterialCost for reagents (vendor when cheaper setting), but still uses auction price for the finished output. Previous fishing key recovery and clickable ingredient behavior preserved.

1.1.39: Enchanting AC integration now shows cached reagent cost and the AC
Search control like Tailoring. Direct gear enchants omit sale-profit text.
Controls follow the visible Reagents heading to avoid long descriptions.
AC searches still require the Auction House; price display uses AC's cached
quotes and respects the AC vendor-pricing setting. If the Reagents heading
cannot be located safely, the compact controls are hidden to prevent overlap.

v1.1.40: Fix AuctionSearch Lua error from AC multi-return price/source values. Position AC cost/search on Enchanting Reagents heading (including long enchant descriptions); use compact cost (+profit for auctionable craft outputs), retain Tailoring layout.


v1.1.41: Standardize the AC reagent-cost header to "Cost:" for all professions.
Keep AC Search, cost calculations, cached quotes and profit layout unchanged.

v1.1.42: Add hover tooltips to all three profession minimap launchers.

v1.1.44: Port the v1.1.31 full-view skill-up countdown placement fix
to the v1.1.43 baseline for Tailoring, Cooking, and Enchanting.
Anchor the countdown above the recipe header instead of below Profit
or near native cooldowns. Remove the obsolete recursive Profit lookup.
All other v1.1.43 files and SavedVariables declarations are preserved.
