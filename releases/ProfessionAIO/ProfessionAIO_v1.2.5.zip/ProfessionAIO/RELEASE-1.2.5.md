# Profession AIO 1.2.5 — Minimize button visibility

Baseline: 1.2.4. Replaces the template-based toggle with an opaque red/gold button and explicit high-contrast plus/minus textures, positioned at the same anchor. Sets FULLSCREEN_DIALOG strata after parenting and raises the frame level above the native controls. Keeps the saved per-profession collapsed state and existing click, tooltip, refresh and close behavior. No SavedVariables migration.

In-game verification: open Tailoring, Cooking and Enchanting; verify the button is visible below X in both states, can be clicked, does not obscure native controls, and disappears with the window.
