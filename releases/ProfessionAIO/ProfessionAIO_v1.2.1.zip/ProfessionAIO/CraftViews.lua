local name, suite = ...
local api, button, label = suite.tradeSkillAPI, suite.button, suite.label
local definitions = {
    {title="Tailoring", id=197, profession=7, db=function() return TailorSwiftDB.nativeUI end},
    {title="Cooking", id=185, profession=5, db=function() return CookItBookItDB end},
    {title="Enchanting", id=333, profession=9, db=function() return EnchantItDB end, enchant=true},
}
local difficulties = {[0]="Orange",[1]="Yellow",[2]="Green",[3]="Gray"}
local modes = {"Recipes","Cheapest","Profitable"}
local routes = {"Auction","Vendor","Disenchant","Best"}
local providers = {"Auto","Auction Companion","Auctionator","Shady Price Engine","AHledger"}
local function cycle(values, current)
    for index, option in ipairs(values) do
        if option == current then return values[index % #values + 1] end
    end
    return values[1]
end

local function field(parent, x, y, width)
    local value = label(parent, x, y)
    value:SetWidth(width)
    value:SetWordWrap(false)
    return value
end

local function money(value)
    return value and suite.money(value) or "|cffffe346Unknown|r"
end

local function profit(route, warning)
    local value = route and route.profit
    if not value then return "|cffffe346Unknown|r" end
    local prefix = warning or route.warning
    local color = prefix and "|cffffe346~ " or (value > 0 and "|cff64ff74✓ " or value < 0 and "|cffff6262× " or "|cffffffff")
    return color .. (value < 0 and "-" or value > 0 and "+" or "") .. suite.money(math.abs(value)) .. "|r"
end

local function scope(native)
    if not native or not native:IsVisible() or native:GetAlpha() == 0 then return end
    for _, def in ipairs(definitions) do
        if suite.isProfession(native, def.id, Enum and Enum.Profession and Enum.Profession[def.title] or def.profession, def.title) then return def end
    end
end

local function makeRow(parent, index, choose)
    local row = CreateFrame("Button", nil, parent)
    row:SetPoint("TOPLEFT", 10, -109 - (index-1)*23)
    row:SetSize(360, 23)
    row:SetHighlightTexture("Interface\\QuestFrame\\UI-QuestTitleHighlight")
    row.icon = row:CreateTexture(nil, "ARTWORK")
    row.icon:SetPoint("LEFT", 1, 0)
    row.icon:SetSize(18, 18)
    row.name = field(row, 23, -5, 145)
    row.kind = field(row, 173, -5, 42)
    row.count = field(row, 221, -5, 30)
    row.price = field(row, 254, -5, 105)
    row:SetScript("OnClick", choose)
    row:SetScript("OnEnter", function(self)
        local entry = self.entry
        GameTooltip:SetOwner(self, "ANCHOR_RIGHT")
        if entry.output then GameTooltip:SetItemByID(entry.output) else GameTooltip:SetText(entry.name) end
        GameTooltip:AddLine("Materials / craft: " .. money(entry.cost))
        if entry.route then GameTooltip:AddLine(entry.route.name .. " profit: " .. profit(entry.route, entry.warning)) end
        if entry.warning then GameTooltip:AddLine(entry.warning, 1, .87, .25) end
        if entry.requirement then GameTooltip:AddLine(entry.requirement, 1, .87, .25) end
        if entry.cooldown then GameTooltip:AddLine("On cooldown", 1, .87, .25) end
        GameTooltip:Show()
    end)
    row:SetScript("OnLeave", function() GameTooltip:Hide() end)
    return row
end

local function build()
    local frame = suite.window(UIParent, {.055,.07,.09,1})
    frame:SetSize(382, 500)
    frame:SetFrameStrata("MEDIUM")
    frame:SetClampedToScreen(true)
    frame:EnableMouse(true)
    frame:Hide()
    local body = CreateFrame("Frame", nil, frame)
    body:SetAllPoints()
    local native, def, settings, mode, page, lastKey, lastRefresh
    local entries, results, rows, tabs = {}, {}, {}, {}
    local refresh, paint, updateSummary
    local dirty, pendingView = true
    local delayedItems
    local expanded, options = false, false
    local estimate, source, material
    local lastID, lastCount
    local layoutLeft, layoutRight, layoutScale, layoutNative
    local summary = CreateFrame("Frame", nil, frame)
    summary:SetSize(382, 179)
    local summaryText = field(summary, 12, -26, 358)
    local details = {}
    details[1] = field(summary, 12, -41, 358)
    details[2] = field(summary, 12, -56, 358)
    details[6] = field(summary, 12, -135, 358)
    local saleLabels, saleValues = {}, {}
    for index, key in ipairs({"Auction", "Vendor", "Disenchant"}) do
        local y = -71 - index * 15
        saleLabels[index] = field(summary, 12, y, 95)
        saleLabels[index]:SetText(key)
        saleValues[index] = field(summary, 112, y, 255)
    end
    local feedback = field(summary, 12, -159, 358)
    local buy = button(summary, "Find missing in AC", 234, -1, 135, function()
        local id, quantity = suite.selectedRecipe(native)
        if not id then feedback:SetText("Select a recipe in the native window."); return end
        local ok, message = suite.searchMissing(id, quantity)
        feedback:SetText((ok and "|cff64ff74Search sent to AC.|r" or "|cffffe346" .. message .. "|r"))
        if not ok then print("Profession AIO: " .. message) end
    end)
    local function resize()
        body:SetShown(mode ~= "Recipes" and not options)
        local showSummary = not options and expanded and settings.details ~= false
        summary:SetShown(showSummary)
        summary:ClearAllPoints()
        local y = mode == "Recipes" and 34 or 340
        summary:SetPoint("TOPLEFT", 0, -y)
        frame:SetHeight(options and 317 or y + (showSummary and 184 or 4))
    end
    local function selectMode(value)
        options, mode, page, dirty = false, value, 1, true
        resize()
        refresh()
    end
    for index, value in ipairs(modes) do
        tabs[value] = button(frame, value, 9+(index-1)*79, -8, 77, function() selectMode(value) end)
    end
    button(frame, "Details", 247, -8, 62, function()
        if options then options = false
        else expanded = not expanded end
        resize()
        updateSummary(true)
    end)
    local settingsPage = CreateFrame("Frame", nil, frame)
    settingsPage:SetAllPoints()
    settingsPage:Hide()
    local controls = {}
    local function preference(key, y, title, values)
        local control = button(settingsPage, "", 12, y, 350, function()
            if values then settings[key] = cycle(values, settings[key] or values[1])
            else settings[key] = settings[key] == false end
            if settings.cheapest == false and mode == "Cheapest" or settings.profitable == false and mode == "Profitable" then
                mode = "Recipes"
            end
            dirty = true
            refresh()
        end)
        controls[key] = {control=control, title=title, values=values}
    end
    preference("provider",-43,"Pricing provider",providers)
    preference("fees",-70,"Apply 5% AH commission")
    preference("vendor",-97,"Use known vendor buy prices")
    preference("details",-124,"Show selected-recipe details")
    preference("cheapest",-151,"Enable Cheapest")
    preference("profitable",-178,"Enable Profitable")
    preference("station",-205,"Location requirements",{"Any","Required","None reported"})
    preference("solid",-232,"Solid background")
    preference("counts",-259,"Show craftable quantities")
    field(settingsPage, 13, -292, 208):SetText("Estimated market values  •  v1.2.0")
    local tribute = field(settingsPage, 312, -292, 63)
    tribute:SetFont("Fonts\\MORPHEUS.TTF", 10, "")
    tribute:SetTextColor(.78,.64,.33)
    tribute:SetText("RIP Shady")
    button(frame, "Options", 310, -8, 64, function()
        options = not options
        resize()
        refresh()
    end)
    local query = CreateFrame("EditBox", nil, body, "InputBoxTemplate")
    query:SetPoint("TOPLEFT", 15, -39)
    query:SetSize(138, 21)
    query:SetAutoFocus(false)
    query:SetMaxLetters(80)
    query:SetScript("OnEscapePressed", function(self) self:ClearFocus() end)
    query:SetScript("OnEnterPressed", function(self) self:ClearFocus() end)
    local filter = button(body, "", 161, -39, 83, function()
        settings.difficulty = cycle({"All","Orange","Yellow","Green","Gray"}, settings.difficulty or "All")
        page = 1; paint()
    end)
    local route = button(body, "", 249, -39, 123, function()
        settings.route = cycle(routes, settings.route or routes[1])
        page = 1; paint()
    end)
    local craftable = button(body, "", 9, -64, 111, function()
        settings.craftable = not settings.craftable
        page = 1; paint()
    end)
    local cooldown = button(body, "", 122, -64, 100, function()
        settings.ready = not settings.ready
        page = 1; paint()
    end)
    local sort = button(body, "", 224, -64, 148, function()
        settings.sort = cycle({"Rank","Name","Craftable"}, settings.sort or "Rank")
        page = 1; paint()
    end)
    query:SetScript("OnTextChanged", function() if settings and body:IsVisible() then page = 1; paint() end end)
    field(body, 12, -94, 160):SetText("Recipe  •  Type to search")
    field(body, 181, -94, 47):SetText("Skill")
    local qtyHeading = field(body, 230, -94, 35)
    qtyHeading:SetText("Qty")
    local column = field(body, 264, -94, 100)
    local note = field(body, 45, -310, 277)
    local previous = button(body, "<", 10, -304, 28, function() page = page - 1; paint() end)
    local following = button(body, ">", 342, -304, 28, function() page = page + 1; paint() end)
    for index = 1, 8 do
        rows[index] = makeRow(body, index, function(self)
            if self.entry and not InCombatLockdown() then api("OpenRecipe", self.entry.id) end
        end)
    end
    frame:EnableKeyboard(true)
    frame:SetPropagateKeyboardInput(true)
    frame:SetScript("OnKeyDown", function(self, key)
        if InCombatLockdown() then return end
        local dismiss = key == "ESCAPE" and (mode ~= "Recipes" or options)
        self:SetPropagateKeyboardInput(not dismiss)
        if dismiss then
            selectMode("Recipes")
            self:SetPropagateKeyboardInput(true)
        end
    end)

    paint = function()
        filter:SetText(settings.difficulty or "All")
        route:SetText("Sale: " .. (settings.route or "Auction"))
        route:SetShown(not def.enchant)
        craftable:SetText(settings.craftable and "✓ Craftable" or "All quantities")
        cooldown:SetText(settings.ready and "✓ Off cooldown" or "All cooldowns")
        sort:SetText("Sort: " .. (settings.sort or "Rank"))
        qtyHeading:SetShown(settings.counts ~= false)
        column:SetText(mode == "Profitable" and "Est. profit" or "Cost / craft")
        local term = query:GetText():lower()
        results = {}
        for _, entry in ipairs(entries) do
            if entry.name:lower():find(term, 1, true) and
                (not settings.difficulty or settings.difficulty == "All" or difficulties[entry.difficulty] == settings.difficulty)
                and (not settings.craftable or (entry.count or 0) > 0) and (not settings.ready or not entry.cooldown)
                and (settings.station ~= "Required" or entry.requirement)
                and (settings.station ~= "None reported" or not entry.requirement) then
                local sale = settings.route or "Auction"
                entry.route = sale == "Best" and entry.best or entry.routes[sale]
                results[#results+1] = entry
            end
        end
        table.sort(results, function(a,b)
            if settings.sort == "Craftable" and (a.count or 0) ~= (b.count or 0) then
                return (a.count or 0) > (b.count or 0)
            end
            if settings.sort ~= "Name" then
                if mode == "Profitable" then
                    local ap, bp = a.route and a.route.profit or -math.huge, b.route and b.route.profit or -math.huge
                    if ap ~= bp then return ap > bp end
                else
                    local ac, bc = a.cost or math.huge, b.cost or math.huge
                    if ac ~= bc then return ac < bc end
                end
            end
            if a.name ~= b.name then return a.name < b.name end
            return a.id < b.id
        end)
        local pages = math.max(1, math.ceil(#results / #rows))
        page = math.max(1, math.min(page, pages))
        previous:SetEnabled(page > 1)
        following:SetEnabled(page < pages)
        note:SetText(#results == 0 and "No matching known recipes." or ("%d recipes  •  Page %d/%d"):format(#results,page,pages))
        for index, row in ipairs(rows) do
            local entry = results[(page-1)*#rows+index]
            row.entry = entry
            row:SetShown(entry ~= nil)
            if entry then
                row.icon:SetTexture(entry.icon or (entry.output and C_Item and C_Item.GetItemIconByID and C_Item.GetItemIconByID(entry.output)) or 134400)
                row.name:SetText(entry.name)
                row.kind:SetText(difficulties[entry.difficulty] or "—")
                row.count:SetText(settings.counts ~= false and (entry.count or "—") or "")
                row.price:SetText(mode == "Profitable" and profit(entry.route, entry.warning)
                    or ((entry.warning and entry.cost) and "|cffffe346~|r " or "") .. money(entry.cost))
            end
        end
    end

    updateSummary = function(force)
        if not summary:IsVisible() then return end
        local id, quantity = suite.selectedRecipe(native)
        if not force and id == lastID and quantity == lastCount then return end
        if id ~= lastID then feedback:SetText("") end
        lastID, lastCount = id, quantity
        local info = id and api("GetRecipeInfo", id)
        buy:SetShown(info ~= nil)
        for _, line in pairs(details) do line:SetText("") end
        for index, line in ipairs(saleValues) do
            line:SetText("")
            saleLabels[index]:Hide()
        end
        if not info or not estimate then summaryText:SetText("Select a recipe to see material estimates."); return end
        local entry = estimate(id, info, def.enchant)
        local count, missing = suite.craftAvailability(entry, quantity)
        summaryText:SetText(info.name .. "  •  " .. (entry.cooldown and "On cooldown" or ("Craftable: " .. (count or "—"))))
        details[1]:SetText("Materials  " .. money(entry.cost) .. " / craft   •   " .. money(entry.cost and entry.cost*quantity) .. " / " .. quantity)
        details[2]:SetText(source .. (entry.oldest and ("  •  Oldest: " .. date("%b %d %I:%M %p", entry.oldest)) or "")
            .. (entry.warning and ("  •  |cffffe346" .. entry.warning .. "|r") or ""))
        if not def.enchant then
            for index, key in ipairs({"Auction","Vendor","Disenchant"}) do
                local sale = entry.routes[key]
                local shownProfit = key == "Auction" and entry.auctionWarning and "|cffffe346Stale quote|r" or profit(sale, entry.warning)
                saleLabels[index]:Show()
                saleValues[index]:SetText(money(sale and sale.value) .. " gross   •   " .. shownProfit)
            end
        end
        local additional = suite.missingEstimate(entry, quantity, material)
        details[6]:SetText((entry.best and ("Best: " .. entry.best.name .. "   •   ") or "")
            .. (missing and (missing .. " missing  •  Est. " .. money(additional)) or "Reagent choices unavailable"))
        if entry.requirement or entry.variable then
            feedback:SetText((entry.requirement or "") .. (entry.variable and "  •  Minimum yield used" or ""))
        end
    end

    refresh = function()
        for value, tab in pairs(tabs) do
            tab:SetEnabled(options or mode ~= value)
            tab:SetText(mode == value and not options and ("• " .. value) or value)
        end
        tabs.Cheapest:SetShown(settings.cheapest ~= false)
        tabs.Profitable:SetShown(not def.enchant and settings.profitable ~= false)
        settingsPage:SetShown(options)
        frame:SetBackdropColor(.055,.07,.09,settings.solid == false and .89 or 1)
        controls.profitable.control:SetShown(not def.enchant)
        for key, setting in pairs(controls) do
            local value = settings[key]
            setting.control:SetText(setting.title .. "  •  " .. tostring(setting.values and (value or setting.values[1])
                or (value == false and "Off" or "On")))
        end
        if dirty and not options then
            estimate, source, material = suite.newEstimates(settings)
            if mode ~= "Recipes" then
                entries = {}
                local ids = api("GetAllRecipeIDs") or api("GetFilteredRecipeIDs") or {}
                for _, id in ipairs(ids) do
                    local info = api("GetRecipeInfo", id)
                    if info and info.learned and info.name and not info.isDummyRecipe and not info.isRecraft then
                        local entry = estimate(id, info, def.enchant)
                        entry.count = suite.craftAvailability(entry, 1)
                        entries[#entries+1] = entry
                    end
                end
                paint()
            end
            dirty = false
        end
        updateSummary(true)
    end

    local function poll()
        local current = ProfessionsFrame or TradeSkillFrame
        local profession = scope(current)
        if not profession then frame:Hide(); def = nil; return end
        if def ~= profession or native ~= current then
            native, def = current, profession
            local db = def.db()
            if type(db.craftViews) ~= "table" then db.craftViews = {version=1} end
            settings = db.craftViews
            frame:SetParent(native)
            mode, page, options, dirty = "Recipes", 1, false, true
            expanded = false
            query:SetText("")
            feedback:SetText("")
            if pendingView == def.title then
                settings.cheapest = true
                mode, pendingView = "Cheapest", nil
            end
            resize()
        end
        local left, right = native:GetLeft(), native:GetRight()
        if not left or not right then return end
        local parentScale = native:GetEffectiveScale()
        local rightSpace = (UIParent:GetWidth()*UIParent:GetEffectiveScale()/parentScale) - right
        local room = math.max(left, rightSpace)
        if room < 155 then frame:Hide(); return end
        if layoutLeft ~= left or layoutRight ~= rightSpace or layoutScale ~= parentScale or layoutNative ~= native then
            layoutLeft, layoutRight, layoutScale, layoutNative = left, rightSpace, parentScale, native
            frame:SetScale(math.min(1, (room-8)/382))
            frame:ClearAllPoints()
            if left > rightSpace then frame:SetPoint("TOPRIGHT", native, "TOPLEFT", -2, 0)
            else frame:SetPoint("TOPLEFT", native, "TOPRIGHT", 2, 0) end
        end
        frame:Show()
        local ac = AuctionCompanionAPI
        local revision = ac and ac.GetPriceRevision and ac.GetPriceRevision()
        local key = tostring(revision) .. "/" .. tostring(ac)
        if delayedItems and GetTime() >= delayedItems then delayedItems, dirty = nil, true end
        if lastKey ~= key or GetTime() - (lastRefresh or 0) >= 30 then
            lastKey, lastRefresh, dirty = key, GetTime(), true
        end
        if dirty and not options then refresh()
        else updateSummary(false) end
    end
    suite.openCheapest = function(title)
        if def and def.title == title then settings.cheapest = true; selectMode("Cheapest")
        else pendingView = title end
    end
    suite.addPoll(poll)
    return function(event)
        if event == "GET_ITEM_INFO_RECEIVED" then
            if frame:IsShown() then delayedItems = delayedItems or GetTime() + 2 end
            return
        end
        dirty = true
        if event == "TRADE_SKILL_CLOSE" then frame:Hide(); def = nil end
    end
end

local invalidate
suite.registerModule(function(event, arg)
    if event == "ADDON_LOADED" and arg == name then
        invalidate = build()
        return {"TRADE_SKILL_CLOSE","TRADE_SKILL_DATA_SOURCE_CHANGED","TRADE_SKILL_LIST_UPDATE",
            "NEW_RECIPE_LEARNED","BAG_UPDATE_DELAYED","MAIL_CLOSED","GET_ITEM_INFO_RECEIVED"}
    elseif invalidate then invalidate(event) end
end)
