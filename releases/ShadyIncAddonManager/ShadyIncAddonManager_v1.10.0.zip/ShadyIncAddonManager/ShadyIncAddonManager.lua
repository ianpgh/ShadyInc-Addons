-- Shady Inc Addon Manager
-- A focused manager for the custom addons made for this WoW Forever setup.

ShadyIncAddonManagerDB = ShadyIncAddonManagerDB or {}

local ADDON = ...
local GetNumAddOns = (C_AddOns and C_AddOns.GetNumAddOns) or GetNumAddOns
local GetAddOnInfo = (C_AddOns and C_AddOns.GetAddOnInfo) or GetAddOnInfo
local count = table.getn or function(t) return #t end
local VERSION = "1.10.0"

-- Match folder names rather than localized display titles. Add aliases here if a
-- custom addon is installed under a different folder name.
local OWN_ADDONS = {
  auctioncompanion = "Auction Companion",
  buffreminder = "Buff Reminder",
  campfiresongs = "Campfire Songs",
  clickcleansenameoverlay = "ClickCleanse Name Overlay",
  disenchantry = "Disenchantry",
  druidmana = "Druid Mana",
  fashion = "FASHION!",
  frameshift = "FrameShift",
  framesquare = "FrameSquare",
  highestthreat = "Highest Threat",
  minimappin = "MiniMappin",
  pinme = "Pin Me",
  professionaio = "Profession AIO",
  pullrange = "PullRange",
  quietresources = "Quiet Resources",
  shadyflighttimer = "Shady Flight Timer",
  shadypriceengine = "Shady Price Engine",
  statgains = "Stat Gains",
  actionhero = "Action Hero",
  auctionpeek = "AuctionPeek",
  bagnonhide = "BagnonHide",
  buffhero = "BuffHero",
  castidentity = "Cast Identity",
  cityplates = "CityPlates",
  clickcleanse = "ClickCleanse",
  dungeonquester = "DungeonQuester",
  easyfollow = "Easy Follow",
  grindtracker = "GrindTracker",
  hidethismanager = "HideThisManager",
  partyframeswitcher = "PartyFrameSwitcher",
  ripshady = "RIP Shady",
  shadyincaddonmanager = "Shady Inc Addon Manager",
  tooltipmover = "TooltipMover",
  writthis = "Writ This",
  writtracker = "Writ This",
}

local function Normalize(value)
  if not value then return "" end
  return string.lower(string.gsub(value, "[^%w]", ""))
end

local function IsMine(folder)
  return OWN_ADDONS[Normalize(folder)] ~= nil
end

local function GetOwnedAddons()
  local found = {}
  if not GetNumAddOns or not GetAddOnInfo then return found end

  local count = GetNumAddOns()
  for index = 1, count do
    local folder, title = GetAddOnInfo(index)
    if folder and IsMine(folder) then
      local state = "Unknown"
      local enabled = nil
      local enableStateAPI = GetAddOnEnableState or (C_AddOns and C_AddOns.GetAddOnEnableState)
      if enableStateAPI then
        local player = UnitName and UnitName("player") or nil
        local ok, result
        if C_AddOns and enableStateAPI == C_AddOns.GetAddOnEnableState then
          ok, result = pcall(enableStateAPI, folder, player)
        else
          ok, result = pcall(enableStateAPI, player, folder)
        end
        if ok and result ~= nil then
          enabled = result ~= 0
        end
      end
      if enabled == nil and IsAddOnLoaded then
        local ok, result = pcall(IsAddOnLoaded, folder)
        if ok and result then enabled = true end
      end
      if enabled == true then
        state = "Enabled"
      elseif enabled == false then
        state = "Disabled"
      end

      table.insert(found, {
        index = index,
        folder = folder,
        title = title or OWN_ADDONS[Normalize(folder)] or folder,
        state = state,
        enabled = enabled,
        protected = Normalize(folder) == "shadyincaddonmanager",
      })
    end
  end

  table.sort(found, function(a, b)
    return string.lower(a.title) < string.lower(b.title)
  end)
  return found
end

local function ChangeAddonState(addon, shouldEnable)
  local api = C_AddOns or _G
  local method
  if shouldEnable then
    method = (api and api.EnableAddOn) or EnableAddOn
  else
    method = (api and api.DisableAddOn) or DisableAddOn
  end
  if not method then return false end

  local player = UnitName and UnitName("player") or nil
  local ok = pcall(method, addon.index, player)
  if not ok then
    ok = pcall(method, addon.folder, player)
  end
  local saveAPI = SaveAddOns or (C_AddOns and C_AddOns.SaveAddOns)
  if ok and saveAPI then pcall(saveAPI) end
  return ok
end

local function MakeText(parent, text, size, r, g, b, font)
  local fs = parent:CreateFontString(nil, "OVERLAY", "GameFontNormal")
  local fallback = (GameFontNormal and GameFontNormal:GetFont()) or STANDARD_TEXT_FONT
  local ok = false
  if font then ok = pcall(fs.SetFont, fs, font, size or 12) end
  if not ok then fs:SetFont(fallback, size or 12) end
  fs:SetText(text or "")
  if r then fs:SetTextColor(r, g, b) end
  return fs
end

local function CreateButton(parent, text, width, height)
  local button = CreateFrame("Button", nil, parent, "UIPanelButtonTemplate")
  button:SetWidth(width)
  button:SetHeight(height)
  button:SetText(text)
  return button
end

local frame = CreateFrame("Frame", "ShadyIncAddonManagerFrame", UIParent)
frame:SetWidth(580)
frame:SetHeight(430)
frame:SetPoint("CENTER", UIParent, "CENTER", 0, 0)
frame:SetFrameStrata("DIALOG")
frame:EnableMouse(true)
frame:SetMovable(true)
frame:RegisterForDrag("LeftButton")
frame:SetScript("OnDragStart", function(self) self:StartMoving() end)
frame:SetScript("OnDragStop", function(self) self:StopMovingOrSizing() end)
frame:Hide()

local backdrop = frame:CreateTexture(nil, "BACKGROUND")
backdrop:SetAllPoints(frame)
backdrop:SetColorTexture(0, 0, 0, 0.86)
frame.backdrop = backdrop

local border = CreateFrame("Frame", nil, frame, BackdropTemplateMixin and "BackdropTemplate" or nil)
border:SetAllPoints(frame)
border:SetBackdrop({
  bgFile = "Interface\\Tooltips\\UI-Tooltip-Background",
  edgeFile = "Interface\\Tooltips\\UI-Tooltip-Border",
  tile = true, tileSize = 16, edgeSize = 16,
  insets = { left = 4, right = 4, top = 4, bottom = 4 },
})
border:SetBackdropColor(0, 0, 0, 0)
border:SetBackdropBorderColor(0.58, 0.42, 0.12, 0.95)

local title = MakeText(frame, "SHADY INC ADDON MANAGER", 16, 0.95, 0.78, 0.25)
title:SetPoint("TOP", frame, "TOP", 0, -16)

local version = MakeText(frame, "v" .. VERSION, 10, 0.68, 0.68, 0.68)
version:SetPoint("TOPRIGHT", frame, "TOPRIGHT", -34, -19)

local close = CreateFrame("Button", nil, frame, "UIPanelCloseButton")
close:SetPoint("TOPRIGHT", frame, "TOPRIGHT", -3, -3)
close:SetScript("OnClick", function() frame:Hide() end)

local tabButtons = {}
local pages = {}
local activePage

local function SetTab(which)
  if activePage then activePage:Hide() end
  activePage = pages[which]
  if activePage then activePage:Show() end
  for id, button in pairs(tabButtons) do
    if id == which then
      button:Disable()
    else
      button:Enable()
    end
  end
end

local function CreateTab(id, label, x)
  local button = CreateButton(frame, label, 120, 24)
  button:SetPoint("TOPLEFT", frame, "TOPLEFT", x, -45)
  button:SetScript("OnClick", function() SetTab(id) end)
  tabButtons[id] = button
  local page = CreateFrame("Frame", nil, frame)
  page:SetPoint("TOPLEFT", frame, "TOPLEFT", 14, -76)
  page:SetPoint("BOTTOMRIGHT", frame, "BOTTOMRIGHT", -14, 28)
  page:Hide()
  pages[id] = page
  return page
end

local addonsPage = CreateTab("addons", "My Addons", 24)
local optionsPage = CreateTab("options", "Options", 154)
local performancePage = CreateTab("performance", "Performance", 284)
local profilesPage = CreateTab("profiles", "Profiles", 414)

local intro = MakeText(addonsPage, "Checked tooltips follow the addon’s settings.", 11, 0.78, 0.78, 0.78)
intro:SetPoint("TOPLEFT", addonsPage, "TOPLEFT", 4, -2)

local countText = MakeText(addonsPage, "", 11, 0.9, 0.78, 0.36)
countText:SetPoint("TOPRIGHT", addonsPage, "TOPRIGHT", -4, -2)

local scrollFrame = CreateFrame("ScrollFrame", "ShadyIncAddonManagerScrollFrame", addonsPage, "UIPanelScrollFrameTemplate")
scrollFrame:SetPoint("TOPLEFT", addonsPage, "TOPLEFT", 0, -24)
scrollFrame:SetPoint("BOTTOMRIGHT", addonsPage, "BOTTOMRIGHT", -24, 0)
local content = CreateFrame("Frame", nil, scrollFrame)
content:SetWidth(510)
content:SetHeight(1)
scrollFrame:SetScrollChild(content)

-- The manager owns only its opt-out list. An absent entry delegates to the addon.
local function tooltipOff()
  local db = ShadyIncAddonManagerDB
  db.hiddenTooltips = db.hiddenTooltips or {}
  return db.hiddenTooltips
end

local function folderFromSource(source)
  if type(source) ~= "string" then return end
  return source:lower():gsub("\\", "/"):match("addons/([^/]+)/")
end

local function tooltipAddon(tip)
  local owner = tip:GetOwner()
  for depth = 1, 12 do
    if not owner or owner == UIParent or owner == WorldFrame then break end
    if owner.IsForbidden and owner:IsForbidden() then return end
    local folder = owner.GetSourceLocation and folderFromSource(owner:GetSourceLocation())
    if folder and not folder:match("^blizzard_") then return Normalize(folder) end
    local name = owner:GetName()
    if name then
      local key = Normalize(name)
      local best
      for addon in pairs(OWN_ADDONS) do
        if key:sub(1, #addon) == addon and (not best or #addon > #best) then best = addon end
      end
      if best then return best end
    end
    owner = owner:GetParent()
  end
  -- Shared owners such as UIParent give no ownership evidence. Use only the
  -- nearest external addon caller, including unrecognized third-party addons.
  if debugstack then
    for line in debugstack(2, 18, 0):gmatch("[^\n]+") do
      local folder = folderFromSource(line)
      if folder and folder ~= "shadyincaddonmanager" and not folder:match("^blizzard_") then
        return Normalize(folder)
      end
    end
  end
end

local function filterTooltip(tip)
  local hidden = tooltipOff()
  if not next(hidden) or (tip.IsForbidden and tip:IsForbidden()) then return end
  local ok, addon = pcall(tooltipAddon, tip)
  if ok and addon and hidden[addon] then tip:Hide() end
end
if GameTooltip then GameTooltip:HookScript("OnShow", filterTooltip) end

-- Use registered settings categories first. Bare slash commands may perform
-- actions (PartyFrameSwitcher, for example), so only call known UI routes.
local settingsCommands = {
  actionhero = {"ACTIONHERO", ""}, auctionpeek = {"AUCTIONPEEK", "settings"},
  buffhero = {"BUFFHERO", ""}, castidentity = {"CASTIDENTITY", ""},
  cityplates = {"CITYPLATES", ""}, hidethismanager = {"HIDETHISMANAGER", "settings"},
  tooltipmover = {"TOOLTIPMOVER", ""},
}

local function settingsFor(item)
  if item.protected then return function() SetTab("options") end end
  local loaded = (C_AddOns and C_AddOns.IsAddOnLoaded) or IsAddOnLoaded
  if loaded and not loaded(item.folder) then return end
  local key = Normalize(item.folder)
  if Settings and Settings.GetCategory and Settings.OpenToCategory then
    for _, name in ipairs({item.folder, item.title, OWN_ADDONS[key]}) do
      local ok, category = pcall(Settings.GetCategory, name)
      if ok and category and category.GetID then
        return function() Settings.OpenToCategory(category:GetID()) end
      end
    end
  end
  local command = settingsCommands[key]
  if command and type(SlashCmdList[command[1]]) == "function" then
    return function() SlashCmdList[command[1]](command[2]) end
  end
  for _, suffix in ipairs({"SettingsFrame", "OptionsFrame", "SettingsWindow", "OptionsWindow"}) do
    local panel = _G[item.folder .. suffix]
    if panel and panel.Show and panel.GetParent and panel:GetParent() == UIParent then
      return function() panel:Show() panel:Raise() end
    end
  end
end

local rows = {}
local function UpdateRows()
  local addons = GetOwnedAddons()
  countText:SetText(tostring(count(addons)) .. " found")

  for i = 1, count(rows) do rows[i]:Hide() end

  if count(addons) == 0 then
    content:SetHeight(44)
    if not rows.empty then
      local empty = MakeText(content, "No recognized Shady Inc addons are installed.", 12, 0.82, 0.82, 0.82)
      empty:SetPoint("TOPLEFT", content, "TOPLEFT", 8, -10)
      rows.empty = empty
    end
    rows.empty:Show()
    return
  end
  if rows.empty then rows.empty:Hide() end

  for i = 1, count(addons) do
    local addon = addons[i]
    local item = addon
    local row = rows[i]
    if not row then
      row = CreateFrame("Frame", nil, content)
      row:SetWidth(510)
      row:SetHeight(38)
      row.bg = row:CreateTexture(nil, "BACKGROUND")
      row.bg:SetAllPoints(row)
      row.bg:SetColorTexture(1, 1, 1, 0.045)
      row.name = MakeText(row, "", 12, 0.95, 0.9, 0.72)
      row.name:SetPoint("TOPLEFT", row, "TOPLEFT", 8, -5)
      row.folder = MakeText(row, "", 9, 0.67, 0.67, 0.67)
      row.folder:SetPoint("BOTTOMLEFT", row, "BOTTOMLEFT", 8, 5)
      row.state = MakeText(row, "", 10, 0.76, 0.86, 0.76)
      row.state:SetPoint("RIGHT", row, "RIGHT", -169, 0)
      row.action = CreateButton(row, "", 72, 22)
      row.action:SetPoint("RIGHT", row, "RIGHT", -83, 0)
      row.tips = CreateFrame("CheckButton", nil, row, "UICheckButtonTemplate")
      row.tips:SetSize(20, 20)
      row.tipsLabel = MakeText(row, "Show Tooltip", 10, 0.95, 0.9, 0.72)
      row.tipsLabel:SetPoint("RIGHT", row, "RIGHT", -233, 0)
      row.tips:SetPoint("RIGHT", row.tipsLabel, "LEFT", -2, 0)
      row.tips:SetHitRectInsets(0, -(row.tipsLabel:GetStringWidth() + 2), 0, 0)
      row.tips:SetScript("OnClick", function(self)
        if self:GetChecked() then tooltipOff()[self.addonKey] = nil
        else tooltipOff()[self.addonKey] = true end
      end)
      row.name:SetPoint("RIGHT", row.tips, "LEFT", -2, 0)
      row.name:SetJustifyH("LEFT")
      row.settings = CreateButton(row, "Settings", 72, 22)
      row.settings:SetPoint("RIGHT", row, "RIGHT", -5, 0)
      rows[i] = row
    end
    row:ClearAllPoints()
    row:SetPoint("TOPLEFT", content, "TOPLEFT", 0, -((i - 1) * 42))
    local open = settingsFor(item)
    row.settings:SetScript("OnClick", open)
    if open then row.settings:Enable() else row.settings:Disable() end
    row.tips.addonKey = Normalize(addon.folder)
    row.tips:SetChecked(not tooltipOff()[row.tips.addonKey])
    row.name:SetText(addon.title)
    row.folder:SetText(addon.folder)
    if addon.protected then
      row.state:SetText("Manager")
      row.action:SetText("Protected")
      row.action:Disable()
      row.action:SetScript("OnClick", nil)
    else
      row.state:SetText(addon.state)
      if addon.enabled == true then
        row.action:SetText("Disable")
        row.action:Enable()
        row.action:SetScript("OnClick", function()
          if ChangeAddonState(item, false) then UpdateRows() end
        end)
      else
        row.action:SetText("Enable")
        row.action:Enable()
        row.action:SetScript("OnClick", function()
          if ChangeAddonState(item, true) then UpdateRows() end
        end)
      end
      local api = C_AddOns or _G
      if not ((api and api.EnableAddOn) or EnableAddOn) or not ((api and api.DisableAddOn) or DisableAddOn) then
        row.action:Disable()
      end
    end
    row:Show()
  end
  content:SetHeight(count(addons) * 42)
end

local refresh = CreateButton(addonsPage, "Refresh", 78, 22)
refresh:SetPoint("BOTTOMLEFT", addonsPage, "BOTTOMLEFT", 2, -27)
refresh:SetScript("OnClick", UpdateRows)

local reload = CreateButton(addonsPage, "Reload UI", 90, 22)
reload:SetPoint("BOTTOMRIGHT", addonsPage, "BOTTOMRIGHT", -3, -27)
reload:SetScript("OnClick", function()
  if ReloadUI then ReloadUI() end
end)

local reloadHint = MakeText(addonsPage, "Enable/disable changes apply after reloading.", 9, 0.7, 0.7, 0.7)
reloadHint:SetPoint("BOTTOM", addonsPage, "BOTTOM", 0, -25)

-- Profiles store only manager-owned settings, never another addon's SavedVariables.
do
  local function Profiles()
    local db = ShadyIncAddonManagerDB
    if db.profiles == nil then db.profiles = {} end
    if type(db.profiles) == "table" then return db.profiles end
  end
  local function Trim(s)
    return (s or ""):match("^%s*(.-)%s*$")
  end
  local function Snapshot()
    local result = { addons = {} }
    local hidden = tooltipOff()
    for _, addon in ipairs(GetOwnedAddons()) do
      local key = Normalize(addon.folder)
      if not addon.protected then
        result.addons[key] = { enabled = addon.enabled, hideTooltip = hidden[key] == true }
      end
    end
    return result
  end
  local function Counts(profile)
    local on, off, unknown = 0, 0, 0
    if type(profile) == "table" and type(profile.addons) == "table" then
      for _, entry in pairs(profile.addons) do
        if type(entry) == "table" and entry.enabled == true then on = on + 1
        elseif type(entry) == "table" and entry.enabled == false then off = off + 1
        else unknown = unknown + 1 end
      end
    end
    return on, off, unknown
  end
  local heading = MakeText(profilesPage, "Addon Profiles", 13, 0.95, 0.78, 0.25)
  heading:SetPoint("TOPLEFT", profilesPage, "TOPLEFT", 4, -2)
  local note = MakeText(profilesPage, "Save enabled addons and tooltip choices. Apply to this character, then reload.", 10, 0.76, 0.76, 0.76)
  note:SetPoint("TOPLEFT", profilesPage, "TOPLEFT", 4, -22)
  local nameBox = CreateFrame("EditBox", nil, profilesPage, "InputBoxTemplate")
  nameBox:SetSize(245, 24)
  nameBox:SetPoint("TOPLEFT", profilesPage, "TOPLEFT", 10, -44)
  nameBox:SetAutoFocus(false)
  nameBox:SetMaxLetters(40)
  nameBox:SetScript("OnEscapePressed", function(self) self:ClearFocus() end)
  local save = CreateButton(profilesPage, "Save New Profile", 144, 24)
  save:SetPoint("LEFT", nameBox, "RIGHT", 8, 0)
  local inputHint = MakeText(profilesPage, "Enter a name", 10, 0.68, 0.68, 0.68)
  inputHint:SetPoint("LEFT", save, "RIGHT", 7, 0)
  local scroll = CreateFrame("ScrollFrame", "ShadyIncAddonManagerProfilesScroll", profilesPage, "UIPanelScrollFrameTemplate")
  scroll:SetPoint("TOPLEFT", profilesPage, "TOPLEFT", 3, -79)
  scroll:SetPoint("BOTTOMRIGHT", profilesPage, "BOTTOMRIGHT", -24, 63)
  local list = CreateFrame("Frame", nil, scroll)
  list:SetSize(510, 1)
  scroll:SetScrollChild(list)
  local apply = CreateButton(profilesPage, "Apply", 90, 24)
  apply:SetPoint("BOTTOMLEFT", profilesPage, "BOTTOMLEFT", 3, 32)
  local update = CreateButton(profilesPage, "Update", 90, 24)
  update:SetPoint("LEFT", apply, "RIGHT", 5, 0)
  local delete = CreateButton(profilesPage, "Delete", 90, 24)
  delete:SetPoint("LEFT", update, "RIGHT", 5, 0)
  local reloadProfile = CreateButton(profilesPage, "Reload UI", 90, 24)
  reloadProfile:SetPoint("BOTTOMRIGHT", profilesPage, "BOTTOMRIGHT", -3, 32)
  reloadProfile:SetScript("OnClick", function() if ReloadUI then ReloadUI() end end)
  local statusText = MakeText(profilesPage, "", 10, 0.82, 0.82, 0.82)
  statusText:SetPoint("BOTTOMLEFT", profilesPage, "BOTTOMLEFT", 4, 4)
  statusText:SetPoint("BOTTOMRIGHT", profilesPage, "BOTTOMRIGHT", -4, 4)
  statusText:SetJustifyH("LEFT")
  local selected, pending
  local profileRows = {}
  local function Status(message) statusText:SetText(message) end
  local function RefreshProfiles()
    local profiles = Profiles()
    local names = {}
    if profiles then
      for name, profile in pairs(profiles) do
        if type(name) == "string" and type(profile) == "table" and type(profile.addons) == "table" then
          names[#names + 1] = name
        end
      end
    end
    table.sort(names, function(a, b) return a:lower() < b:lower() end)
    if not profiles or not selected or type(profiles[selected]) ~= "table" or type(profiles[selected].addons) ~= "table" then selected = nil end
    for _, row in ipairs(profileRows) do row:Hide() end
    for i, name in ipairs(names) do
      local profileName = name
      local row = profileRows[i]
      if not row then
        row = CreateFrame("Frame", nil, list)
        row:SetSize(510, 29)
        row.bg = row:CreateTexture(nil, "BACKGROUND")
        row.bg:SetAllPoints(row)
        row.button = CreateButton(row, "", 285, 23)
        row.button:SetPoint("LEFT", row, "LEFT", 3, 0)
        row.summary = MakeText(row, "", 10, 0.85, 0.85, 0.85)
        row.summary:SetPoint("LEFT", row.button, "RIGHT", 10, 0)
        profileRows[i] = row
      end
      row:ClearAllPoints()
      row:SetPoint("TOPLEFT", list, "TOPLEFT", 0, -(i - 1) * 30)
      row.bg:SetColorTexture(1, 1, 1, selected == name and 0.13 or 0.045)
      row.button:SetText((selected == name and "> " or "") .. name)
      row.button:SetScript("OnClick", function()
        selected, pending = profileName, nil
        Status("Selected: " .. profileName)
        RefreshProfiles()
      end)
      local on, off, unknown = Counts(profiles[name])
      row.summary:SetText(on .. " on / " .. off .. " off" .. (unknown > 0 and (" / " .. unknown .. " ?") or ""))
      row:Show()
    end
    list:SetHeight(math.max(1, #names * 30))
    for _, button in ipairs({apply, update, delete}) do
      if selected then button:Enable() else button:Disable() end
    end
    if profiles then save:Enable() else save:Disable() end
    update:SetText(pending == "update" and "Confirm" or "Update")
    delete:SetText(pending == "delete" and "Confirm" or "Delete")
  end
  local function SaveNew()
    pending = nil
    local profiles = Profiles()
    if not profiles then Status("Profile storage is unreadable; existing data left untouched.") return end
    local name = Trim(nameBox:GetText())
    if name == "" or name:find("[%c|]") or #name > 160 then Status("Enter a valid profile name.") RefreshProfiles() return end
    for existing in pairs(profiles) do
      if type(existing) == "string" and existing:lower() == name:lower() then
        Status("Name already exists. Select that profile and use Update.") RefreshProfiles() return
      end
    end
    local snapshot = Snapshot()
    if not next(snapshot.addons) then Status("No managed addons found; nothing saved.") RefreshProfiles() return end
    profiles[name] = snapshot
    selected = name
    nameBox:SetText("")
    nameBox:ClearFocus()
    Status("Saved: " .. name)
    RefreshProfiles()
  end
  save:SetScript("OnClick", SaveNew)
  nameBox:SetScript("OnEnterPressed", SaveNew)
  update:SetScript("OnClick", function()
    local profiles = Profiles()
    if not selected or not profiles or not profiles[selected] then return end
    if pending ~= "update" then
      pending = "update" Status("Click Confirm to replace this profile with current choices.") RefreshProfiles() return
    end
    local snapshot = Snapshot()
    if not next(snapshot.addons) then pending = nil Status("No managed addons found; profile unchanged.") RefreshProfiles() return end
    -- Keep entries for addons that are not currently installed.
    local old = profiles[selected].addons
    for key, entry in pairs(old) do
      if not snapshot.addons[key] then snapshot.addons[key] = entry
      elseif snapshot.addons[key].enabled == nil and type(entry) == "table" then
        snapshot.addons[key].enabled = entry.enabled
      end
    end
    profiles[selected] = snapshot
    pending = nil Status("Updated: " .. selected) RefreshProfiles()
  end)
  delete:SetScript("OnClick", function()
    local profiles = Profiles()
    if not selected or not profiles or not profiles[selected] then return end
    if pending ~= "delete" then
      pending = "delete" Status("Click Confirm to delete the saved profile, not your addons.") RefreshProfiles() return
    end
    profiles[selected] = nil
    selected, pending = nil, nil
    Status("Profile deleted. Current addon choices unchanged.") RefreshProfiles()
  end)
  apply:SetScript("OnClick", function()
    local profiles = Profiles()
    local profile = profiles and selected and profiles[selected]
    if type(profile) ~= "table" or type(profile.addons) ~= "table" then return end
    pending = nil
    if InCombatLockdown and InCombatLockdown() then Status("Leave combat before applying a profile.") RefreshProfiles() return end
    local desired, attempted = {}, {}
    local hidden = tooltipOff()
    for _, addon in ipairs(GetOwnedAddons()) do
      local key = Normalize(addon.folder)
      local entry = profile.addons[key]
      if not addon.protected and type(entry) == "table" then
        if type(entry.hideTooltip) == "boolean" then hidden[key] = entry.hideTooltip and true or nil end
        if type(entry.enabled) == "boolean" then
          desired[key] = entry.enabled
          if addon.enabled ~= entry.enabled then
            attempted[key] = ChangeAddonState(addon, entry.enabled)
          end
        end
      end
    end
    local changed, failed = 0, 0
    local current = {}
    for _, addon in ipairs(GetOwnedAddons()) do current[Normalize(addon.folder)] = addon.enabled end
    for key, wanted in pairs(desired) do
      if current[key] ~= wanted or attempted[key] == false then failed = failed + 1
      elseif attempted[key] then changed = changed + 1 end
    end
    UpdateRows()
    Status("Applied: " .. selected .. " | " .. changed .. " changed, " .. failed .. " unverified. Reload UI.")
    RefreshProfiles()
  end)
  profilesPage:SetScript("OnShow", function()
    pending = nil
    RefreshProfiles()
    if not Profiles() then Status("Profile storage is unreadable; existing data left untouched.")
    elseif selected then Status("Selected: " .. selected)
    else Status("Enter a name and save your current addon choices.") end
  end)
end

local optionsTitle = MakeText(optionsPage, "Window", 13, 0.95, 0.78, 0.25)
optionsTitle:SetPoint("TOPLEFT", optionsPage, "TOPLEFT", 5, -8)

local opaque = CreateFrame("CheckButton", "ShadyIncAddonManagerOpaqueCheck", optionsPage, "UICheckButtonTemplate")
opaque:SetPoint("TOPLEFT", optionsPage, "TOPLEFT", 0, -34)
local checkLabel = opaque.Text or _G[opaque:GetName() .. "Text"] or MakeText(optionsPage, "", 12)
checkLabel:SetPoint("LEFT", opaque, "RIGHT", 0, 0)
checkLabel:SetText("Solid settings window")
opaque:SetScript("OnClick", function(self)
  ShadyIncAddonManagerDB.opaque = self:GetChecked() and true or false
  if ShadyIncAddonManagerDB.opaque then
    frame.backdrop:SetColorTexture(0, 0, 0, 1)
  else
    frame.backdrop:SetColorTexture(0, 0, 0, 0.86)
  end
end)

local credit = MakeText(optionsPage, "Made for your Shady Inc addons.", 11, 0.76, 0.76, 0.76)
credit:SetPoint("TOPLEFT", optionsPage, "TOPLEFT", 6, -78)

local memorial = MakeText(optionsPage, "RIP Shady", 10, 0.72, 0.55, 0.2, "Interface\\AddOns\\RIPShady\\Morpheus.ttf")
memorial:SetPoint("BOTTOM", optionsPage, "BOTTOM", 0, 5)

local perfTitle = MakeText(performancePage, "Addon Performance", 13, 0.95, 0.78, 0.25)
perfTitle:SetPoint("TOPLEFT", performancePage, "TOPLEFT", 4, -2)

local perfLive = MakeText(performancePage, "FPS: --   Home: -- ms   World: -- ms", 11, 0.86, 0.86, 0.86)
perfLive:SetPoint("TOPLEFT", performancePage, "TOPLEFT", 4, -22)

local perfNote = MakeText(performancePage, "", 9, 0.7, 0.7, 0.7)
perfNote:SetPoint("TOPLEFT", performancePage, "TOPLEFT", 4, -42)
perfNote:SetText("Slow intervals count periods with a frame >50 ms and addon CPU >5 ms.\nHome/World ping is network-wide and cannot be assigned to one addon.")

local perfStatus = MakeText(performancePage, "Start a 30-second sample during your usual play.", 10, 0.8, 0.8, 0.8)
perfStatus:SetPoint("TOPLEFT", performancePage, "TOPLEFT", 4, -72)

local perfScroll = CreateFrame("ScrollFrame", "ShadyIncAddonManagerPerfScroll", performancePage, "UIPanelScrollFrameTemplate")
perfScroll:SetPoint("TOPLEFT", performancePage, "TOPLEFT", 0, -94)
perfScroll:SetPoint("BOTTOMRIGHT", performancePage, "BOTTOMRIGHT", -24, 34)
local perfContent = CreateFrame("Frame", nil, perfScroll)
perfContent:SetWidth(360)
perfContent:SetHeight(1)
perfScroll:SetScrollChild(perfContent)

local perfRows = {}
local perfBaseline = {}
local perfHitchBaseline = {}
local perfResults = {}
local perfSampleCounts = {}
local frozen, frames, slowFrames, summary = nil, {}, 0, ""
local overlap, previous5, slowWindows, windowSlow = {}, {}, 0, false
local firstUpdate = false
local perfRunning = false
local perfSampleComplete = false
local perfMinFPS = nil
local perfElapsed = 0
local perfUpdateElapsed = 0
local liveUpdateElapsed = 0
local sampleButton = CreateButton(performancePage, "Start 30s Sample", 122, 22)
sampleButton:SetPoint("BOTTOMLEFT", performancePage, "BOTTOMLEFT", 2, -27)
local profilerButton = CreateButton(performancePage, "", 126, 22)
profilerButton:SetPoint("BOTTOMRIGHT", performancePage, "BOTTOMRIGHT", -3, -27)

local function GetProfilerMode()
  if C_AddOnProfiler and type(C_AddOnProfiler.GetAddOnMetric) == "function"
      and (not C_AddOnProfiler.IsEnabled or C_AddOnProfiler.IsEnabled())
      and Enum and Enum.AddOnProfilerMetric and Enum.AddOnProfilerMetric.RecentAverageTime ~= nil then
    return "native"
  end
  if type(UpdateAddOnCPUUsage) == "function" and type(GetAddOnCPUUsage) == "function" then
    return "legacy"
  end
  return nil
end

local function HasCPUProfiler()
  return GetProfilerMode() ~= nil
end

local function IsCPUProfilingEnabled()
  if GetProfilerMode() == "native" then return true end
  if GetProfilerMode() ~= "legacy" then return false end
  return GetCVar and GetCVar("scriptProfile") == "1"
end

local function ReadNativeMetric(addonName, metricName)
  if not C_AddOnProfiler or not Enum or not Enum.AddOnProfilerMetric then return nil end
  local metric = Enum.AddOnProfilerMetric[metricName]
  if metric == nil then return nil end
  local ok, value = pcall(C_AddOnProfiler.GetAddOnMetric, addonName, metric)
  if ok then return value end
  return nil
end

local function ReadMetrics(addons)
  local profilerMode = GetProfilerMode()
  if profilerMode == "legacy" and IsCPUProfilingEnabled() then pcall(UpdateAddOnCPUUsage) end
  for i = 1, count(addons) do
    local addon = addons[i]
    addon.cpuMS = nil
    addon.cpuRecent = nil
    addon.cpuPeak = nil
    addon.hitch5 = nil
    addon.hitch10 = nil
    addon.hitch50 = nil
    if profilerMode == "native" then
      addon.cpuRecent = ReadNativeMetric(addon.folder, "RecentAverageTime")
      addon.cpuPeak = ReadNativeMetric(addon.folder, "PeakTime")
      if addon.cpuRecent then
        if perfRunning then
          local count = (perfSampleCounts[addon.folder] or 0) + 1
          local previous = perfResults[addon.folder] or 0
          perfResults[addon.folder] = previous + ((addon.cpuRecent - previous) / count)
          perfSampleCounts[addon.folder] = count
        end
      end
      if (perfRunning or perfSampleComplete) and perfHitchBaseline[addon.folder] then
        local base = perfHitchBaseline[addon.folder]
        local over5 = ReadNativeMetric(addon.folder, "CountTimeOver5Ms")
        local over10 = ReadNativeMetric(addon.folder, "CountTimeOver10Ms")
        local over50 = ReadNativeMetric(addon.folder, "CountTimeOver50Ms")
        if perfRunning and windowSlow and over5 and previous5[addon.folder] then
          overlap[addon.folder] = (overlap[addon.folder] or 0) + (over5 > previous5[addon.folder] and 1 or 0)
        end
        if over5 then previous5[addon.folder] = over5 end
        if over5 and base.over5 then addon.hitch5 = math.max(0, over5 - base.over5) end
        if over10 and base.over10 then addon.hitch10 = math.max(0, over10 - base.over10) end
        if over50 and base.over50 then addon.hitch50 = math.max(0, over50 - base.over50) end
      end
    elseif profilerMode == "legacy" and IsCPUProfilingEnabled() then
      local ok, value = pcall(GetAddOnCPUUsage, addon.index)
      if ok and value then addon.cpuMS = value end
      if perfRunning and addon.cpuMS then
        local start = perfBaseline[addon.folder]
        if start then
          perfResults[addon.folder] = math.max(0, addon.cpuMS - start) / math.max(perfElapsed, 1)
        end
      end
    end
  end
  return addons
end

local function UpdatePerfRows()
  local addons = frozen or ReadMetrics(GetOwnedAddons())
  if perfSampleComplete then frozen = addons end
  local profilerMode = GetProfilerMode()
  local profiled = HasCPUProfiler() and IsCPUProfilingEnabled()
  if profiled then
    table.sort(addons, function(a, b)
      if (overlap[a.folder] or 0) ~= (overlap[b.folder] or 0) then return (overlap[a.folder] or 0) > (overlap[b.folder] or 0) end
      local aValue = perfResults[a.folder] or a.cpuRecent or -1
      local bValue = perfResults[b.folder] or b.cpuRecent or -1
      return aValue > bValue
    end)
  else
    table.sort(addons, function(a, b) return string.lower(a.title) < string.lower(b.title) end)
  end

  for i = 1, count(perfRows) do perfRows[i]:Hide() end
  for i = 1, count(addons) do
    local addon = addons[i]
    local row = perfRows[i]
    if not row then
      row = CreateFrame("Frame", nil, perfContent)
      row:SetWidth(360)
      row:SetHeight(38)
      row.bg = row:CreateTexture(nil, "BACKGROUND")
      row.bg:SetAllPoints(row)
      row.bg:SetColorTexture(1, 1, 1, 0.045)
      row.name = MakeText(row, "", 11, 0.95, 0.9, 0.72)
      row.name:SetPoint("TOPLEFT", row, "TOPLEFT", 8, -5)
      row.folder = MakeText(row, "", 9, 0.67, 0.67, 0.67)
      row.folder:SetPoint("BOTTOMLEFT", row, "BOTTOMLEFT", 8, 5)
      row.avg = MakeText(row, "", 9, 0.8, 0.86, 0.8)
      row.avg:SetPoint("TOPRIGHT", row, "TOPRIGHT", -8, -5)
      row.hitches = MakeText(row, "", 9, 0.8, 0.8, 0.8)
      row.hitches:SetPoint("BOTTOMRIGHT", row, "BOTTOMRIGHT", -8, 5)
      perfRows[i] = row
    end
    row:ClearAllPoints()
    row:SetPoint("TOPLEFT", perfContent, "TOPLEFT", 0, -((i - 1) * 42))
    row.name:SetText(addon.title)
    row.folder:SetText(slowWindows > 0 and string.format("Slow intervals: %s/%d", tostring(overlap[addon.folder] or "--"), slowWindows) or addon.folder)
    local cpu = perfResults[addon.folder] or addon.cpuRecent
    if profiled and cpu and profilerMode == "native" then
      row.avg:SetText(string.format("Avg %.3f ms/tick  |  Session peak %.2f ms", cpu, addon.cpuPeak or 0))
      if addon.hitch5 ~= nil then
        row.hitches:SetText(string.format("Hitches >5 / >10 / >50 ms: %d / %d / %d", addon.hitch5 or 0, addon.hitch10 or 0, addon.hitch50 or 0))
      else
        row.hitches:SetText(perfSampleComplete and "Hitch counts unavailable" or "Run sample to count hitches")
      end
    elseif profiled and cpu then
      row.avg:SetText(string.format("Avg %.1f ms/s", cpu))
      row.hitches:SetText("Hitch counters unavailable on legacy profiler")
    elseif profiled then
      local unit = profilerMode == "native" and "ms/tick" or "ms/s"
      row.avg:SetText("Avg -- " .. unit)
      row.hitches:SetText(perfSampleComplete and "Hitch counts unavailable" or "Run sample to count hitches")
    else
      row.avg:SetText("Avg --")
      row.hitches:SetText("Hitch counts unavailable")
    end
    row:Show()
  end
  perfContent:SetHeight(math.max(count(addons) * 42, 1))

  if perfRunning then
    local unit = profilerMode == "native" and "recent CPU ms/tick" or "CPU ms/s"
    perfStatus:SetText(string.format("Sampling: %d / 30 sec   (%s, lower is lighter)", math.min(math.floor(perfElapsed), 30), unit))
    sampleButton:SetText("Stop Sample")
  elseif not HasCPUProfiler() then
    perfStatus:SetText("This WoW client does not expose addon CPU profiling.")
    sampleButton:SetText("CPU Profiling Unavailable")
    sampleButton:Disable()
  elseif not IsCPUProfilingEnabled() then
    perfStatus:SetText("CPU profiling is off. Enable it, then reload to collect CPU time.")
    sampleButton:SetText("Start 30s Sample")
    sampleButton:Disable()
  else
    if perfSampleComplete then
      if summary ~= "" then perfStatus:SetText(summary)
      elseif profilerMode == "native" then
        perfStatus:SetText(string.format("Sample complete. Min FPS %.0f; hitch counts cover this sample.", perfMinFPS or 0))
      else
        perfStatus:SetText("Sample complete. Ranked by average CPU ms/s.")
      end
    elseif profilerMode == "native" then
      perfStatus:SetText("Recent CPU average, session peak, and sample-only hitch counts.")
    else
      perfStatus:SetText("CPU ms/s averaged across the sample; memory is shown for context.")
    end
    sampleButton:SetText("Start 30s Sample")
    sampleButton:Enable()
  end

  if profilerMode == "native" then
    profilerButton:SetText("Native Profiler Active")
    profilerButton:Disable()
  elseif IsCPUProfilingEnabled() then
    profilerButton:SetText("Turn Profiling Off")
    profilerButton:Enable()
  else
    profilerButton:SetText("Enable CPU Profiling")
    if profilerMode == "legacy" and SetCVar and GetCVar then profilerButton:Enable() else profilerButton:Disable() end
  end
end

local function UpdateLivePerformance()
  local fps = GetFramerate and GetFramerate() or 0
  if perfRunning and (not perfMinFPS or fps < perfMinFPS) then perfMinFPS = fps end
  local home, world = nil, nil
  if GetNetStats then
    local _, _, homeLatency, worldLatency = GetNetStats()
    home, world = homeLatency, worldLatency
  end
  perfLive:SetText(string.format("FPS: %.0f   Home: %s ms   World: %s ms", fps,
    home and tostring(home) or "--", world and tostring(world) or "--"))
end

local report = CreateFrame("Frame", "ShadyIncHealthReport", UIParent)
report:SetSize(390, 196)
report:SetPoint("CENTER")
report:SetFrameStrata("FULLSCREEN_DIALOG")
report:SetClampedToScreen(true)
report:EnableMouse(true)
local panel = report:CreateTexture(nil, "BACKGROUND")
panel:SetAllPoints()
panel:SetColorTexture(0.06, 0.05, 0.04, 1)
local heading = MakeText(report, "Sample results", 16, 1, 0.8, 0.35)
heading:SetPoint("TOP", 0, -14)
local body = report:CreateFontString(nil, "OVERLAY", "GameFontHighlight")
body:SetPoint("TOPLEFT", 14, -40)
body:SetPoint("BOTTOMRIGHT", -14, 40)
local dismiss = CreateButton(report, "Close", 80, 22)
dismiss:SetPoint("BOTTOM", 0, 10)
dismiss:SetScript("OnClick", function() report:Hide() end)
report:Hide()

local reopen = CreateButton(performancePage, "Last Result", 100, 22)
reopen:SetPoint("BOTTOM", performancePage, "BOTTOM", 0, -27)
reopen:Disable()
local function openReport()
  report:Show()
  report:Raise()
end
reopen:SetScript("OnClick", openReport)

-- Time weighting makes one long freeze count for its entire duration.
local function showHealthReport()
  local text
  if perfElapsed < 5 or #frames == 0 then
    text = "Sample too short to score. Record at least 5 seconds."
  else
    local smoothMS, totalMS = 0, 0
    for _, ms in ipairs(frames) do
      totalMS = totalMS + ms
      if ms <= 1000 / 30 then smoothMS = smoothMS + ms end
    end
    text = string.format("|cffffd060Frame health   %.1f%%|r\nTime in frames at 30 FPS or better\n\n%s", 100 * smoothMS / totalMS, summary)
    local top
    for _, addon in ipairs(frozen or {}) do
      if not top or (overlap[addon.folder] or 0) > (overlap[top.folder] or 0) then top = addon end
    end
    if top and (overlap[top.folder] or 0) > 0 then
      text = text .. string.format("\n\n%s exceeded 5 ms in %d of %d slow intervals.", top.title, overlap[top.folder], slowWindows)
    elseif slowWindows > 0 and GetProfilerMode() == "native" then
      text = text .. "\n\nNo matching addon spike recorded."
    end
  end
  body:SetText(text)
  reopen:Enable()
  openReport()
end

local quick = CreateButton(UIParent, "Sample", 64, 23)
quick:Hide()
quick:SetMovable(true)
quick:SetClampedToScreen(true)
quick:RegisterForDrag("LeftButton")
local moved = false
quick:SetScript("OnMouseDown", function() moved = false end)
quick:SetScript("OnDragStart", function(self)
  moved = true
  self:StartMoving()
end)
quick:SetScript("OnDragStop", function(self)
  self:StopMovingOrSizing()
  local x, y = self:GetCenter()
  if x and y then
    ShadyIncAddonManagerDB.sampleX = x / UIParent:GetWidth()
    ShadyIncAddonManagerDB.sampleY = y / UIParent:GetHeight()
  end
end)

local visibility = CreateButton(optionsPage, "", 180, 24)
visibility:SetPoint("TOPLEFT", optionsPage, "TOPLEFT", 4, -105)
local function syncLauncher()
  local db = ShadyIncAddonManagerDB
  quick:ClearAllPoints()
  if type(db.sampleX) == "number" and type(db.sampleY) == "number" then
    quick:SetPoint("CENTER", UIParent, "BOTTOMLEFT", db.sampleX * UIParent:GetWidth(), db.sampleY * UIParent:GetHeight())
  else
    quick:SetPoint("RIGHT", UIParent, "RIGHT", -40, -80)
  end
  quick:SetShown(db.showSample ~= false)
  visibility:SetText(db.showSample == false and "Show Sample button" or "Hide Sample button")
end
visibility:SetScript("OnClick", function()
  ShadyIncAddonManagerDB.showSample = ShadyIncAddonManagerDB.showSample == false
  syncLauncher()
end)

local function finishSample()
  if windowSlow then slowWindows = slowWindows + 1 end
  -- Capture the final counters while running, then freeze the rows for display.
  frozen = ReadMetrics(GetOwnedAddons())
  perfRunning = false
  perfSampleComplete = true
  quick:SetText("Sample")
  table.sort(frames)
  if #frames > 0 then
    summary = string.format("%.1fs   Worst %.1f ms   P99 %.1f ms   Frames >50 ms: %d",
      perfElapsed, frames[#frames], frames[math.ceil(#frames * 0.99)], slowFrames)
  else
    summary = "Sample ended before the first full frame."
  end
  showHealthReport()
  UpdatePerfRows()
end

local function startSample()
  local profilerMode = GetProfilerMode()
  if not profilerMode or not IsCPUProfilingEnabled() then
    print("Shady Inc: Open /shadyinc > Performance to check CPU profiling.")
    return
  end
  report:Hide()
  frozen, frames, slowFrames, summary = nil, {}, 0, ""
  overlap, previous5, slowWindows, windowSlow = {}, {}, 0, false
  firstUpdate = true
  perfBaseline = {}
  perfHitchBaseline = {}
  perfResults = {}
  perfSampleCounts = {}
  perfSampleComplete = false
  perfMinFPS = GetFramerate and GetFramerate() or nil
  perfElapsed = 0
  perfUpdateElapsed = 0
  local addons = GetOwnedAddons()
  if profilerMode == "native" then
    for i = 1, count(addons) do
      local addon = addons[i]
      perfHitchBaseline[addon.folder] = {
        over5 = ReadNativeMetric(addon.folder, "CountTimeOver5Ms"),
        over10 = ReadNativeMetric(addon.folder, "CountTimeOver10Ms"),
        over50 = ReadNativeMetric(addon.folder, "CountTimeOver50Ms"),
      }
    end
  elseif profilerMode == "legacy" then
    pcall(UpdateAddOnCPUUsage)
    for i = 1, count(addons) do
      local addon = addons[i]
      local ok, value = pcall(GetAddOnCPUUsage, addon.index)
      if ok and value then perfBaseline[addon.folder] = value end
    end
  end
  perfRunning = true
  quick:SetText("30s")
  UpdatePerfRows()
end
sampleButton:SetScript("OnClick", function()
  if perfRunning then finishSample() else startSample() end
end)
quick:SetScript("OnClick", function()
  if not moved and not perfRunning then startSample() end
end)

profilerButton:SetScript("OnClick", function()
  if not SetCVar or not GetCVar then return end
  if GetProfilerMode() == "native" then return end
  if IsCPUProfilingEnabled() then
    SetCVar("scriptProfile", "0")
  else
    SetCVar("scriptProfile", "1")
  end
  if ReloadUI then ReloadUI() end
end)

local perfTicker = CreateFrame("Frame")
perfTicker:SetScript("OnUpdate", function(self, elapsed)
  if not perfRunning and not performancePage:IsVisible() then return end
  liveUpdateElapsed = liveUpdateElapsed + elapsed
  if liveUpdateElapsed >= 1 then
    liveUpdateElapsed = 0
    if performancePage:IsVisible() then UpdateLivePerformance() end
  end
  if not perfRunning or elapsed <= 0 then return end
  if firstUpdate then firstUpdate = false return end
  local ms = elapsed * 1000
  frames[#frames + 1] = ms
  if ms > 50 then slowFrames = slowFrames + 1 windowSlow = true end
  perfElapsed = perfElapsed + elapsed
  perfUpdateElapsed = perfUpdateElapsed + elapsed
  if perfElapsed >= 30 then
    finishSample()
  elseif perfUpdateElapsed >= 1 then
    quick:SetText(math.ceil(30 - perfElapsed) .. "s")
    if windowSlow then slowWindows = slowWindows + 1 end
    UpdatePerfRows()
    perfUpdateElapsed, windowSlow = 0, false
  end
end)

local status = MakeText(frame, "", 10, 0.7, 0.7, 0.7)
status:SetPoint("BOTTOM", frame, "BOTTOM", 0, 10)

local function ApplyOpacity()
  if ShadyIncAddonManagerDB.opaque then
    frame.backdrop:SetColorTexture(0, 0, 0, 1)
    opaque:SetChecked(1)
  else
    frame.backdrop:SetColorTexture(0, 0, 0, 0.86)
    opaque:SetChecked(nil)
  end
end

local function Toggle()
  if frame:IsShown() then
    frame:Hide()
  else
    frame:Show()
    ApplyOpacity()
    UpdateRows()
    SetTab("addons")
  end
end

SLASH_SHADYINCADDONMANAGER1 = "/shadyinc"
SLASH_SHADYINCADDONMANAGER2 = "/shadyaddons"
SLASH_SHADYINCADDONMANAGER3 = "/sim"
SlashCmdList["SHADYINCADDONMANAGER"] = Toggle

local events = CreateFrame("Frame")
events:RegisterEvent("PLAYER_LOGIN")
events:SetScript("OnEvent", function()
  syncLauncher()
  ApplyOpacity()
  UpdateRows()
  UpdatePerfRows()
end)
