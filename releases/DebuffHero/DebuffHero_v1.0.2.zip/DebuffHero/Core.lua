local addon = ...
local event = CreateFrame('Frame')
local defaults = {enabled=true, scale=1.35, x=0, y=8, minimap=true, timerSize=13, timerStyle='Both', spacing=4, anchor='Above'}
local db, panel, refreshPreview
local originals = setmetatable({}, {__mode='k'})
local fonts = setmetatable({}, {__mode='k'})
local pending = false
local function safe(v) return not issecretvalue or not issecretvalue(v) end
local function number(v) return safe(v) and type(v)=='number' end
local function canStyle(f)
 if not InCombatLockdown() then return true end
 if not f or not safe(f) then return false end
 for _,method in ipairs({'IsProtected','IsForbidden'}) do
  if type(f[method])=='function' then local ok,v=pcall(f[method],f); if not ok or not safe(v) or v then return false end end
 end
 return true
end
local function call(o,m,...) if not o or type(o[m])~='function' then return false end return pcall(o[m],o,...) end
local function get(o,m,...) local ok,v=call(o,m,...); if ok and safe(v) then return v end end
local function remember(f)
 if originals[f] then return originals[f] end
 local s=get(f,'GetScale'); local n=get(f,'GetNumPoints'); if not number(s) or not number(n) then return end
 local p={}; for i=1,n do local ok,a,b,c,x,y=call(f,'GetPoint',i); if not ok or not safe(a) or not safe(b) or not safe(c) or not number(x) or not number(y) then return end; p[i]={a,b,c,x,y} end
 local r={scale=s,points=p}; originals[f]=r; return r
end
local function restore(f,r)
 if not canStyle(f) then pending=true; return false end
 call(f,'SetScale',r.scale); if #r.points>0 then call(f,'ClearAllPoints'); for _,p in ipairs(r.points) do call(f,'SetPoint',unpack(p)) end end
 return true
end
local function fontStyle(cd)
 local fs=get(cd,'GetCountdownFontString'); if not fs or not canStyle(fs) then return end
 if not fonts[fs] then local ok,a,b,c=call(fs,'GetFont'); if ok and safe(a) and number(b) and safe(c) and a then fonts[fs]={a,b,c} end end
 local v=fonts[fs]; if v then call(fs,'SetFont',v[1],db.timerSize,'OUTLINE') end
end
local cooldowns=setmetatable({}, {__mode='k'})
local function styleCooldown(cd)
 if not cd or not canStyle(cd) then return end
 if not cooldowns[cd] then cooldowns[cd]={swipe=get(cd,'GetDrawSwipe'),hide=get(cd,'GetHideCountdownNumbers')} end
 -- Only change properties whose original state can be read and restored.
 local r=cooldowns[cd]
 if type(r.swipe)=='boolean' then call(cd,'SetDrawSwipe',db.timerStyle~='Numeric') end
 if type(r.hide)=='boolean' then call(cd,'SetHideCountdownNumbers',db.timerStyle=='Radial') end
 fontStyle(cd)
end
local function restoreAll()
 for f,r in pairs(originals) do if restore(f,r) then originals[f]=nil end end
 for f,r in pairs(fonts) do if canStyle(f) then call(f,'SetFont',unpack(r)); fonts[f]=nil else pending=true end end
 for c,r in pairs(cooldowns) do if canStyle(c) then if type(r.swipe)=='boolean' then call(c,'SetDrawSwipe',r.swipe) end; if type(r.hide)=='boolean' then call(c,'SetHideCountdownNumbers',r.hide) end; cooldowns[c]=nil else pending=true end end
end
local function walk(f,depth)
 if depth>3 or not canStyle(f) then return end
 local cd=f.Cooldown or f.cooldown; if cd then styleCooldown(cd) end
 if get(f,'GetObjectType')=='Cooldown' then styleCooldown(f) end
 local ok,children=pcall(function() return {f:GetChildren()} end); if ok then for _,c in ipairs(children) do if safe(c) then walk(c,depth+1) end end end
end
local nativeScale, nativePadding = false, false
local function nativeGet(key)
 local fn=(C_CVar and C_CVar.GetCVar) or GetCVar
 if not fn then return nil end
 local ok,v=pcall(fn,key); if ok and safe(v) then return tonumber(v) end
end
local function nativeSet(key,v)
 local fn=(C_CVar and C_CVar.SetCVar) or SetCVar
 if not fn then return false end
 local ok=pcall(fn,key,tostring(v)); local actual=nativeGet(key)
 return ok and actual~=nil and math.abs(actual-v)<.01
end
local function nativeRefresh()
 if InCombatLockdown() then return end
 db.nativeOriginal=db.nativeOriginal or {}
 for _,spec in ipairs({{'nameplateAuraScale','scale'},{'nameplateDebuffPadding','y'}}) do
  local key,setting=spec[1],spec[2]; local current=nativeGet(key)
  local success=false
  if current~=nil then
   if db.nativeOriginal[key]==nil then db.nativeOriginal[key]=current end
   local wanted=db.enabled and db[setting] or db.nativeOriginal[key]
   success=math.abs(current-wanted)<.01 or nativeSet(key,wanted)
   if not db.enabled and success then db.nativeOriginal[key]=nil end
  end
  if setting=='scale' then nativeScale=success else nativePadding=success end
 end
end
local function apply(plate,unit)
 if not plate then return end
 local token=unit or plate.namePlateUnitToken or (plate.UnitFrame and plate.UnitFrame.unit) or get(plate.UnitFrame,'GetUnit')
 if not safe(token) or type(token)~='string' then return end
 local ok,enemy=pcall(UnitCanAttack,'player',token); if not ok or not safe(enemy) or not enemy then return end
 local uf=plate.UnitFrame; if not uf then return end
 local f=(uf.AurasFrame and uf.AurasFrame.DebuffListFrame) or uf.DebuffFrame or uf.debuffFrame or uf.BuffFrame or uf.AuraFrame or uf.AurasFrame or uf.AuraContainer
 if not f or not safe(f) then return end
 if not canStyle(f) then pending=true; return end
 local r=remember(f); if not r then return end
 if not nativeScale then call(f,'SetScale',r.scale*db.scale) end
 -- Native layout retained; offsets are relative to the original anchor.
 if #r.points>0 then
  call(f,'ClearAllPoints')
  if db.anchor=='Above' then for _,p in ipairs(r.points) do call(f,'SetPoint',p[1],p[2],p[3],p[4]+db.x,p[5]+(nativePadding and 0 or db.y)) end
  elseif db.anchor=='Below' then call(f,'SetPoint','TOP',uf,'BOTTOM',db.x,-db.y)
  elseif db.anchor=='Left' then call(f,'SetPoint','RIGHT',uf,'LEFT',-db.y+db.x,0)
  else call(f,'SetPoint','LEFT',uf,'RIGHT',db.y+db.x,0) end
 end
 walk(f,0)
end
local function refresh()
 if not db then return end
 nativeRefresh(); pending=false; if not db.enabled then restoreAll(); return end
 if C_NamePlate and C_NamePlate.GetNamePlates then local ok,plates=pcall(C_NamePlate.GetNamePlates); if ok and type(plates)=='table' then for _,p in ipairs(plates) do pcall(apply,p) end end end
end
local queued=false
local dirtyUnits={}
local function refreshUnits()
 if not db or not db.enabled or not C_NamePlate or not C_NamePlate.GetNamePlateForUnit then return end
 for unit in pairs(dirtyUnits) do
  local ok,plate=pcall(C_NamePlate.GetNamePlateForUnit,unit)
  if ok and safe(plate) and plate then pcall(apply,plate,unit) end
 end
end
local function queue(unit) if safe(unit) and type(unit)=='string' and unit:match('^nameplate%d+$') then dirtyUnits[unit]=true end; if queued then return end; queued=true; C_Timer.After(.05,function() queued=false; refresh(); refreshUnits(); dirtyUnits={} end) end
local function change(k,v) db[k]=v; queue(); if refreshPreview then refreshPreview() end end
local function label(parent,text,x,y) local f=parent:CreateFontString(nil,'OVERLAY','GameFontNormal'); f:SetPoint('TOPLEFT',x,y); f:SetText(text); return f end
local function button(parent,text,w,x,y,fn) local b=CreateFrame('Button',nil,parent,'UIPanelButtonTemplate'); b:SetSize(w,24); b:SetPoint('TOPLEFT',x,y); b:SetText(text); b:SetScript('OnClick',fn); return b end
local sliders={}; local checks={}; local optionButtons={}
local function sync() for _,v in ipairs(sliders) do v.slider:SetValue(db[v.key]) end; for _,v in ipairs(checks) do v.check:SetChecked(db[v.key]) end; if refreshPreview then refreshPreview() end end
local function makePanel()
 if panel then return end
 panel=CreateFrame('Frame','DebuffHeroSettings',UIParent,'BackdropTemplate'); panel:SetSize(440,530); panel:SetPoint('CENTER'); panel:SetFrameStrata('DIALOG'); panel:SetClampedToScreen(true); panel:SetMovable(true); panel:EnableMouse(true); panel:RegisterForDrag('LeftButton'); panel:SetScript('OnDragStart',panel.StartMoving); panel:SetScript('OnDragStop',panel.StopMovingOrSizing)
 panel:SetBackdrop({bgFile='Interface/Buttons/WHITE8X8',edgeFile='Interface/Tooltips/UI-Tooltip-Border',edgeSize=14}); panel:SetBackdropColor(.065,.065,.075,1); panel:SetBackdropBorderColor(.55,.55,.55,1)
 label(panel,'Debuff Hero  |  v1.0.2',18,-16); local close=CreateFrame('Button',nil,panel,'UIPanelCloseButton'); close:SetPoint('TOPRIGHT',-3,-3); tinsert(UISpecialFrames,'DebuffHeroSettings')
 local preview=CreateFrame('Frame',nil,panel,'BackdropTemplate'); preview:SetPoint('TOPLEFT',18,-48); preview:SetSize(404,150); preview:SetBackdrop({bgFile='Interface/Buttons/WHITE8X8'}); preview:SetBackdropColor(.13,.13,.15,1)
 local bar=preview:CreateTexture(nil,'ARTWORK'); bar:SetColorTexture(.6,.15,.13,1); bar:SetSize(170,22); bar:SetPoint('CENTER',0,-15)
 local name=preview:CreateFontString(nil,'OVERLAY','GameFontHighlight'); name:SetPoint('CENTER',bar); name:SetText('Enemy Nameplate')
 local icons={}; local textures={136207,132293,136145}; for i=1,3 do local a=CreateFrame('Frame',nil,preview); local t=a:CreateTexture(nil,'ARTWORK'); t:SetAllPoints(); t:SetTexture(textures[i]); local n=a:CreateFontString(nil,'OVERLAY','GameFontHighlight'); n:SetPoint('BOTTOM',0,2); n:SetText(({34,12,4})[i]); a.n=n; icons[i]=a end
 local status=label(panel,'',18,-205)
 refreshPreview=function() local size=24*db.scale; for i,a in ipairs(icons) do a:SetSize(size,size); a:ClearAllPoints(); local x=(i-2)*(size+4)+db.x; local y=db.y; if db.anchor=='Below' then a:SetPoint('TOP',bar,'BOTTOM',x,-y) elseif db.anchor=='Left' then a:SetPoint('RIGHT',bar,'LEFT',-y+db.x-(3-i)*(size+4),0) elseif db.anchor=='Right' then a:SetPoint('LEFT',bar,'RIGHT',y+db.x+(i-1)*(size+4),0) else a:SetPoint('BOTTOM',bar,'TOP',x,y) end; a.n:SetFont(STANDARD_TEXT_FONT,db.timerSize,'OUTLINE'); a.n:SetShown(db.timerStyle~='Radial'); a:SetShown(db.enabled) end; status:SetText('Anchor: '..db.anchor..'   |   Timer: '..db.timerStyle) end
 local function check(key,text,x,y) local c=CreateFrame('CheckButton',nil,panel,'UICheckButtonTemplate'); c:SetPoint('TOPLEFT',x,y); label(c,text,29,-7); c:SetScript('OnClick',function(self) change(key,self:GetChecked() and true or false) end); checks[#checks+1]={key=key,check=c} end
 check('enabled','Enable enemy debuff styling',18,-225)
 local function slider(key,text,lo,hi,step,y) local l=label(panel,text,20,y); local s=CreateFrame('Slider',nil,panel,'OptionsSliderTemplate'); s:SetPoint('TOPLEFT',205,y+3); s:SetSize(200,18); s:SetMinMaxValues(lo,hi); s:SetValueStep(step); s:SetObeyStepOnDrag(true); s:SetScript('OnValueChanged',function(_,v) l:SetText(text..': '..string.format(step<1 and '%.2f' or '%.0f',v)); if db[key]~=v then change(key,v) end end); sliders[#sliders+1]={key=key,slider=s} end
 slider('scale','Icon scale',.7,2.5,.05,-270); slider('x','Horizontal offset',-50,50,1,-305); slider('y','Vertical offset',0,45,1,-340); slider('timerSize','Timer text size',8,24,1,-375)
 button(panel,'Anchor',110,20,-410,function() local a={'Above','Below','Left','Right'}; for i,v in ipairs(a) do if db.anchor==v then change('anchor',a[i%4+1]); break end end end)
 button(panel,'Timer style',110,140,-410,function() local a={'Both','Numeric','Radial'}; for i,v in ipairs(a) do if db.timerStyle==v then change('timerStyle',a[i%3+1]); break end end end)
 button(panel,'Reset',110,260,-410,function() restoreAll(); for k,v in pairs(defaults) do db[k]=v end; sync(); queue() end)
 label(panel,'Native scale/padding applied outside combat; persists in combat.',20,-450); label(panel,'Native aura filtering and layout are preserved.',20,-470); label(panel,'RIP Shady',20,-505); sync(); panel:Hide()
end
local function togglePanel() makePanel(); if panel:IsShown() then panel:Hide() else sync(); panel:Show() end end
local function minimap()
 local b=CreateFrame('Button','DebuffHeroMinimapButton',Minimap); b:SetSize(30,30); b:SetPoint('CENTER',Minimap,'CENTER',-70,-42); b:SetFrameStrata('MEDIUM'); b:RegisterForClicks('LeftButtonUp','RightButtonUp'); local t=b:CreateTexture(nil,'ARTWORK'); t:SetPoint('CENTER'); t:SetSize(20,20); t:SetTexture(136207); local ring=b:CreateTexture(nil,'OVERLAY'); ring:SetAllPoints(); ring:SetTexture('Interface/Minimap/MiniMap-TrackingBorder'); b:SetScript('OnClick',function(_,key) if key=='RightButton' then change('enabled',not db.enabled); if panel then sync() end; print('Debuff Hero: '..(db.enabled and 'enabled' or 'disabled')) else togglePanel() end end); b:SetScript('OnEnter',function(self) GameTooltip:SetOwner(self,'ANCHOR_LEFT'); GameTooltip:SetText('Debuff Hero'); GameTooltip:AddLine('Left: Settings | Right: Toggle',1,1,1); GameTooltip:Show() end); b:SetScript('OnLeave',function() GameTooltip:Hide() end)
end
SLASH_DEBUFFHERO1='/dh'; SLASH_DEBUFFHERO2='/debuffhero'; SlashCmdList.DEBUFFHERO=function(msg) if not db then return end; if msg=='debug' then print('Debuff Hero native scale: '..tostring(nativeGet('nameplateAuraScale'))..' | padding: '..tostring(nativeGet('nameplateDebuffPadding'))..' | native scale active: '..tostring(nativeScale)..' | combat: '..tostring(InCombatLockdown())); local ok,p=pcall(C_NamePlate.GetNamePlateForUnit,'target'); if ok and safe(p) and p then local f=p.UnitFrame; print('Debuff Hero target UnitFrame: '..tostring(f~=nil)..' | AurasFrame: '..tostring(f and f.AurasFrame~=nil)..' | DebuffListFrame: '..tostring(f and f.AurasFrame and f.AurasFrame.DebuffListFrame~=nil)) end; elseif msg=='toggle' then change('enabled',not db.enabled); if panel then sync() end else togglePanel() end end
for _,e in ipairs({'ADDON_LOADED','PLAYER_ENTERING_WORLD','NAME_PLATE_UNIT_ADDED','NAME_PLATE_UNIT_REMOVED','PLAYER_REGEN_ENABLED','UNIT_AURA'}) do event:RegisterEvent(e) end
event:SetScript('OnEvent',function(_,e,u)
 if e=='ADDON_LOADED' then if u~=addon then return end; DebuffHeroDB=type(DebuffHeroDB)=='table' and DebuffHeroDB or {}; db=DebuffHeroDB; for k,v in pairs(defaults) do if type(db[k])~=type(v) then db[k]=v end end; minimap(); queue()
 elseif not db then return
 elseif e=='UNIT_AURA' then if safe(u) and type(u)=='string' and u:match('^nameplate') then queue(u) end
 elseif e=='NAME_PLATE_UNIT_REMOVED' then if safe(u) and type(u)=='string' then dirtyUnits[u]=nil end; queue()
 elseif e=='NAME_PLATE_UNIT_ADDED' then queue(u)
 else queue() end
end)
