-- Action Hero: optional, event-driven target nameplate decorations.
local addonName, ns = ...
local M = {}
ns.Nameplates = M
local db, panel, overlay, targetPlate, targetBar, targetToken
local activeTokens = {}
local events = CreateFrame("Frame")
local comboType = (Enum and Enum.PowerType and Enum.PowerType.ComboPoints) or 4
local energyType = (Enum and Enum.PowerType and Enum.PowerType.Energy) or 3
local defaults = {
    npCombo = true, npHideZero = true, npBelow = false, npGlow = true,
    npPercent = false, npBigger = false, npPointSize = 12,
    npGlowAlpha = 0.38, npBorderSize = 1, npEmptyAlpha = 1, npHideEmpty = false,
    npSpacing = 4, npOffsetX = 0, npOffsetY = 3, npHealthScale = 1.4,
}
local colorDefaults = {
    npSimple1 = "FFD61F", npSimple5 = "59FF1F",
    npGroup1 = "00CFFF", npGroup3 = "FF9C28", npGroup5 = "59FF1F",
    npPoint1 = "00CFFF", npPoint2 = "4D8FFF", npPoint3 = "BD75FF", npPoint4 = "FF9C28", npPoint5 = "59FF1F",
    npEmptyColor = "4D4D4D", npBorderColor = "121212", npGlowColor = "40FF26",
}
local animations = { "Static", "None", "Pulse", "Flash" }
local modes = { "simple", "grouped", "individual" }
local behaviors = { "progressive", "fixed" }
local shapes = { "Circle", "Square", "Diamond", "Triangle", "Star", "Letter/Number" }
local glyphs = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789"
local function ValidGlyph(value, index)
    if type(value) == "string" and #value == 1 and glyphs:find(value, 1, true) then return value end
    return tostring(index)
end
local function GlyphTexture(suffix)
    return "Interface\\AddOns\\" .. addonName .. "\\ComboGlyph" .. suffix .. ".tga"
end
local function GlyphCoords(value)
    local i = (glyphs:find(value, 1, true) or 1) - 1
    local x, y = (i % 8) / 8, math.floor(i / 8) / 8
    return x, x + 1/8, y, y + 1/8
end
local colorRows = {
    simple = { { "npSimple1", "Points 1-4" }, { "npSimple5", "Point 5" } },
    grouped = { { "npGroup1", "Points 1-2" }, { "npGroup3", "Points 3-4" }, { "npGroup5", "Point 5" } },
    individual = { { "npPoint1", "Point 1" }, { "npPoint2", "Point 2" }, { "npPoint3", "Point 3" }, { "npPoint4", "Point 4" }, { "npPoint5", "Point 5" } },
}
local commonColors = { { "npEmptyColor", "Empty" }, { "npBorderColor", "Border" }, { "npGlowColor", "Max glow" } }
local function ValidChoice(value, choices)
    for _, v in ipairs(choices) do if value == v then return v end end
    return choices[1]
end
local function Hex(value)
    if type(value) ~= "string" then return end
    value = value:match("^%s*#?(%x%x%x%x%x%x)%s*$")
    return value and value:upper()
end
local function RGB(value)
    return tonumber(value:sub(1,2),16)/255, tonumber(value:sub(3,4),16)/255, tonumber(value:sub(5,6),16)/255
end
local function ColorTexture(t, hex, alpha)
    local r,g,b = RGB(hex)
    t:SetVertexColor(r,g,b,alpha or 1)
end
local function PointKey(mode, i)
    if mode == "individual" then return "npPoint" .. i end
    if mode == "grouped" then return i <= 2 and "npGroup1" or i <= 4 and "npGroup3" or "npGroup5" end
    return i == 5 and "npSimple5" or "npSimple1"
end
local function PointTexture(shape)
    return "Interface\\AddOns\\" .. addonName .. "\\ComboPoint" .. (shape == "Circle" and "" or shape) .. ".tga"
end
local limits = {
    npGlowAlpha = { 0, 1 }, npBorderSize = { 0, 3 }, npEmptyAlpha = { 0, 1 },
    npPointSize = { 8, 24 }, npSpacing = { 0, 12 }, npOffsetX = { -40, 40 },
    npOffsetY = { -20, 40 }, npHealthScale = { 1.1, 1.8 },
}
function M.Defaults(t)
    t.npAnimation = ValidChoice(t.npAnimation, animations)
    for i=1,5 do
        local k="npScale"..i; local v=tonumber(t[k])
        t[k]=v and v==v and math.max(.5,math.min(1.6,v)) or 1
    end
    t.npColorMode = ValidChoice(t.npColorMode, modes)
    t.npColorBehavior = ValidChoice(t.npColorBehavior, behaviors)
    t.npShape = ValidChoice(t.npShape, shapes)
    for i = 1, 5 do t["npGlyph" .. i] = ValidGlyph(t["npGlyph" .. i], i) end
    for key, value in pairs(colorDefaults) do t[key] = Hex(t[key]) or value end
    for key, value in pairs(defaults) do
        if type(value) == "boolean" then
            if type(t[key]) ~= "boolean" then t[key] = value end
        else
            local n, range = tonumber(t[key]), limits[key]
            if not n or n ~= n then n = value end
            t[key] = math.max(range[1], math.min(range[2], n))
        end
    end
end
local function EligibleClass()
    local _, class = UnitClass("player")
    return class == "ROGUE" or class == "DRUID"
end
local function CanCombo()
    local _, class = UnitClass("player")
    if class == "ROGUE" then return true end
    if class ~= "DRUID" then return false end
    -- Cat form uses energy, unlike bear, travel or caster forms.
    return UnitPowerType and UnitPowerType("player") == energyType
end
local function Usable(frame)
    return frame and not (frame.IsForbidden and frame:IsForbidden())
end
local function PlateToken(plate)
    if not Usable(plate) then return end
    local unit = plate.UnitFrame or plate.unitFrame
    return plate.unitToken or plate.namePlateUnitToken or (unit and (unit.unit or unit.displayedUnit)) or (plate.GetUnit and plate:GetUnit())
end
local function HealthBar(plate)
    if not Usable(plate) then return end
    local unit = plate.UnitFrame or plate.unitFrame
    if not Usable(unit) then return end
    local container = unit.HealthBarsContainer
    local bar = unit.healthBar or unit.HealthBar or (container and (container.healthBar or container.HealthBar))
    if Usable(bar) and bar.GetWidth and bar.GetHeight and bar.GetStatusBarColor then return bar end
end
local function Hide()
    if overlay then
        overlay:Hide(); overlay.row.full = nil
        for _,p in ipairs(overlay.row.points) do if p.anim then p.anim:Stop(); p.glow:SetAlpha(1) end end
    end
    targetPlate, targetBar, targetToken = nil, nil, nil
end
local function CreatePoints(row)
    row.points = {}
    local texture = PointTexture("Circle")
    for i = 1, 5 do
        local point = CreateFrame("Frame", nil, row)
        point:EnableMouse(false)
        point.glow = point:CreateTexture(nil, "BACKGROUND")
        point.glow:SetTexture(texture)
        point.glow:SetPoint("CENTER")
        point.glow:SetVertexColor(0.25, 1, 0.15, 0.38)
        point.border = point:CreateTexture(nil, "ARTWORK", nil, 0)
        point.border:SetTexture(texture)
        point.border:SetAllPoints(point)
        point.border:SetVertexColor(0.07, 0.07, 0.07, 1)
        point.fill = point:CreateTexture(nil, "ARTWORK", nil, 1)
        point.fill:SetTexture(texture)
        point.fill:SetPoint("CENTER")
        if point.glow.CreateAnimationGroup then
            -- Some client builds may not expose the full native animation API.
            -- Fall back to a static glow rather than failing to create points.
            local ok, group, a = pcall(function()
                local g=point.glow:CreateAnimationGroup()
                local alpha=g:CreateAnimation("Alpha")
                if not (alpha.SetFromAlpha and alpha.SetToAlpha and alpha.SetDuration
                    and g.SetLooping and g.SetScript and g.Play and g.Stop and g.IsPlaying) then return end
                alpha:SetFromAlpha(.2); alpha:SetToAlpha(1); alpha:SetDuration(.55)
                g:SetScript("OnFinished",function() point.glow:SetAlpha(1) end)
                return g,alpha
            end)
            if ok and group and a then point.anim,point.alphaAnim=group,a end
        end
        row.points[i] = point
    end
end
local function LayoutPoints(row, size, space)
    local letters = db.npShape == "Letter/Number"
    local texture = letters and GlyphTexture("") or PointTexture(db.npShape)
    local total, height, x = 4*space, 0, 0
    for i=1,5 do local d=size*db["npScale"..i]; total=total+d; height=math.max(height,d) end
    row:SetSize(total,height)
    for i, point in ipairs(row.points) do
        local size = size * db["npScale"..i]
        point:ClearAllPoints(); point:SetPoint("LEFT", row, "LEFT", x, 0)
        point:SetSize(size, size); x=x+size+space
        local inset = math.min(db.npBorderSize, (size - 2) / 2)
        point.fill:SetSize(size - 2 * inset, size - 2 * inset)
        point.glow:SetSize(size + 5, size + 5)
        if letters then
            -- A glyph atlas keeps the same texture-based tinting and avoids font
            -- availability differences. Separate dilated masks give readable outlines.
            local border = GlyphTexture(tostring(math.max(1, math.min(3, math.floor(inset * 16 / size + 0.5)))))
            local glow = GlyphTexture("3")
            local value = db["npGlyph" .. i]
            if point.shapeTexture ~= texture or point.glyphBorder ~= border or point.glyphValue ~= value then
                point.fill:SetTexture(texture); point.border:SetTexture(border); point.glow:SetTexture(glow)
                point.fill:SetTexCoord(GlyphCoords(value)); point.border:SetTexCoord(GlyphCoords(value)); point.glow:SetTexCoord(GlyphCoords(value))
                point.shapeTexture, point.glyphBorder, point.glyphValue = texture, border, value
            end
            point.fill:SetSize(size, size)
        elseif point.shapeTexture ~= texture then
            point.fill:SetTexture(texture); point.border:SetTexture(texture); point.glow:SetTexture(texture)
            point.fill:SetTexCoord(0,1,0,1); point.border:SetTexCoord(0,1,0,1); point.glow:SetTexCoord(0,1,0,1)
            point.shapeTexture, point.glyphBorder, point.glyphValue = texture, nil, nil
        end
        point.border:SetShown(inset > 0)
    end
end
local function PaintPoints(row, n)
    local full = n==5 and db.npGlow and db.npGlowAlpha>0 and db.npAnimation~="None"
    local transition = full and (not row.full or row.animMode~=db.npAnimation)
    for i, point in ipairs(row.points) do
        point:SetShown(not db.npHideEmpty or i<=n or row.editGlyphs)
        -- Keep empty positions in the layout so filled points never shift.
        point:SetAlpha(db.npHideEmpty and i>n and not row.editGlyphs and 0 or 1)
        ColorTexture(point.border, db.npBorderColor, i > n and db.npEmptyAlpha or 1)
        if i <= n then
            local index = db.npColorBehavior == "fixed" and i or n
            ColorTexture(point.fill, db[PointKey(db.npColorMode, index)], 1)
        else ColorTexture(point.fill, db.npEmptyColor, db.npEmptyAlpha) end
        ColorTexture(point.glow, db.npGlowColor, db.npGlowAlpha)
        local mode=db.npAnimation
        if not full or row.animMode~=mode then
            if point.anim then point.anim:Stop() end
            point.glow:SetAlpha(1)
        end
        point.glow:SetShown(full and (mode~="Flash" or not point.anim or transition or point.anim:IsPlaying()))
        if point.anim and transition and (mode=="Pulse" or mode=="Flash") then
            point.anim:Stop(); point.glow:SetAlpha(1)
            point.anim:SetLooping(mode=="Pulse" and "BOUNCE" or "NONE")
            point.alphaAnim:SetFromAlpha(mode=="Pulse" and .2 or 1)
            point.alphaAnim:SetToAlpha(mode=="Pulse" and 1 or 0)
            point.alphaAnim:SetDuration(mode=="Pulse" and .55 or .45)
            point.anim:SetScript("OnFinished",function() point.glow:SetAlpha(1); if mode=="Flash" then point.glow:Hide() end end)
            point.anim:Play()
        end
    end
    row.full, row.animMode=full,db.npAnimation
end
local function CreateOverlay()
    if overlay then return overlay end
    local f = CreateFrame("Frame", nil, UIParent)
    f:EnableMouse(false)
    f:SetSize(1, 1)
    f:Hide()
    local hp = CreateFrame("StatusBar", nil, f)
    hp:EnableMouse(false)
    hp:SetStatusBarTexture("Interface\\TargetingFrame\\UI-StatusBar")
    hp:SetMinMaxValues(0, 1)
    local bg = hp:CreateTexture(nil, "BACKGROUND")
    bg:SetPoint("TOPLEFT", -1, 1)
    bg:SetPoint("BOTTOMRIGHT", 1, -1)
    bg:SetColorTexture(0.055, 0.055, 0.055, 1)
    f.hp = hp
    local textLayer = CreateFrame("Frame", nil, f)
    textLayer:SetAllPoints(f)
    textLayer:EnableMouse(false)
    f.textLayer = textLayer
    local percent = textLayer:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
    percent:SetFont("Fonts\\FRIZQT__.TTF", 11, "OUTLINE")
    percent:SetTextColor(1, 1, 1)
    f.percent = percent
    local row = CreateFrame("Frame", nil, f)
    row:EnableMouse(false)
    f.row = row
    CreatePoints(row)
    overlay = f
    return f
end
local function UpdateHealth()
    if not targetBar or not overlay then return end
    if not (db.npBigger or db.npPercent) then
        overlay.hp:Hide(); overlay.percent:Hide(); return
    end
    local hp, maxHP = UnitHealth("target"), UnitHealthMax("target")
    if type(hp) ~= "number" or type(maxHP) ~= "number" or maxHP <= 0 then
        overlay.hp:Hide(); overlay.percent:Hide(); return
    end
    local fraction = math.max(0, math.min(1, hp / maxHP))
    if db.npBigger then
        local r, g, b = targetBar:GetStatusBarColor()
        if type(r) ~= "number" then r, g, b = 0.75, 0.15, 0.15 end
        overlay.hp:SetStatusBarColor(r, g, b, 1)
        overlay.hp:SetValue(fraction)
        overlay.hp:Show()
    else overlay.hp:Hide() end
    if db.npPercent then
        local p = math.floor(fraction * 100 + 0.5)
        if hp > 0 then p = math.max(1, p) end
        if hp < maxHP then p = math.min(99, p) end
        overlay.percent:SetText(p .. "%")
        overlay.percent:Show()
    else overlay.percent:Hide() end
end
local function UpdateCombo()
    if not overlay or not targetBar then return end
    local row = overlay.row
    if not db.npCombo or not CanCombo() then PaintPoints(row,0); row:Hide(); return end
    local n
    -- Prefer target-specific counts on Classic/Forever, not a carried-over player pool.
    if GetComboPoints then n = GetComboPoints("player", "target") end
    if type(n) ~= "number" and UnitPower then n = UnitPower("player", comboType) end
    if type(n) ~= "number" then PaintPoints(row,0); row:Hide(); return end
    n = math.max(0, math.min(5, math.floor(n)))
    if n == 0 and db.npHideZero then PaintPoints(row,0); row:Hide(); return end
    PaintPoints(row, n)
    row:Show()
end
local function Refresh()
    if not db or not UnitExists("target") or not UnitCanAttack("player", "target") or UnitIsDeadOrGhost("target") then Hide(); return end
    if not (db.npBigger or db.npPercent or (db.npCombo and CanCombo())) then Hide(); return end
    if not (C_NamePlate and C_NamePlate.GetNamePlateForUnit) then Hide(); return end
    local plate, token
    for unit in pairs(activeTokens) do
        if UnitIsUnit(unit, "target") then
            plate = C_NamePlate.GetNamePlateForUnit(unit)
            if plate then token = unit; break end
        end
    end
    if not plate then
        local ok, found = pcall(C_NamePlate.GetNamePlateForUnit, "target")
        if ok then plate = found end
    end
    -- Enabling a setting after plates already appeared may precede our token events.
    if not plate and C_NamePlate.GetNamePlates then
        for _, candidate in pairs(C_NamePlate.GetNamePlates() or {}) do
            local u = PlateToken(candidate)
            if u and UnitIsUnit(u, "target") then plate, token = candidate, u; break end
        end
    end
    local bar = HealthBar(plate)
    if not bar or not bar:IsShown() then Hide(); return end
    local w, h = bar:GetWidth(), bar:GetHeight()
    if w <= 0 or h <= 0 then Hide(); return end
    local f = CreateOverlay()
    if targetPlate ~= plate or targetBar ~= bar then
        f:Hide(); PaintPoints(f.row,0)
        f:SetParent(plate)
        f:SetFrameLevel(bar:GetFrameLevel() + 5)
        f.hp:SetFrameLevel(f:GetFrameLevel() + 1)
        f.textLayer:SetFrameLevel(f:GetFrameLevel() + 3)
        f.row:SetFrameLevel(f:GetFrameLevel() + 3)
        f:ClearAllPoints()
        f:SetPoint("CENTER", bar, "CENTER")
    end
    targetPlate, targetBar = plate, bar
    targetToken = token or PlateToken(plate)
    -- Only our overlay is resized. Never change the native health bar, hitbox or CVars.
    local hp = f.hp
    hp:ClearAllPoints(); hp:SetPoint("CENTER", f, "CENTER")
    hp:SetSize(w * db.npHealthScale, h * db.npHealthScale)
    local anchor = db.npBigger and hp or bar
    f.percent:ClearAllPoints(); f.percent:SetPoint("CENTER", anchor, "CENTER")
    f.percent:SetFont("Fonts\\FRIZQT__.TTF", db.npBigger and 12 or 10, "OUTLINE")
    local row, size, space = f.row, db.npPointSize, db.npSpacing
    row:ClearAllPoints()
    if db.npBelow then row:SetPoint("TOP", anchor, "BOTTOM", db.npOffsetX, -db.npOffsetY)
    else row:SetPoint("BOTTOM", anchor, "TOP", db.npOffsetX, db.npOffsetY) end
    LayoutPoints(row, size, space)
    UpdateHealth(); UpdateCombo(); f:Show()
end
local retryPending = false
local function RefreshWithRetry()
    Refresh()
    if not targetBar and not retryPending and C_Timer and C_Timer.After then
        retryPending = true
        C_Timer.After(0, function()
            retryPending = false
            Refresh()
        end)
    end
end
local registered = false
local function Register(event)
    -- Some Forever client builds omit legacy event aliases.
    pcall(events.RegisterEvent, events, event)
end
local configuredProfile
function M.Configure(settings)
    if panel and (db ~= settings or configuredProfile ~= settings.activeProfile) then
        panel.pickerGeneration = (panel.pickerGeneration or 0) + 1
        if panel.glyphPicker then panel.glyphPicker:Hide(); panel.glyphIndex = nil end
    end
    configuredProfile = settings.activeProfile
    db = settings
    M.Defaults(db)
    local enable = db.npBigger or db.npPercent or (db.npCombo and EligibleClass())
    if enable and not registered then
        registered = true
        for _, event in ipairs({ "PLAYER_LOGIN", "PLAYER_ENTERING_WORLD", "PLAYER_TARGET_CHANGED", "NAME_PLATE_UNIT_ADDED", "NAME_PLATE_UNIT_REMOVED", "UNIT_HEALTH", "UNIT_MAXHEALTH", "UNIT_HEALTH_FREQUENT", "UNIT_POWER_UPDATE", "UNIT_POWER_FREQUENT", "UNIT_COMBO_POINTS", "UNIT_DISPLAYPOWER", "UPDATE_SHAPESHIFT_FORM", "UPDATE_SHAPESHIFT_FORMS", "PLAYER_REGEN_ENABLED", "UNIT_FACTION" }) do Register(event) end
    elseif not enable and registered then
        registered = false
        events:UnregisterAllEvents()
        activeTokens = {}
    end
    if enable then RefreshWithRetry() else Hide() end
end
events:SetScript("OnEvent", function(_, event, unit, power)
    if event == "NAME_PLATE_UNIT_ADDED" then
        activeTokens[unit] = true
        if UnitIsUnit(unit, "target") then RefreshWithRetry() end
    elseif event == "NAME_PLATE_UNIT_REMOVED" then
        activeTokens[unit] = nil
        if unit == targetToken or (targetPlate and UnitIsUnit(unit, "target")) then Hide() end
    elseif event == "UNIT_HEALTH" or event == "UNIT_HEALTH_FREQUENT" or event == "UNIT_MAXHEALTH" then
        if unit == "target" or unit == targetToken then
            if UnitIsDeadOrGhost("target") then Hide()
            elseif targetBar then UpdateHealth() end
        end
    elseif event == "UNIT_POWER_UPDATE" or event == "UNIT_POWER_FREQUENT" then
        if unit == "player" and (power == "COMBO_POINTS" or power == "COMBOPOINTS" or power == comboType or power == nil) then UpdateCombo() end
    elseif event == "UNIT_COMBO_POINTS" then
        if not unit or unit == "player" or unit == "target" then UpdateCombo() end
    elseif event == "UNIT_DISPLAYPOWER" then
        if unit == "player" then Refresh() end
    elseif event == "UNIT_FACTION" then
        if unit == "target" or unit == targetToken then Refresh() end
    else
        if event == "PLAYER_ENTERING_WORLD" then activeTokens = {} end
        RefreshWithRetry()
    end
end)

-- Settings panel belongs to Action Hero's existing profile system.
function M.BuildPanel(parent, save)
    if panel then return end
    panel = CreateFrame("Frame", nil, parent)
    panel:SetAllPoints(parent)
    panel:Hide()
    panel.checks, panel.sliders = {}, {}
    local main = CreateFrame("Frame", nil, panel); main:SetAllPoints(panel)
    local style = CreateFrame("Frame", nil, panel); style:SetAllPoints(panel); style:Hide()
    local advanced=CreateFrame("Frame",nil,panel); advanced:SetAllPoints(panel); advanced:Hide()
    panel.main, panel.style, panel.advanced = main, style, advanced
    local page = main
    local function label(text, x, y, template)
        local f = page:CreateFontString(nil, "OVERLAY", template or "GameFontHighlight")
        f:SetPoint("TOPLEFT", page, "TOPLEFT", x, y); f:SetText(text)
        return f
    end
    local function changed(key, value)
        db[key] = value
        M.Configure(db)
        save()
        M.RefreshPanel(panel:IsShown())
    end
    local function check(key, title, y, combo)
        local c = CreateFrame("CheckButton", nil, page, "UICheckButtonTemplate")
        c:SetSize(24, 24); c:SetPoint("TOPLEFT", page, "TOPLEFT", 8, y)
        local t = label(title, 38, y - 5)
        c:SetScript("OnClick", function(self) changed(key, not not self:GetChecked()) end)
        panel.checks[key] = { control = c, label = t, combo = combo }
    end
    local function slider(key, title, lo, hi, step, y, combo, percent)
        local t = label(title, 12, y, "GameFontHighlightSmall")
        local value = page:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
        value:SetPoint("TOPRIGHT", page, "TOPRIGHT", -15, y)
        local s = CreateFrame("Slider", nil, page)
        s:SetPoint("TOPLEFT", page, "TOPLEFT", 14, y - 16); s:SetSize(380, 14)
        s:SetOrientation("HORIZONTAL"); s:SetMinMaxValues(lo, hi); s:SetValueStep(step)
        if s.SetObeyStepOnDrag then s:SetObeyStepOnDrag(true) end
        s:SetThumbTexture("Interface\\Buttons\\UI-SliderBar-Button-Horizontal")
        local track = s:CreateTexture(nil, "BACKGROUND")
        track:SetColorTexture(0.36, 0.32, 0.25, 0.9); track:SetPoint("LEFT", 2, 0); track:SetPoint("RIGHT", -2, 0); track:SetHeight(3)
        s:SetScript("OnValueChanged", function(self, v)
            if self.settingValue then return end
            changed(key, math.floor(v / step + 0.5) * step)
        end)
        panel.sliders[key] = { control = s, label = t, value = value, combo = combo, percent = percent }
    end
    label("TARGET NAMEPLATE", 8, -8, "GameFontNormalSmall")
    check("npBigger", "Bigger HP bar for target", -26)
    check("npPercent", "% in HP bar", -52)
    slider("npHealthScale", "Target HP bar size", 1.1, 1.8, 0.05, -83, false, true)
    label("COMBO POINTS (ROGUE / CAT FORM)", 8, -123, "GameFontNormalSmall")
    check("npCombo", "Show combo points on target", -141, true)
    check("npHideZero", "Hide when no combo points", -167, true)
    check("npBelow", "Position below HP bar", -193, true)
    check("npGlow", "Glow at five points", -219, true)
    slider("npPointSize", "Point size", 8, 24, 1, -250, true)
    slider("npSpacing", "Point spacing", 0, 12, 1, -288, true)
    slider("npOffsetX", "Horizontal offset", -40, 40, 1, -326, true)
    slider("npOffsetY", "Vertical offset (away from bar)", -20, 40, 1, -364, true)
    local function button(parent, text, x, y, w, callback)
        local b = CreateFrame("Button", nil, parent, "UIPanelButtonTemplate")
        b:SetSize(w, 23); b:SetPoint("TOPLEFT", parent, "TOPLEFT", x, y); b:SetText(text)
        b:SetScript("OnClick", callback); return b
    end
    panel.openStyle = button(main, "Combo point colors & shapes", 10, -403, 260, function()
        panel.styleOpen = true; M.RefreshPanel(true)
    end)
    button(main,"More options",278,-403,130,function() panel.advancedOpen=true; M.RefreshPanel(true) end)
    page=advanced
    label("COMBO POINT SIZE & ANIMATION",8,-9,"GameFontNormalSmall")
    button(advanced,"Back",345,-4,65,function() panel.advancedOpen=false; M.RefreshPanel(true) end)
    check("npHideEmpty","Hide empty combo points",-34,false)
    local animation=button(advanced,"Animation: Static",10,-66,260,function()
        local index=1; for i,v in ipairs(animations) do if v==db.npAnimation then index=i%#animations+1; break end end
        changed("npAnimation",animations[index])
    end)
    panel.animation=animation
    label("Uses max-point glow color and intensity (when glow is enabled).",10,-94,"GameFontDisableSmall")
    for i=1,5 do slider("npScale"..i,"Point "..i.." size multiplier",.5,1.6,.05,-120-(i-1)*38,false,true) end
    local preview=CreateFrame("Frame",nil,advanced); preview:SetPoint("TOP",advanced,"TOP",0,-341)
    CreatePoints(preview); panel.advancedPreview=preview
    panel.advancedCount=5; panel.advancedLabel=label("Preview: 5/5",10,-313,"GameFontHighlightSmall")
    button(advanced,"-",298,-310,28,function() panel.advancedCount=math.max(0,panel.advancedCount-1); M.RefreshPanel(true) end)
    button(advanced,"+",332,-310,28,function() panel.advancedCount=math.min(5,panel.advancedCount+1); M.RefreshPanel(true) end)
    button(advanced,"Replay finisher",10,-386,135,function() panel.advancedPreview.full=nil; panel.advancedCount=5; M.RefreshPanel(true) end)
    button(advanced,"Reset sizing & animation",157,-386,230,function()
        for i=1,5 do db["npScale"..i]=1 end
        db.npHideEmpty=false; db.npAnimation="Static"; M.Configure(db); save(); M.RefreshPanel(true)
    end)
    page = style
    label("COMBO POINT APPEARANCE", 8, -9, "GameFontNormalSmall")
    button(style, "Back", 345, -4, 65, function() panel.styleOpen = false; M.RefreshPanel(true) end)
    panel.choices = {}
    local function choiceRow(key, title, choices, names, y, x, width)
        label(title, 8, y - 5, "GameFontHighlightSmall")
        for i, v in ipairs(choices) do
            local value = v
            local b = button(style, names[i], x+(i-1)*(width+3), y, width, function() changed(key,value) end)
            panel.choices[#panel.choices+1] = { key=key, value=value, button=b, label=names[i] }
        end
    end
    choiceRow("npColorMode", "Mode", modes, {"Simple", "Grouped", "Individual"}, -34, 100, 100)
    choiceRow("npColorBehavior", "Behavior", behaviors, {"Progressive", "Fixed"}, -62, 100, 125)
    panel.behaviorHint = label("", 10, -89, "GameFontDisableSmall")
    label("Shape", 8, -113, "GameFontHighlightSmall")
    local shapeWidths = { 47, 48, 60, 56, 36, 110 }
    local x = 48
    for i, v in ipairs(shapes) do
        local value = v
        local b = button(style, v, x, -108, shapeWidths[i], function()
            if panel.glyphPicker then panel.glyphPicker:Hide(); panel.glyphIndex = nil end
            changed("npShape", value)
        end)
        panel.choices[#panel.choices+1] = { key="npShape", value=v, button=b, label=v }
        x = x + shapeWidths[i] + 2
    end
    panel.colors = {}
    -- Hex entry remains available on clients without the modern picker API.
    -- Commit only on Enter, so invalid or unfinished text never changes a profile.
    for i=1,8 do
        local x = 10 + ((i-1)%2)*205
        local y = -142 - math.floor((i-1)/2)*29
        local t = label("", x, y-5, "GameFontHighlightSmall")
        local swatchButton = CreateFrame("Button", nil, style)
        swatchButton:SetPoint("TOPLEFT", style, "TOPLEFT", x+87, y-3); swatchButton:SetSize(17,17)
        local swatch = swatchButton:CreateTexture(nil, "ARTWORK"); swatch:SetAllPoints(swatchButton)
        local e = CreateFrame("EditBox", nil, style, "InputBoxTemplate")
        e:SetAutoFocus(false); e:SetSize(77,23); e:SetMaxLetters(7)
        e:SetPoint("TOPLEFT", style, "TOPLEFT", x+112, y)
        local row = { label=t, swatch=swatch, swatchButton=swatchButton, edit=e }
        panel.colors[i] = row
        swatchButton:SetScript("OnClick", function()
            local key, picker = row.key, ColorPickerFrame
            if not key then return end
            if not (picker and picker.SetupColorPickerAndShow and picker.GetColorRGB) then
                e:SetFocus(); e:HighlightText(); return
            end
            local profile, settings = db.activeProfile, db
            local original = db[key]
            local r,g,b = RGB(original)
            panel.pickerGeneration = (panel.pickerGeneration or 0) + 1
            local generation = panel.pickerGeneration
            local function valid()
                return db == settings and db.activeProfile == profile and panel.pickerGeneration == generation
            end
            picker:SetupColorPickerAndShow({ r=r, g=g, b=b, hasOpacity=false,
                swatchFunc=function()
                    if not valid() then return end
                    local cr,cg,cb = picker:GetColorRGB()
                    if type(cr) == "number" and type(cg) == "number" and type(cb) == "number" then
                        local function byte(v) return math.floor(math.max(0,math.min(1,v))*255+0.5) end
                        changed(key,string.format("%02X%02X%02X",byte(cr),byte(cg),byte(cb)))
                    end
                end,
                cancelFunc=function() if valid() then changed(key,original) end end,
            })
        end)
        e:SetScript("OnEnterPressed", function(self)
            local value = Hex(self:GetText())
            local key = row.key
            self:ClearFocus()
            if key and value then changed(key,value) else M.RefreshPanel(true) end
        end)
        e:SetScript("OnEscapePressed", function(self) self:ClearFocus(); M.RefreshPanel(true) end)
        e:SetScript("OnEditFocusLost", function(self) if row.key then self:SetText(db[row.key]) end end)
    end
    label("Click a swatch or enter an RGB hex code + Enter.", 10, -259, "GameFontDisableSmall")
    slider("npGlowAlpha", "Max glow intensity", 0, 1, 0.05, -279, true, true)
    slider("npBorderSize", "Border thickness", 0, 3, 1, -317, true)
    slider("npEmptyAlpha", "Empty point opacity", 0, 1, 0.05, -355, true, true)
    panel.previewCount = 5
    local preview = CreateFrame("Frame", nil, style)
    preview:SetPoint("TOPLEFT", style, "TOPLEFT", 120, -397)
    CreatePoints(preview); panel.preview = preview; preview.editGlyphs=true
    panel.previewLabel = label("Preview: 5/5", 10, -400, "GameFontHighlightSmall")
    button(style, "-", 295, -391, 28, function() panel.previewCount = math.max(0,panel.previewCount-1); M.RefreshPanel(true) end)
    button(style, "+", 327, -391, 28, function() panel.previewCount = math.min(5,panel.previewCount+1); M.RefreshPanel(true) end)
    panel.glyphHint = label("Experimental: click a preview point to edit.", 162, -428, "GameFontDisableSmall")
    panel.glyphHint:Hide()
    local picker = CreateFrame("Frame", nil, style, "BackdropTemplate")
    picker:SetSize(238, 241); picker:SetPoint("BOTTOM", preview, "TOP", 0, 9)
    picker:SetFrameStrata("DIALOG"); picker:SetFrameLevel(style:GetFrameLevel()+20)
    picker:EnableMouse(true)
    picker:SetBackdrop({ bgFile="Interface\\Buttons\\WHITE8X8", edgeFile="Interface\\Buttons\\WHITE8X8", edgeSize=1 })
    picker:SetBackdropColor(0.075,0.085,0.10,1); picker:SetBackdropBorderColor(0.65,0.52,0.28,1)
    picker:Hide(); panel.glyphPicker = picker
    local pickerTitle = picker:CreateFontString(nil,"OVERLAY","GameFontNormalSmall")
    pickerTitle:SetPoint("TOPLEFT",picker,"TOPLEFT",12,-10)
    local function closeGlyphPicker() picker:Hide(); panel.glyphIndex = nil; panel.glyphProfile = nil end
    button(picker,"X",203,-4,27,closeGlyphPicker)
    panel.glyphChoices = {}
    for i=1,#glyphs do
        local value = glyphs:sub(i,i)
        local b = button(picker,value,10+((i-1)%6)*37,-32-math.floor((i-1)/6)*33,32,function()
            local slot = panel.glyphIndex
            local valid = picker:IsShown() and panel.styleOpen and panel:IsShown() and db.npShape == "Letter/Number"
                and panel.glyphProfile == db.activeProfile and slot and slot >= 1 and slot <= 5
            closeGlyphPicker()
            if valid then changed("npGlyph" .. slot,value) end
        end)
        panel.glyphChoices[i] = b
    end
    panel.glyphButtons = {}
    for i, point in ipairs(preview.points) do
        local slot = i
        local hit = CreateFrame("Button",nil,preview)
        hit:SetAllPoints(point); hit:SetFrameLevel(point:GetFrameLevel()+2)
        hit:SetHighlightTexture("Interface\\Buttons\\ButtonHilight-Square", "ADD")
        hit:SetScript("OnClick",function()
            if db.npShape ~= "Letter/Number" or not panel.styleOpen then return end
            if picker:IsShown() and panel.glyphIndex == slot then closeGlyphPicker(); return end
            panel.glyphIndex, panel.glyphProfile = slot, db.activeProfile
            pickerTitle:SetText("Choose point " .. slot .. " (A-Z / 0-9)")
            for j, b in ipairs(panel.glyphChoices) do
                local v = glyphs:sub(j,j)
                b:SetText(v == db["npGlyph" .. slot] and "|cff00ff66[" .. v .. "]|r" or v)
            end
            picker:Show()
        end)
        hit:Hide(); panel.glyphButtons[i] = hit
    end
    style:HookScript("OnHide",closeGlyphPicker)
    panel:HookScript("OnHide",function() closeGlyphPicker(); if db then PaintPoints(panel.preview,0); PaintPoints(panel.advancedPreview,0) end end)
    button(style, "Reset appearance", 10, -423, 145, function()
        closeGlyphPicker()
        for i=1,5 do db["npGlyph" .. i] = tostring(i) end
        panel.pickerGeneration = (panel.pickerGeneration or 0) + 1
        for key,value in pairs(colorDefaults) do db[key]=value end
        db.npColorMode, db.npColorBehavior, db.npShape = modes[1], behaviors[1], shapes[1]
        db.npGlowAlpha, db.npBorderSize, db.npEmptyAlpha = defaults.npGlowAlpha, defaults.npBorderSize, defaults.npEmptyAlpha
        for i=1,5 do db["npScale"..i]=1 end; db.npAnimation="Static"; db.npHideEmpty=false
        M.Configure(db); save(); M.RefreshPanel(true)
    end)
end
function M.RefreshPanel(visible)
    if not panel then return end
    panel:SetShown(visible)
    if not visible or not db then
        if db then for _,r in ipairs({panel.preview,panel.advancedPreview}) do if r then PaintPoints(r,0) end end end
        if panel.glyphPicker then panel.glyphPicker:Hide(); panel.glyphIndex = nil end
        return
    end
    if not panel.styleOpen and panel.preview then PaintPoints(panel.preview,0) end
    if not panel.advancedOpen and panel.advancedPreview then PaintPoints(panel.advancedPreview,0) end
    local eligible = EligibleClass()
    panel.main:SetShown(not panel.styleOpen and not panel.advancedOpen)
    panel.style:SetShown(not not panel.styleOpen)
    panel.advanced:SetShown(not not panel.advancedOpen)
    panel.animation:SetText("Animation: "..db.npAnimation)
    if panel.advancedOpen then
        LayoutPoints(panel.advancedPreview,db.npPointSize,db.npSpacing)
        PaintPoints(panel.advancedPreview,panel.advancedCount)
        panel.advancedLabel:SetText("Preview: "..panel.advancedCount.."/5")
    end
    -- Appearance can be configured on any class, even without a target.
    for _, choice in ipairs(panel.choices) do
        choice.button:SetText(db[choice.key] == choice.value and "|cff00ff66[" .. choice.label .. "]|r" or choice.label)
    end
    panel.behaviorHint:SetText(db.npColorBehavior == "progressive" and "All filled points change color at each threshold." or "Each filled point keeps its assigned color.")
    local rows = {}
    for _, item in ipairs(colorRows[db.npColorMode]) do rows[#rows+1] = item end
    for _, item in ipairs(commonColors) do rows[#rows+1] = item end
    for i, row in ipairs(panel.colors) do
        local item = rows[i]
        row.edit:ClearFocus()
        row.key = item and item[1] or nil
        row.label:SetShown(item ~= nil); row.swatchButton:SetShown(item ~= nil); row.edit:SetShown(item ~= nil)
        if item then
            row.label:SetText(item[2]); row.edit:SetText(db[item[1]])
            local r,g,b = RGB(db[item[1]]); row.swatch:SetColorTexture(r,g,b,1)
        end
    end
    local letters = panel.styleOpen and db.npShape == "Letter/Number"
    panel.glyphHint:SetShown(not not letters)
    for _, hit in ipairs(panel.glyphButtons) do hit:SetShown(not not letters) end
    if not letters or panel.glyphProfile ~= db.activeProfile then
        panel.glyphPicker:Hide(); panel.glyphIndex = nil
    end
    if panel.styleOpen then
        panel.preview.editGlyphs = db.npShape=="Letter/Number"
        LayoutPoints(panel.preview, 16, 5); PaintPoints(panel.preview, panel.previewCount)
        panel.previewLabel:SetText("Preview: " .. panel.previewCount .. "/5")
    end
    for key, entry in pairs(panel.checks) do
        local enabled = not entry.combo or eligible
        entry.control:SetChecked(db[key]); if enabled then entry.control:Enable() else entry.control:Disable() end
        entry.label:SetAlpha(enabled and 1 or 0.45)
    end
    for key, entry in pairs(panel.sliders) do
        local enabled = (not entry.combo or eligible or key == "npGlowAlpha" or key == "npBorderSize" or key == "npEmptyAlpha") and (key ~= "npHealthScale" or db.npBigger)
        local s = entry.control
        s.settingValue = true; s:SetValue(db[key]); s.settingValue = false
        s:EnableMouse(enabled); s:SetAlpha(enabled and 1 or 0.45)
        entry.label:SetAlpha(enabled and 1 or 0.45)
        entry.value:SetText(entry.percent and string.format("%.0f%%", db[key] * 100) or string.format("%.0f", db[key]))
    end
end
