-- Action Hero 2.2: bounded, data-only recovery and profile exchange.
local _, ns = ...
local R = {}; ns.Recovery = R
local wraps = {12,6,4,3,2,1}
local anchors = {TOP=true, BOTTOM=true, LEFT=true, RIGHT=true, CENTER=true, TOPLEFT=true, TOPRIGHT=true, BOTTOMLEFT=true, BOTTOMRIGHT=true}
local function finite(v) return type(v)=="number" and v==v and math.abs(v)<9007199254740992 end
local function clone(t)
    if type(t) ~= "table" then return t end
    local n={}; for k,v in pairs(t) do n[k]=clone(v) end; return n
end
function R.ValidWrap(v) for _,n in ipairs(wraps) do if n==v then return n end end return 12 end
function R.NextWrap(v) for i,n in ipairs(wraps) do if n==v then return wraps[i%#wraps+1] end end return 12 end
function R.GridSize(count,wrap,vertical)
    count=math.max(1,count); wrap=R.ValidWrap(wrap)
    local a,b=math.min(count,wrap),math.ceil(count/wrap)
    if vertical then return b,a end; return a,b
end
function R.GridCell(slot,wrap,vertical)
    wrap=R.ValidWrap(wrap); local a,b=slot%wrap,math.floor(slot/wrap)
    if vertical then return b,a end; return a,b
end
function R.ValidPoint(p) return type(p)=="table" and anchors[p[1]] and anchors[p[2]] and finite(p[3]) and finite(p[4]) and math.abs(p[3])<1000000 and math.abs(p[4])<1000000 end
function R.DefaultPoint(i)
    if i>5 then return {"TOPRIGHT","TOPRIGHT",-50-(i-6)*55,-150} end
    return {"BOTTOM","BOTTOM",0,54+(i-1)*48}
end
local layoutKeys={"barPoint","barScale","barVertical","barReverse","barSpacing","barLimit","barWrap","showBar"}
local appearanceKeys={"barScale","barVertical","barReverse","barSpacing","barLimit","barWrap"}
local undo, lastGroup, lastTime
function R.ClearUndo() undo,lastGroup,lastTime=nil,nil,nil end
function R.Remember(db)
    local state={barsSnapped=db.barsSnapped,snapLeader=db.snapLeader,snapBreaks=clone(db.snapBreaks)}
    for i=1,7 do for _,k in ipairs(layoutKeys) do state[k..i]=clone(db[k..i]) end end
    undo={profile=db.activeProfile,state=state}; lastGroup,lastTime=nil,nil
end
function R.RememberCoalesced(db,group)
    local now=GetTime and GetTime() or 0
    if lastGroup~=group or not lastTime or now-lastTime>0.6 or not undo or undo.profile~=db.activeProfile then R.Remember(db) end
    lastGroup,lastTime=group,now
end
function R.Undo(db)
    if not undo or undo.profile~=db.activeProfile then return false end
    for k,v in pairs(undo.state) do db[k]=clone(v) end
    R.ClearUndo(); return true
end
function R.ResetPosition(db,i)
    db["barPoint"..i]=R.DefaultPoint(i)
    -- Break the incoming snap link, or unsnap if resetting the leader.
    if db.barsSnapped then
        if db.snapLeader==i then db.barsSnapped=false; db.snapBreaks={}
        elseif i>db.snapLeader then db.snapBreaks[i-1]=true end
    end
end
function R.ResetAllPositions(db)
    R.Remember(db); db.barsSnapped=false; db.snapBreaks={}
    for i=1,7 do db["barPoint"..i]=R.DefaultPoint(i) end
end
function R.CopyBar(db,from,to)
    if from==to then return false end
    R.Remember(db); for _,k in ipairs(appearanceKeys) do db[k..to]=clone(db[k..from]) end
    return true
end
function R.NormalizeBackups(db)
    local out={}
    if type(db.profileBackups)=="table" then
        for _,v in ipairs(db.profileBackups) do
            if type(v)=="table" and type(v.name)=="string" and type(v.snapshot)=="table" then
                out[#out+1]={name=v.name, snapshot=v.snapshot, reason=type(v.reason)=="string" and v.reason or "Backup", when=type(v.when)=="string" and v.when or ""}; if #out>=10 then break end
            end
        end
    end
    db.profileBackups=out
end
function R.Backup(db,name,snapshot,reason)
    R.NormalizeBackups(db)
    local snap=clone(snapshot); snap.profiles=nil; snap.profileBackups=nil; snap.activeProfile=nil; snap.defaultBottomView=nil
    table.insert(db.profileBackups,1,{name=name, snapshot=snap, reason=reason, when=date and date("%Y-%m-%d %I:%M %p") or ""})
    while #db.profileBackups>10 do table.remove(db.profileBackups) end
end
-- Explicit typed length-prefixed grammar; no load/loadstring, no execution.
local function encode(v,depth)
    if depth>8 then error("Profile nested too deeply") end
    local t=type(v)
    if t=="boolean" then return v and "T" or "F" end
    if t=="number" then if not finite(v) then error("Invalid number") end; local s=tostring(v); return "N"..#s..":"..s end
    if t=="string" then return "S"..#v..":"..v end
    if t=="table" then
        local chunks={}; local keys={}; for k in pairs(v) do keys[#keys+1]=k end
        table.sort(keys,function(a,b) if type(a)==type(b) then return a<b end return type(a)<type(b) end)
        for _,k in ipairs(keys) do chunks[#chunks+1]=encode(k,depth+1); chunks[#chunks+1]=encode(v[k],depth+1) end
        return "M"..#keys..":"..table.concat(chunks)
    end
    error("Unsupported value")
end
function R.Export(snapshot)
    local ok,value=pcall(encode,snapshot,0)
    if not ok or #value>60000 then return nil,"Profile cannot be exported safely." end
    -- Hex wrapping avoids linebreak, pipe and UTF-8 issues in WoW edit boxes.
    return "AH22:"..value:gsub(".",function(c) return string.format("%02X",c:byte()) end)
end
local function decode(text)
    if type(text)~="string" or #text>120005 or text:sub(1,5)~="AH22:" then error("Not an Action Hero profile code") end
    local hex=text:sub(6); if #hex%2~=0 or hex:find("[^0-9A-Fa-f]") then error("Invalid profile code") end
    local s=hex:gsub("..",function(c) return string.char(tonumber(c,16)) end)
    local pos,nodes=1,0
    local function parse(depth)
        nodes=nodes+1; if nodes>6000 or depth>8 then error("Profile exceeds limits") end
        local tag=s:sub(pos,pos); pos=pos+1
        if tag=="T" then return true elseif tag=="F" then return false end
        if tag~="S" and tag~="N" and tag~="M" then error("Invalid type") end
        local a,b,raw=s:find("^(%d+):",pos)
        if not a or #raw>6 then error("Invalid length") end
        local n=tonumber(raw); pos=b+1
        if tag=="M" then
            if n>1500 then error("Too many entries") end
            local t={}; for i=1,n do local k=parse(depth+1); if type(k)~="string" and type(k)~="number" then error("Invalid key") end; if t[k]~=nil then error("Duplicate key") end; t[k]=parse(depth+1) end; return t
        end
        if pos+n-1>#s then error("Truncated profile") end
        local v=s:sub(pos,pos+n-1); pos=pos+n
        if tag=="N" then v=tonumber(v); if not finite(v) then error("Invalid number") end end
        return v
    end
    local t=parse(0); if pos~=#s+1 or type(t)~="table" then error("Invalid profile data") end; return t
end
local function cleanPoint(p) if R.ValidPoint(p) then return {p[1],p[2],p[3],p[4]} end end
local function texture(v)
    if type(v)=="number" and finite(v) and v>0 and v==math.floor(v) then return v end
    if type(v)=="string" and #v<=256 and v:match("^[%w_\\/%. %-]+$") then return v end
end
function R.Import(text,normalize)
    local ok, result=pcall(function()
        local raw=decode(text); local template={}; normalize(template); local out={}
        for k,v in pairs(template) do
            if type(v)~="table" and type(raw[k])==type(v) and k~="defaultBottomView" then
                if type(v)=="string" then if #raw[k]<=64 then out[k]=raw[k] end else out[k]=raw[k] end
            end
        end
        for i=1,7 do out["barPoint"..i]=cleanPoint(raw["barPoint"..i]) end
        for _,k in ipairs({"menuPoint","singleBagPoint","druidFormPoint","xpPoint"}) do out[k]=cleanPoint(raw[k]) end
        out.snapBreaks={}; if type(raw.snapBreaks)=="table" then for i=1,6 do if raw.snapBreaks[i]==true then out.snapBreaks[i]=true end end end
        if type(raw.customIcons)=="table" then
            out.customIcons={}
            for i=1,7 do if type(raw.customIcons[i])=="table" then
                local bar={}; out.customIcons[i]=bar
                for j=1,12 do
                    local v=raw.customIcons[i][j]
                    if type(v)=="table" and v.kind=="text" and type(v.text)=="string" and #v.text<=32 then
                        bar[j]={kind="text",text=v.text,scale=finite(v.scale) and math.max(.5,math.min(2,v.scale)) or 1,color=type(v.color)=="string" and v.color:sub(1,16) or "gold",background=v.background~=false}
                    else bar[j]=texture(type(v)=="table" and (v.texture or v.icon) or v) end
                end
            end end
        end
        if raw.slotTooltipMode=="hover" or raw.slotTooltipMode=="dismiss" or raw.slotTooltipMode=="off" then out.slotTooltipMode=raw.slotTooltipMode end
        if not ({off=true,bar=true,square=true,text=true})[out.xpMode] then out.xpMode="off" end
        normalize(out); out.defaultBottomView=nil; return out
    end)
    if not ok then return nil,"Invalid or unsupported profile code. Nothing changed." end
    return result
end
local function newName(db,base)
    base=base:sub(1,24); local n=base; local i=1
    while db.profiles[n]~=nil do i=i+1; n=base.." "..i end
    return n
end
function R.Open(db,parent,api)
    if R.dialog then R.dialog:Hide() end
    local f=R.dialog
    if not f then
        f=CreateFrame("Frame", "ActionHeroRecovery", parent,"BackdropTemplate"); R.dialog=f
        f:SetSize(426,454); f:SetPoint("TOP",parent,"TOP",0,-208); f:SetFrameLevel(parent:GetFrameLevel()+30)
        f:SetBackdrop({bgFile="Interface\\Buttons\\WHITE8X8",edgeFile="Interface\\Buttons\\WHITE8X8",edgeSize=1}); f:SetBackdropColor(.075,.085,.10,1); f:SetBackdropBorderColor(.65,.52,.28,1); f:EnableMouse(true)
        if type(UISpecialFrames)=="table" then table.insert(UISpecialFrames,"ActionHeroRecovery") end
    end
    if f.built then f.refresh(db,api); f:Show(); return end
    f.built=true
    local function label(text,x,y)
        local a=f:CreateFontString(nil,"OVERLAY","GameFontHighlightSmall"); a:SetPoint("TOPLEFT",f,"TOPLEFT",x,y); a:SetText(text); return a
    end
    local function button(text,x,y,w,fn)
        local b=CreateFrame("Button",nil,f,"UIPanelButtonTemplate"); b:SetSize(w,24); b:SetPoint("TOPLEFT",f,"TOPLEFT",x,y); b:SetText(text); b:SetScript("OnClick",fn); return b
    end
    label("LAYOUT & PROFILE RECOVERY",12,-12); button("X",389,-5,26,function() f:Hide() end)
    local function guard(layout)
        local allowed=layout and f.api.layoutAllowed or f.api.allowed
        if not allowed() then f.api.message("Finish combat or dragging before making recovery changes."); return false end
        if layout and f.db.lockBars then f.api.message("Unlock action bars first."); return false end
        return true
    end
    local function apply() f.api.apply() end
    local refreshBackup
    button("Undo last layout change",12,-35,195,function() if guard(true) then if R.Undo(f.db) then apply() else f.api.message("No layout change to undo in this session/profile.") end end end)
    button("Recover all bar positions",213,-35,201,function() if guard(true) then R.Backup(f.db,f.db.activeProfile,f.api.capture(f.db),"Recover positions"); R.ResetAllPositions(f.db); apply(); refreshBackup() end end)
    label("Copy layout (not position, actions, icons or visibility)",12,-70)
    f.source,f.target=1,2
    local src,dst
    src=button("From: Bar 1",12,-87,117,function() f.source=f.source%7+1; src:SetText("From: Bar "..f.source) end)
    dst=button("To: Bar 2",138,-87,117,function() f.target=f.target%7+1; dst:SetText("To: Bar "..f.target) end)
    button("Copy settings",265,-87,149,function() if guard(true) and R.CopyBar(f.db,f.source,f.target) then apply() end end)
    label("Last 10 destructive-operation backups (restore as new)",12,-123)
    f.backupIndex=1
    local backupLabel=label("No backups",12,-150); backupLabel:SetWidth(402); backupLabel:SetJustifyH("LEFT")
    refreshBackup=function()
        local list=f.db.profileBackups or {}; if f.backupIndex>#list then f.backupIndex=1 end
        local b=list[f.backupIndex]; backupLabel:SetText(b and (f.backupIndex.."/"..#list.."  "..b.name.."  "..(b.reason or "").."  "..(b.when or "")) or "No backups yet")
    end
    button("Next backup",12,-173,120,function() local n=#(f.db.profileBackups or {}); if n>0 then f.backupIndex=f.backupIndex%n+1 end; refreshBackup() end)
    button("Restore as new profile",141,-173,188,function()
        if not guard(false) then return end
        local b=f.db.profileBackups and f.db.profileBackups[f.backupIndex]; if not b then return end
        local n=newName(f.db,b.name.." restored"); f.db.profiles[n]=clone(b.snapshot); f.api.select(n); f.api.message("Restored as "..n)
    end)
    label("PROFILE EXCHANGE  |  Copy / paste the full AH22 code",12,-210)
    local scroll=CreateFrame("ScrollFrame",nil,f,"UIPanelScrollFrameTemplate"); scroll:SetPoint("TOPLEFT",f,"TOPLEFT",12,-230); scroll:SetSize(375,122)
    local edit=CreateFrame("EditBox",nil,scroll); edit:SetMultiLine(true); edit:SetAutoFocus(false); edit:SetFontObject(GameFontHighlightSmall); edit:SetWidth(365); edit:SetMaxLetters(120005); scroll:SetScrollChild(edit)
    edit:SetScript("OnEscapePressed",function(self) self:ClearFocus() end)
    local hint=label("Import creates a new profile; existing profiles are not overwritten.",12,-365); hint:SetWidth(400)
    button("Export current",12,-390,130,function()
        local code,err=R.Export(f.api.capture(f.db)); if not code then f.api.message(err); return end
        edit:SetText(code); edit:SetFocus(); edit:HighlightText()
    end)
    button("Import as new",150,-390,133,function()
        if not guard(false) then return end
        local profile,err=R.Import(edit:GetText(),f.api.normalize); if not profile then f.api.message(err); return end
        local n=newName(f.db,"Imported"); f.db.profiles[n]=profile; f.api.select(n); f.api.message("Imported as "..n); edit:ClearFocus()
    end)
    button("Clear text",291,-390,120,function() edit:SetText(""); edit:ClearFocus() end)
    f.refresh=function(current,callbacks) f.db,f.api=current,callbacks; f.backupIndex=1; edit:SetText(""); refreshBackup() end
    f.refresh(db,api); f:Show()
end
