-- Action Hero: optional, event-driven target nameplate decorations.
local addonName, ns = ...
local M = {}
ns.Nameplates = M
local db, panel, overlay, targetPlate, targetBar, targetToken
local activeTokens = {}
local events = CreateFrame("Frame")
local comboType = (Enum and Enum.PowerType and Enum.PowerType.ComboPoints) or 4
local energyType = (Enum and Enum.PowerType and Enum.PowerType.Energy) or 3
local defaults = {
    npCombo = true, npHideZero = true, npBelow = false, npGlow = true,
    npPercent = false, npBigger = false, npPointSize = 12,
    npSpacing = 4, npOffsetX = 0, npOffsetY = 3, npHealthScale = 1.4,
}
local limits = {
    npPointSize = { 8, 24 }, npSpacing = { 0, 12 }, npOffsetX = { -40, 40 },
    npOffsetY = { -20, 40 }, npHealthScale = { 1.1, 1.8 },
}
function M.Defaults(t)
    for key, value in pairs(defaults) do
        if type(value) == "boolean" then
            if type(t[key]) ~= "boolean" then t[key] = value end
        else
            local n, range = tonumber(t[key]), limits[key]
            if not n or n ~= n then n = value end
            t[key] = math.max(range[1], math.min(range[2], n))
        end
    end
end
local function EligibleClass()
    local _, class = UnitClass("player")
    return class == "ROGUE" or class == "DRUID"
end
local function CanCombo()
    local _, class = UnitClass("player")
    if class == "ROGUE" then return true end
    if class ~= "DRUID" then return false end
    -- Cat form uses energy, unlike bear, travel or caster forms.
    return UnitPowerType and UnitPowerType("player") == energyType
end
local function Usable(frame)
    return frame and not (frame.IsForbidden and frame:IsForbidden())
end
local function PlateToken(plate)
    if not Usable(plate) then return end
    local unit = plate.UnitFrame or plate.unitFrame
    return plate.unitToken or plate.namePlateUnitToken or (unit and (unit.unit or unit.displayedUnit)) or (plate.GetUnit and plate:GetUnit())
end
local function HealthBar(plate)
    if not Usable(plate) then return end
    local unit = plate.UnitFrame or plate.unitFrame
    if not Usable(unit) then return end
    local container = unit.HealthBarsContainer
    local bar = unit.healthBar or unit.HealthBar or (container and (container.healthBar or container.HealthBar))
    if Usable(bar) and bar.GetWidth and bar.GetHeight and bar.GetStatusBarColor then return bar end
end
local function Hide()
    if overlay then overlay:Hide() end
    targetPlate, targetBar, targetToken = nil, nil, nil
end
local function CreateOverlay()
    if overlay then return overlay end
    local f = CreateFrame("Frame", nil, UIParent)
    f:EnableMouse(false)
    f:SetSize(1, 1)
    f:Hide()
    local hp = CreateFrame("StatusBar", nil, f)
    hp:EnableMouse(false)
    hp:SetStatusBarTexture("Interface\\TargetingFrame\\UI-StatusBar")
    hp:SetMinMaxValues(0, 1)
    local bg = hp:CreateTexture(nil, "BACKGROUND")
    bg:SetPoint("TOPLEFT", -1, 1)
    bg:SetPoint("BOTTOMRIGHT", 1, -1)
    bg:SetColorTexture(0.055, 0.055, 0.055, 1)
    f.hp = hp
    local textLayer = CreateFrame("Frame", nil, f)
    textLayer:SetAllPoints(f)
    textLayer:EnableMouse(false)
    f.textLayer = textLayer
    local percent = textLayer:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
    percent:SetFont("Fonts\\FRIZQT__.TTF", 11, "OUTLINE")
    percent:SetTextColor(1, 1, 1)
    f.percent = percent
    local row = CreateFrame("Frame", nil, f)
    row:EnableMouse(false)
    f.row = row
    row.points = {}
    local texture = "Interface\\AddOns\\" .. addonName .. "\\ComboPoint.tga"
    for i = 1, 5 do
        local point = CreateFrame("Frame", nil, row)
        point:EnableMouse(false)
        point.glow = point:CreateTexture(nil, "BACKGROUND")
        point.glow:SetTexture(texture)
        point.glow:SetPoint("CENTER")
        point.glow:SetVertexColor(0.25, 1, 0.15, 0.38)
        point.border = point:CreateTexture(nil, "ARTWORK", nil, 0)
        point.border:SetTexture(texture)
        point.border:SetAllPoints(point)
        point.border:SetVertexColor(0.07, 0.07, 0.07, 1)
        point.fill = point:CreateTexture(nil, "ARTWORK", nil, 1)
        point.fill:SetTexture(texture)
        point.fill:SetPoint("CENTER")
        row.points[i] = point
    end
    overlay = f
    return f
end
local function UpdateHealth()
    if not targetBar or not overlay then return end
    if not (db.npBigger or db.npPercent) then
        overlay.hp:Hide(); overlay.percent:Hide(); return
    end
    local hp, maxHP = UnitHealth("target"), UnitHealthMax("target")
    if type(hp) ~= "number" or type(maxHP) ~= "number" or maxHP <= 0 then
        overlay.hp:Hide(); overlay.percent:Hide(); return
    end
    local fraction = math.max(0, math.min(1, hp / maxHP))
    if db.npBigger then
        local r, g, b = targetBar:GetStatusBarColor()
        if type(r) ~= "number" then r, g, b = 0.75, 0.15, 0.15 end
        overlay.hp:SetStatusBarColor(r, g, b, 1)
        overlay.hp:SetValue(fraction)
        overlay.hp:Show()
    else overlay.hp:Hide() end
    if db.npPercent then
        local p = math.floor(fraction * 100 + 0.5)
        if hp > 0 then p = math.max(1, p) end
        if hp < maxHP then p = math.min(99, p) end
        overlay.percent:SetText(p .. "%")
        overlay.percent:Show()
    else overlay.percent:Hide() end
end
local function UpdateCombo()
    if not overlay or not targetBar then return end
    local row = overlay.row
    if not db.npCombo or not CanCombo() then row:Hide(); return end
    local n
    -- Prefer target-specific counts on Classic/Forever, not a carried-over player pool.
    if GetComboPoints then n = GetComboPoints("player", "target") end
    if type(n) ~= "number" and UnitPower then n = UnitPower("player", comboType) end
    if type(n) ~= "number" then row:Hide(); return end
    n = math.max(0, math.min(5, math.floor(n)))
    if n == 0 and db.npHideZero then row:Hide(); return end
    for i, point in ipairs(row.points) do
        if i <= n then
            if n == 5 then point.fill:SetVertexColor(0.35, 1, 0.12, 1)
            else point.fill:SetVertexColor(1, 0.84, 0.12, 1) end
        else point.fill:SetVertexColor(0.30, 0.30, 0.30, 1) end
        point.glow:SetShown(n == 5 and db.npGlow)
    end
    row:Show()
end
local function Refresh()
    if not db or not UnitExists("target") or not UnitCanAttack("player", "target") or UnitIsDeadOrGhost("target") then Hide(); return end
    if not (db.npBigger or db.npPercent or (db.npCombo and CanCombo())) then Hide(); return end
    if not (C_NamePlate and C_NamePlate.GetNamePlateForUnit) then Hide(); return end
    local plate, token
    for unit in pairs(activeTokens) do
        if UnitIsUnit(unit, "target") then
            plate = C_NamePlate.GetNamePlateForUnit(unit)
            if plate then token = unit; break end
        end
    end
    if not plate then
        local ok, found = pcall(C_NamePlate.GetNamePlateForUnit, "target")
        if ok then plate = found end
    end
    -- Enabling a setting after plates already appeared may precede our token events.
    if not plate and C_NamePlate.GetNamePlates then
        for _, candidate in pairs(C_NamePlate.GetNamePlates() or {}) do
            local u = PlateToken(candidate)
            if u and UnitIsUnit(u, "target") then plate, token = candidate, u; break end
        end
    end
    local bar = HealthBar(plate)
    if not bar or not bar:IsShown() then Hide(); return end
    local w, h = bar:GetWidth(), bar:GetHeight()
    if w <= 0 or h <= 0 then Hide(); return end
    local f = CreateOverlay()
    if targetPlate ~= plate or targetBar ~= bar then
        f:Hide()
        f:SetParent(plate)
        f:SetFrameLevel(bar:GetFrameLevel() + 5)
        f.hp:SetFrameLevel(f:GetFrameLevel() + 1)
        f.textLayer:SetFrameLevel(f:GetFrameLevel() + 3)
        f.row:SetFrameLevel(f:GetFrameLevel() + 3)
        f:ClearAllPoints()
        f:SetPoint("CENTER", bar, "CENTER")
    end
    targetPlate, targetBar = plate, bar
    targetToken = token or PlateToken(plate)
    -- Only our overlay is resized. Never change the native health bar, hitbox or CVars.
    local hp = f.hp
    hp:ClearAllPoints(); hp:SetPoint("CENTER", f, "CENTER")
    hp:SetSize(w * db.npHealthScale, h * db.npHealthScale)
    local anchor = db.npBigger and hp or bar
    f.percent:ClearAllPoints(); f.percent:SetPoint("CENTER", anchor, "CENTER")
    f.percent:SetFont("Fonts\\FRIZQT__.TTF", db.npBigger and 12 or 10, "OUTLINE")
    local row, size, space = f.row, db.npPointSize, db.npSpacing
    row:ClearAllPoints()
    if db.npBelow then row:SetPoint("TOP", anchor, "BOTTOM", db.npOffsetX, -db.npOffsetY)
    else row:SetPoint("BOTTOM", anchor, "TOP", db.npOffsetX, db.npOffsetY) end
    row:SetSize(5 * size + 4 * space, size)
    for i, point in ipairs(row.points) do
        point:ClearAllPoints(); point:SetPoint("LEFT", row, "LEFT", (i - 1) * (size + space), 0)
        point:SetSize(size, size)
        point.fill:SetSize(size - 2, size - 2)
        point.glow:SetSize(size + 5, size + 5)
    end
    UpdateHealth(); UpdateCombo(); f:Show()
end
local retryPending = false
local function RefreshWithRetry()
    Refresh()
    if not targetBar and not retryPending and C_Timer and C_Timer.After then
        retryPending = true
        C_Timer.After(0, function()
            retryPending = false
            Refresh()
        end)
    end
end
local registered = false
local function Register(event)
    -- Some Forever client builds omit legacy event aliases.
    pcall(events.RegisterEvent, events, event)
end
function M.Configure(settings)
    db = settings
    M.Defaults(db)
    local enable = db.npBigger or db.npPercent or (db.npCombo and EligibleClass())
    if enable and not registered then
        registered = true
        for _, event in ipairs({ "PLAYER_LOGIN", "PLAYER_ENTERING_WORLD", "PLAYER_TARGET_CHANGED", "NAME_PLATE_UNIT_ADDED", "NAME_PLATE_UNIT_REMOVED", "UNIT_HEALTH", "UNIT_MAXHEALTH", "UNIT_HEALTH_FREQUENT", "UNIT_POWER_UPDATE", "UNIT_POWER_FREQUENT", "UNIT_COMBO_POINTS", "UNIT_DISPLAYPOWER", "UPDATE_SHAPESHIFT_FORM", "UPDATE_SHAPESHIFT_FORMS", "PLAYER_REGEN_ENABLED", "UNIT_FACTION" }) do Register(event) end
    elseif not enable and registered then
        registered = false
        events:UnregisterAllEvents()
        activeTokens = {}
    end
    if enable then RefreshWithRetry() else Hide() end
end
events:SetScript("OnEvent", function(_, event, unit, power)
    if event == "NAME_PLATE_UNIT_ADDED" then
        activeTokens[unit] = true
        if UnitIsUnit(unit, "target") then RefreshWithRetry() end
    elseif event == "NAME_PLATE_UNIT_REMOVED" then
        activeTokens[unit] = nil
        if unit == targetToken or (targetPlate and UnitIsUnit(unit, "target")) then Hide() end
    elseif event == "UNIT_HEALTH" or event == "UNIT_HEALTH_FREQUENT" or event == "UNIT_MAXHEALTH" then
        if unit == "target" or unit == targetToken then
            if UnitIsDeadOrGhost("target") then Hide()
            elseif targetBar then UpdateHealth() end
        end
    elseif event == "UNIT_POWER_UPDATE" or event == "UNIT_POWER_FREQUENT" then
        if unit == "player" and (power == "COMBO_POINTS" or power == "COMBOPOINTS" or power == comboType or power == nil) then UpdateCombo() end
    elseif event == "UNIT_COMBO_POINTS" then
        if not unit or unit == "player" or unit == "target" then UpdateCombo() end
    elseif event == "UNIT_DISPLAYPOWER" then
        if unit == "player" then Refresh() end
    elseif event == "UNIT_FACTION" then
        if unit == "target" or unit == targetToken then Refresh() end
    else
        if event == "PLAYER_ENTERING_WORLD" then activeTokens = {} end
        RefreshWithRetry()
    end
end)

-- Settings panel belongs to Action Hero's existing profile system.
function M.BuildPanel(parent, save)
    if panel then return end
    panel = CreateFrame("Frame", nil, parent)
    panel:SetAllPoints(parent)
    panel:Hide()
    panel.checks, panel.sliders = {}, {}
    local function label(text, x, y, template)
        local f = panel:CreateFontString(nil, "OVERLAY", template or "GameFontHighlight")
        f:SetPoint("TOPLEFT", panel, "TOPLEFT", x, y); f:SetText(text)
        return f
    end
    local function changed(key, value)
        db[key] = value
        M.Configure(db)
        save()
        M.RefreshPanel(true)
    end
    local function check(key, title, y, combo)
        local c = CreateFrame("CheckButton", nil, panel, "UICheckButtonTemplate")
        c:SetSize(24, 24); c:SetPoint("TOPLEFT", panel, "TOPLEFT", 8, y)
        local t = label(title, 38, y - 5)
        c:SetScript("OnClick", function(self) changed(key, not not self:GetChecked()) end)
        panel.checks[key] = { control = c, label = t, combo = combo }
    end
    local function slider(key, title, lo, hi, step, y, combo, percent)
        local t = label(title, 12, y, "GameFontHighlightSmall")
        local value = panel:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
        value:SetPoint("TOPRIGHT", panel, "TOPRIGHT", -15, y)
        local s = CreateFrame("Slider", nil, panel)
        s:SetPoint("TOPLEFT", panel, "TOPLEFT", 14, y - 16); s:SetSize(380, 14)
        s:SetOrientation("HORIZONTAL"); s:SetMinMaxValues(lo, hi); s:SetValueStep(step)
        if s.SetObeyStepOnDrag then s:SetObeyStepOnDrag(true) end
        s:SetThumbTexture("Interface\\Buttons\\UI-SliderBar-Button-Horizontal")
        local track = s:CreateTexture(nil, "BACKGROUND")
        track:SetColorTexture(0.36, 0.32, 0.25, 0.9); track:SetPoint("LEFT", 2, 0); track:SetPoint("RIGHT", -2, 0); track:SetHeight(3)
        s:SetScript("OnValueChanged", function(self, v)
            if self.settingValue then return end
            changed(key, math.floor(v / step + 0.5) * step)
        end)
        panel.sliders[key] = { control = s, label = t, value = value, combo = combo, percent = percent }
    end
    label("TARGET NAMEPLATE", 8, -8, "GameFontNormalSmall")
    check("npBigger", "Bigger HP bar for target", -26)
    check("npPercent", "% in HP bar", -52)
    slider("npHealthScale", "Target HP bar size", 1.1, 1.8, 0.05, -83, false, true)
    label("COMBO POINTS (ROGUE / CAT FORM)", 8, -123, "GameFontNormalSmall")
    check("npCombo", "Show combo points on target", -141, true)
    check("npHideZero", "Hide when no combo points", -167, true)
    check("npBelow", "Position below HP bar", -193, true)
    check("npGlow", "Glow at five points", -219, true)
    slider("npPointSize", "Point size", 8, 24, 1, -250, true)
    slider("npSpacing", "Point spacing", 0, 12, 1, -288, true)
    slider("npOffsetX", "Horizontal offset", -40, 40, 1, -326, true)
    slider("npOffsetY", "Vertical offset (away from bar)", -20, 40, 1, -364, true)
    label("Only the current hostile target is decorated.", 12, -409, "GameFontDisableSmall")
end
function M.RefreshPanel(visible)
    if not panel then return end
    panel:SetShown(visible)
    if not visible or not db then return end
    local eligible = EligibleClass()
    for key, entry in pairs(panel.checks) do
        local enabled = not entry.combo or eligible
        entry.control:SetChecked(db[key]); if enabled then entry.control:Enable() else entry.control:Disable() end
        entry.label:SetAlpha(enabled and 1 or 0.45)
    end
    for key, entry in pairs(panel.sliders) do
        local enabled = (not entry.combo or eligible) and (key ~= "npHealthScale" or db.npBigger)
        local s = entry.control
        s.settingValue = true; s:SetValue(db[key]); s.settingValue = false
        s:EnableMouse(enabled); s:SetAlpha(enabled and 1 or 0.45)
        entry.label:SetAlpha(enabled and 1 or 0.45)
        entry.value:SetText(entry.percent and string.format("%.0f%%", db[key] * 100) or string.format("%.0f", db[key]))
    end
end
