-- Action Hero 2.2.7 | World of Warcraft: Forever (Interface 16001)
-- Seven configurable action bars with compact slots and movable bottom UI controls.

local ADDON_NAME, addonNS = ...
local Nameplates = addonNS.Nameplates
local PREFIX = "|cffd9a64bAction Hero|r"
local VERSION = "2.2.7"
local Recovery = addonNS.Recovery
local temporaryHidden, pendingVisibility = false, false
local recoveryButton, visibilityButton

local BAR_COUNT = 7
local OPTION_ROWS = {
    { key = "editMode", category = "GENERAL", label = "Edit mode (show empty slots)", description = "Show all 12 slots on every bar so you can add or rearrange actions.", default = false },
    { key = "rightClickIconEdit", category = "GENERAL", label = "Right-click to customize slots", description = "Choose an icon or short text label; the assigned action stays unchanged.", default = true, indent = true },
    { key = "transparentSettings", category = "GENERAL", label = "Transparent settings window", description = "Let the game world show through the settings background.", default = false },
    { key = "showMinimapButton", category = "GENERAL", label = "Show minimap button", description = "Left-click opens settings; right-click temporarily reveals hidden bars, then restores them.", default = true },
    { key = "showFlightStop", category = "GENERAL", label = "Show flight landing button", description = "Show Land at next stop while riding a flight path.", default = true },
    { key = "defaultBottomView", category = "BOTTOM UI", label = "Show default bottom UI", description = "Reloads the UI to switch between Blizzard's layout and your saved Action Hero layout.", default = false },
    { key = "hideMainActionBar", category = "BOTTOM UI", label = "Hide original action bar", description = "Removes the old bar and its decorative outline.", default = true },
    { key = "hideMicroMenu", category = "BOTTOM UI", label = "Hide menu icons", description = "Hides the character, spellbook, talents, map and other menu buttons.", default = true },
    { key = "moveMenuIcons", category = "BOTTOM UI", label = "Allow moving menu icons", description = "Adds a drag handle to move the menu icons together.", default = false },
    { key = "hideBagBar", category = "BOTTOM UI", label = "Hide bag bar", description = "Hides the backpack, bag buttons and keyring.", default = true },
    { key = "showSingleBagButton", category = "BOTTOM UI", label = "Show one movable backpack button", description = "Replaces the bag bar with one movable backpack button.", default = false },
    { key = "hideExperienceBar", category = "BOTTOM UI", label = "Hide original XP bar", description = "Hides the XP bar and resting indicator.", default = true },
    { key = "hideReputationBar", category = "BOTTOM UI", label = "Hide reputation bar", description = "Hides the watched reputation or honor bar.", default = true },
    { key = "showBar1", category = "BARS", label = "Show Action Hero bar 1", description = "Uses Blizzard Action Bar 1.", default = true },
    { key = "showBar2", category = "BARS", label = "Show Action Hero bar 2", description = "Uses Blizzard Multi Action Bar 1 (Bottom Left).", default = true },
    { key = "showBar3", category = "BARS", label = "Show Action Hero bar 3", description = "Uses Blizzard Multi Action Bar 2 (Bottom Right).", default = true },
    { key = "showBar4", category = "BARS", label = "Show Action Hero bar 4", description = "Uses Blizzard Multi Action Bar 3 (Right).", default = true },
    { key = "showBar5", category = "BARS", label = "Show Action Hero bar 5", description = "Uses Blizzard Multi Action Bar 4 (Left).", default = true },
    { key = "showBar6", category = "BARS", label = "Show Action Hero bar 6", description = "Native Extra Bar 1 (optional).", default = false },
    { key = "showBar7", category = "BARS", label = "Show Action Hero bar 7", description = "Native Extra Bar 2 (optional).", default = false },
    { key = "showLabels", category = "GENERAL", label = "Show bar labels", description = "Show Action Hero labels above the action bars.", default = false },
    { key = "lockBars", category = "GENERAL", label = "Lock action bars", description = "Prevent dragging, snapping and resizing the rows.", default = false },
}

local DB
local waitingForCombat = false
local settingsWindow, settingsContent, statusText
local optionChecks, optionRows = {}, {}
local settingsTabs, activeSettingsTab = {}, "GENERAL"
local settingsAppearancePanel
local barScaleSliders, barScaleLabels = {}, {}
local barControls, expandedBar = {}, nil
local keybindNote
local hiddenParent = CreateFrame("Frame")
hiddenParent:Hide()
local menuMoveHandle, singleBagAnchor, singleBagButton, singleBagMoveHandle
local minimapButton, minimapRefreshPending
local emergencyBarsRevealed = false
local druidFormBarFrame, druidFormRow, druidFormMoveHandle
local druidFormButtons, druidFormButtonOrigins = {}, {}
local druidSettingsPanel, druidBlizzardModeButton, druidActionHeroModeButton, druidMoveFormCheck
local druidMoveFormLabel, druidMoveFormDescription
local menuFrame, appliedMenuPoint, nativeMenuPoints
local movingMenu
local MenuGuard = { hooked = setmetatable({}, { __mode = "k" }) }
local originalParents = { main = {}, menu = {}, bags = {}, xp = {}, rep = {}, secondaryBars = {}, forms = {} }
local statusBarHooks = setmetatable({}, { __mode = "k" })
local bars, barHeaders, barLabels, barGrips, barButtons = {}, {}, {}, {}, {}
local barsReady = false
local editModeBadge
local RefreshSettingsLayout
local RefreshIconEditOverlays, ShowActionIconPicker
local SavePoint, RestorePoint
local CreateMinimapButton
local formLayout = {}
local formDragProfile
local nativeFormPoints
local ApplyDruidForms
local SaveActiveProfile
local SelectProfile
local profileDropdown, profileNameDialog, profileModalBlocker, styleButton
local iconScaleText, opacityText, equippedHighlightText, equippedHighlightSlider
local RefreshAppearanceControls
local BAR_SKINS = {
    { key = "Classic", label = "Classic (current)", background = { 0, 0, 0, 0 }, edge = { 0, 0, 0, 0 } },
    { key = "Dark", label = "Dark backing", background = { 0.035, 0.03, 0.025, 0.62 }, edge = { 0.54, 0.48, 0.34, 0.78 } },
    { key = "Gold", label = "Dark with gold trim", background = { 0.035, 0.03, 0.025, 0.72 }, edge = { 0.78, 0.55, 0.19, 0.95 } },
    { key = "BlueSteel", label = "Blue Steel (experimental)", background = { 0.025, 0.04, 0.075, 0.74 }, edge = { 0.28, 0.57, 0.92, 0.95 } },
    { key = "Emerald", label = "Emerald (experimental)", background = { 0.025, 0.065, 0.04, 0.74 }, edge = { 0.22, 0.75, 0.42, 0.95 } },
}
local TEXT_COLORS = {
    { key = "gold", label = "Gold", color = { 1, 0.84, 0.35 } },
    { key = "white", label = "White", color = { 1, 1, 1 } },
    { key = "cyan", label = "Cyan", color = { 0.38, 0.88, 1 } },
    { key = "green", label = "Green", color = { 0.45, 1, 0.45 } },
    { key = "red", label = "Red", color = { 1, 0.45, 0.4 } },
}
local UpdateEditModeBadge

local function GetBarSkin(key)
    for _, skin in ipairs(BAR_SKINS) do
        if skin.key == key then return skin end
    end
    return BAR_SKINS[1]
end

local function GetBarSkinLabel(key)
    return GetBarSkin(key).label
end

local function CopyTable(source)
    local copy = {}
    for key, value in pairs(source or {}) do
        copy[key] = type(value) == "table" and CopyTable(value) or value
    end
    return copy
end

local function CaptureSettings(settings)
    local snapshot = {}
    for key, value in pairs(settings or DB or {}) do
        if key ~= "profiles" and key ~= "activeProfile" and key ~= "defaultBottomView" and key ~= "profileBackups" and key ~= "druidPagingFix" then
            snapshot[key] = type(value) == "table" and CopyTable(value) or value
        end
    end
    return snapshot
end

SaveActiveProfile = function()
    if not DB or type(DB.profiles) ~= "table" then return end
    local name = DB.activeProfile or "Default"
    DB.profiles[name] = CaptureSettings()
end

local function RememberLayout()
    if DB then Recovery.Remember(DB) end
end

local function ApplyBarSkins()
    if not DB then return end
    local skin = GetBarSkin(DB.barSkin)
    for index = 1, BAR_COUNT do
        local bar = bars[index]
        if bar and bar.skinBackground then
            local background, edge = skin.background, skin.edge
            bar.skinBackground:SetColorTexture(background[1], background[2], background[3], background[4])
            for _, edgeTexture in ipairs(bar.skinEdges) do
                edgeTexture:SetColorTexture(edge[1], edge[2], edge[3], edge[4])
            end
        end
    end
    if druidFormRow and druidFormRow.SetBackdropColor then
        local background, edge = skin.background, skin.edge
        druidFormRow:SetBackdropColor(background[1], background[2], background[3], background[4])
        druidFormRow:SetBackdropBorderColor(edge[1], edge[2], edge[3], edge[4])
    end
end

local function ApplyBarAppearance()
    if not DB then return end
    local iconScale = DB.iconScale or 1
    local opacity = DB.barOpacity or 1
    for _, bar in pairs(bars) do
        if bar then bar:SetAlpha(opacity) end
    end
    for _, buttons in pairs(barButtons) do
        for _, button in pairs(buttons) do
            if button then
                button:SetScale(iconScale)
            end
        end
    end
    if druidFormRow then druidFormRow:SetScale(DB.barScale1 or 1) end
end

UpdateEditModeBadge = function()
    if not editModeBadge then
        editModeBadge = CreateFrame("Frame", "ActionHeroEditModeBadge", UIParent, "BackdropTemplate")
        editModeBadge:SetSize(62, 18)
        editModeBadge:SetFrameStrata("HIGH")
        editModeBadge:EnableMouse(true)
        editModeBadge:SetBackdrop({ bgFile = "Interface\\Buttons\\WHITE8X8", edgeFile = "Interface\\Buttons\\WHITE8X8", edgeSize = 1 })
        editModeBadge:SetBackdropColor(0.035, 0.03, 0.02, 0.88)
        editModeBadge:SetBackdropBorderColor(0.72, 0.53, 0.20, 0.85)
        local text = editModeBadge:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
        text:SetPoint("CENTER")
        text:SetText("EDIT MODE")
        text:SetTextColor(1, 0.82, 0.25)
        editModeBadge:SetScript("OnEnter", function(self)
            GameTooltip:SetOwner(self, "ANCHOR_TOPLEFT")
            GameTooltip:SetText("Edit Mode")
            GameTooltip:AddLine("Empty slots are shown. Drag actions onto them, then turn Edit Mode off to compact the bars.", 1, 1, 1, true)
            GameTooltip:Show()
        end)
        editModeBadge:SetScript("OnLeave", function() GameTooltip:Hide() end)
    end
    if not DB or not DB.editMode then editModeBadge:Hide(); return end
    local anchorBar
    for index = 1, BAR_COUNT do
        if (emergencyBarsRevealed or DB["showBar" .. index]) and bars[index] and bars[index]:IsShown() then
            anchorBar = bars[index]
            break
        end
    end
    if not anchorBar then editModeBadge:Hide(); return end
    editModeBadge:ClearAllPoints()
    editModeBadge:SetPoint("BOTTOMLEFT", anchorBar, "TOPLEFT", 2, 20)
    editModeBadge:SetFrameLevel(anchorBar:GetFrameLevel() + 20)
    editModeBadge:Show()
end

local function Message(text)
    if DEFAULT_CHAT_FRAME then DEFAULT_CHAT_FRAME:AddMessage(PREFIX .. ": " .. text) end
end

local function InCombat()
    return type(InCombatLockdown) == "function" and InCombatLockdown()
end

local function UpdateStatus()
    if not statusText then return end
    if waitingForCombat and InCombat() then
        statusText:SetText("Changes will apply after combat.")
    else
        statusText:SetText("Settings save automatically. Type /actionhero to reopen.")
    end
end

local function HideWithParent(frame, bucket)
    if not frame then return end
    if bucket[frame] == nil then bucket[frame] = frame:GetParent() or UIParent end
    if frame:GetParent() ~= hiddenParent then frame:SetParent(hiddenParent) end
end

local function RestoreParents(bucket)
    for frame, parent in pairs(bucket) do
        if frame:GetParent() == hiddenParent then frame:SetParent(parent) end
        bucket[frame] = nil
    end
end

local function ApplyMainActionBar()
    local frames = {
        "MainMenuBar", "MainActionBar", "MainMenuBarArtFrame",
        "MainMenuBarLeftEndCap", "MainMenuBarRightEndCap",
        "ActionBarUpButton", "ActionBarDownButton", "MainMenuBarPageNumber",
    }
    if DB.hideMainActionBar then
        for _, name in ipairs(frames) do HideWithParent(_G[name], originalParents.main) end
    else
        RestoreParents(originalParents.main)
    end
end

local BAG_FALLBACKS = {
    "MainMenuBarBackpackButton", "CharacterBag0Slot", "CharacterBag1Slot",
    "CharacterBag2Slot", "CharacterBag3Slot", "CharacterBag4Slot",
    "ReagentBagSlot", "KeyRingButton", "BagBarExpandToggle",
}

local function CreateMoveHandle(owner, text, optionKey, saveKey)
    local handle = CreateFrame("Button", nil, owner, "BackdropTemplate")
    handle:EnableMouse(true)
    handle:SetSize(42, 16)
    handle:SetPoint("BOTTOMLEFT", owner, "TOPLEFT", 0, 2)
    handle:SetFrameLevel((owner:GetFrameLevel() or 1) + 8)
    handle:SetBackdrop({ bgFile = "Interface\\Buttons\\WHITE8X8", edgeFile = "Interface\\Tooltips\\UI-Tooltip-Border", edgeSize = 8, insets = { left = 2, right = 2, top = 2, bottom = 2 } })
    handle:SetBackdropColor(0.08, 0.08, 0.08, 0.82)
    handle:SetBackdropBorderColor(0.68, 0.54, 0.27, 0.85)
    local label = handle:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
    label:SetPoint("CENTER")
    label:SetText(text)
    handle:RegisterForDrag("LeftButton")
    handle:SetScript("OnDragStart", function()
        if DB and DB[optionKey] and not InCombat() then
            owner:StartMoving()
            handle.moving = true
            if saveKey == "menuPoint" then movingMenu = handle end
        end
    end)
    handle:SetScript("OnDragStop", function()
        if not handle.moving then return end
        if InCombat() and saveKey == "menuPoint" then waitingForCombat = true; return end
        handle.moving = false
        if movingMenu == handle then movingMenu = nil end
        owner:StopMovingOrSizing()
        SavePoint(owner, saveKey)
        if saveKey == "menuPoint" then
            appliedMenuPoint = DB.menuPoint
            MenuGuard.Queue()
        end
    end)
    handle:SetScript("OnEnter", function(self)
        GameTooltip:SetOwner(self, "ANCHOR_TOPLEFT")
        GameTooltip:SetText("Drag to move " .. text)
        GameTooltip:Show()
    end)
    handle:SetScript("OnLeave", function() GameTooltip:Hide() end)
    return handle
end

local appliedBagPoint
local function ApplySingleBagPoint()
    if DB.singleBagPoint then
        RestorePoint(singleBagAnchor, DB.singleBagPoint, 0)
    else
        singleBagAnchor:ClearAllPoints()
        singleBagAnchor:SetPoint("BOTTOMRIGHT", UIParent, "BOTTOMRIGHT", -70, 150)
    end
    appliedBagPoint = DB.singleBagPoint
end

local function EnsureSingleBagAnchor()
    if not singleBagAnchor then
        singleBagAnchor = CreateFrame("Frame", "ActionHeroSingleBagAnchor", UIParent)
        singleBagAnchor:SetSize(42, 42)
        singleBagAnchor:SetMovable(true)
        singleBagAnchor:EnableMouse(true)
        singleBagAnchor:SetClampedToScreen(true)
        ApplySingleBagPoint()
        singleBagMoveHandle = CreateMoveHandle(singleBagAnchor, "BAG", "showSingleBagButton", "singleBagPoint")
    end
end

local function EnsureSingleBagButton()
    if not singleBagButton then
        -- Bag toggling is a harmless UI action, so use the native API directly
        -- instead of forwarding clicks to a hidden/protected Blizzard button.
        singleBagButton = CreateFrame("Button", "ActionHeroSingleBagButton", singleBagAnchor)
        singleBagButton:SetSize(38, 38)
        singleBagButton:SetPoint("CENTER", singleBagAnchor, "CENTER")
        singleBagButton:RegisterForClicks("LeftButtonUp")
        singleBagButton:RegisterForDrag("RightButton")
        singleBagButton:SetNormalTexture("Interface\\Buttons\\UI-Quickslot2")
        singleBagButton:SetPushedTexture("Interface\\Buttons\\UI-Quickslot-Depress")
        singleBagButton:SetHighlightTexture("Interface\\Buttons\\ButtonHilight-Square", "ADD")
        local icon = singleBagButton:CreateTexture(nil, "ARTWORK")
        icon:SetSize(34, 34)
        icon:SetPoint("CENTER")
        local nativeButton = _G.MainMenuBarBackpackButton or _G.BackpackButton
        local nativeIcon = nativeButton and (nativeButton.icon or nativeButton.Icon or _G.MainMenuBarBackpackButtonIconTexture)
        local iconTexture = nativeIcon and nativeIcon.GetTexture and nativeIcon:GetTexture()
        icon:SetTexture(iconTexture or "Interface\\Buttons\\Button-Backpack-Up")
        singleBagButton:SetScript("OnEnter", function(self)
            GameTooltip:SetOwner(self, "ANCHOR_TOPLEFT")
            GameTooltip:SetText(BACKPACK_TOOLTIP or "Backpack")
            GameTooltip:Show()
        end)
        singleBagButton:SetScript("OnLeave", function() GameTooltip:Hide() end)
        singleBagButton:SetScript("OnClick", function(_, mouseButton)
            if mouseButton == "LeftButton" and type(ToggleBackpack) == "function" then
                ToggleBackpack()
            end
        end)
        singleBagButton:SetScript("OnDragStart", function()
            if DB and DB.showSingleBagButton and not InCombat() then singleBagAnchor:StartMoving() end
        end)
        singleBagButton:SetScript("OnDragStop", function()
            singleBagAnchor:StopMovingOrSizing()
            SavePoint(singleBagAnchor, "singleBagPoint")
        end)
    end
end

local function ApplyBagBar()
    local shouldShowSingle = DB.hideBagBar and DB.showSingleBagButton

    if shouldShowSingle then
        EnsureSingleBagAnchor()
        EnsureSingleBagButton()
        if appliedBagPoint ~= DB.singleBagPoint then ApplySingleBagPoint() end
        singleBagButton:Show()
    end

    if DB.hideBagBar then
        HideWithParent(_G.BagsBar, originalParents.bags)
        -- Hide each legacy button too; some clients place the expand toggle
        -- outside BagsBar, which otherwise leaves a stray empty square behind.
        for _, name in ipairs(BAG_FALLBACKS) do
            local button = _G[name]
            if button and not (_G.BagsBar and button:GetParent() == _G.BagsBar) then
                HideWithParent(button, originalParents.bags)
            end
        end
    else
        RestoreParents(originalParents.bags)
    end

    if singleBagAnchor then
        if shouldShowSingle then
            singleBagAnchor:Show()
            singleBagMoveHandle:Show()
        else
            singleBagButton:Hide()
            singleBagAnchor:Hide()
            singleBagMoveHandle:Hide()
        end
    end
end

-- The native layout can re-anchor the micro menu without replacing DB.menuPoint.
-- Observe native changes, then compare actual anchors against the saved position.
-- Never change the native menu synchronously from a secure post-hook.
function MenuGuard.Eligible()
    return DB and not DB.defaultBottomView and not DB.hideMicroMenu
        and not movingMenu and menuFrame and Recovery.ValidPoint(DB.menuPoint)
        and menuFrame == (_G.MicroMenu or _G.MicroMenuContainer)
end

function MenuGuard.Matches(frame, saved)
    if frame:GetNumPoints() ~= 1 then return false end
    local point, relative, relativePoint, x, y = frame:GetPoint(1)
    return point == saved[1] and (relative == UIParent or relative == "UIParent")
        and relativePoint == saved[2] and math.abs((x or 0) - saved[3]) < 0.05
        and math.abs((y or 0) - saved[4]) < 0.05
end

function MenuGuard.Repair()
    if not MenuGuard.Eligible() or MenuGuard.applying then return false end
    if InCombat() then return false end
    if not MenuGuard.Matches(menuFrame, DB.menuPoint) then
        MenuGuard.applying = true
        RestorePoint(menuFrame, DB.menuPoint, 0)
        MenuGuard.applying = false
    end
    appliedMenuPoint = DB.menuPoint
    return true
end

function MenuGuard.Queue()
    if not MenuGuard.Eligible() or MenuGuard.applying or MenuGuard.queued then return end
    if InCombat() then return end -- PLAYER_REGEN_ENABLED checks the actual anchor.
    if not (C_Timer and C_Timer.After) then return end
    MenuGuard.queued = true
    C_Timer.After(0.05, function()
        MenuGuard.queued = false
        MenuGuard.Repair() -- Re-read current profile, visibility and combat state.
    end)
end

function MenuGuard.Watch(frame)
    if MenuGuard.hooked[frame] then return end
    MenuGuard.hooked[frame] = true
    local function changed()
        if menuFrame == frame then MenuGuard.Queue() end
    end
    if type(hooksecurefunc) == "function" then
        hooksecurefunc(frame, "SetPoint", changed)
        hooksecurefunc(frame, "ClearAllPoints", changed)
    end
    frame:HookScript("OnShow", changed)
    frame:HookScript("OnSizeChanged", changed)
end

local function ApplyMicroMenu()
    menuFrame = _G.MicroMenu or _G.MicroMenuContainer
    if DB.hideMicroMenu then
        if menuFrame then HideWithParent(menuFrame, originalParents.menu) end
        if menuMoveHandle then menuMoveHandle:Hide() end
    else
        RestoreParents(originalParents.menu)
        if menuFrame then
            menuFrame:SetMovable(true)
            menuFrame:SetClampedToScreen(true)
            if not nativeMenuPoints then
                nativeMenuPoints = {}
                for index = 1, menuFrame:GetNumPoints() do
                    nativeMenuPoints[index] = { menuFrame:GetPoint(index) }
                end
            end
            if not movingMenu then
                if DB.menuPoint then
                    MenuGuard.Repair()
                elseif appliedMenuPoint then
                    menuFrame:ClearAllPoints()
                    for _, point in ipairs(nativeMenuPoints) do menuFrame:SetPoint(unpack(point, 1, 5)) end
                    if menuFrame.SetUserPlaced then menuFrame:SetUserPlaced(false) end
                    appliedMenuPoint = nil
                end
            end
            MenuGuard.Watch(menuFrame)
            if not menuMoveHandle then menuMoveHandle = CreateMoveHandle(menuFrame, "MENU", "moveMenuIcons", "menuPoint") end
            if DB.moveMenuIcons then menuMoveHandle:Show() else menuMoveHandle:Hide() end
        end
    end
end

local RestoreActionBarLayout
local draggingBar

local function ReapplySavedCustomPositions()
    if not DB or DB.defaultBottomView then return end
    if InCombat() then waitingForCombat = true; return end
    RestoreActionBarLayout()
    if not DB.hideMicroMenu then ApplyMicroMenu() end
    if DB.hideBagBar and DB.showSingleBagButton and singleBagAnchor and DB.singleBagPoint then
        RestorePoint(singleBagAnchor, DB.singleBagPoint, 0)
    end
    if ApplyDruidForms then ApplyDruidForms(true) end
end

local function KeepStatusBarHiddenWhileEnabled(frame, optionKey)
    if not frame then return end
    if not statusBarHooks[frame] then
        statusBarHooks[frame] = true
        frame:HookScript("OnShow", function(self)
            if DB and DB[optionKey] then self:Hide() end
        end)
    end
    if DB[optionKey] then frame:Hide() end
end

local function RefreshStatusTrackingManager()
    local manager = _G.StatusTrackingBarManager
    if manager and type(manager.UpdateBarsShown) == "function" then
        manager:UpdateBarsShown()
    end
end

local function ApplyExperienceBar()
    local names = { "MainMenuExpBar", "MainMenuXPBar", "MainMenuBarMaxLevelBar", "ExhaustionTick", "ExhaustionLevelFillBar" }
    if DB.hideExperienceBar then
        for _, name in ipairs(names) do HideWithParent(_G[name], originalParents.xp) end
    else
        RestoreParents(originalParents.xp)
    end
    KeepStatusBarHiddenWhileEnabled(_G.MainStatusTrackingBarContainer, "hideExperienceBar")
    RefreshStatusTrackingManager()
end

local function ApplyReputationBar()
    local names = { "ReputationWatchBar", "HonorWatchBar" }
    if DB.hideReputationBar then
        for _, name in ipairs(names) do HideWithParent(_G[name], originalParents.rep) end
    else
        RestoreParents(originalParents.rep)
    end
    KeepStatusBarHiddenWhileEnabled(_G.SecondaryStatusTrackingBarContainer, "hideReputationBar")
    RefreshStatusTrackingManager()
end

SavePoint = function(bar, key)
    -- Store an absolute UIParent-relative screen position. GetPoint offsets can
    -- be relative to Blizzard-owned parents that move during reload/layout.
    local left, bottom = bar:GetLeft(), bar:GetBottom()
    if left ~= nil and bottom ~= nil then
        DB[key] = { "BOTTOMLEFT", "BOTTOMLEFT", left, bottom }
    else
        local point, _, relativePoint, x, y = bar:GetPoint(1)
        DB[key] = { point or "BOTTOM", relativePoint or point or "BOTTOM", x or 0, y or 0 }
    end
    if SaveActiveProfile then SaveActiveProfile() end
end

RestorePoint = function(bar, saved, fallbackY)
    bar:ClearAllPoints()
    if type(saved) == "table" then
        bar:SetPoint(saved[1] or "BOTTOM", UIParent, saved[2] or saved[1] or "BOTTOM", saved[3] or 0, saved[4] or fallbackY)
    else
        bar:SetPoint("BOTTOM", UIParent, "BOTTOM", 0, fallbackY)
    end
end

local xpModes = {
    { name = "Off", key = "off" },
    { name = "Horizontal bar", key = "bar" },
    { name = "Percentage square", key = "square" },
    { name = "Percentage text", key = "text" },
}
local xpDisplay, xpSelector, xpResetButton

local function FormatXP(amount)
    local digits = string.format("%d", amount)
    local grouped = digits:reverse():gsub("(%d%d%d)", "%1,"):reverse()
    return (grouped:gsub("^,", ""))
end

local function XPProgressText(current, maximum)
    return string.format("%s / %s XP (%s left)", FormatXP(current), FormatXP(maximum),
        FormatXP(math.max(0, maximum - current)))
end

local function RefreshXPTooltip(frame)
    local _, maximum = frame:GetMinMaxValues()
    GameTooltip:SetText(XPProgressText(frame:GetValue(), maximum), 1, 1, 1)
    local rested = GetXPExhaustion and GetXPExhaustion() or 0
    if maximum > 0 then
        GameTooltip:AddLine(string.format("Rested XP: %s (%.1f%% of a level)", FormatXP(rested), rested * 100 / maximum), 1, 0.84, 0.2)
    end
    GameTooltip:Show()
end

local function HideXPTooltip(frame)
    if GameTooltip:IsOwned(frame) then GameTooltip:Hide() end
end

local function UpdateXP()
    if not xpDisplay then return end
    local maximum = UnitXPMax("player") or 0
    if DB.defaultBottomView or not DB.hideExperienceBar or DB.xpMode == "off" or maximum <= 0
        or (IsPlayerAtEffectiveMaxLevel and IsPlayerAtEffectiveMaxLevel()) then
        xpDisplay:Hide()
        return
    end
    local current = math.max(0, math.min(maximum, UnitXP("player") or 0))
    local percent = math.floor(current * 100 / maximum)
    xpDisplay:SetMinMaxValues(0, maximum)
    xpDisplay:SetValue(current)
    if DB.xpMode == "bar" then
        xpDisplay.label:SetFormattedText("%s  %d%%", XPProgressText(current, maximum), percent)
        xpDisplay:SetWidth(math.max(220, xpDisplay.label:GetStringWidth() + 16))
    else
        xpDisplay.label:SetFormattedText("%d%%", percent)
    end
    local rested = GetXPExhaustion and GetXPExhaustion() or 0
    local span = math.min(rested, maximum - current)
    local bonus = xpDisplay.restedFill
    if span > 0 and DB.xpMode ~= "text" then
        local width, height = xpDisplay:GetSize()
        bonus:ClearAllPoints()
        if DB.xpMode == "square" then
            bonus:SetPoint("BOTTOMLEFT", xpDisplay, "BOTTOMLEFT", 0, height * current / maximum)
            bonus:SetSize(width, height * span / maximum)
        else
            bonus:SetPoint("BOTTOMLEFT", xpDisplay, "BOTTOMLEFT", width * current / maximum, 0)
            bonus:SetSize(width * span / maximum, height)
        end
        bonus:Show()
    else
        bonus:Hide()
    end
    xpDisplay:Show()
    if GameTooltip:IsOwned(xpDisplay) then RefreshXPTooltip(xpDisplay) end
end

local function ApplyXPDisplay()
    if DB.defaultBottomView or not DB.hideExperienceBar or DB.xpMode == "off" or not DB.xpMode then
        if xpDisplay then xpDisplay:Hide() end
        return
    end
    if not xpDisplay then
        local frame = CreateFrame("StatusBar", "ActionHeroXPDisplay", UIParent)
        xpDisplay = frame
        frame:SetStatusBarTexture("Interface\\Buttons\\WHITE8X8")
        frame.background = frame:CreateTexture(nil, "BACKGROUND")
        frame.background:SetAllPoints()
        frame.restedFill = frame:CreateTexture(nil, "ARTWORK")
        frame.restedFill:SetColorTexture(1, 0.84, 0.2, 0.85)
        frame.label = frame:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
        frame.label:SetPoint("CENTER")
        frame:SetMovable(true)
        frame:SetClampedToScreen(true)
        frame:RegisterForDrag("LeftButton")
        frame:SetScript("OnDragStart", function(self)
            if not DB.lockBars then self:StartMoving() end
        end)
        frame:SetScript("OnDragStop", function(self)
            self:StopMovingOrSizing()
            SavePoint(self, "xpPoint")
        end)
        frame:SetScript("OnEnter", function(self)
            GameTooltip:SetOwner(self, "ANCHOR_TOP")
            RefreshXPTooltip(self)
        end)
        frame:SetScript("OnLeave", HideXPTooltip)
        frame:SetScript("OnHide", HideXPTooltip)
        frame:RegisterEvent("UPDATE_EXHAUSTION")
        frame:RegisterEvent("PLAYER_XP_UPDATE")
        frame:RegisterEvent("PLAYER_LEVEL_UP")
        frame:SetScript("OnEvent", UpdateXP)
    end
    local square = DB.xpMode == "square"
    local textOnly = DB.xpMode == "text"
    xpDisplay:SetSize(square and 44 or (textOnly and 54 or 220), square and 44 or 20)
    xpDisplay:SetOrientation(square and "VERTICAL" or "HORIZONTAL")
    xpDisplay:SetStatusBarColor(0.44, 0.22, 0.72, textOnly and 0 or 1)
    xpDisplay.background:SetColorTexture(0.09, 0.07, 0.13, textOnly and 0 or 0.9)
    xpDisplay:EnableMouse(true)
    if xpDisplay.SetMouseClickEnabled then xpDisplay:SetMouseClickEnabled(not DB.lockBars) end
    RestorePoint(xpDisplay, DB.xpPoint, 22)
    UpdateXP()
end

local function RestoreIndependentBarPoints()
    for index = 1, BAR_COUNT do
        if bars[index] then
            RestorePoint(bars[index], DB["barPoint" .. index], 54 + (index - 1) * 48)
        end
    end
end

local function ApplySnap()
    if not barsReady or not DB.barsSnapped then return end
    local first = math.max(1, math.min(BAR_COUNT, DB.snapLeader or 1))
    local breaks = type(DB.snapBreaks) == "table" and DB.snapBreaks or {}
    if not bars[first] then return end
    local vertical = DB["barVertical" .. first]
    local previous = first
    for index = first + 1, BAR_COUNT do
        -- Preserve the original five-bar horizontal stack. Extra bars only
        -- participate when explicitly shown, and mixed orientations never snap.
        if bars[index] and (index <= 5 or DB["showBar" .. index])
            and DB["barVertical" .. index] == vertical then
            if breaks[index - 1] then
                RestorePoint(bars[index], DB["barPoint" .. index], 54 + (index - 1) * 48)
            else
                bars[index]:ClearAllPoints()
                if vertical then
                    bars[index]:SetPoint("TOPLEFT", bars[previous], "TOPRIGHT", 4, 0)
                else
                    bars[index]:SetPoint("TOP", bars[previous], "BOTTOM", 0, -4)
                end
            end
            previous = index
        end
    end
end

RestoreActionBarLayout = function()
    if not barsReady or draggingBar or InCombat() then return end
    RestoreIndependentBarPoints()
    ApplySnap()
end

local function DetachBarAtCurrentPosition(index)
    local bar = bars[index]
    if not bar then return end
    local left, bottom = bar:GetLeft(), bar:GetBottom()
    bar:ClearAllPoints()
    bar:SetPoint("BOTTOMLEFT", UIParent, "BOTTOMLEFT", left or 0, bottom or 0)
    SavePoint(bar, "barPoint" .. index)
end

local function SplitStackForDragging(index)
    local leader = DB.snapLeader or 1
    if not DB.barsSnapped or index <= leader or not bars[leader]
        or DB["barVertical" .. index] ~= DB["barVertical" .. leader] then return end
    DB.snapBreaks = type(DB.snapBreaks) == "table" and DB.snapBreaks or {}
    -- Split only the link above the grabbed follower. The grabbed bar and all
    -- bars below it remain snapped together and move as one subgroup.
    DB.snapBreaks[index - 1] = true
    DetachBarAtCurrentPosition(index)
    ApplySnap()
end

local function ToggleSnap(index)
    if not barsReady or DB.lockBars or InCombat() then return end
    RememberLayout()
    if DB.barsSnapped and DB.snapLeader == index then
        DB.barsSnapped = false
        DB.snapBreaks = {}
        RestoreIndependentBarPoints()
    else
        RestoreIndependentBarPoints()
        DB.snapLeader = index
        DB.snapBreaks = {}
        DB.barsSnapped = true
        ApplySnap()
    end
    if SaveActiveProfile then SaveActiveProfile() end
end

local function GetButtonIcon(button)
    if not button then return nil end
    if button.icon then return button.icon end
    local name = button.GetName and button:GetName()
    return name and _G[name .. "Icon"] or nil
end

local function GetActionSlot(button)
    return button and (button.action or (button.GetAttribute and button:GetAttribute("action")) or (button.GetID and button:GetID()))
end

local function IsActionButtonFilled(button)
    local slot = GetActionSlot(button)
    if not slot then return false end
    if type(GetActionInfo) == "function" then
        local actionType = GetActionInfo(slot)
        if actionType == nil then return false end
    elseif type(HasAction) == "function" and not HasAction(slot) then
        return false
    end
    local hasTextureAPI = type(GetActionTexture) == "function"
    if hasTextureAPI then
        local texture = GetActionTexture(slot)
        if texture == nil or texture == "" or texture == 0 then return false end
    end
    local icon = GetButtonIcon(button)
    -- A stale action slot can still report action data during temporary
    -- disenchant/cursor transitions. Require a real icon region and texture.
    if not icon or not icon.GetTexture then return false end
    local iconTexture = icon:GetTexture()
    if iconTexture == nil or iconTexture == "" or iconTexture == 0 then return false end
    if not hasTextureAPI and type(HasAction) == "function" then return HasAction(slot) end
    return true
end

local function UpdateEquippedItemHighlight(button)
    if not button then return end
    local glow = button.equippedItemHighlight
    if not glow then
        glow = button:CreateTexture(nil, "OVERLAY")
        glow:SetTexture("Interface\\Buttons\\UI-ActionButton-Border")
        glow:SetBlendMode("ADD")
        glow:SetVertexColor(1, 0.78, 0.24)
        button.equippedItemHighlight = glow
    end
    glow:ClearAllPoints()
    glow:SetPoint("CENTER", button, "CENTER")
    local width, height = button:GetSize()
    glow:SetSize((width or 36) * 1.25, (height or 36) * 1.25)
    local strength = DB and tonumber(DB.equippedHighlight) or 0
    local slot = GetActionSlot(button)
    local isEquipped = slot and type(IsEquippedAction) == "function" and IsEquippedAction(slot)
    if isEquipped and strength > 0 then
        glow:SetAlpha(math.min(1, strength))
        glow:Show()
    else
        glow:Hide()
    end
end

local function EnsureCustomTextOverlay(button)
    if not button or button.customTextOverlay then return button and button.customTextOverlay end
    local overlay = CreateFrame("Frame", nil, button:GetParent())
    button.customTextOverlay = overlay
    overlay:SetAllPoints(button)
    overlay:SetFrameLevel(button:GetFrameLevel() + 3)
    local background = overlay:CreateTexture(nil, "BACKGROUND")
    button.customTextBackground = background
    background:SetSize(34, 18)
    background:SetPoint("CENTER", overlay, "CENTER")
    background:SetColorTexture(0.015, 0.015, 0.02, 0.82)
    local label = overlay:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
    button.customTextLabel = label
    label:SetPoint("CENTER", overlay, "CENTER")
    label:SetWidth(38)
    label:SetHeight(22)
    label:SetJustifyH("CENTER")
    label:SetJustifyV("MIDDLE")
    label:SetWordWrap(false)
    label:SetShadowColor(0, 0, 0, 1)
    label:SetShadowOffset(1, -1)
    overlay:Hide()
    return overlay
end

local function ApplyCustomActionIcons()
    if not DB then return end
    for barIndex = 1, BAR_COUNT do
        for slotIndex = 1, 12 do
            local button = barButtons[barIndex] and barButtons[barIndex][slotIndex]
            if button then
                UpdateEquippedItemHighlight(button)
                local customBar = type(DB.customIcons) == "table" and DB.customIcons[barIndex]
                local override = type(customBar) == "table" and customBar[slotIndex]
                local icon = GetButtonIcon(button)
                local textOverlay = EnsureCustomTextOverlay(button)
                if type(override) == "table" and override.kind == "text" and type(override.text) == "string" then
                    if icon then icon:SetAlpha(0) end
                    if button.customTextLabel then
                        local length = #override.text
                        local baseSize = length > 6 and 8 or (length > 4 and 11 or 13)
                        button.customTextLabel:SetFont("Fonts\\FRIZQT__.TTF", baseSize * (tonumber(override.scale) or 1), "OUTLINE")
                        button.customTextLabel:SetText(override.text)
                        local color = { 1, 0.84, 0.35 }
                        for _, choice in ipairs(TEXT_COLORS) do
                            if choice.key == override.color then color = choice.color; break end
                        end
                        button.customTextLabel:SetTextColor(color[1], color[2], color[3])
                    end
                    if button.customTextBackground then
                        if override.background == false then button.customTextBackground:Hide() else button.customTextBackground:Show() end
                    end
                    if textOverlay then textOverlay:Show() end
                else
                    if icon then
                        icon:SetAlpha(1)
                        local texture = override
                        if type(override) == "table" then texture = override.texture or override.icon end
                        if type(texture) == "string" or type(texture) == "number" then
                            icon:SetTexture(texture)
                            button.actionHeroTexture = texture
                        elseif button.actionHeroTexture then
                            local slot = GetActionSlot(button)
                            if slot and GetActionTexture then icon:SetTexture(GetActionTexture(slot)) end
                            button.actionHeroTexture = nil
                        end
                    end
                    if textOverlay then textOverlay:Hide() end
                end
            end
        end
    end
end

local function CollectActionHeroIcons()
    local icons, seen = {}, {}
    local function add(texture)
        if texture and texture ~= "" and not seen[texture] then
            seen[texture] = true
            table.insert(icons, texture)
        end
    end
    local function appendFrom(api)
        if type(api) ~= "function" then return end
        local output = {}
        local results = { pcall(api, output) }
        if not results[1] then return end
        if type(results[2]) == "table" then
            for _, texture in pairs(results[2]) do add(texture) end
        else
            for index = 2, #results do
                if type(results[index]) == "string" or type(results[index]) == "number" then add(results[index]) end
            end
            for _, texture in pairs(output) do add(texture) end
        end
    end
    appendFrom(GetMacroIcons)
    appendFrom(GetMacroItemIcons)
    if #icons == 0 and type(GetNumMacroIcons) == "function" and type(GetMacroIconInfo) == "function" then
        local count = GetNumMacroIcons()
        for index = 1, count do add(select(2, GetMacroIconInfo(index)) or GetMacroIconInfo(index)) end
    end
    if #icons == 0 then
        add("Interface\\Icons\\INV_Misc_QuestionMark")
        add("Interface\\Icons\\INV_Misc_Cape_02")
        add("Interface\\Icons\\INV_Misc_Cape_18")
        add("Interface\\Icons\\INV_Misc_Cape_19")
    end
    return icons
end

local function EnsureProfileModalBlocker()
    if profileModalBlocker then return end
    local blocker = CreateFrame("Frame", "ActionHeroProfileModalBlocker", UIParent)
    profileModalBlocker = blocker
    blocker:SetAllPoints(UIParent)
    blocker:SetFrameStrata("FULLSCREEN_DIALOG")
    blocker:SetFrameLevel((settingsWindow and settingsWindow:GetFrameLevel() or 1) + 90)
    blocker:EnableMouse(true)
    blocker:SetScript("OnMouseDown", function() end)
    blocker:SetScript("OnMouseUp", function() end)
    blocker:SetScript("OnMouseWheel", function() end)
    blocker:Hide()
end

local function BuildActionIconPicker()
    if ActionHeroIconPicker then return ActionHeroIconPicker end
    EnsureProfileModalBlocker()
    local frame = CreateFrame("Frame", "ActionHeroIconPicker", UIParent, "BackdropTemplate")
    ActionHeroIconPicker = frame
    frame:SetSize(334, 370)
    frame:SetPoint("CENTER")
    frame:SetFrameStrata("FULLSCREEN_DIALOG")
    frame:SetFrameLevel((profileModalBlocker:GetFrameLevel() or 1) + 10)
    frame:SetBackdrop({ bgFile = "Interface\\Buttons\\WHITE8X8", edgeFile = "Interface\\DialogFrame\\UI-DialogBox-Border", tile = true, tileSize = 32, edgeSize = 24, insets = { left = 8, right = 8, top = 8, bottom = 8 } })
    frame:SetBackdropColor(0.045, 0.045, 0.05, 1)
    frame:EnableMouse(true)
    frame:SetScript("OnMouseDown", function() end)
    frame:SetScript("OnMouseUp", function() end)
    frame:SetScript("OnHide", function() if profileModalBlocker then profileModalBlocker:Hide() end end)

    local title = frame:CreateFontString(nil, "OVERLAY", "GameFontNormal")
    frame.title = title
    title:SetPoint("TOPLEFT", frame, "TOPLEFT", 18, -18)
    title:SetText("Choose slot icon")
    title:SetTextColor(1, 0.82, 0.28)

    local close = CreateFrame("Button", nil, frame, "UIPanelCloseButton")
    close:SetPoint("TOPRIGHT", frame, "TOPRIGHT", -5, -5)
    close:SetScript("OnClick", function() frame:Hide() end)

    local native = CreateFrame("Button", nil, frame, "UIPanelButtonTemplate")
    frame.nativeButton = native
    native:SetSize(120, 22)
    native:SetPoint("TOPLEFT", frame, "TOPLEFT", 18, -40)
    native:SetText("Use action icon")
    native:SetScript("OnClick", function()
        local target = frame.target
        if target and DB.customIcons and DB.customIcons[target.bar] then
            DB.customIcons[target.bar][target.slot] = nil
            local button = barButtons[target.bar] and barButtons[target.bar][target.slot]
            local icon = GetButtonIcon(button)
            local actionSlot = GetActionSlot(button)
            if icon then
                icon:SetAlpha(1)
                if actionSlot and type(GetActionTexture) == "function" then icon:SetTexture(GetActionTexture(actionSlot)) end
            end
            if button and button.customTextOverlay then button.customTextOverlay:Hide() end
            ApplyCustomActionIcons()
            SaveActiveProfile()
        end
        frame:Hide()
    end)

    local textLabel = frame:CreateFontString(nil, "OVERLAY", "GameFontDisableSmall")
    textLabel:SetPoint("TOPLEFT", frame, "TOPLEFT", 145, -45)
    textLabel:SetText("Text:")
    local textEntry = CreateFrame("EditBox", nil, frame, "InputBoxTemplate")
    frame.textEntry = textEntry
    textEntry:SetSize(82, 22)
    textEntry:SetPoint("TOPLEFT", frame, "TOPLEFT", 178, -40)
    textEntry:SetAutoFocus(false)
    textEntry:SetMaxLetters(8)
    frame.textScale = 1
    frame.textColor = "gold"
    frame.textBackground = true

    local sizeLabel = frame:CreateFontString(nil, "OVERLAY", "GameFontDisableSmall")
    sizeLabel:SetPoint("TOPLEFT", frame, "TOPLEFT", 18, -75)
    sizeLabel:SetText("Size")
    local sizeSlider = CreateFrame("Slider", nil, frame)
    frame.textSizeSlider = sizeSlider
    sizeSlider:SetPoint("TOPLEFT", frame, "TOPLEFT", 55, -72)
    sizeSlider:SetSize(126, 12)
    if sizeSlider.SetOrientation then sizeSlider:SetOrientation("HORIZONTAL") end
    sizeSlider:SetMinMaxValues(0.7, 1.5)
    sizeSlider:SetValueStep(0.1)
    if sizeSlider.SetObeyStepOnDrag then sizeSlider:SetObeyStepOnDrag(true) end
    sizeSlider:SetThumbTexture("Interface\\Buttons\\UI-SliderBar-Button-Horizontal")
    local sizeTrack = sizeSlider:CreateTexture(nil, "BACKGROUND")
    sizeTrack:SetColorTexture(0.36, 0.32, 0.25, 0.9)
    sizeTrack:SetPoint("LEFT", sizeSlider, "LEFT", 2, 0)
    sizeTrack:SetPoint("RIGHT", sizeSlider, "RIGHT", -2, 0)
    sizeTrack:SetHeight(3)
    local sizeValue = frame:CreateFontString(nil, "OVERLAY", "GameFontDisableSmall")
    frame.textSizeValue = sizeValue
    sizeValue:SetPoint("TOPLEFT", frame, "TOPLEFT", 184, -75)
    sizeValue:SetWidth(38)
    sizeValue:SetText("100%")

    local colorButton = CreateFrame("Button", nil, frame, "UIPanelButtonTemplate")
    frame.textColorButton = colorButton
    colorButton:SetSize(68, 22)
    colorButton:SetPoint("TOPLEFT", frame, "TOPLEFT", 212, -68)
    local backgroundLabel = frame:CreateFontString(nil, "OVERLAY", "GameFontDisableSmall")
    backgroundLabel:SetPoint("TOPLEFT", frame, "TOPLEFT", 283, -75)
    backgroundLabel:SetText("BG")
    local backgroundCheck = CreateFrame("CheckButton", nil, frame, "UICheckButtonTemplate")
    frame.textBackgroundCheck = backgroundCheck
    backgroundCheck:SetSize(22, 22)
    backgroundCheck:SetPoint("TOPLEFT", frame, "TOPLEFT", 304, -69)
    backgroundCheck:SetScript("OnEnter", function(self)
        GameTooltip:SetOwner(self, "ANCHOR_TOP")
        GameTooltip:SetText("Dark text background")
        GameTooltip:AddLine("Improves readability over colorful icons.", 1, 1, 1, true)
        GameTooltip:Show()
    end)
    backgroundCheck:SetScript("OnLeave", function() GameTooltip:Hide() end)

    local function SaveCurrentTextStyle()
        local target = frame.target
        local current = target and DB.customIcons and DB.customIcons[target.bar] and DB.customIcons[target.bar][target.slot]
        if type(current) ~= "table" or current.kind ~= "text" then return end
        current.scale = frame.textScale
        current.color = frame.textColor
        current.background = frame.textBackground
        ApplyCustomActionIcons()
        SaveActiveProfile()
    end
    sizeSlider:SetScript("OnValueChanged", function(self, value)
        if self.settingValue then return end
        frame.textScale = math.floor(value * 10 + 0.5) / 10
        sizeValue:SetText(string.format("%d%%", math.floor(frame.textScale * 100 + 0.5)))
        SaveCurrentTextStyle()
    end)
    colorButton:SetScript("OnClick", function(self)
        local nextIndex = 1
        for index, color in ipairs(TEXT_COLORS) do
            if color.key == frame.textColor then nextIndex = (index % #TEXT_COLORS) + 1; break end
        end
        frame.textColor = TEXT_COLORS[nextIndex].key
        self:SetText(TEXT_COLORS[nextIndex].label)
        SaveCurrentTextStyle()
    end)
    colorButton:SetScript("OnEnter", function(self)
        GameTooltip:SetOwner(self, "ANCHOR_TOP")
        GameTooltip:SetText("Text color")
        GameTooltip:AddLine("Click to cycle Gold, White, Cyan, Green and Red.", 1, 1, 1, true)
        GameTooltip:Show()
    end)
    colorButton:SetScript("OnLeave", function() GameTooltip:Hide() end)
    backgroundCheck:SetScript("OnClick", function(self)
        frame.textBackground = self:GetChecked() and true or false
        SaveCurrentTextStyle()
    end)

    local function ApplyTextOverride()
        local target = frame.target
        local value = (textEntry:GetText() or ""):match("^%s*(.-)%s*$")
        if not target or value == "" then return end
        DB.customIcons = type(DB.customIcons) == "table" and DB.customIcons or {}
        DB.customIcons[target.bar] = type(DB.customIcons[target.bar]) == "table" and DB.customIcons[target.bar] or {}
        DB.customIcons[target.bar][target.slot] = {
            kind = "text", text = value, scale = frame.textScale,
            color = frame.textColor, background = frame.textBackground,
        }
        ApplyCustomActionIcons()
        SaveActiveProfile()
        frame:Hide()
    end
    local textApply = CreateFrame("Button", nil, frame, "UIPanelButtonTemplate")
    textApply:SetSize(52, 22)
    textApply:SetPoint("TOPLEFT", frame, "TOPLEFT", 266, -40)
    textApply:SetText("Set")
    textApply:SetScript("OnClick", ApplyTextOverride)
    textEntry:SetScript("OnEnterPressed", ApplyTextOverride)
    textEntry:SetScript("OnEscapePressed", function() frame:Hide() end)

    local grid = CreateFrame("Frame", nil, frame)
    frame.grid = grid
    grid:SetPoint("TOPLEFT", frame, "TOPLEFT", 16, -100)
    grid:SetSize(302, 222)
    frame.iconButtons = {}
    for index = 1, 42 do
        local button = CreateFrame("Button", nil, grid)
        frame.iconButtons[index] = button
        button:SetSize(34, 34)
        local column = (index - 1) % 7
        local row = math.floor((index - 1) / 7)
        button:SetPoint("TOPLEFT", grid, "TOPLEFT", column * 42, -row * 36)
        button:SetNormalTexture("Interface\\Buttons\\UI-Quickslot2")
        local icon = button:CreateTexture(nil, "ARTWORK")
        button.iconTexture = icon
        icon:SetSize(28, 28)
        icon:SetPoint("CENTER")
        button:SetHighlightTexture("Interface\\Buttons\\ButtonHilight-Square", "ADD")
        button:SetScript("OnClick", function(self)
            local target = frame.target
            if target and self.iconValue then
                DB.customIcons = type(DB.customIcons) == "table" and DB.customIcons or {}
                DB.customIcons[target.bar] = type(DB.customIcons[target.bar]) == "table" and DB.customIcons[target.bar] or {}
                DB.customIcons[target.bar][target.slot] = self.iconValue
                ApplyCustomActionIcons()
                SaveActiveProfile()
            end
            frame:Hide()
        end)
        button:SetScript("OnEnter", function(self)
            if self.iconValue then
                GameTooltip:SetOwner(self, "ANCHOR_RIGHT")
                GameTooltip:SetText(tostring(self.iconValue))
                GameTooltip:Show()
            end
        end)
        button:SetScript("OnLeave", function() GameTooltip:Hide() end)
    end

    local previous = CreateFrame("Button", nil, frame, "UIPanelButtonTemplate")
    frame.previousButton = previous
    previous:SetSize(72, 22)
    previous:SetPoint("BOTTOMLEFT", frame, "BOTTOMLEFT", 18, 15)
    previous:SetText("Previous")
    previous:SetScript("OnClick", function() frame.page = math.max(1, (frame.page or 1) - 1); ShowActionIconPicker(frame.target.bar, frame.target.slot) end)
    local pageText = frame:CreateFontString(nil, "OVERLAY", "GameFontDisableSmall")
    frame.pageText = pageText
    pageText:SetPoint("BOTTOM", frame, "BOTTOM", 0, 20)
    local nextButton = CreateFrame("Button", nil, frame, "UIPanelButtonTemplate")
    frame.nextButton = nextButton
    nextButton:SetSize(72, 22)
    nextButton:SetPoint("BOTTOMRIGHT", frame, "BOTTOMRIGHT", -18, 15)
    nextButton:SetText("Next")
    nextButton:SetScript("OnClick", function() frame.page = (frame.page or 1) + 1; ShowActionIconPicker(frame.target.bar, frame.target.slot) end)
    frame:SetScript("OnShow", function()
        EnsureProfileModalBlocker()
        profileModalBlocker:Show()
        frame:Raise()
    end)
    frame:Hide()
    return frame
end

ShowActionIconPicker = function(barIndex, slotIndex)
    if not DB or not DB.editMode or not DB.rightClickIconEdit or InCombat() then return end
    local frame = BuildActionIconPicker()
    frame.target = { bar = barIndex, slot = slotIndex }
    frame.page = frame.page or 1
    frame.title:SetText(string.format("Choose icon — Bar %d, Slot %d", barIndex, slotIndex))
    local currentOverride = DB.customIcons and DB.customIcons[barIndex] and DB.customIcons[barIndex][slotIndex]
    frame.textEntry:SetText(type(currentOverride) == "table" and currentOverride.kind == "text" and currentOverride.text or "")
    frame.textScale = type(currentOverride) == "table" and currentOverride.scale or 1
    frame.textColor = type(currentOverride) == "table" and currentOverride.color or "gold"
    frame.textBackground = not (type(currentOverride) == "table" and currentOverride.background == false)
    frame.textSizeSlider.settingValue = true
    frame.textSizeSlider:SetValue(frame.textScale)
    frame.textSizeSlider.settingValue = false
    frame.textSizeValue:SetText(string.format("%d%%", math.floor(frame.textScale * 100 + 0.5)))
    for _, color in ipairs(TEXT_COLORS) do
        if color.key == frame.textColor then frame.textColorButton:SetText(color.label); break end
    end
    frame.textBackgroundCheck:SetChecked(frame.textBackground)
    frame.icons = frame.icons or CollectActionHeroIcons()
    local pageSize = #frame.iconButtons
    local pageCount = math.max(1, math.ceil(#frame.icons / pageSize))
    frame.page = math.max(1, math.min(pageCount, frame.page))
    local first = (frame.page - 1) * pageSize
    for index, button in ipairs(frame.iconButtons) do
        local texture = frame.icons[first + index]
        button.iconValue = texture
        if texture then button.iconTexture:SetTexture(texture); button:Show() else button:Hide() end
    end
    frame.pageText:SetText(string.format("Page %d of %d", frame.page, pageCount))
    frame.previousButton:SetEnabled(frame.page > 1)
    frame.nextButton:SetEnabled(frame.page < pageCount)
    EnsureProfileModalBlocker()
    profileModalBlocker:Show()
    frame:Show()
    frame:Raise()
end

local function HoldingAction()
    local kind = GetCursorInfo and GetCursorInfo()
    return kind == "action" or kind == "spell" or kind == "item" or kind == "macro"
        or kind == "mount" or kind == "companion" or kind == "petaction" or kind == "equipmentset"
end

RefreshIconEditOverlays = function()
    local enabled = DB and DB.editMode and DB.rightClickIconEdit and not InCombat() and not HoldingAction()
    for barIndex = 1, BAR_COUNT do
        local barShown = bars[barIndex] and bars[barIndex]:IsShown()
        for slotIndex = 1, 12 do
            local button = barButtons[barIndex] and barButtons[barIndex][slotIndex]
            local overlay = button and button.iconEditOverlay
            if overlay then
                if enabled and barShown and button:IsShown() then overlay:Show() else overlay:Hide() end
            end
        end
    end
end

local tooltipModeButton
local tooltipModes = { hover = "Show on hover", dismiss = "Middle-click to dismiss", off = "Always off" }
local slotTooltipOwners = {}
local dismissedOwner

local function ApplySlotTooltipMode(tooltip)
    local owner = tooltip:GetOwner()
    if DB and slotTooltipOwners[owner] and (DB.slotTooltipMode == "off"
        or (DB.slotTooltipMode == "dismiss" and owner == dismissedOwner)) then
        tooltip:Hide()
    end
end

GameTooltip:HookScript("OnShow", ApplySlotTooltipMode)

local function WatchSlotTooltip(frame)
    slotTooltipOwners[frame] = true
    frame:HookScript("OnEnter", function() ApplySlotTooltipMode(GameTooltip) end)
    frame:HookScript("OnMouseDown", function(self, mouseButton)
        if mouseButton == "MiddleButton" and DB.slotTooltipMode == "dismiss" and GameTooltip:IsOwned(self) then
            dismissedOwner = self
            GameTooltip:Hide()
        end
    end)
    local function EndHover(self)
        if self == dismissedOwner then dismissedOwner = nil end
    end
    frame:HookScript("OnLeave", EndHover)
    frame:HookScript("OnHide", EndHover)
end

local function EnsureIconEditOverlay(button, barIndex, slotIndex)
    if not button or button.iconEditOverlay then return end
    local overlay = CreateFrame("Button", nil, button)
    button.iconEditOverlay = overlay
    if overlay.SetPassThroughButtons then
        overlay:SetAllPoints(button)
        overlay:SetPassThroughButtons("LeftButton")
    else
        overlay:SetSize(12, 12)
        overlay:SetPoint("TOPRIGHT")
        local marker = overlay:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
        marker:SetPoint("CENTER")
        marker:SetText("*")
    end
    overlay:SetFrameLevel(button:GetFrameLevel() + 8)
    overlay:RegisterForClicks("RightButtonUp")
    overlay:SetHighlightTexture("Interface\\Buttons\\ButtonHilight-Square", "ADD")
    overlay:SetScript("OnClick", function(_, mouseButton)
        if mouseButton == "RightButton" then ShowActionIconPicker(barIndex, slotIndex) end
    end)
    overlay:SetScript("OnEnter", function(self)
        GameTooltip:SetOwner(self, "ANCHOR_TOPLEFT")
        GameTooltip:SetText("Right-click to change this slot's icon")
        GameTooltip:AddLine("The assigned action will not change.", 1, 1, 1, true)
        GameTooltip:Show()
    end)
    overlay:SetScript("OnLeave", function() GameTooltip:Hide() end)
    WatchSlotTooltip(button)
    WatchSlotTooltip(overlay)
    overlay:Hide()
end

local function LayoutActionButtons()
    if not barsReady or InCombat() then return end
    local _, playerClass = UnitClass("player")
    local iconScale = DB.iconScale or 1
    for index = 1, BAR_COUNT do
        local bar, buttons = bars[index], barButtons[index]
        if bar then
            local vertical = DB["barVertical" .. index]
            local reverse = DB["barReverse" .. index]
            local slotStep = (38 + (DB["barSpacing" .. index] or 0)) * iconScale
            local allSlots = DB.editMode or (not DB.lockBars and HoldingAction()) or (index == 1 and playerClass == "DRUID")
            local limit = allSlots and 12 or (DB["barLimit" .. index] or 12)
            local shown = {}
            for slot = 1, 12 do
                local button = buttons[slot]
                if button then
                    if (allSlots or IsActionButtonFilled(button)) and #shown < limit then
                        shown[#shown + 1] = button
                        button.actionHeroLayoutHidden = false
                    else
                        button.actionHeroLayoutHidden = true
                        button:Hide()
                    end
                end
            end
            local visibleCount = #shown
            local extent = math.max(1, visibleCount) * slotStep + 4 * iconScale
            local wrap = DB["barWrap" .. index] or 12
            local columns, rows = Recovery.GridSize(visibleCount, wrap, vertical)
            if wrap == 12 then
                if vertical then bar:SetSize(44 * iconScale, extent) else bar:SetSize(extent, 44) end
            else
                bar:SetSize(columns * slotStep + 4 * iconScale, rows * slotStep + 4 * iconScale)
            end
            for position, button in ipairs(shown) do
                local displaySlot = reverse and (visibleCount - position) or (position - 1)
                button:ClearAllPoints()
                if wrap < 12 then
                    local col, row = Recovery.GridCell(displaySlot, wrap, vertical)
                    button:SetPoint("TOPLEFT", bar, "TOPLEFT", col * slotStep + 2 * iconScale, -row * slotStep - 2 * iconScale)
                elseif vertical then
                    button:SetPoint("TOP", bar, "TOP", 0, -displaySlot * slotStep - 2 * iconScale)
                else
                    button:SetPoint("LEFT", bar, "LEFT", displaySlot * slotStep + 2 * iconScale, 2 * iconScale)
                end
                button:Show()
            end
            if minimapButton then
                minimapButton:SetAttribute("hasSlots" .. index, visibleCount > 0 or DB.editMode)
                minimapButton:SetAttribute("enabledBar" .. index, DB["showBar" .. index])
            end
            if not temporaryHidden and (emergencyBarsRevealed or DB["showBar" .. index]) and (visibleCount > 0 or DB.editMode) then bar:Show() else bar:Hide() end
        end
    end
    ApplyCustomActionIcons()
    if RefreshIconEditOverlays then RefreshIconEditOverlays() end
    if UpdateEditModeBadge then UpdateEditModeBadge() end
end

-- Native buttons can be shown while Blizzard is processing an item or spell.
-- Apply our compact layout on the next frame, outside that call stack.
local layoutUpdate = CreateFrame("Frame")
local refreshForms
layoutUpdate:Hide()
layoutUpdate:SetScript("OnUpdate", function(self)
    self:Hide()
    if InCombat() then waitingForCombat = true; return end
    if refreshForms then
        refreshForms = false
        ApplyDruidForms()
    end
    LayoutActionButtons()
end)

local function BuildBar(index, buttonPrefix, pointKey, fallbackY)
    local bar = CreateFrame("Frame", "ActionHeroBar" .. index, UIParent, "SecureHandlerStateTemplate")
    bar:SetSize(460, 44)
    bar:SetMovable(true)
    bar:SetClampedToScreen(true)
    bar:SetFrameStrata("MEDIUM")
    bar.skinBackground = bar:CreateTexture(nil, "BACKGROUND")
    bar.skinBackground:SetAllPoints(bar)
    bar.skinEdges = {}
    for _, edgeName in ipairs({ "TOP", "BOTTOM", "LEFT", "RIGHT" }) do
        local edge = bar:CreateTexture(nil, "BACKGROUND")
        if edgeName == "TOP" or edgeName == "BOTTOM" then
            edge:SetHeight(1)
            edge:SetPoint(edgeName .. "LEFT", bar, edgeName .. "LEFT")
            edge:SetPoint(edgeName .. "RIGHT", bar, edgeName .. "RIGHT")
        else
            edge:SetWidth(1)
            edge:SetPoint("TOP" .. edgeName, bar, "TOP" .. edgeName)
            edge:SetPoint("BOTTOM" .. edgeName, bar, "BOTTOM" .. edgeName)
        end
        table.insert(bar.skinEdges, edge)
    end
    ApplyBarSkins()
    if bar.SetDontSavePosition then bar:SetDontSavePosition(true) end
    bar:SetScale(DB["barScale" .. index] or 1)
    RestorePoint(bar, DB[pointKey], fallbackY)

    local header = CreateFrame("Button", nil, bar)
    header:SetSize(116, 17)
    header:SetPoint("BOTTOMLEFT", bar, "TOPLEFT", 0, 1)
    header:RegisterForDrag("LeftButton")
    header:RegisterForClicks("LeftButtonUp")
    local stripe = header:CreateTexture(nil, "BACKGROUND")
    stripe:SetAllPoints()
    stripe:SetColorTexture(0, 0, 0, 0)
    local label = header:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
    label:SetPoint("LEFT", 3, 0)
    label:SetText("Action Hero " .. index)
    label:Hide()
    header:SetScript("OnEnter", function()
        stripe:SetColorTexture(0, 0, 0, 0.32)
        GameTooltip:SetOwner(header, "ANCHOR_TOPLEFT")
        GameTooltip:SetText("Action Hero " .. index)
        if index == 1 then
            GameTooltip:AddLine("Blizzard Key Bindings: Action Bar 1, buttons 1–12", 1, 1, 1, true)
        else
            local groupNames = { [2] = "Bottom Left Action Bar / Multi Action Bar 1", [3] = "Bottom Right Action Bar / Multi Action Bar 2", [4] = "Right Action Bar / Multi Action Bar 3", [5] = "Left Action Bar / Multi Action Bar 4", [6] = "Extra Bar 1 / Multi Action Bar 5", [7] = "Extra Bar 2 / Multi Action Bar 6" }
            GameTooltip:AddLine("Blizzard Key Bindings: " .. (groupNames[index] or "Action Bar") .. ", buttons 1–12", 1, 1, 1, true)
        end
        if not DB.lockBars then GameTooltip:AddLine("Drag to move; Shift-click to snap.", 0.75, 0.75, 0.75, true) end
        GameTooltip:Show()
    end)
    header:SetScript("OnLeave", function()
        stripe:SetColorTexture(0, 0, 0, 0)
        GameTooltip:Hide()
    end)
    header:SetScript("OnDragStart", function()
        if DB.lockBars or InCombat() or IsShiftKeyDown() then return end
        RememberLayout()
        draggingBar = bar
        SplitStackForDragging(index)
        bar:StartMoving()
    end)
    local function StopBarDrag()
        if draggingBar ~= bar then return end
        if InCombat() then waitingForCombat = true; return end
        bar:StopMovingOrSizing()
        draggingBar = nil
        SavePoint(bar, pointKey)
        RestorePoint(bar, DB[pointKey], fallbackY)
        if bar.SetUserPlaced then bar:SetUserPlaced(false) end
    end
    header:SetScript("OnDragStop", StopBarDrag)
    header:SetScript("OnClick", function()
        if IsShiftKeyDown() then ToggleSnap(index) end
    end)

    local grip = CreateFrame("Button", nil, bar)
    grip:SetSize(16, 16)
    grip:SetPoint("BOTTOMRIGHT")
    grip:SetNormalTexture("Interface\\ChatFrame\\UI-ChatIM-SizeGrabber-Up")
    grip:SetHighlightTexture("Interface\\ChatFrame\\UI-ChatIM-SizeGrabber-Highlight")
    grip:SetScript("OnMouseDown", function(_, button)
        if button ~= "LeftButton" or DB.lockBars or InCombat() then return end
        local size = (DB["barScale" .. index] or 1) + 0.25
        if size > 1.75 then size = 0.75 end
        RememberLayout()
        DB["barScale" .. index] = size
        bar:SetScale(size)
        if index == 1 and druidFormRow then druidFormRow:SetScale(size) end
        if SaveActiveProfile then SaveActiveProfile() end
    end)
    grip:SetScript("OnEnter", function(self)
        GameTooltip:SetOwner(self, "ANCHOR_TOPLEFT")
    GameTooltip:SetText(DB.lockBars and "Bars are locked" or "Click to resize; use the settings scale control for precision")
    end)
    grip:SetScript("OnLeave", function() GameTooltip:Hide() end)

    local buttons = {}
    for slot = 1, 12 do
        local button = _G[buttonPrefix .. slot]
        if button then
            button:SetParent(bar)
            button:ClearAllPoints()
            local iconScale = DB.iconScale or 1
            button:SetScale(iconScale)
            button:SetPoint("LEFT", bar, "LEFT", (slot - 1) * 38 * iconScale + 2 * iconScale, 2 * iconScale)
            EnsureIconEditOverlay(button, index, slot)
            button:HookScript("OnShow", function(self)
                -- Blizzard can briefly show an empty slot again during hover
                -- grid updates. Re-hide it immediately unless Edit Mode is on.
                if DB and not InCombat() and self.actionHeroLayoutHidden then
                    layoutUpdate:Show()
                end
            end)
            buttons[slot] = button
        end
    end
    bars[index], barHeaders[index], barLabels[index], barGrips[index], barButtons[index] = bar, header, label, grip, buttons
    if minimapButton then minimapButton:SetFrameRef("bar" .. index, bar) end
    bar:Show()
end

local ACTION_BAR_SOURCES = {
    { prefix = "ActionButton", frame = "MainMenuBar", point = "barPoint1", y = 54 },
    { prefix = "MultiBarBottomLeftButton", frame = "MultiBarBottomLeft", point = "barPoint2", y = 102 },
    { prefix = "MultiBarBottomRightButton", frame = "MultiBarBottomRight", point = "barPoint3", y = 150 },
    { prefix = "MultiBarRightButton", frame = "MultiBarRight", point = "barPoint4", y = 198 },
    { prefix = "MultiBarLeftButton", frame = "MultiBarLeft", point = "barPoint5", y = 246 },
    { prefix = "MultiBar5Button", frame = "MultiBar5", point = "barPoint6", y = 150, page = 13 },
    { prefix = "MultiBar6Button", frame = "MultiBar6", point = "barPoint7", y = 150, page = 14 },
}

local function GetDruidFormCount()
    if type(GetNumShapeshiftForms) == "function" then
        return math.max(0, tonumber(GetNumShapeshiftForms()) or 0)
    end
    return #druidFormButtons
end

local function CaptureDruidFormButton(button)
    if druidFormButtonOrigins[button] then return end
    local origin = { parent = button:GetParent(), points = {}, scale = button:GetScale(), frameLevel = button:GetFrameLevel() }
    local count = button.GetNumPoints and button:GetNumPoints() or 0
    for pointIndex = 1, count do
        local point, relativeTo, relativePoint, x, y = button:GetPoint(pointIndex)
        table.insert(origin.points, { point, relativeTo, relativePoint, x, y })
    end
    druidFormButtonOrigins[button] = origin
end

local function RestoreDruidFormButtons()
    local forms = GetDruidFormCount()
    for index, button in ipairs(druidFormButtons) do
        local origin = druidFormButtonOrigins[button]
        if origin then
            button:SetParent(origin.parent)
            button:ClearAllPoints()
            for _, point in ipairs(origin.points) do
                if point[2] then
                    button:SetPoint(point[1], point[2], point[3], point[4] or 0, point[5] or 0)
                else
                    button:SetPoint(point[1], point[4] or 0, point[5] or 0)
                end
            end
            button:SetScale(origin.scale or 1)
            if origin.frameLevel then button:SetFrameLevel(origin.frameLevel) end
            if index <= forms then button:Show() else button:Hide() end
        end
    end
end

local function EnsureDruidFormStrip()
    if druidFormRow then return end
    druidFormRow = CreateFrame("Frame", "ActionHeroDruidFormStrip", UIParent, "BackdropTemplate")
    druidFormRow:SetSize(40, 38)
    druidFormRow:SetFrameStrata("MEDIUM")
    druidFormRow:SetClampedToScreen(true)
    druidFormRow:SetBackdrop({ bgFile = "Interface\\Buttons\\WHITE8X8", edgeFile = "Interface\\Buttons\\WHITE8X8", edgeSize = 1, insets = { left = 1, right = 1, top = 1, bottom = 1 } })
    druidFormRow:SetBackdropColor(0, 0, 0, 0)
    druidFormRow:SetBackdropBorderColor(0, 0, 0, 0)
    druidFormRow:EnableMouse(false)
end

local function LayoutDruidFormStrip()
    if not druidFormRow or not bars[1] then return end
    local forms = math.min(GetDruidFormCount(), #druidFormButtons)
    local iconScale = DB.iconScale or 1
    local firstButton = druidFormButtons[1]
    local slotWidth = firstButton and firstButton:GetWidth() or 36
    local slotHeight = firstButton and firstButton:GetHeight() or 36
    if not slotWidth or slotWidth <= 0 then slotWidth = 36 end
    if not slotHeight or slotHeight <= 0 then slotHeight = 36 end
    druidFormRow:SetFrameLevel(bars[1]:GetFrameLevel() + 5)
    local visible = 0
    for index, button in ipairs(druidFormButtons) do
        if index <= forms then
            CaptureDruidFormButton(button)
            button:SetParent(druidFormRow)
            button:SetFrameLevel(druidFormRow:GetFrameLevel() + visible + 1)
            button:SetScale(iconScale)
            button:ClearAllPoints()
            button:SetPoint("BOTTOMLEFT", druidFormRow, "BOTTOMLEFT", 2 + visible * (slotWidth * iconScale + 2), 2)
            button:Show()
            visible = visible + 1
        else
            button:Hide()
        end
    end
    local width = math.max(1, visible) * (slotWidth * iconScale + 2) + 2
    druidFormRow:SetSize(width, slotHeight * iconScale + 4)
    druidFormRow:SetScale(DB.barScale1 or 1)
    druidFormRow:ClearAllPoints()
    druidFormRow:SetPoint("BOTTOMLEFT", bars[1], "TOPLEFT", 0, 23)
    if visible > 0 then druidFormRow:Show() else druidFormRow:Hide() end
    ApplyBarSkins()
end

local function FinishFormDrag()
    if not formDragProfile then return end
    if InCombat() then
        waitingForCombat = true
        return
    end
    druidFormBarFrame:StopMovingOrSizing()
    if formDragProfile == DB.activeProfile and DB.druidFormMode == "blizzard" then
        SavePoint(druidFormBarFrame, "druidFormPoint")
        formLayout.point = DB.druidFormPoint
    end
    formDragProfile = nil
end

ApplyDruidForms = function(force)
    if not DB or DB.defaultBottomView then return end
    local _, playerClass = UnitClass("player")
    if playerClass ~= "DRUID" then return end

    druidFormBarFrame = druidFormBarFrame or _G.ShapeshiftBarFrame or _G.StanceBarFrame
    if not druidFormBarFrame then return end

    if InCombat() then waitingForCombat = true; return end
    if not nativeFormPoints then
        nativeFormPoints = {}
        for i = 1, druidFormBarFrame:GetNumPoints() do
            local point, relative, anchor, x, y = druidFormBarFrame:GetPoint(i)
            nativeFormPoints[i] = {point, relative or UIParent, anchor, x, y}
        end
    end
    local count = GetDruidFormCount()
    if not force and formLayout.mode == DB.druidFormMode and formLayout.count == count
        and formLayout.point == DB.druidFormPoint and formLayout.move == DB.druidMoveFormBar
        and formLayout.iconScale == DB.iconScale then return end

    local prefix = _G.ShapeshiftButton1 and "ShapeshiftButton" or (_G.StanceButton1 and "StanceButton")
    if prefix then
        for index = 1, 12 do
            local button = _G[prefix .. index]
            if button and not druidFormButtonOrigins[button] then
                CaptureDruidFormButton(button)
                table.insert(druidFormButtons, button)
            end
        end
    end

    if DB.druidFormMode == "actionhero" then
        if InCombat() then waitingForCombat = true; return end
        EnsureDruidFormStrip()
        if druidFormBarFrame:GetParent() ~= hiddenParent then
            if druidFormBarFrame:GetParent() ~= UIParent then druidFormBarFrame:SetParent(UIParent) end
        end
        HideWithParent(druidFormBarFrame, originalParents.forms)
        if druidFormMoveHandle then druidFormMoveHandle:Hide() end
        LayoutDruidFormStrip()
    else
        if InCombat() then waitingForCombat = true; return end
        if druidFormRow then druidFormRow:Hide() end
        if formLayout.mode == "actionhero" then RestoreDruidFormButtons() end
        RestoreParents(originalParents.forms)
        if druidFormBarFrame:GetParent() ~= UIParent then druidFormBarFrame:SetParent(UIParent) end
        if druidFormBarFrame and DB.druidFormPoint then
            RestorePoint(druidFormBarFrame, DB.druidFormPoint, 0)
            if druidFormBarFrame.SetUserPlaced then druidFormBarFrame:SetUserPlaced(true) end
        elseif formLayout.hadCustomPoint then
            druidFormBarFrame:ClearAllPoints()
            for _, anchor in ipairs(nativeFormPoints) do
                druidFormBarFrame:SetPoint(unpack(anchor))
            end
            if #nativeFormPoints == 0 then druidFormBarFrame:SetPoint("BOTTOM", UIParent, "BOTTOM", 0, 96) end
            if druidFormBarFrame.SetUserPlaced then druidFormBarFrame:SetUserPlaced(false) end
        end
        formLayout.hadCustomPoint = DB.druidFormPoint ~= nil
        if druidFormBarFrame then
            druidFormBarFrame:SetMovable(true)
            druidFormBarFrame:SetClampedToScreen(true)
            if GetDruidFormCount() > 0 then druidFormBarFrame:Show() end
        end
        if not druidFormMoveHandle then
            druidFormMoveHandle = CreateMoveHandle(druidFormBarFrame, "FORMS", "druidMoveFormBar", "druidFormPoint")
            druidFormMoveHandle:SetScript("OnDragStart", function()
                if DB.druidMoveFormBar and not InCombat() then
                    druidFormBarFrame:StartMoving()
                    formDragProfile = DB.activeProfile
                    formLayout.hadCustomPoint = true
                end
            end)
            druidFormMoveHandle:SetScript("OnDragStop", FinishFormDrag)
        end
        if DB.druidMoveFormBar then druidFormMoveHandle:Show() else druidFormMoveHandle:Hide() end
    end
    formLayout.mode, formLayout.count = DB.druidFormMode, count
    formLayout.point, formLayout.move = DB.druidFormPoint, DB.druidMoveFormBar
    formLayout.iconScale = DB.iconScale
end

local function NativeSourceReady(source)
    if source.page then
        local frame = _G[source.frame]
        if not frame or not frame.GetAttribute or tonumber(frame:GetAttribute("actionpage")) ~= source.page then return false end
    end
    local seen = {}
    for slot = 1, 12 do
        local button = _G[source.prefix .. slot]
        if not button or seen[button] then return false end
        seen[button] = true
        if source.page then
            -- Reject a different or aliased native action slot, not just a
            -- frame with a matching name. Uninitialized buttons can retry later.
            local expected = (source.page - 1) * 12 + slot
            local actual = tonumber(GetActionSlot(button))
            if actual ~= expected then return false end
        end
    end
    return true
end

local function SetupBars()
    if not DB or DB.defaultBottomView or InCombat() then return end
    if not barsReady then
        for index = 1, 5 do
            if not NativeSourceReady(ACTION_BAR_SOURCES[index]) then return end
        end
        for index = 1, 5 do
            local source = ACTION_BAR_SOURCES[index]
            BuildBar(index, source.prefix, source.point, source.y)
            if index > 1 then HideWithParent(_G[source.frame], originalParents.secondaryBars) end
        end
        barsReady = true
    end
    for index = 6, BAR_COUNT do
        local source = ACTION_BAR_SOURCES[index]
        if not bars[index] and NativeSourceReady(source) then
            BuildBar(index, source.prefix, source.point, source.y)
            HideWithParent(_G[source.frame], originalParents.secondaryBars)
        end
    end
end

local function ApplyBarOptions()
    if not barsReady then return end
    for index = 1, BAR_COUNT do
        if bars[index] then
            bars[index]:SetScale(DB["barScale" .. index] or 1)
            if DB.showLabels then barLabels[index]:Show() else barLabels[index]:Hide() end
            barHeaders[index]:EnableMouse(not DB.lockBars)
            if DB.lockBars then barGrips[index]:Disable() else barGrips[index]:Enable() end
        end
    end
    ApplyBarSkins()
    ApplyBarAppearance()
    LayoutActionButtons()
    RestoreActionBarLayout()
    if ApplyDruidForms then ApplyDruidForms() end
end

local flightStopButton
local function RefreshFlightStop()
    local requestLanding = TaxiRequestEarlyLanding or (C_TaxiMap and C_TaxiMap.RequestEarlyLanding)
    if not (DB and DB.showFlightStop and requestLanding and UnitOnTaxi("player")) then
        if flightStopButton then flightStopButton:Hide() end
        return
    end
    if not flightStopButton then
        flightStopButton = CreateFrame("Button", "ActionHeroFlightStop", UIParent, "UIPanelButtonTemplate")
        flightStopButton:SetSize(144, 24)
        flightStopButton:SetPoint("CENTER", UIParent, "CENTER", 0, -145)
        flightStopButton:SetText("Land at next stop")
        flightStopButton:SetScript("OnClick", function()
            if UnitOnTaxi("player") then requestLanding() end
        end)
    end
    flightStopButton:Show()
end

local function ApplyAll()
    if not DB then return end
    RefreshFlightStop()
    if DB.defaultBottomView then
        UpdateStatus()
        return
    end
    ApplyXPDisplay()
    if InCombat() then
        waitingForCombat = true
        UpdateStatus()
        return
    end
    waitingForCombat = false
    SetupBars()
    if barsReady then ApplyMainActionBar() end
    ApplyMicroMenu()
    ApplyBagBar()
    ApplyExperienceBar()
    ApplyReputationBar()
    ApplyBarOptions()
    MenuGuard.Queue()
    if settingsWindow and settingsWindow:IsShown() then RefreshSettingsLayout() end
    UpdateStatus()
end

function ActionHero_ToggleBars()
    if not DB or DB.defaultBottomView or not barsReady then return end
    if draggingBar or formDragProfile or movingMenu then Message("Finish dragging before toggling bars."); return end
    if InCombat() then
        pendingVisibility = not pendingVisibility
        Message(pendingVisibility and "Bar visibility will toggle when combat ends." or "Pending bar visibility toggle cancelled.")
        return
    end
    temporaryHidden = not temporaryHidden
    emergencyBarsRevealed = false
    if minimapButton then minimapButton:SetAttribute("revealed", false) end
    LayoutActionButtons()
    Message(temporaryHidden and "Action bars hidden. Use the same key to restore." or "Saved action bar visibility restored.")
end
BINDING_HEADER_ACTIONHERO = "Action Hero"
BINDING_NAME_ACTIONHERO_TOGGLEBARS = "Hide / Show Action Hero bars"
_G["BINDING_NAME_CLICK ActionHeroMinimapButton:EmergencyToggle"] = "Reveal / Restore Bars (Minimap Right-click)"

local function SetOption(key, value)
    if key == "defaultBottomView" then
        if InCombat() then
            Message("Switch bottom UI views after combat.")
            RefreshSettingsLayout()
            return
        end
        if draggingBar or formDragProfile or movingMenu then
            Message("Finish moving bars before switching bottom UI views.")
            RefreshSettingsLayout()
            return
        end
        if value then
            -- Custom positions live in our profile. Clear native layout-cache
            -- ownership so it cannot carry those positions across the reload.
            if menuFrame and appliedMenuPoint and menuFrame.SetUserPlaced then
                menuFrame:SetUserPlaced(false)
            end
            if druidFormBarFrame and formLayout.hadCustomPoint and druidFormBarFrame.SetUserPlaced then
                druidFormBarFrame:SetUserPlaced(false)
            end
        end
        DB.defaultBottomView = not not value
        ReloadUI()
        return
    end
    local barIndex = tonumber(key:match("^showBar(%d)$"))
    if barIndex and value and barIndex > 5 and not bars[barIndex] then
        if not InCombat() then SetupBars() end
        if not bars[barIndex] then
            Message("Extra bar unavailable: enable its native Action Bar in game settings and reload, then try again.")
            RefreshSettingsLayout()
            return
        end
    end
    if barIndex and DB[key] ~= not not value then RememberLayout() end
    DB[key] = not not value
    if barIndex and not value and expandedBar == barIndex then expandedBar = nil end
    if key == "transparentSettings" and settingsWindow then
        settingsWindow:SetBackdropColor(0.075, 0.085, 0.10, DB.transparentSettings and 0.62 or 1)
    end
    if key == "showMinimapButton" and CreateMinimapButton then CreateMinimapButton() end
    ApplyAll()
    if RefreshIconEditOverlays then RefreshIconEditOverlays() end
    if SaveActiveProfile then SaveActiveProfile() end
    RefreshSettingsLayout()
end

local function MakeLabel(parent, template, text, anchor, relativeTo, relativePoint, x, y)
    local font = parent:CreateFontString(nil, "OVERLAY", template)
    font:SetPoint(anchor, relativeTo, relativePoint, x, y)
    font:SetText(text)
    font:SetJustifyH("LEFT")
    return font
end

local NormalizeSettings
local function RefreshProfileDropdown()
    if not profileDropdown or not DB then return end
    UIDropDownMenu_SetText(profileDropdown, DB.activeProfile or "Default")
    UIDropDownMenu_Initialize(profileDropdown, function(_, level)
        local names = {}
        for name, profile in pairs(DB.profiles) do
            if type(name) == "string" and type(profile) == "table" then table.insert(names, name) end
        end
        table.sort(names)
        for _, name in ipairs(names) do
            local profileName = name
            local info = UIDropDownMenu_CreateInfo()
            info.text = profileName
            info.checked = profileName == DB.activeProfile
            info.func = function() SelectProfile(profileName) end
            UIDropDownMenu_AddButton(info, level)
        end
    end)
end

SelectProfile = function(name)
    local snapshot = DB and DB.profiles and DB.profiles[name]
    if type(snapshot) ~= "table" then return end
    if InCombat() or draggingBar or formDragProfile or movingMenu then
        Message("Switch profiles after combat and after moving bars.")
        return
    end
    local restored = CopyTable(snapshot)
    NormalizeSettings(restored)
    for _, key in ipairs({ "menuPoint", "singleBagPoint", "druidFormPoint", "xpPoint", "customIcons", "slotTooltipMode" }) do
        DB[key] = nil
    end
    for key, value in pairs(restored) do
        if key ~= "defaultBottomView" and key ~= "profiles" and key ~= "activeProfile" and key ~= "profileBackups" and key ~= "druidPagingFix" then DB[key] = value end
    end
    DB.activeProfile = name
    Recovery.ClearUndo()
    if Recovery.dialog then Recovery.dialog:Hide() end
    Nameplates.Configure(DB)
    if CreateMinimapButton then CreateMinimapButton() end
    ApplyAll()
    if settingsWindow then
        settingsWindow:SetBackdropColor(0.075, 0.085, 0.10, DB.transparentSettings and 0.62 or 1)
    end
    RefreshSettingsLayout()
    RefreshProfileDropdown()
    RefreshAppearanceControls()
    if styleButton then styleButton:SetText("Bar look: " .. GetBarSkinLabel(DB.barSkin or "Classic")) end
end

local function SaveAsProfile(name)
    name = (name or ""):match("^%s*(.-)%s*$")
    if name == "" then return end
    if InCombat() or draggingBar or formDragProfile or movingMenu then Message("Save profiles after combat or dragging."); return end
    if DB.profiles[name] then Recovery.Backup(DB, name, DB.profiles[name], "Overwrite") end
    DB.activeProfile = name
    Recovery.ClearUndo()
    DB.profiles[name] = CaptureSettings()
    RefreshProfileDropdown()
    if profileNameDialog then profileNameDialog:Hide() end
    Message("Profile saved: " .. name)
end

local function ShowProfileNameDialog()
    if not profileNameDialog then
        -- A fullscreen, invisible mouse sink prevents clicks from reaching the
        -- settings controls while the Save As prompt is open.
        EnsureProfileModalBlocker()

        local dialog = CreateFrame("Frame", "ActionHeroProfileNameDialog", UIParent, "BackdropTemplate")
        profileNameDialog = dialog
        dialog:SetSize(300, 112)
        dialog:SetPoint("CENTER")
        -- This popup is a sibling of the settings window, so give it a higher
        -- strata and frame level than the settings tabs and their controls.
        dialog:SetFrameStrata("FULLSCREEN_DIALOG")
        dialog:SetFrameLevel((settingsWindow and settingsWindow:GetFrameLevel() or 1) + 100)
        dialog:EnableMouse(true)
        dialog:SetScript("OnMouseDown", function() end)
        dialog:SetScript("OnMouseUp", function() end)
        dialog:SetScript("OnMouseWheel", function() end)
        dialog:SetScript("OnHide", function()
            if profileModalBlocker then profileModalBlocker:Hide() end
        end)
        dialog:SetBackdrop({ bgFile = "Interface\\Buttons\\WHITE8X8", edgeFile = "Interface\\DialogFrame\\UI-DialogBox-Border", tile = true, tileSize = 32, edgeSize = 24, insets = { left = 8, right = 8, top = 8, bottom = 8 } })
        dialog:SetBackdropColor(0.06, 0.06, 0.07, 1)
        MakeLabel(dialog, "GameFontNormal", "Save current layout as", "TOPLEFT", dialog, "TOPLEFT", 18, -17)
        local edit = CreateFrame("EditBox", nil, dialog, "InputBoxTemplate")
        dialog.edit = edit
        edit:SetSize(195, 24)
        edit:SetPoint("TOPLEFT", dialog, "TOPLEFT", 18, -40)
        edit:SetAutoFocus(false)
        edit:SetMaxLetters(32)
        local save = CreateFrame("Button", nil, dialog, "UIPanelButtonTemplate")
        save:SetSize(64, 24)
        save:SetPoint("LEFT", edit, "RIGHT", 8, 0)
        save:SetText("Save")
        save:SetScript("OnClick", function() SaveAsProfile(edit:GetText()) end)
        edit:SetScript("OnEnterPressed", function() SaveAsProfile(edit:GetText()) end)
        edit:SetScript("OnEscapePressed", function() dialog:Hide() end)
        local cancel = CreateFrame("Button", nil, dialog, "UIPanelButtonTemplate")
        cancel:SetSize(64, 22)
        cancel:SetPoint("BOTTOMRIGHT", dialog, "BOTTOMRIGHT", -16, 14)
        cancel:SetText("Cancel")
        cancel:SetScript("OnClick", function() dialog:Hide() end)
    end
    profileNameDialog.edit:SetText("")
    profileModalBlocker:Show()
    profileNameDialog:Show()
    profileNameDialog:Raise()
    profileNameDialog.edit:SetFocus()
end

local function AddProfileButton(parent, label, width, callback)
    local button = CreateFrame("Button", nil, parent, "UIPanelButtonTemplate")
    button:SetSize(width, 24)
    button:SetText(label)
    button:SetScript("OnClick", callback)
    return button
end

RefreshAppearanceControls = function()
    if iconScaleText then iconScaleText:SetText(string.format("%d%%", math.floor((DB.iconScale or 1) * 100 + 0.5))) end
    if opacityText then opacityText:SetText(string.format("%d%%", math.floor((DB.barOpacity or 1) * 100 + 0.5))) end
    if equippedHighlightText then
        local strength = math.floor((DB.equippedHighlight or 0) * 100 + 0.5)
        equippedHighlightText:SetText(strength == 0 and "Off" or string.format("%d%%", strength))
    end
    if equippedHighlightSlider then
        equippedHighlightSlider.settingValue = true
        equippedHighlightSlider:SetValue(DB.equippedHighlight or 0)
        equippedHighlightSlider.settingValue = false
    end
end

local function MakeStepControl(parent, label, x, y, changeValue)
    MakeLabel(parent, "GameFontNormalSmall", label, "TOPLEFT", parent, "TOPLEFT", x, y)
    local minus = CreateFrame("Button", nil, parent, "UIPanelButtonTemplate")
    minus:SetSize(27, 21)
    minus:SetPoint("TOPLEFT", parent, "TOPLEFT", x, y - 16)
    minus:SetText("-")
    minus:SetScript("OnClick", function() changeValue(-1) end)
    local valueText = MakeLabel(parent, "GameFontHighlightSmall", "", "TOPLEFT", parent, "TOPLEFT", x + 35, y - 20)
    valueText:SetWidth(48)
    valueText:SetJustifyH("CENTER")
    local plus = CreateFrame("Button", nil, parent, "UIPanelButtonTemplate")
    plus:SetSize(27, 21)
    plus:SetPoint("TOPLEFT", parent, "TOPLEFT", x + 90, y - 16)
    plus:SetText("+")
    plus:SetScript("OnClick", function() changeValue(1) end)
    return valueText
end

RefreshSettingsLayout = function()
    if not settingsContent then return end
    local _, playerClass = UnitClass("player")
    local isDruid = playerClass == "DRUID"
    local y = -8
    if expandedBar and (not DB["showBar" .. expandedBar] or DB.defaultBottomView) then expandedBar = nil end
    for _, option in ipairs(OPTION_ROWS) do
        local row = optionRows[option.key]
        local shouldShow = option.category == activeSettingsTab
            and not (DB.defaultBottomView and option.category == "BOTTOM UI" and option.key ~= "defaultBottomView")
            and not ((option.key == "showSingleBagButton" and not DB.hideBagBar)
                or (option.key == "moveMenuIcons" and DB.hideMicroMenu)
                or (option.key == "rightClickIconEdit" and not DB.editMode))
        local barIndex = option.key:match("^showBar(%d)$")
        local number = tonumber(barIndex)
        local controls = barIndex and barControls[barIndex]
        local available = number and (number <= 5 or bars[number] ~= nil)
        local showConfig = shouldShow and available and DB[option.key] and not DB.defaultBottomView
        local showScale = showConfig and expandedBar == number
        if shouldShow then
            local showXP = option.key == "hideExperienceBar" and DB.hideExperienceBar
            local rowHeight = barIndex and (showScale and 188 or 40) or (showXP and 78 or 50)
            if option.key == "hideExperienceBar" then
                xpSelector:SetShown(showXP)
                xpResetButton:SetShown(showXP and DB.xpMode ~= "off")
                for _, mode in ipairs(xpModes) do
                    if DB.xpMode == mode.key then xpSelector:SetText("Custom XP: " .. mode.name) end
                end
            end
            row:ClearAllPoints()
            row:SetPoint("TOPLEFT", settingsContent, "TOPLEFT", option.indent and 16 or 0, y)
            row:SetHeight(rowHeight)
            row:SetWidth(option.indent and 390 or 406)
            row:Show()
            y = y - rowHeight - (barIndex and 2 or 8)
            optionChecks[option.key]:SetChecked(DB[option.key])
        else
            row:Hide()
        end
        if controls then
            controls.configure:SetShown(not not showConfig)
            controls.configure:SetText(showScale and "Collapse" or "Configure")
            controls.panel:SetShown(not not showScale)
            controls.description:SetText(not available and "Native bar unavailable (enable in game and reload)." or option.description)
            if available or DB[option.key] then optionChecks[option.key]:Enable() else optionChecks[option.key]:Disable() end
            if showScale then
                controls.orientation:SetText(DB["barVertical" .. barIndex] and "Vertical" or "Horizontal")
                controls.reverse:SetText(DB["barReverse" .. barIndex] and "Order: Reverse" or "Order: Normal")
                local wrap = DB["barWrap" .. barIndex] or 12
                local c,r = Recovery.GridSize(12,wrap,DB["barVertical" .. barIndex])
                controls.dimensions:SetText("Layout: " .. c .. " x " .. r)
                controls.spacing:SetText(tostring(DB["barSpacing" .. barIndex] or 0))
                controls.limit:SetText(number == 1 and isDruid and "12*" or tostring(DB["barLimit" .. barIndex] or 12))
            end
        end
        if barIndex and barScaleSliders[barIndex] then
            local slider, label = barScaleSliders[barIndex], barScaleLabels[barIndex]
            if shouldShow and showScale then
                slider.settingValue = true
                slider:SetValue(DB["barScale" .. barIndex] or 1)
                slider.settingValue = false
                label:SetText(string.format("%d%%", math.floor((DB["barScale" .. barIndex] or 1) * 100 + 0.5)))
                slider:EnableMouse(not DB.lockBars)
                slider:SetAlpha(DB.lockBars and 0.45 or 1)
                slider:Show()
                label:Show()
            else
                slider:Hide()
                label:Hide()
            end
        end
    end
    settingsContent.keybindShortcut:SetShown(activeSettingsTab == "BARS")
    tooltipModeButton:SetShown(activeSettingsTab == "BARS")
    visibilityButton:SetShown(activeSettingsTab == "BARS" and not DB.defaultBottomView)
    if activeSettingsTab == "BARS" then
        tooltipModeButton:ClearAllPoints()
        tooltipModeButton:SetPoint("TOPLEFT", settingsContent, "TOPLEFT", 0, y)
        tooltipModeButton:SetText("Slot tooltips: " .. (tooltipModes[DB.slotTooltipMode] or tooltipModes.hover))
        visibilityButton:ClearAllPoints(); visibilityButton:SetPoint("TOPLEFT", settingsContent, "TOPLEFT", 265, y)
        settingsContent.keybindShortcut:ClearAllPoints()
        settingsContent.keybindShortcut:SetPoint("TOPLEFT", settingsContent, "TOPLEFT", 265, y - 30)
    end
    for key, button in pairs(settingsTabs) do
        if key == "DRUID" then
            if isDruid then button:Show() else button:Hide() end
        end
        local font = button:GetFontString()
        if font then
            if key == activeSettingsTab then font:SetTextColor(1, 0.82, 0.35) else font:SetTextColor(0.88, 0.88, 0.88) end
        end
    end
    Nameplates.RefreshPanel(activeSettingsTab == "NAMEPLATES")
    if settingsAppearancePanel then
        if activeSettingsTab == "APPEARANCE" then settingsAppearancePanel:Show() else settingsAppearancePanel:Hide() end
    end
    if druidSettingsPanel then
        if isDruid and activeSettingsTab == "DRUID" then druidSettingsPanel:Show() else druidSettingsPanel:Hide() end
        if druidBlizzardModeButton then druidBlizzardModeButton:SetChecked((DB.druidFormMode or "blizzard") == "blizzard") end
        if druidActionHeroModeButton then druidActionHeroModeButton:SetChecked(DB.druidFormMode == "actionhero") end
        if druidMoveFormCheck then
            druidMoveFormCheck:SetChecked(DB.druidMoveFormBar)
            local showMove = isDruid and activeSettingsTab == "DRUID" and DB.druidFormMode ~= "actionhero"
            if showMove then
                druidMoveFormCheck:Show()
                if druidMoveFormLabel then druidMoveFormLabel:Show() end
                if druidMoveFormDescription then druidMoveFormDescription:Show() end
            else
                druidMoveFormCheck:Hide()
                if druidMoveFormLabel then druidMoveFormLabel:Hide() end
                if druidMoveFormDescription then druidMoveFormDescription:Hide() end
            end
        end
    end
end

local function SetDruidFormMode(mode)
    if InCombat() then
        Message("Druid form bar changes can be made after combat.")
        RefreshSettingsLayout()
        return
    end
    DB.druidFormMode = mode
    ApplyDruidForms()
    SaveActiveProfile()
    RefreshSettingsLayout()
end

-- Keep settings builders separate to respect the Forever Lua 60-upvalue limit.
local function BuildSettingsProfileControls(window)
    MakeLabel(window, "GameFontNormalSmall", "PROFILE", "TOPLEFT", window, "TOPLEFT", 25, -119)
    profileDropdown = CreateFrame("Frame", "ActionHeroProfileDropdown", window, "UIDropDownMenuTemplate")
    profileDropdown:SetPoint("TOPLEFT", window, "TOPLEFT", 12, -128)
    UIDropDownMenu_SetWidth(profileDropdown, 120)
    local saveProfile = AddProfileButton(window, "Save", 52, function()
        SaveActiveProfile()
        Message("Profile saved: " .. (DB.activeProfile or "Default"))
    end)
    saveProfile:SetPoint("TOPLEFT", window, "TOPLEFT", 166, -128)
    local saveAs = AddProfileButton(window, "Save As", 62, ShowProfileNameDialog)
    saveAs:SetPoint("TOPLEFT", window, "TOPLEFT", 221, -128)
    local deleteProfile = AddProfileButton(window, "Delete", 65, function()
        local name = DB.activeProfile or "Default"
        if name == "Default" or not DB.profiles or not DB.profiles[name] then
            Message("The Default profile cannot be deleted.")
            return
        end
        if InCombat() or draggingBar or formDragProfile or movingMenu then Message("Delete profiles after combat or dragging."); return end
        Recovery.Backup(DB, name, DB.profiles[name], "Delete")
        if type(DB.profiles.Default) ~= "table" then DB.profiles.Default = CaptureSettings() end
        DB.profiles[name] = nil
        SelectProfile("Default")
        Message("Profile deleted: " .. name)
    end)
    deleteProfile:SetPoint("TOPLEFT", window, "TOPLEFT", 286, -128)
    MakeLabel(window, "GameFontDisableSmall", "Changes save automatically.", "TOPLEFT", window, "TOPLEFT", 25, -153)
    recoveryButton = AddProfileButton(window, "Layout / Recovery", 144, function()
        Recovery.Open(DB, window, {
            allowed = function() return not InCombat() and not draggingBar and not formDragProfile and not movingMenu end,
            layoutAllowed = function() return not InCombat() and not draggingBar and not formDragProfile and not movingMenu and not DB.defaultBottomView end,
            capture = CaptureSettings, normalize = NormalizeSettings, select = SelectProfile,
            apply = function() ApplyAll(); SaveActiveProfile(); RefreshSettingsLayout(); RefreshProfileDropdown() end,
            message = Message,
        })
    end)
    recoveryButton:SetPoint("TOPLEFT", window, "TOPLEFT", 245, -153)
    RefreshProfileDropdown()
end

local function BuildSettingsDruidControls(playerClass)
    if playerClass == "DRUID" then
        druidSettingsPanel = CreateFrame("Frame", nil, settingsContent)
        druidSettingsPanel:SetAllPoints(settingsContent)
        MakeLabel(druidSettingsPanel, "GameFontNormalSmall", "FORM BAR STYLE", "TOPLEFT", druidSettingsPanel, "TOPLEFT", 8, -12)

        druidBlizzardModeButton = CreateFrame("CheckButton", nil, druidSettingsPanel, "UIRadioButtonTemplate")
        druidBlizzardModeButton:SetPoint("TOPLEFT", druidSettingsPanel, "TOPLEFT", 6, -29)
        druidBlizzardModeButton:SetScript("OnClick", function() SetDruidFormMode("blizzard") end)
        MakeLabel(druidSettingsPanel, "GameFontHighlight", "Blizzard form bar", "TOPLEFT", druidSettingsPanel, "TOPLEFT", 38, -32)
        MakeLabel(druidSettingsPanel, "GameFontDisableSmall", "Keep the original buttons and Blizzard layout. Enable the move handle below to drag it.", "TOPLEFT", druidSettingsPanel, "TOPLEFT", 38, -51)

        druidActionHeroModeButton = CreateFrame("CheckButton", nil, druidSettingsPanel, "UIRadioButtonTemplate")
        druidActionHeroModeButton:SetPoint("TOPLEFT", druidSettingsPanel, "TOPLEFT", 6, -90)
        druidActionHeroModeButton:SetScript("OnClick", function() SetDruidFormMode("actionhero") end)
        MakeLabel(druidSettingsPanel, "GameFontHighlight", "Action Hero form strip", "TOPLEFT", druidSettingsPanel, "TOPLEFT", 38, -93)
        MakeLabel(druidSettingsPanel, "GameFontDisableSmall", "Use Blizzard's form buttons in a compact row above Bar 1. It follows Bar 1 when moved or resized.", "TOPLEFT", druidSettingsPanel, "TOPLEFT", 38, -112)

        druidMoveFormCheck = CreateFrame("CheckButton", nil, druidSettingsPanel, "UICheckButtonTemplate")
        druidMoveFormCheck:SetPoint("TOPLEFT", druidSettingsPanel, "TOPLEFT", 4, -157)
        druidMoveFormCheck:SetSize(27, 27)
        druidMoveFormCheck:SetScript("OnClick", function(self)
            if InCombat() then
                self:SetChecked(DB.druidMoveFormBar)
                Message("Druid form bar changes can be made after combat.")
                return
            end
            DB.druidMoveFormBar = self:GetChecked() and true or false
            ApplyDruidForms()
            SaveActiveProfile()
            RefreshSettingsLayout()
        end)
        druidMoveFormLabel = MakeLabel(druidSettingsPanel, "GameFontHighlight", "Make Blizzard form bar movable", "TOPLEFT", druidSettingsPanel, "TOPLEFT", 42, -162)
        druidMoveFormDescription = MakeLabel(druidSettingsPanel, "GameFontDisableSmall", "Shows a FORMS handle above the original bar; drag the handle to reposition it.", "TOPLEFT", druidSettingsPanel, "TOPLEFT", 42, -182)
        local pagingCheck = CreateFrame("CheckButton", nil, druidSettingsPanel, "UICheckButtonTemplate")
        pagingCheck:SetSize(27, 27)
        pagingCheck:SetPoint("TOPLEFT", druidSettingsPanel, "TOPLEFT", 4, -220)
        pagingCheck:SetChecked(DB.druidPagingFix ~= false)
        pagingCheck:SetScript("OnShow", function(self) self:SetChecked(DB.druidPagingFix ~= false) end)
        pagingCheck:SetScript("OnClick", function(self)
            if InCombat() then
                self:SetChecked(DB.druidPagingFix ~= false)
                Message("Change shapeshift paging after combat.")
                return
            end
            SaveActiveProfile()
            DB.druidPagingFix = not not self:GetChecked()
            ReloadUI()
        end)
        MakeLabel(druidSettingsPanel, "GameFontHighlight", "Fix Shapeshift Paging", "TOPLEFT", druidSettingsPanel, "TOPLEFT", 42, -225)
        MakeLabel(druidSettingsPanel, "GameFontDisableSmall", "Keeps Bar 1 in sync with your form. Changing this reloads the UI.", "TOPLEFT", druidSettingsPanel, "TOPLEFT", 42, -245)

    end
end

local function BuildSettingsAppearanceControls()
    settingsAppearancePanel = CreateFrame("Frame", nil, settingsContent)
    settingsAppearancePanel:SetAllPoints(settingsContent)
    styleButton = CreateFrame("Button", nil, settingsAppearancePanel, "UIPanelButtonTemplate")
    styleButton:SetSize(275, 24)
    styleButton:SetPoint("TOPLEFT", settingsAppearancePanel, "TOPLEFT", 8, -8)
    styleButton:SetScript("OnClick", function(self)
        local current = DB.barSkin or "Classic"
        local nextIndex = 1
        for index, item in ipairs(BAR_SKINS) do
            if item.key == current then nextIndex = (index % #BAR_SKINS) + 1 break end
        end
        DB.barSkin = BAR_SKINS[nextIndex].key
        self:SetText("Bar look: " .. GetBarSkinLabel(DB.barSkin))
        ApplyBarSkins()
        SaveActiveProfile()
    end)
    styleButton:SetText("Bar look: " .. GetBarSkinLabel(DB.barSkin or "Classic"))
    styleButton:SetScript("OnEnter", function(self)
        GameTooltip:SetOwner(self, "ANCHOR_RIGHT")
        GameTooltip:SetText("Action bar look")
        GameTooltip:AddLine("Cycle Classic, Dark, Gold, and experimental Blue Steel or Emerald colors. Only the bar backing and trim change.", 1, 1, 1, true)
        GameTooltip:Show()
    end)
    styleButton:SetScript("OnLeave", function() GameTooltip:Hide() end)
    iconScaleText = MakeStepControl(settingsAppearancePanel, "ICON SIZE", 8, -48, function(direction)
        local value = math.floor(((DB.iconScale or 1) + direction * 0.1) * 10 + 0.5) / 10
        DB.iconScale = math.max(0.7, math.min(1.3, value))
        ApplyAll()
        SaveActiveProfile()
        RefreshAppearanceControls()
    end)
    opacityText = MakeStepControl(settingsAppearancePanel, "BAR OPACITY", 215, -48, function(direction)
        local value = math.floor(((DB.barOpacity or 1) + direction * 0.1) * 10 + 0.5) / 10
        DB.barOpacity = math.max(0.5, math.min(1, value))
        ApplyAll()
        SaveActiveProfile()
        RefreshAppearanceControls()
    end)
    MakeLabel(settingsAppearancePanel, "GameFontNormalSmall", "EQUIPPED ITEM HIGHLIGHT", "TOPLEFT", settingsAppearancePanel, "TOPLEFT", 8, -112)
    MakeLabel(settingsAppearancePanel, "GameFontDisableSmall", "Gold glow for equipped items placed on an Action Hero bar.", "TOPLEFT", settingsAppearancePanel, "TOPLEFT", 8, -130)
    equippedHighlightText = MakeLabel(settingsAppearancePanel, "GameFontHighlightSmall", "", "TOPRIGHT", settingsAppearancePanel, "TOPRIGHT", -10, -112)
    equippedHighlightSlider = CreateFrame("Slider", nil, settingsAppearancePanel)
    equippedHighlightSlider:SetPoint("TOPLEFT", settingsAppearancePanel, "TOPLEFT", 12, -151)
    equippedHighlightSlider:SetSize(370, 14)
    if equippedHighlightSlider.SetOrientation then equippedHighlightSlider:SetOrientation("HORIZONTAL") end
    equippedHighlightSlider:SetMinMaxValues(0, 1)
    equippedHighlightSlider:SetValueStep(0.05)
    if equippedHighlightSlider.SetObeyStepOnDrag then equippedHighlightSlider:SetObeyStepOnDrag(true) end
    equippedHighlightSlider:SetThumbTexture("Interface\\Buttons\\UI-SliderBar-Button-Horizontal")
    local equippedTrack = equippedHighlightSlider:CreateTexture(nil, "BACKGROUND")
    equippedTrack:SetColorTexture(0.36, 0.32, 0.25, 0.9)
    equippedTrack:SetPoint("LEFT", equippedHighlightSlider, "LEFT", 2, 0)
    equippedTrack:SetPoint("RIGHT", equippedHighlightSlider, "RIGHT", -2, 0)
    equippedTrack:SetHeight(3)
    equippedHighlightSlider:SetScript("OnValueChanged", function(self, value)
        if self.settingValue then return end
        if InCombat() then
            self.settingValue = true
            self:SetValue(DB.equippedHighlight or 0)
            self.settingValue = false
            return
        end
        DB.equippedHighlight = math.max(0, math.min(1, math.floor(value * 20 + 0.5) / 20))
        for barIndex = 1, BAR_COUNT do
            for slotIndex = 1, 12 do
                UpdateEquippedItemHighlight(barButtons[barIndex] and barButtons[barIndex][slotIndex])
            end
        end
        SaveActiveProfile()
        RefreshAppearanceControls()
    end)
    equippedHighlightSlider:SetScript("OnEnter", function(self)
        GameTooltip:SetOwner(self, "ANCHOR_RIGHT")
        GameTooltip:SetText("Equipped item highlight")
        GameTooltip:AddLine("Set to Off to disable the gold glow, or drag right to make it stronger.", 1, 1, 1, true)
        GameTooltip:Show()
    end)
    equippedHighlightSlider:SetScript("OnLeave", function() GameTooltip:Hide() end)
    RefreshAppearanceControls()
end

local function BuildSettingsOptionRows()
    for _, option in ipairs(OPTION_ROWS) do
        local row = CreateFrame("Frame", nil, settingsContent, "BackdropTemplate")
        row:SetSize(option.indent and 390 or 406, 50)
        row:SetBackdrop({ bgFile = "Interface\\Buttons\\WHITE8X8" })
        row:SetBackdropColor(1, 1, 1, 0.04)
        optionRows[option.key] = row
        local check = CreateFrame("CheckButton", nil, row, "UICheckButtonTemplate")
        check:SetPoint("TOPLEFT", row, "TOPLEFT", 6, -9)
        check:SetSize(27, 27)
        check:SetChecked(DB[option.key])
        optionChecks[option.key] = check
        local label = MakeLabel(row, "GameFontHighlight", option.label, "TOPLEFT", row, "TOPLEFT", 42, -9)
        label:SetWidth(option.indent and 330 or 346)
        local description = MakeLabel(row, "GameFontDisableSmall", option.description, "TOPLEFT", row, "TOPLEFT", 42, -29)
        description:SetWidth(option.indent and 330 or 346)
        if option.key == "hideExperienceBar" then
            xpSelector = CreateFrame("Button", nil, row, "UIPanelButtonTemplate")
            xpSelector:SetSize(192, 22)
            xpSelector:SetPoint("TOPLEFT", row, "TOPLEFT", 42, -49)
            xpSelector:SetScript("OnClick", function()
                local nextIndex = 1
                for index, mode in ipairs(xpModes) do
                    if DB.xpMode == mode.key then nextIndex = index % #xpModes + 1 end
                end
                DB.xpMode = xpModes[nextIndex].key
                ApplyXPDisplay()
                SaveActiveProfile()
                RefreshSettingsLayout()
            end)
            xpResetButton = CreateFrame("Button", nil, row, "UIPanelButtonTemplate")
            xpResetButton:SetSize(128, 22)
            xpResetButton:SetPoint("LEFT", xpSelector, "RIGHT", 6, 0)
            xpResetButton:SetText("Reset to Center")
            xpResetButton:SetScript("OnClick", function()
                DB.xpPoint = { "CENTER", "CENTER", 0, 0 }
                ApplyXPDisplay()
                SaveActiveProfile()
            end)
        end
        local barIndex = option.key:match("^showBar(%d)$")
        if barIndex then
            local scaleBarIndex = tonumber(barIndex)
            label:SetWidth(250)
            description:ClearAllPoints()
            description:SetPoint("TOPLEFT", row, "TOPLEFT", 42, -25)
            local configure = CreateFrame("Button", nil, row, "UIPanelButtonTemplate")
            configure:SetSize(92, 22)
            configure:SetPoint("TOPRIGHT", row, "TOPRIGHT", -6, -4)
            configure:SetScript("OnClick", function()
                if expandedBar == scaleBarIndex then expandedBar = nil else expandedBar = scaleBarIndex end
                RefreshSettingsLayout()
            end)
            local panel = CreateFrame("Frame", nil, row)
            panel:SetAllPoints(row)
            local function change(key, value)
                if DB.lockBars or InCombat() or draggingBar or DB.defaultBottomView or not DB[option.key] then
                    Message("Unlock bars and finish combat or dragging before changing the layout.")
                    return
                end
                RememberLayout()
                DB[key .. scaleBarIndex] = value
                ApplyAll()
                SaveActiveProfile()
                RefreshSettingsLayout()
            end
            local function makeButton(text, x, y, width, fn)
                local b = CreateFrame("Button", nil, panel, "UIPanelButtonTemplate")
                b:SetSize(width, 21); b:SetPoint("TOPLEFT", panel, "TOPLEFT", x, y)
                b:SetText(text); b:SetScript("OnClick", fn)
                return b
            end
            local orientation = makeButton("Horizontal", 42, -77, 125, function()
                change("barVertical", not DB["barVertical" .. scaleBarIndex])
            end)
            local reverse = makeButton("Order: Normal", 175, -77, 155, function()
                change("barReverse", not DB["barReverse" .. scaleBarIndex])
            end)
            MakeLabel(panel, "GameFontDisableSmall", "Spacing", "TOPLEFT", panel, "TOPLEFT", 42, -105)
            MakeLabel(panel, "GameFontDisableSmall", "Limit", "TOPLEFT", panel, "TOPLEFT", 208, -105)
            local spacing = MakeLabel(panel, "GameFontHighlightSmall", "0", "TOPLEFT", panel, "TOPLEFT", 134, -120)
            local limit = MakeLabel(panel, "GameFontHighlightSmall", "12", "TOPLEFT", panel, "TOPLEFT", 292, -120)
            local function step(key, delta, low, high, default)
                if key == "barLimit" and scaleBarIndex == 1 then
                    local _, class = UnitClass("player")
                    if class == "DRUID" then Message("Druid primary bar keeps all 12 slots for form paging."); return end
                end
                change(key, math.max(low, math.min(high, (DB[key .. scaleBarIndex] or default) + delta)))
            end
            makeButton("-", 90, -115, 32, function() step("barSpacing", -1, -2, 10, 0) end)
            makeButton("+", 157, -115, 32, function() step("barSpacing", 1, -2, 10, 0) end)
            local minus = makeButton("-", 248, -115, 32, function() step("barLimit", -1, 1, 12, 12) end)
            local plus = makeButton("+", 320, -115, 32, function() step("barLimit", 1, 1, 12, 12) end)
            for _, control in ipairs({minus, plus}) do
                control:SetScript("OnEnter", function(self)
                    GameTooltip:SetOwner(self, "ANCHOR_RIGHT")
                    GameTooltip:SetText("Visible button limit")
                    GameTooltip:AddLine("Limits visible occupied buttons only; assignments and keybinds are unchanged. Edit mode and dragging show all 12. Druid primary bar always shows all slots.", 1, 1, 1, true)
                    GameTooltip:Show()
                end)
                control:SetScript("OnLeave", function() GameTooltip:Hide() end)
            end
            local dimensions = makeButton("Layout", 42, -139, 145, function()
                change("barWrap", Recovery.NextWrap(DB["barWrap" .. scaleBarIndex]))
            end)
            local function recoverBar(center)
                if InCombat() or draggingBar or DB.defaultBottomView then Message("Finish combat or dragging first."); return end
                Recovery.Backup(DB, DB.activeProfile, CaptureSettings(), "Recover Bar " .. scaleBarIndex)
                RememberLayout()
                Recovery.RescueBar(DB, bars, scaleBarIndex, center)
                ApplyAll(); SaveActiveProfile(); RefreshSettingsLayout()
            end
            makeButton("Reset position", 199, -139, 153, function() recoverBar(false) end)
            makeButton("Rescue to center", 42, -163, 310, function() recoverBar(true) end)
            barControls[barIndex] = { configure = configure, panel = panel, description = description, dimensions = dimensions,
                orientation = orientation, reverse = reverse, spacing = spacing, limit = limit }
            local sizeLabel = MakeLabel(panel, "GameFontDisableSmall", "Scale", "TOPLEFT", row, "TOPLEFT", 42, -52)
            sizeLabel:SetWidth(38)
            local slider = CreateFrame("Slider", nil, panel)
            barScaleSliders[barIndex] = slider
            slider:SetPoint("TOPLEFT", row, "TOPLEFT", 82, -55)
            slider:SetSize(190, 14)
            if slider.SetOrientation then slider:SetOrientation("HORIZONTAL") end
            slider:SetMinMaxValues(0.75, 1.75)
            slider:SetValueStep(0.05)
            if slider.SetObeyStepOnDrag then slider:SetObeyStepOnDrag(true) end
            slider:SetThumbTexture("Interface\\Buttons\\UI-SliderBar-Button-Horizontal")
            local track = slider:CreateTexture(nil, "BACKGROUND")
            track:SetColorTexture(0.32, 0.29, 0.23, 0.9)
            track:SetPoint("LEFT", slider, "LEFT", 2, 0)
            track:SetPoint("RIGHT", slider, "RIGHT", -2, 0)
            track:SetHeight(3)
            local sliderValue = MakeLabel(panel, "GameFontDisableSmall", "100%", "TOPLEFT", row, "TOPLEFT", 282, -52)
            sliderValue:SetWidth(48)
            sliderValue:SetJustifyH("RIGHT")
            barScaleLabels[barIndex] = sliderValue
            slider:SetScript("OnValueChanged", function(self, value)
                if self.settingValue then return end
                if DB.lockBars or InCombat() or draggingBar or DB.defaultBottomView or not DB[option.key] then
                    self.settingValue = true
                    self:SetValue(DB["barScale" .. scaleBarIndex] or 1)
                    self.settingValue = false
                    return
                end
                value = math.floor(value * 20 + 0.5) / 20
                if value ~= DB["barScale" .. scaleBarIndex] then Recovery.RememberCoalesced(DB, "scale" .. scaleBarIndex) end
                DB["barScale" .. scaleBarIndex] = value
                if bars[scaleBarIndex] then bars[scaleBarIndex]:SetScale(value) end
                if scaleBarIndex == 1 and druidFormRow then druidFormRow:SetScale(value) end
                sliderValue:SetText(string.format("%d%%", math.floor(value * 100 + 0.5)))
                if SaveActiveProfile then SaveActiveProfile() end
            end)
            slider:SetScript("OnEnter", function(self)
                GameTooltip:SetOwner(self, "ANCHOR_RIGHT")
                GameTooltip:SetText(DB.lockBars and "Bars are locked" or "Scale this bar")
                GameTooltip:AddLine("Drag for a precise size from 75% to 175%.", 1, 1, 1, true)
                GameTooltip:Show()
            end)
            slider:SetScript("OnLeave", function() GameTooltip:Hide() end)
        end
        check:SetScript("OnClick", function(self) SetOption(option.key, self:GetChecked()) end)
        row:EnableMouse(true)
        row:SetScript("OnMouseUp", function(_, button)
            if button == "LeftButton" then SetOption(option.key, not DB[option.key]) end
        end)
        row:SetScript("OnEnter", function(self) self:SetBackdropColor(1, 1, 1, 0.08) end)
        row:SetScript("OnLeave", function(self) self:SetBackdropColor(1, 1, 1, 0.04) end)
    end
end

local function OpenNativeKeybindings()
    if InCombat() then Message("Open Keybindings after combat."); return end
    if Settings and type(Settings.OpenToCategory) == "function" then
        local category = Settings.KEYBINDINGS_CATEGORY_ID
        if not category and SettingsPanel and type(SettingsPanel.GetKeybindingsCategory) == "function" then
            local ok, result = pcall(SettingsPanel.GetKeybindingsCategory, SettingsPanel)
            if ok then
                if type(result) == "table" and type(result.GetID) == "function" then category = result:GetID()
                elseif type(result) == "number" or type(result) == "string" then category = result end
            end
        end
        if not category and SettingsPanel then
            local result = SettingsPanel.keybindingsCategory
            if type(result) == "table" and type(result.GetID) == "function" then category = result:GetID() end
        end
        local ok = pcall(Settings.OpenToCategory, category or KEY_BINDINGS or "Keybindings")
        if ok and SettingsPanel and SettingsPanel:IsShown() then
            settingsWindow:Hide()
            Message("In Keybindings, choose AddOns > Action Hero.")
            return
        end
    end
    if type(KeyBindingFrame_LoadUI) == "function" then pcall(KeyBindingFrame_LoadUI) end
    if KeyBindingFrame and type(ShowUIPanel) == "function" then
        local ok = pcall(ShowUIPanel, KeyBindingFrame)
        if ok and KeyBindingFrame:IsShown() then settingsWindow:Hide(); return end
    end
    Message("Open Esc > Options > Keybindings > AddOns > Action Hero.")
end

local function BuildSettings()
    if settingsWindow then return settingsWindow end
    local window = CreateFrame("Frame", "ActionHeroSettings", UIParent, "BackdropTemplate")
    settingsWindow = window
    window:SetSize(470, 720)
    window:SetPoint("CENTER")
    window:SetFrameStrata("DIALOG")
    window:SetClampedToScreen(true)
    window:SetMovable(true)
    window:EnableMouse(true)
    window:RegisterForDrag("LeftButton")
    window:SetScript("OnDragStart", function(self) self:StartMoving() end)
    window:SetScript("OnDragStop", function(self) self:StopMovingOrSizing() end)
    window:HookScript("OnHide", function() if Recovery.dialog then Recovery.dialog:Hide() end end)
    window:SetBackdrop({
        bgFile = "Interface\\Buttons\\WHITE8X8",
        edgeFile = "Interface\\DialogFrame\\UI-DialogBox-Border",
        tile = true, tileSize = 32, edgeSize = 32,
        insets = { left = 10, right = 10, top = 10, bottom = 10 },
    })
    window:SetBackdropColor(0.075, 0.085, 0.10, DB.transparentSettings and 0.62 or 1)
    MakeLabel(window, "GameFontNormalLarge", "Action Hero", "TOPLEFT", window, "TOPLEFT", 25, -26)
    MakeLabel(window, "GameFontHighlightSmall", "Seven flexible action bars and bottom UI controls.", "TOPLEFT", window, "TOPLEFT", 25, -53)
    keybindNote = MakeLabel(window, "GameFontHighlightSmall",
        "Bars 1–5 keep their native bindings. Optional bars 6–7 use native Extra Bars 1–2.\nDrag spells in Edit Mode; assign keys in Blizzard Key Bindings.",
        "TOPLEFT", window, "TOPLEFT", 25, -68)
    keybindNote:SetWidth(390)
    keybindNote:SetJustifyV("TOP")
    local version = MakeLabel(window, "GameFontDisableSmall", "v" .. VERSION, "TOPRIGHT", window, "TOPRIGHT", -54, -30)
    version:SetJustifyH("RIGHT")

    local close = CreateFrame("Button", nil, window, "UIPanelCloseButton")
    close:SetPoint("TOPRIGHT", window, "TOPRIGHT", -8, -8)
    close:SetScript("OnClick", function() window:Hide() end)
    local line = window:CreateTexture(nil, "ARTWORK")
    line:SetColorTexture(0.62, 0.48, 0.25, 0.65)
    line:SetPoint("TOPLEFT", window, "TOPLEFT", 24, -112)
    line:SetPoint("TOPRIGHT", window, "TOPRIGHT", -24, -112)
    line:SetHeight(1)

    BuildSettingsProfileControls(window)

    local _, playerClass = UnitClass("player")
    local tabDefinitions = {
        { key = "GENERAL", label = "General", width = 63 },
        { key = "BOTTOM UI", label = "Bottom UI", width = 71 },
        { key = "BARS", label = "Bars", width = 49 },
        { key = "APPEARANCE", label = "Appearance", width = 82 },
        { key = "NAMEPLATES", label = "Nameplates", width = 82 },
    }
    if playerClass == "DRUID" then
        table.insert(tabDefinitions, { key = "DRUID", label = "Forms", width = 51 })
    end
    local tabX = 24
    for _, definition in ipairs(tabDefinitions) do
        local tabKey = definition.key
        local tab = CreateFrame("Button", nil, window, "UIPanelButtonTemplate")
        tab:SetSize(definition.width, 24)
        tab:SetPoint("TOPLEFT", window, "TOPLEFT", tabX, -181)
        tab:SetText(definition.label)
        tab:SetScript("OnClick", function()
            activeSettingsTab = tabKey
            RefreshSettingsLayout()
        end)
        settingsTabs[tabKey] = tab
        tabX = tabX + definition.width + 4
    end
    settingsContent = CreateFrame("Frame", "ActionHeroSettingsContent", window)
    settingsContent:SetPoint("TOPLEFT", window, "TOPLEFT", 24, -211)
    settingsContent:SetPoint("BOTTOMRIGHT", window, "BOTTOMRIGHT", -24, 58)
    settingsContent:SetWidth(422)
    Nameplates.BuildPanel(settingsContent, SaveActiveProfile)
    tooltipModeButton = CreateFrame("Button", nil, settingsContent, "UIPanelButtonTemplate")
    tooltipModeButton:SetSize(252, 22)
    visibilityButton = AddProfileButton(settingsContent, "Hide / Show Bars", 140, ActionHero_ToggleBars)
    visibilityButton:SetScript("OnEnter", function(self)
        GameTooltip:SetOwner(self, "ANCHOR_RIGHT"); GameTooltip:SetText("Hide / Show Action Hero bars")
        GameTooltip:AddLine("Bind in Blizzard Key Bindings > Action Hero. No default key assigned. Combat requests defer.", 1,1,1,true); GameTooltip:Show()
    end)
    visibilityButton:SetScript("OnLeave", function() GameTooltip:Hide() end)
    settingsContent.keybindShortcut = AddProfileButton(settingsContent, "Keybinds...", 140, OpenNativeKeybindings)
    settingsContent.keybindShortcut:SetScript("OnEnter", function(self)
        GameTooltip:SetOwner(self, "ANCHOR_RIGHT")
        GameTooltip:SetText("Open Blizzard Keybindings")
        GameTooltip:AddLine("Set Action Hero shortcuts under AddOns > Action Hero.", 1, 1, 1, true)
        GameTooltip:Show()
    end)
    settingsContent.keybindShortcut:SetScript("OnLeave", function() GameTooltip:Hide() end)
    tooltipModeButton:SetScript("OnClick", function()
        local mode = DB.slotTooltipMode
        if mode == "dismiss" then
            DB.slotTooltipMode = "off"
        elseif mode == "off" then
            DB.slotTooltipMode = "hover"
        else
            DB.slotTooltipMode = "dismiss"
        end
        dismissedOwner = nil
        SaveActiveProfile()
        RefreshSettingsLayout()
    end)

    BuildSettingsDruidControls(playerClass)
    BuildSettingsAppearanceControls()
    BuildSettingsOptionRows()
    equippedHighlightSlider.settingValue = true
    equippedHighlightSlider:SetValue(DB.equippedHighlight or 0)
    equippedHighlightSlider.settingValue = false
    RefreshSettingsLayout()

    local bottomLine = window:CreateTexture(nil, "ARTWORK")
    bottomLine:SetColorTexture(0.45, 0.45, 0.45, 0.4)
    bottomLine:SetPoint("BOTTOMLEFT", window, "BOTTOMLEFT", 24, 47)
    bottomLine:SetPoint("BOTTOMRIGHT", window, "BOTTOMRIGHT", -24, 47)
    bottomLine:SetHeight(1)
    statusText = MakeLabel(window, "GameFontDisableSmall", "", "BOTTOMLEFT", window, "BOTTOMLEFT", 25, 24)
    statusText:SetWidth(380)
    local memorial = window:CreateFontString(nil, "OVERLAY")
    memorial:SetFont("Fonts\\MORPHEUS.TTF", 11, "OUTLINE")
    memorial:SetPoint("BOTTOM", window, "BOTTOM", 0, 7)
    memorial:SetText("RIP Shady")
    memorial:SetTextColor(0.78, 0.60, 0.27, 0.82)
    UpdateStatus()
    window:Hide()
    if type(UISpecialFrames) == "table" then table.insert(UISpecialFrames, "ActionHeroSettings") end
    return window
end

local function ToggleSettings()
    -- Native extra bars can be initialized after login. Retry safely when
    -- opening settings instead of polling or blocking the original bars.
    if not InCombat() and not DB.defaultBottomView and not draggingBar and (not barsReady or not bars[6] or not bars[7]) then ApplyAll() end
    local window = BuildSettings()
    if window:IsShown() then window:Hide() else RefreshSettingsLayout(); window:Show(); window:Raise() end
end

local function SetMinimapButtonPosition()
    if not minimapButton or not Minimap then return end
    if InCombat() then minimapRefreshPending = true; return end
    local angle = math.rad(DB.minimapAngle or 220)
    local radius = (Minimap:GetWidth() / 2) + 4
    minimapButton:ClearAllPoints()
    minimapButton:SetPoint("CENTER", Minimap, "CENTER", math.cos(angle) * radius, math.sin(angle) * radius)
end

local function UpdateMinimapButtonAngle()
    if not minimapButton or not Minimap then return end
    local cursorX, cursorY = GetCursorPosition()
    local uiScale = UIParent:GetScale()
    cursorX, cursorY = cursorX / uiScale, cursorY / uiScale
    local centerX, centerY = Minimap:GetCenter()
    DB.minimapAngle = math.deg(math.atan2(cursorY - centerY, cursorX - centerX))
    SetMinimapButtonPosition()
end

CreateMinimapButton = function()
    if not DB or not Minimap then return end
    if InCombat() then minimapRefreshPending = true; return end
    minimapRefreshPending = false
    if not minimapButton then
        local button = CreateFrame("Button", "ActionHeroMinimapButton", Minimap, "SecureHandlerClickTemplate")
        minimapButton = button
        for index, bar in pairs(bars) do button:SetFrameRef("bar" .. index, bar) end
        button:SetAttribute("_onclick", [[
            if self:GetAttribute("defaultBottomView") then return end
            if button ~= "EmergencyToggle" and (button ~= "RightButton" or IsShiftKeyDown()) then return end
            local reveal = not self:GetAttribute("revealed")
            self:SetAttribute("revealed", reveal)
            for index = 1, 7 do
                local bar = self:GetFrameRef("bar" .. index)
                if bar then
                    if self:GetAttribute("hasSlots" .. index) and (reveal or self:GetAttribute("enabledBar" .. index)) then
                        bar:Show()
                    else
                        bar:Hide()
                    end
                end
            end
        ]])
        button:SetAttribute("defaultBottomView", DB.defaultBottomView)
        button:SetSize(32, 32)
        button:SetFrameStrata("MEDIUM")
        button:SetFrameLevel(8)
        button:RegisterForClicks("AnyUp")
        button:RegisterForDrag("LeftButton")

        local icon = button:CreateTexture(nil, "BACKGROUND")
        icon:SetTexture("Interface\\Icons\\INV_Sword_39")
        icon:SetSize(20, 20)
        icon:SetPoint("CENTER")
        button.icon = icon

        local border = button:CreateTexture(nil, "OVERLAY")
        border:SetTexture("Interface\\Minimap\\MiniMap-TrackingBorder")
        border:SetSize(54, 54)
        border:SetPoint("TOPLEFT")
        button.border = border
        button:SetHighlightTexture("Interface\\Minimap\\UI-Minimap-ZoomButton-Highlight")

        button:SetScript("OnEnter", function(self)
            GameTooltip:SetOwner(self, "ANCHOR_LEFT")
            GameTooltip:SetText("Action Hero")
            GameTooltip:AddLine("Left-click: open settings", 1, 1, 1)
            if not DB.defaultBottomView then
                GameTooltip:AddLine(emergencyBarsRevealed and "Right-click: restore your bar layout" or "Right-click: temporarily show all available bars", 1, 1, 1)
                local key1, key2 = GetBindingKey("CLICK ActionHeroMinimapButton:EmergencyToggle")
                local keys = key1 and (key1 .. (key2 and (" / " .. key2) or "")) or "Not bound"
                GameTooltip:AddLine("Reveal / Restore key: " .. keys, 1, 0.82, 0.35)
                GameTooltip:AddLine("Shift-right-click: lock or unlock action bars", 1, 1, 1)
            end
            GameTooltip:AddLine("Drag to move this icon", 0.75, 0.75, 0.75)
            GameTooltip:Show()
        end)
        button:SetScript("OnLeave", function() GameTooltip:Hide() end)
        button:HookScript("OnClick", function(self, mouseButton)
            if (mouseButton == "RightButton" or mouseButton == "EmergencyToggle") and DB.defaultBottomView then return end
            if mouseButton == "RightButton" and IsShiftKeyDown() then
                if InCombat() then
                    Message("Lock or unlock action bars after combat.")
                    return
                end
                SetOption("lockBars", not DB.lockBars)
                Message(DB.lockBars and "Action bars locked." or "Action bars unlocked.")
            elseif mouseButton == "RightButton" or mouseButton == "EmergencyToggle" then
                temporaryHidden = false
                pendingVisibility = false
                emergencyBarsRevealed = self:GetAttribute("revealed")
                Message(emergencyBarsRevealed and "Hidden action bars revealed." or "Saved action bar visibility restored.")
            elseif self.suppressClick then
                return
            elseif mouseButton == "LeftButton" then
                ToggleSettings()
            end
        end)
        button:SetScript("OnDragStart", function(self)
            if InCombat() then return end
            self.suppressClick = true
            self:SetScript("OnUpdate", UpdateMinimapButtonAngle)
        end)
        button:SetScript("OnDragStop", function(self)
            self:SetScript("OnUpdate", nil)
            UpdateMinimapButtonAngle()
            if SaveActiveProfile then SaveActiveProfile() end
            if C_Timer and C_Timer.After then
                C_Timer.After(0.2, function() self.suppressClick = false end)
            else
                self.suppressClick = false
            end
        end)
        Minimap:HookScript("OnSizeChanged", SetMinimapButtonPosition)
    end
    SetMinimapButtonPosition()
    if DB.showMinimapButton then minimapButton:Show() else minimapButton:Hide() end
end

SLASH_ACTIONHERO1 = "/actionhero"
SLASH_ACTIONHERO2 = "/ahero"
SlashCmdList.ACTIONHERO = function(input)
    if DB and (input or ""):match("^%s*default%s*$") then
        SetOption("defaultBottomView", not DB.defaultBottomView)
    elseif DB and (input or ""):match("^%s*repairmenu%s*$") then
        if DB.defaultBottomView or DB.hideMicroMenu then
            Message("Menu repair is available when the custom menu is visible.")
        elseif movingMenu then
            Message("Finish moving the menu first.")
        elseif not Recovery.ValidPoint(DB.menuPoint) then
            Message("Move the menu once to save a custom position first.")
        elseif InCombat() then
            Message("Menu position will be checked after combat.")
        elseif MenuGuard.Repair() then
            Message("Saved menu position restored.")
        else
            Message("Menu frame unavailable.")
        end
    elseif DB and (input or ""):match("^%s*bars%s*$") then
        ActionHero_ToggleBars()
    elseif DB then
        ToggleSettings()
    end
end

NormalizeSettings = function(settings)
    Nameplates.Defaults(settings)
    if settings.transparentSettings == nil and settings.opaqueSettings ~= nil then
        settings.transparentSettings = not settings.opaqueSettings
    end
    settings.xpMode = settings.xpMode or "off"
    for _, option in ipairs(OPTION_ROWS) do
        if type(settings[option.key]) ~= "boolean" then settings[option.key] = option.default end
    end
    for index = 1, BAR_COUNT do
        local pointKey, scaleKey = "barPoint" .. index, "barScale" .. index
        if type(settings[pointKey]) ~= "table" then
            if index > 5 then
                settings[pointKey] = { "TOPRIGHT", "TOPRIGHT", -50 - (index - 6) * 55, -150 }
            else
                settings[pointKey] = { "BOTTOM", "BOTTOM", 0, 54 + (index - 1) * 48 }
            end
        end
        if not Recovery.ValidPoint(settings[pointKey]) then settings[pointKey] = Recovery.DefaultPoint(index) end
        settings["barWrap" .. index] = Recovery.ValidWrap(settings["barWrap" .. index])
        local verticalKey, reverseKey = "barVertical" .. index, "barReverse" .. index
        local spacingKey, limitKey = "barSpacing" .. index, "barLimit" .. index
        if type(settings[verticalKey]) ~= "boolean" then settings[verticalKey] = index > 5 end
        if type(settings[reverseKey]) ~= "boolean" then settings[reverseKey] = false end
        settings[spacingKey] = math.floor(math.max(-2, math.min(10, tonumber(settings[spacingKey]) or 0)))
        settings[limitKey] = math.floor(math.max(1, math.min(12, tonumber(settings[limitKey]) or 12)))
        settings[scaleKey] = math.max(0.75, math.min(1.75, tonumber(settings[scaleKey]) or 1))
    end
    for _, key in ipairs({"menuPoint", "singleBagPoint", "druidFormPoint", "xpPoint"}) do
        if settings[key] ~= nil and not Recovery.ValidPoint(settings[key]) then settings[key] = nil end
    end
    settings.barsSnapped = not not settings.barsSnapped
    settings.snapLeader = math.floor(math.max(1, math.min(BAR_COUNT, tonumber(settings.snapLeader) or 1)))
    if type(settings.snapBreaks) ~= "table" then settings.snapBreaks = {} end
    local angle = tonumber(settings.minimapAngle)
    settings.minimapAngle = angle and angle == angle and math.abs(angle) < math.huge and angle or 220
    settings.barSkin = settings.barSkin or "Classic"
    settings.iconScale = math.max(0.7, math.min(1.3, tonumber(settings.iconScale) or 1))
    settings.barOpacity = math.max(0.5, math.min(1, tonumber(settings.barOpacity) or 1))
    settings.equippedHighlight = math.max(0, math.min(1, tonumber(settings.equippedHighlight) or 0.65))
    if settings.druidFormMode ~= "actionhero" then settings.druidFormMode = "blizzard" end
    if settings.druidMoveFormBar == nil then settings.druidMoveFormBar = true end
end

local function MigrateSettings(settings)
    NormalizeSettings(settings)
    -- Profiles are additive: the current saved layout remains the active
    -- configuration, and becomes Default only when profiles do not exist yet.
    if type(settings.profiles) ~= "table" then settings.profiles = {} end
    Recovery.NormalizeBackups(settings)
    for _, profile in pairs(settings.profiles) do
        if type(profile) == "table" then
            Nameplates.Defaults(profile)
            for i=1,BAR_COUNT do profile["barWrap"..i]=Recovery.ValidWrap(profile["barWrap"..i]) end
        end
        if type(profile) == "table" and profile.equippedHighlight == nil then
            profile.equippedHighlight = settings.equippedHighlight
        end
        if type(profile) == "table" and profile.druidFormMode == nil then profile.druidFormMode = settings.druidFormMode end
        if type(profile) == "table" and profile.druidMoveFormBar == nil then profile.druidMoveFormBar = settings.druidMoveFormBar end
    end
    if not next(settings.profiles) then
        settings.activeProfile = "Default"
        settings.profiles.Default = CaptureSettings(settings)
    elseif type(settings.activeProfile) ~= "string" or type(settings.profiles[settings.activeProfile]) ~= "table" then
        settings.activeProfile = nil
        if type(settings.profiles.Default) ~= "table" then
            for name, profile in pairs(settings.profiles) do
                if type(name) == "string" and type(profile) == "table" then settings.activeProfile = name; break end
            end
            if not settings.activeProfile then
                local name = "Default"
                while settings.profiles[name] ~= nil do name = name .. " (new)" end
                settings.activeProfile = name
                settings.profiles[name] = CaptureSettings(settings)
            end
        else
            settings.activeProfile = "Default"
        end
    end
    return settings
end

local function InitializeDB()
    local ok, migrated = pcall(function()
        local saved = type(ActionHeroDB) == "table" and ActionHeroDB or {}
        return MigrateSettings(CopyTable(saved))
    end)
    if not ok then
        Message("Could not migrate settings. Saved data was retained. " .. tostring(migrated))
        return
    end
    ActionHeroDB = migrated
    DB = migrated
    Nameplates.Configure(DB)
    CreateMinimapButton()
    ApplyAll()
end

local loader = CreateFrame("Frame")
loader:RegisterEvent("ADDON_LOADED")
loader:RegisterEvent("PLAYER_CONTROL_LOST")
loader:RegisterEvent("PLAYER_CONTROL_GAINED")
loader:RegisterEvent("PLAYER_MOUNT_DISPLAY_CHANGED")
loader:RegisterEvent("PLAYER_LOGIN")
loader:RegisterEvent("PLAYER_ENTERING_WORLD")
loader:RegisterEvent("PLAYER_REGEN_ENABLED")
loader:RegisterEvent("PLAYER_REGEN_DISABLED")
loader:RegisterEvent("ACTIONBAR_SLOT_CHANGED")
loader:RegisterEvent("ACTIONBAR_PAGE_CHANGED")
loader:RegisterEvent("CURSOR_CHANGED")
loader:RegisterEvent("ACTIONBAR_SHOWGRID")
loader:RegisterEvent("ACTIONBAR_HIDEGRID")
loader:RegisterEvent("UPDATE_BONUS_ACTIONBAR")
loader:RegisterEvent("UPDATE_SHAPESHIFT_FORMS")
local cursorHeldAction = false
loader:RegisterEvent("PLAYER_EQUIPMENT_CHANGED")
loader:SetScript("OnEvent", function(_, event, addonName)
    if event == "ADDON_LOADED" and addonName == ADDON_NAME then
        InitializeDB()
        if DB and not barsReady and not DB.defaultBottomView and C_Timer and C_Timer.After then
            C_Timer.After(0, ApplyAll)
        end
    elseif event == "PLAYER_LOGIN" or event == "PLAYER_ENTERING_WORLD" then
        ApplyAll()
        if C_Timer and C_Timer.After then C_Timer.After(0.75, ReapplySavedCustomPositions) end
    elseif event == "PLAYER_CONTROL_LOST" or event == "PLAYER_CONTROL_GAINED" or event == "PLAYER_MOUNT_DISPLAY_CHANGED" then
        RefreshFlightStop()
        MenuGuard.Queue()
        if C_Timer and C_Timer.After then C_Timer.After(0.25, RefreshFlightStop) end
    elseif event == "PLAYER_REGEN_ENABLED" then
        if minimapRefreshPending then CreateMinimapButton(); waitingForCombat = true end
        FinishFormDrag()
        if draggingBar then
            for index, bar in pairs(bars) do
                if bar == draggingBar then barHeaders[index]:GetScript("OnDragStop")(); break end
            end
        end
        if movingMenu then movingMenu:GetScript("OnDragStop")() end
        if pendingVisibility then pendingVisibility = false; ActionHero_ToggleBars() end
        if waitingForCombat then
            waitingForCombat = false
            ApplyAll()
        elseif RefreshIconEditOverlays then
            RefreshIconEditOverlays()
        end
        MenuGuard.Queue()
    elseif event == "PLAYER_REGEN_DISABLED" then
        if formDragProfile or draggingBar or movingMenu then waitingForCombat = true end
        if ActionHeroIconPicker then ActionHeroIconPicker:Hide() end
        if RefreshIconEditOverlays then RefreshIconEditOverlays() end
    elseif not DB or DB.defaultBottomView or not barsReady then
        return
    elseif event == "CURSOR_CHANGED" then
        local holding = HoldingAction()
        if cursorHeldAction ~= holding then
            cursorHeldAction = holding
            layoutUpdate:Show()
        end
    elseif event ~= "ADDON_LOADED" then
        if InCombat() then
            waitingForCombat = true
        else
            if event == "UPDATE_SHAPESHIFT_FORMS" then refreshForms = true end
            layoutUpdate:Show()
        end
    end
end)
