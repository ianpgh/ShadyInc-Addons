-- Independent Druid-only secure paging workaround for Forever 16001.
local _, ns = ...
if select(2, UnitClass("player")) ~= "DRUID" then return end
local paging = {}
ns.DruidPaging = paging
local header, registered, pending, currentDriver
local pages = { [768]=7, [5487]=9, [9634]=9, [24858]=10, [33891]=10, [783]=1, [1066]=1 }
function paging.BuildDriver()
    local rules = {}
    local function addSpecial(condition, getter)
        if type(getter) == "function" then
            local page = tonumber(getter())
            if page and page > 0 then rules[#rules+1] = condition .. page end
        end
    end
    addSpecial("[overridebar]", GetOverrideBarIndex)
    addSpecial("[vehicleui]", GetVehicleBarIndex)
    addSpecial("[shapeshift]", GetTempShapeshiftBarIndex)
    rules[#rules+1] = "[bonusbar:5]11"
    for page=2,6 do rules[#rules+1] = ("[bar:%d]%d"):format(page,page) end
    for i=1,GetNumShapeshiftForms() do
        local _, _, _, spell = GetShapeshiftFormInfo(i)
        local page = pages[spell]
        if spell == 768 then rules[#rules+1] = ("[form:%d,stealth]8"):format(i) end
        if page then rules[#rules+1] = ("[form:%d]%d"):format(i,page) end
    end
    rules[#rules+1] = "[noform]1"
    rules[#rules+1] = "1"
    return table.concat(rules,";")
end
local function conflictingAddon()
    local loaded = C_AddOns and C_AddOns.IsAddOnLoaded or IsAddOnLoaded
    if not loaded then return false end
    for _, name in ipairs({"FormBars","ShiftBar","DruidActionBarPager","PowerShiftBarFix","Bartender4","Dominos","ElvUI"}) do
        if loaded(name) then return true end
    end
    return false
end
local function apply(force)
    if InCombatLockdown() then pending = true; return end
    pending = false
    if not ActionHeroDB or ActionHeroDB.druidPagingFix == false then return end
    if conflictingAddon() then return end
    if not RegisterStateDriver or not GetShapeshiftFormInfo or not GetNumShapeshiftForms then return end
    if not header then
        for i=1,12 do if not _G["ActionButton"..i] then return end end
        header = CreateFrame("Frame", nil, UIParent, "SecureHandlerStateTemplate")
        for i=1,12 do
            local button = _G["ActionButton"..i]
            header:SetFrameRef("button"..i,button)
            button:HookScript("OnAttributeChanged",function(self,key)
                if key == "actionpage" and self.UpdateAction then self:UpdateAction() end
            end)
        end
        header:SetAttribute("_onstate-ahpage", [[
            local page = tonumber(newstate)
            if not page then return end
            for i=1,12 do
                local button = self:GetFrameRef("button"..i)
                button:SetAttribute("actionpage",page)
            end
        ]])
    end
    local driver = paging.BuildDriver()
    if registered and driver == currentDriver and not force then return end
    if registered then UnregisterStateDriver(header,"ahpage") end
    header:SetAttribute("state-ahpage",nil)
    RegisterStateDriver(header,"ahpage",driver)
    registered, currentDriver = true, driver
end
local events = CreateFrame("Frame")
for _, event in ipairs({"PLAYER_LOGIN","PLAYER_ENTERING_WORLD","UPDATE_SHAPESHIFT_FORMS","PLAYER_REGEN_ENABLED"}) do events:RegisterEvent(event) end
events:SetScript("OnEvent",function(_,event)
    if event == "PLAYER_REGEN_ENABLED" then
        if pending then apply(true) end
    else
        apply(event ~= "UPDATE_SHAPESHIFT_FORMS")
    end
end)
