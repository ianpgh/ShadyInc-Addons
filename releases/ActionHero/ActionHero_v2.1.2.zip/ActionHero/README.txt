ACTION HERO 2.1.2 — EXPERIMENTAL LETTER/NUMBER COMBO POINTS
Baseline: complete 2.1.1. Open /ahero > Nameplates > Combo point colors & shapes.
Choose Letter/Number after Star, then click any of the five preview points.
Choose A-Z or 0-9 from the grid. Defaults are 1, 2, 3, 4, 5. Repeated characters
are allowed. Characters save independently per profile and persist when switching
shapes. Existing colors, fixed/progressive behavior, empty opacity and max glow
apply to glyphs as well. Outline masks approximate the border thickness slider.
Reset appearance also resets the characters. No changes to combo tracking or bars.
Offline validation: Lua syntax, 188 prior regression cases and 360 glyph
picker/render/color cases plus migration, profile and shape switch checks.
Live client appearance and popup interaction require in-game testing.

ACTION HERO 2.1.1 — COMBO POINT APPEARANCE
Baseline: complete 2.1.0. Open /ahero > Nameplates > Combo point colors & shapes.
Choose Simple (1–4 / 5), Grouped (1–2 / 3–4 / 5), or Individual (1–5).
Progressive: all filled points take the current count's color. Fixed: each point
retains its assigned color. Each mode retains its own palette. Original simple
progressive colors and circle shape remain the defaults (rounded to RGB hex).
Choose Circle, Square, Diamond, Triangle or Star. Only relevant color fields
are shown. Click a swatch on clients with the modern native color picker, or
enter six-digit RGB hex values and press Enter; invalid values are
ignored. Empty, border and max glow colors, glow intensity, border thickness,
and empty opacity are shared. Preview 0–5 points without a target. Reset
appearance restores appearance defaults only. Existing glow toggle still applies.
All appearance settings are profile-specific; no combo tracking, native action
bar, keybind or health bar behavior changed. Offline validation: Lua syntax,
188 point/shape/visibility assertions plus invalid input, picker cancel, profile
isolation and migration checks. Live client testing still required.

ACTION HERO 2.1.0 — PER-BAR LAYOUTS
World of Warcraft: Forever (Interface 16001)

Baseline: ActionHero_v2.0.0.zip (original five bars and native bindings retained).
Open /ahero > Bars. Only enabled bars have a Configure button. Expand one bar
at a time to set horizontal/vertical, scale (75–175%), spacing (-2 to +10
relative to the existing spacing), normal/reversed display order, and visible
occupied-button limit (1–12). The limit never deletes actions or changes their
slot assignments. Edit Mode and action dragging reveal all twelve; the Druid
primary bar always retains twelve for form paging. Changes require unlocked
bars, out of combat and no active bar drag. Show/hide retains the configuration.

Optional bars 6 and 7 are hidden by default and start vertical near the right
edge. They reuse the native MultiBar5/MultiBar6 buttons, independent slots
145–156 and 157–168, and native Multi Action Bar 5/6 keybinds. A bar is adopted
only when the corresponding native frame, page and all 12 actual action slots
match. Missing or incompatible optional bars never block the original five;
if unavailable, enable the native extra bar in game settings, reload and retry.
Use Edit Mode to populate empty enabled bars. Native Extra Bar 3 is untouched.

Shift-click a bar header to snap same-orientation bars: horizontal bars stack
below the leader; vertical bars snap to the right. Mixed orientations remain
independent. This retains the original single snap-stack behavior; selecting a
new leader replaces the previous stack. Optional hidden bars do not participate.
Right-click the minimap icon temporarily reveals available populated bars.

Existing profiles, custom slot icons, sizes, anchors, visibility and bindings
are retained. Old profiles gain independent defaults on restore. No native
binding or action storage writes are introduced. Default View still reloads
back to the native UI; all original functionality and nameplates are retained.

Validation: Lua syntax, archive integrity, and focused simulated tests of
migration, optional source rejection, missing-source fallback, native button
identity, layout geometry, limit/edit mode, vertical/horizontal snap, combat
layout guards, Druid primary slots, profile switching, and settings visibility.
Mocked frame behavior is not a live WoW client: verify secure clicks, bindings,
combat lockdown, native bar initialization and actual UI appearance in game.

Install with the client closed. Back up Interface/AddOns/ActionHero and its
WTF SavedVariables, replace only the ActionHero addon folder, and keep WTF.
Recommended first check: enable Bar 6/7, enable Edit Mode, drag a distinct
ability to each, bind and use both, switch orientation, reload, then test
combat and Default View. Do not publish until those checks pass.

--- PREVIOUS RELEASE NOTES ---

ACTION HERO 2.0.0

- Build all five bars only when all 60 native buttons are available. Defer
  protected layout and drag changes during combat.
- Preserve the original SavedVariables if migration fails. Restore sparse
  profiles without carrying over the previous bag, menu, XP or icon settings.
- Keep the custom XP display off in Default View. Keep Default View outside
  layout profiles.
- Coalesce bursts of action-bar and equipment events into one layout refresh.

Settings > Bottom UI > Show default bottom UI (or /ahero default) reloads
the UI and switches between Blizzard's bottom UI and your saved Action Hero
layout. Switch outside combat. This setting applies across profiles.
Install HideThisManager 1.3.6 if you use it to hide the native bag bar or
micro menu, or to center the main action bar.

ACTION HERO 2.0 ALPHA 3 - TARGET NAMEPLATES

Settings: /ahero > Nameplates. Combo points are enabled by default for Rogues and
Druids in Cat Form; no count or finisher text. Yellow filled points, gray empty
points, green at five. Hide-zero, glow, above/below, size, spacing and X/Y offsets
are configurable. The current hostile target alone is decorated.

Bigger HP bar for target and % in HP bar are independent, opt-in for all classes.
The size slider changes the width and height of a visual HP overlay (default 140%).
The native health bar, hitbox, CVars and action bars are not modified. Turning
options off removes only our own decoration. The overlay may obscure existing
health-bar text or absorb artwork and may overlap other nameplate decorations;
adjust the size or disable the option if using another nameplate addon.

Existing profiles gain additive defaults; no SavedVariables reset is required.
No OnUpdate polling. Target and unit events drive the display. Native nameplate
health-bar discovery is guarded, but custom nameplate layouts are not guaranteed.
Static Lua syntax and mocked nameplate event tests passed; live Forever testing
is required, especially in combat and with other nameplate addons.

Install: exit the game, back up the existing ActionHero folder and SavedVariables,
then replace the addon folder with the included ActionHero folder. Do not delete
WTF/SavedVariables. /reload after installing if appropriate.

--- PREVIOUS RELEASE NOTES ---

Action Hero 2.0 Alpha 2
World of Warcraft: Forever (Interface 16001)

Action Hero supplies five movable action rows and focused bottom UI controls.
Its cleanup controls are independent from HideThisManager's settings.

Druid Forms (Druids only)
- The Druid Forms tab offers two mutually exclusive layouts.
- Blizzard form bar keeps Blizzard's original form buttons and layout. The optional FORMS handle lets you move the original bar; its position saves with the active profile.
- Action Hero form strip reuses Blizzard's form buttons in a compact row just above Action Hero Bar 1. The strip follows Bar 1 when it moves or changes scale.
- Form buttons keep Blizzard's shapeshift behavior and update when forms change. The selected style and native bar position are saved per profile.

Settings are organized into General, Bottom UI, Action Bars, and Appearance tabs. Profile controls remain at the top for quick access; the settings pages no longer use a scrolling list.

General options
- Edit mode shows all 12 slots on each bar for adding and arranging actions.
- Normal mode hides empty slots and compacts filled actions on fixed action bars; slots without action icons are omitted.
- The minimap button opens settings with left-click. Right-click temporarily reveals bars hidden by your settings while keeping their normal compact layout; right-click again restores your saved visibility. Drag it around the minimap to reposition it.
- The minimap button uses a sword emblem with the standard gold tracking border.
- Druids keep all 12 primary bar slots visible so form-swapped actions remain available during combat.
- Enable Transparent settings window to let the game world show through; leave it unchecked for a solid background.

Bottom UI options
- Hide the original action bar and its decorative outline.
- Hide the Micro Menu icons, or enable moving to drag the group by its MENU handle.
- Hide the bag bar, or show one movable backpack button. Drag its BAG handle or right-drag the button to move it; left-click opens the backpack.
- The movable backpack button directly toggles the backpack and does not depend on Blizzard's hidden button being clickable.
- Empty action slots are rechecked if Blizzard tries to show them during action-bar hover/grid updates.
- Hide the experience bar, including Blizzard's status tracking container.
- Hide the reputation/honor bar, including Blizzard's status tracking container.

Action Hero options
- In Action Bars, click Slot tooltips to cycle through Show on hover (default), Middle-click to dismiss for the current hover, and Always off.
- Show or hide each row independently.
- Settings use General, Bottom UI, Action Bars and Appearance tabs instead of a long scrolling options list. Profile controls stay pinned at the top.
- Show or hide labels above all five rows (off by default).
- Lock all rows against moving and resizing.
- Save named profiles for complete layouts and settings. Changes save to the active profile automatically; use Save As to create another layout.
- The Save As prompt now stays above the settings window so the profile name and buttons remain accessible.
- While Save As is open, an invisible modal shield absorbs clicks outside the prompt so they cannot toggle settings behind it.
- Switch profiles from the Profile menu. Default is protected from deletion.
- Cycle the bar look between Classic (the existing appearance), Dark backing, and Dark with gold trim. Experimental Blue Steel and Emerald colors are also available. These change only the backing and trim; action icons and their behavior stay the same.
- The Appearance tab has an equipped-item highlight slider. It adds a gold glow to actions recognized by the client as equipped items; set the slider to Off to disable it.
- Replace Blizzard Action Bar 1 and Multi Action Bars 1–4 with five Action Hero rows.
- Adjust icon size from 70% to 130% independently of each row's overall size, and set bar opacity from 50% to 100%.
- Each enabled action bar has its own precise 75%–175% scale slider in the Action Bars tab. The corner grip still cycles through quick size steps. Bar scale, equipped-item highlight and custom text-size controls use horizontal sliders.
- In Edit Mode, right-click a slot to choose a different display icon or enter a short text label (for example, “Water”). These display overrides are saved per slot in the active profile; the assigned action remains unchanged. Use “Use action icon” to reset to the action’s default icon.
- Text labels can be scaled from 70% to 150%, colored gold/white/cyan/green/red, and shown with an optional dark background for readability.
- The Appearance tab's equipped-item highlight slider adds a gold glow to action slots the client recognizes as equipped items. Set it to Off to disable the glow; the value is saved per profile.
- The equipped-item glow texture is enlarged slightly so its visible border aligns with the full action button instead of appearing as a smaller square inside it.
- The right-click icon option is nested under Edit Mode and appears only while Edit Mode is enabled.
- When Edit Mode is on, a single small gold EDIT MODE badge appears above the first visible Action Hero bar. Hover it for a reminder; it disappears when Edit Mode is off.

Move and snap
- When unlocked, drag the slim strip above a row to move it.
- Shift-click a bar's strip to stack that bar and every higher-numbered bar
  in order (for example, bar 2 stacks bars 2–5).
- Shift-click the same leader again to restore bars to their saved independent positions.
- Drag the selected leader to move its whole stack. Drag a lower bar to split
  the stack above it; that bar and the rows below it stay grouped together.
- Click the corner grip to cycle the row size. Positions save relative to the screen and are reapplied after UI loading.

Bar 1 uses Blizzard's primary action buttons. Bars 2–5 use Multi Action Bars 1–4
(Bottom Left, Bottom Right, Right, Left). They retain normal action slots and
key bindings. Spells are not sorted automatically.

Type /actionhero or /ahero to open settings. Hover over a row's handle to see
its Blizzard key binding group. Copy the ActionHero folder into Interface/AddOns
and reload the UI.

The settings footer includes a small gold RIP Shady memorial.

Custom XP display
In Bottom UI, enable Hide original XP bar. Click Custom XP to cycle through Off, Horizontal bar, Percentage square and Percentage text. Drag the display while action bars are unlocked. Style and position save per profile.
Use Reset to Center beside the selected XP style to place the display at screen center, even when the action bars are locked.
Hover over any custom XP display to see current XP / total XP and your rested XP bonus as an amount and percentage of a full level.
Unlocked bars reveal empty slots while carrying an action, spell or item. Drop onto the slot to assign it. On clients without click passthrough, right-click the small corner star in Edit Mode to customize a slot.

Shift-right-click the minimap icon outside combat to toggle Lock action bars for the active profile.

General > Show flight landing button displays Land at next stop during a flight path. Click it to request the next available landing. Enabled by default.

The purple fill shows earned XP. Yellow shows the available rested bonus up to the level boundary. Hover for the full amount.
