-- Writ This 4.0.2 / WoW Forever (Interface 16001)
-- AC v0.1.8 live name-scan integration: read-only, throttled, scope-checked.
-- Experimental AC vs Auctionator pricing on Writs and Crates (shared switch).
-- Users window: backward-compatible addon version reporting via presence pings.
-- Experimental Tabbed UI: same existing data and legacy panel internals,
-- hosted as seven switchable pages; Classic is still the default and reversible.
-- v3.4.3: Multi-Screen option defaults on; when disabled, use a single Writ This
-- screen with Back/Escape navigation, X closes all screens; only setting saved.
-- v3.1.0 diagnostics: searchable command console and live owned-AH ID audit.
-- v3.1.0 posting stability: match owned auctions to nonbanked copies; select
-- correct bag loss during simultaneous transfers; retry owned-list queries
-- after posting; allow explicit false Posted correction without fake loss.
-- v3.1.0: Read-only Auctionator v1 cached-price lookup for crate materials.
-- Unit quote x quantity = estimated fill cost; rank cheapest KNOWN bundle.
-- Price/Favor for confirmed rewards only. No Auction House scans/purchases,
-- Auctionator data writes, WritTrackerDB migration, or extra events.
-- v3.4.2: Safe merchant scanner learns item IDs from actual Merchant's Favor
-- vendors (known NPCs, exact catalog names), auto-scans on vendor open/update
-- and offers a manual Scan Open Trader button. Saved per character; scanned
-- item IDs power native vendor tooltips without altering static Favor prices,
-- crafted-item IDs, stock estimates, AH or existing tracking. Supports modern
-- C_MerchantFrame plus legacy merchant API safely; no automatic purchases.
-- v3.4.1: Verified IDs for all 28 Alchemy vendor recipes and their 28
-- crafted consumables; 29th Alchemy certification was already mapped.
-- No vendor visit needed. Other professions remain partial until mapped.
-- v3.4.0: Native tooltip previews for Merchant's Favor Traders: toggle
-- Crafted Item / Vendor Recipe, verified item IDs, asynchronous item loading,
-- Shift-hover alternate mode, modest item icons, and clear unknown-ID fallback.
-- No guessed IDs, AH access, purchases, or SavedVariables changes.
-- v3.3.0: Read-only Merchant's Favor vendor shop: 316 unique profession
-- entries and 4 specials, both factions, search and cached-native item hover.
-- v3.3.0: No Auctionator, Winner, writ-tracking or sync logic changes.
-- v3.3.6: Sold Writs is now a writ-only resale ledger. Profit uses actual
-- net AH proceeds minus writ acquisition and known lost posting deposits.
-- Material purchases, missing material prices, and later item resale are
-- excluded; old sold records remain unchanged and totals recalculate on view.
-- Show Writ Paid, Sale (net), Posts and Result; preserve estimation warnings.
-- v3.3.5: Sold Writs separates verified, estimated and combined net;
-- flags incomplete/unpriced records, unknown deposits and zero-post sales.
-- Distinct writ/item expense columns, explicit estimated profit/loss labels,
-- and an all-in calculation explanation. Display-only; no record changes.
-- v3.3.4: Coin Pouch burst guard. Match each bag loss and independent wallet
-- gain before auto-archiving; never merge rapid uses into one 0.5s click.
-- Multiple quick openings, coalesced money events, or mismatched signals are
-- logged as needing manual confirmation, rather than guessing per-writ payouts.
-- Single confirmed pouch payout remains automatic. No changes to saved orders.
-- v3.3.3: Separate AH scan/cache timestamps into a compact right-aligned
-- two-line column above crate details; resize-safe hover hitboxes prevent
-- overlaps with the crate title and price counters. No data/price changes.
-- v3.3.2: Read Auctionator Forever's saved TimeOfLastBrowseScan when
-- available; older Auctionator global full-scan timestamp remains a fallback.
-- Distinguish browse scan from full scan and never treat cache reads or
-- price-database callbacks as proof of a completed AH scan. No pricing changes.
-- v3.3.1: Readable price coverage row, separate small cache-read and optional
-- global AH scan timestamps, with contextual hover explanations.
-- v3.3.1: Winner tooltip separates empty crate and material cache ages.
-- UI only: no changes to price lookups, freshness rules, Winner ranking,
-- saved data, inventory/quest tracking, or Auctionator behavior.
-- v3.2.1: Recheck local Auctionator quotes every 5m while Waylaid Crates is open.
-- v3.2.1: 30s manual refresh cooldown, 2m visual clock updates, optional
-- Auctionator price-database update callback, distinct global last AH scan.
-- v3.2.1: Missing quotes still never enter the Winner calculation; no old-price
-- fallback, AH requests, Auctionator DB writes, or SavedVariables changes.
-- v3.2.0: Separate minute/hour cache-check clock from Auctionator whole-day per-item age.
-- v3.2.0: Crate/filled-bundle quote freshness indicators (Auctionator whole days).
-- v3.2.0: Waylaid Winner efficiency banner, copyable Discord text, resizeable crate window.
-- v3.1.0: Waylaid Crates reference next to Reputation: all 30 documented
-- crate variants, alternative material bundles, reported Merchant's Favor,
-- level requirements, faction turn-in NPCs and independent search/filters.
-- Artisan Favor remains UNCONFIRMED rather than inventing a payout.
-- Reference only: no crate purchase monitoring, inventory changes or rep math.
-- v3.0.1: Mail Warning is tied to the actual visible MailFrame. Parenting
-- prevents the warning remaining onscreen after closing mail even when the
-- client omits MAIL_CLOSED; the saved Settings checkbox remains authoritative.
-- This is a UI-only fix: auction sale, invoices, and mail scanning are unchanged.
-- v3.0 release safety: Items & Locations Missing Only filter; explicit
-- confirm dialogs for Reset and reference saves; zone changes invalidate old
-- coordinates without altering the built-in catalog or personal history.
-- v3.0 UI: Reputation window is resizable, with persistent Show Chart toggle.
-- v3.0 UI: Rep Chart now shows live Durotar Supply and Logistics rep,
-- next-rank remaining rep, and rounded-up Journeyman/Expert/Artisan requirements.
-- Rep Chart popup retains fixed guide reputation/writ requirements;
-- Send Data moved to Settings without altering community transfer behavior.
-- v3.0 UI: Exclusive supplemental windows: showing Settings, Items & Locations,
-- v3.0.0 purchase verification: reconcile required-item price against the
-- buyer's actual invoice (correct stack count), while preserving manual edits.
-- Posted list shows writ + unrefunded/lost posting deposits, NOT materials.
-- Sold Log continues to account for recorded required-item expenses.
-- Missing filters by UNKNOWN ZONE only.
-- Sold Log, Rep Chart, Users or an editor automatically closes any other
-- supplemental panel without changing records, filters or SavedVariables.
-- v3.0.0 mail reconciliation: retry unreadable buyer invoices, never consume
-- unmatched receipt signatures, and match repeated same-item purchases once.
-- v3.0.0 main UI: persisted Details checkbox beside Keybinds; turning it
-- off hides only the selected-writ details, uses a separately remembered
-- compact window height, and gives the active/posted list more row space.
-- v3.0.0 manual Coin Pouch recovery: Shift+Middle on an awaiting-payout
-- writ requests the ACTUAL payout and confirms before archiving that record.
-- No fabricated payout, no change to automatic pouch completion detection.
-- Track AH purchases, buyer invoices, sealed -> opened replacements, and bag arrivals.
-- Tracking is always active; Start on Login controls the window only.
-- v1.9: guard purchased writ costs across mailbox arrivals, match by name when
-- a custom client exposes different item IDs, and Shift-click individual delete.
-- Mail invoice entries with unreliable prices cannot override confirmed AH costs.
-- v2.0: allocate at most one required item to each writ, at the actual UNIT
-- price when an AH lot/commodity purchase contains multiple items. Buyer mail
-- verifies that allocation instead of charging again. Extra purchases are not
-- silently attributed to the writ (they may be for personal use).
-- v2.1: separate Items & Locations reference book, searchable and sortable,
-- sourced from the existing static location catalog. Does not alter tracking.
-- v2.2: quest completion => pending pouch => payout => archive + measured stats.
-- Coin Pouch is item 284584; only a confirmed use / bag loss followed by
-- wallet gain can archive a completion. Missing payouts remain pending.
-- Costs / reputation accumulate in Items & Locations to compare writs and zones.
-- v2.3: mini location/item view, Alt+Shift-click manual bag import,
-- manual item/zone Coin Pouch observations, clear economics, /writ command.
-- v2.3.1: label negative net averages as positive PROFIT in the Info Book.
-- v2.4: per-reference completed-run log; safe one-click player coordinate capture
-- in the editor; clean, high-contrast separators between reference detail rows.
-- v2.5: colored Profit/Cost in reference rows, a manual writ/item/rep editor,
-- improved delayed commodity AH capture, and mini bag-ready indicators.
-- v2.5.1: item-name aliases for writ orders whose text differs from the
-- actual auction item (e.g., Ogre's Strength vs Ogre Strength).
-- v2.6: acquired-order numbered active writ list with aligned item/source/
-- TOTAL cost/reputation/zone columns. The shown total is blank/None until
-- both writ and required-item costs are verified.
-- v2.7: clear, stacked Active/Completed header; recorded Total Costs include
-- known writ + required-item spending (active and archived), and Total Profit
-- shows recorded Coin Pouches less those costs, negative while still invested.
-- No SavedVariables changes or migrations; preserve all existing data.
-- v2.7.5: Active / Posted list switch; confirmed posted writs leave the
-- active task list until returned or sold. Listed state remains in original
-- records. Show currently incurred writ + item costs (even when an item has
-- not yet been purchased). The rest of tracking, archiving and DB are unchanged.
-- v2.9.2: persisted Show Details checkbox for Items & Locations. Collapsed
-- reference panel gives more room to the catalog, without touching saved runs,
-- shared snapshots, costs, sales or any other tracked data.
-- v2.7.4: rescan older active writs using a correctly re-owned hidden bag
-- tooltip, improved font-string parsing, and /writ tierscan diagnostics.
-- v2.7.3: read Journeyman/Expert/Artisan directly from opened writ item
-- tooltips and automatically derive 75/125/200 reputation, even when the
-- named writ was purchased directly rather than opened from a sealed writ.
-- v2.9.5: Collect All batch-sale settlement (including mixed mail when verifiable);
-- optional non-blocking mailbox reminder to collect writ sales individually.
-- Shift+right-click manual sale recovery.
-- Shift+left-click remains confirmed deletion; retired sold entries are reconciled
-- out of Active/Posted without changing saved acquisition costs.
-- v2.9.4: native draggable minimap launcher. Left-click toggles Writ This,
-- right-click toggles Items & Locations. Angle persists in the existing DB.
-- Keeps the existing WritTrackerDB SavedVariablesPerCharacter database.
-- v2.9.6: per-active-writ Map button opens the matched world-map zone;
-- shows a native user waypoint when verified coordinates are present.
-- No map data is guessed; unknown zones or coordinates remain unmarked.
-- v2.9.7: Existing and future writ locations use personal Items & Locations
-- coordinates immediately. On confirmed quest turn-in, missing coordinates are
-- captured from the character's actual zone-map position, saved to the personal
-- reference book, and reused the next time the same writ is acquired.
-- Never overwrite verified coordinates or capture on a manual completion.
-- Banked writs remain active and preserve their IDs/prices; bank deposits do
-- not masquerade as sealed openings and withdrawals never create duplicates.
-- All previous writ, sale, pouch, syncing and settings data is unchanged.
-- v2.9.7 login duplicate guard: reconcile existing bags to the saved orders
-- during the loading window instead of treating stale cross-login item-count
-- differences as acquisitions. Does not delete or rewrite cost/history data.
-- v2.9.8: Mini-mode turn-in zones are clickable map links. Click an available
-- zone to open the same map and saved waypoint used by the full-screen Map
-- button. No new SavedVariables and no change to purchase/completion logic.
-- v3.0: Expand Items & Locations from 99 to 150 writs, with published
-- Forever-specific turn-in coordinates and no unknown-coordinate guesses.
-- No database migrations: user-entered locations and costs stay authoritative.
-- v2.9.9: Items & Locations now has per-row Map buttons in both Items
-- and Zones views. Reuses the native map/verified-waypoint launcher; never
-- guesses missing coordinates. Only one unambiguous matching active writ
-- takes completion-cleanup ownership. Reference-only pins are kept separate.
-- v2.9.8 waypoint cleanup: remove only the native waypoint Writ This last
-- placed for a writ when THAT writ is successfully turned in. Verify the
-- current native waypoint still matches before clearing; leave user waypoints
-- and other writ markers alone. Manual completion never clears a waypoint.
-- v2.9.8 detected-users counter: show nearby Writ This addon users (self +
-- recently heard guild/party/raid peers) next to ACTIVE on the main window.
-- Lightweight presence pings use the existing addon prefix, no user statistics
-- are sent, and there are no SavedVariables or version changes.
-- v2.9.8 community sync: Send Data broadcasts to BOTH guild and group, and
-- to explicitly connected online whisper peers; /writ send player Name can
-- reach another Writ This installation outside your guild. A WoW Forever
-- Classic addon cannot broadcast to all server installs via custom channels.
-- Personal saved writs, costs, sale history and settings remain untouched.
-- v2.9.9: Users counter remains a 5-minute active estimate. Hovering shows
-- all-time distinct addon users discovered by this character (including self),
-- persisted across reloads. A sender is recorded only after a real addon
-- presence/sync message; previous saved community senders seed that history.
-- v2.9.9: real Settings panel with a persisted Show Commands checkbox.
-- v2.9.9 UI polish: larger Morpheus title, login/mail preferences in Settings,
-- Mini beside Send Data, and clickable active/all-time character name list.
-- v2.9.9 main-header cleanup: aligned, large Active / Posted / Completed
-- counters; compact acquisition / cost / profit row; no noisy shortcut line.
-- Settings > Show Keybinds lists verified mouse shortcuts (off by default),
-- with an optional one-click shortcut from the main header.
-- Scrollable, grouped reference lists the full /writ command set, including
-- sync/friends, item corrections, window modes and diagnostics. /writ commands
-- (or /writ help) opens that reference; no tracking/sync behavior is changed.
-- v2.9.8 friends sync: discover online character friends via tiny addon
-- presence whispers (only Writ This replies). Send Data includes confirmed
-- friend users across guilds without direct re-sends to people already covered
-- by guild/party/raid. The user count includes discovered friend addon users.
-- Discovery is paced; full data still sends only when Send Data is pressed.

local addonName = ...
local DB, window, settings, itemsBook, miniWindow, pouchEditor, referenceLog, orderEditor
local selectedID, page = nil, 1
local bagBefore, auctionCache, pendingBid, recentConfirmed = {}, {}, {}, {}
-- Bank transfers are location changes, never new purchases, loot, or openings.
local BankGuard={open=false,prior=nil,pendingAt=nil,loginSettling=false,loginUntil=0}
local WritBatch={} -- sealed-writ lot quantity handling and conservative legacy repair
local pendingSuccess, sealedActions, sealedLossConsumed, bagSlotIDs = {}, {}, {}, {}
local lastMoney = nil
local openedQueue, sealedUseAt, lootHints = {}, {}, {}
local confirmedItems = {}
local mailOpen = false
local ahOpen = false
local pendingCommodity = nil
local pendingItemEvents = {}
local rows = {}
local bookRows = {}
local bookPage, bookSort, bookQuery, bookSelected = 1, 'location', '', nil
local bookRefresh
local community={} -- opt-in, read-only shared aggregate reference statistics
local pouchBagCount, scanPouchChanges, archivePouch, finishWrit, onPouchUse, findRecentLostWrit
local POUCH_REP={[284584]=75,[284585]=125,[284586]=200}
local lastPouchCount=0
local pouchUses={}
rows.pouchGains={} -- separate wallet events; one gain is NOT proof of multiple payouts
rows.pouchLastActivity=0
local recentPouchGains={}
local questScreen=nil
local pendingTurnIn=nil
local recentFactionGain=nil
local bookMode='items'
local bookEditor
local deleteWrit, requestDeleteWrit
local pendingDeleteID, pendingDeleteAt = nil, nil
local refresh, scanChanges, miniRefresh, setMiniMode, parseMoney, openPouchEditor
local VERSION='4.0.2'
local miniRows, miniPage = {}, 1
local bagClickHooked=false
local lastPouchEditorSubmit=nil
local BASE_W, BASE_H = 690, 565
local SEALS = {
  [248206] = {"Sealed Craftsman's Writ", nil},
  [262887] = {"Sealed Apprentice's Writ", nil},
  [262888] = {"Sealed Journeyman's Writ", 75},
  [262889] = {"Sealed Expert's Writ", 125},
  [262890] = {"Sealed Artisan's Writ", 200},
}
-- Sealed writ tier comes from the originally acquired envelope. Preserve it
-- when it is replaced by a named writ (the opened writ has a different item ID).
local SEAL_TIERS = {
  [248206] = "Craftsman's",
  [262887] = 'Apprentice',
  [262888] = 'Journeyman',
  [262889] = 'Expert',
  [262890] = 'Artisan',
}
local function writTier(e)
  if not e then return 'Unknown' end
  local sealID = e.sealedItemID or (e.sealed and e.itemID)
  return (sealID and SEAL_TIERS[tonumber(sealID)]) or e.tooltipTier
end
local function writOrigin(e)
  local tier=writTier(e)
  if tier then return tier..' Writ' end
  if e.wasSealed then return 'Opened sealed writ (tier unknown)' end
  return 'Already-opened writ'
end
local function reputationLabel(e)
  if e.repNeedsReview or not tonumber(e.rep) then
    return 'Unknown (use /writ rep 75, 125, or 200)'
  end
  return tostring(math.floor(tonumber(e.rep)))..' rep'
end
local SKINS = {
  default = {name='Original',
    bg={0.025,0.033,0.043,0.92},
    header={0.045,0.06,0.078,0.84},
    edge={0.22,0.31,0.40,1},
    text={0.88,0.92,0.96},
    button={.055,.067,.082,.92},
  },
  wow = {name='Vanilla WoW',
    bg={0.105,0.070,0.032,0.97},
    header={0.175,0.105,0.035,0.94},
    edge={0.58,0.40,0.15,1},
    text={0.94,0.90,0.80},
    button={.105,.068,.028,.96},
    backdrop={bgFile='Interface\\DialogFrame\\UI-DialogBox-Background-Dark',edgeFile='Interface\\DialogFrame\\UI-DialogBox-Border',
      tile=true,tileSize=32,edgeSize=24,insets={left=8,right=8,top=8,bottom=8}},
  },
  authenticvanilla = {name='Authentic Vanilla (Exp)',
    bg={0.36,0.29,0.20,0.97},
    header={0.15,0.105,0.052,0.97},
    edge={0.88,0.67,0.33,1},
    text={1.00,0.87,0.57},
    button={.17,.10,.035,.97},
    backdrop={bgFile='Interface\\DialogFrame\\UI-DialogBox-Background-Dark',edgeFile='Interface\\DialogFrame\\UI-DialogBox-Border',
      tile=true,tileSize=32,edgeSize=28,insets={left=10,right=10,top=10,bottom=10}},
  },
  classicstone = {name='Classic Stone (Exp)',
    bg={0.57,0.55,0.50,0.98},
    header={0.12,0.11,0.09,0.96},
    edge={0.80,0.63,0.33,1},
    text={0.99,0.87,0.59},
    button={.16,.14,.10,.96},
    backdrop={bgFile='Interface\\FrameGeneral\\UI-Background-Rock',edgeFile='Interface\\DialogFrame\\UI-DialogBox-Border',
      tile=true,tileSize=128,edgeSize=24,insets={left=8,right=8,top=8,bottom=8}},
  },
  classicleather = {name='Classic Leather (Exp)',
    bg={0.68,0.56,0.39,0.98},
    header={0.18,0.12,0.065,0.97},
    edge={0.81,0.58,0.28,1},
    text={0.99,0.86,0.56},
    button={.19,.12,.055,.97},
    backdrop={bgFile='Interface\\DialogFrame\\UI-DialogBox-Background',edgeFile='Interface\\DialogFrame\\UI-DialogBox-Border',
      tile=true,tileSize=32,edgeSize=24,insets={left=8,right=8,top=8,bottom=8}},
  },
  tooltipframe = {name='Tooltip Frame (Exp)',
    bg={0.10,0.10,0.15,0.97},
    header={0.07,0.065,0.10,0.97},
    edge={0.57,0.51,0.72,1},
    text={0.94,0.91,0.99},
    button={.09,.085,.14,.97},
    backdrop={bgFile='Interface\\Tooltips\\UI-Tooltip-Background',edgeFile='Interface\\Tooltips\\UI-Tooltip-Border',
      tile=true,tileSize=16,edgeSize=16,insets={left=5,right=5,top=5,bottom=5}},
  },
  nightfall = {name='Nightfall',
    bg={0.020,0.015,0.035,0.96},
    header={0.070,0.044,0.105,0.96},
    edge={0.42,0.30,0.62,1},
    text={0.92,0.89,0.99},
    button={.084,.052,.126,.95},
  },
  wowlook = {name='WoW Experimental',
    bg={0.51,0.42,0.31,0.98},
    header={0.105,0.077,0.045,0.98},
    edge={0.80,0.60,0.28,1},
    text={0.94,0.83,0.60},
    button={.090,.061,.030,.98},
    backdrop={bgFile='Interface\\DialogFrame\\UI-DialogBox-Background-Dark',edgeFile='Interface\\DialogFrame\\UI-DialogBox-Border',
      tile=true,tileSize=32,edgeSize=28,insets={left=9,right=9,top=9,bottom=9}},
  },
}
local function clock() return GetTime and GetTime() or 0 end
local function datetime() return date and date('%Y-%m-%d %H:%M:%S') or '' end
local function trim(s) return tostring(s or ''):match('^%s*(.-)%s*$') end
-- Capture Writ This's own chat, debug and diagnostic output in a persistent,
-- searchable console. This does not intercept anyone else's chat messages.
rows.consoleAdd=function(kind,message)
  if not DB then return end
  local entries=DB.consoleLog or {};DB.consoleLog=entries
  local stamp=datetime()
  local first=entries[1]
  -- Common rapid duplicate callbacks are counted rather than flooding the log.
  if first and first.kind==kind and first.message==tostring(message) and first.at==stamp then
    first.repeatCount=(first.repeatCount or 1)+1
  else
    table.insert(entries,1,{at=stamp,kind=kind,message=tostring(message)})
    while #entries>300 do table.remove(entries) end
  end
  rows.consoleDirty=true
end
local function say(s)
  if rows.consoleAdd then rows.consoleAdd('CHAT',s) end
  if DEFAULT_CHAT_FRAME and not (DB and DB.muteRegularChat) then DEFAULT_CHAT_FRAME:AddMessage('|cFFFFD477Writ This|r  '..tostring(s)) end
end
local function debugMessage(message)
  if not DB then return end
  DB.debugLog=DB.debugLog or {}
  table.insert(DB.debugLog,1,datetime()..'  '..message)
  while #DB.debugLog>80 do table.remove(DB.debugLog) end
  if rows.consoleAdd then rows.consoleAdd('DEBUG',message) end
  -- Avoid double-logging debug messages by writing chat directly here.
  if DB.debugEnabled and DEFAULT_CHAT_FRAME then
    DEFAULT_CHAT_FRAME:AddMessage('|cFFFFD477Writ This|r  [debug] '..tostring(message))
  end
end
local function fmtMoney(v)
  v=math.max(0, math.floor((tonumber(v) or 0)+.5))
  return string.format('%dg %02ds %02dc',math.floor(v/10000),math.floor(v%10000/100),v%100)
end
local function fmtNetMoney(v)
  v=tonumber(v) or 0
  return (v<0 and '-' or '')..fmtMoney(math.abs(v))
end
local function skin() return SKINS[(DB and DB.skin) or 'wow'] or SKINS.wow end
local function namedItem(raw)
  if not raw then return nil end
  local linked=tostring(raw):match('|h%[([^%]]+)%]|h')
  return trim(linked or raw)
end
local function idFromLink(link)
  return tonumber(tostring(link or ''):match('|Hitem:(%d+)') or tostring(link or ''):match('|h%[.*%]|h.*item:(%d+)'))
end
local function getName(id)
  if not id then return nil end
  local name
  if C_Item and C_Item.GetItemInfo then
    local ok,result=pcall(C_Item.GetItemInfo,id)
    if ok then name=result end
  end
  if not name and GetItemInfo then
    local ok,result=pcall(GetItemInfo,id)
    if ok then name=result end
  end
  return name
end
-- An already-opened Craftsman's Writ has its rank on the item tooltip
-- (e.g. a line reading 'Journeyman'), even though the item name has no tier.
-- Keep one hidden tooltip to inspect actual item links/bag slots. The live
-- visible tooltip is also hooked because some Forever/TSM links arrive before
-- the local item cache is populated. Do NOT infer rank from item level/rarity.
-- The table and helpers live in one scoped local to respect WoW's Lua local
-- variable limit in this large single-file addon.
local TIER = (function()
  local obj={cache={},rep={Journeyman=75,Expert=125,Artisan=200}}
  local function isNamedWrit(name)
    local n=trim(namedItem(name)):lower()
    return n:match('^craftsman.s writ:%s*')~=nil
  end
  local function fontText(tt,line)
    if not tt or not tt.GetName then return nil end
    local name=tt:GetName()
    if not name or name=='' then return nil end
    local fs=(_G and _G[name..'TextLeft'..line]) or
      (getglobal and getglobal(name..'TextLeft'..line))
    return fs and fs.GetText and fs:GetText() or nil
  end
  -- Forever's rank line may be on either tooltip column, and some clients
  -- expose the text through regions rather than the named TextLeft fields.
  -- Only call this on a confirmed writ; ordinary items must not gain tiers.
  local function parseTier(raw)
    local txt=trim(raw):lower():gsub('|c%x%x%x%x%x%x%x%x',''):gsub('|r','')
    txt=trim(txt:gsub('[\r\n\t]',' '))
    if txt=='journeyman' or txt:match('^tier:%s*journeyman%s*$') then return 'Journeyman' end
    if txt=='expert' or txt:match('^tier:%s*expert%s*$') then return 'Expert' end
    if txt=='artisan' or txt:match('^tier:%s*artisan%s*$') then return 'Artisan' end
    return nil
  end
  function obj.read(tt)
    if not tt then return nil end
    if tt.NumLines then
      for i=1,math.min(tonumber(tt:NumLines()) or 0,20) do
        local tier=parseTier(fontText(tt,i))
        if tier then return tier end
        -- Item tooltips may put metadata on the right rather than left.
        local name=tt.GetName and tt:GetName()
        local fs=name and ((_G and _G[name..'TextRight'..i]) or
          (getglobal and getglobal(name..'TextRight'..i)))
        tier=parseTier(fs and fs.GetText and fs:GetText())
        if tier then return tier end
      end
    end
    if tt.GetRegions then
      local regions={tt:GetRegions()}
      for _,region in ipairs(regions) do
        if region and region.GetText and
          (not region.IsObjectType or region:IsObjectType('FontString')) then
          local tier=parseTier(region:GetText())
          if tier then return tier end
        end
      end
    end
    return nil
  end
  local function hiddenTip()
    if obj.tip then return obj.tip end
    if not CreateFrame then return nil end
    local tt=(_G and _G.WritThisRankScanner) or nil
    if not tt then
      local ok,created=pcall(CreateFrame,'GameTooltip','WritThisRankScanner',UIParent,'GameTooltipTemplate')
      if ok then tt=created end
    end
    -- Hide() clears the owner on Classic clients. Do not assume the owner
    -- survives until the next scan; it is reset in peek() every time.
    if tt and tt.Hide then tt:Hide() end
    obj.tip=tt
    return tt
  end
  function obj.peek(id,link,bag,slot)
    id=tonumber(id) or idFromLink(link)
    if id and obj.cache[id] then
      local tier=obj.cache[id]
      return tier,obj.rep[tier]
    end
    local tt=hiddenTip()
    if not tt then return nil end
    -- Crucial: WoW clears the owner when a tooltip is hidden. Older bagged
    -- writs were missed because the reused scanner no longer had an owner.
    if tt.SetOwner then pcall(tt.SetOwner,tt,WorldFrame or UIParent,'ANCHOR_NONE') end
    local tier
    if bag~=nil and slot~=nil and tt.SetBagItem then
      if tt.ClearLines then tt:ClearLines() end
      local ok=pcall(tt.SetBagItem,tt,bag,slot)
      if ok then tier=obj.read(tt) end
    end
    if not tier and tt.SetHyperlink then
      local itemLink=(type(link)=='string' and
        (link:find('|Hitem:',1,true) or link:match('^item:'))) and link or nil
      if not itemLink and id and GetItemInfo then
        local ok,_,cachedLink=pcall(GetItemInfo,id)
        if ok and type(cachedLink)=='string' then itemLink=cachedLink end
      end
      if not itemLink and id then itemLink='item:'..tostring(id) end
      if itemLink then
        if tt.ClearLines then tt:ClearLines() end
        local ok=pcall(tt.SetHyperlink,tt,itemLink)
        if ok then tier=obj.read(tt) end
      end
    end
    -- Custom server item classes sometimes expose the rank as a subtype.
    -- Only trust an exact Journeyman/Expert/Artisan string, not item rarity.
    if not tier and id and GetItemInfo then
      local ok,subType=pcall(function() return select(7,GetItemInfo(id)) end)
      if ok then tier=parseTier(subType) end
    end
    if tt.Hide then tt:Hide() end
    if tier and id then obj.cache[id]=tier end
    return tier,tier and obj.rep[tier] or nil
  end
  function obj.apply(e,tier,source)
    if not e or not tier or not obj.rep[tier] then return false end
    if e.sealed or e.wasSealed or e.sealedItemID then return false end
    local changed=false
    if e.tooltipTier~=tier then e.tooltipTier=tier;changed=true end
    -- A user-entered/confirmed rank is authoritative; only fill blanks.
    if e.repNeedsReview or not tonumber(e.rep) then
      e.rep=obj.rep[tier]
      e.repNeedsReview=false
      e.repSource=source or 'Item tooltip'
      changed=true
    end
    return changed
  end
  function obj.applyToKnown(id,name,tier,source)
    if not DB or not tier then return false end
    local changed=false
    for _,e in ipairs(DB.orders or {}) do
      local match=(id and tonumber(e.itemID)==tonumber(id)) or
        (name and isNamedWrit(name) and trim(e.writ):lower()==trim(namedItem(name)):lower())
      if match and not e.sealed then
        if obj.apply(e,tier,source) then changed=true end
      end
    end
    return changed
  end
  function obj.installHover()
    if obj.hooked or not GameTooltip or not GameTooltip.HookScript then return end
    local ok=pcall(GameTooltip.HookScript,GameTooltip,'OnTooltipSetItem',function(tt)
      if not DB then return end
      local itemName,itemLink
      if tt.GetItem then
        local got,n,l=pcall(tt.GetItem,tt)
        if got then itemName=n;itemLink=l end
      end
      if not isNamedWrit(itemName) then
        local title=fontText(tt,1)
        if isNamedWrit(title) then itemName=title end
      end
      if not isNamedWrit(itemName) then return end
      local tier=obj.read(tt)
      if not tier then return end
      local id=idFromLink(itemLink)
      if id then obj.cache[id]=tier end
      if obj.applyToKnown(id,itemName,tier,'Visible item tooltip') and refresh then
        refresh(true)
      end
    end)
    obj.hooked=ok
  end
  return obj
end)()
local function recognize(id, raw)
  id=tonumber(id)
  if SEALS[id] then return SEALS[id][1],SEALS[id][2],true end
  -- The container/mail index can change between separate client reads.
  -- A link for another item cannot establish the identity of this slot.
  local linkID=type(raw)=='string' and raw:find('|Hitem:',1,true) and idFromLink(raw)
  if id and linkID and id~=linkID then raw=nil end
  local name=namedItem(raw)
  local official=getName(id)
  -- Forever/Auctionator occasionally exposes a short search-result label
  -- (e.g. "Fine Leather Pants") for an item whose real name is
  -- "Craftsman's Writ: Fine Leather Pants". Trust the actual item ID/name.
  if official and (official:lower():match("^craftsman's writ:") or
                   official:lower():match('^craftsmans writ:')) then
    local _,rep=TIER.peek(id,raw)
    return official,rep,false
  end
  -- An explicit full writ name in the actual auction/mail item link also
  -- identifies the writ, even if Forever's item-info cache resolves the
  -- item ID to a different display name. A plain required-item name alone
  -- must never turn into a writ without a matching full name or sealed ID.
  if name and (name:lower():match("^craftsman's writ:") or
               name:lower():match('^craftsmans writ:')) then
    local _,rep=TIER.peek(id,raw)
    return name,rep,false
  end
  return nil
end
-- The named writ's suffix names the required AH item in normal writ orders.
-- Keep it separate from the original envelope item ID and buyout price.
local function requiredItemName(e)
  if not e or e.sealed then return nil end
  local name=e.requiredName or e.item
  if type(name)=='string' and name~='' and name:sub(1,1)~='(' then
    return trim(name)
  end
  return trim((e.writ or ''):match("^[Cc]raftsman'?s [Ww]rit:%s*(.+)$") or '')~='' and
    trim((e.writ or ''):match("^[Cc]raftsman'?s [Ww]rit:%s*(.+)$")) or nil
end
-- v3.0: All 150 WoW Forever crafting writs (Forever XP / client 1.60.1).
-- v3.0 zone coverage pass: add sourced zones/NPCs and verified/reported waypoints.
-- Do not invent coordinates for unconfirmed customers. Personal overrides still win.
-- Published Questie Forever turn-in coords are included where available;
-- deliberately unknown NPCs/zones have no invented pins.
-- Personal bookOverrides always take priority over built-in map data.
-- The existing Goblin Rocket Fuel zone conflict is held for verification.
-- This catalog never changes purchases, writ data, saved runs, or prices.
local WRIT_LOCATIONS = {
  ['advanced target dummy'] = {'Desolace', 'Bibbly F\'utzbuckle', 62.3, 39},
  ['arcanite skeleton key'] = {'Unknown', nil},
  ['azure silk hood'] = {'Ashenvale', 'Cowardly Peon', 78.5, 68.9},
  ['barbaric gloves'] = {'Thousand Needles', 'Goblin Pit Boss', 79.9, 76.7},
  ['big bronze bomb'] = {'Thousand Needles', 'Razzeric', 80.3, 76.1},
  ['big bronze knife'] = {'Thousand Needles', 'Plucky Johnson', 79.6, 75.6},
  ['big voodoo mask'] = {'Swamp of Sorrows', 'Mukomonji', 62.4, 52.9},
  ['big voodoo robe'] = {'Tanaris', 'Yeh\'kinya', 67, 22.4},
  ['black mageweave vest'] = {'Riverglades', 'Spek', 76.9, 54.1},
  ['blue glittering axe'] = {'Feralas', 'Scout Raroul', 72.4, 52.5},
  ['blue overalls'] = {'Arathi Highlands', 'Alyce', 34.0, 23.3},
  ['catseye draught'] = {'Feralas', 'Scout Raroul', 72.4, 52.5},
  ['catseye ultra goggles'] = {'Feralas', 'Scout Raroul', 72.4, 52.5},
  ['cenarion herb bag'] = {'Unknown', nil},
  ['chimeric vest'] = {'Unknown', nil},
  ['cindercloth robe'] = {'The Hinterlands', 'Atal\'ai Exile'},
  ['colorful kilt'] = {'Stranglethorn Vale', 'Hekshi', 50.7, 19.3},
  ['comfortable leather hat'] = {'Badlands', 'Garek', 61.9, 54.3},
  ['crafted solid shot'] = {'Wetlands', 'Kixxle', 50.2, 37.7},
  ['craftsman\'s monocle'] = {'Dustwallow Marsh', 'The Ravenous', 54.0, 56.5},
  ['crimson silk robe'] = {'Dustwallow Marsh', 'Tabetha', 46.1, 57.1},
  ['dark iron bomb'] = {'Unknown', nil},
  ['dark leather shoulders'] = {'Stranglethorn Vale', 'Narkk', 28.1, 74.4},
  ['dark leather tunic'] = {'Duskwood', 'Kzixx', 81.8, 19.8},
  ['darkrune gauntlets'] = {'Unknown', nil},
  ['distilled firewater'] = {'Winterspring', 'Bor\'dorc'},
  ['draught of detect demon'] = {'Deadwind Pass', 'Hastings', 47, 75},
  ['draught of water breathing'] = {'Wetlands', 'Kixxle', 50.2, 37.7},
  ['dreamless sleep potion'] = {'Blasted Lands', 'Kum\'isha the Collector', 52, 35},
  ['dusky bracers'] = {'Dustwallow Marsh', 'The Ravenous', 54, 56.5},
  ['earthen silk belt'] = {'Un\'Goro Crater', 'Petra Grossen', 43.7, 7.2},
  ['ebon shiv'] = {'Unknown', nil},
  ['elixir of agility'] = {'The Hinterlands', 'Juo', 80.1, 55.4},
  ['elixir of defense'] = {'Thousand Needles', 'Rizzle Brassbolts', 77.2, 77.4},
  ['elixir of lesser agility'] = {'Stonetalon Mountains', 'Ziz Fizziks', 59.0, 62.6},
  ['elixir of ogre\'s strength'] = {'Alterac Mountains', 'Sos\'mol', 38.3, 61.1},
  ['elixir of wisdom'] = {'Arathi Highlands', 'Muggol Breezebeard', 48.6, 55.8},
  ['enchanted mageweave pouch'] = {'Felwood', 'Impsy', 41.4, 45},
  ['explosive sheep'] = {'Arathi Highlands', 'Alyce', 34.0, 23.3},
  ['felcloth boots'] = {'Unknown', nil},
  ['field repair bot 74a'] = {'Unknown', nil},
  ['fine leather pants'] = {'Arathi Highlands', 'Alyce', 34.0, 23.3},
  ['fire goggles'] = {'Searing Gorge', 'Durganon', 41.1, 58.3},
  ['fire protection potion'] = {'Searing Gorge', 'Durganon', 41.1, 58.3},
  ['flash bomb'] = {'Riverglades', 'Spek', 76.9, 54.1},
  ['flask of chromatic resistance'] = {'Unknown', nil},
  ['free action potion'] = {'Hillsbrad Foothills', 'Webbed Mudsnout Gnoll', 62.4, 69.2},
  ['frost protection potion'] = {'Badlands', 'Lotwil Veriatus', 25.9, 44.9},
  ['frostsaber boots'] = {'Unknown', nil},
  ['ghostweave vest'] = {'Unknown', nil},
  ['gift of arthas'] = {'Eastern Plaguelands', 'Adon'},
  ['gnomish alarm-o-bot'] = {'Unknown', nil},
  ['gnomish universal remote'] = {'Stranglethorn Vale', 'Scooty', 27.6, 77.5},
  ['goblin jumper cables xl'] = {'Unknown', nil},
  ['goblin land mine'] = {'Felwood', 'Jessir Moonbow', 51.4, 82},
  ['goblin rocket fuel'] = {'Tanaris', 'Alchemist Pestlezugg', 50.9, 27},
  ['golden rod'] = {'Arathi Highlands', 'Muggol Breezebeard', 48.6, 55.8},
  ['golden scale coif'] = {'Riverglades', 'Spek', 76.9, 54.1},
  ['golden scale gauntlets'] = {'The Hinterlands', 'Gilveradin Sunchaser', 26.7, 48.5},
  ['gordok ogre suit'] = {'Unknown', nil},
  ['great rage potion'] = {'Moonglade', 'Dendrite Starblaze', 56.2, 30.6},
  ['greater adept\'s robe'] = {'Thousand Needles', 'Magus Tirth', 78.3, 75.7},
  ['greater fire protection potion'] = {'Unknown', nil},
  ['green iron boots'] = {'Wetlands', 'Kixxle', 50.2, 37.7},
  ['green iron gauntlets'] = {'Stranglethorn Vale', 'Sea Wolf MacKinley', 27.8, 77.1},
  ['green lens'] = {'Unknown', nil},
  ['guardian cloak'] = {'Desolace', 'Azore Aldamort', 38.9, 27.2},
  ['gyromatic micro-adjuster'] = {'Tanaris', 'Jhordy Lapforge', 52.3, 26.9},
  ['heavy bronze mace'] = {'Hillsbrad Foothills', 'Gorgrash', 80.0, 48.5},
  ['heavy leather ball'] = {'Alterac Mountains', 'Sos\'mol', 38.3, 61.1},
  ['heavy mithril axe'] = {'Un\'Goro Crater', 'Torwa Pathfinder'},
  ['heavy quiver'] = {'Stonetalon Mountains', 'Ziz Fizziks', 59.0, 62.6},
  ['heavy scorpid helm'] = {'Unknown', nil},
  ['herbalist\'s gloves'] = {'Ashenvale', 'Murache', 64.8, 80.2},
  ['huge thorium battleaxe'] = {'Unknown', nil},
  ['imperial plate chest'] = {'Unknown', nil},
  ['inlaid mithril cylinder'] = {'Desolace', 'Bibbly F\'utzbuckle', 62.3, 39},
  ['iridescent hammer'] = {'Ashenvale', 'Cowardly Peon', 78.5, 68.9},
  ['lesser invisibility potion'] = {'Desolace', 'Centaur Pariah', 50.4, 86.7},
  ['lesser mana potion'] = {'Ashenvale', 'Ash\'alari', 60.2, 72.7},
  ['lesser stoneshield potion'] = {'Dustwallow Marsh', 'Mudcrush Durtfeet', 35.1, 38.3},
  ['lesser troll\'s blood elixir'] = {'Stranglethorn Vale', 'Short John Mithril', 29.6, 47.4},
  ['lesser wizard\'s robe'] = {'Alterac Mountains', 'Alan Sneeks', 30.6, 61},
  ['lifelike mechanical toad'] = {'Unknown', nil},
  ['limited invulnerability potion'] = {'Unknown', nil},
  ['mageweave bag'] = {'Badlands', 'Rigglefuzz'},
  ['major rejuvenation potion'] = {'Unknown', nil},
  ['mana potion'] = {'Riverglades', 'Spek', 76.9, 54.1},
  ['masterwork target dummy'] = {'Unknown', nil},
  ['mechanical dragonling'] = {'Badlands', nil},
  ['mechanical repair kit'] = {'The Hinterlands', 'Rhapsody Shindigger', 26.9, 48.6},
  ['minor recombobulator'] = {'Duskwood', 'Kzixx', 81.8, 19.8},
  ['mithril frag bomb'] = {'Swamp of Sorrows', 'Bullets Bigblast', 70, 41.6},
  ['mithril spurs'] = {'Deadwind Pass', nil},
  ['moonsight rifle'] = {'Ashenvale', 'Grembly', 82.1, 51},
  ['moonsteel broadsword'] = {'Moonglade', 'Meliri'},
  ['nature protection potion'] = {'Felwood', 'Greta Mosshoof', 51.2, 82.1},
  ['nightscape shoulders'] = {'Searing Gorge', 'Evonice Sootsmoker', 38.4, 27.7},
  ['orange martial shirt'] = {'Swamp of Sorrows', 'Bullets Bigblast', 70, 41.6},
  ['orcish war leggings'] = {'Unknown', nil},
  ['ornate mithril shoulders'] = {'Felwood', 'Taronn Redfeather'},
  ['ornate spyglass'] = {'Alterac Mountains', 'Alan Sneeks', 30.6, 61},
  ['pearl-handled dagger'] = {'Alterac Mountains', 'Alan Sneeks', 30.6, 61},
  ['phoenix pants'] = {'Alterac Mountains', 'Bath\'rah the Windwatcher', 80.5, 66.9},
  ['pilferer\'s gloves'] = {'Hillsbrad Foothills', 'Kris Legace', 80.1, 38.9},
  ['potion of demonslaying'] = {'Azshara', 'Archmage Xylem', 29.2, 40.2},
  ['practice lock'] = {'Hillsbrad Foothills', 'Gorgrash', 80.0, 48.5},
  ['quickdraw quiver'] = {'Moonglade', 'Narianna', 53.3, 42.7},
  ['radiant belt'] = {'Blasted Lands', 'Kum\'isha the Collector', 52, 35},
  ['radiant circlet'] = {'Unknown', nil},
  ['red mageweave pants'] = {'Searing Gorge', 'Lookout Captain Lolo Longstriker', 37.7, 26.6},
  ['red whelp gloves'] = {'Wetlands', 'Kixxle', 50.2, 37.7},
  ['red woolen boots'] = {'Stonetalon Mountains', 'Ziz Fizziks', 59.0, 62.6},
  ['rough bronze leggings'] = {'Stonetalon Mountains', 'Ziz Fizziks', 59.0, 62.6},
  ['runecloth bag'] = {'Blasted Lands', 'Kum\'isha the Collector', 52, 35},
  ['runecloth boots'] = {'Burning Steppes', 'Gorzeeki Wildeyes', 12.5, 31.6},
  ['runic leather bracers'] = {'Western Plaguelands', 'Fallen Adventurer'},
  ['runic leather headband'] = {'Deadwind Pass', 'Hastings', 47, 75},
  ['shadow goggles'] = {'Stonetalon Mountains', 'Ziz Fizziks', 59.0, 62.6},
  ['shadow oil'] = {'Swamp of Sorrows', 'Mukomonji', 62.4, 52.9},
  ['shadow protection potion'] = {'Duskwood', 'Kzixx', 81.8, 19.8},
  ['shadoweave gloves'] = {'Desolace', 'Willow'},
  ['shadoweave mask'] = {'Silithus', 'Hermit Ortell'},
  ['shadoweave robe'] = {'Felwood', 'Eridan Bluewind'},
  ['silver skeleton key'] = {'Duskwood', 'Battered Trunk', 26.3, 36.2},
  ['small silk pack'] = {'Duskwood', 'Kzixx', 81.8, 19.8},
  ['sniper scope'] = {'Unknown', nil},
  ['solid sharpening stone'] = {'Searing Gorge', 'Master Smith Burninate', 38.8, 28.5},
  ['soul pouch'] = {'Winterspring', nil},
  ['spider silk slippers'] = {'Wetlands', 'Kixxle', 50.2, 37.7},
  ['star belt'] = {'Moonglade', 'Mylentha Riverbend'},
  ['steel plate helm'] = {'Badlands', 'Furious Shadowforge Digger', 44.3, 11.4},
  ['steel weapon chain'] = {'Dustwallow Marsh', 'Ugbert', 41.0, 27.9},
  ['swift boots'] = {'Riverglades', 'Spek', 76.9, 54.1},
  ['thick leather ammo pouch'] = {'Un\'Goro Crater', 'Nergal', 43.3, 7.7},
  ['tranquil mechanical yeti'] = {'Unknown', nil},
  ['truesilver rod'] = {'Tanaris', 'Spigot Operator Luglunket', 52.5, 28.4},
  ['truesilver transformer'] = {'Silithus', 'Khur Hornstriker'},
  ['turtle scale breastplate'] = {'The Hinterlands', 'Juo', 80.1, 55.4},
  ['tuxedo jacket'] = {'Deadwind Pass', 'Hastings', 47, 75},
  ['unstable trigger'] = {'Moonglade', 'Narianna', 53.3, 42.7},
  ['volcanic breastplate'] = {'Unknown', nil},
  ['white bandit mask'] = {'Tanaris', 'Vizzklick', 51, 27.4},
  ['wicked leather bracers'] = {'Eastern Plaguelands', 'Quartermaster Miranda Breechlock'},
  ['wicked leather pants'] = {'Unknown', nil},
  ['wicked mithril blade'] = {'Unknown', nil},
  ['wild leather helmet'] = {'Felwood', 'Ivy Leafrunner', 51, 81.6},
  ['wild leather shoulders'] = {'Feralas', 'Scout Raroul', 72.4, 52.5},
  ['wildvine potion'] = {'Un\'Goro Crater', 'Spark Nilminer', 43.5, 7.4},
  ['wizardweave turban'] = {'Unknown', nil},
}
local function writLocation(e)
  if not e or e.sealed then return 'Not revealed', nil, nil, nil end
  local name=requiredItemName(e)
  if not name then return 'Unknown', nil, nil, nil end
  local key=trim(name):lower():gsub('^craftsman.s writ:%s*','')
  local info=WRIT_LOCATIONS[key]
  -- Items & Locations edits are authoritative for existing AND future writs.
  -- Do not duplicate the reference coordinates into any individual writ record.
  local personal=DB and DB.bookOverrides and DB.bookOverrides[key]
  if not info and not personal then return 'Unknown', nil, nil, nil end
  local zone=(personal and personal.zone) or (info and info[1]) or 'Unknown'
  local npc=personal and personal.npc
  if npc==nil then npc=info and info[2] end
  if npc==false then npc=nil end
  -- false explicitly clears old-zone built-in coordinates when the user moves
  -- a turn-in to another zone. nil means "inherit the catalog's coordinates".
  local x=personal and personal.x
  local y=personal and personal.y
  if x==nil then x=info and info[3] end
  if y==nil then y=info and info[4] end
  return zone,npc,tonumber(x),tonumber(y)
end
-- Turn-in map launcher. Locate the actual zone map from the client's map
-- hierarchy instead of guessing UIMapIDs (Forever has additional custom maps).
-- The lookup is triggered only on user clicking Map and never alters saved data.
do
local turnInMapCache={}
local function turnInMapID(zone)
  local target=trim(zone or ''):lower()
  if target=='' or target=='unknown' or target=='not revealed' then return nil end
  if turnInMapCache[target] then return turnInMapCache[target] end
  if not (C_Map and type(C_Map.GetMapInfo)=='function') then return nil end
  local queue,seen={},{}
  local function enqueue(id)
    id=tonumber(id)
    if id and id>0 and not seen[id] then
      seen[id]=true
      queue[#queue+1]=id
    end
  end
  -- Classic zone continents and the world root. Extra roots are discovered
  -- from the current/fallback world map when the client exposes them.
  enqueue(1414);enqueue(1415);enqueue(947)
  if C_Map.GetFallbackWorldMapID then
    local ok,id=pcall(C_Map.GetFallbackWorldMapID)
    if ok then enqueue(id) end
  end
  if C_Map.GetBestMapForUnit then
    local ok,id=pcall(C_Map.GetBestMapForUnit,'player')
    if ok then enqueue(id) end
  end
  local cursor=1
  while cursor<=#queue and cursor<=3500 do
    local id=queue[cursor];cursor=cursor+1
    local ok,info=pcall(C_Map.GetMapInfo,id)
    if ok and info then
      if type(info.name)=='string' and trim(info.name):lower()==target then
        turnInMapCache[target]=id
        return id
      end
      enqueue(info.parentMapID)
    end
    if type(C_Map.GetMapChildrenInfo)=='function' then
      local childrenOK,children=pcall(C_Map.GetMapChildrenInfo,id,nil,true)
      if not childrenOK or type(children)~='table' then
        childrenOK,children=pcall(C_Map.GetMapChildrenInfo,id)
      end
      if childrenOK and type(children)=='table' then
        for _,child in ipairs(children) do
          if child and type(child.name)=='string' and trim(child.name):lower()==target then
            local childID=tonumber(child.mapID)
            if childID then turnInMapCache[target]=childID;return childID end
          end
          if child then enqueue(child.mapID) end
        end
      end
    end
  end
  return nil
end
-- Track only markers that Writ This itself successfully placed. A user can
-- replace the native waypoint at any time; never clear that replacement.
-- The small fingerprint survives /reload in the existing SavedVariables DB.
local function isOurCurrentWaypoint(owner)
  if not owner or not C_Map or type(C_Map.GetUserWaypoint)~='function' then
    return false
  end
  local ok,point=pcall(C_Map.GetUserWaypoint)
  if not ok or not point or tonumber(point.uiMapID)~=tonumber(owner.mapID) then
    return false
  end
  local position=point.position
  if not position then return false end
  local x,y
  if type(position.GetXY)=='function' then
    local got,a,b=pcall(position.GetXY,position)
    if got then x,y=a,b end
  end
  if x==nil or y==nil then x,y=position.x,position.y end
  x,y=tonumber(x),tonumber(y)
  -- A 0.1 percentage-point tolerance is sufficient for stored map positions.
  return x and y and math.abs(x-(tonumber(owner.x) or -1))<=0.001
                     and math.abs(y-(tonumber(owner.y) or -1))<=0.001
end
rows.clearCompletedWritWaypoint=function(e)
  if not DB or not e then return end
  local owner=DB.writThisWaypoint
  if not owner or tostring(owner.writID)~=tostring(e.id) then return end
  if isOurCurrentWaypoint(owner) and C_Map and
     type(C_Map.ClearUserWaypoint)=='function' then
    local ok=pcall(C_Map.ClearUserWaypoint)
    if ok then debugMessage('Cleared Writ This waypoint for completed writ #'..tostring(e.id)) end
  end
  -- Retire ownership even if the player changed/cleared the marker or their
  -- client does not support waypoint inspection. Do not clear any other pin.
  DB.writThisWaypoint=nil
end
-- A reference-book click may use known zone/coordinates without requiring an
-- active purchased writ. An optional reference entry only supplies map data;
-- it never creates or modifies orders, tracked costs, or saved reference edits.
function rows.openTurnInMap(e,referenceEntry)
  if not e and not referenceEntry then return end
  local zone,npc,x,y
  if referenceEntry then
    zone,npc,x,y=referenceEntry.zone,referenceEntry.npc,referenceEntry.x,referenceEntry.y
  else
    zone,npc,x,y=writLocation(e)
  end
  if not zone or zone=='Unknown' or zone=='Not revealed' then
    say('Turn-in location is not documented for this writ yet.')
    return
  end
  local mapID=turnInMapID(zone)
  if not mapID then
    say('Could not locate the '..zone..' world map in this client. Turn-in zone: '..zone..
      (x and y and string.format(' (%.1f, %.1f)',x,y) or '')..'.')
    return
  end
  if type(InCombatLockdown)=='function' and InCombatLockdown() then
    say('The world map cannot be opened in combat. Try again afterwards.')
    return
  end
  local opened=false
  if C_Map and type(C_Map.OpenWorldMap)=='function' then
    local ok=pcall(C_Map.OpenWorldMap,mapID)
    opened=ok and true or false
  end
  if not opened and WorldMapFrame then
    if not WorldMapFrame:IsShown() and type(ToggleWorldMap)=='function' then
      pcall(ToggleWorldMap)
    end
    if type(WorldMapFrame.SetMapID)=='function' then
      opened=pcall(WorldMapFrame.SetMapID,WorldMapFrame,mapID)
    end
  end
  if not opened then
    say('Could not open '..zone..' world map; please open your map manually.')
    return
  end
  -- Native map marker: optional and only for known, valid coordinates.
  local pin=false
  x,y=tonumber(x),tonumber(y)
  if x and y and x>=0 and x<=100 and y>=0 and y<=100 and (x>0 or y>0)
     and C_Map and type(C_Map.SetUserWaypoint)=='function' then
    local allowed=true
    if type(C_Map.CanSetUserWaypointOnMap)=='function' then
      local ok,result=pcall(C_Map.CanSetUserWaypointOnMap,mapID)
      allowed=ok and result==true
    end
    if allowed then
      local p=nil
      if UiMapPoint and type(UiMapPoint.CreateFromCoordinates)=='function' then
        local ok,result=pcall(UiMapPoint.CreateFromCoordinates,mapID,x/100,y/100)
        if ok then p=result end
      end
      if not p and UiMapPoint and type(UiMapPoint.CreateFromVector2D)=='function'
         and type(CreateVector2D)=='function' then
        local ok,vector=pcall(CreateVector2D,x/100,y/100)
        if ok and vector then
          local ok2,result=pcall(UiMapPoint.CreateFromVector2D,mapID,vector)
          if ok2 then p=result end
        end
      end
      if not p and type(CreateVector2D)=='function' then
        local ok,vector=pcall(CreateVector2D,x/100,y/100)
        if ok then p={uiMapID=mapID,position=vector} end
      end
      if p then
        local ok,result=pcall(C_Map.SetUserWaypoint,p)
        pin=ok and result~=false
        if pin and DB then
          DB.writThisWaypoint={writID=(e and e.id) or ('book:'..tostring(referenceEntry.key)),
            mapID=mapID,x=x/100,y=y/100}
        end
      end
    end
  end
  local label=zone..(npc and (' - '..npc) or '')
  if x and y then
    label=label..string.format(' (%.1f, %.1f)',x,y)
    if not pin then label=label..' [coordinates; no automatic marker]' end
  else
    label=label..' [coordinates not documented]'
  end
  say('Turn-in map: '..label)
end
end -- map helpers have their own local scope (Forever's top-level 200-local limit)

-- Some custom-client mail item links may disagree with the item ID reported by
-- the Auction House. Treat a matching normalized writ name as the same order,
-- without merging a sealed writ with an already-opened writ.
local function writNameKey(raw)
  local name=namedItem(raw)
  if not name then return nil end
  return name:lower():gsub('[%s%c]+',' '):gsub("'",''):gsub('^craftsmans writ:%s*',''):gsub('^%s+',''):gsub('%s+$','')
end
local function sameWritName(a,b)
  local x,y=writNameKey(a),writNameKey(b)
  return x~=nil and x~='' and x==y
end
local function writMatchesRecord(e,id,name,sealed)
  return e and (sealed==nil or (not not e.sealed)==(not not sealed)) and
    ((id and tonumber(e.itemID)==tonumber(id)) or sameWritName(e.writ,name))
end
local function itemKey(raw)
  return trim(raw):lower():gsub('^craftsman.s writ:%s*','')
end
-- Forever writ order text is sometimes not identical to the actual auction
-- item name. Keep only known, specific aliases to avoid matching unrelated items.
-- The *real item name* is used for AH buyout and bag checks; both spellings
-- resolve to the same key without changing the stored item/writ display name.
local REQUIRED_ITEM_ALIASES = {
  ["elixir of ogre strength"] = "elixir of ogre's strength",
}
local function requiredKey(name)
  -- Normalize formatting before resolving a specific known name mismatch.
  local key=trim(name):lower():gsub('’',"'"):gsub('`',"'"):gsub('%s+',' ')
  return REQUIRED_ITEM_ALIASES[key] or key
end
local function sameRequired(a,b)
  if not a or not b then return false end
  return requiredKey(a)==requiredKey(b)
end
local function matchingRequiredEntry(id,name)
  -- Every writ needs ONE required item in the current tracker. Once an item
  -- has been assigned, do not assign a second unit to that writ, even when
  -- another copy is bought or a buyer-mail event fires later.
  local function available(e)
    return e and not e.sealed and not e.complete and
      sameRequired(requiredItemName(e),name) and
      not e.itemCostKnown and not e.itemPriceUnknown and
      (tonumber(e.itemPurchases) or 0)==0
  end
  local chosen
  for _,candidate in ipairs(DB.orders) do
    if candidate.id==selectedID then chosen=candidate;break end
  end
  if available(chosen) then return chosen end
  for i=#DB.orders,1,-1 do
    local e=DB.orders[i]
    if available(e) then return e end
  end
end
local function matchingUnpricedRequiredEntry(id,name,auctionID)
  -- Recover an unfinished purchase that was first reported without its price.
  -- Upgrading that row must not allocate a second item or add another cost.
  for i=#DB.orders,1,-1 do
    local e=DB.orders[i]
    if not e.sealed and not e.complete and e.itemPriceUnknown and
       not e.itemCostKnown and (tonumber(e.itemPurchases) or 0)>0 and
       sameRequired(requiredItemName(e),name) and
       (not e.requiredItemID or not id or tonumber(e.requiredItemID)==tonumber(id)) and
       not e.itemInvoiceKey and
       ((auctionID and e.lastItemAuctionID==auctionID) or
        (not e.lastItemAuctionID and (not e.itemPurchaseAt or clock()-e.itemPurchaseAt<60))) then
      return e
    end
  end
end
local function isRequiredPurchaseName(name)
  if not name or not DB then return false end
  for _,e in ipairs(DB.orders) do
    if not e.sealed and not e.complete and sameRequired(requiredItemName(e),name) then return true end
  end
  return false
end
local function bagID(bag,slot)
  if C_Container and C_Container.GetContainerItemID then return C_Container.GetContainerItemID(bag,slot) end
  if GetContainerItemID then return GetContainerItemID(bag,slot) end
end
local function bagLink(bag,slot)
  if C_Container and C_Container.GetContainerItemLink then return C_Container.GetContainerItemLink(bag,slot) end
  if GetContainerItemLink then return GetContainerItemLink(bag,slot) end
end
local function bagCount(bag,slot)
  if C_Container and C_Container.GetContainerItemInfo then
    local info=C_Container.GetContainerItemInfo(bag,slot)
    return info and (info.stackCount or info.count) or 1
  end
  if GetContainerItemInfo then
    local _,n=GetContainerItemInfo(bag,slot)
    return n or 1
  end
  return 1
end
rows.bagItemIDs={}
rows.bankItemIDs={}
local function bagSnapshot()
  local result={}
  local ids={}
  local unresolved={}
  rows.bagItemIDs=ids
  rows.bagInfoScanAt=nil
  for b=0,(NUM_BAG_SLOTS or 4) do
    local slots=0
    if C_Container and C_Container.GetContainerNumSlots then slots=C_Container.GetContainerNumSlots(b) or 0
    elseif GetContainerNumSlots then slots=GetContainerNumSlots(b) or 0 end
    for s=1,slots do
      local id=bagID(b,s)
      bagSlotIDs[tostring(b)..':'..tostring(s)]=id
      if id then
        ids[id]=true
        local link=bagLink(b,s)
        local name,rep,sealed=recognize(id,link)
        if name then
          if not sealed then
            local tier,readRep=TIER.peek(id,link,b,s)
            if readRep then rep=readRep end
            if tier then TIER.applyToKnown(id,name,tier,'Bag tooltip') end
          end
          local e=result[id] or {name=name,count=0,rep=rep,sealed=sealed}
          local ignored=false
          if not sealed and C_Item and C_Item.GetItemGUID and ItemLocation and ItemLocation.CreateFromBagAndSlot then
            local location=ItemLocation:CreateFromBagAndSlot(b,s)
            local ok,guid=pcall(C_Item.GetItemGUID,location)
            if ok and type(guid)=='string' and guid~='' then
              ignored=DB.ignoredWritGUIDs and DB.ignoredWritGUIDs[guid]
              if not ignored then
                e.guids=e.guids or {}
                e.guids[#e.guids+1]=guid
              end
            else
              unresolved[id]=true
            end
          end
          if not ignored then
            e.count=e.count+(sealed and (tonumber(bagCount(b,s)) or 1) or 1)
            result[id]=e
          end
        end
      end
    end
  end
  for id in pairs(unresolved) do
    local prior=bagBefore and bagBefore[id]
    local needsIdentity=prior and prior.guids
    if not needsIdentity then
      for _,ignoredID in pairs(DB.ignoredWritGUIDs or {}) do
        if ignoredID==id then needsIdentity=true;break end
      end
    end
    if needsIdentity then
      result[id]=prior
      rows.bagInfoScanAt=clock()+1
    end
  end
  return result
end
-- Read only the bank containers while the character bank is open. Bank
-- contents are not part of the ordinary carried-bag snapshot: comparing the
-- two identifies true deposits/withdrawals without inventing new writ records.
BankGuard.snapshot=function()
  local counts={}
  local ids={}
  rows.bankItemIDs=ids
  if not BankGuard.open then return counts end
  local function readBag(b, fallback)
    local slots=0
    if C_Container and C_Container.GetContainerNumSlots then
      slots=tonumber(C_Container.GetContainerNumSlots(b)) or 0
    elseif GetContainerNumSlots then
      slots=tonumber(GetContainerNumSlots(b)) or 0
    end
    if slots==0 and fallback then slots=fallback end
    for slot=1,slots do
      local id=bagID(b,slot)
      if id then
        ids[id]=true
        local name,_,sealed=recognize(id,bagLink(b,slot))
        if name then counts[id]=(counts[id] or 0)+(sealed and math.max(1,tonumber(bagCount(b,slot)) or 1) or 1) end
      end
    end
  end
  readBag(BANK_CONTAINER or -1,NUM_BANKGENERIC_SLOTS or 24)
  local start=(NUM_BAG_SLOTS or 4)+1
  for b=start,start+(NUM_BANKBAGSLOTS or 7)-1 do readBag(b) end
  return counts
end
BankGuard.schedule=function()
  if BankGuard.open then BankGuard.pendingAt=clock()+0.28 end
end
-- Force a fresh tooltip read for every tracked opened writ already in bags.
-- This updates only tier/rep on existing rows; it never creates a new writ,
-- changes costs, or touches completed / sold records.
function TIER.rescanBags(report)
  if not DB then return end
  local bagged,identified,changed=0,0,0
  local missing={}
  for b=0,(NUM_BAG_SLOTS or 4) do
    local slots=0
    if C_Container and C_Container.GetContainerNumSlots then
      slots=C_Container.GetContainerNumSlots(b) or 0
    elseif GetContainerNumSlots then
      slots=GetContainerNumSlots(b) or 0
    end
    for slot=1,slots do
      local id=bagID(b,slot)
      if id then
        local link=bagLink(b,slot)
        local name,_,sealed=recognize(id,link)
        if not name then
          -- Existing AH records can have an ID/name differing from a fresh
          -- GetItemInfo result. Prefer the known writ, never a required item.
          for _,e in ipairs(DB.orders) do
            if not e.complete and not e.sealed and
              (tonumber(e.itemID)==tonumber(id) or tonumber(e.openedItemID)==tonumber(id)) then
              name=e.writ;break
            end
          end
        end
        if name and not sealed and TIER.peek then
          bagged=bagged+1
          local tier=TIER.peek(id,link,b,slot)
          if tier then
            identified=identified+1
            if TIER.applyToKnown(id,name,tier,'Bag tier rescan') then changed=changed+1 end
          elseif #missing<4 then
            missing[#missing+1]=name..' (bag '..b..', slot '..slot..')'
          end
        end
      end
    end
  end
  if changed>0 and refresh then refresh(true) end
  if report then
    say('Tier rescan: '..identified..' / '..bagged..' bagged writs recognized; '..changed..' existing records updated.')
    if #missing>0 then
      for _,name in ipairs(missing) do say('Tier not readable: '..name) end
      say('If still Unknown, hover the writ in your bags, then run /writ tierscan again.')
    end
  end
  return bagged,identified,changed
end
local function entryByID(recordID)
  for _,e in ipairs(DB.orders) do if e.id==recordID then return e end end
end
local function selected() return selectedID and entryByID(selectedID) or nil end
local function addLog(kind,e,description)
  DB.log=DB.log or {}
  table.insert(DB.log,1,{time=datetime(),kind=kind,name=e and e.writ or '',id=e and e.id or nil,note=description or ''})
  while #DB.log>500 do table.remove(DB.log) end
end
-- Reuse an existing writ record when a matching banked copy comes back.
-- Never relabel a bank withdrawal as Loot/Collected or charge it twice.
BankGuard.withdraw=function(id,item,guid)
  local chosen=nil
  for _,e in ipairs(DB.orders or {}) do
    if not e.complete and not e.sold and not e.resaleSold and
       not e.resaleListed and not e.bagPresent and
       (not guid or not e.bagGUID or e.bagGUID==guid) and writMatchesRecord(e,id,item.name,item.sealed) then
      if guid and e.bagGUID==guid then chosen=e;break end
      if e.banked and (not chosen or not chosen.banked) then chosen=e end
      if not chosen then chosen=e end
    end
  end
  if not chosen then
    debugMessage('Ignored untracked bank withdrawal '..tostring(item.name)..' (no matching saved writ)')
    return nil
  end
  chosen.bagGUID=guid or chosen.bagGUID
  chosen.bagPresent=true
  chosen.banked=false
  chosen.writLostAt=nil
  chosen.sealLostAt=nil
  addLog('BANK WITHDRAW',chosen,'Bank withdrawal; original cost and record preserved')
  return chosen
end
deleteWrit=function(id)
  local e,index
  for i=#DB.orders,1,-1 do
    if DB.orders[i].id==id then e=DB.orders[i];index=i;break end
  end
  if not e then return end
  if e.acquired=='Auction House' and not e.bagPresent and not e.complete then
    DB.deletedMailWrits=DB.deletedMailWrits or {}
    table.insert(DB.deletedMailWrits,{itemID=e.itemID,writ=e.writ,at=time and time() or 0})
  end
  if e.bagGUID then
    DB.ignoredWritGUIDs=DB.ignoredWritGUIDs or {}
    DB.ignoredWritGUIDs[e.bagGUID]=e.itemID or true
    local old=bagBefore and bagBefore[e.itemID]
    for i,guid in ipairs(old and old.guids or {}) do
      if guid==e.bagGUID then
        table.remove(old.guids,i)
        old.count=old.count-1
        if old.count==0 then bagBefore[e.itemID]=nil end
        break
      end
    end
  elseif not e.sealed and e.itemID and e.bagPresent and bagBefore[e.itemID] then
    local represented=0
    for _,other in ipairs(DB.orders) do
      if other~=e and other.itemID==e.itemID and other.bagPresent and not other.complete then
        represented=represented+1
      end
    end
    DB.ignoredBagCounts=DB.ignoredBagCounts or {}
    local old=DB.ignoredBagCounts[e.itemID] or 0
    local physical=bagBefore[e.itemID].count
    if physical>represented+old then DB.ignoredBagCounts[e.itemID]=old+1 end
  end
  addLog('DELETE',e,'Manually removed with Shift-click')
  table.remove(DB.orders,index)
  if selectedID==id then selectedID=nil;DB.selectedID=nil end
  pendingDeleteID=nil;pendingDeleteAt=nil
  if refresh then refresh() end
  say('Deleted one record: '..tostring(e.writ)..'. Other writs were not affected.')
end
requestDeleteWrit=function(id)
  local e=entryByID(id)
  if not e then return end
  if StaticPopupDialogs and StaticPopup_Show then
    if not StaticPopupDialogs.WRITTHIS_DELETE_CONFIRM then
      StaticPopupDialogs.WRITTHIS_DELETE_CONFIRM={
        text='Delete this writ from Writ This?\n%s',button1='Delete',button2='Cancel',
        OnAccept=function(_, recordID) deleteWrit(recordID) end,
        timeout=0,whileDead=true,hideOnEscape=true,preferredIndex=3,
      }
    end
    StaticPopup_Show('WRITTHIS_DELETE_CONFIRM',e.writ,nil,id)
  elseif pendingDeleteID==id and clock()-(pendingDeleteAt or 0)<8 then
    deleteWrit(id)
  else
    pendingDeleteID=id;pendingDeleteAt=clock()
    say('Shift-click '..tostring(e.writ)..' again within 8 seconds to confirm deletion.')
  end
end
local function markWrit(id,name,rep,sealed,source,price,received,reason)
  if not DB then return nil end
  DB.nextID=(DB.nextID or 0)+1
  local purchased=source=='Auction House'
  local e={id=DB.nextID,itemID=id,writ=name,rep=rep or 75,repNeedsReview=rep==nil,
    sealed=sealed,createdAt=datetime(),createdEpoch=(time and time() or 0),purchaseSession=DB.session or 1,
    acquired=source,source=source,bagPresent=received==true,
    writCost=price or 0,itemCost=0,itemCostKnown=false,itemPriceUnknown=false,priceUnknown=(purchased and price==nil) or source=='Found in bags' or source=='Collected',
    item=sealed and '(open to reveal)' or trim(name:match("^[Cc]raftsman'?s [Ww]rit:%s*(.+)$") or '') ,complete=false,priceSource=(price~=nil and source=='Auction House') and 'AH event' or nil}
  table.insert(DB.orders,e)
  if not sealed then
    local tier=TIER.peek(id,name)
    if tier then TIER.apply(e,tier,'Acquisition item tooltip') end
  end
  selectedID=e.id
  addLog('ACQUIRE',e,reason or source)
  if refresh then refresh(true) end
  return e
end
-- The auction purchase may precede delivery to the mailbox by several minutes.
-- Mark the AH record as awaiting bag arrival, so mail pickup does NOT duplicate it.
local function purchaseRecord(id,name,rep,sealed,cost,quantity,auctionID,kind)
  -- Sealed envelopes can be bought as a multi-item Auction House lot.
  -- Named/opened writs stay ONE record per auction so erroneous client
  -- quantity fields cannot recreate the old duplicate-opened-writ bug.
  local reportedQty=math.floor(tonumber(quantity) or 1)
  if sealed and SEALS[tonumber(id)] and reportedQty>=2 and reportedQty<=200 then
    quantity=reportedQty
    debugMessage('Writ batch purchase '..tostring(quantity)..'x '..tostring(name)..
      ' auction='..tostring(auctionID)..' full price='..tostring(cost))
  else
    quantity=1
    if reportedQty>1 then
      debugMessage('Ignored ambiguous named-writ quantity '..tostring(reportedQty)..
        ' for auction '..tostring(auctionID))
    end
  end
  local total=cost and math.max(0,math.floor(cost)) or nil
  for i=1,quantity do
    local part=total and (math.floor(total/quantity)+(i<=total%quantity and 1 or 0)) or nil
    local e
    -- ITEM_PURCHASED can arrive before auction-completed, briefly producing
    -- a PRICE? placeholder. Upgrade it in place rather than logging two buys.
    if auctionID then
      for j=#DB.orders,1,-1 do
        local candidate=DB.orders[j]
        local age=(time and time() or 0)-(tonumber(candidate.createdEpoch) or 0)
        if candidate.acquired=='Auction House' and candidate.priceUnknown and
           not candidate.auctionID and not candidate.mailInvoiceKey and
           writMatchesRecord(candidate,id,name,sealed) and age>=0 and age<=180 then
          e=candidate
          break
        end
      end
    end
    if e then
      if part then e.writCost=part;e.priceUnknown=false;e.priceSource='AH event' end
      e.auctionID=auctionID;e.itemID=id or e.itemID
      if not sealed then TIER.apply(e,TIER.peek(id,name),'AH item tooltip') end
      addLog('AH PRICE',e,'Confirmed buyout upgraded existing pending purchase')
    else
      e=markWrit(id,name,rep,sealed,'Auction House',part,false,kind or 'Successful buyout')
      e.auctionID=auctionID
    end
    if quantity>1 then
      e.purchaseBatchQuantity=quantity
      e.purchaseBatchTotal=total
      e.purchaseBatchIndex=i
      e.purchaseBatchAuctionID=auctionID
    end
  end
  say(quantity..'x '..name..' purchased. '..(total and
    ('Lot total '..fmtMoney(total)..(quantity>1 and ' (allocated per envelope)' or '')) or
    'Price unavailable; marked None'))
end
-- Keep a single required-item allocation per writ, rather than a running
-- sum of every auction win for that item. More than one copy may be bought for
-- personal use. The event price for an AH lot is the WHOLE lot, so only one
-- item's proportional (per-unit) price belongs to this writ.
local function unitPrice(total,quantity)
  if total==nil then return nil end
  local qty=math.max(1,math.min(200,math.floor(tonumber(quantity) or 1)))
  return math.floor(math.max(0,tonumber(total) or 0)/qty+0.5)
end
-- Pre-invoice AH figures may be inaccurate on the Forever client. Retain
-- them only as internal reconciliation clues until the buyer invoice arrives.
-- An intentional manual price edit is immediately authoritative.
rows.itemPricePending=function(e)
  return e and e.itemAwaitingMail==true and not e.itemInvoiceKey and
    not e.itemManual and (tonumber(e.itemPurchases) or 0)>0
end
local function recordRequiredPurchase(id,name,paid,auctionID,reason,quantity)
  if not DB then return nil end
  if recognize(id) then
    debugMessage('Rejected required-item purchase: item ID '..tostring(id)..' is actually a writ')
    return nil
  end
  if auctionID then
    DB.requiredAuctionSeen=DB.requiredAuctionSeen or {}
    local key=tostring(auctionID)
    if DB.requiredAuctionSeen[key] then
      debugMessage('Already handled required-item auction '..key..' / '..tostring(name))
      return nil
    end
    DB.requiredAuctionSeen[key]=true
  end
  local e=matchingUnpricedRequiredEntry(id,name,auctionID) or matchingRequiredEntry(id,name)
  if not e then
    debugMessage('Unassigned extra item purchase (personal/duplicate): '..tostring(name)..
      ' qty='..tostring(quantity or 1)..' total='..tostring(paid))
    return nil
  end
  local price=unitPrice(paid,quantity)
  if price~=nil then
    -- Assignment or price upgrade, never cumulative charge.
    e.itemCost=price
    e.itemCostKnown=true
    e.itemPriceUnknown=false
    e.itemPriceSource=reason or 'AH event'
  elseif not e.itemCostKnown then
    e.itemPriceUnknown=true
  end
  e.requiredItemID=id or e.requiredItemID
  e.requiredName=requiredItemName(e) or name
  e.itemPurchases=1
  e.itemPurchaseAt=clock()
  e.itemPurchaseEpoch=e.itemPurchaseEpoch or (time and time() or 0)
  -- Keep the invoice confirmation pending even when the client supplied no
  -- auction ID (some commodity/early events omit it). Only buyer mail or an
  -- explicit manual correction closes this pending allocation.
  if auctionID then e.lastItemAuctionID=auctionID end
  e.itemAwaitingMail=true
  e.itemInvoiceKey=nil
  e.itemBoughtQuantity=math.max(1,math.floor(tonumber(quantity) or 1))
  addLog('ITEM BUY',e,(reason or 'AH purchase')..' '..tostring(name)..
    ' | one item allocated at '..(price and fmtMoney(price) or 'None')..
    ((e.itemBoughtQuantity>1) and (' from a lot of '..e.itemBoughtQuantity) or ''))
  debugMessage('One required item assigned to #'..e.id..' '..tostring(name)..
    ' itemPrice='..tostring(price)..' boughtQty='..tostring(quantity or 1))
  if type(reason)=='string' and reason:find('^Buyer mail invoice') and price then
    say('Required item for '..e.writ..': '..fmtMoney(price)..' (buyer invoice verified)')
  else
    say('Required item for '..e.writ..': Price Pending (buyer invoice required)')
  end
  if refresh then refresh(true) end
  return e
end
local function resolveCommodityPurchase()
  local p=pendingCommodity
  if not p or not p.succeeded or not p.paid or not DB then return end
  local name=getName(p.id)
  if name and isRequiredPurchaseName(name) then
    recordRequiredPurchase(p.id,name,p.paid,nil,'Confirmed commodity purchase',p.quantity)
  else
    debugMessage('Commodity purchase had no matching writ: '..tostring(p.id))
  end
  pendingCommodity=nil
end
local function matchRequiredMailInvoice(id,name,paid,invoiceKey,quantity)
  if recognize(id) then
    debugMessage('Skipped material invoice because item ID is a named writ: '..tostring(id))
    return nil
  end
  -- The buyer invoice's paid amount and actual attachment count determine
  -- the REQUIRED UNIT PRICE. A wallet-confirmed AH TOTAL does not validate a
  -- listing quantity: Forever may show 18 available units even when the
  -- purchased attachment contains one. Preserve any conflict in the audit log
  -- rather than rejecting the verified invoice. Manual edits always win.
  local price=unitPrice(paid,quantity)
  local candidates={}
  for i=1,#DB.orders do
    local e=DB.orders[i]
    if e.itemAwaitingMail and not e.itemInvoiceKey and not e.complete and
       not e.sold and not e.resaleSold and
       sameRequired(requiredItemName(e),name) then
      candidates[#candidates+1]=e
    end
  end
  -- Never consume a mailbox receipt when its price cannot yet be read.
  -- Forever may populate the invoice later than its attachment/header.
  if price==nil then
    debugMessage('Material buyer invoice awaiting readable paid amount: '..tostring(name))
    return nil
  end
  local chosen
  if #candidates==1 then
    chosen=candidates[1]
  elseif #candidates>1 then
    -- First match the authoritative invoice to a UNIQUE equal provisional
    -- price. If Forever gave bogus provisional prices for all copies, use
    -- acquisition order as a stable fallback instead of leaving all pending.
    -- Note the fallback for audit: the client exposes no reliable transaction
    -- ID tying an attachment to an individual same-item AH order.
    local same,found=0,nil
    for _,e in ipairs(candidates) do
      if e.itemCostKnown and not e.itemPriceUnknown and
         tonumber(e.itemCost)==price then
        same=same+1;found=e
      end
    end
    if same==1 then chosen=found end
    if not chosen then
      table.sort(candidates,function(a,b)
        local at,bt=tonumber(a.itemPurchaseEpoch),tonumber(b.itemPurchaseEpoch)
        if at and bt and at~=bt then return at<bt end
        return (tonumber(a.id) or 0)<(tonumber(b.id) or 0)
      end)
      chosen=candidates[1]
      debugMessage('Same-item invoice '..tostring(name)..' matched oldest pending writ #'..
        tostring(chosen.id)..' of '..tostring(#candidates)..
        ' (AH transaction-to-mail ID unavailable)')
      addLog('ITEM MAIL ORDER MATCH',chosen,'Oldest pending required-item allocation for '..
        tostring(name)..'; '..tostring(#candidates)..' candidates')
    end
  end
  if chosen then
    local e=chosen
    e.itemInvoiceKey=invoiceKey
    e.itemAwaitingMail=false
    local oldPrice=tonumber(e.itemCost)
    if price~=nil and not e.itemManual then
      if e.itemPriceVerifiedWallet and e.itemCostKnown and oldPrice~=price then
        -- The wallet verified the entire AH debit, NOT an item-unit split.
        -- This case caused 38s45c / listed quantity 18 => bogus 2s14c.
        addLog('ITEM PRICE CONFLICT',e,'Provisional wallet/listing estimate '..
          fmtMoney(oldPrice or 0)..' differed from attached buyer invoice '..
          fmtMoney(price)..'; accepting verified invoice for '..tostring(name))
        e.itemPriceWalletEstimate=oldPrice
        e.itemPriceVerifiedWallet=false
      end
      e.itemCost=price
      e.itemCostKnown=true
      e.itemPriceUnknown=false
      e.itemPriceSource='Buyer invoice (paid)'
      if oldPrice~=nil and oldPrice~=price then
        addLog('ITEM PRICE FIX',e,'Corrected '..tostring(name)..' from '..
          fmtMoney(oldPrice)..' to buyer invoice '..fmtMoney(price))
        debugMessage('Corrected material #'..tostring(e.id)..
          ' from '..tostring(oldPrice)..' to invoice '..tostring(price))
      end
    elseif price and e.itemManual and oldPrice~=price then
      debugMessage('Preserved manual required-item price for #'..tostring(e.id)..
        '; incoming invoice paid='..tostring(price))
    elseif price==nil and not e.itemManual then
      -- Invoice was found but did not expose a trustworthy amount.
      -- Keep the old provisional cost for diagnostics, not for display.
      e.itemPriceUnknown=true
      e.itemPriceSource='Buyer invoice missing amount: VERIFY'
      addLog('ITEM PRICE PENDING',e,'Buyer invoice lacked a usable price; manual verification required')
    end
    addLog('ITEM MAIL',e,'Buyer invoice for '..tostring(name)..
      ' | '..(price and fmtMoney(price) or 'price unavailable')..
      (e.itemManual and ' (manual correction preserved)' or ''))
    if refresh then refresh(true) end
    return e
  end
  -- No priced match: do not force a receipt onto a different order.
  -- Older unpriced acquisitions may lack the awaiting-mail marker. Recover
  -- only a unique pending entry; do not create a second purchase or charge.
  local pending=matchingUnpricedRequiredEntry(id,name,nil)
  if not pending then
    for _,e in ipairs(DB.orders) do
      if not e.sealed and not e.complete and not e.itemManual and
         e.itemPriceUnknown and not e.itemCostKnown and
         (tonumber(e.itemPurchases) or 0)>0 and not e.itemInvoiceKey and
         sameRequired(requiredItemName(e),name) then
        if pending then pending=false;break end
        pending=e
      end
    end
  end
  if pending then
    if price~=nil then
      pending.itemCost=price;pending.itemCostKnown=true;pending.itemPriceUnknown=false
      pending.itemPriceSource='Buyer invoice (paid)'
    elseif not pending.itemManual then
      pending.itemPriceUnknown=true
      pending.itemPriceSource='Buyer invoice missing amount: VERIFY'
    end
    pending.itemInvoiceKey=invoiceKey
    pending.itemAwaitingMail=false
    addLog('ITEM MAIL',pending,'Recovered missing required-item price from buyer mail')
    if refresh then refresh(true) end
    return pending
  end
  -- Genuine mail-only purchase: assign one required item to one writ.
  local e=recordRequiredPurchase(id,name,paid,nil,'Buyer mail invoice (no AH event)',quantity)
  if e then
    e.itemInvoiceKey=invoiceKey;e.itemAwaitingMail=false
    if price then
      e.itemPriceSource='Buyer invoice (paid)'
    elseif not e.itemManual then
      e.itemPriceUnknown=true
      e.itemPriceSource='Buyer invoice missing amount: VERIFY'
    end
  end
  return e
end
-- A manually removed awaiting-mail purchase must not be re-imported by its
-- same buyer invoice or the subsequent bag pickup. One tombstone per copy.
local function matchingDeletedReceipt(id,name)
  if not DB then return nil end
  local now=time and time() or 0
  for i=#(DB.deletedMailWrits or {}),1,-1 do
    local d=DB.deletedMailWrits[i]
    if now>0 and d.at and now-d.at>7*86400 then
      table.remove(DB.deletedMailWrits,i)
    elseif (id and d.itemID==id) or sameWritName(d.writ,name) then
      return i
    end
  end
end
local function consumeDeletedReceipt(id,name)
  local index=matchingDeletedReceipt(id,name)
  if index then table.remove(DB.deletedMailWrits,index);return true end
  return false
end
-- The Forever client exposes actual buyer invoice data for auction-winning mail.
-- This does NOT rely on Auctionator's market estimates or on Blizzard's purchase
-- event being delivered to the addon. Only known buyer invoices are accepted.
local function matchMailInvoice(id,name,rep,sealed,price,quantity,invoiceKey)
  -- A sealed writ attachment may itself contain multiple envelopes. A named
  -- writ stays one per attachment; an ambiguous invoice count must not create
  -- multiple opened-writ records.
  quantity=(sealed and SEALS[tonumber(id)]) and
    math.max(1,math.min(200,math.floor(tonumber(quantity) or 1))) or 1
  local total=price and math.max(0,math.floor(tonumber(price))) or nil
  local matched=0
  for i=1,quantity do
    local part=total and (math.floor(total/quantity)+(i<=total%quantity and 1 or 0)) or nil
    local e
    -- First pair invoices with AH-event records still awaiting mail.
    for j=#DB.orders,1,-1 do
      local c=DB.orders[j]
      if c.acquired=='Auction House' and not c.mailInvoiceKey and
         not c.complete and writMatchesRecord(c,id,name,sealed) then
        e=c;break
      end
    end
    -- The mailbox may have delivered the item before invoice data was ready.
    -- Recover that very same record rather than adding another AH purchase.
    if not e then
      for j=#DB.orders,1,-1 do
        local c=DB.orders[j]
        if not c.mailInvoiceKey and not c.complete and not c.openedAt and c.priceUnknown and
           (c.acquired=='Collected' or c.acquired=='Found in bags' or c.acquired=='Loot') and
           writMatchesRecord(c,id,name,sealed) then
          e=c;break
        end
      end
    end
    if e then
      local old=e.writCost
      if part and (e.priceUnknown or e.priceSource=='Mail invoice' or old==1) then
        e.writCost=part
        e.priceUnknown=false
        e.priceSource='Mail invoice (paid)'
      elseif part and not e.priceUnknown and tonumber(old) and old~=part and
             not e.priceVerifiedWallet and e.priceSource~='Manual edit' and
             e.priceSource~='Manual correction' then
        -- Two apparent purchase prices conflict. Retain the old amount for
        -- audit, but NEVER silently present either as confirmed spending.
        e.priceUnknown=true
        e.priceSource='AH/invoice price conflict: VERIFY'
        addLog('PRICE CONFLICT',e,'AH '..fmtMoney(old)..' versus buyer invoice '..fmtMoney(part))
        debugMessage('Writ price conflict #'..tostring(e.id)..' AH='..tostring(old)..' invoice='..tostring(part))
      end
      e.acquired='Auction House';e.source='Auction House'
      if not sealed then TIER.apply(e,TIER.peek(id,name),'Mail item tooltip') end
      e.mailInvoiceKey=invoiceKey
      if quantity>1 then
        e.purchaseBatchQuantity=e.purchaseBatchQuantity or quantity
        e.purchaseBatchTotal=e.purchaseBatchTotal or total
        e.purchaseBatchIndex=e.purchaseBatchIndex or i
      end
      addLog('INVOICE',e,'Buyer invoice matched; paid '..(part and fmtMoney(part) or 'not known'))
      debugMessage('Mail matched #'..e.id..' price='..tostring(part)..' old='..tostring(old))
      matched=matched+1
    elseif part and part>1 and not matchingDeletedReceipt(id,name) then
      -- Only a trustworthy, nontrivial paid amount may create an AH record.
      -- Bad 1-copper / missing invoices must never create an extra PRICE?
      -- writ when the confirmed auction purchase already has a known price.
      e=markWrit(id,name,rep,sealed,'Auction House',part,false,'Buyer mail invoice (AH event not seen)')
      e.mailInvoiceKey=invoiceKey
      e.priceSource='Mail invoice (paid)'
      if quantity>1 then
        e.purchaseBatchQuantity=quantity
        e.purchaseBatchTotal=total
        e.purchaseBatchIndex=i
      end
      matched=matched+1
      debugMessage('Mail created #'..e.id..' '..name..' paid='..tostring(part))
    else
      debugMessage('Ignored unpriced or deleted buyer invoice for '..tostring(name)..' (already purchased or no reliable price)')
    end
  end
  if matched>0 then
    say('Auction mail: '..matched..'x '..name..' | '..(total and fmtMoney(total) or 'None'))
    if refresh then refresh(true) end
  end
  return matched>0
end
-- Legacy batch repair: older versions treated an entire sealed-writ lot as
-- one purchase, then created extra unpriced Collected records on mailbox pickup.
-- Never guess a batch size. On startup require saved evidence of the old AH
-- quantity event; a manual repair command is available when that evidence aged
-- out of the 80-line diagnostics buffer.
do
  local function sealOf(e)
    if not e then return nil end
    return tonumber(e.sealedItemID) or (e.sealed and tonumber(e.itemID) or nil)
  end
  local function possibleExtras(anchor)
    local results={}
    local seal=sealOf(anchor)
    if not seal or not SEALS[seal] then return results end
    for _,row in ipairs(DB.orders or {}) do
      local epoch=tonumber(row.createdEpoch) or 0
      local start=tonumber(anchor.createdEpoch) or 0
      if row~=anchor and sealOf(row)==seal and row.priceUnknown and
         (row.acquired=='Collected' or row.acquired=='Found in bags') and
         not row.complete and not row.resaleSold and not row.pouchPaid and
         epoch>=start-3600 and epoch<=start+30*86400 then
        results[#results+1]=row
      end
    end
    table.sort(results,function(a,b)
      if (a.createdEpoch or 0)==(b.createdEpoch or 0) then return (a.id or 0)<(b.id or 0) end
      return (a.createdEpoch or 0)<(b.createdEpoch or 0)
    end)
    return results
  end
  local function evidenceQty(anchor)
    local quantity=tonumber(anchor.purchaseBatchQuantity)
    if quantity and quantity>1 then return quantity end
    -- The old addon stored its ignored lot quantity in debugLog even when
    -- /writ debug on wasn't enabled. Match by original auction ID only.
    if anchor.auctionID and DB.debugLog then
      for _,line in ipairs(DB.debugLog) do
        local qty,auction=tostring(line):match('Writ AH quantity%s+(%d+)%s+ignored for single auction%s+(%S+)')
        if qty and tostring(anchor.auctionID)==auction then return tonumber(qty) end
      end
    end
    return nil
  end
  function WritBatch.repair(anchor,qty,automatic)
    if not DB or not anchor then return false,'Select the original priced AH writ first.' end
    qty=math.floor(tonumber(qty) or 0)
    if qty<2 or qty>200 then return false,'Batch quantity must be between 2 and 200.' end
    if not sealOf(anchor) or not SEALS[sealOf(anchor)] then
      return false,'Only sealed Journeyman/Expert/Artisan purchase batches can be split.'
    end
    if anchor.acquired~='Auction House' or anchor.priceUnknown or
       (tonumber(anchor.writCost) or 0)<=0 then
      return false,'Choose the priced Auction House record (the one showing the whole lot cost).'
    end
    if anchor.priceSource=='Manual edit' or anchor.priceSource=='Manual correction' then
      return false,'This price was manually corrected; will not overwrite it.'
    end
    if anchor.purchaseBatchRepaired or anchor.purchaseBatchIndex then
      return false,'This purchase has already been allocated per writ.'
    end
    if anchor.complete or anchor.resaleSold or anchor.pouchPaid then
      return false,'Archived or sold writs cannot be batch-repaired automatically.'
    end
    local extras=possibleExtras(anchor)
    if #extras~=qty-1 then
      return false,'Found '..#extras..' matching unpriced Collected copies, but expected '..(qty-1)..'. No records were changed.'
    end
    local total=math.floor(tonumber(anchor.writCost))
    local entries={anchor}
    for _,e in ipairs(extras) do entries[#entries+1]=e end
    local batchKey='legacy:'..tostring(anchor.id)
    for i,e in ipairs(entries) do
      local portion=math.floor(total/qty)+(i<=total%qty and 1 or 0)
      e.writCost=portion
      e.priceUnknown=false
      e.priceSource='Recovered AH batch ('..qty..' writs)'
      e.acquired='Auction House';e.source='Auction House'
      e.purchaseBatchQuantity=qty
      e.purchaseBatchTotal=total
      e.purchaseBatchIndex=i
      e.purchaseBatchAuctionID=anchor.auctionID
      e.purchaseBatchRepaired=true
      e.purchaseBatchRepairKey=batchKey
      addLog('BATCH REPAIR',e,'Allocated '..fmtMoney(portion)..' of '..fmtMoney(total)..' across '..qty..' sealed writs')
    end
    DB.batchRepairs=DB.batchRepairs or {}
    DB.batchRepairs[batchKey]={quantity=qty,total=total,when=datetime(),automatic=automatic and true or false}
    debugMessage('REPAIRED '..qty..'x sealed writs, total '..fmtMoney(total)..' preserved. IDs ' .. tostring(anchor.id))
    if refresh then refresh(true) end
    return true,'Repaired '..qty..' writs. Original total '..fmtMoney(total)..' was split into individual prices. No extra spending added.'
  end
  function WritBatch.autoRepair()
    if not DB or not DB.orders then return end
    for _,anchor in ipairs(DB.orders) do
      if anchor.acquired=='Auction House' and not anchor.priceUnknown and
         not anchor.purchaseBatchIndex and (sealOf(anchor) and SEALS[sealOf(anchor)]) then
        local quantity=evidenceQty(anchor)
        if quantity and quantity>1 then
          local ok,msg=WritBatch.repair(anchor,quantity,true)
          if ok then say('Automatic Expert/Journeyman/Artisan lot repair: '..msg) end
        end
      end
    end
  end
end
local function scanMailInvoices(canPrune)
  if not DB or not mailOpen or not GetInboxNumItems or not GetInboxInvoiceInfo then return end
  local ok,num=pcall(GetInboxNumItems)
  if not ok or type(num)~='number' then return end
  DB.mailInvoiceSeen=DB.mailInvoiceSeen or {}
  local function agrees(expected,attached)
    if not expected or expected=='' or not attached then return true end
    return sameRequired(expected,attached)
  end
  local occurrences={}
  for idx=1,math.min(num,400) do
    local valid,kind,invoiceName,seller,bid,buyout,deposit,consignment,
          moneyDelay,etaHour,etaMin,invoiceCount = pcall(GetInboxInvoiceInfo,idx)
    if valid and kind=='buyer' then
      local mailSender,mailSubject,daysLeft
      if GetInboxHeaderInfo then
        local hdr,s1,s2,s3,s4,s5,s6,s7=pcall(GetInboxHeaderInfo,idx)
        if hdr then mailSender=s3;mailSubject=s4;daysLeft=s7 end
      end
      -- An invoice is read only when its actual writ attachment can be identified.
      -- This avoids matching items with similar names from normal player mail.
      for attachment=1,(ATTACHMENTS_MAX_RECEIVE or 12) do
        local itemName,id,count,link
        if GetInboxItem then
          local itemOk,rawName,rawID,texture,rawCount=pcall(GetInboxItem,idx,attachment)
          if itemOk then itemName=rawName;id=tonumber(rawID);count=rawCount end
        end
        if GetInboxItemLink then
          local linkOK,rawLink=pcall(GetInboxItemLink,idx,attachment)
          if linkOK then link=rawLink;id=id or idFromLink(rawLink) end
        end
        local name,rep,sealed
        if id or itemName or link then
          name,rep,sealed=recognize(id,link or itemName)
        end
        local requiredName=not name and (namedItem(link or itemName) or getName(id)) or nil
        local linkID=idFromLink(link)
        local attached=namedItem(link or itemName)
        local subjectItem=tostring(mailSubject or ''):match('^[Aa]uction won:%s*(.+)$')
        if (id and linkID and id~=linkID) or not agrees(invoiceName,attached) or not agrees(subjectItem,attached) then
          canPrune=false -- inbox is shifting; preserve existing receipt fingerprints
        elseif name or (requiredName and isRequiredPurchaseName(requiredName)) then
          -- In buyer mail, "bid" is the AMOUNT PAID displayed by Blizzard's
          -- invoice UI. Some Forever invoices report 1 copper in "buyout"
          -- (listing data), so that field is NOT reliable for purchase cost.
          local cost=tonumber(bid)
          if not cost or cost<=0 then cost=tonumber(buyout) end
          -- One copper is a known bogus invoice fallback on this server.
          -- Without a larger paid amount, leave the price unknown.
          if not cost or cost<=1 then cost=nil end
          debugMessage('Buyer mail '..tostring(name or requiredName)..' bid='..tostring(bid)..' buyout='..tostring(buyout)..' paid='..tostring(cost))
          -- Prefer actual attached stack count. On some Forever builds
          -- invoiceCount isn't the count of attachments. Never expand a named
          -- writ from that unverified value.
          local qty=1
          if sealed then
            local stackCount=tonumber(count)
            if stackCount and stackCount>1 then
              qty=math.max(1,math.min(200,math.floor(stackCount)))
            elseif stackCount==nil and tonumber(invoiceCount) and tonumber(invoiceCount)>1 then
              qty=math.max(1,math.min(200,math.floor(tonumber(invoiceCount))))
            end
          elseif not name then
            -- Invoice count can be unrelated to the attachment stack on
            -- Forever. The attached item count takes precedence: a single
            -- Mageweave Bag paid at 60s99c must remain 60s99c, not be divided
            -- by an unrelated invoice quantity.
            local stackCount=tonumber(count)
            if stackCount and stackCount>0 then
              qty=math.max(1,math.min(200,math.floor(stackCount)))
            elseif tonumber(invoiceCount)==1 then
              qty=1 -- singular invoice has no ambiguous quantity
            else
              -- Do not finalize a unit cost from an unreliable invoiceCount.
              -- The next mailbox scan may populate the attachment count.
              cost=nil
              debugMessage('Deferred item invoice with no reliable attached quantity: '..
                tostring(requiredName)..' invoiceCount='..tostring(invoiceCount))
            end
          end
          local currentTime=time and time() or 0
          local expiry=math.floor((currentTime+(tonumber(daysLeft) or 30)*86400)/1800+.5)
          -- The expiry estimate differentiates otherwise identical mail from
          -- purchases on different days, and survives /reload and mail reordering.
          local key=table.concat({tostring(id or name or requiredName),tostring(mailSender or seller or ''),
            tostring(mailSubject or ''),tostring(bid or ''),tostring(buyout or ''),
            tostring(qty),tostring(expiry)},'|')
          occurrences[key]=(occurrences[key] or 0)+1
          local seen=tonumber(DB.mailInvoiceSeen[key]) or 0
          if occurrences[key]>seen then
            local matched
            if name then
              matched=matchMailInvoice(id,name,rep,sealed,cost,qty,key)
            elseif cost then
              matched=matchRequiredMailInvoice(id,requiredName,cost,key,qty)
            else
              -- The mail exists, but its invoice isn't loaded yet. Do NOT
              -- mark it seen, and do NOT turn Price Pending into Unverified.
              debugMessage('Deferred item invoice with missing paid amount: '..
                tostring(requiredName)..' mailbox slot '..tostring(idx))
            end
            if matched then DB.mailInvoiceSeen[key]=occurrences[key] end
          end
        end
      end
    end
  end
  -- Seen counts describe currently visible receipt copies, NOT the number
  -- ever encountered across the character's lifetime. If a receipt is taken
  -- out of the inbox, release its fingerprint so a newly bought identical
  -- item at the same price can be recognized later. Only do this on a full
  -- inbox update; MAIL_SHOW may briefly report an unloaded/empty inbox.
  if canPrune then
    for key,seen in pairs(DB.mailInvoiceSeen) do
      local live=tonumber(occurrences[key]) or 0
      if live<seen then
        if live==0 then DB.mailInvoiceSeen[key]=nil
        else DB.mailInvoiceSeen[key]=live end
      end
    end
  end
end
local function findUnreceived(id,name,sealed,guid)
  -- Prefer a confirmed-price purchase. The same named writ can have different
  -- IDs/links across the AH listing and the actual inbox attachment.
  local fallback
  for i=#DB.orders,1,-1 do
    local e=DB.orders[i]
    if e.acquired=='Auction House' and not e.bagPresent and not e.complete and not e.openedAt and
       not e.resaleListed and not e.resaleSold and not e.banked and (not guid or not e.bagGUID or e.bagGUID==guid) and
       writMatchesRecord(e,id,name,sealed) then
      if not e.priceUnknown then return e end
      fallback=fallback or e
    end
  end
  return fallback
end
local function findSealedInBags(id)
  for _,e in ipairs(DB.orders) do
    if e.sealed and e.bagPresent and not e.openedAt and not e.complete and e.itemID==id then
      return e
    end
  end
end
local function onSealedUsed(bag,slot)
  if not DB then return end
  local id=bagID(bag,slot)
  if not SEALS[id] and not POUCH_REP[id] then id=bagSlotIDs[tostring(bag)..':'..tostring(slot)] end
  if POUCH_REP[id] then onPouchUse('bag use');return end
  if not SEALS[id] then return end
  local e=findSealedInBags(id)
  if not e then return end
  for _,action in ipairs(sealedActions) do
    if action.recordID==e.id and clock()-action.at<3 then return end
  end
  sealedUseAt[id]=clock()
  sealedActions[#sealedActions+1]={recordID=e.id,at=clock(),itemID=id}
  debugMessage('Used sealed #'..e.id..' ('..tostring(id)..')')
end
local function replaceSealed(e,id,item,reason)
  if not e or not e.sealed or e.openedAt then return nil end
  local oldID=e.itemID
  local wasPresent=e.bagPresent
  local queueLoss=false
  for _,q in ipairs(openedQueue) do
    if q.recordID==e.id then queueLoss=true;break end
  end
  if wasPresent and not queueLoss then
    -- The new named item was received BEFORE the old seal loss event.
    sealedLossConsumed[oldID]=(sealedLossConsumed[oldID] or 0)+1
  end
  e.sealed=false;e.wasSealed=true;e.sealedItemID=oldID
  e.writ=item.name;e.itemID=id;e.openedItemID=id
  e.openedAt=datetime();e.bagPresent=true
  e.item=item.name:gsub("^[Cc]raftsman'?s [Ww]rit:%s*",'')
  addLog('OPEN',e,reason or 'Envelope opened; acquisition and cost retained')
  debugMessage('Sealed #'..e.id..' -> '..item.name..' | cost '..tostring(e.writCost)..' | source '..tostring(e.acquired))
  say('Opened '..item.name..' (original purchase price retained)')
  return e
end
local function findOpeningRecord()
  local now=clock()
  -- A genuine use signal takes precedence over inferred bag losses.
  for i=#sealedActions,1,-1 do
    local action=sealedActions[i]
    if now-action.at<180 then
      local e=entryByID(action.recordID)
      if e and e.sealed and not e.openedAt then
        table.remove(sealedActions,i)
        return e,'Sealed writ use'
      end
    end
  end
  for i=#openedQueue,1,-1 do
    local q=openedQueue[i]
    if now-q.at<180 then
      local e=entryByID(q.recordID)
      if e and e.sealed and not e.openedAt then
        table.remove(openedQueue,i)
        return e,'Sealed writ removed from bags'
      end
    end
  end
  -- Last resort for a client that split/missed inventory events.
  for i=#DB.orders,1,-1 do
    local e=DB.orders[i]
    if e.sealed and not e.bagPresent and not e.openedAt and
       e.sealLostAt and now-e.sealLostAt<90 then
      return e,'Recent sealed writ disappeared'
    end
  end
end
local function freshLootHint(id)
  local a=lootHints[id]
  return a and clock()-a<4
end
local function receiveItem(id,item,starting,currentBagCount,guid)
  if guid then
    for _,e in ipairs(DB.orders) do
      if e.bagGUID==guid and not e.complete and not e.resaleListed and not e.resaleSold then
        e.bagPresent=true;e.writLostAt=nil;e.banked=false
        if e.resaleReturnPending then
          e.resaleReturnPending=false
          addLog('RETURN',e,'Unsold AH listing collected; original acquisition cost retained')
        end
        return e
      end
    end
  end
  if not item.sealed and not starting then
    local original,reason=findOpeningRecord()
    if original then return replaceSealed(original,id,item,reason) end
  end
  -- Returned expired/cancelled AH listings are the SAME writ, not newly looted copies.
  for _,existing in ipairs(DB.orders or {}) do
    if existing.resaleReturnPending and not existing.bagPresent and not existing.complete and
       writMatchesRecord(existing,id,item.name,item.sealed) then
      existing.bagPresent=true;existing.resaleReturnPending=false
      addLog('RETURN',existing,'Unsold AH listing collected; original acquisition cost retained')
      return existing
    end
  end
  local previouslyPurchased=findUnreceived(id,item.name,item.sealed,guid)
  if previouslyPurchased then
    local oldID=previouslyPurchased.itemID
    previouslyPurchased.itemID=id or oldID
    previouslyPurchased.bagPresent=true
    if item.name and not previouslyPurchased.sealed then
      previouslyPurchased.writ=item.name
      TIER.apply(previouslyPurchased,TIER.peek(id,item.name),'Collected item tooltip')
    end
    addLog('RECEIVED',previouslyPurchased,'AH purchase collected; retained '..
      (previouslyPurchased.priceUnknown and 'unverified cost' or fmtMoney(previouslyPurchased.writCost)))
    debugMessage('Mail/bag received AH #'..previouslyPurchased.id..' id '..tostring(oldID)..' -> '..tostring(id)..
      ' cost='..tostring(previouslyPurchased.writCost)..' priceUnknown='..tostring(previouslyPurchased.priceUnknown))
    return previouslyPurchased
  end
  if consumeDeletedReceipt(id,item.name) then
    debugMessage('Ignored bag pickup of manually deleted awaiting-mail writ '..tostring(item.name))
    return nil
  end
  -- A late BAG_UPDATE after login, item-cache resolution, or a bank refresh
  -- can report an item as newly arrived even though the same physical copies
  -- are already represented by saved active records. Count existing bagged
  -- copies instead of making a second Loot/Collected record. If bag quantity
  -- really increased (e.g. one more writ purchased), it is still captured.
  if not starting and tonumber(currentBagCount) then
    local represented=(DB.ignoredBagCounts and DB.ignoredBagCounts[id]) or 0
    for _,existing in ipairs(DB.orders or {}) do
      if existing.bagPresent and not existing.complete and not existing.resaleSold and
         not existing.resaleListed and writMatchesRecord(existing,id,item.name,item.sealed) then
        represented=represented+1
      end
    end
    if represented>=tonumber(currentBagCount) then
      debugMessage('Ignored repeat bag arrival for '..tostring(item.name)..
        ': '..represented..' existing bagged record(s) cover '..currentBagCount..' item(s)')
      return nil
    end
  end
  if mailOpen and not guid and rows.mailMissing then
    for _,e in ipairs(DB.orders) do
      if rows.mailMissing[e.id]==id and not e.bagPresent and not e.complete and
         not e.resaleListed and not e.resaleSold and not e.banked then
        rows.mailMissing[e.id]=nil
        e.bagPresent=true;e.writLostAt=nil
        return e
      end
    end
  end
  local source
  if starting then source='Found in bags'
  elseif mailOpen then source='Collected'
  elseif freshLootHint(id) then source='Loot'
  else source='Collected' end
  local price=(source=='Loot') and 0 or nil
  local e=markWrit(id,item.name,item.rep,item.sealed,source,price,true,starting and 'Already in bags at first scan' or 'New writ entered bags')
  if not starting then say('Captured '..item.name..' ('..source..')') end
  return e
end
-- IMPORTANT: opening an envelope is a loss of one sealed item plus a gain of
-- one named writ. Reuse the SAME row and cost; do not create a second writ.
function rows.hasGUID(item,guid)
  for _,value in ipairs(item and item.guids or {}) do
    if value==guid then return true end
  end
end
scanChanges=function(initial)
  if not DB then return end
  local current=bagSnapshot()
  local before=bagBefore or {}
  -- Open All can briefly hide a bag slot while moving its contents. Confirm
  -- disappearance on a later scan before releasing a named writ's record.
  if mailOpen and not BankGuard.open then
    rows.mailBagLosses=rows.mailBagLosses or {}
    local now=clock()
    for id,old in pairs(before) do
      if not old.sealed and (current[id] and current[id].count or 0)<old.count then
        local due=rows.mailBagLosses[id] or (now+.4)
        if now<due then
          rows.mailBagLosses[id]=due
          rows.bagInfoScanAt=math.min(rows.bagInfoScanAt or due,due)
          current[id]=old
        else rows.mailBagLosses[id]=nil end
      else rows.mailBagLosses[id]=nil end
    end
  else rows.mailBagLosses=nil end
  if not mailOpen and not initial and DB.ignoredBagCounts then
    for id,ignored in pairs(DB.ignoredBagCounts) do
      local count=current[id] and current[id].count or 0
      if count==0 then DB.ignoredBagCounts[id]=nil
      elseif count<ignored then DB.ignoredBagCounts[id]=count end
    end
  end
  local losses,additions={},{ }
  -- Track moved copies by comparing changes in bags AND bank at the same time.
  -- The delayed scan lets the client finish both inventory events first.
  local deposits,withdrawals={},{}
  local bankNow=BankGuard.open and BankGuard.snapshot() or nil
  if bankNow then
    local bankWas=BankGuard.prior or bankNow
    for id,now in pairs(bankNow) do
      local gained=now-(bankWas[id] or 0)
      if gained>0 then
        local bagWas=before[id] and before[id].count or 0
        local bagNow=current[id] and current[id].count or 0
        deposits[id]=math.min(gained,math.max(0,bagWas-bagNow))
      end
    end
    for id,oldBank in pairs(bankWas) do
      local lost=oldBank-(bankNow[id] or 0)
      if lost>0 then
        local bagWas=before[id] and before[id].count or 0
        local bagNow=current[id] and current[id].count or 0
        withdrawals[id]=math.min(lost,math.max(0,bagNow-bagWas))
      end
    end
  end
  for id,old in pairs(before) do
    local diff=old.count-((current[id] and current[id].count) or 0)
    if diff>0 then
      if old.sealed then
        for i=1,diff do
          local transferred=(deposits[id] or 0)>0
          if transferred then deposits[id]=deposits[id]-1 end
          losses[#losses+1]={id=id,banked=transferred}
        end
      else
        for j=1,diff do
          local transferred=(deposits[id] or 0)>0
          if transferred then deposits[id]=deposits[id]-1 end
          local selectedCopy,otherCopy
          for _,e in ipairs(DB.orders) do
            if e.itemID==id and e.bagPresent and not (e.bagGUID and rows.hasGUID(current[id],e.bagGUID)) then
              if (transferred and not e.resaleListed) or
                 (not transferred and e.resaleListed) then
                selectedCopy=e;break
              end
              if not otherCopy then otherCopy=e end
            end
          end
          -- A transfer must NEVER bank a copy already confirmed as listed.
          -- Non-transfer losses may use an unlisted copy if the auction
          -- confirmation has not arrived yet.
          local e=selectedCopy or (otherCopy and (not transferred or not otherCopy.resaleListed) and otherCopy)
          if e then
            e.bagPresent=false
            if transferred then
              e.banked=true;e.writLostAt=nil
              addLog('BANK DEPOSIT',e,'Moved to bank; still active')
            else
              e.writLostAt=clock()
              if mailOpen then
                rows.mailMissing=rows.mailMissing or {}
                rows.mailMissing[e.id]=id
              end
            end
          else
            debugMessage('Bank/AH writ copy not assigned for itemID '..tostring(id)..
              ': retained existing posted and bank record identities')
          end
        end
      end
    end
  end
  for id,item in pairs(current) do
    local count=item.count-((before[id] and before[id].count) or 0)
    if count>0 then
      local added=0
      for _,guid in ipairs(item.guids or {}) do
        if added<count and not rows.hasGUID(before[id],guid) then
          additions[#additions+1]={id=id,item=item,guid=guid}
          added=added+1
        end
      end
      for i=added+1,count do additions[#additions+1]={id=id,item=item} end
    end
  end
  -- Preserve a stable sequence and open sealed envelopes before new items.
  table.sort(losses,function(a,b)return a.id<b.id end)
  table.sort(additions,function(a,b)
    if a.item.sealed~=b.item.sealed then return not a.item.sealed end
    return a.id<b.id
  end)
  for _,loss in ipairs(losses) do
    local id=loss.id
    if loss.banked then
      local e=findSealedInBags(id)
      if e then
        e.bagPresent=false;e.banked=true;e.sealLostAt=nil
        addLog('BANK DEPOSIT',e,'Sealed writ moved into bank; envelope not opened')
      end
    elseif (sealedLossConsumed[id] or 0)>0 then
      sealedLossConsumed[id]=sealedLossConsumed[id]-1
    else
      local e=findSealedInBags(id)
      if e then
        e.bagPresent=false;e.sealLostAt=clock()
        openedQueue[#openedQueue+1]={recordID=e.id,at=clock(),hadUse=(sealedUseAt[id] and clock()-sealedUseAt[id]<15)}
      end
    end
  end
  for _,a in ipairs(additions) do
    if (withdrawals[a.id] or 0)>0 then
      withdrawals[a.id]=withdrawals[a.id]-1
      BankGuard.withdraw(a.id,a.item,a.guid)
    else
      -- A previously tracked banked copy can return after a reload, when the
      -- bank event's item count has not yet been populated by this client.
      local oldBanked
      if BankGuard.open then
        for _,e in ipairs(DB.orders) do
          if e.banked and not e.bagPresent and (not a.guid or not e.bagGUID or e.bagGUID==a.guid) and
             writMatchesRecord(e,a.id,a.item.name,a.item.sealed) then
            if not oldBanked then oldBanked=e end
            if a.guid and e.bagGUID==a.guid then oldBanked=e;break end
          end
        end
      end
      if oldBanked then
        oldBanked.bagGUID=a.guid or oldBanked.bagGUID
        oldBanked.bagPresent=true;oldBanked.banked=false
        oldBanked.writLostAt=nil;oldBanked.sealLostAt=nil
        addLog('BANK WITHDRAW',oldBanked,'Existing banked writ returned to bags')
      else
        local e=receiveItem(a.id,a.item,initial,current[a.id].count,a.guid)
        if e and a.guid then e.bagGUID=a.guid end
      end
    end
  end
  bagBefore=current
  if bankNow then BankGuard.prior=bankNow end
  if pendingTurnIn and clock()-pendingTurnIn.at<12 and findRecentLostWrit then
    local e=findRecentLostWrit()
    if e then
      finishWrit(e,'Quest turn-in confirmed by bag loss',pendingTurnIn.questID)
      pendingTurnIn=nil
    end
  end
  if scanPouchChanges then scanPouchChanges() end
  local serial={}
  for id,e in pairs(current) do serial[id]=e.count end
  DB.lastBag=serial
  for i=#openedQueue,1,-1 do
    if clock()-openedQueue[i].at>180 then table.remove(openedQueue,i) end
  end
  if refresh then refresh(true) end
end
-- Completion tracking. A turn-in does NOT destroy its writ record. It sits
-- in active records as "Awaiting pouch" until we have the actual wallet gain.
local function findQuestWrit(title,questID)
  if not title or not title:lower():find('writ',1,true) then return nil end
  local candidate
  for _,e in ipairs(DB.orders) do
    if not e.sealed and not e.complete and sameWritName(e.writ,title) then
      if e.bagPresent then return e end
      candidate=candidate or e
    end
  end
  return candidate
end
findRecentLostWrit=function()
  local found
  for _,e in ipairs(DB.orders) do
    if not e.complete and not e.sealed and not e.resaleListed and not e.resaleReturnPending and e.writLostAt and
      clock()-e.writLostAt<12 then
      if found then return nil end
      found=e
    end
  end
  return found
end
local function applyBookRep(e)
  if not e or not e.repNeedsReview then return end
  local key=itemKey(requiredItemName(e))
  local over=DB.bookOverrides and DB.bookOverrides[key]
  if over and tonumber(over.rep) and tonumber(over.rep)>0 then
    e.rep=tonumber(over.rep);e.repNeedsReview=false;e.repSource='Personal reference'
  end
end
-- Store the latest personal turn-in per item. A mailbox or bag event on its
-- own cannot mark a daily as done.
function rows.noteWritTurnIn(name,at)
  local key=requiredKey(name)
  if key=='' or not at or at<=0 then return end
  DB.lastWritTurnIn=DB.lastWritTurnIn or {}
  if at<=(DB.lastWritTurnIn[key] or 0) then return end
  DB.lastWritTurnIn[key]=at
  if rows.dailyPriceChanged then rows.dailyPriceChanged(key,at) end
end
finishWrit=function(e,reason,questID)
  if not e or e.complete or e.sealed then return false end
  applyBookRep(e)
  e.complete=true;e.completedAt=datetime();e.completedEpoch=time and time() or 0
  e.completedClock=clock();e.pouchPending=true;e.pouchPaid=false
  e.questID=questID or e.questID
  e.repEarned=(not e.repNeedsReview and tonumber(e.rep)) or nil
  if recentFactionGain and clock()-recentFactionGain.at<3 then
    e.repEarned=recentFactionGain.amount
    e.rep=e.repEarned;e.repNeedsReview=false;e.repSource='Reputation chat'
    recentFactionGain=nil
  end
  e.finishReason=reason
  rows.noteWritTurnIn(requiredItemName(e),e.completedEpoch)
  -- Only confirmed in-game quest turn-ins record turn-in coordinates. A
  -- manual /writ finish must never save the player's arbitrary position.
  if type(reason)=='string' and reason:find('^Quest turn%-in') then
    if community.captureTurnInLocation then community.captureTurnInLocation(e) end
    if rows.clearCompletedWritWaypoint then rows.clearCompletedWritWaypoint(e) end
  end
  addLog('COMPLETE',e,reason..' | waiting for Coin Pouch payout')
  debugMessage('Writ completed #'..e.id..' '..e.writ..' | coin pouch is PENDING')
  say('Completed '..e.writ..'; waiting for Coin Pouch payout.')
  if refresh then refresh(true) end
  if bookRefresh then bookRefresh(true) end
  return true
end
local function pendingPayoutWrit(pouchID)
  local chosen,unknown,unknownCount=nil,nil,0
  local expected=POUCH_REP[pouchID]
  for _,e in ipairs(DB.orders) do
    if e.complete and not e.pouchPaid then
      local rep=not e.repNeedsReview and tonumber(e.rep)
      if expected and not rep then
        unknown=e;unknownCount=unknownCount+1
      elseif (not expected or rep==expected) and (not chosen or (tonumber(e.completedEpoch) or 0)<(tonumber(chosen.completedEpoch) or 0) or
        (e.completedEpoch==chosen.completedEpoch and e.id<chosen.id)) then
        chosen=e
      end
    end
  end
  return chosen or (unknownCount==1 and unknown or nil)
end
archivePouch=function(e,amount,source)
  if not e or not e.complete or e.pouchPaid then return false end
  if type(amount)~='number' or amount<=0 or amount~=math.floor(amount) or amount==math.huge then return false end
  -- Explicit corrections take precedence over any in-flight automatic match.
  -- Retire the entire transient burst, not just one event: otherwise its
  -- remaining wallet gain could silently archive a different pending writ.
  if type(source)=='string' and source:sub(1,6)=='Manual' then
    pouchUses={};rows.pouchGains={};rows.pouchLastActivity=0
    recentPouchGains={}
    if pouchBagCount then lastPouchCount,rows.lastPouchCounts=pouchBagCount() end
    debugMessage('Manual pouch payout: cleared unverified transient batch')
  end
  e.pouchAmount=amount;e.pouchPaid=true;e.pouchPending=false
  e.pouchReceivedAt=datetime();e.pouchSource=source or 'Coin Pouch'
  e.totalCost=(not e.priceUnknown and e.itemCostKnown and not e.itemPriceUnknown and not rows.itemPricePending(e))
    and ((e.writCost or 0)+(e.itemCost or 0)) or nil
  e.netCost=e.totalCost and (e.totalCost-amount) or nil
  DB.completed=DB.completed or {}
  table.insert(DB.completed,e)
  for i=#DB.orders,1,-1 do
    if DB.orders[i].id==e.id then table.remove(DB.orders,i);break end
  end
  if selectedID==e.id then selectedID=nil;DB.selectedID=nil end
  addLog('POUCH',e,'Coin Pouch credited '..fmtMoney(amount)..
    ' | net '..(e.netCost and fmtNetMoney(e.netCost) or 'cost unknown'))
  debugMessage('Archived writ #'..e.id..' with payout '..tostring(amount))
  say('Saved '..e.writ..': pouch '..fmtMoney(amount)..' | net '..
    (e.netCost and fmtNetMoney(e.netCost) or 'unknown')..' | '..
    tostring(e.repEarned or 'unknown')..' rep')
  if refresh then refresh(true) end
  if bookRefresh then bookRefresh(true) end
  return true
end
pouchBagCount=function()
  local total,counts=0,{}
  for bag=0,(NUM_BAG_SLOTS or 4) do
    local slots=0
    if C_Container and C_Container.GetContainerNumSlots then slots=C_Container.GetContainerNumSlots(bag) or 0
    elseif GetContainerNumSlots then slots=GetContainerNumSlots(bag) or 0 end
    for slot=1,slots do
      local id=bagID(bag,slot)
      if POUCH_REP[id] then
        local count=tonumber(bagCount(bag,slot)) or 1
        counts[id]=(counts[id] or 0)+count
        total=total+count
      end
    end
  end
  return total,counts
end
-- A Coin Pouch has no per-writ identity. A payout can be associated with an
-- individual completed order only by a conservative chronological convention.
-- For rapid batches the client can coalesce several PLAYER_MONEY events into
-- one sum; assigning that sum to the oldest writ would corrupt its history.
-- Defer processing briefly and only auto-archive a SINGLE independently
-- confirmed pouch loss and wallet gain. Ambiguous batches remain pending.
rows.collectRecentPouchGains=function(now)
  for _,gain in ipairs(recentPouchGains) do
    if now-gain.at<2 then table.insert(rows.pouchGains,gain) end
  end
  recentPouchGains={}
end
onPouchUse=function(source)
  if not DB or not pendingPayoutWrit() then
    debugMessage('Coin Pouch used without matching completed writ; no payout assigned')
    return
  end
  local now=clock()
  -- Do not debounce rapid independent clicks. A repeated hook is harmless:
  -- without a corresponding bag-count decrease it never becomes a payout.
  table.insert(pouchUses,{at=now,source=source or 'item use',consumed=false})
  rows.pouchLastActivity=now
  rows.collectRecentPouchGains(now)
  debugMessage('Coin Pouch use seen; waiting for matching bag loss and wallet gain')
end
local function settlePouchEvents()
  if not DB or #pouchUses==0 then return end
  local now=clock()
  if now-rows.pouchLastActivity<1.5 then return end
  local used,unused=0,0
  for _,p in ipairs(pouchUses) do
    if p.consumed then used=used+1 else unused=unused+1 end
  end
  -- Let the client deliver delayed bag updates and wallet changes after a
  -- burst. The frame OnUpdate checks this without adding timers/events.
  if unused>0 then
    local newest=0
    for _,p in ipairs(pouchUses) do
      if not p.consumed then newest=math.max(newest,p.at) end
    end
    if now-newest<4 then return end
  end
  if used>0 and #rows.pouchGains<used and now-rows.pouchLastActivity<4 then return end
  if used==0 then
    -- E.g., a cancelled use or duplicate click hook: no bag loss, no payout.
    pouchUses={};rows.pouchGains={}
    return
  end
  if used==1 and #rows.pouchGains==1 and tonumber(rows.pouchGains[1].amount) and
     rows.pouchGains[1].amount>0 then
    local pouchID
    for _,p in ipairs(pouchUses) do if p.consumed then pouchID=p.itemID;break end end
    local e=pendingPayoutWrit(pouchID)
    if e then
      archivePouch(e,rows.pouchGains[1].amount,'Coin Pouch (single verified bag loss + wallet gain)')
    else
      debugMessage('Pouch payout pending review: no matching completed writ for item '..tostring(pouchID))
    end
  else
    local total=0
    for _,g in ipairs(rows.pouchGains) do total=total+(tonumber(g.amount) or 0) end
    debugMessage('COIN POUCH REVIEW: '..used..' bag loss(es), '..#rows.pouchGains..
      ' wallet increase event(s), combined observed gain '..fmtMoney(total)..
      '. No payout assigned; individual values/order are unverified.')
    say('|cFFFFB46A'..used..' Coin Pouch opening(s) need review: '..
      #rows.pouchGains..' wallet increase(s) observed. No writ was archived. '..
      'Use Shift+Middle-click on each awaiting-payout writ ONLY with its verified amount.|r')
  end
  pouchUses={};rows.pouchGains={};recentPouchGains={}
  rows.pouchLastActivity=0
end
scanPouchChanges=function()
  if not DB then return end
  local count,counts=pouchBagCount()
  local losses={}
  if counts and rows.lastPouchCounts then
    for id,prior in pairs(rows.lastPouchCounts) do
      for i=1,prior-(counts[id] or 0) do losses[#losses+1]=id end
    end
  else
    for i=1,lastPouchCount-count do losses[#losses+1]=false end
  end
  if #losses>0 then
    local now=clock()
    for _,id in ipairs(losses) do
      local p
      for _,event in ipairs(pouchUses) do
        if not event.consumed and now-event.at<15 then p=event;break end
      end
      if not p then
        p={at=now,source='bag count'}
        table.insert(pouchUses,p)
      end
      p.consumed=true;p.consumedAt=now;p.itemID=id or nil
    end
    -- PLAYER_MONEY can arrive slightly before BAG_UPDATE_DELAYED on Forever.
    rows.collectRecentPouchGains(now)
    rows.pouchLastActivity=now
    debugMessage('Coin Pouch bag count -'..tostring(#losses)..
      '; matching wallet events after burst settles')
  elseif count>lastPouchCount then
    debugMessage('Coin Pouch reward observed in bags: +'..(count-lastPouchCount))
  end
  lastPouchCount,rows.lastPouchCounts=count,counts
end
local function onQuestCompleteScreen()
  local title=GetTitleText and GetTitleText() or nil
  local questID=GetQuestID and tonumber(GetQuestID()) or nil
  if title and title:lower():find('writ',1,true) then
    questScreen={title=title,questID=questID,at=clock()}
    debugMessage('Writ reward screen: '..title..' quest '..tostring(questID))
  else
    questScreen=nil
  end
end
local function onQuestTurnedIn(questID)
  questID=tonumber(questID)
  local title=nil
  if questScreen and clock()-questScreen.at<900 and
    (not questScreen.questID or not questID or questScreen.questID==questID) then
    title=questScreen.title
  end
  if not title and questID and C_QuestLog then
    if C_QuestLog.GetTitleForQuestID then
      local ok,result=pcall(C_QuestLog.GetTitleForQuestID,questID)
      if ok then title=result end
    end
    if not title and C_QuestLog.GetQuestInfo then
      local ok,result=pcall(C_QuestLog.GetQuestInfo,questID)
      if ok then title=result end
    end
  end
  if title and type(title)=='string' then
    local named=requiredItemName({writ=title})
    if named and WRIT_LOCATIONS[itemKey(named)] then rows.noteWritTurnIn(named,time and time()) end
  end
  local e=findQuestWrit(title,questID)
  if not e and questID and questID>=94000 and questID<95000 then
    e=findRecentLostWrit()
    if e then debugMessage('Completed via unique lost writ + Forever quest '..questID) end
  end
  if e then
    finishWrit(e,'Quest turn-in '..tostring(questID or '?'),questID)
    questScreen=nil;pendingTurnIn=nil
  elseif questID and questID>=94000 and questID<95000 then
    -- Some clients deliver QUEST_TURNED_IN before updating bag contents.
    -- Associate it only if exactly one named writ disappears shortly after.
    pendingTurnIn={questID=questID,at=clock()}
    debugMessage('Pending writ quest '..questID..' until bag loss can verify it')
  elseif title and title:lower():find('writ',1,true) then
    debugMessage('Turned in writ quest but no matching acquired row: '..tostring(title))
  end
end
-- Auction House capture: cache the exact auction's name, quantity, and buyout;
-- hook PlaceBid only to PREPARE the transaction. It becomes real only after
-- AUCTION_HOUSE_PURCHASE_COMPLETED, avoiding false entries from failed clicks.
local function ahName(itemKey)
  if not itemKey or not itemKey.itemID then return nil end
  local id=itemKey.itemID
  local name=getName(id)
  if not name and C_AuctionHouse and C_AuctionHouse.GetItemKeyInfo then
    local ok,info=pcall(C_AuctionHouse.GetItemKeyInfo,itemKey,false)
    if ok and info then name=info.itemName end
  end
  if not name and C_AuctionHouse and C_AuctionHouse.GetItemKeySampleLink then
    local ok,link=pcall(C_AuctionHouse.GetItemKeySampleLink,itemKey)
    if ok then name=namedItem(link) end
  end
  return name
end
local function cacheAuctions(itemKey)
  if not itemKey or not itemKey.itemID or not C_AuctionHouse or
     not C_AuctionHouse.GetNumItemSearchResults or not C_AuctionHouse.GetItemSearchResultInfo then return end
  local id=itemKey.itemID
  local baseName=ahName(itemKey)
  local ok,count=pcall(C_AuctionHouse.GetNumItemSearchResults,itemKey)
  if not ok then return end
  -- All listings of an item/label pair share the same tracking decision.
  -- Keep the cache local to this event so newly active orders are respected.
  local classified={}
  local stamp=clock()
  for i=1,math.min(tonumber(count) or 0,500) do
    local success,item=pcall(C_AuctionHouse.GetItemSearchResultInfo,itemKey,i)
    if success and item and item.auctionID then
      local itemID=(item.itemKey and item.itemKey.itemID) or id
      local candidate=namedItem(item.itemLink) or baseName or getName(itemID)
      local byName=classified[itemID]
      if not byName then byName={};classified[itemID]=byName end
      local key=candidate or false
      local tracked=byName[key]
      if tracked==nil then
        tracked=recognize(itemID,candidate) or (candidate and isRequiredPurchaseName(candidate) and candidate) or false
        byName[key]=tracked
      end
      if tracked then
        local cached=auctionCache[item.auctionID] or {}
        cached.id=itemID;cached.name=tracked;cached.quantity=item.quantity or 1
        cached.price=tonumber(item.buyoutAmount);cached.at=stamp
        auctionCache[item.auctionID]=cached
      end
    end
  end
end
local function auctionDetails(auctionID)
  local a=auctionCache[auctionID]
  if C_AuctionHouse and C_AuctionHouse.GetAuctionInfoByID then
    local ok,info=pcall(C_AuctionHouse.GetAuctionInfoByID,auctionID)
    if ok and info then
      local id=info.itemKey and info.itemKey.itemID or (a and a.id)
      a=a or {}
      a.id=id
      a.name=namedItem(info.itemLink) or (a.name or ahName(info.itemKey))
      a.price=info.buyoutAmount or a.price
      a.quantity=a.quantity or info.quantity or 1
    end
  end
  return a
end
local function consumePendingItemEvent(id)
  for i,event in ipairs(pendingItemEvents) do
    if event.id==id then table.remove(pendingItemEvents,i);return true end
  end
  return false
end
local function confirmed(auctionID,overrideID,reason)
  if not DB or recentConfirmed[auctionID] then return false end
  local a=auctionDetails(auctionID) or pendingBid[auctionID]
  local pending=pendingBid[auctionID]
  if not a and not overrideID then
    pendingSuccess[auctionID]=clock()
    debugMessage('AH completed '..tostring(auctionID)..' but listing not cached; awaiting item ID')
    return false
  end
  a=a or {}
  local id=overrideID or a.id or (pending and pending.id)
  local raw=a.name or (pending and pending.name) or getName(id)
  local name,rep,sealed=recognize(id,raw)
  if not name then
    local itemName=raw or getName(id)
    if itemName and isRequiredPurchaseName(itemName) then
      recentConfirmed[auctionID]=clock()
      if not consumePendingItemEvent(id) then
        confirmedItems[id]=(confirmedItems[id] or 0)+1
      end
      local paid=(pending and pending.price) or a.price
      if pending and a~=pending and a.price and tonumber(pending.price) and
         tonumber(a.price)~=tonumber(pending.price) and not pending.walletVerified then
        debugMessage('Required-item AH bid/listing price disagreement for '..tostring(itemName)..
          ' bid='..tostring(pending.price)..' listing='..tostring(a.price)..'; waiting for invoice')
        paid=nil
      end
      -- PlaceBid's auction quantity describes the LISTING, not how many
      -- items were actually purchased/attached to buyer mail. Do not divide
      -- the price using that number. The real attached stack count will be
      -- read from the invoice before the displayed price is confirmed.
      local listingQty=(pending and pending.quantity) or a.quantity or 1
      local itemRecord=recordRequiredPurchase(id,itemName,paid,auctionID,
        reason or 'Confirmed required-item buyout',1)
      if itemRecord then
        itemRecord.itemAHListingQuantity=tonumber(listingQty) or 1
        if pending and pending.walletVerified and paid~=nil then
          itemRecord.itemPriceVerifiedWallet=true
        end
        if tonumber(listingQty) and tonumber(listingQty)>1 then
          debugMessage('Required-item AH listing shows '..tostring(listingQty)..
            ' available; not used as purchased quantity for '..tostring(itemName))
        end
      end
      pendingBid[auctionID]=nil;pendingSuccess[auctionID]=nil
      return true
    end
    pendingSuccess[auctionID]=clock()
    debugMessage('AH completion '..tostring(auctionID)..' no tracked item name yet id='..tostring(id))
    return false
  end
  recentConfirmed[auctionID]=clock()
  if not consumePendingItemEvent(id) then
    confirmedItems[id]=(confirmedItems[id] or 0)+1
  end
  local price=(pending and pending.price) or a.price
  if pending and a~=pending and a.price and tonumber(pending.price) and
     tonumber(a.price)~=tonumber(pending.price) and not pending.walletVerified then
    debugMessage('Writ AH bid/listing price disagreement for '..tostring(name)..
      ' bid='..tostring(pending.price)..' listing='..tostring(a.price)..'; price marked unverified')
    price=nil
  end
  local qty=(pending and pending.quantity) or a.quantity or 1
  purchaseRecord(id,name,rep,sealed,price,qty,auctionID,reason or 'Confirmed AH buyout')
  -- Only an exact wallet deduction certifies this source, not ITEM_PURCHASED.
  if pending and pending.walletVerified then
    for _,entry in ipairs(DB.orders) do
      if tostring(entry.auctionID)==tostring(auctionID) then entry.priceVerifiedWallet=true end
    end
  end
  pendingBid[auctionID]=nil;pendingSuccess[auctionID]=nil
  debugMessage('AH bought auction='..tostring(auctionID)..' id='..tostring(id)..' price='..tostring(price))
  return true
end
-- ITEM_PURCHASED no longer attempts to match an unverified nearby bid.
-- A completed auction, exact money change, or buyer invoice supplies price.
local auctionHooked=false
local sealedHooked=false
local commodityHooked=false
local commodityStartHooked=false
local function installHooks()
  -- Auctionator may start a commodity purchase before opening its confirmation
  -- flow. Track the item ID/quantity early so PLAYER_MONEY is not missed even
  -- when ConfirmCommoditiesPurchase does not run on a particular client build.
  if not commodityStartHooked and C_AuctionHouse and C_AuctionHouse.StartCommoditiesPurchase and hooksecurefunc then
    hooksecurefunc(C_AuctionHouse,'StartCommoditiesPurchase',function(itemID,quantity)
      if itemID then
        pendingCommodity={id=itemID,quantity=quantity,at=clock(),succeeded=false}
        debugMessage('Commodity start: '..tostring(getName(itemID) or itemID)..' x'..tostring(quantity))
      end
    end)
    commodityStartHooked=true
  end
  if not commodityHooked and C_AuctionHouse and C_AuctionHouse.ConfirmCommoditiesPurchase and hooksecurefunc then
    hooksecurefunc(C_AuctionHouse,'ConfirmCommoditiesPurchase',function(itemID,quantity)
      if itemID then
        local name=getName(itemID)
        local previous=pendingCommodity
        pendingCommodity={id=itemID,quantity=quantity,at=clock(),succeeded=false,
          paid=previous and previous.id==itemID and previous.paid or nil,
          likelyRequired=name and isRequiredPurchaseName(name) or nil}
        debugMessage('Commodity confirmation observed: '..tostring(name or itemID)..
          ' x'..tostring(quantity)..' (assigned only if it matches an active writ)')
      end
    end)
    commodityHooked=true
  end
  if not auctionHooked and C_AuctionHouse and C_AuctionHouse.PlaceBid and hooksecurefunc then
    hooksecurefunc(C_AuctionHouse,'PlaceBid',function(auctionID,amount)
      local a=auctionDetails(auctionID) or {}
      if not tonumber(amount) or tonumber(amount)<=0 then return end
      -- Bids below an actual known buyout must NOT be logged as purchases.
      if a.price and tonumber(amount) and tonumber(amount)<a.price then return end
      pendingBid[auctionID]={id=a.id,name=a.name,quantity=a.quantity or 1,
        price=tonumber(amount) or a.price,isBuyout=(a.price and tonumber(amount) and tonumber(amount)>=a.price) or false,
        at=clock()}
      debugMessage('PlaceBid auction='..tostring(auctionID)..' id='..tostring(a.id)..' amount='..tostring(amount))
      if pendingSuccess[auctionID] then confirmed(auctionID,nil,'AH completed after bid hook') end
    end)
    auctionHooked=true
  end
  if not sealedHooked and hooksecurefunc then
    if C_Container and C_Container.UseContainerItem then
      hooksecurefunc(C_Container,'UseContainerItem',onSealedUsed)
      sealedHooked=true
    elseif UseContainerItem then
      hooksecurefunc('UseContainerItem',onSealedUsed)
      sealedHooked=true
    end
  end
end
local function skinFrame(f)
  if not f.SetBackdrop then return end
  local theme=skin()
  local panel=f:GetParent()==UIParent
  f:SetBackdrop(panel and theme.backdrop or rows.flatBackdrop)
  f:SetBackdropColor(unpack(panel and theme.bg or theme.button))
  f:SetBackdropBorderColor(unpack(theme.edge))
  if panel and DB.solidWindows then
    if not f.writBacking then
      f.writBacking=f:CreateTexture(nil,'BACKGROUND',nil,-8)
      f.writBacking:SetAllPoints(f)
    end
    f.writBacking:SetColorTexture(0,0,0,1)
    f.writBacking:Show()
  elseif f.writBacking then f.writBacking:Hide() end
  if f.writSkinButton then
    local raised=(DB.skin=='authenticvanilla' or DB.skin=='wowlook') and f:GetWidth()>=40 and f:GetHeight()<=34
    if raised and not f.writRaised then
      f:SetNormalTexture('Interface\\Buttons\\UI-Panel-Button-Up')
      f:SetPushedTexture('Interface\\Buttons\\UI-Panel-Button-Down')
      f:GetNormalTexture():SetTexCoord(0,.625,0,.6875)
      f:GetPushedTexture():SetTexCoord(0,.625,0,.6875)
      f.writRaised=true
    end
    if f.writRaised then
      f:GetNormalTexture():SetAlpha(raised and 1 or 0)
      f:GetPushedTexture():SetAlpha(raised and 1 or 0)
    end
  end
  rows.skinFrames[f]=true
end
rows.flatBackdrop={bgFile='Interface\\Buttons\\WHITE8X8',edgeFile='Interface\\Buttons\\WHITE8X8',edgeSize=1}
rows.skinFrames=setmetatable({},{__mode='k'})
rows.skinText=setmetatable({},{__mode='k'})
rows.skinHeaders=setmetatable({},{__mode='k'})
rows.applySkin=function(key)
  local previous=skin()
  DB.skin=key
  local function matches(rgb,r,g,b)
    return math.abs(rgb[1]-r)<.005 and math.abs(rgb[2]-g)<.005 and math.abs(rgb[3]-b)<.005
  end
  for frame in pairs(rows.skinFrames) do
    local r,g,b,a=frame:GetBackdropBorderColor()
    skinFrame(frame)
    if not matches(previous.edge,r,g,b) then frame:SetBackdropBorderColor(r,g,b,a) end
  end
  for label in pairs(rows.skinText) do
    if matches(previous.text,label:GetTextColor()) then label:SetTextColor(unpack(skin().text)) end
  end
  for heading in pairs(rows.skinHeaders) do heading:SetColorTexture(unpack(skin().header)) end
end
local function textLine(parent,str,width,large)
  local l=parent:CreateFontString(nil,'OVERLAY',large and 'GameFontNormalLarge' or 'GameFontNormalSmall')
  l:SetText(str);l:SetJustifyH('LEFT')
  if width then l:SetWidth(width) end
  rows.skinText[l]=true
  l:SetTextColor(unpack(skin().text))
  return l
end
local function createButton(parent,title,width,height,fn)
  local b=CreateFrame('Button',nil,parent,BackdropTemplateMixin and 'BackdropTemplate')
  b:SetSize(width,height);b.writSkinButton=true;skinFrame(b)
  local t=textLine(b,title,nil,false);t:SetPoint('CENTER');t:SetJustifyH('CENTER');b.text=t
  b:SetScript('OnClick',fn)
  b:SetScript('OnEnter',function(self)
    if self.SetBackdropColor then self:SetBackdropColor(.20,.17,.12,.98) end
  end)
  b:SetScript('OnLeave',function(self)
    if self.SetBackdropColor then self:SetBackdropColor(unpack(skin().button)) end
  end)
  return b
end
local function position(f,key,dx,dy)
  local saved=DB[key] or {}
  f:ClearAllPoints()
  f:SetPoint('CENTER',UIParent,'CENTER',saved.x or dx,saved.y or dy)
end
local function savePosition(f,key)
  -- An embedded page has a host-relative anchor, not a standalone position.
  -- Preserve its classic-window position while tabbed mode is active.
  if DB and DB.experimentalTabbedUI and rows.experimentalTabs
    and rows.experimentalTabs.embedded[f] then return end
  local x,y=f:GetCenter()
  local cx,cy=UIParent:GetCenter()
  if x and y and cx and cy then DB[key]={x=x-cx,y=y-cy} end
end
local function makeDraggable(f,positionKey)
  positionKey=positionKey or 'mainPos'
  -- Only the TITLE area is draggable. v1.2's full-width drag overlay
  -- blocked clicks on the Start on Login checkbox.
  local grip=CreateFrame('Frame',nil,f)
  grip:SetPoint('TOPLEFT',8,-6);grip:SetSize(170,42)
  grip:EnableMouse(true);grip:RegisterForDrag('LeftButton')
  -- In experimental mode legacy panels are anchored inside the tab host.
  -- Their title grips must move the host, not the non-movable child.
  local moving
  grip:SetScript('OnDragStart',function()
    local target=f
    if DB and DB.experimentalTabbedUI and rows.experimentalTabs
      and rows.experimentalTabs.embedded[f] then
      target=rows.experimentalTabs.host
    end
    if target and target:IsMovable() then
      moving=target
      target:StartMoving()
    end
  end)
  grip:SetScript('OnDragStop',function()
    if not moving then return end
    moving:StopMovingOrSizing()
    savePosition(moving,moving==f and positionKey or 'experimentalTabsPos')
    moving=nil
  end)
end
local function makeResizable(f)
  f:SetResizable(true)
  local minHeight=DB.mainShowDetails==false and 350 or 500
  if f.SetResizeBounds then f:SetResizeBounds(580,minHeight,1000,1000)
  else
    if f.SetMinResize then f:SetMinResize(580,minHeight) end
    if f.SetMaxResize then f:SetMaxResize(1000,1000) end
  end
  local grip=CreateFrame('Button',nil,f)
  grip:SetSize(20,20);grip:SetPoint('BOTTOMRIGHT',-2,2)
  grip:SetFrameLevel(f:GetFrameLevel()+6)
  grip:SetNormalTexture('Interface\\ChatFrame\\UI-ChatIM-SizeGrabber-Up')
  grip:SetHighlightTexture('Interface\\ChatFrame\\UI-ChatIM-SizeGrabber-Highlight')
  grip:SetPushedTexture('Interface\\ChatFrame\\UI-ChatIM-SizeGrabber-Down')
  grip:SetScript('OnMouseDown',function()f:StartSizing('BOTTOMRIGHT')end)
  grip:SetScript('OnMouseUp',function()
    f:StopMovingOrSizing()
    DB.mainWidth=math.floor(f:GetWidth()+.5)
    DB.mainHeight=math.floor(f:GetHeight()+.5)
    if DB.mainShowDetails==false then DB.mainCompactHeight=DB.mainHeight
    else DB.mainExpandedHeight=DB.mainHeight end
    savePosition(f,'mainPos')
  end)
end
-- Auxiliary Writ This windows share one exclusive visibility group. Main/Mini
-- remain available as the navigation hub; independent Blizzard frames and the
-- informational mailbox alert do not participate. Hook OnShow rather than
-- replacing opener callbacks, so toolbar, minimap and /writ commands all work.
-- No SavedVariables are added: hiding a panel does not reset its current state.
-- Register the top-level addon windows with Blizzard's normal Escape close
-- stack.  Do not capture Escape with an OnKeyDown handler: UISpecialFrames
-- closes visible windows *before* the game menu can open, and leaves normal
-- Escape behaviour untouched when no Writ This window is visible.
-- Reusing the existing registration path covers lazily created popups too.
-- Single-Screen navigation is UI-only: this back stack is never written to
-- SavedVariables. Tracking, shared data, and the native WoW Game Menu are not
-- touched. In the original Multi-Screen mode the old popup rules still apply.
rows.navigation={screens={},history={},current=nil,busy=false}
rows.navigation.refreshButtons=function()
  for panel,info in pairs(rows.navigation.screens) do
    if info.back then
      info.back:SetShown(DB and DB.multiScreen==false and panel:IsShown())
    end
  end
end
rows.navigation.hideOthers=function(keep)
  local nav=rows.navigation
  nav.busy=true
  for panel in pairs(nav.screens) do
    if panel~=keep and panel:IsShown() then panel:Hide() end
  end
  nav.busy=false
end
rows.navigation.closeAll=function()
  local nav=rows.navigation
  nav.history={};nav.current=nil
  nav.hideOthers(nil)
  nav.refreshButtons()
end
rows.navigation.close=function(panel)
  if DB and DB.experimentalTabbedUI and rows.experimentalTabs then
    local tabs=rows.experimentalTabs
    if panel==window and tabs.host then tabs.host:Hide();return end
    if tabs.embedded and tabs.embedded[panel] then tabs.open('Tracking');return end
    if panel then panel:Hide();return end
  end
  if DB and DB.multiScreen==false then rows.navigation.closeAll()
  elseif panel then panel:Hide() end
end
rows.navigation.back=function()
  local nav=rows.navigation
  if not DB or DB.multiScreen~=false or nav.busy then return end
  local from=nav.current
  if not from then return end
  local target
  while #nav.history>0 do
    local candidate=table.remove(nav.history)
    if candidate and candidate~=from and nav.screens[candidate] then
      target=candidate;break
    end
  end
  if not target and from~=window and from~=miniWindow then
    target=DB.miniMode and miniWindow or window
  end
  if not target then nav.closeAll();return end
  nav.busy=true
  if from:IsShown() then from:Hide() end
  for panel in pairs(nav.screens) do
    if panel~=target and panel:IsShown() then panel:Hide() end
  end
  nav.current=target
  if not target:IsShown() then target:Show() end
  nav.busy=false
  nav.refreshButtons()
end
rows.navigation.activate=function(panel,isRoot)
  local nav=rows.navigation
  if not DB or DB.multiScreen~=false or nav.busy then return end
  if isRoot then
    nav.history={}
    nav.current=panel
  elseif nav.current~=panel then
    local previous=nav.current
    if not previous or not previous:IsShown() then
      previous=(window and window~=panel and window:IsShown() and window)
        or (miniWindow and miniWindow~=panel and miniWindow:IsShown() and miniWindow)
    end
    -- A popup opened through /writ directly still has Main as its Back target.
    if not previous then previous=DB.miniMode and miniWindow or window end
    if previous and previous~=panel then
      for i=#nav.history,1,-1 do
        if nav.history[i]==panel then table.remove(nav.history,i) end
      end
      nav.history[#nav.history+1]=previous
    end
    nav.current=panel
  end
  nav.hideOthers(panel)
  nav.refreshButtons()
end
rows.navigation.attach=function(panel,isRoot)
  local nav=rows.navigation
  if not panel or nav.screens[panel] then return end
  local info={root=isRoot}
  nav.screens[panel]=info
  if not isRoot then
    local back=createButton(panel,'< Back',54,23,function()nav.back()end)
    back:SetPoint('TOPRIGHT',-49,-12)
    back:Hide()
    info.back=back
  end
  panel:HookScript('OnHide',function(self)
    if DB and DB.multiScreen==false and not nav.busy and nav.current==self then
      -- UISpecialFrames hides a panel on Escape. Restore the prior screen;
      -- there is no OnKeyDown hook to taint WoW's own Escape handling.
      nav.back()
    end
  end)
  if isRoot then
    panel:HookScript('OnShow',function(self)nav.activate(self,true)end)
  end
end
rows.navigation.setMode=function(multi,currentPanel)
  local nav=rows.navigation
  if multi then
    nav.history={};nav.current=nil
    nav.refreshButtons()
    -- Restore the main hub immediately when re-enabling multiple screens.
    local home=DB.miniMode and miniWindow or window
    if home and currentPanel and currentPanel:IsShown() and not home:IsShown() then
      home:Show()
    end
  elseif currentPanel and currentPanel:IsShown() then
    nav.history={};nav.current=nil
    nav.activate(currentPanel,false)
  end
end
rows.registerEscapeWindow=function(panel)
  if not panel or not panel.GetName or not UISpecialFrames then return end
  local name=panel:GetName()
  if not name or name=='' then return end
  for _,existing in ipairs(UISpecialFrames) do
    if existing==name then
      if panel==window or panel==miniWindow then rows.navigation.attach(panel,true) end
      return
    end
  end
  UISpecialFrames[#UISpecialFrames+1]=name
  if panel==window or panel==miniWindow then rows.navigation.attach(panel,true) end
end
rows.popupWindows={}
rows.registerPopup=function(panel)
  if not panel or rows.popupWindows[panel] then return end
  rows.popupWindows[panel]=true
  rows.registerEscapeWindow(panel)
  rows.navigation.attach(panel,false)
  panel:HookScript('OnShow',function(self)
    if rows.navigation.busy then return end
    if DB and DB.experimentalTabbedUI and rows.experimentalTabs then
      local tabs=rows.experimentalTabs
      if tabs.switching or tabs.embedded[self] then return end
      if rows.switchingPopup then return end
      rows.switchingPopup=true
      -- Auxiliary popups may close each other but never the embedded page.
      for other in pairs(rows.popupWindows) do
        if other~=self and not tabs.embedded[other] and other:IsShown() then
          other:Hide()
        end
      end
      rows.switchingPopup=false
      return
    end
    if DB and DB.multiScreen==false then
      rows.navigation.activate(self,false)
      return
    end
    if rows.switchingPopup then return end
    rows.switchingPopup=true
    for other in pairs(rows.popupWindows) do
      if other~=self and other:IsShown() then other:Hide() end
    end
    rows.switchingPopup=false
  end)
end
-- v2.7.2 resale ledger: entirely separate from quest completion and pouch history.
-- All helpers live inside one scope to stay below Forever's top-level local limit.
local resale = (function()
  local frame, displayRows, pageNo = nil, {}, 1
  local manualSaleFrame, manualSaleEntry, manualSaleInput
  local mailRows, pendingMoney, moneyGains = {}, {}, {}
  local otherMailRows, pendingOtherMoney = {}, {}
  local pendingPosts = {}
  -- Trust live owned-auction IDs rather than treating stored IDs as proof of
  -- CURRENT listings. Two separate server updates are needed to correct an
  -- already linked record; the lists are never used to auto-delete records.
  local ownedRecent,ownedPrior=nil,nil
  local ownedRefreshDue,ownedRefreshAttempts,ownedLastRequest=nil,0,-999
  local postHooked, moneyHooked, autoMailHooked = false, false, false
  local function epoch() return time and time() or 0 end
  local function saleName(e) return e and (e.writ or '') or '' end
  -- Only genuine writ identities may enter the resale ledger. A plain
  -- "Golden Scale Coif" item sale must NEVER be confused with the writ
  -- "Craftsman's Writ: Golden Scale Coif".
  local function verifiedWritName(id,rawName)
    local recognized=recognize(id,rawName)
    if recognized then return recognized end
    local name=trim(rawName)
    for _,seal in pairs(SEALS) do
      if name~='' and trim(seal[1]):lower()==name:lower() then return seal[1] end
    end
    return nil
  end
  local function matched(e,id,rawName)
    if not e or e.complete or e.sold then return false end
    local official=verifiedWritName(id,rawName)
    if not official then return false end
    return trim(official):lower()==trim(saleName(e)):lower()
  end
  local function activeFor(id,name,requireListed)
    local candidate
    for _,e in ipairs(DB.orders or {}) do
      if matched(e,id,name) and (not requireListed or e.resaleListed or e.resaleReturnPending) then
        if e.resaleListed and e.resalePostings and e.resalePostings>0 then return e end
        candidate=candidate or e
      end
    end
    return candidate
  end
  local function recordPost(e,reason,pending)
    if not e or e.complete or e.sold or e.resaleListed or e.banked then return false end
    -- Reposts must get a NEW auction ID. A stale expired/cancelled ID would
    -- prevent a new owned-auction update from ever binding this record.
    if e.resaleAuctionID then
      local oldID=tostring(e.resaleAuctionID)
      if DB.resaleAuctionIDs and DB.resaleAuctionIDs[oldID]==e.id then
        DB.resaleAuctionIDs[oldID]=nil
      end
      e.resaleAuctionID=nil
    end
    e.resalePostings=(tonumber(e.resalePostings) or 0)+1
    e.resaleListed=true;e.resaleReturnPending=false;e.resaleListingStatus='Listed'
    e.resaleLastPostAt=datetime()
    e.resaleLastDeposit=nil
    if pending and tonumber(pending.deposit) and pending.deposit>0 then
      e.resaleLastDeposit=pending.deposit
    end
    if pending and pending.guid then e.bagGUID=pending.guid end
    if pending then pending.confirmed=true;pending.recordID=e.id;pending.postNumber=e.resalePostings end
    addLog('LISTED',e,'Posted # '..e.resalePostings..' ('..tostring(reason)..')')
    if refresh then refresh(true) end
    return true
  end
  local function findPostItemID(item)
    if type(item)=='table' or type(item)=='userdata' then
      if item.GetItemID then
        local ok,id=pcall(item.GetItemID,item);if ok and tonumber(id) then return tonumber(id) end
      end
      if item.GetBagAndSlot then
        local ok,bag,slot=pcall(item.GetBagAndSlot,item)
        if ok and tonumber(bag) and tonumber(slot) then return bagID(bag,slot) end
      end
    end
    if C_Item and C_Item.GetItemID then
      local ok,id=pcall(C_Item.GetItemID,item)
      if ok and tonumber(id) then return tonumber(id) end
    end
    return nil
  end
  local function recordDeposit(moneySpent)
    if moneySpent<=0 or not ahOpen then return end
    local candidate
    for _,p in ipairs(pendingPosts) do
      if clock()-p.at<7 then
        -- One wallet event can cover several postings. Never split or
        -- assign that debit to the most recent writ.
        if candidate then return end
        candidate=p
      end
    end
    if not candidate or candidate.deposit then return end
    candidate.deposit=moneySpent
    local e=candidate.recordID and entryByID(candidate.recordID)
    if e and e.resaleListed and e.resalePostings==candidate.postNumber then
      e.resaleLastDeposit=moneySpent
    end
    debugMessage('Resale deposit from single pending post wallet deduction: '..fmtMoney(moneySpent))
  end
  local function postCandidate(id,name,guid)
    local recentlyRemoved,bagged
    for _,e in ipairs(DB.orders or {}) do
      if not e.resaleListed and not e.complete and not e.sold and
         not e.banked and (not guid or not e.bagGUID or e.bagGUID==guid) and matched(e,id,name) then
        if guid and e.bagGUID==guid then return e end
        -- A copy that JUST left the bags is strongest evidence for a post.
        -- A banked copy or an older unseen/mail copy is NOT a candidate.
        if not e.bagPresent and e.writLostAt and clock()-e.writLostAt>=0 and
           clock()-e.writLostAt<35 then
          recentlyRemoved=recentlyRemoved or e
        elseif e.bagPresent then bagged=bagged or e end
      end
    end
    return recentlyRemoved or bagged
  end
  local function scheduleOwnedRefresh()
    if not ahOpen then return end
    local due=clock()+1.3
    if not ownedRefreshDue or ownedRefreshDue>due then ownedRefreshDue=due end
    ownedRefreshAttempts=math.max(ownedRefreshAttempts,2)
  end
  local function created()
    local best
    for _,p in ipairs(pendingPosts) do
      if not p.confirmed and clock()-p.at<20 and (not best or p.at<best.at) then best=p end
    end
    if best then
      local e=postCandidate(best.id,best.name,best.guid)
      if e then
        recordPost(e,'AH auction created',best)
      end
    end
    scheduleOwnedRefresh()
  end
  local function ownedUpdated(fromServerUpdate)
    if not C_AuctionHouse or not C_AuctionHouse.GetOwnedAuctions then return end
    local ok,auctions=pcall(C_AuctionHouse.GetOwnedAuctions)
    if not ok or type(auctions)~='table' then return end
    -- AH_SHOW can initially expose an old cache. Count snapshots only when
    -- WoW delivers OWNED_AUCTIONS_UPDATED, not when merely opening the AH.
    if fromServerUpdate and ahOpen then
      local snapshot={at=clock(),when=datetime(),ids={},count=0,names={},writIDs={}}
      for _,a in ipairs(auctions) do
        local aid=a.auctionID
        if aid and (not a.status or a.status==0) then
          snapshot.ids[tostring(aid)]=true
          snapshot.count=snapshot.count+1
          local itemID=a.itemKey and a.itemKey.itemID or idFromLink(a.itemLink)
          local itemName=a.itemLink and namedItem(a.itemLink) or getName(itemID)
          local resolved=verifiedWritName(itemID,itemName)
          if resolved then
            local key=resolved:lower()
            snapshot.names[key]=(snapshot.names[key] or 0)+1
            snapshot.writIDs[key]=snapshot.writIDs[key] or {}
            snapshot.writIDs[key][#snapshot.writIDs[key]+1]=tostring(aid)
          end
        end
      end
      if not ownedRecent or snapshot.at-ownedRecent.at>=2 then
        ownedPrior=ownedRecent
      end
      ownedRecent=snapshot
      local identities={}
      for aid in pairs(snapshot.ids) do identities[#identities+1]=aid end
      table.sort(identities)
      debugMessage('Owned-auctions update: '..snapshot.count..' active IDs ['..table.concat(identities,', ')..']')
    end
    DB.resaleAuctionIDs=DB.resaleAuctionIDs or {}
    for _,a in ipairs(auctions) do
      local aid=a.auctionID
      local id=a.itemKey and a.itemKey.itemID or idFromLink(a.itemLink)
      local name=a.itemLink and namedItem(a.itemLink) or getName(id)
      if aid and (not a.status or a.status==0) then
        local mappedID=DB.resaleAuctionIDs[tostring(aid)]
        local known=mappedID and entryByID(mappedID)
        if known and matched(known,id,name) then
          -- Repair a saved record whose AH confirmation was observed earlier,
          -- but whose current listed flag was not set (no duplicate posting).
          if not known.resaleListed and known.resaleListingStatus~='Expired' and
             known.resaleListingStatus~='Cancelled' then
            known.resaleListed=true;known.resaleReturnPending=false
            known.resaleListingStatus='Listed'
            if refresh then refresh(true) end
          end
        elseif not mappedID then
          -- The creation callback may already have marked this writ as
          -- listed. Attach the auction ID to it before looking for another
          -- unlisted copy, or two copies could be counted for one post.
          local e
          for _,entry in ipairs(DB.orders or {}) do
            if entry.resaleListed and not entry.resaleAuctionID and
               not entry.banked and matched(entry,id,name) then e=entry;break end
          end
          if not e then e=postCandidate(id,name) end
          if e then
            DB.resaleAuctionIDs[tostring(aid)]=e.id
            if not e.resaleListed then
              local matchingPending
              for _,p in ipairs(pendingPosts) do
                if not p.confirmed and clock()-p.at<20 and
                   (not p.guid or not e.bagGUID or p.guid==e.bagGUID) and matched(e,p.id,p.name) then matchingPending=p;break end
              end
              -- Owned-auction evidence is authoritative even if the bag
              -- event has not yet removed the item.
              recordPost(e,'Confirmed owned auction',matchingPending)
            end
            e.resaleAuctionID=aid
          end
        end
      end
    end
    -- Repair a stale auction ID only where TWO spaced server snapshots agree
    -- on a SINGLE current listing and the local ledger has exactly ONE copy
    -- of this writ. Ambiguous duplicate writs must never be silently linked.
    if fromServerUpdate and ahOpen and ownedPrior and ownedRecent and
       ownedRecent.at-ownedPrior.at>=2 and clock()-ownedPrior.at<=180 and
       ownedRecent.count>0 and ownedPrior.count>0 then
      for key,nowIDs in pairs(ownedRecent.writIDs or {}) do
        local beforeIDs=ownedPrior.writIDs and ownedPrior.writIDs[key]
        if #nowIDs==1 and beforeIDs and #beforeIDs==1 and nowIDs[1]==beforeIDs[1] then
          local newID=nowIDs[1]
          if not DB.resaleAuctionIDs[newID] then
            local candidate,copies=nil,0
            for _,entry in ipairs(DB.orders or {}) do
              if not entry.complete and not entry.sold and saleName(entry):lower()==key then
                copies=copies+1
                if entry.resaleListed and not entry.banked and entry.resaleAuctionID then
                  candidate=entry
                end
              end
            end
            if copies==1 and candidate then
              local oldID=tostring(candidate.resaleAuctionID)
              if oldID~=newID and not ownedRecent.ids[oldID] and not ownedPrior.ids[oldID] then
                if DB.resaleAuctionIDs[oldID]==candidate.id then
                  DB.resaleAuctionIDs[oldID]=nil
                end
                candidate.resaleAuctionID=tonumber(newID) or newID
                DB.resaleAuctionIDs[newID]=candidate.id
                candidate.resaleListingStatus='Listed'
                addLog('AUCTION ID RELINK',candidate,'Two owned-auction snapshots matched unique writ: '..oldID..' -> '..newID..'; no new post/deposit')
                debugMessage('Safely relinked writ #'..tostring(candidate.id)..' AH '..oldID..' -> '..newID..' (unique live listing; no additional posting)')
                if refresh then refresh(true) end
              end
            end
          end
        end
      end
    end
  end
  local function expire(e,reason,deposit)
    if not e or e.sold or e.complete or not e.resaleListed then return false end
    e.resaleListed=false;e.resaleReturnPending=true
    e.resaleListingStatus=reason
    if reason=='Expired' then e.resaleExpirations=(tonumber(e.resaleExpirations) or 0)+1
    else e.resaleCancels=(tonumber(e.resaleCancels) or 0)+1 end
    local paid=tonumber(deposit) or tonumber(e.resaleLastDeposit)
    if paid and paid>=0 then
      e.resaleLostDeposits=(tonumber(e.resaleLostDeposits) or 0)+paid
    else
      e.resaleUnknownDeposits=(tonumber(e.resaleUnknownDeposits) or 0)+1
    end
    e.resaleLastDeposit=nil
    addLog(string.upper(reason),e,reason..' listing; lost deposit '..(paid and fmtMoney(paid) or 'not verified'))
    if refresh then refresh(true) end
    return true
  end
  local function saleCandidate(name,reserved)
    for _,e in ipairs(DB.orders or {}) do
      if not (reserved and reserved[e.id]) and e.resaleListed and matched(e,nil,name) then
        return e
      end
    end
    return nil
  end
  local function saleProfitFromRecord(e)
    -- A SOLD WRIT is a separate transaction from the required crafting item.
    -- Only count the writ acquisition, actual net AH proceeds (fee already
    -- deducted), and confirmed lost posting deposits. Materials may be sold
    -- independently and must not distort this sale's result. Unknown item
    -- costs must not prevent a verified writ-only resale calculation.
    -- Recalculate archived rows from their original components on display;
    -- do not overwrite old SavedVariables or cached legacy profit fields.
    if not e or e.priceUnknown then return nil end
    local price=tonumber(e.writCost)
    local proceeds=tonumber(e.resaleNetProceeds)
    if not price or not proceeds then return nil end
    local lost=math.max(0,tonumber(e.resaleLostDeposits) or 0)
    return proceeds-math.max(0,price)-lost
  end
  local function archiveSale(p,received,isManual)
    local e=entryByID(p.recordID)
    if not e or e.complete or e.sold then return false end
    -- The header money is collected cash, including any refunded current deposit.
    -- Seller invoice bid is the sale's gross amount, not the buyout ask.
    local gross=tonumber(p.bid)
    if not gross or gross<=0 then gross=tonumber(p.buyout) end
    local fee=tonumber(p.consignment)
    local refund=tonumber(p.deposit)
    if refund==nil and not isManual then refund=tonumber(e.resaleLastDeposit) end
    local proceeds
    if gross and gross>0 and fee and fee>=0 then
      proceeds=gross-fee
    elseif refund and received>=refund then
      proceeds=received-refund
    end
    -- Do not silently treat an unknown refundable deposit as revenue.
    if not proceeds then
      debugMessage('Seller mail collected but net proceeds cannot be verified for '..tostring(e.writ))
      e.resaleUnverifiedCash=received
      return false
    end
    proceeds=math.max(0,math.floor(proceeds+.5))
    e.sold=true;e.soldAt=datetime();e.soldEpoch=epoch()
    e.resaleManual=not not isManual
    e.resaleListed=false;e.resaleListingStatus='Sold'
    e.resaleGrossPrice=gross;e.resaleAHFee=fee
    e.resaleDepositRefund=refund;e.resaleCollected=(not isManual) and received or nil
    e.resaleNetProceeds=proceeds
    e.resaleEstimatedProfit=saleProfitFromRecord(e)
    e.resaleFinalProfit=(not isManual and (tonumber(e.resaleUnknownDeposits) or 0)==0) and e.resaleEstimatedProfit or nil
    DB.soldWrits=DB.soldWrits or {}
    table.insert(DB.soldWrits,e)
    for i=#DB.orders,1,-1 do
      if DB.orders[i].id==e.id then table.remove(DB.orders,i);break end
    end
    if selectedID==e.id then selectedID=nil;DB.selectedID=nil end
    addLog(isManual and 'SOLD MANUAL' or 'SOLD',e,
      (isManual and 'User-entered gross sale (5% fee estimate): ' or 'Auction mail collected: ')..
      fmtMoney(isManual and gross or received)..'; net resale '..fmtMoney(proceeds))
    local calculated=e.resaleFinalProfit or e.resaleEstimatedProfit
    say('Sold '..e.writ..': '..(calculated and
      ((isManual and 'estimated ' or '')..(calculated>=0 and 'profit ' or 'loss ')..fmtMoney(math.abs(calculated))) or 'purchase price unknown')..
      ' | posted '..tostring(e.resalePostings or 0)..' times.')
    if refresh then refresh(true) end
    return true
  end
  -- Mail addons often collect several seller payments as one wallet increase.
  -- Only settle receipts whose individual mail amounts sum to the exact observed
  -- gain. A simultaneous unrelated payment is never guessed or assigned.
  local function canArchiveSale(p)
    local e=entryByID(p.recordID)
    if not e or e.complete or e.sold then return false end
    local gross=tonumber(p.bid)
    if not gross or gross<=0 then gross=tonumber(p.buyout) end
    local fee=tonumber(p.consignment)
    local refund=tonumber(p.deposit)
    if refund==nil then refund=tonumber(e.resaleLastDeposit) end
    return (gross and gross>0 and fee and fee>=0) or
      (refund and tonumber(p.money) and p.money>=refund)
  end
  local function trySettle()
    local now=clock()
    -- Prune old expectations; never archive a sale from a stale event.
    for i=#pendingMoney,1,-1 do
      local p=pendingMoney[i]
      if p.done or now-p.at>35 or not entryByID(p.recordID) then
        table.remove(pendingMoney,i)
      end
    end
    for i=#pendingOtherMoney,1,-1 do
      if pendingOtherMoney[i].done or now-pendingOtherMoney[i].at>35 then
        table.remove(pendingOtherMoney,i)
      end
    end
    for i=#moneyGains,1,-1 do
      local gain=moneyGains[i]
      if not gain.used and now-gain.at<20 then
        -- Exact one-mail payment first: ordinary collection behavior.
        for _,p in ipairs(pendingMoney) do
          if not p.done and canArchiveSale(p) and
             math.abs((tonumber(p.money) or -100)-gain.amount)<=1 and
             math.abs(gain.at-p.at)<12 then
            if archiveSale(p,gain.amount) then p.done=true;gain.used=true;break end
          end
        end
        if not gain.used then
          local eligible={}
          for _,p in ipairs(pendingMoney) do
            if not p.done and canArchiveSale(p) and
               math.abs(gain.at-p.at)<12 and tonumber(p.money) and p.money>0 then
              eligible[#eligible+1]=p
            end
          end
          -- Prefer an exact match of all seller mails, the usual Collect All case.
          local batch,sum={},0
          for _,p in ipairs(eligible) do batch[#batch+1]=p;sum=sum+p.money end
          local extras={}
          if #batch>=1 then
            for _,p in ipairs(pendingOtherMoney) do
              if not p.done and math.abs(p.at-gain.at)<12 and tonumber(p.money) and p.money>0 then
                extras[#extras+1]=p
              end
            end
          end
          local extraSum=0
          for _,other in ipairs(extras) do extraSum=extraSum+other.money end
          if #batch<2 or math.abs(sum-gain.amount)>1 then
            if #batch>=1 and #extras>=1 and math.abs(sum+extraSum-gain.amount)<=1 then
              -- Collect All also took ordinary gold mail. The exact combined
              -- total validates writ payments without treating other mail as sales.
            else
              batch=nil;extras={}
              -- A subset match is only safe when UNIQUE. A coincidental equal
              -- sum must not silently reassign another writ's actual price.
              if #eligible>=2 and #eligible<=12 then
                local found,matches=nil,0
                local function findSubset(i,total,picked)
                  if matches>1 or total>gain.amount+1 then return end
                  if i>#eligible then
                    if #picked>=2 and math.abs(total-gain.amount)<=1 then
                      matches=matches+1
                      found={};for _,p in ipairs(picked) do found[#found+1]=p end
                    end
                    return
                  end
                  picked[#picked+1]=eligible[i]
                  findSubset(i+1,total+eligible[i].money,picked)
                  picked[#picked]=nil
                  findSubset(i+1,total,picked)
                end
                findSubset(1,0,{})
                if matches==1 then batch=found end
              end
            end
          end
          if batch then
            local settled=0
            for _,p in ipairs(batch) do
              if archiveSale(p,p.money) then p.done=true;settled=settled+1 end
            end
            if settled==#batch then
              for _,other in ipairs(extras) do other.done=true end
              gain.used=true
              debugMessage('Collect All: archived '..settled..' verified writ sale mails from one gold gain.')
            end
          end
        end
      end
    end
    for i=#pendingMoney,1,-1 do if pendingMoney[i].done then table.remove(pendingMoney,i) end end
    for i=#moneyGains,1,-1 do
      if now-moneyGains[i].at>20 or moneyGains[i].used then table.remove(moneyGains,i) end
    end
  end
  local function queuePickup(c)
    if not c or not c.recordID or not c.mailKey then return end
    for _,p in ipairs(pendingMoney) do
      if p.mailKey==c.mailKey and not p.done then return end
    end
    pendingMoney[#pendingMoney+1]={recordID=c.recordID,at=clock(),mailKey=c.mailKey,
      money=c.money,bid=c.bid,buyout=c.buyout,deposit=c.deposit,consignment=c.consignment}
  end
  local function queueOther(c)
    if not c or not c.mailKey or not tonumber(c.money) or c.money<=0 then return end
    for _,p in ipairs(pendingOtherMoney) do
      if p.mailKey==c.mailKey and not p.done then return end
    end
    pendingOtherMoney[#pendingOtherMoney+1]={mailKey=c.mailKey,money=c.money,at=clock()}
  end
  local function expectTake(index)
    local c=mailRows[tonumber(index)]
    if c then queuePickup(c)
    else queueOther(otherMailRows[tonumber(index)]) end
    trySettle()
  end
  local function scanMail()
    if not mailOpen or not GetInboxNumItems or not GetInboxHeaderInfo then return end
    local ok,n=pcall(GetInboxNumItems)
    if not ok or type(n)~='number' then return end
    local old=mailRows
    local oldOther=otherMailRows
    local fresh={}
    local freshOther={}
    local seenThisScan={}
    local reservedRecords={}
    DB.resaleReturnsSeen=DB.resaleReturnsSeen or {}
    for i=1,math.min(n,300) do
      local good,icon,stationery,sender,subject,money,cod,daysLeft,hasItem=pcall(GetInboxHeaderInfo,i)
      if good then
        subject=tostring(subject or '')
        local lower=subject:lower()
        local isAuction=(tostring(sender or ''):lower():find('auction',1,true) or lower:find('auction',1,true))
        local inv,invoiceName,player,bid,buyout,deposit,consignment
        if GetInboxInvoiceInfo then
          local o; o,inv,invoiceName,player,bid,buyout,deposit,consignment=pcall(GetInboxInvoiceInfo,i)
          if not o then inv=nil end
        end
        if isAuction and inv=='seller' and (tonumber(money) or 0)>0 then
          local saleItem=verifiedWritName(nil,invoiceName)
          if not saleItem then
            local qualified=subject:match("([Cc]raftsman'?s [Ww]rit:%s*.+)")
            saleItem=qualified and verifiedWritName(nil,qualified) or nil
          end
          local e=saleItem and saleCandidate(saleItem,reservedRecords) or nil
          if e then
            reservedRecords[e.id]=true
            local expires=math.floor((epoch()+(tonumber(daysLeft) or 30)*86400)/1800+.5)
            local mailKey=table.concat({tostring(invoiceName or ''),subject,tostring(money),tostring(bid),tostring(expires)},'|')
            seenThisScan[mailKey]=(seenThisScan[mailKey] or 0)+1
            mailKey=mailKey..'|'..seenThisScan[mailKey]
            fresh[i]={recordID=e.id,mailKey=mailKey,money=tonumber(money),bid=bid,buyout=buyout,
                      deposit=deposit,consignment=consignment}
          end
        elseif isAuction and (lower:find('expired',1,true) or lower:find('cancelled',1,true) or lower:find('canceled',1,true)) and hasItem then
          local id,name
          if GetInboxItem then
            local io,rawName,rawID=pcall(GetInboxItem,i,1)
            if io then id=tonumber(rawID);name=rawName end
          end
          if GetInboxItemLink then
            local lo,link=pcall(GetInboxItemLink,i,1)
            if lo and link then id=id or idFromLink(link);name=namedItem(link) or name end
          end
          local e=activeFor(id,name,true)
          if e then
            local expires=math.floor((epoch()+(tonumber(daysLeft) or 30)*86400)/1800+.5)
            local base=table.concat({tostring(id or ''),tostring(name),subject,tostring(expires)},'|')
            seenThisScan[base]=(seenThisScan[base] or 0)+1
            local key=base..'|'..seenThisScan[base]
            if not DB.resaleReturnsSeen[key] then
              DB.resaleReturnsSeen[key]=true
              -- A zero in return mail is not proof of a free posting.
              local mailDeposit=tonumber(deposit)
              expire(e,lower:find('expired',1,true) and 'Expired' or 'Cancelled',
                mailDeposit and mailDeposit>0 and mailDeposit or nil)
            end
          end
        end
        -- Preserve positive-money NON-writ mail separately. It is never a
        -- sold writ, but may be part of the same bulk wallet increase.
        if (tonumber(money) or 0)>0 and not fresh[i] then
          local expires=math.floor((epoch()+(tonumber(daysLeft) or 30)*86400)/1800+.5)
          local base=table.concat({'OTHER',tostring(sender),subject,tostring(money),tostring(expires)},'|')
          seenThisScan[base]=(seenThisScan[base] or 0)+1
          freshOther[i]={mailKey=base..'|'..seenThisScan[base],money=tonumber(money)}
        end
      end
    end
    -- If mail vanishes and the matching gold gain arrives, this also handles
    -- bulk-collect mail addons that bypass TakeInboxMoney.
    for _,prior in pairs(old) do
      local still=false
      for _,current in pairs(fresh) do if current.mailKey==prior.mailKey then still=true;break end end
      if not still then
        local tracked=entryByID(prior.recordID)
        if tracked and not tracked.sold then
          queuePickup(prior)
        end
      end
    end
    for _,prior in pairs(oldOther) do
      local still=false
      for _,current in pairs(freshOther) do
        if current.mailKey==prior.mailKey then still=true;break end
      end
      if not still then queueOther(prior) end
    end
    mailRows=fresh
    otherMailRows=freshOther
    trySettle()
  end
  local function onMoneyChange(amount)
    if amount>0 and (mailOpen or #pendingMoney>0) then
      moneyGains[#moneyGains+1]={amount=amount,at=clock()}
      trySettle()
    elseif amount<0 then recordDeposit(-amount) end
  end
  local function onEvent(event,...)
    if event=='AUCTION_HOUSE_AUCTION_CREATED' then created()
    elseif event=='OWNED_AUCTIONS_UPDATED' then ownedUpdated(true)
    elseif event=='AUCTION_HOUSE_SHOW' then
      ownedRecent=nil;ownedPrior=nil
      ownedUpdated(false)
    elseif event=='AUCTION_HOUSE_CLOSED' then
      ownedRecent=nil;ownedPrior=nil
      ownedRefreshDue=nil;ownedRefreshAttempts=0
    elseif event=='MAIL_SHOW' or event=='MAIL_INBOX_UPDATE' then scanMail()
    elseif event=='MAIL_CLOSED' then mailRows={};otherMailRows={} end
    -- Sales and turn-ins do not share any triggers or archive collections.
  end
  local function installHooks()
    if not postHooked and C_AuctionHouse and C_AuctionHouse.PostItem and hooksecurefunc then
      hooksecurefunc(C_AuctionHouse,'PostItem',function(item,duration,quantity,bid,buyout)
        local id=findPostItemID(item)
        local name=id and getName(id)
        local writ=recognize(id,name)
        if writ then
          local quote
          if C_AuctionHouse.CalculateItemDeposit then
            local ok,cost=pcall(C_AuctionHouse.CalculateItemDeposit,item,duration,quantity)
            if ok and type(cost)=='number' and cost>0 then quote=cost end
          end
          local guid
          if C_Item and C_Item.GetItemGUID then
            local ok,value=pcall(C_Item.GetItemGUID,item)
            if ok and type(value)=='string' and value~='' then guid=value end
          end
          pendingPosts[#pendingPosts+1]={at=clock(),guid=guid,id=id,name=writ,quantity=quantity,deposit=quote}
          scheduleOwnedRefresh()
          debugMessage('Resale post attempted for '..writ..'; waiting for confirmation')
        end
      end)
      postHooked=true
    end
    if not moneyHooked and TakeInboxMoney and hooksecurefunc then
      hooksecurefunc('TakeInboxMoney',function(index) expectTake(index) end)
      moneyHooked=true
    end
    if not autoMailHooked and AutoLootMailItem and hooksecurefunc then
      hooksecurefunc('AutoLootMailItem',function(index) expectTake(index) end)
      autoMailHooked=true
    end
  end
  local function manualPosted(e,deposit)
    if not e or e.complete or e.sold then say('Select an active writ first.');return end
    if not recordPost(e,'Manual posting correction') then return end
    e.resaleLastDeposit=deposit
    say('Marked as posted # '..tostring(e.resalePostings))
  end
  local function manualReturn(e,kind,deposit)
    if not e or not e.resaleListed then say('Select a listed writ first.');return end
    expire(e,kind,deposit)
    say('Recorded '..kind:lower()..' listing; writ stays active for reposting.')
  end
  local function ownedEvidence(e)
    if not e or not e.resaleAuctionID then return 'NO_LINK' end
    local aid=tostring(e.resaleAuctionID)
    if not ahOpen or not ownedRecent or clock()-ownedRecent.at>120 then return 'NOT_CHECKED' end
    if ownedRecent.ids[aid] then return 'ACTIVE' end
    if not ownedPrior or ownedRecent.at-ownedPrior.at<2 or
       clock()-ownedPrior.at>180 then return 'CHECK_AGAIN' end
    if ownedPrior.ids[aid] then return 'CHECK_AGAIN' end
    -- Some client builds briefly return empty/partial owner lists. Requiring
    -- other live auctions of THIS writ in both snapshots avoids using an
    -- unrelated or incompletely populated list as permission to unlink.
    local key=(e.writ or ''):lower()
    if ownedRecent.count==0 or ownedPrior.count==0 or
       (ownedRecent.names[key] or 0)==0 or (ownedPrior.names[key] or 0)==0 then
      return 'AH_DATA_INCOMPLETE'
    end
    return 'MISSING_TWICE'
  end
  local function inspectPosts(query)
    local needle=trim(query):lower()
    local selectedEntry=selected()
    local rowsFound=0
    local state=ownedRecent and ('last owned update '..ownedRecent.when..', '..ownedRecent.count..' auctions')
      or 'no live owned-auctions snapshot (open AH; /writ syncposts)'
    say('Posting audit: '..state..'. Selected record ID: '..tostring(selectedEntry and selectedEntry.id or 'none'))
    for _,e in ipairs(DB.orders or {}) do
      local hit=(needle~='' and ((e.writ or ''):lower():find(needle,1,true) or tostring(e.id)==needle)) or
        (needle=='' and e.resaleListed)
      if hit then
        rowsFound=rowsFound+1
        local evidence=ownedEvidence(e)
        say(('#%s %s | %s | bank=%s bag=%s | auction=%s | ID check=%s'):format(
          tostring(e.id),(e.writ or 'Unknown'):gsub("^Craftsman's Writ:%s*",''),
          e.resaleListed and 'POSTED' or 'ACTIVE',tostring(e.banked==true),
          tostring(e.bagPresent==true),tostring(e.resaleAuctionID or 'none'),evidence))
      end
    end
    if rowsFound==0 then say('No writs found for that search.') end
    if rowsFound>12 then say('Many matching records. Narrow the search with /writ inspectposts Phoenix Pants.') end
  end
  local function manualUnpost(e,expectedID)
    -- Target the explicit saved record ID, not the selected row. These are
    -- different numbers when identical writs are shown in sorted Posted rows.
    local requested=entryByID(tonumber(expectedID))
    if not requested or not requested.resaleListed then
      say('No change: record #'..tostring(expectedID)..' is missing or not Posted. Run /writ inspectposts first.');return false
    end
    e=requested
    local link=e.resaleAuctionID and tostring(e.resaleAuctionID)
    if link then
      local evidence=ownedEvidence(e)
      if evidence~='MISSING_TWICE' then
        say('No change for #'..e.id..' (AH '..link..'): '..evidence..
          '. Open the AH, run /writ syncposts and inspect the actual Active Auctions twice before retrying.');return false
      end
      -- A missing OLD ID plus a matching NEW, unbound live ID can mean this
      -- very writ was reposted. Do not turn a genuine listing into Active.
      if not e.banked and ownedRecent and ownedRecent.writIDs then
        local current=ownedRecent.writIDs[saleName(e):lower()] or {}
        for _,newID in ipairs(current) do
          if newID~=link and not (DB.resaleAuctionIDs and DB.resaleAuctionIDs[newID]) then
            say('No change for #'..e.id..': a live matching auction '..newID..
              ' has no writ link. This may need AH ID relinking, not unposting. Run /writ syncposts again.');return false
          end
        end
      end
      debugMessage('Manual false-post correction for #'..e.id..' after TWO missing owned-auction snapshots; old AH ID '..link)
      if DB.resaleAuctionIDs and DB.resaleAuctionIDs[link]==e.id then DB.resaleAuctionIDs[link]=nil end
      e.resaleAuctionID=nil
    end
    e.resaleListed=false
    e.resaleReturnPending=false
    e.resaleListingStatus='Corrected false posting'
    e.resaleLastDeposit=nil -- A false posting is not an expired auction.
    e.resaleLastPostAt=nil
    e.resalePostings=math.max(0,(tonumber(e.resalePostings) or 0)-1)
    addLog('UNPOST CORRECTION',e,'Explicit correction; prior AH ID '..tostring(link or 'none')..
      ' | '..(link and 'two owned-auction snapshots excluded this ID' or 'no owned ID')..
      ' | no imaginary lost deposit')
    say('Corrected false Posted marker for #'..e.id..'. No lost deposit invented; writ cost/bank status preserved.')
    if refresh then refresh() end
    return true
  end
  local function requestOwnedSync()
    if not ahOpen then
      say('Open the Auction House, then /writ syncposts to refresh your owned auctions.');return false
    end
    if not C_AuctionHouse or type(C_AuctionHouse.QueryOwnedAuctions)~='function' then
      say('This client cannot query owned auctions from Writ This. Open the AH Active Auctions tab.');return false
    end
    -- Throw away previous evidence so two new server responses must arrive.
    ownedRecent=nil;ownedPrior=nil
    ownedRefreshAttempts=2
    ownedRefreshDue=clock()
    say('Requesting two spaced owned-auction refreshes. Use /writ inspectposts Phoenix Pants to inspect live IDs.')
    return true
  end
  -- Manual recovery for seller mails already removed by Collect All.
  -- User enters GROSS sale value; the AH fee is a labeled 5% estimate.
  -- No phantom mail income or refundable deposits are invented.
  local function possibleReceipt(target,gross,when)
    local found
    for _,r in ipairs(DB.soldWrits or {}) do
      if r.id~=target.id and not r.resaleManual and r.resaleCollected and (r.priceUnknown or tonumber(r.writCost)==nil)
        and sameWritName(r.writ,target.writ) and r.soldEpoch and when>=r.soldEpoch and when-r.soldEpoch<=86400
        and not (target.bagGUID and r.bagGUID and target.bagGUID~=r.bagGUID)
        and (math.abs((r.resaleGrossPrice or -100)-gross)<=1 or
          math.abs((r.resaleNetProceeds or -100)-(gross-math.floor(gross*.05+.5)))<=1) then
        if found then return nil,true end
        found=r
      end
    end
    return found
  end
  local function linkReceipt(target,receipt,list)
    if target.priceUnknown or not tonumber(target.writCost) or (not receipt.priceUnknown and tonumber(receipt.writCost)~=nil) then return false end
    local index
    for i,row in ipairs(list) do if row==target then index=i;break end end
    if not index then return false end
    -- Keep the original rows for audit. Both histories can contain the same posting.
    receipt.linkedWritRecord=target
    receipt.beforeLink={postings=receipt.resalePostings,lost=receipt.resaleLostDeposits,
      unknown=receipt.resaleUnknownDeposits,acquired=receipt.acquired,writCost=receipt.writCost}
    receipt.writCost=target.writCost;receipt.priceUnknown=false;receipt.acquired=target.acquired
    receipt.priceSource=target.priceSource;receipt.bagGUID=receipt.bagGUID or target.bagGUID
    for _,field in ipairs({'resalePostings','resaleLostDeposits','resaleUnknownDeposits'}) do
      receipt[field]=math.max(tonumber(receipt[field]) or 0,tonumber(target[field]) or 0)
    end
    receipt.resaleEstimatedProfit=saleProfitFromRecord(receipt)
    receipt.resaleFinalProfit=receipt.resaleUnknownDeposits==0 and receipt.resaleEstimatedProfit or nil
    table.remove(list,index)
    if selectedID==target.id then selectedID=nil;DB.selectedID=nil end
    addLog('SALE LINK',receipt,'User linked record #'..target.id..' to this collected seller payment')
    if refresh then refresh() end
    say('Linked '..receipt.writ..' to its collected payment of '..fmtMoney(receipt.resaleNetProceeds)..' net.')
    return true
  end
  local function repairSale(name)
    local target,receipt
    for _,e in ipairs(DB.soldWrits or {}) do
      if e.resaleManual and not e.priceUnknown and e.resaleGrossPrice and e.soldEpoch and sameWritName(name,e.writ) then
        local match,ambiguous=possibleReceipt(e,e.resaleGrossPrice,e.soldEpoch)
        if ambiguous or (match and target) then say('Multiple possible pairs. No change made.');return end
        if match then target=e;receipt=match end
      end
    end
    if not target then say('No matching manual sale and unpriced payment for '..name..'.');return end
    if not StaticPopupDialogs or not StaticPopup_Show then say('Sale confirmation unavailable.');return end
    StaticPopupDialogs.WRITTHIS_LINK_RECEIPT={
      text='Count these as one sale?\n%s',button1='Link sale',button2='Cancel',
      timeout=0,whileDead=true,hideOnEscape=true,
      OnAccept=function(_,pair)
        local e,r=pair[1],pair[2]
        if possibleReceipt(e,e.resaleGrossPrice,e.soldEpoch)==r then linkReceipt(e,r,DB.soldWrits) end
      end}
    StaticPopup_Show('WRITTHIS_LINK_RECEIPT',target.writ..'\nManual #'..target.id..' ('..fmtMoney(target.resaleNetProceeds)..') + mail #'..
      receipt.id..' ('..fmtMoney(receipt.resaleNetProceeds)..')',nil,{target,receipt})
  end
  local function openManualSale(e)
    if not e or e.sold or e.complete then
      say('Select a writ that has not already been sold or completed.')
      return
    end
    if not manualSaleFrame then
      local f=CreateFrame('Frame','WritThisManualSaleFrame',UIParent,
        BackdropTemplateMixin and 'BackdropTemplate')
      f:SetSize(430,238);f:SetFrameStrata('DIALOG');f:SetMovable(true)
      f:EnableMouse(true);f:SetClampedToScreen(true)
      f:SetPoint('CENTER',UIParent,'CENTER',0,45)
      skinFrame(f);makeDraggable(f,'manualSalePosition')
      local title=textLine(f,'RECORD WRIT SALE',390,true)
      title:SetPoint('TOPLEFT',16,-15)
      createButton(f,'X',26,25,function()rows.navigation.close(f)end):SetPoint('TOPRIGHT',-12,-10)
      local name=textLine(f,'',392)
      name:SetPoint('TOPLEFT',16,-51);f.name=name
      local label=textLine(f,'Gross selling price (e.g. 1g25s):',390)
      label:SetPoint('TOPLEFT',16,-79)
      local input=CreateFrame('EditBox',nil,f,'InputBoxTemplate')
      input:SetSize(180,25);input:SetPoint('TOPLEFT',26,-101)
      input:SetAutoFocus(false);input:SetMaxLetters(30);manualSaleInput=input
      local hint=textLine(f,'5% AH fee estimated. Deposit refunds excluded. Result marked estimated.',390)
      hint:SetPoint('TOPLEFT',16,-139)
      if hint.SetFont then hint:SetFont(STANDARD_TEXT_FONT or 'Fonts\\FRIZQT__.TTF',10) end
      local confirm=createButton(f,'Record Sale',125,27,function()
        local target=manualSaleEntry and entryByID(manualSaleEntry)
        if not target or target.sold or target.complete then say('Writ no longer active.');f:Hide();return end
        local gross=parseMoney(input:GetText())
        if not gross or gross<=0 then say('Enter a valid sale price such as 42s50c.');return end
        local fee=math.floor(gross*.05+.5)
        local receipt,ambiguous=possibleReceipt(target,gross,epoch())
        if (receipt or ambiguous) and not (IsShiftKeyDown and IsShiftKeyDown()) then
          if receipt and not target.priceUnknown and StaticPopupDialogs and StaticPopup_Show then
            StaticPopupDialogs.WRITTHIS_MANUAL_EXISTING={
              text='A matching payment is already in Sold Writs. Link this writ to it?\n%s\nFor a separate sale, cancel and Shift-click Record Sale.',
              button1='Link payment',button2='Cancel',timeout=0,whileDead=true,hideOnEscape=true,
              OnAccept=function(_,pair)
                if possibleReceipt(pair[1],pair[3],epoch())==pair[2] and linkReceipt(pair[1],pair[2],DB.orders) then f:Hide() end
              end}
            StaticPopup_Show('WRITTHIS_MANUAL_EXISTING',target.writ..'  '..fmtMoney(receipt.resaleNetProceeds)..' net',nil,{target,receipt,gross})
          else hint:SetText('Possible existing payment. Shift-click Record Sale only for a separate sale.') end
          return
        end
        if archiveSale({recordID=target.id,bid=gross,consignment=fee},gross-fee,true) then
          f:Hide()
        else say('Could not record this sale. The selected writ was not changed.') end
      end)
      confirm:SetPoint('BOTTOMRIGHT',-16,13)
      createButton(f,'Cancel',85,27,function()f:Hide()end):SetPoint('RIGHT',confirm,'LEFT',-8,0)
      input:SetScript('OnEnterPressed',function()confirm:Click()end)
      input:SetScript('OnEscapePressed',function()f:Hide()end)
      manualSaleFrame=f
      f:Hide()
      rows.registerPopup(f)
    end
    manualSaleEntry=e.id
    manualSaleFrame.name:SetText(tostring(e.writ or 'Unknown writ'))
    manualSaleInput:SetText('');manualSaleFrame:Show();manualSaleInput:SetFocus()
  end
  local function reconcileSoldRecords()
    -- Older revisions sometimes archived a sale but left an Active/Posted
    -- copy behind. Remove by exact record ID only, never by similar name.
    local soldIDs={}
    for _,e in ipairs(DB.soldWrits or {}) do
      if e.id then soldIDs[e.id]=e.writ end
    end
    local removed=0
    for i=#DB.orders,1,-1 do
      local e=DB.orders[i]
      if (e.sold or (e.id and soldIDs[e.id] and soldIDs[e.id]==e.writ)) then
        if e.sold and not soldIDs[e.id] then
          DB.soldWrits[#DB.soldWrits+1]=e
          soldIDs[e.id]=e.writ
        end
        if selectedID==e.id then selectedID=nil;DB.selectedID=nil end
        table.remove(DB.orders,i);removed=removed+1
      end
    end
    if removed>0 then debugMessage('Reconciled '..removed..' already-sold entries remaining in Active/Posted.') end
  end
  local function makeWindow()
    frame=CreateFrame('Frame','WritThisSoldLogFrame',UIParent,BackdropTemplateMixin and 'BackdropTemplate')
    frame:SetSize(960,570);frame:SetFrameStrata('DIALOG');frame:SetMovable(true)
    rows.soldLogFrame=frame
    frame:EnableMouse(true);frame:SetClampedToScreen(true)
    position(frame,'soldPos',-140,15);skinFrame(frame);makeDraggable(frame,'soldPos')
    local title=textLine(frame,'SOLD WRITS',nil,true);title:SetPoint('TOPLEFT',18,-18)
    createButton(frame,'X',26,26,function()rows.navigation.close(frame)end):SetPoint('TOPRIGHT',-12,-12)
    local hint=textLine(frame,'Collected AH-mail sales and manually confirmed sales; manual results are estimates.',900)
    hint:SetPoint('TOPLEFT',18,-49)
    hint:SetTextColor(.75,.73,.68)

    -- Keep verified and incomplete results separate. The legacy single 'Net
    -- profit' field silently excluded estimates while presenting the total as
    -- though it covered every sale. The ledger itself is NEVER rewritten here.
    local countLine=textLine(frame,'',915)
    countLine:SetPoint('TOPLEFT',18,-76)
    local verifiedLine=textLine(frame,'',265,true)
    verifiedLine:SetPoint('TOPLEFT',18,-99)
    local estimatedLine=textLine(frame,'',285,true)
    estimatedLine:SetPoint('TOPLEFT',318,-99)
    local combinedLine=textLine(frame,'',325,true)
    combinedLine:SetPoint('TOPLEFT',617,-99)
    local depositLine=textLine(frame,'',921)
    depositLine:SetPoint('TOPLEFT',18,-126)
    local methodNote=textLine(frame,
      'Writ resale only: net AH sale - writ paid - known lost deposits. Materials are excluded.',915)
    methodNote:SetPoint('TOPLEFT',18,-148)
    methodNote:SetTextColor(.70,.68,.61)

    local function summaryTooltip(self)
      if not GameTooltip then return end
      GameTooltip:SetOwner(self,'ANCHOR_BOTTOMRIGHT')
      GameTooltip:AddLine('Sold Writs accounting')
      GameTooltip:AddLine('Verified: automatic AH-mail sale, known writ purchase cost and no unknown lost deposits.',1,1,1,true)
      GameTooltip:AddLine('Estimated: manual sale, missing AH-post history, or unknown lost deposits; amounts are provisional.',1,.82,.50,true)
      GameTooltip:AddLine('Unpriced: key acquisition or proceeds information is unavailable; omitted from net totals.',1,.82,.50,true)
      GameTooltip:AddLine('Combined estimate = verified + estimated; partial when any sales are unpriced.',.78,.88,.99,true)
      GameTooltip:AddLine('Writ resale net = AH sale proceeds AFTER fee - writ paid - confirmed lost posting deposits.',1,1,1,true)
      GameTooltip:AddLine('Required-item purchases and any separate material sale proceeds are excluded from this ledger.',1,.78,.50,true)
      GameTooltip:AddLine('Lost deposits only includes amounts actually captured; 0-post sales may have missed tracking.',1,.78,.50,true)
      GameTooltip:Show()
    end
    local summaryHit=CreateFrame('Frame',nil,frame)
    summaryHit:SetPoint('TOPLEFT',18,-72);summaryHit:SetSize(922,87)
    summaryHit:EnableMouse(true)
    summaryHit:SetScript('OnEnter',summaryTooltip)
    summaryHit:SetScript('OnLeave',function()if GameTooltip then GameTooltip:Hide()end end)

    -- One resale ledger: writ acquisition and sale value are the only
    -- monetary inputs, other than real AH fees and lost posting deposits.
    local cols={
      {x=4,w=254,name='WRIT'},
      {x=272,w=128,name='WRIT PAID'},
      {x=422,w=139,name='SALE (NET)'},
      {x=585,w=75,name='POSTS'},
      {x=690,w=219,name='NET RESULT'},
    }
    for _,def in ipairs(cols) do
      local heading=textLine(frame,def.name,def.w)
      heading:SetPoint('TOPLEFT',18+def.x,-178)
      heading:SetTextColor(.69,.65,.56)
    end
    for i=1,9 do
      local row=CreateFrame('Frame',nil,frame);row:SetSize(922,32)
      row:SetPoint('TOPLEFT',18,-195-(i-1)*35)
      row.cells={}
      for n,def in ipairs(cols) do
        local label=textLine(row,'',def.w)
        label:SetPoint('LEFT',row,'LEFT',def.x,0)
        row.cells[n]=label
      end
      local divider=row:CreateTexture(nil,'ARTWORK');divider:SetColorTexture(.77,.72,.60,.28)
      divider:SetHeight(1);divider:SetPoint('BOTTOMLEFT',0,0);divider:SetPoint('BOTTOMRIGHT',0,0)
      displayRows[i]=row
    end
    local prev=createButton(frame,'<',29,25,function()pageNo=math.max(1,pageNo-1);frame.update()end)
    prev:SetPoint('BOTTOMLEFT',18,18)
    local counter=textLine(frame,'Page 1 / 1',120);counter:SetJustifyH('CENTER')
    counter:SetPoint('LEFT',prev,'RIGHT',12,0);frame.counter=counter
    createButton(frame,'>',29,25,function()pageNo=pageNo+1;frame.update()end):SetPoint('LEFT',counter,'RIGHT',8,0)

    local function signedNet(money)
      return (money>0 and '+' or '')..fmtNetMoney(money)
    end
    local function classifySale(e)
      local calculated=saleProfitFromRecord(e)
      if calculated==nil then return nil,'unpriced' end
      if e.resaleManual or (tonumber(e.resaleUnknownDeposits) or 0)>0 or
         (tonumber(e.resalePostings) or 0)<=0 then
        -- Missing posting history can mean missing deposit history. Do not
        -- classify an otherwise recorded sale as fully verified in that case.
        return calculated,'estimated'
      end
      return calculated,'verified'
    end
    frame.update=function()
      local records=DB.soldWrits or {}
      local verifiedNet,estimateNet,verifiedCount,estimateCount,unpricedCount=0,0,0,0,0
      local knownLost,unknownDepositEvents,unknownDepositSales,zeroPostSales=0,0,0,0
      for _,e in ipairs(records) do
        knownLost=knownLost+math.max(0,tonumber(e.resaleLostDeposits) or 0)
        local unknown=math.max(0,tonumber(e.resaleUnknownDeposits) or 0)
        unknownDepositEvents=unknownDepositEvents+unknown
        if unknown>0 then unknownDepositSales=unknownDepositSales+1 end
        if (tonumber(e.resalePostings) or 0)<=0 then zeroPostSales=zeroPostSales+1 end
        local result,category=classifySale(e)
        if category=='verified' then verifiedNet=verifiedNet+result;verifiedCount=verifiedCount+1
        elseif category=='estimated' then estimateNet=estimateNet+result;estimateCount=estimateCount+1
        else unpricedCount=unpricedCount+1 end
      end
      local totalKnown=verifiedCount+estimateCount
      countLine:SetText('Sold: '..#records..'    |    Verified: '..verifiedCount..
        '    |    Estimated: '..estimateCount..'    |    Unpriced: '..unpricedCount)
      verifiedLine:SetText('Verified net: '..(verifiedCount>0 and signedNet(verifiedNet) or '--'))
      verifiedLine:SetTextColor(verifiedCount==0 and .65 or (verifiedNet>=0 and .43 or .98),
        verifiedCount==0 and .65 or (verifiedNet>=0 and .86 or .49),
        verifiedCount==0 and .65 or (verifiedNet>=0 and .53 or .43))
      estimatedLine:SetText('Est. net: '..(estimateCount>0 and signedNet(estimateNet) or '--'))
      estimatedLine:SetTextColor(estimateCount==0 and .65 or (estimateNet>=0 and .63 or .98),
        estimateCount==0 and .65 or (estimateNet>=0 and .83 or .54),
        estimateCount==0 and .65 or (estimateNet>=0 and .62 or .47))
      local label=(unpricedCount>0 and 'Combined (partial): ' or 'Combined est.: ')
      combinedLine:SetText(label..(totalKnown>0 and signedNet(verifiedNet+estimateNet) or '--'))
      local combined=verifiedNet+estimateNet
      combinedLine:SetTextColor(totalKnown==0 and .65 or (combined>=0 and .43 or .98),
        totalKnown==0 and .65 or (combined>=0 and .86 or .49),
        totalKnown==0 and .65 or (combined>=0 and .53 or .43))
      depositLine:SetText('Known lost deposits: '..fmtMoney(knownLost)..
        '    |    Unknown deposits: '..unknownDepositEvents..' ('..unknownDepositSales..' sales)'..
        '    |    Sales with 0 tracked posts: '..zeroPostSales)
      depositLine:SetTextColor((unknownDepositEvents>0 or zeroPostSales>0) and .97 or .78,
        (unknownDepositEvents>0 or zeroPostSales>0) and .74 or .80,
        (unknownDepositEvents>0 or zeroPostSales>0) and .50 or .75)
      local maxPage=math.max(1,math.ceil(#records/#displayRows))
      pageNo=math.max(1,math.min(pageNo,maxPage));counter:SetText('Page '..pageNo..' / '..maxPage)
      for i,row in ipairs(displayRows) do
        local e=records[#records-((pageNo-1)*#displayRows+i)+1]
        if e then
          local short=trim(e.writ or ''):gsub('^[Cc]raftsman.?s [Ww]rit:%s*','')
          if #short>30 then short=short:sub(1,28)..'..' end
          local writPaid=(e.priceUnknown or tonumber(e.writCost)==nil) and 'Unknown' or
            fmtMoney(math.max(0,tonumber(e.writCost)))
          -- Display NET collected resale proceeds so the visible math agrees
          -- with the result. Gross sale and AH fee remain in the row tooltip.
          local sale=e.resaleNetProceeds and fmtMoney(e.resaleNetProceeds) or 'Unknown'
          local postCount=tonumber(e.resalePostings) or 0
          local postLabel=tostring(postCount)..'x'
          if postCount<=0 then postLabel=postLabel..' !'
          elseif (tonumber(e.resaleUnknownDeposits) or 0)>0 then postLabel=postLabel..' ?' end
          local result,category=classifySale(e)
          local descriptor
          if result==nil then descriptor='Unpriced'
          else
            local outcome=(result<0 and 'Loss ' or (result>0 and 'Profit ' or 'Even '))
            descriptor=(category=='estimated' and 'Est. ' or '')..outcome..fmtMoney(math.abs(result))
          end
          local values={short,writPaid,sale,postLabel,descriptor}
          for n,value in ipairs(values) do
            row.cells[n]:SetText(value)
            row.cells[n]:SetTextColor(.85,.86,.78)
          end
          if category=='unpriced' then row.cells[5]:SetTextColor(.95,.72,.45)
          elseif category=='estimated' then
            if result<0 then row.cells[5]:SetTextColor(.99,.58,.49)
            else row.cells[5]:SetTextColor(.85,.77,.49) end
          elseif result<0 then row.cells[5]:SetTextColor(.98,.47,.41)
          else row.cells[5]:SetTextColor(.42,.87,.54) end
          if postCount<=0 or (tonumber(e.resaleUnknownDeposits) or 0)>0 then
            row.cells[4]:SetTextColor(.98,.68,.40)
          end
          row:Show()
          row:SetScript('OnEnter',function()
            if not GameTooltip then return end
            GameTooltip:SetOwner(row,'ANCHOR_RIGHT')
            GameTooltip:AddLine(e.writ or 'Unknown writ')
            GameTooltip:AddLine('Acquired: '..tostring(e.acquired or 'Unknown'),.8,.8,.8)
            GameTooltip:AddLine('Writ acquisition: '..writPaid,1,1,1)
            GameTooltip:AddLine('Required-item spending and any material resale are NOT counted here.',1,.77,.50,true)
            GameTooltip:AddLine('Posted '..postCount..' times | Expired '..tostring(e.resaleExpirations or 0)..
              ' | Cancelled '..tostring(e.resaleCancels or 0))
            GameTooltip:AddLine('Gross sale: '..(e.resaleGrossPrice and fmtMoney(e.resaleGrossPrice) or 'Unknown')..' | AH fee: '..(e.resaleAHFee and fmtMoney(e.resaleAHFee) or 'Unknown'))
            GameTooltip:AddLine('Sale (net, after AH fee): '..sale)
            GameTooltip:AddLine('Refunded deposit: '..(e.resaleDepositRefund and fmtMoney(e.resaleDepositRefund) or 'Unknown')..
              ' | Known lost: '..fmtMoney(e.resaleLostDeposits or 0))
            if (tonumber(e.resaleUnknownDeposits) or 0)>0 then
              GameTooltip:AddLine('Warning: '..tostring(e.resaleUnknownDeposits)..' expired/cancelled deposit amount(s) unknown.',1,.58,.40,true)
            end
            if postCount<=0 then
              GameTooltip:AddLine('Warning: Sale has no tracked AH posting; check the original record.',1,.58,.40,true)
            end
            if category=='estimated' then
              local causes={}
              if e.resaleManual then causes[#causes+1]='sale entered manually' end
              if (tonumber(e.resaleUnknownDeposits) or 0)>0 then
                causes[#causes+1]='some lost deposits unknown'
              end
              if postCount<=0 then causes[#causes+1]='AH posting history missing' end
              GameTooltip:AddLine('Estimated: '..table.concat(causes,'; ')..'.',1,.78,.48,true)
            elseif category=='unpriced' then
              GameTooltip:AddLine('Unpriced: missing/uncertain writ acquisition cost or net sale proceeds.',1,.78,.48,true)
            else
              GameTooltip:AddLine('Verified: collected AH mail and recorded writ cost (no unknown lost deposits).',.54,.93,.62,true)
            end
            GameTooltip:AddLine(e.resaleManual and 'Manual sale: AH fee estimated at 5%; no mail receipt claimed.' or
              ('AH mail collected: '..(e.resaleCollected and fmtMoney(e.resaleCollected) or 'Unknown')), .76,.80,.87,true)
            GameTooltip:Show()
          end)
          row:SetScript('OnLeave',function()if GameTooltip then GameTooltip:Hide()end end)
        else
          row:Hide()
        end
      end
    end
    frame:Hide()
    rows.registerPopup(frame)
  end
  local function openLog()
    if DB and DB.experimentalTabbedUI and rows.experimentalTabs and not rows.experimentalTabs.switching then
      rows.experimentalTabs.open('Sold Log');return
    end
    if not frame then return end
    frame:SetShown(not frame:IsShown())
  end
  return {init=function()
    DB.soldWrits=DB.soldWrits or {};DB.resaleAuctionIDs=DB.resaleAuctionIDs or {}
    DB.resaleReturnsSeen=DB.resaleReturnsSeen or {}
    reconcileSoldRecords();makeWindow();frame:HookScript('OnShow',function() rows.paint(frame,frame.update) end);installHooks()
  end,installHooks=installHooks,onEvent=onEvent,onMoney=onMoneyChange,open=openLog,
  refresh=function(defer) if frame then rows.paint(frame,frame.update,defer) end end,
  manualPosted=manualPosted,manualReturn=manualReturn,manualUnpost=manualUnpost,
  requestOwnedSync=requestOwnedSync,inspectPosts=inspectPosts,ownedEvidence=ownedEvidence,
  openManualSale=openManualSale,repairSale=repairSale,
  hasPendingWork=function()
    return #pendingMoney>0 or #pendingOtherMoney>0 or #moneyGains>0 or
      #pendingPosts>0 or (ownedRefreshDue and ahOpen)
  end,
  tick=function()
    if #pendingMoney>0 or #pendingOtherMoney>0 or #moneyGains>0 then trySettle() end
    -- Posting confirmations can arrive before the owned list refreshes.
    -- Ask WoW for it a couple of times, throttled, without opening the AH
    -- tab or inventing additional postings. Only OWNED_AUCTIONS_UPDATED
    -- and real auction-create events may change saved Posted records.
    if ownedRefreshDue and ahOpen and clock()>=ownedRefreshDue then
      if clock()-ownedLastRequest<4 then
        ownedRefreshDue=ownedLastRequest+4
      else
        ownedLastRequest=clock()
        ownedRefreshAttempts=ownedRefreshAttempts-1
        local api=C_AuctionHouse and C_AuctionHouse.QueryOwnedAuctions
        if type(api)=='function' then
          local ok,err=pcall(api,{})
          if not ok then debugMessage('Owned auction refresh failed: '..tostring(err)) end
        else
          debugMessage('Owned auction query unavailable; use the Active Auctions tab')
        end
        if ownedRefreshAttempts>0 then ownedRefreshDue=clock()+5
        else ownedRefreshDue=nil end
      end
    end
    for i=#pendingPosts,1,-1 do if clock()-pendingPosts[i].at>30 then table.remove(pendingPosts,i) end end
  end}
end)()

-- A standalone diagnostic console. Every command invokes Writ This's own
-- existing slash handler, never arbitrary Lua or another addon's commands.
-- Uses the standard ScrollingMessageFrame API without intercepting chat globally.
rows.initConsole=function()
  if rows.consoleFrame then return end
  local f=CreateFrame('Frame','WritThisConsoleFrame',UIParent,BackdropTemplateMixin and 'BackdropTemplate')
  f:SetSize(735,510);f:SetFrameStrata('DIALOG')
  f:SetMovable(true);f:EnableMouse(true);f:SetClampedToScreen(true)
  position(f,'consolePos',0,0);skinFrame(f);makeDraggable(f,'consolePos')
  textLine(f,'WRIT THIS  |  DIAGNOSTIC CONSOLE',600,true):SetPoint('TOPLEFT',18,-17)
  createButton(f,'X',27,24,function()rows.navigation.close(f)end):SetPoint('TOPRIGHT',-12,-12)
  local help=textLine(f,'Writ This chat, debug, and tracking activity. Type Writ commands below.',680)
  help:SetPoint('TOPLEFT',18,-47);help:SetTextColor(.76,.78,.73)
  local result=CreateFrame('ScrollingMessageFrame',nil,f)
  result:SetPoint('TOPLEFT',18,-115);result:SetPoint('BOTTOMRIGHT',-22,85)
  if result.SetFontObject then result:SetFontObject(ChatFontNormal or GameFontNormal) end
  if result.SetMaxLines then result:SetMaxLines(450) end
  if result.SetFading then result:SetFading(false) end
  if result.SetHyperlinksEnabled then result:SetHyperlinksEnabled(false) end
  result:EnableMouseWheel(true)
  result:SetScript('OnMouseWheel',function(self,delta)
    if delta>0 then self:ScrollUp() else self:ScrollDown() end
  end)
  local filter='ALL'
  local query=''
  local function eligible(entry)
    local kind=entry.kind or 'CHAT'
    if filter~='ALL' and kind~=filter then return false end
    if query=='' then return true end
    local whole=(entry.at or '')..' '..kind..' '..(entry.message or '')
    return whole:lower():find(query,1,true)~=nil
  end
  local function draw()
    if not f:IsShown() then return end
    result:Clear()
    local list={}
    for _,e in ipairs(DB.consoleLog or {}) do
      if eligible(e) then
        list[#list+1]={at=e.at or '',kind=e.kind or 'CHAT',message=e.message or '',repeatCount=e.repeatCount}
      end
    end
    if filter=='ALL' or filter=='ACTIVITY' then
      for _,e in ipairs(DB.log or {}) do
        local item={at=e.time or '',kind='ACTIVITY',message=('#%s %s: %s  %s'):format(
          tostring(e.id or '-'),tostring(e.kind or ''),tostring(e.name or ''),tostring(e.note or ''))}
        if eligible(item) then list[#list+1]=item end
      end
    end
    table.sort(list,function(a,b)
      if a.at==b.at then return a.kind<b.kind end
      return a.at<b.at
    end)
    local first=math.max(1,#list-235)
    for i=first,#list do
      local e=list[i]
      local color=e.kind=='DEBUG' and {0.67,0.83,1} or
        e.kind=='ACTIVITY' and {0.7,0.92,0.69} or {1,0.86,0.56}
      local line=(e.at or '')..' ['..e.kind..'] '..(e.message or '')
      if (e.repeatCount or 1)>1 then line=line..'  (x'..e.repeatCount..')' end
      result:AddMessage(line,color[1],color[2],color[3])
    end
    if result.ScrollToBottom then result:ScrollToBottom() end
    if #list==0 then result:AddMessage('No matching entries.',.7,.7,.7) end
    if f.summary then f.summary:SetText(tostring(#list)..' matching entries | latest 235 shown | captured events persist across reloads') end
  end
  local filterButtons={}
  for i,which in ipairs({'ALL','CHAT','DEBUG','ACTIVITY'}) do
    local b=createButton(f,which=='ALL' and 'All' or
      (which=='ACTIVITY' and 'Activity' or (which=='CHAT' and 'Chat' or 'Debug')),
      which=='ACTIVITY' and 85 or 66,22,function()
        filter=which;draw()
      end)
    if i==1 then b:SetPoint('TOPLEFT',18,-77)
    else b:SetPoint('LEFT',filterButtons[i-1],'RIGHT',6,0) end
    filterButtons[i]=b
  end
  local search=CreateFrame('EditBox',nil,f,'InputBoxTemplate')
  search:SetSize(230,23);search:SetAutoFocus(false)
  search:SetPoint('TOPRIGHT',-35,-76)
  search:SetScript('OnTextChanged',function(self)
    query=(self:GetText() or ''):lower();draw()
  end)
  search:SetScript('OnEscapePressed',function(self)self:ClearFocus()end)
  local input=CreateFrame('EditBox',nil,f,'InputBoxTemplate')
  input:SetSize(554,26);input:SetAutoFocus(false)
  input:SetPoint('BOTTOMLEFT',18,50)
  local go=createButton(f,'Run',100,26,function()
    local text=trim(input:GetText() or '')
    if text=='' then return end
    input:SetText('');input:ClearFocus()
    local lower=text:lower()
    local arg
    if lower:match('^/writ%s') then arg=text:sub(7)
    elseif lower=='/writ' then arg=''
    elseif lower:match('^/writthis%s') then arg=text:sub(11)
    elseif lower=='/writthis' then arg=''
    elseif lower:match('^/writtracker%s') then arg=text:sub(14)
    elseif lower=='/writtracker' then arg='' end
    if not arg then
      if text:sub(1,1)=='/' then
        say('Console accepts Writ This commands only (/writ ...), not unrelated slash commands.')
        return
      end
      arg=text
    end
    if rows.consoleAdd then rows.consoleAdd('COMMAND','/writ '..arg) end
    if SlashCmdList and SlashCmdList.WRITTHIS then SlashCmdList.WRITTHIS(arg) end
    draw()
  end)
  go:SetPoint('LEFT',input,'RIGHT',13,0)
  input:SetScript('OnEnterPressed',function()go:Click()end)
  input:SetScript('OnEscapePressed',function(self)self:ClearFocus()end)
  f.summary=textLine(f,'',670)
  f.summary:SetPoint('BOTTOMLEFT',19,23)
  f.summary:SetTextColor(.67,.74,.70)
  f:SetScript('OnShow',function()rows.consoleDirty=true;draw()end)
  f:SetScript('OnUpdate',function(self,elapsed)
    self.acc=(self.acc or 0)+elapsed
    if self.acc<.8 then return end
    self.acc=0
    if rows.consoleDirty then rows.consoleDirty=false;draw() end
  end)
  rows.consoleFrame=f
  rows.consoleRefresh=draw
  rows.registerPopup(f)
  f:Hide()
end
rows.openConsole=function()
  if not rows.consoleFrame then rows.initConsole() end
  rows.consoleFrame:SetShown(not rows.consoleFrame:IsShown())
end

local function searchRequiredAtAH()
  local e=selected()
  local name=requiredItemName(e)
  if not name then say('Select an opened writ before searching for its item.');return end
  if not ahOpen then say('Open the Auction House at an auctioneer first. Writ This will remain open beside it.');return end
  -- Keep Tracking's individual AH lookup on the chosen provider, too.
  if rows.usingACPrices and rows.usingACPrices() then
    local ac=rows.ACPriceAPI and rows.ACPriceAPI()
    if not ac or type(ac.StartNameScan)~='function' then
      say('AC 0.1.8+ is needed for live item searches.');return
    end
    local id=e and tonumber(e.requiredItemID)
    local ok,started,reason=pcall(ac.StartNameScan,{{name=name,itemID=id}},'Writs: item')
    say(ok and started and ('AC searching for '..name) or
      ('AC item search unavailable: '..tostring(ok and reason or started)))
    return
  end
  -- Modern Auctionator API; passes ONE term and keeps our window open.
  local v1=Auctionator and Auctionator.API and Auctionator.API.v1
  if v1 and type(v1.MultiSearch)=='function' then
    local ok,err=pcall(v1.MultiSearch,'WritTracker',{name})
    if ok then say('Auctionator searching for '..name);return end
    debugMessage('Auctionator MultiSearch error: '..tostring(err))
  end
  -- Legacy Auctionator search API is available on some custom clients.
  if type(Atr_SearchAH)=='function' then
    local ok,err=pcall(Atr_SearchAH,'Writ This',{name})
    if ok then say('Auctionator searching for '..name);return end
    debugMessage('Legacy Auctionator search error: '..tostring(err))
  end
  -- Blizzard browse search as fallback when Auctionator did not expose an API.
  if C_AuctionHouse and type(C_AuctionHouse.SendBrowseQuery)=='function' then
    local ok,err=pcall(C_AuctionHouse.SendBrowseQuery,{searchString=name,sorts={}})
    if ok then say('AH search sent for '..name);return end
    debugMessage('AH search error: '..tostring(err))
  end
  say('No compatible Auctionator search API found. Search manually for: '..name)
end
local function makeSettings()
  -- Keep both catalogues in this scope to respect Classic's 200-local limit.
  local commandGroups={
    {'DUPLICATE WRITS & SALES',{
      {'/writ repairsale Cindercloth Robe', 'Use the writ name to find a manual sale and its unpriced AH payment. Choose Link sale to count them once.'},
      {'/writ duplicates Cindercloth Robe', 'Preview extra unpriced Collected copies of the named active writ.'},
      {'/writ duplicates confirm', 'Archive eligible active copies from your last preview.'},
      {'/writ duplicates undo', 'Restore all copies archived by the duplicates command.'},
    }},
    {'WINDOWS & NAVIGATION',{
      {'/writ   (or /writ show)', 'Open or close the Writ This window.'},
      {'/writthis   /writtracker', 'Alternative slash prefixes; support the same subcommands.'},
      {'/writ mini   /writ full', 'Switch between compact and full-size mode.'},
      {'/writ active', 'Switch the main list to your active writs.'},
      {'/writ listed   /writ postings', 'Show the posted-for-sale writ list.'},
      {'/writ sold   /writ sales', 'Open the Sold Writs log.'},
      {'/writ items   /writ locations   /writ book', 'Toggle the History/Records reference window.'},
      {'/writ settings', 'Open or close this settings panel.'},
      {'/writ reputation', 'Open or close the Reputation window (also /writ repchart).'},
      {'/writ writs', 'Compare AH prices for named writs and their required items.'},
      {'/writ crates   /writ waylaid', 'Browse all known Waylaid Crates, Favor rewards and material bundles.'},
      {'/writ traders   /writ shop   /writ vendors', 'Open the read-only Merchant\'s Favor vendor catalog.'},
      {'/writ scantrader', 'Read the open Merchant\'s Favor merchant inventory and save exact item IDs for native recipe tooltips.'},
      {'/writ commands   /writ help', 'Open this panel with the full command list visible.'},
      {'/writ minimap', 'Show or hide the minimap launcher button.'},
    }},
    {'COMMUNITY DATA SHARING',{
      {'/writ send   /writ sync   /writ share', 'Send shared writ averages to guild, group and detected friends.'},
      {'/writ send guild', 'Send community stats through guild addon messages.'},
      {'/writ send group   /writ send party', 'Send community stats to your current party or raid.'},
      {'/writ send player CharacterName', 'Send community data directly to an online player.'},
    }},
    {'SELECTED WRIT ACTIONS',{
      {'/writ posted [deposit]', 'Mark selected writ as posted; optional AH deposit (e.g. 12s).'},
      {'/writ syncposts', 'Request two owned-auction snapshots from the live AH; no records are changed.'},
      {'/writ inspectposts Phoenix Pants', 'Compare record IDs and linked auction IDs to currently owned listings.'},
      {'/writ unpost confirm <ID>', 'Correct a false Posted record by exact ID; linked IDs need TWO missing live snapshots.'},
      {'/writ expired [deposit]', 'Record an expired posting and its optional lost deposit.'},
      {'/writ cancelled [deposit]   /writ canceled', 'Record a cancelled posting and optional lost deposit.'},
      {'/writ finish   /writ complete', 'Manually mark the selected opened writ as completed.'},
      {'/writ payout 25s   /writ pouch 25s', 'Manually record a pending Coin Pouch payout.'},
    }},
    {'COSTS, REP & RECOVERY',{
      {'/writ rep 75', 'Correct the selected writ reputation (also 125 or 200).'},
      {'/writ price 20s50c', 'Correct the selected writ purchase price.'},
      {'/writ itemcost 15s50c', 'Correct its required-item purchase cost.'},
      {'/writ repairbatch 5', 'Repair a verified sealed-writ batch; select its priced row.'},
    }},
    {'TRACKING & DIAGNOSTICS',{
      {'/writ history', 'Print the most recent paid completions to chat.'},
      {'/writ status', 'Show tracking and auction-hook status.'},
      {'/writ scan', 'Rescan your bags for writ changes and tooltip ranks.'},
      {'/writ tierscan   /writ tier scan   /writ rep scan', 'Re-read rank and reputation from writ item tooltips.'},
      {'/writ console', 'Open the searchable Writ This log with an interactive /writ command field.'},
      {'/writ debug', 'Print the 12 most recent debugging events.'},
      {'/writ debug on   /writ debug off', 'Enable or disable diagnostic messages in chat.'},
    }},
    {'DISPLAY & PREFERENCES',{
      {'/writ startup on   /writ startup off', 'Control whether the window opens at login.'},
      {'Settings > Multi-Screen', 'On (default): keep Main open with a popup. Off: one Writ This screen, Back/Escape navigation; X exits.'},
      {'/writ mailwarning on   /writ mailwarning off', 'Turn the auction-sale mailbox reminder on or off.'},
      {'/writ size reset', 'Restore the default main-window dimensions.'},
    }},
  }

  local keybindGroups={
    {'WRIT LIST ACTIONS',{
      {'Escape (Esc)', 'In Single-Screen mode, go Back; Escape on the main screen closes Writ This. Multi-Screen keeps original close behavior.'},
      {'Left-click a writ row', 'Select that writ to view its details.'},
      {'Shift + Left-click a writ row', 'Delete that record after confirmation. The other writs are untouched.'},
      {'Shift + Right-click a writ row', 'Open manual auction-sale recovery for that writ.'},
      {'Shift + Middle-click a writ row', 'Recover a missed Coin Pouch payout for a turned-in writ marked (*); confirmation required.'},
      {'Click Map on a writ row', 'Open its known turn-in zone, with a waypoint when coordinates exist.'},
      {'Shift + Left-click a Writs AH row', 'Open the required item in History/Records.'},
      {'Click Waylaid Crates / /writ crates', 'Browse 30 crate types, bundles, and reported Merchant\'s Favor.'},
      {'Click Traders / /writ traders', 'Browse Favor recipes; native vendor tooltips. Scan Open Trader at a Favor vendor; Shift-hover the other preview.'},
    }},
    {'BAGS AND MINI VIEW',{
      {'Alt + Shift + Left-click a bagged writ', 'Manually add one untracked writ from your inventory; never invent an AH price.'},
      {'Click a turn-in zone in Mini mode', 'Open the writ turn-in map and any verified waypoint.'},
    }},
    {'MINIMAP LAUNCHER',{
      {'Left-click the minimap icon', 'Toggle the full Writ This window.'},
      {'Right-click the minimap icon', 'Toggle History/Records.'},
      {'Left-drag the minimap icon', 'Move the launcher around the minimap; its position is saved.'},
    }},
  }

  settings=CreateFrame('Frame','WritThisSettingsFrame',UIParent,BackdropTemplateMixin and 'BackdropTemplate')
  settings:SetSize(560,427);settings:SetMovable(true)
  settings:SetFrameStrata('DIALOG');settings:SetClampedToScreen(true)
  settings:EnableMouse(true);position(settings,'settingsPos',0,0)
  skinFrame(settings)
  local title=textLine(settings,'SETTINGS',nil,true)
  title:SetPoint('TOPLEFT',18,-18)
  -- Drag by the title without blocking checkboxes or the close button.
  -- Reuse the existing window position helpers; this stays saved on /reload.
  makeDraggable(settings,'settingsPos')
  createButton(settings,'X',25,24,function()rows.navigation.close(settings)end):SetPoint('TOPRIGHT',-12,-11)

  local function option(label,y,checked,onClick,x,parent,labelWidth)
    parent=parent or settings
    local check=CreateFrame('CheckButton',nil,parent,'UICheckButtonTemplate')
    check:SetSize(25,25);check:SetPoint('TOPLEFT',x or 16,y)
    check:SetChecked(checked)
    local text=textLine(parent,label,labelWidth or 203)
    text:SetPoint('LEFT',check,'RIGHT',4,0)
    local hit=CreateFrame('Button',nil,parent)
    hit:SetPoint('LEFT',check,'RIGHT',0,0);hit:SetSize(labelWidth and (labelWidth+4) or 214,26)
    check:SetScript('OnClick',function(self) onClick(not not self:GetChecked()) end)
    hit:SetScript('OnClick',function() local value=not check:GetChecked();check:SetChecked(value);onClick(value) end)
    return check
  end

  local showCommands,showKeybinds
  local collapsedHelp=textLine(settings,'Choose what to display below. Preferences are saved.',515)
  collapsedHelp:SetPoint('TOPLEFT',20,-356)
  collapsedHelp:SetTextColor(.73,.71,.66)
  local expandedHelp=textLine(settings,'Scroll for commands and mouse/keyboard shortcuts.',515)
  expandedHelp:SetPoint('TOPLEFT',20,-356)
  expandedHelp:SetTextColor(.75,.75,.69)

  local scroll=CreateFrame('ScrollFrame','WritThisSettingsCommandScroll',settings,'UIPanelScrollFrameTemplate')
  scroll:SetPoint('TOPLEFT',18,-388)
  scroll:SetPoint('BOTTOMRIGHT',-40,19)
  local content=CreateFrame('Frame',nil,scroll)
  content:SetWidth(478)
  scroll:SetScrollChild(content)
  scroll:EnableMouseWheel(true)
  scroll:SetScript('OnMouseWheel',function(self,delta)
    local max=math.max(0,self:GetVerticalScrollRange() or 0)
    local value=math.max(0,math.min(max,(self:GetVerticalScroll() or 0)-delta*44))
    local bar=_G and _G.WritThisSettingsCommandScrollScrollBar
    if bar and bar.SetValue then bar:SetValue(value) else self:SetVerticalScroll(value) end
  end)

  -- Build once, then lay out only the requested sections. Sections hidden by
  -- their checkboxes take up no scroll space, including when both are enabled.
  local function section(groups)
    local panel=CreateFrame('Frame',nil,content)
    panel:SetWidth(478)
    local y=10
    for _,group in ipairs(groups) do
      local header=textLine(panel,group[1],455,true)
      header:SetPoint('TOPLEFT',8,-y);header:SetTextColor(1,.76,.35)
      y=y+27
      for _,entry in ipairs(group[2]) do
        local first=textLine(panel,entry[1],455)
        first:SetPoint('TOPLEFT',15,-y);first:SetTextColor(.65,.87,1)
        local description=textLine(panel,entry[2],452)
        description:SetPoint('TOPLEFT',19,-(y+18));description:SetTextColor(.78,.78,.74)
        -- Allow longer descriptions to occupy two lines without collisions.
        if description.SetWordWrap then description:SetWordWrap(true) end
        y=y+44
      end
      y=y+12
    end
    local height=y+12
    panel:SetHeight(height)
    return panel,height
  end
  local commandPanel,commandHeight=section(commandGroups)
  local keybindPanel,keybindHeight=section(keybindGroups)

  local function updateSections(resetScroll)
    local commands=DB.showCommands==true
    local keys=DB.showKeybinds==true
    showCommands:SetChecked(commands)
    showKeybinds:SetChecked(keys)
    local expanded=commands or keys
    settings:SetHeight(not expanded and 427 or (commands and 675 or 575))
    collapsedHelp:SetShown(not expanded)
    expandedHelp:SetShown(expanded)
    scroll:SetShown(expanded)
    local y=0
    commandPanel:SetShown(commands)
    if commands then
      commandPanel:ClearAllPoints();commandPanel:SetPoint('TOPLEFT',content,'TOPLEFT',0,-y)
      y=y+commandHeight
    end
    keybindPanel:SetShown(keys)
    if keys then
      keybindPanel:ClearAllPoints();keybindPanel:SetPoint('TOPLEFT',content,'TOPLEFT',0,-y)
      y=y+keybindHeight
    end
    content:SetHeight(math.max(2,y+10))
    if resetScroll then scroll:SetVerticalScroll(0) end
  end
  showCommands=option('Show Commands',-48,DB.showCommands==true,function(value)
    DB.showCommands=value;updateSections(true)
  end)
  showKeybinds=option('Show Keybinds',-79,DB.showKeybinds==true,function(value)
    DB.showKeybinds=value;updateSections(true)
  end)
  -- Display preferences move off the main header, keeping their original
  -- SavedVariables keys and /writ startup / mailwarning commands intact.
  settings.startupCheckbox=option('Start on Login',-48,DB.startOnLogin==true,function(value)
    DB.startOnLogin=value
    say('Open on Login '..(value and 'ON' or 'OFF')..'. Tracking is always active.')
  end,278)
  settings.mailWarningCheckbox=option('Mail Warning',-79,DB.mailWarningEnabled~=false,function(value)
    DB.mailWarningEnabled=value
    if rows.refreshMailAlert then rows.refreshMailAlert() end
  end,278)
  settings.multiScreenCheckbox=option('Multi-Screen',-110,DB.multiScreen~=false,function(value)
    if DB.experimentalTabbedUI then
      settings.multiScreenCheckbox:SetChecked(DB.multiScreen~=false)
      say('Disable Experimental Tabbed UI to change classic Multi-Screen mode.')
      return
    end
    DB.multiScreen=value
    if settings.multiScreenCheckbox then settings.multiScreenCheckbox:SetChecked(value) end
    if rows.navigation then rows.navigation.setMode(value,settings) end
  end,278)
  -- Community sharing is an explicit action, not a background sync. Moving the
  -- button here changes only navigation; existing sending/recipient logic stays.
  local solid
  solid=option('Solid windows',-110,DB.solidWindows==true,function(value)
    DB.solidWindows=value
    solid:SetChecked(value)
    rows.applySkin(DB.skin)
  end)
  option('Left-edge launcher',-175,DB.leftEdgeButton==true,function(value)
    DB.leftEdgeButton=value
    rows.updateEdgeButton()
  end,278,settings,138)
  local launcherPanel=CreateFrame('Frame',nil,settings,BackdropTemplateMixin and 'BackdropTemplate')
  launcherPanel:SetSize(233,81)
  launcherPanel:SetFrameLevel(settings:GetFrameLevel()+8)
  launcherPanel:EnableMouse(true)
  skinFrame(launcherPanel)
  local launcherTitle=textLine(launcherPanel,'Launcher settings',166,true)
  launcherTitle:SetPoint('TOPLEFT',12,-12)
  createButton(launcherPanel,'X',23,22,function()launcherPanel:Hide()end):SetPoint('TOPRIGHT',-6,-6)
  option('Use W for collapsed tab',-43,DB.leftEdgeUseW==true,function(value)
    DB.leftEdgeUseW=value
    if rows.edgeButton then rows.edgeButton:RefreshLabel() end
  end,10,launcherPanel,178)
  local launcherSettings=createButton(settings,'Settings',80,23,function()
    launcherPanel:SetShown(not launcherPanel:IsShown())
  end)
  launcherSettings:SetPoint('TOPRIGHT',-20,-176)
  launcherPanel:SetPoint('TOPRIGHT',launcherSettings,'BOTTOMRIGHT',0,-3)
  launcherPanel:Hide()
  settings:HookScript('OnHide',function()launcherPanel:Hide()end)
  option('Mute Writ This in chat',-318,DB.muteRegularChat==true,function(value)
    DB.muteRegularChat=value
  end)
  settings.muteDebug=option('Mute debug in chat',-318,not DB.debugEnabled,function(value)
    DB.debugEnabled=not value
  end,278)
  local skinTitle=textLine(settings,'Skin',244)
  skinTitle:SetPoint('TOPLEFT',20,-182)
  local choices={'default','wow','authenticvanilla','classicstone','classicleather','tooltipframe','nightfall','wowlook'}
  for i,key in ipairs(choices) do
    local button=createButton(settings,SKINS[key].name,248,23,function()
      rows.applySkin(key)
      skinTitle:SetText('Skin  |  '..SKINS[key].name)
    end)
    button:SetPoint('TOPLEFT',20+((i-1)%2)*261,-203-math.floor((i-1)/2)*27)
  end
  skinTitle:SetText('Skin  |  '..skin().name)
  local memorial=textLine(settings,'RIP Shady',100)
  memorial:SetPoint('BOTTOM',0,3);memorial:SetJustifyH('CENTER')
  memorial:SetFont('Fonts\\MORPHEUS.TTF',10);memorial:SetTextColor(.73,.58,.29)
  local settingsSend=createButton(settings,'Send Data',114,28,function()
    community.startDataSend('')
  end)
  settingsSend:SetPoint('TOPLEFT',20,-147)
  local sendInfo=textLine(settings,'Share statistics',121)
  sendInfo:SetPoint('LEFT',settingsSend,'RIGHT',12,0)
  sendInfo:SetTextColor(.76,.80,.77)
  settings.sendData=settingsSend
  settings.experimentalTabsCheckbox=option('Experimental Tabbed UI',-142,
    DB.experimentalTabbedUI==true,function(enabled)
      if rows.experimentalTabs and rows.experimentalTabs.setEnabled then
        rows.experimentalTabs.setEnabled(enabled,true)
      else DB.experimentalTabbedUI=enabled end
    end,278,settings,204)
  if settings.experimentalTabsCheckbox.HookScript then
    settings.experimentalTabsCheckbox:HookScript('OnEnter',function(self)
      if not GameTooltip then return end
      GameTooltip:SetOwner(self,'ANCHOR_RIGHT')
      GameTooltip:AddLine('Experimental Tabbed UI',1,.82,.35)
      GameTooltip:AddLine('Seven pages in one Writ This window: Tracking, Writs, Crates, Traders, Rep, Sold Log and History/Records.',.90,.87,.79,true)
      GameTooltip:AddLine('The tracking database is shared. Disable to restore the original windows instantly.',.61,.90,.72,true)
      GameTooltip:Show()
    end)
    settings.experimentalTabsCheckbox:HookScript('OnLeave',function()
      if GameTooltip then GameTooltip:Hide() end
    end)
  end
  if settingsSend.HookScript then
    settingsSend:HookScript('OnEnter',function(self)
      if not GameTooltip then return end
      GameTooltip:SetOwner(self,'ANCHOR_TOPLEFT')
      GameTooltip:AddLine('Send community writ averages',1,.82,.35)
      GameTooltip:AddLine('Sends to Writ This users in your guild and party/raid.',.92,.92,.88)
      GameTooltip:AddLine('Also reaches detected online character friends.',.92,.92,.88)
      GameTooltip:AddLine('Use /writ send player Name to reach others directly.',.7,.85,1)
      GameTooltip:AddLine('Not server-wide. Personal writs and coordinates remain local.',.7,.79,.86)
      GameTooltip:Show()
    end)
    settingsSend:HookScript('OnLeave',function()
      if GameTooltip then GameTooltip:Hide() end
    end)
  end
  settings.showCommandList=function()
    DB.showCommands=true
    updateSections(true)
    settings:Show()
  end
  settings.showKeybindList=function()
    DB.showKeybinds=true
    updateSections(true)
    settings:Show()
  end
  settings:SetScript('OnShow',function() updateSections(false) end)
  updateSections(true)
  settings:Hide()
  rows.registerPopup(settings)
end
-- One-off corrections for purchases or reputation that the AH client did not report.
-- A manual item price is FINAL for the selected writ: later mail/purchase
-- notifications must not allocate a second item or replace the correction.
local function makeOrderEditor()
  orderEditor=CreateFrame('Frame','WritThisOrderEditFrame',UIParent,BackdropTemplateMixin and 'BackdropTemplate')
  orderEditor:SetSize(418,308)
  orderEditor:SetPoint('CENTER',UIParent,'CENTER',0,0)
  orderEditor:SetFrameStrata('DIALOG')
  skinFrame(orderEditor)
  local title=textLine(orderEditor,'EDIT WRIT',325,true)
  title:SetPoint('TOPLEFT',18,-17)
  local target=textLine(orderEditor,'',380)
  target:SetPoint('TOPLEFT',18,-47)
  orderEditor.target=target
  local hint=textLine(orderEditor,'Blank fields keep their existing values. Use 0 for a free item.',376)
  hint:SetTextColor(.72,.70,.62)
  hint:SetPoint('TOPLEFT',18,-73)
  local fields={}
  local function field(label,y)
    local t=textLine(orderEditor,label,159)
    t:SetPoint('TOPLEFT',18,y)
    local edit=CreateFrame('EditBox',nil,orderEditor,BackdropTemplateMixin and 'BackdropTemplate')
    edit:SetSize(185,25);edit:SetPoint('TOPLEFT',202,y+6)
    skinFrame(edit)
    edit:SetFontObject(GameFontNormalSmall)
    rows.skinText[edit]=true
    edit:SetTextColor(unpack(skin().text))
    edit:SetTextInsets(7,7,0,0)
    edit:SetAutoFocus(false)
    edit:SetMaxLetters(40)
    edit:SetScript('OnEscapePressed',function(self)self:ClearFocus()end)
    edit:SetScript('OnEnterPressed',function(self)self:ClearFocus()end)
    fields[#fields+1]=edit
    return edit
  end
  local writPrice=field('Writ price (e.g. 20s45c)',-111)
  local itemPrice=field('Required item price',-148)
  local rep=field('Reputation (75/125/200)',-185)
  orderEditor.writPrice=writPrice
  orderEditor.itemPrice=itemPrice
  orderEditor.rep=rep
  local function editorMoney(raw)
    raw=trim(raw)
    if raw=='' then return nil end
    local compact=raw:lower():gsub('%s+','')
    if compact:match('^0+[gsc]?$') or compact:match('^0g0+s0+c$') then return 0 end
    return parseMoney and parseMoney(raw) or nil
  end
  local save=createButton(orderEditor,'Save Changes',143,28,function()
    local e=selected()
    if not e or e.id~=orderEditor.recordID then
      say('Select an active writ to edit.');return
    end
    local wp=trim(writPrice:GetText())
    local ip=trim(itemPrice:GetText())
    local rp=trim(rep:GetText())
    local w=editorMoney(wp)
    local item=editorMoney(ip)
    local amount=rp~='' and tonumber(rp) or nil
    if wp~='' and w==nil then say('Invalid writ cost. Use 20s45c or 0.');return end
    if ip~='' and item==nil then say('Invalid item cost. Use 15s or 0.');return end
    if rp~='' and (not amount or amount<1 or amount>10000 or amount~=math.floor(amount)) then
      say('Invalid reputation. Enter a whole number such as 75, 125, or 200.');return
    end
    if wp~='' and wp~=orderEditor.defaultWrit then
      e.writCost=w;e.priceUnknown=false;e.priceSource='Manual edit'
      addLog('EDIT PRICE',e,'Writ purchase cost manually set to '..fmtMoney(w))
    end
    if ip~='' and ip~=orderEditor.defaultItem then
      e.itemCost=item;e.itemCostKnown=true;e.itemPriceUnknown=false
      e.itemPurchases=math.max(1,tonumber(e.itemPurchases) or 0)
      e.itemManual=true
      e.itemAwaitingMail=false
      addLog('EDIT ITEM',e,'Required item cost manually set to '..fmtMoney(item))
    end
    if rp~='' and rp~=orderEditor.defaultRep then
      e.rep=amount;e.repNeedsReview=false;e.repSource='Manual edit'
      addLog('EDIT REP',e,'Expected reputation set to '..tostring(amount))
    end
    orderEditor:Hide()
    refresh()
    say('Saved edits for '..tostring(e.writ))
  end)
  save:SetPoint('BOTTOMLEFT',18,16)
  createButton(orderEditor,'Cancel',106,28,function()orderEditor:Hide()end):SetPoint('LEFT',save,'RIGHT',10,0)
  createButton(orderEditor,'X',25,24,function()rows.navigation.close(orderEditor)end):SetPoint('TOPRIGHT',-12,-12)
  orderEditor:Hide()
  rows.registerPopup(orderEditor)
end
local function openOrderEditor()
  local e=selected()
  if not e then say('Select a writ before clicking Edit.');return end
  orderEditor.recordID=e.id
  orderEditor.target:SetText(e.writ or 'Selected writ')
  orderEditor.writPrice:SetText(e.priceUnknown and '' or fmtMoney(e.writCost or 0))
  orderEditor.itemPrice:SetText(e.itemCostKnown and fmtMoney(e.itemCost or 0) or '')
  orderEditor.rep:SetText(e.repNeedsReview and '' or tostring(e.rep or ''))
  orderEditor.defaultWrit=trim(orderEditor.writPrice:GetText())
  orderEditor.defaultItem=trim(orderEditor.itemPrice:GetText())
  orderEditor.defaultRep=trim(orderEditor.rep:GetText())
  orderEditor:Show()
end
-- Reference catalog: independent of purchased writs and their SavedVariables.
-- Use the existing location records; never infer coordinates for an unknown NPC.
local bookEntries={}
local function prettyItemName(key)
  local first=true
  return (tostring(key):gsub("[A-Za-z][A-Za-z']*",function(word)
    local low=word:lower()
    if first then first=false;return low:sub(1,1):upper()..low:sub(2) end
    if low=='of' or low=='the' or low=='and' or low=='for' or low=='in' or low=='to' then return low end
    return low:sub(1,1):upper()..low:sub(2)
  end))
end
local function bookField(entry)
  -- Explicit false coordinate overrides mean "no waypoint in this edited
  -- zone"; unlike nil they must not fall through to old catalog coordinates.
  local override=DB and DB.bookOverrides and DB.bookOverrides[entry.key]
  if not override then return entry end
  local e={}
  for k,v in pairs(entry) do e[k]=v end
  for _,field in ipairs({'zone','npc','x','y','rep'}) do
    if override[field]~=nil then e[field]=override[field] end
  end
  return e
end
local function populateBook()
  bookEntries={}
  local known={}
  for _,e in ipairs(bookEntries) do known[e.key]=true end
  for key,location in pairs(WRIT_LOCATIONS) do
    if not known[key] then
      table.insert(bookEntries,bookField({
        key=key, item=prettyItemName(key), zone=location[1] or 'Unknown',
        npc=location[2], x=location[3], y=location[4],
      }))
      known[key]=true
    end
  end
  -- Personal observations can introduce newly discovered writs, too.
  for _,orderGroup in ipairs({DB and DB.orders or {},DB and DB.completed or {}}) do
    for _,order in ipairs(orderGroup) do
      local key=itemKey(requiredItemName(order))
      if key~='' and not known[key] then
        local zone,npc,x,y=writLocation(order)
        table.insert(bookEntries,bookField({key=key,item=requiredItemName(order),zone=zone,
          npc=npc,x=x,y=y}))
        known[key]=true
      end
    end
  end
  for key,_ in pairs(DB and DB.bookOverrides or {}) do
    if key~='' and not known[key] then
      table.insert(bookEntries,bookField({key=key,item=prettyItemName(key),zone='Unknown'}))
      known[key]=true
    end
  end
  -- When explicitly enabled, show items contributed only by synced players.
  -- Never persist them into the user's personal reference overrides.
  if DB and DB.bookShowCommunity then
    for sender,peer in pairs(DB.sharedSources or {}) do
      if not community.isOwnSharedSource or not community.isOwnSharedSource(sender,peer) then
      for key,shared in pairs(peer.items or {}) do
        if key~='' and not known[key] then
          bookEntries[#bookEntries+1]=bookField({key=key,item=prettyItemName(key),
            zone=shared.zone or 'Unknown'})
          known[key]=true
        end
      end
      end
    end
  end
  -- Apply changes to reference data without changing the static built-ins.
  for i,entry in ipairs(bookEntries) do
    local base=WRIT_LOCATIONS[entry.key]
    local original={key=entry.key,item=entry.item,zone=base and base[1] or entry.zone,
      npc=base and base[2] or entry.npc,x=base and base[3] or entry.x,y=base and base[4] or entry.y}
    bookEntries[i]=bookField(original)
  end
end
local function statsFor(key,zone)
  local stats={runs=0,priced=0,costSamples=0,spent=0,pouches=0,pouchSamples=0,
    net=0,rep=0,repRuns=0,pricedRep=0,manualPouches=0}
  for _,e in ipairs(DB and DB.completed or {}) do
    local k=itemKey(requiredItemName(e))
    local z=writLocation(e)
    local over=DB.bookOverrides and DB.bookOverrides[k]
    if over and over.zone then z=over.zone end
    if (key and k==key) or (zone and z==zone) then
      stats.runs=stats.runs+1
      if e.pouchAmount~=nil then
        stats.pouches=stats.pouches+tonumber(e.pouchAmount)
        stats.pouchSamples=stats.pouchSamples+1
      end
      local earned=tonumber(e.repEarned) or (over and tonumber(over.rep)) or nil
      if earned and earned>0 then stats.rep=stats.rep+earned;stats.repRuns=stats.repRuns+1 end
      local cost=e.totalCost
      if cost==nil and not e.priceUnknown and e.itemCostKnown and not e.itemPriceUnknown and not rows.itemPricePending(e) then
        cost=(e.writCost or 0)+(e.itemCost or 0)
      end
      if cost~=nil then
        stats.costSamples=stats.costSamples+1
        stats.spent=stats.spent+cost
        if earned and earned>0 and e.pouchAmount~=nil then
          stats.priced=stats.priced+1
          stats.net=stats.net+cost-tonumber(e.pouchAmount)
          stats.pricedRep=stats.pricedRep+earned
        end
      end
    end
  end
  -- Manual observations are independent of completed-writ payouts. Submitting
  -- a payout against a pending writ uses archivePouch instead (never both).
  for _,sample in ipairs(DB and DB.pouchSamples or {}) do
    local sampleZone=sample.zone
    if sample.key then
      local override=DB.bookOverrides and DB.bookOverrides[sample.key]
      if override and override.zone then sampleZone=override.zone end
    end
    if (key and sample.key==key) or (zone and sampleZone==zone) then
      stats.pouches=stats.pouches+(tonumber(sample.amount) or 0)
      stats.pouchSamples=stats.pouchSamples+1
      stats.manualPouches=stats.manualPouches+1
    end
  end
  return stats
end
local function lastCompletedFor(key)
  local completed=DB and DB.completed or {}
  for i=#completed,1,-1 do
    local e=completed[i]
    if itemKey(requiredItemName(e))==key then return e end
  end
end
local function costPer100(s)
  return s.pricedRep>0 and fmtNetMoney(math.floor(s.net*100/s.pricedRep+.5)) or 'None yet'
end
local function listEfficiency(s)
  if not s or s.pricedRep<=0 then return '' end
  local net=s.net*100/s.pricedRep
  local label=net<0 and 'Profit ' or 'Cost '
  local color=net<0 and 'ff66db85' or 'ffff7777'
  return '   |   |c'..color..label..fmtMoney(math.abs(net))..' / 100 rep|r'
end
local function moneyAverage(total,n)
  return n>0 and fmtNetMoney(math.floor(total/n+.5)) or 'None yet'
end
-- Keep signed net values for efficiency calculations, but display a negative
-- average net cost as a positive profit in the reference book.
local function trueCostDisplay(s, withFormula)
  local suffix=withFormula and ' (avg cost - avg pouch)' or ''
  if s.costSamples<1 or s.pouchSamples<1 then
    return 'TRUE COST'..suffix..': None yet'
  end
  local net=s.spent/s.costSamples - s.pouches/s.pouchSamples
  local label=(net<0) and 'PROFIT' or 'TRUE COST'
  return label..suffix..': '..fmtMoney(math.abs(net))
end
-- Separate paid-only purchase averages: a looted writ (or a looted needed
-- item) cannot lower the price buyers actually paid for that component.
do
local SYNC_PREFIX='WRITTHISDB'
local SYNC_FIELDS={'runs','costSamples','spent','pouchSamples','pouches','repRuns','rep','priced','net','pricedRep',
  'writSamples','writSpent','itemSamples','itemSpent'}
local syncOutgoing=nil
local syncIncoming={}
local makeLocalShareSnapshot -- forward declaration for legacy self-sync cleanup
local function blankStats()
  return {runs=0,priced=0,costSamples=0,spent=0,pouches=0,pouchSamples=0,
    net=0,rep=0,repRuns=0,pricedRep=0,manualPouches=0,
    writSamples=0,writSpent=0,itemSamples=0,itemSpent=0,contributors=0}
end
local function addStats(to,from)
  if not from then return end
  for _,field in ipairs(SYNC_FIELDS) do
    to[field]=(tonumber(to[field]) or 0)+(tonumber(from[field]) or 0)
  end
  to.manualPouches=(to.manualPouches or 0)+(tonumber(from.manualPouches) or 0)
end
-- Addon-message senders may be returned as Name, Name-Realm, or with
-- different capitalization. Never count a character's own broadcast as a
-- second contributor. A GUID in new packets also covers ambiguous names.
local function identityText(value)
  return tostring(value or ''):lower():gsub('%s+','')
end
local function characterPart(value)
  return identityText(value):match('^([^%-]+)') or ''
end
local function ownCharacterIDs()
  local names={}
  local function add(value)
    if value and value~='' then names[identityText(value)]=true end
  end
  local n=(UnitName and UnitName('player')) or ''
  add(n)
  if GetUnitName then
    local ok,name=pcall(GetUnitName,'player',true)
    if ok then add(name) end
  end
  if UnitFullName then
    local ok,first,realm=pcall(UnitFullName,'player')
    if ok then
      add(first)
      if first and realm and realm~='' then add(first..'-'..realm) end
    end
  end
  if GetRealmName and n~='' then
    local ok,realm=pcall(GetRealmName)
    if ok and realm and realm~='' then add(n..'-'..realm) end
  end
  local guid=(UnitGUID and UnitGUID('player')) or nil
  return names,characterPart(n),guid
end
local function isSelfSender(sender,peer)
  local names,myBase,myGUID=ownCharacterIDs()
  if peer and peer.sourceGUID and myGUID and peer.sourceGUID==myGUID then return true end
  if names[identityText(sender)] then return true end
  -- If the API supplies only a short player name while the sender is
  -- realm-qualified (or vice versa), it is the same character in our guild.
  return myBase~='' and characterPart(sender)==myBase
end
local function sameSourceSummary(a,b)
  for _,field in ipairs(SYNC_FIELDS) do
    if (tonumber(a[field]) or 0)~=(tonumber(b[field]) or 0) then return false end
  end
  return identityText(a.zone)==identityText(b.zone)
end
local function isOldSelfMirror(peer)
  if not peer or not makeLocalShareSnapshot then return false end
  local items,zones=makeLocalShareSnapshot()
  local number=0
  for key,entry in pairs(peer.items or {}) do
    if not items[key] or not sameSourceSummary(entry,items[key]) then return false end
    number=number+1
  end
  for key in pairs(items) do if not (peer.items or {})[key] then return false end end
  for zone,entry in pairs(peer.zones or {}) do
    local localZone=zones[zone]
    if not localZone or (tonumber(entry.pouches) or 0)~=(tonumber(localZone.pouches) or 0)
      or (tonumber(entry.pouchSamples) or 0)~=(tonumber(localZone.pouchSamples) or 0) then return false end
    number=number+1
  end
  for zone in pairs(zones) do if not (peer.zones or {})[zone] then return false end end
  -- Avoid treating two empty datasets as evidence of identical ownership.
  return number>0
end
function community.isOwnSharedSource(sender,peer)
  return isSelfSender(sender,peer) or isOldSelfMirror(peer)
end
function community.pruneSelfSnapshots()
  if not DB or not DB.sharedSources then return 0 end
  local removed=0
  for sender,peer in pairs(DB.sharedSources) do
    if community.isOwnSharedSource(sender,peer) then
      DB.sharedSources[sender]=nil;removed=removed+1
    end
  end
  return removed
end
local function completedZone(e,key)
  local zone=writLocation(e)
  local over=DB.bookOverrides and DB.bookOverrides[key]
  if over and over.zone then zone=over.zone end
  return zone
end
local function addCompletedStats(stats,e,key)
  stats.runs=stats.runs+1
  local pouch=tonumber(e.pouchAmount)
  if pouch then stats.pouches=stats.pouches+pouch;stats.pouchSamples=stats.pouchSamples+1 end
  local override=DB.bookOverrides and DB.bookOverrides[key]
  local earned=tonumber(e.repEarned) or (override and tonumber(override.rep)) or nil
  if earned and earned>0 then stats.rep=stats.rep+earned;stats.repRuns=stats.repRuns+1 end
  local w=tonumber(e.writCost)
  if not e.priceUnknown and w and w>0 and
     (e.acquired~='Loot' or e.priceSource=='Manual correction' or e.priceSource=='Manual edit') then
    stats.writSamples=stats.writSamples+1
    stats.writSpent=stats.writSpent+w
  end
  local item=tonumber(e.itemCost)
  if e.itemCostKnown and not e.itemPriceUnknown and not rows.itemPricePending(e) and item and item>0 then
    stats.itemSamples=stats.itemSamples+1
    stats.itemSpent=stats.itemSpent+item
  end
  -- Full-run costs and actual net/rep remain strictly observed, not inferred.
  local cost=e.totalCost
  if cost==nil and not e.priceUnknown and e.itemCostKnown and not e.itemPriceUnknown then
    cost=(w or 0)+(item or 0)
  end
  if cost~=nil then
    stats.costSamples=stats.costSamples+1
    stats.spent=stats.spent+cost
    if earned and earned>0 and pouch then
      stats.priced=stats.priced+1
      stats.net=stats.net+cost-pouch
      stats.pricedRep=stats.pricedRep+earned
    end
  end
end
local function sampleZone(sample)
  local z=sample.zone
  if sample.key then
    local over=DB.bookOverrides and DB.bookOverrides[sample.key]
    if over and over.zone then z=over.zone end
  end
  return z
end
local function localStatsFor(key,zone)
  local stats=blankStats()
  for _,e in ipairs(DB and DB.completed or {}) do
    local k=itemKey(requiredItemName(e))
    if (key and k==key) or (zone and completedZone(e,k)==zone) then
      addCompletedStats(stats,e,k)
    end
  end
  -- Pouch-only observations are independent; they do not invent item costs.
  for _,sample in ipairs(DB and DB.pouchSamples or {}) do
    if (key and sample.key==key) or (zone and sampleZone(sample)==zone) then
      stats.pouches=stats.pouches+(tonumber(sample.amount) or 0)
      stats.pouchSamples=stats.pouchSamples+1
      stats.manualPouches=stats.manualPouches+1
    end
  end
  return stats
end
-- Personal and received figures are separate. Never merge another player's
-- completed runs into the actual local writ history, personal finances or log.
community.personalStatsFor=localStatsFor
function community.sharedStatsFor(key,zone)
  local stats=blankStats()
  for sender,peer in pairs(DB and DB.sharedSources or {}) do
    if not community.isOwnSharedSource(sender,peer) then
    local contributed=false
    for k,entry in pairs(peer.items or {}) do
      if (key and k==key) or (zone and entry.zone==zone) then
        addStats(stats,entry)
        contributed=true
      end
    end
    if zone and peer.zones and peer.zones[zone] then
      addStats(stats,peer.zones[zone]);contributed=true
    end
    if contributed then stats.contributors=stats.contributors+1 end
    end
  end
  return stats
end
function community.statsFor(key,zone)
  local stats=localStatsFor(key,zone)
  if DB and DB.bookShowCommunity then
    local shared=community.sharedStatsFor(key,zone)
    addStats(stats,shared)
    stats.contributors=shared.contributors
  end
  return stats
end
function community.lastCompletedFor(key)
  local completed=DB and DB.completed or {}
  for i=#completed,1,-1 do
    local e=completed[i]
    if itemKey(requiredItemName(e))==key then return e end
  end
end
function community.costPer100(s)
  return s.pricedRep>0 and fmtNetMoney(math.floor(s.net*100/s.pricedRep+.5)) or 'None yet'
end
function community.listEfficiency(s)
  if not s or s.pricedRep<=0 then return '' end
  local net=s.net*100/s.pricedRep
  local label=net<0 and 'Profit ' or 'Cost '
  local color=net<0 and 'ff66db85' or 'ffff7777'
  return '   |   |c'..color..label..fmtMoney(math.abs(net))..' / 100 rep|r'
end
function community.moneyAverage(total,n)
  return n>0 and fmtNetMoney(math.floor(total/n+.5)) or 'None yet'
end
-- Keep signed net values for efficiency calculations, but display a negative
-- average net cost as a positive profit in the reference book.
function community.trueCostDisplay(s, withFormula)
  local suffix=withFormula and ' (paid writ + paid item - pouch)' or ''
  if s.writSamples<1 or s.itemSamples<1 or s.pouchSamples<1 then
    return 'TRUE COST'..suffix..': Not enough paid-price/pouch samples'
  end
  local net=s.writSpent/s.writSamples+s.itemSpent/s.itemSamples-s.pouches/s.pouchSamples
  local label=(net<0) and 'PROFIT' or 'TRUE COST'
  return label..suffix..': '..fmtMoney(math.abs(net))
end

-- Manual opt-in send. The receiver stores a REPLACEABLE aggregate snapshot for
-- each named sender. Personal run rows, gold totals, and reference edits stay
-- local, and retransmissions never create duplicate observations.
makeLocalShareSnapshot=function()
  local items,zones={},{}
  for _,e in ipairs(DB.completed or {}) do
    local key=itemKey(requiredItemName(e))
    if key~='' then
      local row=items[key]
      if not row then row=blankStats();items[key]=row end
      row.zone=completedZone(e,key)
      addCompletedStats(row,e,key)
    end
  end
  for _,sample in ipairs(DB.pouchSamples or {}) do
    local key=sample.key
    if key and key~='' then
      local row=items[key]
      if not row then row=blankStats();items[key]=row end
      row.zone=sampleZone(sample) or row.zone or 'Unknown'
      row.pouches=row.pouches+(tonumber(sample.amount) or 0)
      row.pouchSamples=row.pouchSamples+1
      row.manualPouches=row.manualPouches+1
    else
      local zone=sampleZone(sample) or 'Unknown'
      local row=zones[zone]
      if not row then row={pouches=0,pouchSamples=0};zones[zone]=row end
      row.pouches=row.pouches+(tonumber(sample.amount) or 0)
      row.pouchSamples=row.pouchSamples+1
    end
  end
  return items,zones
end
local function encodeSyncText(value)
  local encoded=tostring(value or ''):gsub('%%','%%25'):gsub('%^','%%5E'):gsub('[\r\n]',' ')
  return encoded
end
local function decodeSyncText(value)
  return tostring(value or ''):gsub('%%5[Ee]','^'):gsub('%%25','%%')
end
local function syncSplit(message)
  local parts={}
  for part in (message..'^'):gmatch('(.-)%^') do parts[#parts+1]=part end
  return parts
end
local function hasSyncTransport()
  return (C_ChatInfo and C_ChatInfo.SendAddonMessage) or SendAddonMessage
end
-- Report failures rather than interpreting pcall(true, InvalidChannel=7) as
-- success. Forever/Classic API versions may return true, nil or enum zero.
local function syncSendMessage(message,channel,target)
  local sender=(C_ChatInfo and C_ChatInfo.SendAddonMessage) or SendAddonMessage
  if not sender then return false,'unavailable' end
  local ok,result=pcall(sender,SYNC_PREFIX,message,channel,target)
  if not ok or result==false then return false,'failed' end
  if type(result)=='number' and result~=0 then
    return false,(result==3 or result==8) and 'throttle' or ('error '..result)
  end
  return true
end
local function groupChannel()
  if (IsInRaid and IsInRaid()) or (GetNumRaidMembers and GetNumRaidMembers()>0) then return 'RAID' end
  if (IsInGroup and IsInGroup()) or (GetNumPartyMembers and GetNumPartyMembers()>0) then return 'PARTY' end
  return nil
end
-- Read online in-game character friends (not Battle.net account contacts).
-- Support Forever's modern C_FriendList and older GetFriendInfo clients.
function community.friendEntries()
  local entries={}
  local count=0
  if C_FriendList and type(C_FriendList.GetNumFriends)=='function' then
    local ok,n=pcall(C_FriendList.GetNumFriends)
    if ok then count=tonumber(n) or 0 end
  elseif type(GetNumFriends)=='function' then
    local ok,n=pcall(GetNumFriends)
    if ok then count=tonumber(n) or 0 end
  end
  local unique={}
  for i=1,math.min(math.max(0,count),100) do
    local name,online
    if C_FriendList and type(C_FriendList.GetFriendInfoByIndex)=='function' then
      local ok,info=pcall(C_FriendList.GetFriendInfoByIndex,i)
      if ok and type(info)=='table' then
        name=info.name
        online=info.connected==true
      end
    elseif type(GetFriendInfo)=='function' then
      local ok,n,_,_,_,connected=pcall(GetFriendInfo,i)
      if ok then name=n;online=connected==true end
    end
    if type(name)=='string' and #name>0 and #name<=70 and
       not name:find('[%s%c|%^]') and not isSelfSender(name) then
      local key=identityText(name)
      if not unique[key] then
        unique[key]=true
        entries[#entries+1]={name=name,online=online==true}
      end
    end
  end
  return entries
end
function community.requestFriendRefresh()
  local fn=(C_FriendList and C_FriendList.ShowFriends) or ShowFriends
  if type(fn)=='function' then pcall(fn) end
end
-- Exclude individual whispers to friends already included in a GUILD or
-- PARTY/RAID broadcast. Guild and group themselves are still independent
-- broadcast paths; the receiver stores only one snapshot per player.
function community.coveredByBroadcast(destinations)
  local covered={}
  local function add(name)
    if type(name)=='string' and name~='' then
      covered[identityText(name)]=true
      covered[characterPart(name)]=true
    end
  end
  local inGuild=false
  local inGroup=false
  local groupType=nil
  for _,d in ipairs(destinations) do
    if d.channel=='GUILD' then inGuild=true end
    if d.channel=='RAID' or d.channel=='PARTY' then
      inGroup=true;groupType=d.channel
    end
  end
  if inGuild and type(GetNumGuildMembers)=='function' and
     type(GetGuildRosterInfo)=='function' then
    local ok,count=pcall(GetNumGuildMembers)
    if ok then
      for i=1,math.min(tonumber(count) or 0,500) do
        local got,name=pcall(GetGuildRosterInfo,i)
        if got then add(name) end
      end
    end
  end
  if inGroup then
    local prefix=groupType=='RAID' and 'raid' or 'party'
    local count=0
    if groupType=='RAID' and type(GetNumGroupMembers)=='function' then
      count=tonumber(GetNumGroupMembers()) or 0
    elseif groupType=='RAID' and type(GetNumRaidMembers)=='function' then
      count=tonumber(GetNumRaidMembers()) or 0
    elseif type(GetNumSubgroupMembers)=='function' then
      count=tonumber(GetNumSubgroupMembers()) or 0
    elseif type(GetNumPartyMembers)=='function' then
      count=tonumber(GetNumPartyMembers()) or 0
    end
    for i=1,math.min(math.max(0,count),40) do
      local unit=prefix..i
      if type(UnitName)=='function' then
        local ok,name=pcall(UnitName,unit)
        if ok then add(name) end
      end
    end
  end
  return covered
end
function community.friendHasRecentPresence(name)
  if not community.hasRecentPresence then return false end
  return community.hasRecentPresence(name)
end
-- WoW Forever does not permit addon CHANNEL broadcasts across the server.
-- Use every *supported* and reachable path; the user can also choose a direct
-- WHISPER recipient using /writ send player Name.
local function selectSyncDestinations(requested)
  requested=trim(requested)
  local mode=requested:lower()
  local destinations,used={},{}
  local function add(channel,target)
    local key=channel..':'..identityText(target)
    if not used[key] then
      destinations[#destinations+1]={channel=channel,target=target}
      used[key]=true
    end
  end
  if mode=='' or mode=='guild' then
    if IsInGuild and IsInGuild() then add('GUILD') end
  end
  if mode=='' or mode=='group' or mode=='party' or mode=='raid' then
    local g=groupChannel()
    if g then add(g) end
  end
  if mode=='' then
    local covered=community.coveredByBroadcast(destinations)
    -- The friend list reports who is online, not who has Writ This. Only
    -- send full statistics to peers whose addon answered our presence ping.
    local allFriends=community.friendEntries()
    local offlineFriends={}
    for _,friend in ipairs(allFriends) do
      if not friend.online then offlineFriends[identityText(friend.name)]=true end
    end
    for _,friend in ipairs(allFriends) do
      if friend.online and community.friendHasRecentPresence(friend.name) and
         not covered[identityText(friend.name)] and
         not covered[characterPart(friend.name)] then
        add('WHISPER',friend.name)
      end
    end
    -- Keep explicit cross-guild peer support, also skipping covered recipients.
    if community.activeWhisperPeers then
      for _,name in ipairs(community.activeWhisperPeers(12)) do
        if not covered[identityText(name)] and
           not covered[characterPart(name)] and
           not offlineFriends[identityText(name)] then
          add('WHISPER',name)
        end
      end
    end
  end
  local target=requested:match('^[Pp][Ll][Aa][Yy][Ee][Rr]%s+(.+)$') or
    requested:match('^[Pp][Ee][Ee][Rr]%s+(.+)$')
  if not target and mode~='' and mode~='guild' and mode~='group' and
     mode~='party' and mode~='raid' then
    target=requested
  end
  if target then
    target=trim(target)
    -- Character[-Realm] names only; never send to a user-supplied channel ID.
    if #target>0 and #target<=70 and not target:find('[%s%c|%^]') then
      add('WHISPER',target)
    end
  end
  return destinations
end
function community.registerSyncPrefix()
  local fn=(C_ChatInfo and C_ChatInfo.RegisterAddonMessagePrefix) or RegisterAddonMessagePrefix
  if not fn then return false end
  local ok,value=pcall(fn,SYNC_PREFIX)
  return ok and value~=false
end

-- Active presence is session-only (five-minute window), while all-time
-- detected addon users are kept in the *existing per-character SavedVariables*.
-- Both count verified addon senders, not installations or an entire server.
-- Normalize Name and Name-Realm to one character on this single-world client.
local presenceSeen={}
-- Only show a version that the peer actually advertised. Never guess from a
-- presence packet, the install on THIS computer, or a saved user record.
local function validPresenceVersion(value)
  if type(value)~='string' or #value<5 or #value>32 then return nil end
  if not value:match('^%d+%.%d+%.%d+[%w%.%-_]*$') then return nil end
  return value
end
function community.rememberAllTimeUser(sender)
  if not DB or type(sender)~='string' or #sender>90 or isSelfSender(sender) then return false end
  local key=characterPart(sender)
  -- Sender must be a plausible character name, not an arbitrary channel token.
  if key=='' or #key>70 or key:find('[%s%c|%^]') then return false end
  DB.allTimeAddonUsers=DB.allTimeAddonUsers or {}
  -- Save readable case separately without altering the old unique-key set.
  DB.allTimeAddonNames=DB.allTimeAddonNames or {}
  DB.allTimeAddonNames[key]=sender:match('^[^%-]+') or sender
  if DB.allTimeAddonUsers[key] then return false end
  DB.allTimeAddonUsers[key]=true
  return true
end
function community.seedAllTimeUsers()
  if not DB then return end
  DB.allTimeAddonUsers=DB.allTimeAddonUsers or {}
  -- Existing snapshots are proof of prior Writ This users, even if they are
  -- offline now. Do not count arbitrary friends who never used the addon.
  for sender,source in pairs(DB.sharedSources or {}) do
    if type(source)=='table' then community.rememberAllTimeUser(sender) end
  end
end
function community.allTimeUsers()
  local count=1 -- Include this character; it is running Writ This.
  if DB and type(DB.allTimeAddonUsers)=='table' then
    for _,seen in pairs(DB.allTimeAddonUsers) do
      if seen then count=count+1 end
    end
  end
  return count
end
local presenceNextHello=nil
local presenceLastHello=-1000
local presenceLastUI=-1000
local presenceLastAck={}
community.friendProbeQueue={}
community.friendProbeQueued={}
community.friendProbeSent={}
community.friendProbeNextAt=0
community.friendListRefreshAt=-1000
community.pendingDefaultSend=false
community.pendingDefaultSendAt=nil
-- Only whisper a small 6-byte discovery packet at a controlled rate.
-- Missing friends never receive statistics, and only Send Data initiates those.
function community.queueFriendProbes()
  -- Guild/group members can answer broadcast pings. Reserve whisper probes
  -- for online friends who aren't already reachable through those routes.
  local routes={}
  if IsInGuild and IsInGuild() then routes[#routes+1]={channel='GUILD'} end
  local group=groupChannel()
  if group then routes[#routes+1]={channel=group} end
  local covered=community.coveredByBroadcast(routes)
  for _,friend in ipairs(community.friendEntries()) do
    local key=identityText(friend.name)
    if friend.online and not community.friendHasRecentPresence(friend.name) and
       not covered[key] and not covered[characterPart(friend.name)] then
      if not community.friendProbeQueued[key] and clock()-(community.friendProbeSent[key] or -1000)>=120 then
        community.friendProbeQueued[key]=true
        community.friendProbeQueue[#community.friendProbeQueue+1]=friend.name
      end
    end
  end
end
function community.refreshFriendsIfDue(force)
  if force or clock()-community.friendListRefreshAt>=180 then
    community.requestFriendRefresh()
    community.friendListRefreshAt=clock()
  end
end
function community.hasRecentPresence(name)
  local full=identityText(name)
  local basic=characterPart(name)
  local now=clock()
  for key,peer in pairs(presenceSeen) do
    if now-(peer.at or 0)<=300 and
       (key==full or (basic~='' and characterPart(key)==basic)) then
      return true
    end
  end
  return false
end
function community.detectedUsers()
  local now=clock()
  local total=1 -- This character is running Writ This.
  for key,peer in pairs(presenceSeen) do
    if now-(peer.at or 0)<=300 then total=total+1
    else presenceSeen[key]=nil end
  end
  return total
end
-- Reuse the exact same deduplicated identities used by the counters.
-- The character running Writ This is included in both lists.
function community.activeUserNames()
  local ownName=(UnitName and UnitName('player')) or 'You'
  local names={ownName..' (you)'}
  local now=clock()
  for key,peer in pairs(presenceSeen) do
    if now-(peer.at or 0)<=300 then
      names[#names+1]=(peer.name or key):match('^[^%-]+') or key
    end
  end
  table.sort(names,function(a,b) return a:lower()<b:lower() end)
  return names
end
function community.allTimeUserNames()
  local ownName=(UnitName and UnitName('player')) or 'You'
  local names={ownName..' (you)'}
  for key,seen in pairs((DB and DB.allTimeAddonUsers) or {}) do
    if seen then
      local known=DB.allTimeAddonNames and DB.allTimeAddonNames[key]
      local display=known or (key:gsub('^%l',string.upper))
      names[#names+1]=display
    end
  end
  table.sort(names,function(a,b) return a:lower()<b:lower() end)
  return names
end
-- Active: most recently reported by this peer during this session.
-- All-time: last valid version explicitly received from that peer (if any).
function community.userVersion(name,isActive)
  if type(name)~='string' then return 'Not reported' end
  if name:sub(-6)==' (you)' then return 'v'..VERSION end
  local key=characterPart(name)
  local version
  if isActive then
    version=presenceSeen[key] and presenceSeen[key].version
  elseif DB and type(DB.allTimeAddonVersions)=='table' then
    version=DB.allTimeAddonVersions[key]
  end
  version=validPresenceVersion(version)
  return version and ('v'..version) or 'Not reported'
end
function community.refreshPresenceCount()
  if window and window.userCount then
    window.userCount:SetText('Users: '..tostring(community.detectedUsers()))
  end
  if rows.refreshUserList then rows.refreshUserList() end
end
local function observePresence(sender,channel,reportedVersion,hasVersionField)
  if type(sender)~='string' or #sender>90 or isSelfSender(sender) then return end
  local key=characterPart(sender)
  if key=='' or #key>70 or key:find('[%s%c|%^]') then return end
  -- Name / Name-Realm / channel differences are the same verified character.
  local peer=presenceSeen[key] or {channels={}}
  peer.at=clock()
  peer.name=sender
  if channel then peer.channels[channel]=true end
  -- A legacy presence ping is proof of being online, not proof of a version.
  -- Reset the *active* version on legacy pings so a downgrade isn't concealed.
  -- A full data-sync packet has no version field and should not clear it.
  if hasVersionField then
    peer.version=validPresenceVersion(reportedVersion)
    if peer.version then
      DB.allTimeAddonVersions=DB.allTimeAddonVersions or {}
      DB.allTimeAddonVersions[key]=peer.version
    end
  end
  presenceSeen[key]=peer
  community.rememberAllTimeUser(sender)
  community.refreshPresenceCount()
end
-- An addon whisper peer (including an online friend) is reusable for Send
-- Data for five minutes after an actual addon-message exchange.
function community.activeWhisperPeers(limit)
  local candidates={}
  for _,peer in pairs(presenceSeen) do
    if peer.channels.WHISPER and clock()-(peer.at or 0)<=300 then
      candidates[#candidates+1]=peer
    end
  end
  table.sort(candidates,function(a,b) return a.at>b.at end)
  local names={}
  for i=1,math.min(tonumber(limit) or 12,#candidates) do
    names[#names+1]=candidates[i].name
  end
  return names
end
function community.startPresence()
  presenceNextHello=clock()+4 -- Allow WoW group/guild state to initialize.
  community.refreshFriendsIfDue(true)
end
function community.schedulePresence()
  local now=clock()
  if now-presenceLastHello>=15 then
    presenceNextHello=math.min(presenceNextHello or (now+2),now+2)
  end
end
function community.scheduleFriends()
  -- Friend list events might arrive while the server is refreshing the list.
  -- The next lightweight periodic pass picks up newly online characters.
  presenceNextHello=math.min(presenceNextHello or (clock()+3),clock()+3)
end
function community.tickPresence()
  local now=clock()
  if now-presenceLastUI>=5 then
    presenceLastUI=now
    community.refreshPresenceCount()
  end
  if presenceNextHello and now>=presenceNextHello and
     community.syncPrefixReady and hasSyncTransport() then
    presenceNextHello=now+120
    community.refreshFriendsIfDue(false)
    community.queueFriendProbes()
    -- Tiny presence ping: no inventory, prices, transactions or saved records.
    if not syncOutgoing then
      if IsInGuild and IsInGuild() then syncSendMessage('V1^P^1^'..VERSION,'GUILD') end
      local g=groupChannel()
      if g then syncSendMessage('V1^P^1^'..VERSION,g) end
      for _,name in ipairs(community.activeWhisperPeers(8)) do
        -- Explicit peers also get a lightweight heartbeat.
        if clock()-(community.friendProbeSent[identityText(name)] or -1000)>=120 then
          syncSendMessage('V1^P^1^'..VERSION,'WHISPER',name)
          community.friendProbeSent[identityText(name)]=clock()
        end
      end
    end
    presenceLastHello=now
  end
  -- Pace discovery whispers; do not interrupt a full statistics transmission.
  if #community.friendProbeQueue>0 and now>=community.friendProbeNextAt and not syncOutgoing and
     community.syncPrefixReady and hasSyncTransport() then
    local name=community.friendProbeQueue[1]
    local ok,err=syncSendMessage('V1^P^1^'..VERSION,'WHISPER',name)
    if ok or err~='throttle' then
      table.remove(community.friendProbeQueue,1)
      community.friendProbeQueued[identityText(name)]=nil
      community.friendProbeSent[identityText(name)]=now
    end
    community.friendProbeNextAt=now+(err=='throttle' and 1.5 or .65)
  end
  if community.pendingDefaultSend and #community.friendProbeQueue==0 then
    if not community.pendingDefaultSendAt then community.pendingDefaultSendAt=now+1.5 end
    if now>=community.pendingDefaultSendAt then
      community.pendingDefaultSend=false
      community.pendingDefaultSendAt=nil
      if community.beginDataSend then community.beginDataSend('') end
    end
  end
end
community.startDataSend=function(channelRequest)
  if not DB then return end
  if syncOutgoing or community.pendingDefaultSend then
    say('A community data send is already underway. Try again after it finishes.')
    return
  end
  if trim(channelRequest)=='' and community.syncPrefixReady and hasSyncTransport() then
    community.refreshFriendsIfDue(true)
    community.queueFriendProbes()
    if #community.friendProbeQueue>0 then
      community.pendingDefaultSend=true
      community.pendingDefaultSendAt=nil
      say('Checking online friends for Writ This before sending community statistics.')
      return
    end
  end
  community.beginDataSend(channelRequest)
end
community.beginDataSend=function(channelRequest)
  if not DB then return end
  if syncOutgoing then return end
  local destinations=selectSyncDestinations(channelRequest)
  if #destinations==0 then
    say('No detected recipients. Send Data reaches guild/group and verified online friends; or /writ send player Name.')
    return
  end
  if not community.syncPrefixReady or not hasSyncTransport() then
    say('This client has no available addon-message transport; nothing was sent.')
    return
  end
  local items,zones=makeLocalShareSnapshot()
  DB.shareCounter=(tonumber(DB.shareCounter) or 0)+1
  local sid=tostring((time and time() or 0)%1000000000)..'-'..tostring(DB.shareCounter)
  local packets={}
  local itemsSent,zonesSent=0,0
  for key,row in pairs(items) do
    if itemsSent<400 then
      local fields={'V1','I',sid,encodeSyncText(key),encodeSyncText(row.zone)}
      for _,field in ipairs(SYNC_FIELDS) do fields[#fields+1]=tostring(math.floor(tonumber(row[field]) or 0)) end
      local message=table.concat(fields,'^')
      if #message<=230 then packets[#packets+1]=message;itemsSent=itemsSent+1 end
    end
  end
  for zone,row in pairs(zones) do
    if zonesSent<100 then
      local message=table.concat({'V1','Z',sid,encodeSyncText(zone),
        tostring(row.pouchSamples),tostring(row.pouches)},'^')
      if #message<=230 then packets[#packets+1]=message;zonesSent=zonesSent+1 end
    end
  end
  -- Optional identity stamp; old clients still understand fields 1-5.
  local myGUID=(UnitGUID and UnitGUID('player')) or ''
  table.insert(packets,1,table.concat({'V1','S',sid,tostring(itemsSent),tostring(zonesSent),myGUID},'^'))
  packets[#packets+1]='V1^E^'..sid
  syncOutgoing={messages=packets,packetIndex=1,destinations=destinations,
    destinationIndex=1,nextAt=0,retries=0,delivered=0,failed=0,
    items=itemsSent,zones=zonesSent}
  local routes={}
  for _,d in ipairs(destinations) do
    routes[#routes+1]=d.channel..(d.target and (':'..d.target) or '')
  end
  say('Sending '..itemsSent..' item and '..zonesSent..' zone summaries to '..
      table.concat(routes,', ')..'.')
end
local function finishIncoming(sender,incoming)
  if not incoming.ended or incoming.gotItems~=incoming.expectedItems or
     incoming.gotZones~=incoming.expectedZones then return end
  DB.sharedSources=DB.sharedSources or {}
  -- Reject both normal self-echoes and already-known legacy self mirrors.
  local candidate={items=incoming.items,zones=incoming.zones,sourceGUID=incoming.sourceGUID}
  if community.isOwnSharedSource(sender,candidate) then
    DB.sharedSources[sender]=nil
    syncIncoming[sender]=nil
    return
  end
  DB.sharedSources[sender]={items=incoming.items,zones=incoming.zones,
    sourceGUID=incoming.sourceGUID,
    receivedAt=datetime(),receivedEpoch=time and time() or 0}
  syncIncoming[sender]=nil
  say('Community data updated from '..sender..' ('..incoming.gotItems..' items).')
  if bookRefresh then bookRefresh(true) end
end
community.onSyncMessage=function(prefix,message,channel,sender)
  if not DB or prefix~=SYNC_PREFIX or type(message)~='string' or type(sender)~='string' then return end
  if channel~='GUILD' and channel~='PARTY' and channel~='RAID' and channel~='WHISPER' then return end
  if isSelfSender(sender,{sourceGUID=nil}) then return end
  if #message>255 then return end
  local part=syncSplit(message)
  if part[1]~='V1' or not part[3] or #part[3]>42 then return end
  local code,sid=part[2],part[3]
  if code=='P' or code=='A' then
    if sid~='1' then return end
    observePresence(sender,channel,part[4],true)
    local ackKey=channel=='WHISPER' and ('WHISPER:'..identityText(sender)) or channel
    if code=='P' and clock()-(presenceLastAck[ackKey] or -1000)>=120 and
       community.syncPrefixReady and hasSyncTransport() then
      -- One guild/group response per 2 minutes, or one per direct whisper peer.
      if syncSendMessage('V1^A^1^'..VERSION,channel,channel=='WHISPER' and sender or nil) then
        presenceLastAck[ackKey]=clock()
      end
    end
    return
  end
  if code=='S' then
    local a,b=tonumber(part[4]),tonumber(part[5])
    if not a or not b or a<0 or a>400 or b<0 or b>100 or
       a~=math.floor(a) or b~=math.floor(b) then return end
    local sourceGUID=part[6] and part[6]~='' and part[6] or nil
    if sourceGUID and (UnitGUID and UnitGUID('player'))==sourceGUID then return end
    -- Recognize clients that share statistics but do not send presence pings.
    observePresence(sender,channel)
    if channel=='WHISPER' and community.syncPrefixReady and hasSyncTransport() then
      local key='WHISPER:'..identityText(sender)
      if clock()-(presenceLastAck[key] or -1000)>=120 and
         syncSendMessage('V1^A^1^'..VERSION,'WHISPER',sender) then
        presenceLastAck[key]=clock()
      end
    end
    syncIncoming[sender]={sid=sid,expectedItems=a,expectedZones=b,gotItems=0,gotZones=0,
      sourceGUID=sourceGUID,
      items={},zones={},seenItems={},seenZones={},receivedAt=clock(),ended=false}
    return
  end
  local r=syncIncoming[sender]
  if not r or r.sid~=sid then return end
  r.receivedAt=clock()
  if code=='I' and #part==19 then
    local key=decodeSyncText(part[4])
    local zone=decodeSyncText(part[5])
    if #key<1 or #key>100 or #zone>85 or r.seenItems[key] then return end
    local entry=blankStats()
    for i,field in ipairs(SYNC_FIELDS) do
      local n=tonumber(part[i+5])
      if not n or n~=math.floor(n) or math.abs(n)>10000000000000 then return end
      if field~='net' and n<0 then return end
      entry[field]=n
    end
    entry.zone=zone~='' and zone or 'Unknown'
    r.items[key]=entry;r.seenItems[key]=true;r.gotItems=r.gotItems+1
  elseif code=='Z' and #part==6 then
    local zone=decodeSyncText(part[4])
    local n,amount=tonumber(part[5]),tonumber(part[6])
    if #zone<1 or #zone>85 or r.seenZones[zone] or not n or not amount or
       n<0 or n>10000000 or amount<0 or amount>10000000000000 or
       n~=math.floor(n) or amount~=math.floor(amount) then return end
    r.zones[zone]={pouchSamples=n,pouches=amount}
    r.seenZones[zone]=true;r.gotZones=r.gotZones+1
  elseif code=='E' then
    r.ended=true
  end
  if r.gotItems>r.expectedItems or r.gotZones>r.expectedZones then
    syncIncoming[sender]=nil;return
  end
  finishIncoming(sender,r)
end
community.tickSyncSend=function()
  if not syncOutgoing or clock()<(syncOutgoing.nextAt or 0) then return end
  local state=syncOutgoing
  local d=state.destinations[state.destinationIndex]
  if not d then
    say('Community send finished across '..state.delivered..' route(s)'..
      (state.failed>0 and ('; '..state.failed..' unavailable route(s).') or '.')..
      ' Other players must be online with Writ This installed to receive it.')
    syncOutgoing=nil
    return
  end
  local message=state.messages[state.packetIndex]
  if not message then
    state.delivered=state.delivered+1
    state.destinationIndex=state.destinationIndex+1
    state.packetIndex=1
    state.nextAt=clock()+.32
    return
  end
  local ok,err=syncSendMessage(message,d.channel,d.target)
  if not ok then
    if err=='throttle' and state.retries<8 then
      state.retries=state.retries+1
      state.nextAt=clock()+1.5
      return
    end
    state.failed=state.failed+1
    say('Cannot send to '..d.channel..(d.target and (':'..d.target) or '')..
      ' ('..tostring(err)..'); trying remaining routes.')
    state.destinationIndex=state.destinationIndex+1
    state.packetIndex=1
    state.retries=0
    state.nextAt=clock()+.32
    return
  end
  state.packetIndex=state.packetIndex+1
  state.retries=0
  state.nextAt=clock()+.32 -- Slow enough for the Classic addon-message throttle.
end
community.tickBackground=function()
  if syncOutgoing then community.tickSyncSend() end
  if next(syncIncoming) then community.tickSyncReceive() end
  if community.tickPresence then community.tickPresence() end
end
community.tickSyncReceive=function()
  for sender,r in pairs(syncIncoming) do
    if clock()-(r.receivedAt or 0)>120 then syncIncoming[sender]=nil end
  end
end

end -- community stats and synchronization helpers

local function matchingBookEntries()
  local matches={}
  -- Missing refers ONLY to an unknown turn-in zone, not an absent
  -- coordinate pair. Zone-known writs remain visible with Missing: Off.
  -- Personal edits have already been applied to bookEntries.
  local function missing(entry)
    local zone=trim(entry.zone):lower()
    return zone=='' or zone=='unknown' or zone=='not revealed'
  end
  if bookMode=='zones' then
    local zoneMap={}
    for _,entry in ipairs(bookEntries) do
      if (DB.bookMissingOnly == true) == missing(entry) then
        local zone=entry.zone or 'Unknown'
        if not zoneMap[zone] then
          zoneMap[zone]={key='zone:'..zone,zone=zone,item='Zone summary',kind='zone',numberOfItems=0}
        end
        zoneMap[zone].numberOfItems=zoneMap[zone].numberOfItems+1
        local searchable=(entry.item..' '..zone..' '..(entry.npc or '')):lower()
        if bookQuery=='' or searchable:find(bookQuery,1,true) then zoneMap[zone].match=true end
      end
    end
    for _,zone in pairs(zoneMap) do
      if zone.match then matches[#matches+1]=zone end
    end
  else
    for _,entry in ipairs(bookEntries) do
      if (DB.bookMissingOnly == true) == missing(entry) then
        local searchable=(entry.item..' '..entry.zone..' '..(entry.npc or '')):lower()
        if bookQuery=='' or searchable:find(bookQuery,1,true) then
          matches[#matches+1]=entry
        end
      end
    end
  end
  if bookSort=='efficiency' then
    table.sort(matches,function(a,b)
      local as=community.statsFor(a.kind=='zone' and nil or a.key,a.kind=='zone' and a.zone or nil)
      local bs=community.statsFor(b.kind=='zone' and nil or b.key,b.kind=='zone' and b.zone or nil)
      local av=as.pricedRep>0 and as.net/as.pricedRep or math.huge
      local bv=bs.pricedRep>0 and bs.net/bs.pricedRep or math.huge
      if av~=bv then return av<bv end
      return a.zone..a.item<b.zone..b.item
    end)
  elseif bookSort=='location' or bookMode=='zones' then
    table.sort(matches,function(a,b)
      if a.zone~=b.zone then return a.zone:lower()<b.zone:lower() end
      return a.item:lower()<b.item:lower()
    end)
  else
    table.sort(matches,function(a,b)
      if a.item~=b.item then return a.item:lower()<b.item:lower() end
      return a.zone:lower()<b.zone:lower()
    end)
  end
  return matches
end
-- Read real player coordinates for the item being edited. Never record map
-- coordinates from another zone or silently save an invalid (0,0) result.
local function capturePlayerCoordinates(expectedZone)
  local currentZone=trim((GetRealZoneText and GetRealZoneText()) or
                         (GetZoneText and GetZoneText()) or '')
  if currentZone=='' then return nil,nil,nil,'Current zone is unavailable.' end
  local expected=trim(expectedZone)
  if expected~='' and expected:lower()~='unknown' and expected:lower()~=currentZone:lower() then
    return nil,nil,nil,'You are in '..currentZone..', but this writ is listed in '..expected..'. No coordinates captured.'
  end
  local x,y=nil,nil
  -- The Forever client supports C_Map. Search parent maps for the selected
  -- zone so a subzone map does not produce coordinates in the wrong scale.
  if C_Map and type(C_Map.GetBestMapForUnit)=='function' and
     type(C_Map.GetPlayerMapPosition)=='function' then
    local mapID=C_Map.GetBestMapForUnit('player')
    local bestID=nil
    for _=1,12 do
      if not mapID or mapID==0 then break end
      local info=C_Map.GetMapInfo and C_Map.GetMapInfo(mapID)
      if info and type(info.name)=='string' and info.name:lower()==currentZone:lower() then
        bestID=mapID;break
      end
      mapID=info and info.parentMapID or nil
    end
    -- Avoid saving a position relative to the wrong subzone map.
    if bestID then
      local pos=C_Map.GetPlayerMapPosition(bestID,'player')
      if pos then
        if type(pos.GetXY)=='function' then x,y=pos:GetXY()
        else x,y=pos.x,pos.y end
      end
    end
  end
  -- Older client fallback: explicitly move the map to the player's zone.
  if not x and type(GetPlayerMapPosition)=='function' then
    if type(SetMapToCurrentZone)=='function' then SetMapToCurrentZone() end
    x,y=GetPlayerMapPosition('player')
  end
  x,y=tonumber(x),tonumber(y)
  if not x or not y or x<0 or x>1 or y<0 or y>1 or (x==0 and y==0) then
    return nil,nil,nil,'Map coordinates unavailable here. Try outdoors in the turn-in zone.'
  end
  return currentZone,x*100,y*100,nil
end

-- Automatically learn a writ's turn-in coordinates from a confirmed quest
-- completion and store them as an Items & Locations personal reference edit.
-- This is deliberately separate from writ costs, completed logs and sync data.
-- Do not overwrite an existing manual coordinate or a verified built-in pair.
community.captureTurnInLocation=function(order)
  if not DB or not order or order.sealed or not DB.bookOverrides then return end
  local key=itemKey(requiredItemName(order))
  if key=='' then return end
  local existing=DB.bookOverrides[key]
  if existing and (tonumber(existing.x) or tonumber(existing.y)) then return end
  local expected,npc,oldX,oldY=writLocation(order)
  if oldX or oldY then return end
  if expected=='Unknown' or expected=='Not revealed' then expected=nil end
  local zone,x,y,err=capturePlayerCoordinates(expected)
  if not zone then
    debugMessage('Turn-in coordinates not saved for '..key..': '..tostring(err))
    return
  end
  -- Modify only the reference override for this exact required item.
  local override=existing or {}
  if override.zone and trim(override.zone)~='' and
     trim(override.zone):lower()~=zone:lower() then
    debugMessage('Refused turn-in coordinates: personal zone does not match '..zone)
    return
  end
  if not override.zone or trim(override.zone)=='' then override.zone=zone end
  override.x=tonumber(string.format('%.1f',x))
  override.y=tonumber(string.format('%.1f',y))
  DB.bookOverrides[key]=override
  populateBook()
  if bookRefresh then bookRefresh(true) end
  if refresh then refresh(true) end
  debugMessage(string.format('Saved turn-in coordinates: %s in %s (%.1f, %.1f)',
    key,zone,override.x,override.y))
  say(string.format('Saved %s turn-in: %s (%.1f, %.1f) to History/Records.',
    requiredItemName(order) or key,zone,override.x,override.y))
end

local function makeBookEditor()
  bookEditor=CreateFrame('Frame','WritThisReferenceEditor',UIParent,BackdropTemplateMixin and 'BackdropTemplate')
  bookEditor:SetSize(425,335);bookEditor:SetPoint('CENTER',UIParent,'CENTER',0,0)
  bookEditor:SetFrameStrata('DIALOG');bookEditor:SetMovable(true);bookEditor:EnableMouse(true)
  skinFrame(bookEditor);makeDraggable(bookEditor,'bookEditPos')
  local heading=textLine(bookEditor,'EDIT REFERENCE INFO',350,true)
  heading:SetPoint('TOPLEFT',18,-20)
  createButton(bookEditor,'X',25,24,function()rows.navigation.close(bookEditor)end):SetPoint('TOPRIGHT',-12,-13)
  local fields={{'zone','Zone'},{'npc','NPC'},{'x','X coordinate'},{'y','Y coordinate'},{'rep','Reputation'}}
  bookEditor.fields={}
  for i,field in ipairs(fields) do
    local name,label=field[1],field[2]
    local line=textLine(bookEditor,label,115)
    line:SetPoint('TOPLEFT',19,-59-(i-1)*39)
    local box=CreateFrame('EditBox',nil,bookEditor,BackdropTemplateMixin and 'BackdropTemplate')
    box:SetSize(250,27);box:SetPoint('TOPLEFT',143,-51-(i-1)*39)
    skinFrame(box);box:SetFontObject(GameFontNormalSmall)
    rows.skinText[box]=true
    box:SetTextColor(unpack(skin().text));box:SetTextInsets(7,7,0,0)
    box:SetAutoFocus(false);box:SetMaxLetters(100)
    box:SetScript('OnEscapePressed',function(self)self:ClearFocus()end)
    box:SetScript('OnEnterPressed',function(self)self:ClearFocus()end)
    bookEditor.fields[name]=box
  end
  local note=textLine(bookEditor,'Blank restores defaults if zone matches. New zones clear old map data.',390)
  note:SetPoint('BOTTOMLEFT',18,57)
  -- Save only after the player accepts a proper confirmation dialog. Its
  -- payload is an immutable snapshot of the fields at the time of clicking.
  -- A declined dialog leaves the editor and everything in SavedVariables alone.
  local function applyReferenceSave(data)
    if not DB or not data or not data.key then return end
    DB.bookOverrides[data.key]={zone=data.zone,npc=data.npc,
      x=data.x,y=data.y,rep=data.rep}
    bookEditor:Hide()
    populateBook();bookRefresh()
    if refresh then refresh() end
    say('Saved personal reference details for '..prettyItemName(data.key))
  end
  if StaticPopupDialogs then
    StaticPopupDialogs.WRITTHIS_REFERENCE_SAVE_CONFIRM={
      text='Save changes to %s?\nThis updates your personal reference only.',
      button1='Save Changes',button2='Cancel',
      OnAccept=function(_,data) applyReferenceSave(data) end,
      timeout=0,whileDead=true,hideOnEscape=true,preferredIndex=3,
    }
  end
  local saveButton=createButton(bookEditor,'Save reference',140,29,function()
    local key=bookEditor.editKey
    if not key then return end
    local fields=bookEditor.fields
    local zone=trim(fields.zone:GetText())
    local npc=trim(fields.npc:GetText())
    local xs,ys,rs=trim(fields.x:GetText()),trim(fields.y:GetText()),trim(fields.rep:GetText())
    local x=xs~='' and tonumber(xs) or nil
    local y=ys~='' and tonumber(ys) or nil
    local reputation=rs~='' and tonumber(rs) or nil
    if (xs~='' and not x) or (ys~='' and not y) or
       (rs~='' and not reputation) or
       (x and (x<0 or x>100)) or (y and (y<0 or y>100)) or
       (reputation and (reputation<1 or reputation>10000 or reputation~=math.floor(reputation))) or
       ((x==nil)~=(y==nil)) or (x==0 and y==0) then
      say('Invalid reference. Enter both X and Y as numbers 0-100 (not 0,0), and whole-number reputation.');return
    end
    local base=WRIT_LOCATIONS[key]
    local newZone=zone~='' and zone or (base and base[1]) or 'Unknown'
    local priorZone=bookEditor.originalZone or 'Unknown'
    local zoneChanged=trim(newZone):lower()~=trim(priorZone):lower()
    local oldX,oldY=tonumber(bookEditor.originalX),tonumber(bookEditor.originalY)
    -- When the zone changes and the user has not supplied a DIFFERENT pair,
    -- the old map coordinates cannot safely be used in the new zone. Setting
    -- false suppresses inherited catalog coords (nil would inherit them).
    local baseZone=base and trim(base[1]):lower() or 'unknown'
    local sameAsBase=trim(newZone):lower()==baseZone
    local stalePair=zoneChanged and x==oldX and y==oldY
    if stalePair or (zoneChanged and x==nil and y==nil) then
      -- If they return to the built-in zone, restore that zone's verified pair.
      if sameAsBase then x=nil;y=nil else x=false;y=false end
    elseif x==nil and y==nil and not sameAsBase then
      x=false;y=false
    end
    local storedNpc=npc~='' and npc or nil
    local npcUnchanged=npc==trim(bookEditor.originalNPC)
    if (zoneChanged and npcUnchanged) or npc=='' then
      -- Never inherit an NPC from a different zone. The false sentinel is
      -- deliberately separate from nil, which restores the built-in NPC.
      if sameAsBase then storedNpc=nil else storedNpc=false end
    end
    local data={key=key,zone=zone~='' and zone or nil,npc=storedNpc,
      x=x,y=y,rep=reputation}
    if not (StaticPopupDialogs and StaticPopup_Show) then
      say('Confirmation dialog is unavailable; reference changes were NOT saved.')
      return
    end
    StaticPopupDialogs.WRITTHIS_REFERENCE_SAVE_CONFIRM.text=
      (x==false and y==false and zoneChanged) and
      'Save changes to %s?\nZone changed: old coordinates and NPC details will be cleared for safety.' or
      'Save changes to %s?\nThis updates your personal zone, NPC, coordinates and reputation.'
    StaticPopup_Show('WRITTHIS_REFERENCE_SAVE_CONFIRM',prettyItemName(key),nil,data)
  end)
  saveButton:SetPoint('BOTTOMLEFT',19,15)
  local recordCoords=createButton(bookEditor,'Record Coordinates',171,29,function()
    if not bookEditor.editKey then return end
    local fields=bookEditor.fields
    local zone,x,y,err=capturePlayerCoordinates(fields.zone:GetText())
    if not zone then say(err or 'Could not capture coordinates.');return end
    if trim(fields.zone:GetText())=='' or trim(fields.zone:GetText()):lower()=='unknown' then
      fields.zone:SetText(zone)
    end
    fields.x:SetText(string.format('%.1f',x))
    fields.y:SetText(string.format('%.1f',y))
    say(string.format('Captured %s (%.1f, %.1f). Click Save reference to keep it.',zone,x,y))
  end)
  recordCoords:SetPoint('LEFT',saveButton,'RIGHT',9,0)
  bookEditor.recordCoords=recordCoords
  bookEditor.saveButton=saveButton
  bookEditor:Hide()
  rows.registerPopup(bookEditor)
end
local function openBookEditor()
  if bookMode~='items' or not bookSelected then
    say('Choose an item in Items view before editing reference details.')
    return
  end
  local chosen
  for _,e in ipairs(bookEntries) do if e.key==bookSelected then chosen=e;break end end
  if not chosen then return end
  bookEditor.editKey=chosen.key
  bookEditor.originalZone=chosen.zone
  bookEditor.originalNPC=chosen.npc
  bookEditor.originalX=chosen.x
  bookEditor.originalY=chosen.y
  local f=bookEditor.fields
  for _,key in ipairs({'zone','npc','x','y','rep'}) do
    f[key]:SetText(chosen[key] and tostring(chosen[key]) or '')
  end
  bookEditor:Show()
end
local function makePouchEditor()
  pouchEditor=CreateFrame('Frame','WritThisPouchEditor',UIParent,BackdropTemplateMixin and 'BackdropTemplate')
  pouchEditor:SetSize(465,229)
  pouchEditor:SetPoint('CENTER',UIParent,'CENTER',0,0)
  pouchEditor:SetFrameStrata('FULLSCREEN_DIALOG')
  skinFrame(pouchEditor)
  local heading=textLine(pouchEditor,'SUBMIT COIN POUCH',390,true)
  heading:SetPoint('TOPLEFT',18,-19)
  createButton(pouchEditor,'X',25,24,function()rows.navigation.close(pouchEditor)end):SetPoint('TOPRIGHT',-12,-12)
  local target=textLine(pouchEditor,'',420)
  target:SetPoint('TOPLEFT',18,-58)
  pouchEditor.target=target
  local hint=textLine(pouchEditor,'Only enter the actual amount received (example: 25s50c).',426)
  hint:SetPoint('TOPLEFT',18,-87)
  local input=CreateFrame('EditBox',nil,pouchEditor,BackdropTemplateMixin and 'BackdropTemplate')
  input:SetSize(180,30);input:SetPoint('TOPLEFT',18,-114)
  skinFrame(input);input:SetFontObject(GameFontNormalSmall)
  rows.skinText[input]=true
  input:SetTextColor(unpack(skin().text));input:SetTextInsets(7,7,0,0)
  input:SetAutoFocus(false);input:SetMaxLetters(22)
  input:SetScript('OnEscapePressed',function(self)self:ClearFocus();pouchEditor:Hide()end)
  pouchEditor.input=input
  local warning=textLine(pouchEditor,'',429)
  warning:SetPoint('TOPLEFT',18,-155)
  pouchEditor.warning=warning
  -- The same amount-entry frame can be opened on one exact pending writ,
  -- without creating a free-standing reference-book payout sample.
  -- Confirmation is a separate popup: closing either dialog changes nothing.
  local function confirmManualRecovery(data)
    if not DB or not data or not data.recordID then return end
    local e=entryByID(data.recordID)
    if not e or not e.complete or e.pouchPaid or e.sealed then
      say('Pouch recovery cancelled: this writ is no longer awaiting payout.')
      return
    end
    local amount=tonumber(data.amount)
    if not amount or amount<=0 then return end
    if archivePouch(e,amount,'Manual Shift+Middle payout recovery') then
      -- archivePouch has already retired any unverified transient candidates;
      -- never reassign leftovers from a rapid group to an unrelated writ.
      addLog('POUCH RECOVERY',e,'Confirmed manual payout; archived once')
      debugMessage('Manual pouch recovery for writ #'..tostring(e.id))
    end
  end
  if StaticPopupDialogs then
    StaticPopupDialogs.WRITTHIS_POUCH_RECOVERY_CONFIRM={
      text='Manually archive this writ?\n%s\nCoin Pouch paid: %s\n\nOnly confirm after you have OPENED the pouch and verified the actual amount. This removes the writ from Active and cannot be undone from the list.',
      button1='Confirm Payout',button2='Cancel',
      OnAccept=function(_,data) confirmManualRecovery(data) end,
      timeout=0,whileDead=true,hideOnEscape=true,preferredIndex=3,
    }
  end
  local function submit()
    local amount=parseMoney and parseMoney(input:GetText())
    if amount==nil or amount<=0 then
      say('Enter a positive Coin Pouch amount, for example 25s50c.');return
    end
    if pouchEditor.targetRecordID then
      local e=entryByID(pouchEditor.targetRecordID)
      if not e or not e.complete or e.pouchPaid or e.sealed then
        say('This writ is no longer awaiting a Coin Pouch payout.')
        pouchEditor:Hide();return
      end
      if not (StaticPopupDialogs and StaticPopup_Show) then
        say('Payout confirmation is unavailable; NO writ was archived.')
        return
      end
      -- Snapshot the record ID and payout at submission time. A later row
      -- selection change cannot redirect this payout to another writ.
      local data={recordID=e.id,amount=amount}
      pouchEditor:Hide()
      if not StaticPopup_Show('WRITTHIS_POUCH_RECOVERY_CONFIRM',e.writ,fmtMoney(amount),data) then
        say('Could not open payout confirmation; nothing was changed.')
      end
      return
    end
    local key,zone=pouchEditor.targetKey,pouchEditor.targetZone
    if not key and not zone then return end
    local pending={}
    for _,e in ipairs(DB.orders or {}) do
      if e.complete and not e.pouchPaid then
        local ek=itemKey(requiredItemName(e))
        local ez=writLocation(e)
        local over=DB.bookOverrides and DB.bookOverrides[ek]
        if over and over.zone then ez=over.zone end
        if (key and ek==key) or (not key and zone and ez==zone) then
          pending[#pending+1]=e
        end
      end
    end
    if #pending>1 then
      say('Multiple writs await a pouch here. Select the exact writ in the main list and use /writ payout 25s, or select its item in Items view.');return
    end
    if #pending==1 then
      local e=pending[1]
      if archivePouch(e,amount,'Manual History/Records entry') then
        say('Pouch recorded against completed writ (no duplicate sample created).')
        pouchEditor:Hide();return
      end
    end
    -- No completed writ waiting for payout: keep a pouch-only observation.
    -- This improves the payout average, but does not invent a cost, run or rep.
    DB.pouchSamples=DB.pouchSamples or {}
    local now=clock()
    if lastPouchEditorSubmit and now-lastPouchEditorSubmit<2 then return end
    lastPouchEditorSubmit=now
    table.insert(DB.pouchSamples,{key=key,zone=zone,amount=amount,at=datetime(),source='Manual book entry'})
    addLog('POUCH SAMPLE',nil,'Reference payout '..fmtMoney(amount)..' for '..(key or zone))
    say('Saved standalone Coin Pouch observation: '..fmtMoney(amount)..'. It counts once in the average, not as a completed writ.')
    pouchEditor:Hide()
    if bookRefresh then bookRefresh() end
  end
  local submitButton=createButton(pouchEditor,'Submit Pouch',136,28,submit)
  submitButton:SetPoint('BOTTOMLEFT',18,16)
  pouchEditor.submitButton=submitButton
  createButton(pouchEditor,'Cancel',98,28,function()pouchEditor:Hide()end):SetPoint('BOTTOMLEFT',166,16)
  input:SetScript('OnEnterPressed',function(self)self:ClearFocus();submit()end)
  pouchEditor:Hide()
  rows.registerPopup(pouchEditor)
  rows.openManualPouchRecovery=function(recordID)
    local e=recordID and entryByID(recordID)
    if not e or not e.complete or e.pouchPaid or e.sealed then
      say('Shift + Middle-click only works for a turned-in writ marked Awaiting Pouch (*).')
      return
    end
    pouchEditor.targetRecordID=e.id
    pouchEditor.targetKey=nil
    pouchEditor.targetZone=nil
    pouchEditor.target:SetText('Writ #'..tostring(e.id)..': '..tostring(e.writ or '?'))
    pouchEditor.warning:SetText('Enter the actual payout from the pouch you already opened.')
    pouchEditor.submitButton.text:SetText('Review Payout')
    pouchEditor.input:SetText('')
    pouchEditor:Show()
  end
end
openPouchEditor=function()
  if not bookSelected or not itemsBook then return end
  pouchEditor.targetRecordID=nil
  pouchEditor.submitButton.text:SetText('Submit Pouch')
  local chosen
  for _,entry in ipairs(matchingBookEntries()) do
    if entry.key==bookSelected then chosen=entry;break end
  end
  if not chosen then say('Select an item or zone first.');return end
  if chosen.kind=='zone' then
    pouchEditor.targetKey=false
  else
    pouchEditor.targetKey=chosen.key
  end
  pouchEditor.targetZone=chosen.zone
  pouchEditor.target:SetText((chosen.kind=='zone' and 'Zone: '..chosen.zone) or
    ('Required item: '..chosen.item..'  |  '..chosen.zone))
  local matches=0
  for _,e in ipairs(DB.orders) do
    if e.complete and not e.pouchPaid then
      local k=itemKey(requiredItemName(e))
      local z=writLocation(e)
      local over=DB.bookOverrides and DB.bookOverrides[k]
      if over and over.zone then z=over.zone end
      if (pouchEditor.targetKey and k==pouchEditor.targetKey) or
         (not pouchEditor.targetKey and z==chosen.zone) then
        matches=matches+1
      end
    end
  end
  if matches==1 then
    pouchEditor.warning:SetText('One writ awaiting payout: this will complete that record.')
  elseif matches>1 then
    pouchEditor.warning:SetText('Several writs pending: select a specific writ to assign payout.')
  else
    pouchEditor.warning:SetText('No pending writ: adds one standalone payout observation only.')
  end
  pouchEditor.input:SetText('')
  lastPouchEditorSubmit=nil
  pouchEditor:Show()
end
-- A read-only history of PAID writs and manual pouch observations for
-- exactly the selected reference item or the selected zone.
local referenceLogRows={}
local referenceLogPage=1
local referenceLogKey,referenceLogZone=nil,nil
local referenceLogRefresh
local function referenceLogRecords(key,zone)
  local result={}
  for _,e in ipairs(DB.completed or {}) do
    local k=itemKey(requiredItemName(e))
    local z=writLocation(e)
    local over=DB.bookOverrides and DB.bookOverrides[k]
    if over and over.zone then z=over.zone end
    if (key and k==key) or (not key and zone and z==zone) then
      local total=e.totalCost
      if total==nil and not e.priceUnknown and e.itemCostKnown and not e.itemPriceUnknown and not rows.itemPricePending(e) then
        total=(tonumber(e.writCost) or 0)+(tonumber(e.itemCost) or 0)
      end
      result[#result+1]={kind='run',name=requiredItemName(e) or e.writ or 'Unknown writ',
        at=e.pouchReceivedAt or e.completedAt or '',cost=total,
        pouch=tonumber(e.pouchAmount),rep=tonumber(e.repEarned),id=e.id or 0}
    end
  end
  for i,sample in ipairs(DB.pouchSamples or {}) do
    local sz=sample.zone
    if sample.key then
      local over=DB.bookOverrides and DB.bookOverrides[sample.key]
      if over and over.zone then sz=over.zone end
    end
    if (key and sample.key==key) or (not key and zone and sz==zone) then
      result[#result+1]={kind='sample',name=sample.key and prettyItemName(sample.key) or
        ('Zone: '..(sz or 'Unknown')),at=sample.at or '',pouch=tonumber(sample.amount),id=i}
    end
  end
  table.sort(result,function(a,b)
    if a.at==b.at then
      if a.kind~=b.kind then return a.kind=='run' end
      return a.id>b.id
    end
    return a.at>b.at
  end)
  return result
end
local function makeReferenceLog()
  referenceLog=CreateFrame('Frame','WritThisReferenceLog',UIParent,BackdropTemplateMixin and 'BackdropTemplate')
  referenceLog:SetSize(670,555)
  referenceLog:SetPoint('CENTER',UIParent,'CENTER',10,0)
  referenceLog:SetFrameStrata('FULLSCREEN_DIALOG')
  referenceLog:SetMovable(true);referenceLog:EnableMouse(true);referenceLog:SetClampedToScreen(true)
  skinFrame(referenceLog);makeDraggable(referenceLog,'referenceLogPos')
  local heading=textLine(referenceLog,'WRIT COMPLETION LOG',430,true)
  heading:SetPoint('TOPLEFT',18,-17)
  createButton(referenceLog,'X',25,24,function()rows.navigation.close(referenceLog)end):SetPoint('TOPRIGHT',-13,-13)
  local target=textLine(referenceLog,'',625)
  target:SetPoint('TOPLEFT',18,-56);referenceLog.target=target
  local summary=textLine(referenceLog,'',615)
  summary:SetPoint('TOPLEFT',18,-80);referenceLog.summary=summary
  local divider=referenceLog:CreateTexture(nil,'ARTWORK')
  divider:SetColorTexture(.85,.82,.76,.48)
  divider:SetHeight(1);divider:SetPoint('TOPLEFT',18,-104);divider:SetPoint('TOPRIGHT',-18,-104)
  local perPage=8
  for i=1,perPage do
    local panel=CreateFrame('Frame',nil,referenceLog)
    panel:SetPoint('TOPLEFT',18,-115-(i-1)*48);panel:SetPoint('TOPRIGHT',-18,-115-(i-1)*48)
    panel:SetHeight(46)
    local main=textLine(panel,'',615)
    main:SetPoint('TOPLEFT',5,-3)
    local detail=textLine(panel,'',615)
    detail:SetPoint('TOPLEFT',5,-24)
    detail:SetTextColor(.84,.81,.73)
    local line=panel:CreateTexture(nil,'ARTWORK')
    line:SetColorTexture(.86,.83,.78,.33)
    line:SetHeight(1)
    line:SetPoint('BOTTOMLEFT',0,1);line:SetPoint('BOTTOMRIGHT',0,1)
    panel.main=main;panel.detail=detail
    referenceLogRows[i]=panel
  end
  local prev=createButton(referenceLog,'<',30,25,function()
    referenceLogPage=math.max(1,referenceLogPage-1)
    referenceLogRefresh()
  end)
  prev:SetPoint('BOTTOMLEFT',18,16)
  local pages=textLine(referenceLog,'Page 1 / 1',100)
  pages:SetJustifyH('CENTER');pages:SetPoint('LEFT',prev,'RIGHT',12,0)
  referenceLog.pages=pages
  local nextB=createButton(referenceLog,'>',30,25,function()
    referenceLogPage=referenceLogPage+1
    referenceLogRefresh()
  end)
  nextB:SetPoint('LEFT',pages,'RIGHT',8,0)
  local foot=textLine(referenceLog,'Manual pouch-only entries have no assumed cost or reputation.',400)
  foot:SetTextColor(.66,.63,.57);foot:SetPoint('BOTTOMRIGHT',-19,22)
  referenceLog:Hide()
  rows.registerPopup(referenceLog)
end
referenceLogRefresh=function()
  if not referenceLog then return end
  local entries=referenceLogRecords(referenceLogKey,referenceLogZone)
  local count=#entries
  local runs=0;local samples=0
  for _,e in ipairs(entries) do
    if e.kind=='run' then runs=runs+1 else samples=samples+1 end
  end
  referenceLog.summary:SetText('Completed runs: '..runs..'   |   Manual pouch samples: '..samples)
  local pages=math.max(1,math.ceil(count/#referenceLogRows))
  referenceLogPage=math.max(1,math.min(pages,referenceLogPage))
  referenceLog.pages:SetText('Page '..referenceLogPage..' / '..pages)
  for i,row in ipairs(referenceLogRows) do
    local e=entries[(referenceLogPage-1)*#referenceLogRows+i]
    if e then
      if e.kind=='run' then
        row.main:SetText((e.at~='' and e.at or 'Unknown date')..'   |   '..e.name)
        local label='Cost '..(e.cost and fmtMoney(e.cost) or 'None')..
          '   |   Pouch '..(e.pouch and fmtMoney(e.pouch) or 'None')..
          '   |   Rep '..(e.rep and tostring(e.rep) or 'Unknown')
        if e.cost~=nil and e.pouch~=nil then
          local net=e.cost-e.pouch
          label=label..'   |   '..(net<0 and 'PROFIT ' or 'TRUE COST ')..fmtMoney(math.abs(net))
        end
        row.detail:SetText(label)
      else
        row.main:SetText((e.at~='' and e.at or 'Unknown date')..'   |   '..e.name)
        row.detail:SetText('MANUAL POUCH SAMPLE   |   Payout '..(e.pouch and fmtMoney(e.pouch) or 'None')..
          '   |   No cost or rep assigned')
      end
      row:Show()
    else row:Hide() end
  end
end
local function openReferenceLog()
  if not bookSelected then say('Select a reference item or zone first.');return end
  local chosen
  for _,entry in ipairs(matchingBookEntries()) do
    if entry.key==bookSelected then chosen=entry;break end
  end
  if not chosen then return end
  referenceLogKey=nil
  if chosen.kind~='zone' then referenceLogKey=chosen.key end
  referenceLogZone=chosen.zone
  referenceLogPage=1
  referenceLog.target:SetText(chosen.kind=='zone' and ('Zone: '..chosen.zone) or
    ('Item: '..chosen.item..'   |   '..chosen.zone))
  referenceLogRefresh()
  referenceLog:Show()
end

function rows.openReferenceMap(entry)
  if not entry or not entry.zone or entry.zone=='Unknown' or
     entry.zone=='Not revealed' then return end
  local matched,count=nil,0
  -- If exactly one unposted active writ matches this item, associate its
  -- waypoint with that writ so the existing confirmed-turn-in cleanup works.
  -- With zero or multiple matches, use an isolated reference-only owner.
  if entry.kind~='zone' and DB then
    for _,candidate in ipairs(DB.orders or {}) do
      if not candidate.complete and not candidate.sold and
         not candidate.resaleSold and not candidate.resaleListed and
         not candidate.sealed and
         itemKey(requiredItemName(candidate))==entry.key then
        count=count+1;matched=candidate
        if count>1 then break end
      end
    end
  end
  if count==1 then rows.openTurnInMap(matched)
  else rows.openTurnInMap(nil,entry) end
end
local function makeItemsBook()
  populateBook()
  itemsBook=CreateFrame('Frame','WritThisItemsLocationsFrame',UIParent,BackdropTemplateMixin and 'BackdropTemplate')
  -- Remember expanded and compact heights independently, preserving the existing book size.
  local initialBookHeight
  if DB.bookShowDetails==false then
    initialBookHeight=math.min(900,math.max(340,DB.bookCompactHeight or 430))
  else
    initialBookHeight=math.min(900,math.max(590,DB.bookHeight or 655))
  end
  itemsBook:SetSize(math.min(1040,math.max(600,DB.bookWidth or 750)),initialBookHeight)
  itemsBook:SetFrameStrata('DIALOG')
  itemsBook:SetMovable(true);itemsBook:EnableMouse(true);itemsBook:SetClampedToScreen(true)
  position(itemsBook,'bookPos',-190,10)
  skinFrame(itemsBook)
  local heading=itemsBook:CreateTexture(nil,'BORDER')
  heading:SetTexture('Interface\\Buttons\\WHITE8X8')
  rows.skinHeaders[heading]=true
  heading:SetColorTexture(unpack(skin().header))
  heading:SetPoint('TOPLEFT',5,-5);heading:SetPoint('TOPRIGHT',-5,-5);heading:SetHeight(46)
  local title=textLine(itemsBook,'HISTORY/RECORDS',nil,true)
  title:SetPoint('TOPLEFT',18,-17)
  local sharedCheckbox=CreateFrame('CheckButton',nil,itemsBook,'UICheckButtonTemplate')
  sharedCheckbox:SetSize(24,24)
  sharedCheckbox:SetPoint('TOPLEFT',221,-15)
  sharedCheckbox:SetChecked(DB.bookShowCommunity==true)
  sharedCheckbox:SetScript('OnClick',function(self)
    DB.bookShowCommunity=self:GetChecked() and true or false
    bookPage=1
    if bookRefresh then bookRefresh() end
  end)
  local sharedLabel=textLine(itemsBook,'Include Shared Data',190)
  sharedLabel:SetPoint('LEFT',sharedCheckbox,'RIGHT',2,0)
  sharedLabel:SetTextColor(.52,.73,1)
  itemsBook.sharedCheckbox=sharedCheckbox
  -- Personal setting: collapse the large reference/statistics panel while keeping the list.
  local detailsCheckbox=CreateFrame('CheckButton',nil,itemsBook,'UICheckButtonTemplate')
  detailsCheckbox:SetSize(24,24)
  detailsCheckbox:SetPoint('TOPLEFT',430,-15)
  detailsCheckbox:SetChecked(DB.bookShowDetails~=false)
  local detailsLabel=textLine(itemsBook,'Show Details',104)
  detailsLabel:SetPoint('LEFT',detailsCheckbox,'RIGHT',2,0)
  detailsCheckbox:SetScript('OnClick',function(self)
    local newState=self:GetChecked() and true or false
    if newState == (DB.bookShowDetails~=false) then return end
    if DB.bookShowDetails==false then
      DB.bookCompactHeight=math.floor(itemsBook:GetHeight()+.5)
    else
      DB.bookHeight=math.floor(itemsBook:GetHeight()+.5)
    end
    DB.bookShowDetails=newState
    local minimum=newState and 590 or 340
    if itemsBook.SetResizeBounds then itemsBook:SetResizeBounds(600,minimum,1040,900)
    else
      if itemsBook.SetMinResize then itemsBook:SetMinResize(600,minimum) end
    end
    itemsBook:SetHeight(newState and math.min(900,math.max(590,DB.bookHeight or 655))
      or math.min(900,math.max(340,DB.bookCompactHeight or 430)))
    bookPage=1
    if bookRefresh then bookRefresh() end
  end)
  itemsBook.detailsCheckbox=detailsCheckbox
  makeDraggable(itemsBook,'bookPos')
  createButton(itemsBook,'X',26,26,function()rows.navigation.close(itemsBook)end):SetPoint('TOPRIGHT',-12,-13)
  local count=textLine(itemsBook,'',380)
  count:SetPoint('TOPLEFT',18,-55);itemsBook.count=count
  local searchLabel=textLine(itemsBook,'Search:',58)
  searchLabel:SetPoint('TOPLEFT',18,-90)
  local edit=CreateFrame('EditBox',nil,itemsBook,BackdropTemplateMixin and 'BackdropTemplate')
  edit:SetSize(265,26)
  edit:SetPoint('TOPLEFT',75,-80)
  skinFrame(edit)
  edit:SetFontObject(GameFontNormalSmall)
  rows.skinText[edit]=true
  edit:SetTextColor(unpack(skin().text))
  edit:SetTextInsets(7,7,0,0)
  edit:SetAutoFocus(false)
  edit:SetMaxLetters(90)
  edit:SetText('')
  edit:SetScript('OnEscapePressed',function(self)self:ClearFocus()end)
  edit:SetScript('OnEnterPressed',function(self)self:ClearFocus()end)
  edit:SetScript('OnTextChanged',function(self)
    bookQuery=trim(self:GetText()):lower()
    bookPage=1;bookSelected=nil
    if bookRefresh then bookRefresh() end
  end)
  itemsBook.search=edit
  local sortButton=createButton(itemsBook,'Sort: Location',127,26,function(self)
    bookSort=(bookSort=='location' and 'item') or (bookSort=='item' and 'efficiency') or 'location'
    self.text:SetText((bookSort=='location' and 'Sort: Location') or (bookSort=='item' and 'Sort: Item') or 'Sort: Efficiency')
    bookPage=1;bookSelected=nil
    bookRefresh()
  end)
  sortButton:SetPoint('TOPRIGHT',-18,-80)
  itemsBook.sortButton=sortButton
  local viewButton=createButton(itemsBook,'View: Items',116,26,function(self)
    bookMode=(bookMode=='items') and 'zones' or 'items'
    self.text:SetText(bookMode=='items' and 'View: Items' or 'View: Zones')
    bookPage=1;bookSelected=nil;bookRefresh()
  end)
  viewButton:SetPoint('RIGHT',sortButton,'LEFT',-7,0)
  itemsBook.viewButton=viewButton
  local missingButton=createButton(itemsBook,DB.bookMissingOnly and 'Missing: On' or 'Missing: Off',96,26,function(self)
    DB.bookMissingOnly=not DB.bookMissingOnly
    self.text:SetText(DB.bookMissingOnly and 'Missing: On' or 'Missing: Off')
    bookPage=1;bookSelected=nil
    bookRefresh()
  end)
  missingButton:SetPoint('LEFT',edit,'RIGHT',8,0)
  itemsBook.missingButton=missingButton
  missingButton:SetScript('OnEnter',function(self)
    if not GameTooltip then return end
    GameTooltip:SetOwner(self,'ANCHOR_RIGHT')
    GameTooltip:AddLine('Missing Locations',1,.8,.35)
    GameTooltip:AddLine('On: show only entries with missing zones or coordinates.',1,1,1,true)
    GameTooltip:AddLine('Off: hide missing entries and show only complete locations.',1,1,1,true)
    GameTooltip:AddLine('Works in Items and Zones views. Personal edits take priority.',.75,.75,.75,true)
    GameTooltip:Show()
  end)
  missingButton:SetScript('OnLeave',function()if GameTooltip then GameTooltip:Hide() end end)
  local header=textLine(itemsBook,'Turn-in zone                              Required item / personal efficiency',580)
  header:SetPoint('TOPLEFT',18,-129)
  local pageNext=createButton(itemsBook,'>',27,25,function()
    bookPage=bookPage+1;bookSelected=nil;bookRefresh()
  end)
  pageNext:SetPoint('TOPRIGHT',-18,-121)
  local pageText=textLine(itemsBook,'Page 1 / 1',95)
  pageText:SetJustifyH('CENTER')
  pageText:SetPoint('RIGHT',pageNext,'LEFT',-5,0)
  itemsBook.pageText=pageText
  createButton(itemsBook,'<',27,25,function()
    bookPage=math.max(1,bookPage-1);bookSelected=nil;bookRefresh()
  end):SetPoint('RIGHT',pageText,'LEFT',-5,0)
  for i=1,18 do
    local row=createButton(itemsBook,'',itemsBook:GetWidth()-36,26,function(self)
      if not self.entryKey then return end
      bookSelected=self.entryKey
      bookRefresh()
    end)
    row:SetPoint('TOPLEFT',18,-159-(i-1)*30)
    row.text:Hide()
    local zoneLabel=textLine(row,'',180)
    zoneLabel:SetPoint('LEFT',row,'LEFT',9,0)
    local itemLabel=textLine(row,'',math.max(190,itemsBook:GetWidth()-310))
    itemLabel:SetPoint('LEFT',row,'LEFT',209,0)
    if itemLabel.SetWordWrap then itemLabel:SetWordWrap(false) end
    row.zoneLabel=zoneLabel;row.itemLabel=itemLabel
    -- The Map button is separate from row selection. It uses the same native
    -- map/waypoint launcher as Active Writs, with NO reference edits or costs.
    local mapButton=createButton(row,'Map',43,22,function()
      local entry=row.bookEntry
      rows.openReferenceMap(entry)
    end)
    mapButton:SetPoint('RIGHT',row,'RIGHT',-6,0)
    if mapButton.SetFrameLevel then mapButton:SetFrameLevel(row:GetFrameLevel()+2) end
    row.mapButton=mapButton
    bookRows[#bookRows+1]=row
  end
  local divider=itemsBook:CreateTexture(nil,'ARTWORK')
  divider:SetHeight(1);divider:SetColorTexture(.42,.38,.28,.7)
  divider:SetPoint('BOTTOMLEFT',16,310);divider:SetPoint('BOTTOMRIGHT',-16,310)
  itemsBook.detailDivider=divider
  local detailTitle=textLine(itemsBook,'REFERENCE DETAILS',280,true)
  detailTitle:SetPoint('BOTTOMLEFT',18,285)
  itemsBook.detailTitle=detailTitle
  local detail1=textLine(itemsBook,'',600);detail1:SetPoint('BOTTOMLEFT',18,260)
  local detail2=textLine(itemsBook,'',600);detail2:SetPoint('BOTTOMLEFT',18,236)
  local detail3=textLine(itemsBook,'',600);detail3:SetPoint('BOTTOMLEFT',18,212)
  local detail4=textLine(itemsBook,'',600);detail4:SetPoint('BOTTOMLEFT',18,188)
  local detail5=textLine(itemsBook,'',600);detail5:SetPoint('BOTTOMLEFT',18,164)
  local detail6=textLine(itemsBook,'',600);detail6:SetPoint('BOTTOMLEFT',18,140)
  itemsBook.detail1=detail1;itemsBook.detail2=detail2;itemsBook.detail3=detail3
  itemsBook.detail4=detail4;itemsBook.detail5=detail5;itemsBook.detail6=detail6
  -- A pale rule between EVERY detail row; darker theme still remains readable.
  itemsBook.detailRules={}
  for _,bottomOffset in ipairs({254,230,206,182,158}) do
    local rule=itemsBook:CreateTexture(nil,'ARTWORK')
    rule:SetHeight(1)
    rule:SetColorTexture(.86,.84,.80,.42)
    rule:SetPoint('BOTTOMLEFT',18,bottomOffset)
    rule:SetPoint('BOTTOMRIGHT',-18,bottomOffset)
    itemsBook.detailRules[#itemsBook.detailRules+1]=rule
  end
  -- Blue = opt-in combined figures, distinct from the personal reference data.
  local sharedRule=itemsBook:CreateTexture(nil,'ARTWORK')
  sharedRule:SetHeight(1);sharedRule:SetColorTexture(.36,.62,1,.68)
  sharedRule:SetPoint('BOTTOMLEFT',18,129);sharedRule:SetPoint('BOTTOMRIGHT',-18,129)
  itemsBook.sharedRule=sharedRule
  itemsBook.sharedDetails={}
  for i,y in ipairs({105,80,55}) do
    local line=textLine(itemsBook,'',700)
    line:SetPoint('BOTTOMLEFT',18,y)
    line:SetTextColor(.38,.72,1)
    if line.SetFont then line:SetFont(STANDARD_TEXT_FONT or 'Fonts\\FRIZQT__.TTF',12,'OUTLINE') end
    itemsBook.sharedDetails[i]=line
  end
  local note=textLine(itemsBook,'Paid-price averages exclude looted units.',230)
  note:SetTextColor(.65,.62,.54);note:SetPoint('BOTTOMLEFT',18,17)
  local editBook=createButton(itemsBook,'Edit Info',94,27,openBookEditor)
  editBook:SetPoint('BOTTOMRIGHT',-20,11)
  itemsBook.editBook=editBook
  local addPouch=createButton(itemsBook,'Submit Pouch',119,27,openPouchEditor)
  addPouch:SetPoint('RIGHT',editBook,'LEFT',-9,0)
  itemsBook.addPouch=addPouch
  local showLog=createButton(itemsBook,'Log',65,27,openReferenceLog)
  showLog:SetPoint('RIGHT',addPouch,'LEFT',-9,0)
  itemsBook.showLog=showLog
  itemsBook.note=note
  -- Called after each book refresh: the detail section stays collapsed even if
  -- reference selection or shared-sync changes try to reveal child controls.
  itemsBook.applyDetailsVisibility=function(self)
    local visible=DB.bookShowDetails~=false
    if visible then
      self.detailDivider:Show();self.detailTitle:Show();self.note:Show()
      for i=1,6 do self['detail'..i]:Show() end
      for _,rule in ipairs(self.detailRules) do rule:Show() end
      -- Buttons and blue shared stats are handled by bookRefresh per selection.
    else
      self.detailDivider:Hide();self.detailTitle:Hide();self.note:Hide()
      for i=1,6 do self['detail'..i]:Hide() end
      for _,rule in ipairs(self.detailRules) do rule:Hide() end
      self.sharedRule:Hide()
      for _,line in ipairs(self.sharedDetails) do line:Hide() end
      self.editBook:Hide();self.addPouch:Hide();self.showLog:Hide()
    end
  end
  itemsBook:SetResizable(true)
  local minBookHeight=DB.bookShowDetails==false and 340 or 590
  if itemsBook.SetResizeBounds then itemsBook:SetResizeBounds(600,minBookHeight,1040,900)
  else
    if itemsBook.SetMinResize then itemsBook:SetMinResize(600,minBookHeight) end
    if itemsBook.SetMaxResize then itemsBook:SetMaxResize(1040,900) end
  end
  local grip=CreateFrame('Button',nil,itemsBook)
  grip:SetSize(20,20);grip:SetPoint('BOTTOMRIGHT',-2,2)
  grip:SetFrameLevel(itemsBook:GetFrameLevel()+6)
  grip:SetNormalTexture('Interface\\ChatFrame\\UI-ChatIM-SizeGrabber-Up')
  grip:SetHighlightTexture('Interface\\ChatFrame\\UI-ChatIM-SizeGrabber-Highlight')
  grip:SetPushedTexture('Interface\\ChatFrame\\UI-ChatIM-SizeGrabber-Down')
  grip:SetScript('OnMouseDown',function()itemsBook:StartSizing('BOTTOMRIGHT')end)
  grip:SetScript('OnMouseUp',function()
    itemsBook:StopMovingOrSizing()
    DB.bookWidth=math.floor(itemsBook:GetWidth()+.5)
    if DB.bookShowDetails==false then
      DB.bookCompactHeight=math.floor(itemsBook:GetHeight()+.5)
    else
      DB.bookHeight=math.floor(itemsBook:GetHeight()+.5)
    end
    savePosition(itemsBook,'bookPos')
  end)
  itemsBook:SetScript('OnSizeChanged',function(self,w,h)
    -- Leave room for Missing: On/Off between search and the Items/Sort tools,
    -- including at the minimum 600px book width.
    edit:SetWidth(math.max(140,math.min(265,w-460)))
    self.count:SetWidth(math.max(370,w-36))
    local reserved=DB.bookShowDetails==false and 190 or 500
    self.visibleRows=math.max(3,math.min(18,math.floor((h-reserved)/30)))
    for _,name in ipairs({'detail1','detail2','detail3','detail4','detail5','detail6'}) do self[name]:SetWidth(w-36) end
    for _,line in ipairs(self.sharedDetails or {}) do line:SetWidth(w-36) end
    self.note:SetWidth(math.max(230,w-350))
    for _,row in ipairs(bookRows) do
      row:SetWidth(w-36)
      -- Reserve a dedicated button area, including at the minimum 600px size.
      row.itemLabel:SetWidth(math.max(190,w-310))
    end
    if bookRefresh then bookRefresh() end
  end)
  edit:SetWidth(math.max(140,math.min(265,itemsBook:GetWidth()-460)))
  itemsBook.count:SetWidth(math.max(370,itemsBook:GetWidth()-36))
  itemsBook.referenceRows=bookRows
  itemsBook.visibleRows=math.max(3,math.min(18,
    math.floor((itemsBook:GetHeight()-(DB.bookShowDetails==false and 190 or 500))/30)))
  itemsBook:applyDetailsVisibility()
  itemsBook:Hide()
  rows.registerPopup(itemsBook)
end
-- Tracking can request several paints before the next game frame. Store only
-- panel callbacks here. Event evidence and saved records never enter the queue.
do
  local pending,painting={},{}
  local driver
  function rows.paint(panel,draw,defer)
    if not panel or not panel:IsShown() then return end
    if defer~=true then
      pending[panel]=nil;painting[panel]=nil
      draw()
      return
    end
    if not driver then
      driver=CreateFrame('Frame')
      driver:SetScript('OnUpdate',function(self)
        self:Hide()
        painting,pending=pending,painting
        for frame,callback in pairs(painting) do
          painting[frame]=nil
          if frame:IsShown() then callback() end
        end
      end)
    end
    pending[panel]=draw
    driver:Show()
  end
end
bookRefresh=function(defer)
  rows.paint(itemsBook,rows.drawBook,defer)
end
rows.drawBook=function()
  if not itemsBook then return end
  populateBook()
  local entries=matchingBookEntries()
  local zones={}
  for _,e in ipairs(bookEntries) do zones[e.zone]=true end
  local countZones=0;for _ in pairs(zones) do countZones=countZones+1 end
  local peerCount=0
  if DB.bookShowCommunity then
    for sender,peer in pairs(DB.sharedSources or {}) do
      if not community.isOwnSharedSource(sender,peer) then peerCount=peerCount+1 end
    end
  end
  -- On = unknown-zone writs; Off = known-zone writs, even without X/Y.
  -- Both filters respect personal overrides and work in Items/Zone views.
  local missing=0
  for _,e in ipairs(bookEntries) do
    local zone=trim(e.zone):lower()
    if zone=='' or zone=='unknown' or zone=='not revealed' then
      missing=missing+1
    end
  end
  local visibleTotal=DB.bookMissingOnly and missing or (#bookEntries-missing)
  local category=DB.bookMissingOnly and 'unknown-zone' or 'known-zone'
  itemsBook.count:SetText(#entries..' matching '..category..' '..(bookMode=='items' and 'items' or 'zones')..
    ' / '..visibleTotal..' '..category..' writs / '..#bookEntries..' total items')
  local visible=itemsBook.visibleRows or 8
  local pages=math.max(1,math.ceil(#entries/visible))
  bookPage=math.max(1,math.min(bookPage,pages))
  itemsBook.pageText:SetText('Page '..bookPage..' / '..pages)
  for i,row in ipairs(bookRows) do
    local e=(i<=visible) and entries[(bookPage-1)*visible+i] or nil
    if e then
      row.entryKey=e.key
      row.bookEntry=e
      if e.zone and e.zone~='Unknown' and e.zone~='Not revealed' then
        row.mapButton:Show()
      else
        row.mapButton:Hide()
      end
      row.zoneLabel:SetText(e.zone)
      local stats=community.statsFor(e.kind=='zone' and nil or e.key,e.kind=='zone' and e.zone or nil)
      row.itemLabel:SetText(e.item..listEfficiency(stats))
      if row.SetBackdropBorderColor then
        if e.key==bookSelected then row:SetBackdropBorderColor(1,.73,.27,1)
        else row:SetBackdropBorderColor(unpack(skin().edge)) end
      end
      row:Show()
    else row.entryKey=nil;row.bookEntry=nil;row.mapButton:Hide();row:Hide() end
  end
  local selectedEntry
  for _,e in ipairs(entries) do
    if e.key==bookSelected then selectedEntry=e;break end
  end
  if not selectedEntry then
    selectedEntry=entries[1]
    bookSelected=selectedEntry and selectedEntry.key or nil
  end
  if selectedEntry then
    if selectedEntry.kind=='zone' then
      local stats=community.personalStatsFor(nil,selectedEntry.zone)
      itemsBook.detailTitle:SetText('ZONE EFFICIENCY')
      itemsBook.detail1:SetText('Zone: '..selectedEntry.zone..'   |   Known writs: '..(selectedEntry.numberOfItems or 0))
      itemsBook.detail2:SetText('Personal runs: '..stats.runs..'   |   Pouch samples: '..stats.pouchSamples)
      itemsBook.detail3:SetText('Avg writ BUY ('..stats.writSamples..'): '..community.moneyAverage(stats.writSpent,stats.writSamples)..
        '   |   Avg item BUY ('..stats.itemSamples..'): '..community.moneyAverage(stats.itemSpent,stats.itemSamples))
      itemsBook.detail4:SetText('Avg full run ('..stats.costSamples..'): '..community.moneyAverage(stats.spent,stats.costSamples)..
        '   |   Avg pouch ('..stats.pouchSamples..'): '..community.moneyAverage(stats.pouches,stats.pouchSamples))
      itemsBook.detail5:SetText(community.trueCostDisplay(stats,false))
      itemsBook.detail6:SetText('Reputation logged: '..stats.rep..'   |   Net cost / 100 rep: '..costPer100(stats))
      itemsBook.detail5:SetTextColor(unpack(skin().text))
      itemsBook.detail5:SetTextColor((community.trueCostDisplay(stats,false):find('^PROFIT') and .54 or .94),
        (community.trueCostDisplay(stats,false):find('^PROFIT') and .88 or .90),
        (community.trueCostDisplay(stats,false):find('^PROFIT') and .58 or .80))
      itemsBook.editBook:Hide();itemsBook.addPouch:Show();itemsBook.showLog:Show()
    else
      local stats=community.personalStatsFor(selectedEntry.key,nil)
      itemsBook.detailTitle:SetText('REFERENCE DETAILS')
      local knownRep=tonumber(selectedEntry.rep)
      if not knownRep and stats.repRuns>0 and stats.rep>0 then knownRep=math.floor(stats.rep/stats.repRuns+.5) end
      itemsBook.detail1:SetText('Required item: '..selectedEntry.item..'   |   Rep: '..(knownRep and tostring(knownRep) or 'Unknown'))
      itemsBook.detail2:SetText('Turn-in zone: '..selectedEntry.zone..'   |   NPC: '..(selectedEntry.npc or 'Not documented'))
      if selectedEntry.x and selectedEntry.y then
        itemsBook.detail3:SetText(string.format('Coordinates: %.1f, %.1f',selectedEntry.x,selectedEntry.y))
      else itemsBook.detail3:SetText('Coordinates: Not verified') end
      local last=lastCompletedFor(selectedEntry.key)
      if last then
        itemsBook.detail4:SetText('Last completed: Cost '..(last.totalCost and fmtMoney(last.totalCost) or 'None')..
          '   |   Coin Pouch '..fmtMoney(last.pouchAmount or 0)..
          '   |   Rep '..tostring(last.repEarned or 'Unknown'))
      else itemsBook.detail4:SetText('Last completed: None yet') end
      itemsBook.detail5:SetText('Personal runs: '..stats.runs..'   |   Avg writ BUY ('..stats.writSamples..'): '..community.moneyAverage(stats.writSpent,stats.writSamples)..
        '   |   Avg item BUY ('..stats.itemSamples..'): '..community.moneyAverage(stats.itemSpent,stats.itemSamples))
      itemsBook.detail6:SetText('Avg pouch ('..stats.pouchSamples..'): '..community.moneyAverage(stats.pouches,stats.pouchSamples)..
        '   |   '..community.trueCostDisplay(stats,false)..'   |   /100 rep: '..community.costPer100(stats))
      itemsBook.detail6:SetTextColor((community.trueCostDisplay(stats,false):find('^PROFIT') and .54 or .94),
        (community.trueCostDisplay(stats,false):find('^PROFIT') and .88 or .90),
        (community.trueCostDisplay(stats,false):find('^PROFIT') and .58 or .80))
      itemsBook.editBook:Show();itemsBook.addPouch:Show();itemsBook.showLog:Show()
    end
    if DB.bookShowCommunity then
      local key=selectedEntry.kind=='zone' and nil or selectedEntry.key
      local zone=selectedEntry.kind=='zone' and selectedEntry.zone or nil
      local shared=community.sharedStatsFor(key,zone)
      local combined=community.statsFor(key,zone)
      local personal=community.personalStatsFor(key,zone)
      itemsBook.sharedDetails[1]:SetText('SYNCED RUNS: '..combined.runs..'  ('..personal.runs..' yours + '..shared.runs..
        ' shared)    |    Contributors: '..shared.contributors)
      itemsBook.sharedDetails[2]:SetText('SYNCED WRIT AVG ('..combined.writSamples..'): '..community.moneyAverage(combined.writSpent,combined.writSamples)..
        '    |    ITEM AVG ('..combined.itemSamples..'): '..community.moneyAverage(combined.itemSpent,combined.itemSamples))
      itemsBook.sharedDetails[3]:SetText('SYNCED POUCH AVG ('..combined.pouchSamples..'): '..community.moneyAverage(combined.pouches,combined.pouchSamples)..
        '    |    '..community.trueCostDisplay(combined,false))
      itemsBook.sharedRule:Show()
      for _,line in ipairs(itemsBook.sharedDetails) do line:Show() end
    else
      itemsBook.sharedRule:Hide()
      for _,line in ipairs(itemsBook.sharedDetails) do line:Hide() end
    end
  else
    itemsBook.sharedRule:Hide()
    for _,line in ipairs(itemsBook.sharedDetails) do line:Hide() end
    itemsBook.detailTitle:SetText('NO MATCHES')
    itemsBook.detail5:SetTextColor(unpack(skin().text))
    itemsBook.detail6:SetTextColor(unpack(skin().text))
    itemsBook.detail1:SetText('No known writ items match your search.')
    itemsBook.detail2:SetText('Try a zone, required item name, or NPC.')
    for _,key in ipairs({'detail3','detail4','detail5','detail6'}) do itemsBook[key]:SetText('') end
    itemsBook.editBook:Hide();itemsBook.addPouch:Hide();itemsBook.showLog:Hide()
  end
  itemsBook:applyDetailsVisibility()
end
local function toggleItemsBook()
  if DB and DB.experimentalTabbedUI and rows.experimentalTabs and not rows.experimentalTabs.switching then
    rows.experimentalTabs.open('History/Records');return
  end
  if not itemsBook then return end
  itemsBook:SetShown(not itemsBook:IsShown())
end
local mailAlert={}
rows.refreshMailAlert=function()
  if mailAlert.refresh then mailAlert.refresh() end
end

-- One movable, scrollable panel for the names behind the active / all-time
-- presence counters. Lazily created; no server-wide data or extra network work.
rows.toggleUserList=function()
  if not rows.userListFrame then
    local panel=CreateFrame('Frame','WritThisUsersFrame',UIParent,BackdropTemplateMixin and 'BackdropTemplate')
    panel:SetSize(415,448)
    panel:SetFrameStrata('DIALOG')
    panel:SetClampedToScreen(true);panel:SetMovable(true);panel:EnableMouse(true)
    position(panel,'userListPos',65,25)
    skinFrame(panel);makeDraggable(panel,'userListPos')
    local title=textLine(panel,'WRIT THIS USERS',340,true)
    title:SetPoint('TOPLEFT',18,-18)
    local close=createButton(panel,'X',25,24,function()rows.navigation.close(panel)end)
    close:SetPoint('TOPRIGHT',-12,-11)
    local help=textLine(panel,'Version shown for compatible clients (4.0 Beta 3+).',367)
    help:SetPoint('TOPLEFT',18,-48);help:SetTextColor(.73,.73,.67)
    local scroll=CreateFrame('ScrollFrame','WritThisUserListScroll',panel,'UIPanelScrollFrameTemplate')
    scroll:SetPoint('TOPLEFT',15,-78);scroll:SetPoint('BOTTOMRIGHT',-37,17)
    local content=CreateFrame('Frame',nil,scroll)
    content:SetWidth(344);content:SetHeight(1)
    scroll:SetScrollChild(content)
    scroll:EnableMouseWheel(true)
    scroll:SetScript('OnMouseWheel',function(self,delta)
      local maximum=math.max(0,self:GetVerticalScrollRange() or 0)
      self:SetVerticalScroll(math.max(0,math.min(maximum,(self:GetVerticalScroll() or 0)-delta*42)))
    end)
    local lines={}
    local versionLabels={}
    local function line(index,text,r,g,b,isHeader,version)
      local l=lines[index]
      if not l then
        l=textLine(content,'',170,isHeader)
        l:SetPoint('TOPLEFT',9,-(10+(index-1)*20))
        lines[index]=l
      end
      if l.SetFontObject then
        l:SetFontObject(isHeader and GameFontNormalLarge or GameFontNormalSmall)
      end
      if isHeader then l:SetWidth(334) else l:SetWidth(169) end
      l:SetText(text)
      l:SetTextColor(r,g,b)
      l:Show()
      local v=versionLabels[index]
      if version then
        if not v then
          v=textLine(content,'',164,false)
          v:SetPoint('TOPRIGHT',-6,-(10+(index-1)*20))
          v:SetJustifyH('RIGHT')
          versionLabels[index]=v
        end
        v:SetText(version)
        v:SetTextColor(.75,.77,.70)
        v:Show()
      elseif v then
        v:Hide()
      end
    end
    panel.refresh=function()
      local active=community.activeUserNames()
      local history=community.allTimeUserNames()
      local row=0
      local function put(text,r,g,b,isHeader,version)
        row=row+1
        line(row,text,r,g,b,isHeader,version)
      end
      put('ACTIVE USERS ('..tostring(#active)..')',.58,.95,.68,true)
      for _,name in ipairs(active) do
        put('  '..name,.89,.91,.85,false,community.userVersion(name,true))
      end
      put(' ',.65,.65,.65,false)
      put('ALL-TIME USERS ('..tostring(#history)..')',1,.79,.35,true)
      for _,name in ipairs(history) do
        put('  '..name,.89,.91,.85,false,community.userVersion(name,false))
      end
      for i=row+1,#lines do
        lines[i]:Hide()
        if versionLabels[i] then versionLabels[i]:Hide() end
      end
      content:SetHeight(math.max(2,10+row*20+14))
      local maximum=math.max(0,scroll:GetVerticalScrollRange() or 0)
      if (scroll:GetVerticalScroll() or 0)>maximum then scroll:SetVerticalScroll(maximum) end
    end
    panel:SetScript('OnShow',function(self) self.refresh() end)
    panel:Hide()
    rows.registerPopup(panel)
    rows.userListFrame=panel
  end
  local panel=rows.userListFrame
  panel:SetShown(not panel:IsShown())
end
rows.refreshUserList=function()
  local panel=rows.userListFrame
  if panel and panel:IsShown() and panel.refresh then panel.refresh() end
end
-- Static WoW Forever Waylaid Crate reference (not tracking). Every listed
-- material bundle is an ALTERNATIVE: completing one option fills the crate.
-- Data reconciled with Method's all-crates list and Zockify, Nov 2026.
-- Artisan reward figures are not confirmed, so we deliberately display '?'.
local WAYLAID_CRATES={
  {name='Waylaid Crate: Apprentice Ore', label='Apprentice Ore',tier='Apprentice',kind='Ore',level=10,quality='White',favor=5,options={{'Copper Ore',20},{'Tin Ore',20}}},
  {name='Waylaid Crate: Journeyman Ore', label='Journeyman Ore',tier='Journeyman',kind='Ore',level=10,quality='White',favor=10,options={{'Silver Ore',10},{'Iron Ore',20}}},
  {name='Waylaid Crate: Expert Ore', label='Expert Ore',tier='Expert',kind='Ore',level=20,quality='White',favor=15,options={{'Gold Ore',10},{'Mithril Ore',20}}},
  {name='Waylaid Crate: Artisan Ore', label='Artisan Ore',tier='Artisan',kind='Ore',level=35,quality='White',favor=nil,options={{'Truesilver Ore',10},{'Thorium Ore',20},{'Dark Iron Ore',20}}},
  {name='Waylaid Crate: Apprentice Ingots', label='Apprentice Ingots',tier='Apprentice',kind='Ingots',level=10,quality='Green',favor=10,options={{'Copper Bar',20},{'Tin Bar',20},{'Bronze Bar',10}}},
  {name='Waylaid Crate: Journeyman Ingots', label='Journeyman Ingots',tier='Journeyman',kind='Ingots',level=10,quality='Green',favor=20,options={{'Silver Bar',10},{'Iron Bar',20}}},
  {name='Waylaid Crate: Expert Ingots', label='Expert Ingots',tier='Expert',kind='Ingots',level=20,quality='Green',favor=30,options={{'Mithril Bar',20},{'Steel Bar',15},{'Gold Bar',10}}},
  {name='Waylaid Crate: Artisan Ingots', label='Artisan Ingots',tier='Artisan',kind='Ingots',level=35,quality='Green',favor=nil,options={{'Dark Iron Bar',2},{'Truesilver Bar',10},{'Thorium Bar',20}}},
  {name='Waylaid Crate: Apprentice Herbs', label='Apprentice Herbs',tier='Apprentice',kind='Herbs',level=10,quality='White',favor=5,options={{'Peacebloom',20},{'Silverleaf',20},{'Earthroot',10},{'Mageroyal',10},{'Briarthorn',10}}},
  {name='Waylaid Crate: Journeyman Herbs', label='Journeyman Herbs',tier='Journeyman',kind='Herbs',level=10,quality='White',favor=10,options={{'Stranglekelp',10},{'Bruiseweed',10},{'Wild Steelbloom',10},{'Grave Moss',10},{'Kingsblood',10}}},
  {name='Waylaid Crate: Earthly Expert Herbs', label='Earthly Expert Herbs',tier='Expert',kind='Herbs',level=20,quality='White',favor=15,options={{'Liferoot',20},{'Fadeleaf',10},{'Goldthorn',10},{'Khadgar\'s Whisker',10}}},
  {name='Waylaid Crate: Flowering Expert Herbs', label='Flowering Expert Herbs',tier='Expert',kind='Herbs',level=20,quality='White',favor=15,options={{'Wintersbite',10},{'Firebloom',10},{'Purple Lotus',20},{'Arthas\' Tears',10}}},
  {name='Waylaid Crate: Earthly Artisan Herbs', label='Earthly Artisan Herbs',tier='Artisan',kind='Herbs',level=35,quality='White',favor=nil,options={{'Golden Sansam',10},{'Sungrass',20},{'Blindweed',10},{'Ghost Mushroom',10},{'Gromsblood',10}}},
  {name='Waylaid Crate: Flowering Artisan Herbs', label='Flowering Artisan Herbs',tier='Artisan',kind='Herbs',level=35,quality='White',favor=nil,options={{'Dreamfoil',20},{'Mountain Silversage',20},{'Plaguebloom',20},{'Icecap',20}}},
  {name='Waylaid Crate: Apprentice Parts', label='Apprentice Parts',tier='Apprentice',kind='Parts',level=10,quality='Green',favor=10,options={{'Handful of Copper Bolts',16},{'Copper Tube',16},{'Copper Modulator',4}}},
  {name='Waylaid Crate: Journeyman Parts', label='Journeyman Parts',tier='Journeyman',kind='Parts',level=10,quality='Green',favor=20,options={{'Bronze Tube',8},{'Whirring Bronze Gizmo',7},{'Bronze Framework',4},{'Gold Power Core',45}}},
  {name='Waylaid Crate: Expert Parts', label='Expert Parts',tier='Expert',kind='Parts',level=20,quality='Green',favor=30,options={{'Iron Strut',8},{'Mithril Tube',5},{'Unstable Trigger',12},{'Mithril Casing',5}}},
  {name='Waylaid Crate: Artisan Parts', label='Artisan Parts',tier='Artisan',kind='Parts',level=35,quality='Green',favor=nil,options={{'Thorium Widget',5},{'Truesilver Transformer',5},{'Thorium Tube',2}}},
  {name='Waylaid Crate: Apprentice Textiles', label='Apprentice Textiles',tier='Apprentice',kind='Textiles',level=10,quality='White',favor=5,options={{'Linen Cloth',40},{'Light Leather',20}}},
  {name='Waylaid Crate: Journeyman Textiles', label='Journeyman Textiles',tier='Journeyman',kind='Textiles',level=10,quality='White',favor=10,options={{'Wool Cloth',20},{'Silk Cloth',40},{'Medium Leather',20}}},
  {name='Waylaid Crate: Expert Textiles', label='Expert Textiles',tier='Expert',kind='Textiles',level=20,quality='White',favor=15,options={{'Mageweave Cloth',40},{'Heavy Leather',20}}},
  {name='Waylaid Crate: Artisan Textiles', label='Artisan Textiles',tier='Artisan',kind='Textiles',level=35,quality='White',favor=nil,options={{'Runecloth',40},{'Thick Leather',20},{'Rugged Leather',20}}},
  {name='Waylaid Crate: Apprentice Fabrics', label='Apprentice Fabrics',tier='Apprentice',kind='Fabrics',level=10,quality='Green',favor=10,options={{'Cured Light Hide',2},{'Bolt of Linen Cloth',20}}},
  {name='Waylaid Crate: Journeyman Fabrics', label='Journeyman Fabrics',tier='Journeyman',kind='Fabrics',level=10,quality='Green',favor=20,options={{'Bolt of Woolen Cloth',6},{'Bolt of Silk Cloth',10},{'Cured Medium Hide',2}}},
  {name='Waylaid Crate: Expert Fabrics', label='Expert Fabrics',tier='Expert',kind='Fabrics',level=20,quality='Green',favor=30,options={{'Bolt of Mageweave',8},{'Cured Heavy Hide',2}}},
  {name='Waylaid Crate: Artisan Fabrics', label='Artisan Fabrics',tier='Artisan',kind='Fabrics',level=35,quality='Green',favor=nil,options={{'Bolt of Runecloth',8},{'Cured Thick Hide',2}}},
  {name='Waylaid Crate: Apprentice Curiosities', label='Apprentice Curiosities',tier='Apprentice',kind='Curiosities',level=10,quality='White',favor=5,options={{'Strange Dust',20},{'Greater Magic Essence',4},{'Small Glimmering Shard',6},{'Large Glimmering Shard',2}}},
  {name='Waylaid Crate: Journeyman Curiosities', label='Journeyman Curiosities',tier='Journeyman',kind='Curiosities',level=10,quality='White',favor=10,options={{'Soul Dust',20},{'Greater Astral Essence',4},{'Small Glowing Shard',6},{'Large Glowing Shard',2}}},
  {name='Waylaid Crate: Expert Curiosities', label='Expert Curiosities',tier='Expert',kind='Curiosities',level=20,quality='White',favor=15,options={{'Vision Dust',20},{'Greater Mystic Essence',4},{'Small Radiant Shard',6},{'Large Radiant Shard',2}}},
  {name='Waylaid Crate: Artisan Curiosities', label='Artisan Curiosities',tier='Artisan',kind='Curiosities',level=35,quality='White',favor=nil,options={{'Dream Dust',20},{'Greater Nether Essence',4},{'Small Brilliant Shard',6},{'Large Brilliant Shard',2}}},
}
do  -- Scope Auctionator read-only helpers away from WoW 200-local chunk limit
local CRATE_STANDARD_ITEM_IDS={
  ['Copper Ore']=2770,
  ['Tin Ore']=2771,
  ['Silver Ore']=2775,
  ['Iron Ore']=2772,
  ['Gold Ore']=2776,
  ['Mithril Ore']=3858,
  ['Truesilver Ore']=7911,
  ['Thorium Ore']=10620,
  ['Dark Iron Ore']=11370,
  ['Copper Bar']=2840,
  ['Tin Bar']=3576,
  ['Bronze Bar']=2841,
  ['Silver Bar']=2842,
  ['Iron Bar']=3575,
  ['Mithril Bar']=3860,
  ['Steel Bar']=3859,
  ['Gold Bar']=3577,
  ['Dark Iron Bar']=11371,
  ['Truesilver Bar']=6037,
  ['Thorium Bar']=12359,
  ['Peacebloom']=2447,
  ['Silverleaf']=765,
  ['Earthroot']=2449,
  ['Mageroyal']=785,
  ['Briarthorn']=2450,
  ['Stranglekelp']=3820,
  ['Bruiseweed']=2453,
  ['Wild Steelbloom']=3355,
  ['Grave Moss']=3369,
  ['Kingsblood']=3356,
  ['Liferoot']=3357,
  ['Fadeleaf']=3818,
  ['Goldthorn']=3821,
  ['Khadgar\'s Whisker']=3358,
  ['Wintersbite']=3819,
  ['Firebloom']=4625,
  ['Purple Lotus']=8831,
  ['Arthas\' Tears']=8836,
  ['Golden Sansam']=13464,
  ['Sungrass']=8838,
  ['Blindweed']=8839,
  ['Ghost Mushroom']=8845,
  ['Gromsblood']=8846,
  ['Dreamfoil']=13463,
  ['Mountain Silversage']=13465,
  ['Plaguebloom']=13466,
  ['Icecap']=13467,
  ['Handful of Copper Bolts']=4359,
  ['Copper Modulator']=4363,
  ['Bronze Framework']=4382,
  ['Gold Power Core']=10558,
  ['Copper Tube']=4361,
  ['Bronze Tube']=4371,
  ['Whirring Bronze Gizmo']=4375,
  ['Iron Strut']=4387,
  ['Mithril Tube']=10559,
  ['Unstable Trigger']=10560,
  ['Mithril Casing']=10561,
  ['Thorium Widget']=15994,
  ['Truesilver Transformer']=18631,
  ['Thorium Tube']=16000,
  ['Linen Cloth']=2589,
  ['Light Leather']=2318,
  ['Wool Cloth']=2592,
  ['Silk Cloth']=4306,
  ['Medium Leather']=2319,
  ['Mageweave Cloth']=4338,
  ['Heavy Leather']=4234,
  ['Runecloth']=14047,
  ['Thick Leather']=4304,
  ['Rugged Leather']=8170,
  ['Cured Light Hide']=4231,
  ['Bolt of Linen Cloth']=2996,
  ['Bolt of Woolen Cloth']=2997,
  ['Bolt of Silk Cloth']=4305,
  ['Cured Medium Hide']=4233,
  ['Bolt of Mageweave']=4339,
  ['Cured Heavy Hide']=4236,
  ['Bolt of Runecloth']=14048,
  ['Cured Thick Hide']=8172,
  ['Strange Dust']=10940,
  ['Greater Magic Essence']=10939,
  ['Small Glimmering Shard']=10978,
  ['Large Glimmering Shard']=11084,
  ['Soul Dust']=11083,
  ['Greater Astral Essence']=11082,
  ['Small Glowing Shard']=11138,
  ['Large Glowing Shard']=11139,
  ['Vision Dust']=11137,
  ['Greater Mystic Essence']=11135,
  ['Small Radiant Shard']=11177,
  ['Large Radiant Shard']=11178,
  ['Dream Dust']=11176,
  ['Greater Nether Essence']=11175,
  ['Small Brilliant Shard']=14343,
  ['Large Brilliant Shard']=14344,
}

local CRATE_FOREVER_ITEM_IDS={
  ['Waylaid Crate: Apprentice Herbs']=248682,
  ['Waylaid Crate: Apprentice Ore']=248683,
  ['Waylaid Crate: Apprentice Textiles']=248684,
  ['Waylaid Crate: Apprentice Curiosities']=248685,
  ['Waylaid Crate: Journeyman Herbs']=248686,
  ['Waylaid Crate: Journeyman Ore']=248687,
  ['Waylaid Crate: Journeyman Textiles']=248688,
  ['Waylaid Crate: Journeyman Curiosities']=248689,
  ['Waylaid Crate: Earthly Expert Herbs']=248690,
  ['Waylaid Crate: Flowering Expert Herbs']=248691,
  ['Waylaid Crate: Expert Ore']=248692,
  ['Waylaid Crate: Expert Textiles']=248693,
  ['Waylaid Crate: Expert Curiosities']=248694,
  ['Waylaid Crate: Earthly Artisan Herbs']=248695,
  ['Waylaid Crate: Flowering Artisan Herbs']=248696,
  ['Waylaid Crate: Artisan Ore']=248697,
  ['Waylaid Crate: Artisan Textiles']=248698,
  ['Waylaid Crate: Artisan Curiosities']=248699,
  ['Waylaid Crate: Apprentice Fabrics']=248702,
  ['Waylaid Crate: Apprentice Ingots']=248703,
  ['Waylaid Crate: Apprentice Parts']=248704,
  ['Waylaid Crate: Journeyman Fabrics']=248705,
  ['Waylaid Crate: Journeyman Ingots']=248706,
  ['Waylaid Crate: Journeyman Parts']=248707,
  ['Waylaid Crate: Expert Fabrics']=248708,
  ['Waylaid Crate: Expert Ingots']=248709,
  ['Waylaid Crate: Expert Parts']=248710,
  ['Waylaid Crate: Artisan Fabrics']=248711,
  ['Waylaid Crate: Artisan Ingots']=248712,
  ['Waylaid Crate: Artisan Parts']=248713,
}

local crateResolvedItemIDs={}
local function crateItemID(name)
  local cached=CRATE_FOREVER_ITEM_IDS[name] or crateResolvedItemIDs[name]
  if cached then return cached end
  local id
  -- Some Forever versions resolve an item by name even when its hyperlink
  -- has not yet entered the cache; others only support GetItemInfo(name).
  if C_Item and type(C_Item.GetItemInfoInstant)=='function' then
    local ok,result=pcall(C_Item.GetItemInfoInstant,name)
    if ok and tonumber(result) and tonumber(result)>0 then id=tonumber(result) end
  end
  if not id and type(GetItemInfoInstant)=='function' then
    local ok,result=pcall(GetItemInfoInstant,name)
    if ok and tonumber(result) and tonumber(result)>0 then id=tonumber(result) end
  end
  if not id then
    local link
    if C_Item and type(C_Item.GetItemInfo)=='function' then
      local ok,_,result=pcall(C_Item.GetItemInfo,name)
      if ok then link=result end
    end
    if not link and type(GetItemInfo)=='function' then
      local ok,_,result=pcall(GetItemInfo,name)
      if ok then link=result end
    end
    if link then id=idFromLink(link) end
  end
  id=id or CRATE_FOREVER_ITEM_IDS[name] or CRATE_STANDARD_ITEM_IDS[name]
  if id and id>0 then crateResolvedItemIDs[name]=id end
  return id
end
local function crateAuctionatorAPI()
  local api=Auctionator and Auctionator.API and Auctionator.API.v1
  if api and type(api.GetAuctionPriceByItemID)=='function' then return api end
  return nil
end
local function crateReadAuctionatorQuote(name,knownID)
  local api=crateAuctionatorAPI()
  if not api then return nil,nil,nil,'Auctionator API unavailable' end
  local id=tonumber(knownID) or crateItemID(name)
  if not id then return nil,nil,nil,'Item ID not resolved' end
  local ok,result=pcall(api.GetAuctionPriceByItemID,'WritTracker',id)
  local unit=ok and tonumber(result) or nil
  if not unit or unit<=0 or unit~=unit or unit>100000000000 then
    return nil,id,nil,'No cached Auctionator price'
  end
  unit=math.floor(unit+.5)
  local age
  if type(api.GetAuctionAgeByItemID)=='function' then
    local good,days=pcall(api.GetAuctionAgeByItemID,'WritTracker',id)
    if good and type(days)=='number' and days>=0 then age=math.floor(days) end
  end
  return unit,id,age,nil
end
-- Optional AH price providers: Writ This itself requires neither addon.
-- With one provider installed, use it automatically. If both exist, retain the
-- character's manual preference (Auctionator by default for public installs).
-- A temporary absence never overwrites the saved preference.
function rows.ACPriceAPI()
  local api=rawget(_G,'AuctionCompanionAPI')
  return type(api)=='table' and type(api.GetPriceByItemID)=='function' and api or nil
end
function rows.providerAvailability()
  return rows.ACPriceAPI()~=nil,crateAuctionatorAPI()~=nil
end
function rows.activeProvider()
  local hasAC,hasAuctionator=rows.providerAvailability()
  if hasAC and hasAuctionator then
    return DB and DB.writACPricing==true and 'AC' or 'Auctionator'
  end
  if hasAC then return 'AC' end
  if hasAuctionator then return 'Auctionator' end
  return nil
end
function rows.usingACPrices()
  return rows.activeProvider()=='AC'
end
rows.writProviderChecks=rows.writProviderChecks or setmetatable({},{__mode='k'})
function rows.updateProviderChecks()
  local hasAC,hasAuctionator=rows.providerAvailability()
  local both=hasAC and hasAuctionator
  local label=both and 'Use AC prices (experimental)' or
    hasAC and 'Auction Companion (only provider)' or
    hasAuctionator and 'Auctionator (only provider)' or
    'No AH price addon detected'
  for control,labelText in pairs(rows.writProviderChecks) do
    if control and control.SetChecked then
      control:SetChecked(rows.usingACPrices())
      -- One-provider setups are read-only: there's nothing to switch to.
      if control.SetEnabled then control:SetEnabled(both) end
    end
    if labelText and labelText.SetText then labelText:SetText(label) end
  end
end
rows.setWritPriceProvider=function(enabled)
  if not DB then return end
  local hasAC,hasAuctionator=rows.providerAvailability()
  if not (hasAC and hasAuctionator) then
    rows.updateProviderChecks()
    say('Price source is selected automatically. Install both Auction Companion and Auctionator to enable switching.')
    return
  end
  DB.writACPricing=enabled==true
  rows.updateProviderChecks()
  local crates=rows.waylaidCratesFrame
  if crates and crates.refreshProvider then crates.refreshProvider() end
  local writs=rows.writPrices
  if writs and writs.refreshProvider then writs.refreshProvider() end
end
function rows.readMarketQuote(name,knownID)
  local provider=rows.activeProvider()
  if not provider then
    return nil,tonumber(knownID) or crateItemID(name),nil,
      'Install Auctionator or Auction Companion for AH prices',nil,nil
  end
  if provider=='Auctionator' then
    local unit,id,age,err=crateReadAuctionatorQuote(name,knownID)
    return unit,id,age,err,unit and 'Auctionator' or nil,nil
  end
  local api=rows.ACPriceAPI()
  local id=tonumber(knownID) or crateItemID(name)
  if not api then return nil,id,nil,'Auction Companion API unavailable',nil,nil end
  -- An ongoing/finished AC Live Scan explicitly owns its target names. Never
  -- fill an unchecked or missing name with old Full Scan/cached data: that would
  -- make a partially checked catalogue appear freshly verified.
  if type(api.GetNameScanQuote)=='function' then
    local ok,livePrice,liveID,liveStamp,liveState=pcall(api.GetNameScanQuote,name)
    if ok and liveState and liveState~='not-in-scan' then
      livePrice=tonumber(livePrice);liveID=tonumber(liveID)
      if liveState=='verified' and livePrice and livePrice>0 and livePrice<100000000000 then
        -- Do not silently associate a live name match with a conflicting known ID.
        if id and liveID and id~=liveID then
          return nil,id,nil,'AC Live: name/ID mismatch ('..tostring(liveID)..')',nil,nil
        end
        local observed=tonumber(liveStamp)
        local now=type(time)=='function' and time() or 0
        local age=observed and observed>0 and now>=observed and math.floor((now-observed)/86400) or nil
        return math.floor(livePrice+.5),liveID or id,age,nil,'AC live name',observed
      end
      return nil,id,nil,'AC Live: '..tostring(liveState),nil,nil
    end
  end
  if not id then return nil,nil,nil,'AC item ID unknown (run AC Live Scan by name)',nil,nil end
  local ok,price,origin,stamp=pcall(api.GetPriceByItemID,id)
  price=ok and tonumber(price) or nil
  if not price or price<=0 or price~=price or price>100000000000 then
    return nil,id,nil,'No AC scan/search price',nil,nil
  end
  local age
  local now=type(time)=='function' and tonumber(time()) or nil
  stamp=tonumber(stamp)
  if now and stamp and stamp<=now and stamp>1000000000 then
    age=math.floor((now-stamp)/86400)
  end
  return math.floor(price+.5),id,age,nil,
    origin=='search' and 'AC cached search' or origin=='scan' and 'AC cached snapshot' or 'AC cached quote',stamp
end
function rows.providerName()
  local provider=rows.activeProvider()
  return provider=='AC' and 'Auction Companion' or provider or 'No AH price provider'
end
function rows.providerScanAge()
  if not rows.activeProvider() then return 'Install AC or Auctionator for AH prices' end
  if not rows.usingACPrices() then return rows.crateFullScanClock() end
  local api=rows.ACPriceAPI()
  if api and type(api.GetNameScanStatus)=='function' then
    local ok,job=pcall(api.GetNameScanStatus)
    if ok and type(job)=='table' then
      local label=job.label or 'items'
      if job.phase=='running' then
        return ('AC Live %s: %d/%d checked'):format(
          label,job.done or 0,job.total or 0)
      end
      -- Do not present a Full Scan timestamp as evidence of a live name scan.
      local elapsed=job.completedAt and rows.crateElapsedShort(job.completedAt)
      if elapsed and job.phase=='complete' then
        return ('AC Live %s %s ago'):format(label,elapsed)
      elseif elapsed and job.phase then
        return ('AC Live %s: %s %s ago'):format(label,job.phase,elapsed)
      end
    end
  end
  return 'AC live scan not run yet'
end

-- A complete per-window snapshot: Refresh Prices reads every unique material
-- and all 30 empty crate quotes, independent of search/tier/current page.
-- Nothing is added to SavedVariables, Auctionator or the Auction House.
local cratePriceSnapshot={}
local crateQuoteCount=0
local crateQuotePriced=0
local crateQuoteStale=0
local crateQuoteAgeUnknown=0
-- Exact timestamps here describe OUR cache lookups, not when the AH quote
-- was recorded. Do not confuse a new Writ This lookup with a fresh AH scan.
rows.crateElapsedShort=function(epoch)
  local now=type(time)=='function' and tonumber(time()) or nil
  local stamp=tonumber(epoch)
  if not now or not stamp or stamp<1000000000 or stamp>now+30 then return nil end
  local minutes=math.floor(math.max(0,now-stamp)/60)
  if minutes<1 then return '<1m' end
  if minutes<60 then return minutes..'m' end
  local hours=math.floor(minutes/60)
  if hours<24 then return hours..'h '..(minutes%60)..'m' end
  return math.floor(hours/24)..'d '..(hours%24)..'h'
end
-- Auctionator Forever (modern AH) saves its completed browse-scan time as
-- TimeOfLastBrowseScan, rather than the legacy AUCTIONATOR_LAST_SCAN_TIME.
-- Probe read-only saved state / settings, since exact exposure varies by build.
-- Only a real, past Unix timestamp counts: a cache lookup, DB update callback,
-- or opening the AH must NEVER be presented as a completed scan.
rows.crateFullScanClock=function()
  local function scanAge(value)
    local elapsed=rows.crateElapsedShort(value)
    return elapsed
  end
  local modern=Auctionator
  -- Test each table independently; ipairs would skip later sources if an
  -- earlier optional SavedVariables global is absent.
  local saved=rawget(_G,'AUCTIONATOR_SAVEDVARS')
  if type(saved)=='table' then
    local elapsed=scanAge(rawget(saved,'TimeOfLastBrowseScan'))
    if elapsed then return 'Last AH browse scan '..elapsed..' ago' end
  end
  saved=modern and modern.SavedState
  if type(saved)=='table' then
    local elapsed=scanAge(rawget(saved,'TimeOfLastBrowseScan'))
    if elapsed then return 'Last AH browse scan '..elapsed..' ago' end
  end
  -- Some current builds surface the same setting through Config.Get.
  local cfg=modern and modern.Config
  if cfg and type(cfg.Get)=='function' then
    local key=(type(cfg.Options)=='table' and cfg.Options.TIME_OF_LAST_BROWSE_SCAN)
      or 'TimeOfLastBrowseScan'
    local ok,stamp=pcall(cfg.Get,key)
    local elapsed=ok and scanAge(stamp)
    if elapsed then return 'Last AH browse scan '..elapsed..' ago' end
    -- The string key is an optional fallback for older Config layouts.
    if key~='TimeOfLastBrowseScan' then
      ok,stamp=pcall(cfg.Get,'TimeOfLastBrowseScan')
      elapsed=ok and scanAge(stamp)
      if elapsed then return 'Last AH browse scan '..elapsed..' ago' end
    end
  end
  -- Older/Classic Auctionator releases expose a distinct full-scan global.
  local elapsed=scanAge(rawget(_G,'AUCTIONATOR_LAST_SCAN_TIME'))
  if elapsed then return 'Last AH full scan '..elapsed..' ago' end
  return nil
end
rows.crateCacheClock=function()
  local age=rows.crateElapsedShort(cratePriceSnapshot._checkedAt)
  if age then return 'Cache last read '..age..' ago' end
  return 'Cache not read yet'
end
local function crateCachedQuote(name)
  local entry=cratePriceSnapshot[name]
  if not entry then return nil,nil,nil,'Refresh Prices to load AH quotes' end
  return entry.unit,entry.id,entry.age,entry.error,entry.source,entry.stamp
end
local function crateRefreshAllQuotes()
  local fresh={}
  local total,known,stale,unknownAge=0,0,0,0
  local function query(name)
    if fresh[name] then return end
    local unit,id,age,err,source,stamp=rows.readMarketQuote(name)
    fresh[name]={unit=unit,id=id,age=age,error=err,source=source,stamp=stamp}
    total=total+1
    if unit then
      known=known+1
      if age==nil then unknownAge=unknownAge+1
      elseif age>=2 then stale=stale+1 end
    end
  end
  for _,crate in ipairs(WAYLAID_CRATES) do
    query(crate.name)
    for _,bundle in ipairs(crate.options) do query(bundle[1]) end
  end
  cratePriceSnapshot=fresh
  crateQuoteCount=total
  crateQuotePriced=known
  crateQuoteStale=stale
  crateQuoteAgeUnknown=unknownAge
  cratePriceSnapshot._checkedAt=type(time)=='function' and time() or nil
  return known,total
end

-- Auctionator reports quote age in *whole days*. We cannot infer an exact
-- last-scan timestamp or tell whether a day-0 quote is only minutes old.
-- A completed bundle depends on TWO quotes (empty crate and fill material),
-- so mark its age unknown if either API age is unavailable.
local function crateBundleFreshness(crateName,materialName)
  local _,_,crateAge=crateCachedQuote(crateName)
  local _,_,materialAge=crateCachedQuote(materialName)
  if crateAge==nil or materialAge==nil then return 'AGE UNKNOWN',nil,true end
  local oldest=math.max(crateAge,materialAge)
  if oldest>=2 then return 'STALE '..oldest..'d',oldest,false end
  if oldest==0 then return '0d OLD',oldest,false end
  return '1d OLD',oldest,false
end

local function crateCopperText(value)
  value=math.max(0,math.floor((tonumber(value) or 0)+.5))
  local gold=math.floor(value/10000)
  local silver=math.floor(value%10000/100)
  local copper=value%100
  if gold>0 then return string.format('%dg %02ds %02dc',gold,silver,copper) end
  if silver>0 then return string.format('%ds %02dc',silver,copper) end
  return string.format('%dc',copper)
end

-- Rank only fully priced crate + material combinations. Unknown Artisan Favor
-- must never be assigned an invented cost/Favor; rank that tier by raw cost.
local function crateWinnerSummary()
  local outcome={overall=nil,byTier={},priced=0,scored=0,skipped=0}
  for _,crate in ipairs(WAYLAID_CRATES) do
    local cratePrice=crateCachedQuote(crate.name)
    local fill
    for _,option in ipairs(crate.options) do
      local unit=crateCachedQuote(option[1])
      if unit and unit>0 then
        local cost=unit*option[2]
        if not fill or cost<fill.cost then
          fill={material=option[1],quantity=option[2],cost=cost}
        end
      end
    end
    if cratePrice and fill then
      local allIn=cratePrice+fill.cost
      local favor=tonumber(crate.favor)
      local ratio=favor and favor>0 and allIn/favor or nil
      local freshness,ageDays,ageUnknown=crateBundleFreshness(crate.name,fill.material)
      local entry={crate=crate,crateCost=cratePrice,fill=fill,
        total=allIn,ratio=ratio,favor=favor,
        freshness=freshness,ageDays=ageDays,ageUnknown=ageUnknown}
      outcome.priced=outcome.priced+1
      if ratio then
        outcome.scored=outcome.scored+1
        if not outcome.overall or ratio<outcome.overall.ratio or
          (ratio==outcome.overall.ratio and allIn<outcome.overall.total) then
          outcome.overall=entry
        end
      end
      local old=outcome.byTier[crate.tier]
      if not old or (ratio and old.ratio and
          (ratio<old.ratio or (ratio==old.ratio and allIn<old.total))) or
        (not ratio and not old.ratio and allIn<old.total) then
        outcome.byTier[crate.tier]=entry
      end
    else
      outcome.skipped=outcome.skipped+1
    end
  end
  return outcome
end
local function crateWinnerDiscordText(entry)
  if not entry then return 'Writ This: No completely priced Waylaid Crate winner yet.' end
  local ratio=entry.ratio and (' | '..crateCopperText(entry.ratio)..'/Favor') or ' | Favor unconfirmed'
  return '**Writ This v'..VERSION..' — Waylaid Winner**\n'..
    '**'..entry.crate.name..'** ('..entry.crate.tier..')\n'..
    'Crate: '..crateCopperText(entry.crateCost)..' | Fill: '..entry.fill.quantity..'x '..
    entry.fill.material..' ('..crateCopperText(entry.fill.cost)..')\n'..
    'Total: **'..crateCopperText(entry.total)..'**'..ratio..
    (entry.favor and (' | Favor: '..entry.favor) or '')..
    '\nPrice freshness: '..(entry.freshness or 'AGE UNKNOWN')..' (oldest of crate and fill)'..
    '\n'..rows.providerName()..' cached price estimate; listings may change.'
end

rows.waylaidCrateCatalog=WAYLAID_CRATES
-- Clicking a Waylaid material bundle opens that material plus ONE empty crate
-- using whichever optional AH provider is selected. No automatic purchases,
-- price-provider switching, price-cache rewrites, or background scans.
rows.searchCrateBundleAtAH=function(crate,bundle)
  if type(crate)~='table' or type(bundle)~='table' then return false end
  local material,amount=bundle[1],tonumber(bundle[2])
  if type(crate.name)~='string' or type(material)~='string' or
    not amount or amount<1 then return false end
  amount=math.floor(amount)
  local atAH=ahOpen or
    (AuctionHouseFrame and AuctionHouseFrame.IsShown and AuctionHouseFrame:IsShown()) or
    (AuctionFrame and AuctionFrame.IsShown and AuctionFrame:IsShown())
  if not atAH then
    say('Open the Auction House to search '..material..' and the empty crate.')
    return false
  end
  local provider=rows.activeProvider()
  if provider=='AC' then
    local ac=rows.ACPriceAPI()
    if not ac or type(ac.SearchShoppingItems)~='function' then
      say('Auction Companion v0.1.19+ is required for Crates shopping.')
      return false
    end
    -- The interactive AC shopping queue subtracts owned counts and verifies
    -- live listings before enabling buys. Item IDs are hints, not substitutes
    -- for exact-name matching; unknown IDs are resolved in AC's browse search.
    local items={
      {name=crate.name,itemID=crateItemID(crate.name),required=1,role='Empty crate'},
      {name=material,itemID=crateItemID(material),required=amount,role='Fill material'},
    }
    local ok,started,reason=pcall(ac.SearchShoppingItems,items,'Crates: '..crate.label)
    if not ok or not started then
      say('AC Crates shopping: '..tostring(ok and (reason or 'Search unavailable') or started))
      return false
    end
    return true
  elseif provider=='Auctionator' then
    local api=crateAuctionatorAPI()
    if not api or type(api.MultiSearchExact)~='function' then
      say('Auctionator Shopping is unavailable; check that Auctionator is enabled.')
      return false
    end
    local ok,reason=pcall(api.MultiSearchExact,'WritTracker',{crate.name,material})
    if not ok then
      say('Auctionator could not search the crate and material: '..tostring(reason))
      return false
    end
    return true
  end
  say('Install Auction Companion or Auctionator to search Waylaid Crates at the AH.')
  return false
end
do
  local copyDialog
  function rows.copyWinner(message)
    if not copyDialog then
      local d=CreateFrame('Frame','WritThisWinnerCopyFrame',UIParent,
        BackdropTemplateMixin and 'BackdropTemplate')
      d:SetSize(590,214);d:SetPoint('CENTER',UIParent,'CENTER',0,0)
      d:SetFrameStrata('FULLSCREEN_DIALOG');d:EnableMouse(true);skinFrame(d)
      local heading=textLine(d,'DISCORD ANNOUNCEMENT — Ctrl+C to copy',535,true)
      heading:SetPoint('TOPLEFT',17,-17);heading:SetTextColor(1,.83,.45)
      local edit=CreateFrame('EditBox',nil,d,BackdropTemplateMixin and 'BackdropTemplate')
      edit:SetSize(546,113);edit:SetPoint('TOPLEFT',21,-56)
      edit:SetMultiLine(true);edit:SetAutoFocus(false)
      edit:SetFontObject(GameFontHighlightSmall);skinFrame(edit)
      edit:SetTextColor(.93,.89,.80)
      if edit.SetTextInsets then edit:SetTextInsets(8,8,7,7) end
      edit:SetScript('OnEscapePressed',function(self) self:ClearFocus();d:Hide() end)
      createButton(d,'Select All',113,25,function()
        edit:SetFocus();edit:HighlightText()
      end):SetPoint('BOTTOMLEFT',20,15)
      createButton(d,'Close',84,25,function()d:Hide()end):SetPoint('BOTTOMRIGHT',-20,15)
      createButton(d,'X',25,24,function()rows.navigation.close(d)end):SetPoint('TOPRIGHT',-12,-11)
      if rows.registerEscapeWindow then rows.registerEscapeWindow(d) end
      d.edit=edit;copyDialog=d
    end
    copyDialog.edit:SetText(message)
    copyDialog:Show();copyDialog:Raise()
    copyDialog.edit:SetFocus();copyDialog.edit:HighlightText()
  end
end

rows.toggleWaylaidCrates=function()
    if DB and DB.experimentalTabbedUI and rows.experimentalTabs and not rows.experimentalTabs.switching then
      rows.experimentalTabs.open('Crates');return
    end
  if not rows.waylaidCratesFrame then
    local f=CreateFrame('Frame','WritThisWaylaidCratesFrame',UIParent,
      BackdropTemplateMixin and 'BackdropTemplate')
    f:SetSize(math.min(1320,math.max(900,tonumber(DB.waylaidCratesWidth) or 940)),
      math.min(900,math.max(500,tonumber(DB.waylaidCratesHeight) or 575)))
    f:SetMovable(true);f:SetClampedToScreen(true);f:SetResizable(true)
    if f.SetResizeBounds then f:SetResizeBounds(900,500,1320,900)
    else
      if f.SetMinResize then f:SetMinResize(900,500) end
      if f.SetMaxResize then f:SetMaxResize(1320,900) end
    end
    f:SetFrameStrata('DIALOG');f:EnableMouse(true)
    position(f,'waylaidCratesPos',25,0);skinFrame(f)
    local title=textLine(f,'WAYLAID CRATES',450,true)
    title:SetPoint('TOPLEFT',18,-17);title:SetTextColor(1,.83,.45)
    makeDraggable(f,'waylaidCratesPos')
    createButton(f,'X',25,24,function()rows.navigation.close(f)end):SetPoint('TOPRIGHT',-13,-12)
    createButton(f,'Traders',86,26,function()
      if rows.toggleMerchantShop then rows.toggleMerchantShop() end
    end):SetPoint('TOPLEFT',222,-12)
    local acCheck=CreateFrame('CheckButton',nil,f,'UICheckButtonTemplate')
    acCheck:SetSize(23,23);acCheck:SetPoint('TOPLEFT',317,-13)
    acCheck:SetChecked(rows.usingACPrices())
    local acCheckText=textLine(acCheck,'Use AC prices (experimental)',220)
    acCheckText:SetPoint('LEFT',acCheck,'RIGHT',2,0)
    acCheck:SetHitRectInsets(0,-220,0,0)
    acCheck:SetScript('OnClick',function(self)rows.setWritPriceProvider(self:GetChecked())end)
    acCheck:SetScript('OnEnter',function(self)
      if not GameTooltip then return end
      GameTooltip:SetOwner(self,'ANCHOR_BOTTOM')
      GameTooltip:AddLine('Experimental AH price provider',1,.83,.44)
      GameTooltip:AddLine('AC only: uses AC automatically. Auctionator only: uses Auctionator automatically. Install both to switch here.',1,1,1,true)
      GameTooltip:AddLine('Missing AC item IDs or quotes stay missing; no silent Auctionator fallback.',.95,.79,.5,true)
      GameTooltip:Show()
    end)
    acCheck:SetScript('OnLeave',function()if GameTooltip then GameTooltip:Hide()end end)
    rows.writProviderChecks[acCheck]=acCheckText
    rows.updateProviderChecks()
    local help=textLine(f,'30 crate types  |  One bundle fills each crate  |  Merchant\'s Favor',445)
    help:SetPoint('TOPLEFT',19,-48);help:SetTextColor(.80,.77,.69)

    local tierNames={'All tiers','Apprentice','Journeyman','Expert','Artisan'}
    local kinds={'All types','Herbs','Ore','Ingots','Textiles','Fabrics','Parts','Curiosities'}
    local tierIndex,kindIndex,first,selected=1,1,1,nil
    local pageSize=10
    local query=''
    local search
    local updateList
    -- Winner always compares ALL crates, independent of the current filters.
    -- Normal click selects the best favor efficiency. Shift-click offers
    -- selectable Discord text; no addon-side HTTP/webhook credentials.
    local winners
    local function showWinnerCopy()
      if not winners or not winners.overall then
        say('No fully priced winner yet. Refresh '..rows.providerName()..' prices.')
        return
      end
      rows.copyWinner(crateWinnerDiscordText(winners.overall))
    end
    local winnerButton=createButton(f,'WINNER | Waiting for AH quotes',335,48,function()
      if IsShiftKeyDown and IsShiftKeyDown() then showWinnerCopy();return end
      if not winners or not winners.overall then
        say('No completely priced Favor winner. Refresh '..rows.providerName()..' prices first.')
        return
      end
      tierIndex=1;kindIndex=1;query='';first=1
      -- Select after text-change callbacks have cleared any previous selection.
      if search and search.SetText then search:SetText('') end
      selected=winners.overall.crate
      local index=1
      for i,crate in ipairs(WAYLAID_CRATES) do
        if crate==selected then index=i;break end
      end
      first=math.floor((index-1)/pageSize)*pageSize+1
      if updateList then updateList() end
    end)
    winnerButton:SetPoint('TOPRIGHT',f,'TOPRIGHT',-52,-31)
    winnerButton.text:SetWidth(320);winnerButton.text:SetJustifyH('CENTER')
    winnerButton.text:SetTextColor(.92,.84,.54)
    winnerButton:SetScript('OnEnter',function(self)
      if self.SetBackdropColor then self:SetBackdropColor(.20,.17,.12,.98) end
      if not GameTooltip then return end
      GameTooltip:SetOwner(self,'ANCHOR_BOTTOM')
      GameTooltip:AddLine('Waylaid Crate winners - '..rows.providerName(),1,.83,.44)
      local function addWinner(label,entry)
        if not entry then
          GameTooltip:AddLine(label..': price data incomplete',.8,.65,.55)
        else
          GameTooltip:AddLine(label..': '..entry.crate.label,1,1,1)
          GameTooltip:AddLine('   '..crateCopperText(entry.total)..' all-in  |  '..
            (entry.ratio and (crateCopperText(entry.ratio)..'/Favor') or
              'Favor unconfirmed (cheapest total)'),.65,.9,.67)
          -- Only the overall winner needs the detailed per-item ages here;
          -- tier winners retain the compact combined freshness line below.
          if label=='Overall' then
            local _,_,crateAge=crateCachedQuote(entry.crate.name)
            local _,_,materialAge=crateCachedQuote(entry.fill.material)
            local function ageLabel(days)
              return days==nil and 'Unknown' or (tostring(days)..'d')
            end
            GameTooltip:AddLine('   Empty crate: '..ageLabel(crateAge)..
              '  |  Fill material: '..ageLabel(materialAge),.69,.87,1)
          end
          GameTooltip:AddLine('   Price age: '..entry.freshness..' (oldest of crate + chosen fill)',
            entry.ageUnknown and 1 or .72,
            (entry.ageUnknown or (entry.ageDays and entry.ageDays>=2)) and .72 or .94,
            .52)
        end
      end
      if winners then
        addWinner('Overall',winners.overall)
        for _,tier in ipairs({'Apprentice','Journeyman','Expert','Artisan'}) do
          addWinner(tier,winners.byTier[tier])
        end
        GameTooltip:AddLine(winners.priced..'/30 fully priced; '..
          winners.skipped..' missing crate or fill prices.',.82,.76,.65)
      end
      GameTooltip:AddLine('Click: select overall winner | Shift-click: copy Discord text',.70,.82,1,true)
      GameTooltip:AddLine(rows.crateCacheClock()..' (not a new AH scan)',.68,.87,1,true)
      local scanClock=rows.providerScanAge()
      if scanClock then GameTooltip:AddLine(scanClock,.68,.87,1,true) end
      GameTooltip:AddLine(rows.usingACPrices() and 'AC: age from last saved search/scan timestamp.' or 'Auctionator item ages are whole days; exact item scan minutes unavailable.',.72,.72,.72,true)
      GameTooltip:AddLine('0d = quote less than one day old; not necessarily live.',.72,.72,.72,true)
      GameTooltip:AddLine("Age unknown = an item scan age is unavailable; refresh after scanning.",.72,.72,.72,true)
      GameTooltip:AddLine('Prices are cached estimates; current AH stock not verified.',.69,.69,.69,true)
      GameTooltip:Show()
    end)
    winnerButton:SetScript('OnLeave',function(self)
      if self.SetBackdropColor then self:SetBackdropColor(unpack(skin().button)) end
      if GameTooltip then GameTooltip:Hide() end
    end)
    local function updateWinnerBanner()
      winners=crateWinnerSummary()
      local entry=winners.overall
      local provisional=false
      if rows.usingACPrices() then
        local api=rows.ACPriceAPI()
        if api and type(api.GetNameScanStatus)=='function' then
          local ok,job=pcall(api.GetNameScanStatus)
          if ok and type(job)=='table' and job.label=='Crates' then
            provisional=job.phase=='running' or job.phase=='partial' or job.phase=='cancelled'
          end
        end
      end
      if entry then
        winnerButton.text:SetText((provisional and 'PROVISIONAL: ' or 'WINNER: ')..entry.crate.label..'\n'..
          crateCopperText(entry.total)..' | '..crateCopperText(entry.ratio)..'/F | '..entry.freshness)
        if entry.ageUnknown or (entry.ageDays and entry.ageDays>=2) then
          winnerButton.text:SetTextColor(1,.79,.43)
        else
          winnerButton.text:SetTextColor(.59,1,.58)
        end
      else
        winnerButton.text:SetText('WINNER: No complete Favor quotes\nScan AH, then Refresh Prices')
        winnerButton.text:SetTextColor(.96,.73,.46)
      end
    end
    local tierButton=createButton(f,'All tiers',122,27,function()
      tierIndex=tierIndex%#tierNames+1;first=1;selected=nil;updateList()
    end)
    tierButton:SetPoint('TOPLEFT',20,-82)
    local kindButton=createButton(f,'All types',142,27,function()
      kindIndex=kindIndex%#kinds+1;first=1;selected=nil;updateList()
    end)
    kindButton:SetPoint('LEFT',tierButton,'RIGHT',10,0)
    local searchLabel=textLine(f,'Search:',56)
    searchLabel:SetPoint('LEFT',kindButton,'RIGHT',18,0)
    search=CreateFrame('EditBox',nil,f,'InputBoxTemplate')
    search:SetSize(220,24);search:SetPoint('LEFT',searchLabel,'RIGHT',1,0)
    search:SetAutoFocus(false);search:SetMaxLetters(65)
    search:SetScript('OnEscapePressed',function(self)self:ClearFocus()end)
    search:SetScript('OnEnterPressed',function(self)self:ClearFocus()end)
    search:SetScript('OnTextChanged',function(self)
      query=(self:GetText() or ''):lower();first=1;selected=nil
      if updateList then updateList() end
    end)
    -- Refresh snapshots ALL 30 crates and their materials, not just selection.
    -- In-session timing only. Never persist lookup timestamps or turn a cache
    -- check into a claim that Auctionator actually scanned the Auction House.
    local refreshQuotes
    local lastPriceRefresh=-1000000
    local CACHE_AUTO_SECONDS=300
    local REFRESH_COOLDOWN_SECONDS=30
    local DISPLAY_CLOCK_SECONDS=120
    local refreshButton=createButton(f,'Refresh Prices',130,27,function()
      if refreshQuotes then refreshQuotes() end
    end)
    local scanButton=createButton(f,'Scan AH',112,27,function()
      local ah=(AuctionFrame and AuctionFrame.IsShown and AuctionFrame:IsShown())
        or (AuctionHouseFrame and AuctionHouseFrame.IsShown and AuctionHouseFrame:IsShown())
      if not ah then
        say('Open the Auction House before using Scan AH.')
        return
      end
      if not Auctionator then
        say('Auctionator is not loaded. AH scanning is unavailable.')
        return
      end
      -- Version-dependent scan UI is not part of Auctionator's public API.
      -- Open its own window only if its native helper is exposed; the user
      -- starts the scan there. Never issue raw AH queries from Writ This.
      if type(Atr_ShowFullScanFrame)=='function' then
        local ok,err=pcall(Atr_ShowFullScanFrame)
        if ok then
          f:Hide()  -- native scanner stays accessible instead of behind our dialog
          say('Auctionator Full Scan opened. Start its scan, then reopen Crates to refresh quotes.')
        else
          say('Auctionator scanner could not open: '..tostring(err))
        end
      else
        say('Use Auctionator > Full Scan at the AH, then press Refresh Prices here.')
      end
    end)
    scanButton:SetPoint('TOPRIGHT',f,'TOPRIGHT',-20,-82)
    -- Keep the Crates page for price comparisons only. The read-only AC live
    -- scanning workflow lives in Writs; AC Full Scan stays in AC's own AH UI.
    local function layoutCrateScanControls()
      local provider=rows.activeProvider()
      scanButton:SetShown(provider=='Auctionator')
      refreshButton:ClearAllPoints()
      if provider~='Auctionator' then
        refreshButton:SetPoint('TOPRIGHT',f,'TOPRIGHT',-20,-82)
      else
        refreshButton:SetPoint('RIGHT',scanButton,'LEFT',-8,0)
      end
    end
    layoutCrateScanControls()
    -- Keep price COVERAGE prominent; a recent cache read is not a fresh AH
    -- scan. The second row uses the existing space alongside the crate count.
    local priceHeading=textLine(f,'AUCTIONATOR PRICES',196,true)
    priceHeading:SetPoint('TOPLEFT',22,-111)
    priceHeading:SetTextColor(1,.82,.46)
    local availableStatus=textLine(f,'Checking...',205,true)
    availableStatus:SetPoint('TOPLEFT',220,-111)
    local staleStatus=textLine(f,'',124)
    staleStatus:SetPoint('TOPLEFT',432,-115)
    local unknownStatus=textLine(f,'',128)
    unknownStatus:SetPoint('TOPLEFT',554,-115)
    -- Stack the two timestamps at the far right of the PRICE header.
    -- The crate title starts at y=-141; neither timestamp should share
    -- that baseline or reach into the details panel.
    local cacheStatus=textLine(f,'',230)
    cacheStatus:SetPoint('TOPRIGHT',f,'TOPRIGHT',-20,-126)
    cacheStatus:SetJustifyH('RIGHT')
    cacheStatus:SetTextColor(.69,.76,.85)
    -- Optional Auctionator browse/full scan timestamp is independent of
    -- Writ This cache reads and never claims an item-specific scan time.
    local scanStatus=textLine(f,'',230)
    scanStatus:SetPoint('TOPRIGHT',f,'TOPRIGHT',-20,-111)
    scanStatus:SetJustifyH('RIGHT')
    scanStatus:SetTextColor(.69,.76,.85)
    local function updateCacheClockText()
      local api=rows.usingACPrices() and rows.ACPriceAPI() or crateAuctionatorAPI()
      priceHeading:SetText(rows.usingACPrices() and 'AUCTION COMPANION' or
        rows.activeProvider()=='Auctionator' and 'AUCTIONATOR PRICES' or 'NO AH PRICE PROVIDER')
      if api then
        availableStatus:SetText(crateQuotePriced..' / '..crateQuoteCount..' available')
        availableStatus:SetTextColor(crateQuotePriced==crateQuoteCount and .57 or 1,
          crateQuotePriced==crateQuoteCount and .99 or .79,
          crateQuotePriced==crateQuoteCount and .59 or .44)
        staleStatus:SetText(crateQuoteStale..' stale')
        staleStatus:SetTextColor(crateQuoteStale>0 and 1 or .70,
          crateQuoteStale>0 and .72 or .87,
          crateQuoteStale>0 and .43 or .73)
        unknownStatus:SetText(crateQuoteAgeUnknown..' unknown')
        unknownStatus:SetTextColor(crateQuoteAgeUnknown>0 and 1 or .70,
          crateQuoteAgeUnknown>0 and .72 or .87,
          crateQuoteAgeUnknown>0 and .43 or .73)
      else
        availableStatus:SetText('Pricing unavailable')
        availableStatus:SetTextColor(1,.72,.44)
        staleStatus:SetText('');unknownStatus:SetText('')
      end
      cacheStatus:SetText(rows.crateCacheClock())
      scanStatus:SetText(rows.providerScanAge() or '')
    end
    local function showPriceInfo(self,kind)
      if not GameTooltip then return end
      GameTooltip:SetOwner(self,'ANCHOR_BOTTOM')
      if kind=='cache' then
        GameTooltip:AddLine('Cache last read',1,.83,.44)
        GameTooltip:AddLine('When Writ This last reread '..rows.providerName()..' saved prices.',.88,.88,.88,true)
        GameTooltip:AddLine('This does not scan the AH or make prices newer.',.72,.81,.95,true)
      elseif kind=='scan' then
        GameTooltip:AddLine(rows.providerName()..' last completed AH scan',1,.83,.44)
        GameTooltip:AddLine(rows.providerScanAge() or 'Timestamp unavailable',.84,.9,.99,true)
        GameTooltip:AddLine('Completed AH scan timestamp; not a per-item live price.',.72,.81,.95,true)
      else
        GameTooltip:AddLine(rows.providerName()..' cached prices',1,.83,.44)
        GameTooltip:AddLine(crateQuotePriced..' of '..crateQuoteCount..' tracked item quotes available.',.82,.98,.82)
        GameTooltip:AddLine('Stale: '..crateQuoteStale..' cached prices aged 2+ whole days.',.96,.78,.49)
        GameTooltip:AddLine('Unknown: '..crateQuoteAgeUnknown..' prices have no reported age.',.88,.83,.72)
        GameTooltip:AddLine('0d means less than one day old; it is not a guaranteed live listing.',.72,.81,.95,true)
        GameTooltip:AddLine('Read-only estimates. Current AH prices and stock may differ.',.75,.75,.75,true)
        if not rows.providerScanAge() then
          GameTooltip:AddLine('Last AH scan time unavailable for this provider.',.72,.81,.95,true)
        end
      end
      GameTooltip:Show()
    end
    -- Hover hitboxes follow the actual text rows. Even at the minimum
    -- window width (900), they do not cover one another or the crate title.
    local priceInfoHit=CreateFrame('Frame',nil,f)
    priceInfoHit:SetPoint('TOPLEFT',19,-107)
    priceInfoHit:SetSize(610,26)
    priceInfoHit:EnableMouse(true)
    priceInfoHit:SetScript('OnEnter',function(self)showPriceInfo(self,'prices')end)
    priceInfoHit:SetScript('OnLeave',function()if GameTooltip then GameTooltip:Hide()end end)
    local cacheInfoHit=CreateFrame('Frame',nil,f)
    cacheInfoHit:SetPoint('TOPRIGHT',f,'TOPRIGHT',-18,-125)
    cacheInfoHit:SetSize(232,13)
    cacheInfoHit:EnableMouse(true)
    cacheInfoHit:SetScript('OnEnter',function(self)showPriceInfo(self,'cache')end)
    cacheInfoHit:SetScript('OnLeave',function()if GameTooltip then GameTooltip:Hide()end end)
    local scanInfoHit=CreateFrame('Frame',nil,f)
    scanInfoHit:SetPoint('TOPRIGHT',f,'TOPRIGHT',-18,-110)
    scanInfoHit:SetSize(232,13)
    scanInfoHit:EnableMouse(true)
    scanInfoHit:SetScript('OnEnter',function(self)
      if rows.crateFullScanClock() then showPriceInfo(self,'scan') end
    end)
    scanInfoHit:SetScript('OnLeave',function()if GameTooltip then GameTooltip:Hide()end end)
    local function updateRefreshButton()
      local ready=(clock()-lastPriceRefresh)>=REFRESH_COOLDOWN_SECONDS
      if refreshButton.SetEnabled then refreshButton:SetEnabled(ready) end
      refreshButton.text:SetTextColor(ready and .91 or .56,
        ready and .88 or .56,ready and .79 or .56)
    end
    local countLabel=textLine(f,'30 crates',245)
    countLabel:SetPoint('TOPLEFT',22,-139);countLabel:SetTextColor(.63,.84,1)
    local leftTitle=textLine(f,'CRATES',355,true)
    leftTitle:SetPoint('TOPLEFT',23,-164)
    local favorTitle=textLine(f,'FAVOR',80,true)
    favorTitle:SetPoint('TOPLEFT',355,-164)

    local selectedTitle=textLine(f,'Select a crate',460,true)
    selectedTitle:SetPoint('TOPLEFT',457,-141);selectedTitle:SetTextColor(1,.82,.43)
    local selectedMeta=textLine(f,'',452)
    selectedMeta:SetPoint('TOPLEFT',457,-172)
    local selectedReward=textLine(f,'',455,true)
    selectedReward:SetPoint('TOPLEFT',457,-197);selectedReward:SetTextColor(.62,.94,.61)
    local chooseOne=textLine(f,'Click a material to shop crate + bundle:',242)
    chooseOne:SetPoint('TOPLEFT',457,-239);chooseOne:SetTextColor(.88,.86,.78)
    local pricingHeader=textLine(f,'MATERIALS / ALL-IN FAVOR COST',218)
    pricingHeader:SetPoint('TOPLEFT',702,-239)
    pricingHeader:SetTextColor(.69,.85,.99)
    local optionLines,optionPrices,optionHovers={},{},{}
    for i=1,7 do
      local y=-(260+(i-1)*27)
      local line=textLine(f,'',231)
      line:SetPoint('TOPLEFT',468,y)
      local cost=textLine(f,'',215)
      cost:SetPoint('TOPLEFT',702,y)
      cost:SetJustifyH('RIGHT')
      -- This is an actual button, not a generic mouse-up hitbox: native
      -- AH panels can consume mouse release events in some Forever clients.
      local hit=CreateFrame('Button',nil,f)
      hit:SetSize(445,24);hit:SetPoint('TOPLEFT',465,y+3)
      hit:SetFrameLevel(f:GetFrameLevel()+3)
      hit:EnableMouse(true)
      hit:RegisterForClicks('LeftButtonUp')
      hit:SetScript('OnEnter',function(self)
        local info=self.quote
        if not info or not GameTooltip then return end
        GameTooltip:SetOwner(self,'ANCHOR_RIGHT')
        GameTooltip:AddLine(info.name,1,.83,.48)
        GameTooltip:AddLine('Required: '..info.quantity,1,1,1)
        if info.unit then
          GameTooltip:AddLine((info.source or rows.providerName())..' material/unit: '..crateCopperText(info.unit),.75,1,.75)
          GameTooltip:AddLine('Materials total: '..crateCopperText(info.total),.75,1,.75)
          GameTooltip:AddLine('Material quote age: '..
              (info.age==nil and 'Unknown' or (info.age..' whole day(s)')),.80,.81,.94)
          if info.allIn then
            GameTooltip:AddLine('Plus empty crate: '..crateCopperText(info.crateUnit),.70,1,.70)
            GameTooltip:AddLine('All-in estimate: '..crateCopperText(info.allIn),.55,1,.55)
          else
            GameTooltip:AddLine('Empty crate AH price unknown; all-in cost unavailable',1,.74,.50)
          end
          GameTooltip:AddLine('Empty crate quote age: '..
            (info.crateAge==nil and 'Unknown' or (info.crateAge..' whole day(s)')),.80,.81,.94)
          local status=crateBundleFreshness(info.crateName,info.name)
          GameTooltip:AddLine('Combined price freshness: '..status,.98,.77,.45)
          GameTooltip:AddLine(rows.crateCacheClock()..' (not an AH scan)',.68,.87,1)
        else
          GameTooltip:AddLine(info.error or 'No cached quote',1,.62,.55)
        end
        GameTooltip:AddLine('Cached '..rows.providerName()..' quote; price/stock may have changed.',.7,.7,.7,true)
        GameTooltip:AddLine('Left-click: Search '..info.quantity..' x '..info.name..' and 1 empty crate in '..rows.providerName(),.51,.88,1,true)
        GameTooltip:AddLine('Shopping only; purchases require your confirmation.',.66,.84,.97,true)
        GameTooltip:Show()
      end)
      hit:SetScript('OnLeave',function() if GameTooltip then GameTooltip:Hide() end end)
      -- Reuse the existing hitbox so the material and price can both be
      -- clicked. The current crate + bundle are stored per redraw (never a
      -- captured stale row/selection), including when filters or tabs change.
      hit:SetScript('OnClick',function(self,button)
        if button~='LeftButton' or not self.quote or not self.bundleCrate then return end
        local itemName=self.quote.name
        local ok=rows.searchCrateBundleAtAH(self.bundleCrate,
          {self.quote.name,self.quote.quantity})
        if ok then
          chooseOne:SetText('Opened shopping: '..itemName)
        else
          chooseOne:SetText('Shopping unavailable (see chat).')
        end
      end)
      optionLines[i],optionPrices[i],optionHovers[i]=line,cost,hit
    end
    local bestLabel=textLine(f,'',453)
    bestLabel:SetPoint('TOPLEFT',457,-445)
    bestLabel:SetTextColor(.55,.97,.57)
    local note=textLine(f,'',454)
    note:SetPoint('TOPLEFT',456,-473)
    note:SetTextColor(.91,.75,.48)
    local turnIn=textLine(f,'Horde: Dokimi, The Barrens (50.0, 29.2)\nAlliance: Marcy Baker, Redridge Mountains (9.6, 71.0)',463)
    turnIn:SetPoint('TOPLEFT',456,-500);turnIn:SetTextColor(.73,.82,.94)
    local info=textLine(f,'First Shipping Label quest: +50 Favor and +2,000 rep once per character.',892)
    info:SetPoint('BOTTOMLEFT',20,11);info:SetTextColor(.74,.73,.67)

    local rowButtons={}
    local function showDetail(crate)
      selected=crate
      local api=rows.usingACPrices() and rows.ACPriceAPI() or crateAuctionatorAPI()
      updateCacheClockText()
      if not crate then
        selectedTitle:SetText('Select a crate')
        selectedMeta:SetText('');selectedReward:SetText('');chooseOne:Hide()
        bestLabel:SetText('')
        for i,line in ipairs(optionLines) do
          line:SetText('');optionPrices[i]:SetText('');optionHovers[i].quote=nil
          optionHovers[i].bundleCrate=nil
        end
        note:SetText('')
        return
      end
      chooseOne:Show()
      selectedTitle:SetText(crate.name)
      local crateUnit,crateID,crateAge=crateCachedQuote(crate.name)
      selectedMeta:SetText(crate.tier..'  |  '..crate.quality..'  |  Min lvl '..crate.level..
        '  |  Crate AH: '..(crateUnit and crateCopperText(crateUnit) or 'No cached price'))
      if crate.favor then
        selectedReward:SetText('Reward: '..crate.favor.." Merchant's Favor")
        note:SetText(crate.tier=='Expert' and 'Expert Favor values are reported; verify in-game.' or
          'All-in = one empty crate + required materials; last cached AH quotes.')
      else
        selectedReward:SetText('Reward: Unconfirmed Merchant\'s Favor')
        note:SetText('Artisan payout unverified; cost per Favor is not estimated.')
      end
      local cheapest,found= nil,0
      for i,line in ipairs(optionLines) do
        local opt=crate.options[i]
        local priceLabel=optionPrices[i]
        local hit=optionHovers[i]
        if opt then
          local name,quantity=opt[1],opt[2]
          line:SetText(quantity..' x '..name)
          line:SetTextColor(unpack(skin().text))
          local unit,id,age,err=crateCachedQuote(name)
          local total=unit and unit*quantity or nil
          local allIn=total and crateUnit and total+crateUnit or nil
          local stored=cratePriceSnapshot[name]
          hit.quote={name=name,quantity=quantity,unit=unit,total=total,allIn=allIn,
            crateUnit=crateUnit,crateAge=crateAge,crateName=crate.name,
            id=id,age=age,error=err,source=stored and stored.source}
          hit.bundleCrate=crate
          if total then
            found=found+1
            if not cheapest or total<cheapest.total then
              cheapest={index=i,name=name,total=total,quantity=quantity}
            end
            local quote=crateCopperText(total)
            if crate.favor and crate.favor>0 then
              if allIn then
                quote=quote..'  /  '..crateCopperText(allIn/crate.favor)..'/F'
              else
                quote=quote..'  /  ?/F'
              end
            end
            priceLabel:SetText(quote)
            priceLabel:SetTextColor(.77,.85,.95)
          else
            priceLabel:SetText('No cached price')
            priceLabel:SetTextColor(.68,.65,.59)
          end
        else
          line:SetText('');priceLabel:SetText('');hit.quote=nil;hit.bundleCrate=nil
        end
      end
      if cheapest then
        optionLines[cheapest.index]:SetTextColor(.54,1,.58)
        optionPrices[cheapest.index]:SetTextColor(.54,1,.58)
        local coverage=(found<#crate.options) and ('  ('..found..'/'..#crate.options..' priced)') or ''
        local fullCost=crateUnit and (crateUnit+cheapest.total) or nil
        bestLabel:SetText('Cheapest mats: '..cheapest.quantity..' x '..cheapest.name..
          ' - '..crateCopperText(cheapest.total)..
          (fullCost and ('  |  All-in '..crateCopperText(fullCost)) or '  |  Crate price missing')..coverage)
      elseif not api then
        bestLabel:SetText('Enable '..rows.providerName()..' to see cached AH material estimates.')
      else
        bestLabel:SetText('No cached quotes for these bundles; scan in '..rows.providerName()..' first.')
      end
    end
    refreshQuotes=function()
      -- Guard both button spam and bursts of optional Auctionator callbacks.
      -- OnShow/auto/callback/manual all share this single recheck path.
      if clock()-lastPriceRefresh<REFRESH_COOLDOWN_SECONDS then
        updateRefreshButton()
        return false
      end
      crateRefreshAllQuotes()
      lastPriceRefresh=clock()
      f.cratePendingAuctionator=false
      updateWinnerBanner()
      showDetail(selected or WAYLAID_CRATES[1])
      updateRefreshButton()
      return true
    end
    f:SetScript('OnShow',function(self)
      self.crateClockAccumulator=0
      self.cratePollAccumulator=0
      -- If the window was reopened during cooldown, schedule the deferred
      -- check instead of showing a possibly outdated snapshot for five minutes.
      if refreshQuotes and not refreshQuotes() then
        self.cratePendingAuctionator=true
      end
      updateCacheClockText()
      updateRefreshButton()
    end)
    f:SetScript('OnUpdate',function(self,elapsed)
      -- The UI clock only redraws every two minutes (plus actual checks).
      -- The lightweight 5-second poll is for cooldown/scan notifications,
      -- never for item price lookups by itself.
      self.crateClockAccumulator=(self.crateClockAccumulator or 0)+(elapsed or 0)
      if self.crateClockAccumulator>=DISPLAY_CLOCK_SECONDS then
        self.crateClockAccumulator=self.crateClockAccumulator%DISPLAY_CLOCK_SECONDS
        updateCacheClockText()
      end
      self.cratePollAccumulator=(self.cratePollAccumulator or 0)+(elapsed or 0)
      if self.cratePollAccumulator>=5 then
        self.cratePollAccumulator=self.cratePollAccumulator%5
        if rows.usingACPrices() then
          local api=rows.ACPriceAPI()
          if api and type(api.GetPriceRevision)=='function' then
            local ok,revision=pcall(api.GetPriceRevision)
            if ok and revision~=self.lastACPriceRevision then
              self.lastACPriceRevision=revision
              lastPriceRefresh=-1000000
              self.cratePendingAuctionator=true
            end
          end
        end
        local since=clock()-lastPriceRefresh
        if since>=CACHE_AUTO_SECONDS or
            (self.cratePendingAuctionator and since>=REFRESH_COOLDOWN_SECONDS) then
          refreshQuotes()
        else
          updateRefreshButton()
        end
      end
    end)
    f.refreshProvider=function()
      acCheck:SetChecked(rows.usingACPrices())
      layoutCrateScanControls()
      lastPriceRefresh=-1000000
      f.cratePendingAuctionator=true
      f.lastACPriceRevision=nil
      if f:IsShown() then refreshQuotes() end
      updateCacheClockText()
    end
    -- Versions exposing the v1 callback notify us after Auctionator processes
    -- prices/full scans. Legacy Auctionator may expose its older callback.
    -- A closed window only remembers an update notification; callback
    -- registration never makes an AH query or writes Auctionator data.
    local function onAuctionatorPricesUpdated()
      -- Preserve the notification across a hidden window; no price lookup
      -- runs until it is actually visible again.
      f.cratePendingAuctionator=true
    end
    local api=crateAuctionatorAPI()
    local subscribed=false
    if api and type(api.RegisterForDBUpdate)=='function' then
      subscribed=pcall(api.RegisterForDBUpdate,'WritTracker',onAuctionatorPricesUpdated)
    end
    if not subscribed and type(Atr_RegisterFor_DBupdated)=='function' then
      pcall(Atr_RegisterFor_DBupdated,onAuctionatorPricesUpdated)
    end
    local function matches(crate)
      if tierIndex>1 and crate.tier~=tierNames[tierIndex] then return false end
      if kindIndex>1 and crate.kind~=kinds[kindIndex] then return false end
      if query=='' then return true end
      if crate.name:lower():find(query,1,true) then return true end
      for _,option in ipairs(crate.options) do
        if option[1]:lower():find(query,1,true) then return true end
      end
      return false
    end
    local previous=createButton(f,'< Previous',110,25,function()
      first=math.max(1,first-pageSize);updateList()
    end)
    previous:SetPoint('BOTTOMLEFT',24,43)
    local nextPage=createButton(f,'Next >',100,25,function()
      first=first+pageSize;updateList()
    end)
    nextPage:SetPoint('LEFT',previous,'RIGHT',184,0)
    local pageLabel=textLine(f,'',112)
    pageLabel:SetPoint('LEFT',previous,'RIGHT',13,0)
    for i=1,18 do
      local b=createButton(f,'',401,28,function(self)
        local data=self.crate
        if data then showDetail(data);updateList() end
      end)
      b:SetPoint('TOPLEFT',21,-(189+(i-1)*31))
      b.text:ClearAllPoints();b.text:SetPoint('LEFT',b,'LEFT',9,0)
      b.text:SetWidth(306);b.text:SetJustifyH('LEFT')
      b.reward=textLine(b,'',77)
      b.reward:SetPoint('RIGHT',b,'RIGHT',-9,0)
      b.reward:SetJustifyH('RIGHT')
      rowButtons[i]=b
    end
    updateList=function()
      tierButton.text:SetText(tierNames[tierIndex])
      kindButton.text:SetText(kinds[kindIndex])
      local filtered={}
      for _,crate in ipairs(WAYLAID_CRATES) do
        if matches(crate) then filtered[#filtered+1]=crate end
      end
      if first>math.max(1,#filtered) then
        first=math.max(1,(math.ceil(#filtered/pageSize)-1)*pageSize+1)
      end
      countLabel:SetText(#filtered..' of '..#WAYLAID_CRATES..' crate types')
      local pages=math.max(1,math.ceil(#filtered/pageSize))
      pageLabel:SetText('Page '..math.ceil(first/pageSize)..'/'..pages)
      if previous.SetEnabled then previous:SetEnabled(first>1) end
      if nextPage.SetEnabled then nextPage:SetEnabled(first+pageSize<=#filtered) end
      -- Keep the detail panel synchronized with the visible page/filter.
      local onPage=false
      for i=first,math.min(first+pageSize-1,#filtered) do
        if filtered[i]==selected then onPage=true;break end
      end
      if not onPage then showDetail(filtered[first]) end
      for i,b in ipairs(rowButtons) do
        local entry=filtered[first+i-1]
        b.crate=entry
        b:SetShown(entry~=nil and i<=pageSize)
        if entry then
          b.text:SetText(entry.label)
          b.reward:SetText(entry.favor and tostring(entry.favor) or '?')
          b.reward:SetTextColor(entry.favor and .73 or 1,entry.favor and .90 or .73,.55)
          if b.SetBackdropBorderColor then
            if selected==entry then b:SetBackdropBorderColor(1,.78,.25,1)
            elseif entry.quality=='Green' then b:SetBackdropBorderColor(.28,.54,.35,.8)
            else b:SetBackdropBorderColor(unpack(skin().edge)) end
          end
        end
      end
      if selected and not matches(selected) then showDetail(nil) end
    end
    -- Responsive list and detail columns: both dimensions persist per character.
    -- Resize increases the number of rows per page, not an empty bottom area.
    local function layoutCrates(width,height)
      width=math.max(900,tonumber(width) or f:GetWidth())
      height=math.max(500,tonumber(height) or f:GetHeight())
      local listRight=math.min(540,math.max(390,math.floor(width*.43)))
      local detailsX=listRight+48
      local detailsWidth=math.max(410,width-detailsX-20)
      local midX=detailsX+math.floor(detailsWidth*.54)
      local leftSub=math.max(175,midX-detailsX-15)
      local rightSub=math.max(150,width-midX-29)
      local oldPageSize=pageSize
      pageSize=math.max(5,math.min(#rowButtons,math.floor((height-189-73)/31)))
      -- Preserve the selected crate when a resize changes the page size.
      -- Otherwise an old page start (e.g. 21) may be mislabelled page 1.
      if pageSize~=oldPageSize then
        local visibleIndex,selectedIndex=0,nil
        for _,crate in ipairs(WAYLAID_CRATES) do
          if matches(crate) then
            visibleIndex=visibleIndex+1
            if crate==selected then selectedIndex=visibleIndex;break end
          end
        end
        local keepIndex=selectedIndex or first
        first=math.floor((keepIndex-1)/pageSize)*pageSize+1
      end
      help:SetWidth(math.max(350,width-440))
      countLabel:SetWidth(listRight-42)
      leftTitle:SetWidth(listRight-70)
      favorTitle:ClearAllPoints();favorTitle:SetPoint('TOPLEFT',listRight-72,-164)
      selectedTitle:ClearAllPoints();selectedTitle:SetPoint('TOPLEFT',detailsX,-141)
      selectedTitle:SetWidth(detailsWidth)
      selectedMeta:ClearAllPoints();selectedMeta:SetPoint('TOPLEFT',detailsX,-172)
      selectedMeta:SetWidth(detailsWidth)
      selectedReward:ClearAllPoints();selectedReward:SetPoint('TOPLEFT',detailsX,-197)
      selectedReward:SetWidth(detailsWidth)
      chooseOne:ClearAllPoints();chooseOne:SetPoint('TOPLEFT',detailsX,-239)
      chooseOne:SetWidth(detailsWidth)
      pricingHeader:ClearAllPoints();pricingHeader:SetPoint('TOPLEFT',midX,-239)
      pricingHeader:SetWidth(rightSub)
      local gap=height<545 and 22 or 27
      for i,line in ipairs(optionLines) do
        local y=260+(i-1)*gap
        line:ClearAllPoints();line:SetPoint('TOPLEFT',detailsX+11,-y)
        line:SetWidth(leftSub)
        optionPrices[i]:ClearAllPoints()
        optionPrices[i]:SetPoint('TOPLEFT',midX,-y)
        optionPrices[i]:SetWidth(rightSub)
        optionHovers[i]:ClearAllPoints()
        optionHovers[i]:SetPoint('TOPLEFT',detailsX+8,-y+3)
        optionHovers[i]:SetSize(detailsWidth-10,24)
      end
      local bestY=math.max(370,height-130)
      bestLabel:ClearAllPoints();bestLabel:SetPoint('TOPLEFT',detailsX,-bestY)
      bestLabel:SetWidth(detailsWidth)
      note:ClearAllPoints();note:SetPoint('TOPLEFT',detailsX,-(bestY+28))
      note:SetWidth(detailsWidth)
      turnIn:ClearAllPoints();turnIn:SetPoint('TOPLEFT',detailsX,-(bestY+55))
      turnIn:SetWidth(detailsWidth)
      info:SetWidth(width-42)
      local leftWidth=listRight-26
      for i,b in ipairs(rowButtons) do
        b:SetWidth(leftWidth)
        b.text:SetWidth(math.max(215,leftWidth-100))
      end
      if updateList then updateList() end
    end
    local grip=CreateFrame('Button',nil,f)
    grip:SetSize(20,20);grip:SetPoint('BOTTOMRIGHT',-2,2)
    grip:SetFrameLevel(f:GetFrameLevel()+6)
    grip:SetNormalTexture('Interface\\ChatFrame\\UI-ChatIM-SizeGrabber-Up')
    grip:SetHighlightTexture('Interface\\ChatFrame\\UI-ChatIM-SizeGrabber-Highlight')
    grip:SetPushedTexture('Interface\\ChatFrame\\UI-ChatIM-SizeGrabber-Down')
    grip:SetScript('OnMouseDown',function()f:StartSizing('BOTTOMRIGHT')end)
    grip:SetScript('OnMouseUp',function()
      f:StopMovingOrSizing()
      DB.waylaidCratesWidth=math.floor(f:GetWidth()+.5)
      DB.waylaidCratesHeight=math.floor(f:GetHeight()+.5)
      savePosition(f,'waylaidCratesPos')
    end)
    f:SetScript('OnSizeChanged',function(_,w,h)layoutCrates(w,h)end)
    -- Wait until first OnShow for the initial lookup; no duplicate read
    -- during construction of this initially hidden panel.
    layoutCrates(f:GetWidth(),f:GetHeight())
    updateList()
    showDetail(WAYLAID_CRATES[1])
    updateList()
    f:Hide();rows.registerPopup(f);rows.waylaidCratesFrame=f
  end
  local f=rows.waylaidCratesFrame
  f:SetShown(not f:IsShown())
end

local WRIT_QUOTE_IDS={
  ["azure silk hood"]={nil,7048,nil},
  ["barbaric gloves"]={264045,nil,"Craftsman's Writ: Barbaric Gloves"},
  ["big bronze bomb"]={264036,nil,"Craftsman's Writ: Big Bronze Bomb"},
  ["big voodoo mask"]={264100,nil,"Craftsman's Writ: Big Voodoo Mask"},
  ["black mageweave vest"]={nil,9998,nil},
  ["catseye draught"]={264060,nil,"Craftsman's Writ: Catseye Draught"},
  ["catseye ultra goggles"]={264084,nil,"Craftsman's Writ: Catseye Ultra Goggles"},
  ["cenarion herb bag"]={264157,nil,"Craftsman's Writ: Cenarion Herb Bag"},
  ["cindercloth robe"]={264114,10042,"Craftsman's Writ: Cindercloth Robe"},
  ["craftsman's monocle"]={264082,nil,"Craftsman's Writ: Craftsman's Monocle"},
  ["draught of water breathing"]={264019,5996,"Craftsman's Writ: Draught of Water Breathing"},
  ["dusky bracers"]={264094,7378,"Craftsman's Writ: Dusky Bracers"},
  ["earthen silk belt"]={264115,nil,"Craftsman's Writ: Earthen Silk Belt"},
  ["elixir of defense"]={264018,nil,"Craftsman's Writ: Elixir of Defense"},
  ["elixir of ogre's strength"]={264011,3391,"Craftsman's Writ: Elixir of Ogre's Strength"},
  ["enchanted mageweave pouch"]={264108,nil,"Craftsman's Writ: Enchanted Mageweave Pouch"},
  ["fine leather pants"]={264039,5958,"Craftsman's Writ: Fine Leather Pants"},
  ["fire protection potion"]={264063,nil,"Craftsman's Writ: Fire Protection Potion"},
  ["gnomish universal remote"]={264035,7506,"Craftsman's Writ: Gnomish Universal Remote"},
  ["golden scale coif"]={264074,nil,"Craftsman's Writ: Golden Scale Coif"},
  ["golden scale gauntlets"]={264078,nil,"Craftsman's Writ: Golden Scale Gauntlets"},
  ["greater adept's robe"]={264054,nil,"Craftsman's Writ: Greater Adept's Robe"},
  ["heavy bronze mace"]={264024,3491,"Craftsman's Writ: Heavy Bronze Mace"},
  ["heavy leather ball"]={264038,18662,"Craftsman's Writ: Heavy Leather Ball"},
  ["iridescent hammer"]={264022,5541,"Craftsman's Writ: Iridescent Hammer"},
  ["lesser mana potion"]={264013,3385,"Craftsman's Writ: Lesser Mana Potion"},
  ["lesser troll's blood elixir"]={264017,3388,"Craftsman's Writ: Lesser Troll's Blood Elixir"},
  ["lesser wizard's robe"]={264047,5766,"Craftsman's Writ: Lesser Wizard's Robe"},
  ["mageweave bag"]={264104,10050,"Craftsman's Writ: Mageweave Bag"},
  ["mana potion"]={nil,3827,nil},
  ["mithril frag bomb"]={264088,nil,"Craftsman's Writ: Mithril Frag Bomb"},
  ["mithril spurs"]={nil,7969,nil},
  ["moonsteel broadsword"]={264073,nil,"Craftsman's Writ: Moonsteel Broadsword"},
  ["ornate spyglass"]={264029,5507,"Craftsman's Writ: Ornate Spyglass"},
  ["pearl-handled dagger"]={264020,5540,"Craftsman's Writ: Pearl-Handled Dagger"},
  ["phoenix pants"]={264051,4317,"Craftsman's Writ: Phoenix Pants"},
  ["pilferer's gloves"]={264042,7358,"Craftsman's Writ: Pilferer's Gloves"},
  ["practice lock"]={nil,6712,nil},
  ["rough bronze leggings"]={264025,2865,"Craftsman's Writ: Rough Bronze Leggings"},
  ["shadow protection potion"]={264014,6048,"Craftsman's Writ: Shadow Protection Potion"},
  ["shadoweave gloves"]={264105,nil,"Craftsman's Writ: Shadoweave Gloves"},
  ["shadoweave robe"]={264107,nil,"Craftsman's Writ: Shadoweave Robe"},
  ["small silk pack"]={nil,4245,nil},
  ["solid sharpening stone"]={nil,7964,nil},
  ["steel weapon chain"]={264070,6041,"Craftsman's Writ: Steel Weapon Chain"},
  ["swift boots"]={264098,nil,"Craftsman's Writ: Swift Boots"},
  ["thick leather ammo pouch"]={264103,nil,"Craftsman's Writ: Thick Leather Ammo Pouch"},
  ["truesilver rod"]={nil,11144,nil},
  ["unstable trigger"]={264085,nil,"Craftsman's Writ: Unstable Trigger"},
  ["wicked leather pants"]={264143,nil,"Craftsman's Writ: Wicked Leather Pants"},
  ["wicked mithril blade"]={264076,nil,"Craftsman's Writ: Wicked Mithril Blade"},
  ["wild leather helmet"]={264095,nil,"Craftsman's Writ: Wild Leather Helmet"},
  ["wildvine potion"]={264067,nil,"Craftsman's Writ: Wildvine Potion"},
}
-- Named writs and their turn-in items have distinct auction IDs.
function rows.toggleWritPrices()
    if DB and DB.experimentalTabbedUI and rows.experimentalTabs and not rows.experimentalTabs.switching then
      rows.experimentalTabs.open('Writs');return
    end
  if rows.writPrices then
    rows.writPrices:SetShown(not rows.writPrices:IsShown())
    return
  end
  local f=CreateFrame('Frame','WritThisWritPrices',UIParent,BackdropTemplateMixin and 'BackdropTemplate')
  rows.writPrices=f
  f:SetSize(1040,535);f:SetMovable(true);f:SetClampedToScreen(true);f:EnableMouse(true)
  f:SetFrameStrata('DIALOG');position(f,'writPricesPos',0,0);skinFrame(f);makeDraggable(f,'writPricesPos')
  local function label(str,width,x,y,large)
    local t=textLine(f,str,width,large);t:SetPoint('TOPLEFT',x,-y);return t
  end
  label('WRITS  |  AUCTION HOUSE',280,18,16,true)
  local acCheck=CreateFrame('CheckButton',nil,f,'UICheckButtonTemplate')
  acCheck:SetSize(23,23);acCheck:SetPoint('TOPLEFT',303,-13)
  acCheck:SetChecked(rows.usingACPrices())
  local acCheckText=textLine(acCheck,'Use AC prices (experimental)',220)
  acCheckText:SetPoint('LEFT',acCheck,'RIGHT',2,0)
  acCheck:SetHitRectInsets(0,-220,0,0)
  acCheck:SetScript('OnClick',function(self)rows.setWritPriceProvider(self:GetChecked())end)
  acCheck:SetScript('OnEnter',function(self)
    if not GameTooltip then return end
    GameTooltip:SetOwner(self,'ANCHOR_BOTTOM')
    GameTooltip:AddLine('Experimental AH price provider',1,.83,.44)
    GameTooltip:AddLine('AC only: uses AC automatically. Auctionator only: uses Auctionator automatically. Install both to switch here.',1,1,1,true)
    GameTooltip:AddLine('Unresolved AC item IDs are missing, never silently filled from Auctionator.',.95,.79,.5,true)
    GameTooltip:Show()
  end)
  acCheck:SetScript('OnLeave',function()if GameTooltip then GameTooltip:Hide()end end)
  rows.writProviderChecks[acCheck]=acCheckText
    rows.updateProviderChecks()
  createButton(f,'X',25,24,function()rows.navigation.close(f)end):SetPoint('TOPRIGHT',-12,-12)
  local status=label('',810,19,52)
  local columns={{'Required item',18,207},{'Turn-in location',229,151},{'Turn-in NPC',384,140},{'Writ price',528,98},{'Item price',629,98},{'Total',730,99},{'Rep',832,36},{'Cost / 100 rep',872,100}}
  for _,col in ipairs(columns) do label(col[1],col[3],col[2],159) end
  local page,sortMode,query=1,'total',''
  local entries,filtered,lines={},{},{}
  local cursor,selected
  local byName,observed={},{}
  local resetAt
  local function readReset()
    local getReset=(C_DateAndTime and C_DateAndTime.GetSecondsUntilDailyReset) or GetQuestResetTime
    local seconds=getReset and getReset()
    if time and type(seconds)=='number' and seconds>0 and seconds<=86400 then
      return time()+seconds
    end
  end
  local function done(e)
    return resetAt and e.lastTurnIn and e.lastTurnIn>0 and e.lastTurnIn>=resetAt-86400
  end
  local scanLabel,scanCount,expectedScanSize,liveJob=nil,0,nil,nil
  local liveQuoteLifetime=15*60
  local function liveMarket()
    local realm=type(GetRealmName)=='function' and GetRealmName() or 'Unknown Realm'
    local faction=type(UnitFactionGroup)=='function' and UnitFactionGroup('player') or 'Unknown'
    local house=faction
    if C_AuctionHouse and type(C_AuctionHouse.IsNeutralAuctionHouse)=='function' then
      local ok,neutral=pcall(C_AuctionHouse.IsNeutralAuctionHouse)
      if ok and neutral then house='Neutral' end
    end
    return tostring(realm)..'|'..tostring(house)
  end
  local function currentScan()
    if not rows.usingACPrices() then return end
    local api=rows.ACPriceAPI()
    local now=time()
    local scope=liveMarket()
    if scanLabel and api and type(api.GetNameScanStatus)=='function' then
      local ok,job=pcall(api.GetNameScanStatus)
      if ok and type(job)=='table' and job.label==scanLabel and job.scope==scope then
        local startedAt=tonumber(job.startedAt)
        if job.phase=='cancelled' then
          local saved=DB.writLiveScan
          if type(saved)=='table' and saved.label==scanLabel then DB.writLiveScan=nil end
          return
        end
        local completedAt=tonumber(job.completedAt)
        local finished=job.phase=='complete' or job.phase=='partial'
        if startedAt and startedAt<=now and (job.phase=='running' or
            (finished and completedAt and completedAt>=startedAt and completedAt<=now and
             now-completedAt<liveQuoteLifetime)) then
          local saved=DB.writLiveScan
          if type(saved)~='table' or saved.label~=job.label or saved.startedAt~=startedAt or
              saved.scope~=scope or type(saved.quotes)~='table' then
            saved={label=job.label,startedAt=startedAt,scope=scope,quotes={}}
            DB.writLiveScan=saved
          end
          saved.phase=finished and job.phase or 'partial'
          saved.savedAt=finished and completedAt or now
          saved.total=job.total
          saved.done=job.done
          saved.verified=job.verified
          saved.missing=job.missing
          saved.failed=job.failed
          saved.expected=expectedScanSize
          return job
        end
      end
      return
    end
    local saved=DB.writLiveScan
    if type(saved)~='table' or saved.scope~=scope or type(saved.quotes)~='table' or
        (saved.phase~='complete' and saved.phase~='partial') then return end
    local stamp,start=tonumber(saved.savedAt),tonumber(saved.startedAt)
    if stamp and start and start<=stamp and stamp<=now and now-stamp<liveQuoteLifetime then
      expectedScanSize=saved.expected
      return saved
    end
  end
  local function quote(name,id)
    local key=requiredKey(name)
    local learned=DB.writBrowseIDs and DB.writBrowseIDs[key]
    if rows.usingACPrices() then
      local start=liveJob and tonumber(liveJob.startedAt)
      if not start then return nil,nil,nil,'Run AC Live Scan All' end
      local snapshot=DB.writLiveScan
      local fromSaved=liveJob==snapshot
      local ok,price,actualID,stamp,state
      if fromSaved then
        local entry=snapshot.quotes[key]
        if type(entry)=='table' then ok,price,actualID,stamp,state=true,entry.price,entry.id,entry.stamp,'verified' end
      else
        local api=rows.ACPriceAPI()
        if not api or type(api.GetNameScanQuote)~='function' then return nil,nil,nil,'No current AC live quote' end
        ok,price,actualID,stamp,state=pcall(api.GetNameScanQuote,name)
      end
      price,actualID,stamp=tonumber(price),tonumber(actualID),tonumber(stamp)
      local now=time()
      if ok and state=='verified' and actualID and actualID>0 and
          price and price>=1 and price<100000000000 and
          stamp and stamp>=start and stamp<=now and now-stamp<liveQuoteLifetime then
        local actualName=getName(actualID)
        if (not actualName or requiredKey(actualName)==key) and
            (not id or tonumber(id)==actualID or actualName) and
            (not learned or tonumber(learned)==actualID or actualName) then
          if not fromSaved and snapshot then
            snapshot.quotes[key]={price=price,id=actualID,stamp=stamp}
          end
          return math.floor(price+.5),actualID,0,'AC live name',stamp
        end
      end
      return nil,nil,nil,'No current AC live quote'
    end
    local seen=observed[key]
    if seen and ahOpen and rows.activeProvider()=='Auctionator' and
        time()-seen.stamp<liveQuoteLifetime then return seen.price,seen.id,0,'AH browse' end
    id=learned or id
    local actualName=id and getName(id)
    if not actualName or requiredKey(actualName)~=key then
      id=not actualName and learned or crateItemID(name)
      actualName=id and getName(id)
      if (actualName and requiredKey(actualName)~=key) or
          (not actualName and id~=learned) then id=nil end
    end
    if not id and rows.activeProvider()=='Auctionator' then
      return nil,nil,nil,'Item ID not verified; search by name'
    end
    local price,actualID,age,err,source,stamp=rows.readMarketQuote(name,id)
    return price,actualID,age,source or err or 'No quote',stamp
  end
  local function updateEntry(e)
    local w,id,wa,ws,wt=quote(e.writ,e.writID)
    local v,_,va,vs,vt=quote(e.item,e.itemID)
    local changed=e.writPrice~=w or e.itemPrice~=v or e.writSource~=ws or e.itemSource~=vs
    e.writPrice=w;e.itemPrice=v;e.writSource=ws;e.itemSource=vs
    e.writStamp=wt;e.itemStamp=vt
    e.total=w and v and w+v
    if not e.rep and id and e.total then
      local _,reward=TIER.peek(id)
      e.rep=reward
    end
    local age=wa and va and math.max(wa,va)
    local per100=age==0 and e.rep and e.total and e.total*100/e.rep or nil
    changed=changed or e.age~=age or e.per100~=per100
    e.age=age;e.per100=per100
    return changed
  end
  local pageText=label('',135,364,490)
  local hint=label('',810,19,450)
  local function draw()
    local pages=math.max(1,math.ceil(#filtered/#lines))
    page=math.max(1,math.min(page,pages))
    pageText:SetText('Page '..page..' / '..pages)
    for i,line in ipairs(lines) do
      local e=filtered[(page-1)*#lines+i]
      line.entry=e;line:SetShown(e~=nil)
      if e then
        local function money(v)return v and fmtMoney(math.floor(v+.5)) or '—' end
        local values={done(e) and ('|cffffff00[DONE]|r '..e.item) or e.item,e.zone,e.book.npc or 'Unknown',money(e.writPrice),money(e.itemPrice),money(e.total),e.rep or '—',money(e.per100)}
        for k,t in ipairs(line.labels) do t:SetText(values[k]) end
        line.mapButton:SetShown(e.zone~='Unknown')
        if line.SetBackdropBorderColor then
          if selected==e then line:SetBackdropBorderColor(1,.82,.3,1)
          else line:SetBackdropBorderColor(unpack(skin().edge)) end
        end
      end
    end
    hint:SetText(selected and (selected.item..'   |   '..selected.zone..'   |   Writ: '..(selected.writSource or '…')..'   |   Item: '..(selected.itemSource or '…')..'   |   '..(selected.age and ('Oldest quote: '..selected.age..'d') or 'Quote age unknown')) or 'Click to select. Shift-click an item for History/Records.')
  end
  local function filter()
    filtered={}
    local keepSelected=false
    for _,e in ipairs(entries) do
      if (not DB.hideNoWritPrice or e.writPrice) and (not DB.hideNoItemPrice or e.itemPrice)
        and (e.item:lower():find(query,1,true) or e.zone:lower():find(query,1,true) or (e.book.npc or ''):lower():find(query,1,true)) then
        filtered[#filtered+1]=e
        if e==selected then keepSelected=true end
      end
    end
    if not keepSelected then selected=nil end
    local field=sortMode=='per100' and 'per100' or 'total'
    table.sort(filtered,function(a,b)
      if sortMode=='location' and a.zone~=b.zone then
        if a.zone=='Unknown' then return false end
        if b.zone=='Unknown' then return true end
        return a.zone<b.zone
      end
      local av,bv=a[field] or math.huge,b[field] or math.huge
      if av~=bv then return av<bv end
      return a.item<b.item
    end)
    draw()
  end
  for i=1,9 do
    local line=createButton(f,'',1004,28,function(self)
      local e=self.entry
      if not e then return end
      if IsShiftKeyDown and IsShiftKeyDown() and itemsBook then
        bookMode='items'
        itemsBook.viewButton.text:SetText('View: Items')
        local zone=trim(e.zone):lower()
        DB.bookMissingOnly=zone=='' or zone=='unknown' or zone=='not revealed'
        itemsBook.missingButton.text:SetText(DB.bookMissingOnly and 'Missing: On' or 'Missing: Off')
        itemsBook.search:SetText(e.bookItem)
        bookSelected=e.bookKey
        if itemsBook:IsShown() then bookRefresh() else itemsBook:Show() end
        if itemsBook.Raise then itemsBook:Raise() end
        return
      end
      selected=e;draw()
    end)
    line:SetPoint('TOPLEFT',16,-179-(i-1)*29);line.labels={}
    for _,col in ipairs(columns) do
      local t=textLine(line,'',col[3]);t:SetPoint('LEFT',col[2]-14,0)
      if t.SetWordWrap then t:SetWordWrap(false) end
      line.labels[#line.labels+1]=t
    end
    line.mapButton=createButton(line,'Map',42,22,function()
      if line.entry then rows.openReferenceMap(line.entry.book) end
    end)
    line.mapButton:SetPoint('RIGHT',line,'RIGHT',-4,0)
    lines[i]=line
  end
  local function priceFilter(key,caption,x)
    local check=CreateFrame('CheckButton',nil,f,'UICheckButtonTemplate')
    check:SetSize(24,24);check:SetPoint('TOPLEFT',x,-116);check:SetChecked(DB[key]==true)
    local title=textLine(check,caption,nil)
    title:SetPoint('LEFT',check,'RIGHT',2,0)
    check:SetHitRectInsets(0,-140,0,0)
    check:SetScript('OnClick',function(self)
      DB[key]=not not self:GetChecked()
      page=1;filter()
    end)
  end
  priceFilter('hideNoWritPrice','Hide missing writ price',18)
  priceFilter('hideNoItemPrice','Hide missing item price',216)
  label('Find',38,19,97)
  local search=CreateFrame('EditBox',nil,f,'InputBoxTemplate')
  search:SetSize(190,25);search:SetPoint('TOPLEFT',63,-88);search:SetAutoFocus(false);search:SetFontObject(GameFontHighlightSmall)
  search:SetScript('OnTextChanged',function(self)query=trim(self:GetText()):lower();page=1;filter()end)
  search:SetScript('OnEscapePressed',function(self)self:ClearFocus()end)
  local sort=createButton(f,'Sort: Total',143,27,function(self)
    if sortMode=='total' then sortMode='per100';self.text:SetText('Sort: Cost / 100 rep')
    elseif sortMode=='per100' then sortMode='location';self.text:SetText('Sort: Location')
    else sortMode='total';self.text:SetText('Sort: Total') end
    page=1;filter()
  end)
  sort:SetPoint('TOPLEFT',272,-88)
  createButton(f,'Previous',85,27,function()page=page-1;draw()end):SetPoint('BOTTOMLEFT',263,22)
  createButton(f,'Next',85,27,function()page=page+1;draw()end):SetPoint('BOTTOMLEFT',480,22)
  local winner,winnerStatus
  local function winnerText(e)
    return e.item..'  |  '..fmtMoney(e.total)..' total  |  '..e.rep..' rep  |  '..
      fmtMoney(math.floor(e.per100+.5))..' / 100 rep'
  end
  local winnerButton=createButton(f,'WINNER  |  Reading prices',345,35,function()
    if not winner or cursor then return end
    if IsShiftKeyDown and IsShiftKeyDown() then
      rows.copyWinner('Writ This AH '..(winnerStatus=='WINNER' and 'winner' or 'provisional')..': '..winnerText(winner)..'  |  '..winner.zone)
      return
    end
    query=''
    search:SetText('')
    search:ClearFocus()
    selected=winner
    for i,e in ipairs(filtered) do
      if e==winner then page=math.floor((i-1)/#lines)+1;break end
    end
    draw()
  end)
  winnerButton:SetPoint('TOPRIGHT',-120,-10)
  winnerButton.text:SetWidth(335)
  winnerButton:SetScript('OnEnter',function(self)
    if not GameTooltip then return end
    GameTooltip:SetOwner(self,'ANCHOR_BOTTOM')
    GameTooltip:AddLine('Lowest cost per 100 rep among eligible writs without a recorded turn-in this reset.',1,.83,.44,true)
    GameTooltip:AddLine('AC: prices require the current Writs Live Scan All. Quotes expire after 15 minutes or when AC withdraws them.',1,.74,.51,true)
    GameTooltip:AddLine('Auctionator: cached prices are estimates. A confirmed winner requires current browse prices for all eligible pairs.',.9,.76,.52,true)
    GameTooltip:AddLine('WINNER requires a complete scan with no missing names, failed queries or eligible unverified pairs.',.9,.76,.52,true)
    if winner and not cursor then
      GameTooltip:AddLine(winnerText(winner),1,1,1,true)
      GameTooltip:AddLine('Writ '..fmtMoney(winner.writPrice)..' + item '..fmtMoney(winner.itemPrice),.8,.9,1)
      GameTooltip:AddLine('Click to select. Shift-click to copy.',.84,.83,.73)
    else
      GameTooltip:AddLine('Requires both prices and a known reputation reward.',.84,.83,.73)
    end
    GameTooltip:Show()
  end)
  winnerButton:SetScript('OnLeave',function()if GameTooltip then GameTooltip:Hide() end end)
  local function evaluateWinner(candidateEntries,usingAC,liveJob,isDone)
    local best,eligible,livePairs,allVerified=nil,0,0,true
    local start=liveJob and tonumber(liveJob.startedAt)
    for _,e in ipairs(candidateEntries) do
      local rep=tonumber(e.rep)
      if not isDone(e) then
        eligible=eligible+1
        local isLive=usingAC and start and
          e.writSource=='AC live name' and e.itemSource=='AC live name' and
          e.writPrice and e.itemPrice and e.per100 and
          e.writStamp and e.writStamp>=start and
          e.itemStamp and e.itemStamp>=start
        local browsePair=e.writSource=='AH browse' and e.itemSource=='AH browse'
        if (usingAC and not isLive) or (not usingAC and not browsePair) or
            not rep or rep<=0 then allVerified=false end
        if isLive then livePairs=livePairs+1 end
        if (isLive or (not usingAC and e.age==0)) and e.per100 and
           (not best or e.per100<best.per100 or
             (e.per100==best.per100 and (e.total<best.total or
             (e.total==best.total and e.item<best.item)))) then
          best=e
        end
      end
    end
    -- A completed scan with missing catalogue names cannot confirm the best
    -- even if the displayed candidate has its own verified quote. A fresh
    -- scan is required again once AC's live-quote window has expired.
    local total=liveJob and tonumber(liveJob.total)
    local complete=(not usingAC and allVerified) or (type(liveJob)=='table' and
      liveJob.phase=='complete' and total and total>0 and total==expectedScanSize and
      tonumber(liveJob.done)==total and tonumber(liveJob.verified)==total and
      tonumber(liveJob.missing)==0 and tonumber(liveJob.failed)==0 and
      allVerified)
    return best,complete and 'WINNER' or 'PROVISIONAL',livePairs,eligible
  end
  local function updateStatus()
    local priced=0
    for _,e in ipairs(entries) do if e.total then priced=priced+1 end end
    local usingAC=rows.usingACPrices()
    local live
    if usingAC and liveJob then
      local label=liveJob==DB.writLiveScan and 'Saved scan' or 'Live'
      live=(label..' %d/%d checked (%d priced, %d missing, %d unverified)'):format(
        tonumber(liveJob.done) or 0,tonumber(liveJob.total) or 0,tonumber(liveJob.verified) or 0,
        tonumber(liveJob.missing) or 0,tonumber(liveJob.failed) or 0)
    end
    local livePairs,eligible
    winner,winnerStatus,livePairs,eligible=evaluateWinner(entries,usingAC,liveJob,done)
    if winner then
      winnerButton.text:SetText(winnerStatus..'  |  '..winner.item..'\n'..
        fmtMoney(math.floor(winner.per100+.5))..' / 100 rep')
    elseif usingAC then
      winnerButton.text:SetText(liveJob and 'PROVISIONAL  |  No live-priced candidate' or
        'LIVE SCAN REQUIRED  |  No verified candidate')
    else
      winnerButton.text:SetText('No eligible writ with current prices')
    end
    status:SetText(priced..' / '..#entries..' priced'..
      (usingAC and ('   |   '..livePairs..' / '..eligible..' eligible live-verified') or '')..'   |   '..
      (live or (usingAC and 'Run AC Live Scan All for current prices' or
        rows.activeProvider()=='Auctionator' and 'AH browse + Auctionator cache | Cost/rep requires day-0 quotes' or
        'Install AC or Auctionator for prices'))..
      '   |   '..(rows.providerScanAge() or 'Scan time unknown')..(resetAt and '' or '   |   Daily reset unknown'))
  end
  -- Process the user's existing browse results. Never start searches in this listener.
  local listener=CreateFrame('Frame')
  local pending,job,again
  local function applyBrowse(best)
    local changed=false
    for key,seen in pairs(best) do
      local old=observed[key]
      if not old or old.price~=seen.price or old.id~=seen.id or old.stamp~=time() then
        seen.stamp=time()
        observed[key]=seen
        DB.writBrowseIDs=DB.writBrowseIDs or {}
        DB.writBrowseIDs[key]=seen.id
        if byName[key] and f:IsShown() then updateEntry(byName[key]) end
        changed=true
      end
    end
    if changed and f:IsShown() and not cursor and not rows.usingACPrices() then filter();updateStatus() end
  end
  local function requestBrowse()
    if rows.activeProvider()~='Auctionator' or not ahOpen or not C_AuctionHouse or not C_AuctionHouse.GetBrowseResults then return end
    pending=true;listener:Show()
  end
  local function capture()
    local ok,result=pcall(C_AuctionHouse.GetBrowseResults)
    if ok and type(result)=='table' then
      job={list=result,index=1,best={},retry={}}
    end
  end
  listener:SetScript('OnUpdate',function()
    if not job and pending then pending=nil;capture() end
    if not job then listener:Hide();return end
    for i=job.index,math.min(job.index+19,#job.list) do
      local r=job.list[i]
      local k=r.itemKey
      local id=k and tonumber(k.itemID)
      local price=tonumber(r.minPrice)
      if id and id>0 and price and price>0 and (not r.totalQuantity or r.totalQuantity>0) then
        local name=r.itemName or ahName(k)
        if name then
          local key=requiredKey(name)
          if byName[key] and (not job.best[key] or price<job.best[key].price) then
            job.best[key]={id=id,price=price}
          end
        elseif not job.retried then
          job.retry[#job.retry+1]=r
        end
      end
    end
    job.index=job.index+20
    if job.index<=#job.list then return end
    if #job.retry>0 and not job.retried and not pending then
      if not again then again=clock()+0.5 end
      if clock()<again then return end
      job.list=job.retry;job.retry={};job.index=1;job.retried=true;again=nil
      return
    end
    applyBrowse(job.best)
    job=nil;again=nil
    if not pending then listener:Hide() end
  end)
  listener:SetScript('OnEvent',function(_,event)
    if event=='AUCTION_HOUSE_CLOSED' then
      observed={};job=nil;pending=nil;again=nil;listener:Hide()
      if f:IsShown() then cursor=1 end
    else requestBrowse() end
  end)
  for _,event in ipairs({'AUCTION_HOUSE_BROWSE_RESULTS_UPDATED','AUCTION_HOUSE_BROWSE_RESULTS_ADDED','AUCTION_HOUSE_CLOSED'}) do
    pcall(listener.RegisterEvent,listener,event)
  end
  listener:Hide()
  rows.dailyPriceChanged=function(key,at)
    local e=byName[key]
    if e and f:IsShown() then
      e.lastTurnIn=at
      if not cursor then updateStatus();draw() end
    end
  end
  local nextResetCheck=0
  local function checkReset()
    resetAt=readReset()
    nextResetCheck=clock()+(resetAt and math.max(1,resetAt-time()) or 60)
  end
  local function refreshPrices()
    checkReset()
    populateBook()
    local known={}
    for _,group in ipairs({DB.completed or {},DB.orders or {}}) do
      for _,e in ipairs(group) do
        local name=requiredItemName(e)
        if name and not e.sealed then
          local key=requiredKey(name)
          local data=known[key] or {}
          if e.writ and e.writ:lower():find('writ:',1,true) then
            data.writ=e.writ
            data.writID=e.openedItemID or e.itemID or data.writID
          end
          data.itemID=e.requiredItemID or data.itemID
          data.rep=tonumber(e.repEarned) or (not e.repNeedsReview and tonumber(e.rep)) or data.rep
          if e.complete and tonumber(e.completedEpoch) then
            data.lastTurnIn=math.max(data.lastTurnIn or 0,e.completedEpoch)
          end
          known[key]=data
        end
      end
    end
    entries={};byName={};selected=nil;page=1
    for _,book in ipairs(bookEntries) do
      local key=requiredKey(book.item)
      if key~='' and book.item:sub(1,1)~='(' then
        local d=known[key] or {}
        local writ=d.writ or ('Craftsman\'s Writ: '..book.item)
        local seed=WRIT_QUOTE_IDS[key] or {}
        local rep=tonumber(book.rep) or d.rep
        local zone=trim(book.zone)
        if zone=='' or zone:lower()=='not revealed' or zone:lower()=='unknown' then zone='Unknown' end
        entries[#entries+1]={book=book,bookKey=book.key,bookItem=book.item,lastTurnIn=math.max(d.lastTurnIn or 0,(DB.lastWritTurnIn or {})[key] or 0),item=prettyItemName(key),writ=d.writ or seed[3] or writ,zone=zone,
          writID=d.writID or seed[1],itemID=d.itemID or seed[2],rep=rep and rep>0 and rep or nil}
      end
    end
    for _,e in ipairs(entries) do
      byName[requiredKey(e.item)]=e
      byName[requiredKey(e.writ)]=e
    end
    winner=nil;winnerButton.text:SetText('WINNER  |  Reading prices')
    cursor=1;status:SetText('Reading AH prices…');filter()
  end
  createButton(f,'Refresh Prices',122,27,refreshPrices):SetPoint('TOPLEFT',426,-88)
  local scanAllButton=createButton(f,'Scan all at AH',146,27,function()
    if rows.usingACPrices() then
      if not ahOpen then hint:SetText('Open the AH to run AC Live Scan All.');return end
      local api=rows.ACPriceAPI()
      if not api or type(api.StartNameScan)~='function' then
        hint:SetText('Install/update Auction Companion 0.1.8+ to use AC Live Scan All.');return
      end
      local names,seen={},{}
      local function add(name,id)
        local key=requiredKey(name)
        if key~='' and not seen[key] then
          seen[key]=true
          local learned=DB.writBrowseIDs and DB.writBrowseIDs[key]
          local candidate=learned or id or crateItemID(name)
          local actualName=candidate and getName(candidate)
          if (actualName and requiredKey(actualName)~=key) or
              (not actualName and candidate~=learned) then candidate=nil end
          names[#names+1]={name=name,itemID=candidate}
        end
      end
      for _,e in ipairs(entries) do
        add(e.writ,e.writID);add(e.item,e.itemID)
      end
      if #names==0 then hint:SetText('Refresh Prices to load the writ catalogue first.');return end
      scanCount=scanCount+1
      local label='Writs: Live Scan All '..time()..'.'..scanCount
      local ok,started,reason=pcall(api.StartNameScan,names,label)
      if ok and started then
        DB.writLiveScan=nil
        scanLabel=label
        expectedScanSize=#names
        liveJob=currentScan()
        for _,entry in ipairs(entries) do updateEntry(entry) end
        filter()
        winner=nil;cursor=1
        winnerButton.text:SetText('Reading live prices')
        hint:SetText('AC Live Scan All started: '..#names..' names. Prices update as verified.')
      else
        hint:SetText('AC Live Scan All: '..tostring(ok and reason or started))
      end
      return
    end
    -- Preserve the original thorough Auctionator Shopping scan in Auctionator mode.
    local api=crateAuctionatorAPI()
    if not ahOpen then hint:SetText('Open the auction house to scan all writs.');return end
    if not api or not api.MultiSearchExact then hint:SetText('Enable Auctionator to scan all writs.');return end
    local terms,added={},{}
    for _,e in ipairs(entries) do
      for _,name in ipairs({e.writ,e.item}) do
        local key=requiredKey(name)
        if not added[key] then terms[#terms+1]=name;added[key]=true end
      end
    end
    local ok=pcall(api.MultiSearchExact,'WritTracker',terms)
    if ok then f:Hide() else hint:SetText('Auctionator could not start the catalogue search.') end
  end)
  scanAllButton:SetPoint('TOPRIGHT',f,'TOPRIGHT',-20,-88)
  scanAllButton:SetEnabled(rows.activeProvider()~=nil)
  local function attachShopping()
    if f.shoppingListener then return end
    local bus=Auctionator and Auctionator.EventBus
    local ev=Auctionator and Auctionator.Shopping and Auctionator.Shopping.Tab and Auctionator.Shopping.Tab.Events
    if not bus or not bus.Register or not ev or not ev.SearchEnd or not ev.SearchIncrementalUpdate then return end
    local receiver={}
    function receiver:ReceiveEvent(_,results)
      if rows.activeProvider()~='Auctionator' or not ahOpen or type(results)~='table' then return end
      local best={}
      for _,r in ipairs(results) do
        local id=r.itemKey and tonumber(r.itemKey.itemID)
        local price=tonumber(r.minPrice)
        if id and id>0 and price and price>0 and (not r.totalQuantity or r.totalQuantity>0) then
          local name=r.name or r.itemName or ahName(r.itemKey)
          local key=name and requiredKey(name)
          if key and byName[key] and (not best[key] or price<best[key].price) then
            best[key]={id=id,price=price}
          end
        end
      end
      applyBrowse(best)
    end
    if pcall(bus.Register,bus,receiver,{ev.SearchEnd,ev.SearchIncrementalUpdate}) then f.shoppingListener=receiver end
  end
  createButton(f,'Search both at AH',156,27,function()
    if not selected then hint:SetText('Select a writ first.');return end
    if not ahOpen then hint:SetText('Open the auction house to search both items.');return end
    if rows.usingACPrices() then
      local ac=rows.ACPriceAPI()
      if not ac or type(ac.SearchShoppingItems)~='function' then
        hint:SetText('Update Auction Companion to 0.1.19+ for Writ shopping.');return
      end
      local function item(name,seed,role)
        local key=requiredKey(name)
        local id=(DB.writBrowseIDs and DB.writBrowseIDs[key]) or seed or crateItemID(name)
        -- Reuse an exact item ID when verified, but always require a fresh
        -- direct search of purchasable listings in the AC shopping interface.
        if type(ac.GetNameScanQuote)=='function' then
          local ok,_,verifiedID,_,state=pcall(ac.GetNameScanQuote,name)
          if ok and state=='verified' and tonumber(verifiedID) then id=tonumber(verifiedID) end
        end
        return {name=name,itemID=id,role=role,required=1}
      end
      local ok,started,reason=pcall(ac.SearchShoppingItems,
        {item(selected.writ,selected.writID,'Writ'),
         item(selected.item,selected.itemID,'Required item')},'Writs: shopping')
      hint:SetText(ok and started and 'Opened Writ + required item in AC shopping (1 each; edit before purchase).' or
        ('AC shopping search: '..tostring(ok and reason or started)))
      return
    end
    local api=crateAuctionatorAPI()
    if not api or not api.MultiSearchExact then hint:SetText('Enable Auctionator to search current listings.');return end
    local ok=pcall(api.MultiSearchExact,'WritTracker',{selected.writ,selected.item})
    if not ok then hint:SetText('Auctionator could not start the search. Reopen the AH and retry.') end
  end):SetPoint('TOPLEFT',559,-88)
  local nextPriceCheck,nextCacheCheck,lastProvider=0,0,rows.activeProvider()
  f.refreshProvider=function()
    local provider=rows.activeProvider()
    if lastProvider~=provider then
      observed={};job=nil;pending=nil;again=nil;listener:Hide()
      scanLabel=nil;liveJob=nil
      lastProvider=provider
    end
    liveJob=currentScan()
    acCheck:SetChecked(rows.usingACPrices())
    scanAllButton.text:SetText(rows.usingACPrices() and 'AC Live Scan All' or
      rows.activeProvider()=='Auctionator' and 'Scan all at AH' or 'No AH provider')
    scanAllButton:SetEnabled(rows.activeProvider()~=nil)
    nextPriceCheck=0;nextCacheCheck=clock()+60
    -- A source toggle should change ONLY prices, not page, selection, filters,
    -- sort mode or the underlying writ catalogue.
    if f:IsShown() then
      if #entries==0 then refreshPrices()
      else
        for _,e in ipairs(entries) do updateEntry(e) end
        updateStatus();filter()
      end
    end
  end
  f:SetScript('OnUpdate',function()
    if clock()>=nextPriceCheck then
      nextPriceCheck=clock()+2
      local previous=liveJob
      liveJob=currentScan()
      -- AC may expire a quote or change phase without incrementing its price
      -- revision. Only poll quotes while the Writs screen and a job are active.
      if not cursor and (liveJob or previous) then
        local changed=false
        for _,entry in ipairs(entries) do
          if updateEntry(entry) then changed=true end
        end
        updateStatus()
        if changed then filter() end
      elseif not cursor and rows.activeProvider()=='Auctionator' then
        local expired=false
        for key,seen in pairs(observed) do
          if time()-seen.stamp>=liveQuoteLifetime then observed[key]=nil;expired=true end
        end
        if expired or clock()>=nextCacheCheck then
          nextCacheCheck=clock()+60
          for _,entry in ipairs(entries) do updateEntry(entry) end
          updateStatus();filter()
        end
      end
    end
    if clock()>=nextResetCheck then
      checkReset()
      if not cursor then updateStatus();draw() end
    end
    if not cursor then return end
    for i=cursor,math.min(cursor+4,#entries) do
      local e=entries[i]
      updateEntry(e)
    end
    cursor=cursor+5
    if cursor>#entries then
      cursor=nil
      if rows.usingACPrices() then
        liveJob=currentScan()
        for _,entry in ipairs(entries) do updateEntry(entry) end
      end
      updateStatus()
      filter()
    end
  end)
  f:Hide();rows.registerPopup(f);f:HookScript('OnShow',function()attachShopping();f.refreshProvider()end);f:Show()
end

end -- scoped Waylaid Auctionator integration


-- v3.3.0 Merchant's Favor vendor catalogue. Reference-only: it neither buys
-- anything nor changes WritTrackerDB, AH queries, crate prices or the Winner.
-- Dataset: 60.tools/guides/merchants-favor (18 Nov 2026). The published 317-row
-- table duplicates "Alchemy Certification" with a contradictory low price;
-- include only its separately documented 300-skill, 1000-Favor version.
-- Thus 316 unique profession purchases + 4 special rewards.
do
  local SHOP={}
  local trade={
    {'Alchemy','Nina Surefire','10.8, 72.5','Apothecary Durelle','49.8, 29.5'},
    {'Blacksmithing','Stondry Darkhammer','10.3, 74.4',"Gor'mak",'49.8, 29.6'},
    {'Cooking','Kalsey Sanden','10.8, 72.5',"Aza'bek",'49.6, 29.2'},
    {'Enchanting','Alynsia','11.2, 71.5','Beneris','49.6, 29.8'},
    {'Engineering','Fritz Fizzle','10.4, 74.2','Fizzlefuse','49.8, 29.6'},
    {'Leatherworking','Daniel Stitchsong','10.0, 72.5','Pawani','49.6, 29.6'},
    {'Tailoring','Mivin Shadowweave','10.0, 72.5',"Jim'bek",'49.6, 29.5'},
    {'Special Rewards','Tamelyn Aldridge / Huey Sunnydale','10.5, 71.5 / 8.5, 71.9',
      'Gishah / Okamache','49.4, 29.4 / 49.6, 28.8'},
  }
  local prefixes={Alchemy='Recipe: ',Blacksmithing='Plans: ',Cooking='Recipe: ',
    Enchanting='Formula: ',Engineering='Schematic: ',Leatherworking='Pattern: ',
    Tailoring='Pattern: '}
  -- Item standings matched to Method profession tables and Kovarel faction rewards.
  -- Packed lines avoid hundreds of redundant Lua constructors at load time.
  local raw=[=[Enchanting|130|45|Mystic Mushroom|Neutral
Enchanting|130|45|Polished Driftwood Icon|Neutral
Enchanting|130|45|Tenets of the Silver Hand|Neutral
Enchanting|140|45|Glimmering Staff|Neutral
Enchanting|140|45|Orb of Mystic Insight|Neutral
Enchanting|140|45|Orb of Souls|Neutral
Enchanting|140|45|Soulstaff|Neutral
Enchanting|140|45|Enchant Weapon - Insight|Neutral
Enchanting|140|45|Enchant Weapon - Recovery|Neutral
Enchanting|140|45|Enchant Weapon - Revelation|Neutral
Enchanting|210|120|Libram of Invocation|Friendly
Enchanting|210|120|Enchant Necklace - Agility|Friendly
Enchanting|210|120|Enchant Necklace - Deflection|Friendly
Enchanting|210|120|Enchant Necklace - Healing Power|Friendly
Enchanting|210|120|Enchant Necklace - Spell Power|Friendly
Enchanting|210|120|Enchant Necklace - Strength|Friendly
Enchanting|210|120|Talons of Wrath|Friendly
Enchanting|210|120|Totem of Ancestral Protection|Friendly
Enchanting|220|120|Enchant Chest - Absorption|Friendly
Enchanting|220|120|Dreamstaff|Friendly
Enchanting|220|120|Radiant Staff|Friendly
Enchanting|220|120|Truesilver Conduit|Friendly
Enchanting|220|120|Twisting Essence Jar|Friendly
Enchanting|275|180|Brilliant Wand|Honored
Enchanting|300|240|Enchant 2H Weapon - Mighty Healing Power|Honored
Enchanting|300|240|Enchant 2H Weapon - Mighty Spell Power|Honored
Enchanting|300|240|Enchant 2H Weapon - Spellblasting|Honored
Enchanting|300|240|Enchant Bracer - Greater Spellpower|Honored
Enchanting|300|240|Enchant Bracer - Superior Deflection|Honored
Enchanting|300|240|Enchant Bracer - Superior Intellect|Honored
Enchanting|300|240|Enchant Cloak - Agility|Honored
Enchanting|300|240|Enchant Gloves - Arcane Power|Honored
Enchanting|300|240|Enchant Gloves - Holy Power|Honored
Enchanting|300|240|Enchant Gloves - Natural Power|Honored
Enchanting|300|240|Enchant Gloves - Superior Strength|Honored
Enchanting|300|240|Idol of the Dream|Honored
Enchanting|300|240|Libram of Holy Alacrity|Honored
Enchanting|300|240|Enchant Off-Hand - Wisdom|Honored
Enchanting|300|240|Totem of Thunder|Honored
Enchanting|300|1000|Enchanting Certification|Neutral
Alchemy|65|45|Elixir of Lesser Spirit|Neutral
Alchemy|75|45|Lesser Mageblood Elixir|Neutral
Alchemy|95|45|Elixir of Lesser Intellect|Neutral
Alchemy|95|45|Lesser Cleric's Elixir|Neutral
Alchemy|120|45|Lesser Arcane Elixir|Neutral
Alchemy|130|45|Mender's Potion|Neutral
Alchemy|135|45|Spellblasting Potion|Neutral
Alchemy|140|45|Frenzy Potion|Neutral
Alchemy|165|120|Elixir of Greater Spirit|Friendly
Alchemy|175|120|Greater Mageblood Elixir|Friendly
Alchemy|195|120|Greater Cleric's Elixir|Friendly
Alchemy|200|120|Elixir of Greater Fortitude|Friendly
Alchemy|245|120|Dragonfire Potion|Friendly
Alchemy|250|180|Elixir of the Phalanx|Honored
Alchemy|265|180|Caustic Smog Potion|Honored
Alchemy|275|180|Elixir of Cunning|Honored
Alchemy|275|180|Elixir of Ferocity|Honored
Alchemy|275|180|Elixir of Sages|Honored
Alchemy|275|180|Elixir of the Whale|Honored
Alchemy|275|180|Potion of Venomous Blood|Honored
Alchemy|280|180|Elixir of the Owl|Honored
Alchemy|280|180|Major Mender's Potion|Honored
Alchemy|280|180|Potion of Elemental Purging|Honored
Alchemy|285|180|Elixir of Nature Power|Honored
Alchemy|285|180|Elixir of Wicked Regeneration|Honored
Alchemy|285|180|Major Spellblasting Potion|Honored
Alchemy|290|240|Major Frenzy Potion|Honored
Alchemy|300|240|Elixir of the Grizzly|Honored
Alchemy|300|1000|Alchemy Certification|Neutral
Blacksmithing|45|30|Acolyte's Chain Belt|Neutral
Blacksmithing|80|30|Acolyte's Gloves|Neutral
Blacksmithing|85|30|Acolyte's Boots|Neutral
Blacksmithing|95|30|Acolyte's Silvered Chain Helm|Neutral
Blacksmithing|110|30|Acolyte's Silvered Chain Shirt|Neutral
Blacksmithing|125|30|Acolyte's Silvered Chain Leggings|Neutral
Blacksmithing|45|30|Crusader's Chain Belt|Neutral
Blacksmithing|80|30|Crusader's Gloves|Neutral
Blacksmithing|85|30|Crusader's Boots|Neutral
Blacksmithing|95|30|Crusader's Silvered Chain Helm|Neutral
Blacksmithing|110|30|Crusader's Silvered Chain Shirt|Neutral
Blacksmithing|125|30|Crusader's Silvered Chain Leggings|Neutral
Blacksmithing|45|30|Guard's Chain Belt|Neutral
Blacksmithing|80|30|Guard's Gloves|Neutral
Blacksmithing|85|30|Guard's Boots|Neutral
Blacksmithing|95|30|Guard's Silvered Chain Helm|Neutral
Blacksmithing|110|30|Guard's Silvered Chain Shirt|Neutral
Blacksmithing|125|30|Guard's Silvered Chain Leggings|Neutral
Blacksmithing|45|30|Protector's Chain Belt|Neutral
Blacksmithing|80|30|Protector's Gloves|Neutral
Blacksmithing|85|30|Protector's Boots|Neutral
Blacksmithing|95|30|Protector's Silvered Chain Helm|Neutral
Blacksmithing|110|30|Protector's Silvered Chain Shirt|Neutral
Blacksmithing|125|30|Protector's Silvered Chain Leggings|Neutral
Blacksmithing|45|30|Veteran's Chain Belt|Neutral
Blacksmithing|80|30|Veteran's Gloves|Neutral
Blacksmithing|85|30|Veteran's Boots|Neutral
Blacksmithing|95|30|Veteran's Silvered Chain Helm|Neutral
Blacksmithing|110|30|Veteran's Silvered Chain Shirt|Neutral
Blacksmithing|125|30|Veteran's Silvered Chain Leggings|Neutral
Blacksmithing|175|60|Justicar's Gauntlet|Friendly
Blacksmithing|210|60|Justicar's Pauldrons|Friendly
Blacksmithing|225|90|Justicar's Wristguards|Honored
Blacksmithing|240|90|Justicar's Sabatons|Honored
Blacksmithing|250|90|Justicar's Waistguard|Honored
Blacksmithing|175|60|Officer's Gauntlet|Friendly
Blacksmithing|210|60|Officer's Pauldrons|Friendly
Blacksmithing|225|90|Officer's Wristguards|Honored
Blacksmithing|240|90|Officer's Sabatons|Honored
Blacksmithing|250|90|Officer's Waistguard|Honored
Blacksmithing|175|60|Prefect's Gauntlet|Friendly
Blacksmithing|210|60|Prefect's Pauldrons|Friendly
Blacksmithing|225|90|Prefect's Wristguards|Honored
Blacksmithing|240|90|Prefect's Sabatons|Honored
Blacksmithing|250|90|Prefect's Waistguard|Honored
Blacksmithing|175|60|Sentinel's Gauntlet|Friendly
Blacksmithing|210|60|Sentinel's Pauldrons|Friendly
Blacksmithing|225|90|Sentinel's Wristguards|Honored
Blacksmithing|240|90|Sentinel's Sabatons|Honored
Blacksmithing|250|90|Sentinel's Waistguard|Honored
Blacksmithing|175|60|Warder's Gauntlet|Friendly
Blacksmithing|210|60|Warder's Pauldrons|Friendly
Blacksmithing|225|90|Warder's Wristguards|Honored
Blacksmithing|240|90|Warder's Sabatons|Honored
Blacksmithing|250|90|Warder's Waistguard|Honored
Blacksmithing|250|90|Thorium Cestus|Honored
Blacksmithing|250|90|Thorium Greatmace|Honored
Blacksmithing|300|120|Enriched Thorium Breastplate|Honored
Blacksmithing|300|120|Enriched Thorium Helm|Honored
Blacksmithing|300|120|Enriched Thorium Leggings|Honored
Blacksmithing|300|120|Legionite Glaive|Honored
Blacksmithing|300|1000|Blacksmithing Certification|Neutral
Leatherworking|60|30|Brawler's Leather Belt|Neutral
Leatherworking|75|30|Brawler's Leather Gloves|Neutral
Leatherworking|85|30|Brawler's Leather Boots|Neutral
Leatherworking|100|30|Brawler's Leather Hood|Neutral
Leatherworking|110|30|Brawler's Leather Tunic|Neutral
Leatherworking|125|30|Brawler's Leather Legguards|Neutral
Leatherworking|60|30|Defender's Leather Belt|Neutral
Leatherworking|75|30|Defender's Leather Gloves|Neutral
Leatherworking|85|30|Defender's Leather Boots|Neutral
Leatherworking|100|30|Defender's Leather Hood|Neutral
Leatherworking|110|30|Defender's Leather Tunic|Neutral
Leatherworking|125|30|Defender's Leather Kilt|Neutral
Leatherworking|60|30|Stormrider's Leather Belt|Neutral
Leatherworking|75|30|Stormrider's Leather Gloves|Neutral
Leatherworking|85|30|Stormrider's Leather Boots|Neutral
Leatherworking|100|30|Stormrider's Leather Hood|Neutral
Leatherworking|110|30|Stormrider's Leather Tunic|Neutral
Leatherworking|125|30|Stormrider's Leather Kilt|Neutral
Leatherworking|60|30|Totemic's Leather Belt|Neutral
Leatherworking|75|30|Totemic's Leather Gloves|Neutral
Leatherworking|85|30|Totemic's Leather Boots|Neutral
Leatherworking|100|30|Totemic's Leather Hood|Neutral
Leatherworking|110|30|Totemic's Leather Tunic|Neutral
Leatherworking|125|30|Totemic's Leather Leggings|Neutral
Leatherworking|60|30|Trapper's Leather Belt|Neutral
Leatherworking|75|30|Trapper's Leather Gloves|Neutral
Leatherworking|85|30|Trapper's Leather Boots|Neutral
Leatherworking|100|30|Trapper's Leather Hood|Neutral
Leatherworking|110|30|Trapper's Leather Tunic|Neutral
Leatherworking|125|30|Trapper's Leather Legguards|Neutral
Leatherworking|60|30|Wisdom's Leather Belt|Neutral
Leatherworking|75|30|Wisdom's Leather Gloves|Neutral
Leatherworking|85|30|Wisdom's Leather Boots|Neutral
Leatherworking|100|30|Wisdom's Leather Hood|Neutral
Leatherworking|110|30|Wisdom's Leather Tunic|Neutral
Leatherworking|125|30|Wisdom's Leather Leggings|Neutral
Leatherworking|175|60|Mender's Leather Gloves|Friendly
Leatherworking|175|60|Prowler's Leather Gloves|Friendly
Leatherworking|175|60|Skirmisher's Leather Gloves|Friendly
Leatherworking|175|60|Skulker's Leather Gloves|Friendly
Leatherworking|175|60|Skycaller's Leather Gloves|Friendly
Leatherworking|175|60|Stalker's Leather Gloves|Friendly
Leatherworking|175|60|Warden's Leather Gloves|Friendly
Leatherworking|185|60|Forceful Thick Armor Kit|Friendly
Leatherworking|210|60|Mender's Leather Shoulders|Friendly
Leatherworking|210|60|Mender's Mail Shoulders|Friendly
Leatherworking|210|60|Prowler's Leather Shoulders|Friendly
Leatherworking|210|60|Skirmisher's Mail Shoulders|Friendly
Leatherworking|210|60|Skulker's Leather Shoulders|Friendly
Leatherworking|210|60|Skycaller's Leather Shoulders|Friendly
Leatherworking|210|60|Skycaller's Mail Shoulders|Friendly
Leatherworking|210|60|Stalker's Mail Shoulders|Friendly
Leatherworking|210|60|Warden's Leather Shoulders|Friendly
Leatherworking|225|90|Mender's Leather Bracers|Honored
Leatherworking|225|90|Mender's Mail Bracers|Honored
Leatherworking|225|90|Prowler's Leather Bracers|Honored
Leatherworking|225|90|Skirmisher's Mail Bracers|Honored
Leatherworking|225|90|Skulker's Leather Bracers|Honored
Leatherworking|225|90|Skycaller's Leather Bracers|Honored
Leatherworking|225|90|Skycaller's Mail Bracers|Honored
Leatherworking|225|90|Stalker's Mail Bracers|Honored
Leatherworking|225|90|Warden's Leather Bracers|Honored
Leatherworking|235|90|Mender's Leather Boots|Honored
Leatherworking|235|90|Mender's Mail Sabatons|Honored
Leatherworking|235|90|Prowler's Leather Boots|Honored
Leatherworking|235|90|Skirmisher's Mail Sabatons|Honored
Leatherworking|235|90|Skulker's Leather Boots|Honored
Leatherworking|235|90|Skycaller's Leather Boots|Honored
Leatherworking|235|90|Skycaller's Mail Sabatons|Honored
Leatherworking|235|90|Stalker's Mail Sabatons|Honored
Leatherworking|235|90|Warden's Leather Boots|Honored
Leatherworking|235|90|Mystic Rugged Armor Kit|Honored
Leatherworking|250|90|Mender's Leather Waistguard|Honored
Leatherworking|250|90|Mender's Mail Belt|Honored
Leatherworking|250|90|Prowler's Leather Waistguard|Honored
Leatherworking|250|90|Skirmisher's Mail Belt|Honored
Leatherworking|250|90|Skulker's Leather Waistguard|Honored
Leatherworking|250|90|Skycaller's Leather Waistguard|Honored
Leatherworking|250|90|Skycaller's Mail Belt|Honored
Leatherworking|250|90|Stalker's Mail Belt|Honored
Leatherworking|250|90|Warden's Leather Waistguard|Honored
Leatherworking|300|1000|Leatherworking Certification|Neutral
Tailoring|60|30|Flame Boots|Neutral
Tailoring|75|30|Flame Gloves|Neutral
Tailoring|85|30|Flame Sash|Neutral
Tailoring|100|30|Flame Circlet|Neutral
Tailoring|110|30|Flame Gown|Neutral
Tailoring|125|30|Flame Leggings|Neutral
Tailoring|60|30|Pearly Boots|Neutral
Tailoring|75|30|Pearly Gloves|Neutral
Tailoring|85|30|Pearly Sash|Neutral
Tailoring|100|30|Pearly Circlet|Neutral
Tailoring|110|30|Pearly Gown|Neutral
Tailoring|125|30|Pearly Leggings|Neutral
Tailoring|60|30|Pristine Boots|Neutral
Tailoring|75|30|Pristine Gloves|Neutral
Tailoring|85|30|Pristine Sash|Neutral
Tailoring|100|30|Pristine Circlet|Neutral
Tailoring|110|30|Pristine Gown|Neutral
Tailoring|125|30|Pristine Leggings|Neutral
Tailoring|60|30|Shadow Boots|Neutral
Tailoring|75|30|Shadow Gloves|Neutral
Tailoring|85|30|Shadow Sash|Neutral
Tailoring|100|30|Shadow Circlet|Neutral
Tailoring|110|30|Shadow Gown|Neutral
Tailoring|125|30|Shadow Leggings|Neutral
Tailoring|60|30|Shining Boots|Neutral
Tailoring|75|30|Shining Gloves|Neutral
Tailoring|85|30|Shining Sash|Neutral
Tailoring|100|30|Shining Circlet|Neutral
Tailoring|110|30|Shining Gown|Neutral
Tailoring|125|30|Shining Leggings|Neutral
Tailoring|60|30|Silky Boots|Neutral
Tailoring|75|30|Silky Gloves|Neutral
Tailoring|85|30|Silky Sash|Neutral
Tailoring|100|30|Silky Circlet|Neutral
Tailoring|110|30|Silky Gown|Neutral
Tailoring|125|30|Silky Leggings|Neutral
Tailoring|165|60|Black Handwraps|Friendly
Tailoring|165|60|Fiery Handwraps|Friendly
Tailoring|165|60|Frothing Handwraps|Friendly
Tailoring|165|60|Golden Handwraps|Friendly
Tailoring|165|60|Radiant Handwraps|Friendly
Tailoring|190|60|Mageweave Reagent Bag|Friendly
Tailoring|195|60|Netherflame Shoulders|Friendly
Tailoring|205|60|Netherflame Cuffs|Friendly
Tailoring|195|60|Netherfroth Shoulders|Friendly
Tailoring|205|60|Netherfroth Cuffs|Friendly
Tailoring|195|60|Nethergeld Shoulders|Friendly
Tailoring|205|60|Nethergeld Cuffs|Friendly
Tailoring|195|60|Netherlight Shoulders|Friendly
Tailoring|205|60|Netherlight Cuffs|Friendly
Tailoring|195|60|Netherpearl Shoulders|Friendly
Tailoring|205|60|Netherpearl Cuffs|Friendly
Tailoring|195|60|Nethershine Shoulders|Friendly
Tailoring|205|60|Nethershine Cuffs|Friendly
Tailoring|215|60|Black Waistcord|Friendly
Tailoring|215|60|Fiery Waistcord|Friendly
Tailoring|215|60|Frothing Waistcord|Friendly
Tailoring|215|60|Gilded Waistcord|Friendly
Tailoring|215|60|Golden Waistcord|Friendly
Tailoring|215|60|Radiant Waistcord|Friendly
Tailoring|215|60|Runecloth Reagent Bag|Friendly
Tailoring|235|90|Black Sandals|Honored
Tailoring|235|90|Fiery Sandals|Honored
Tailoring|235|90|Frothing Sandals|Honored
Tailoring|235|90|Gilded Sandals|Honored
Tailoring|235|90|Golden Sandals|Honored
Tailoring|235|90|Radiant Sandals|Honored
Tailoring|300|1000|Tailoring Certification|Neutral
Engineering|25|45|SAF-T Dynamite|Neutral
Engineering|25|45|SAF-T Tabs|Neutral
Engineering|55|45|SAF-T Copper Bomb|Neutral
Engineering|85|45|Satchel of Copper Bombs|Neutral
Engineering|100|45|EZ-Thro Wrap|Neutral
Engineering|130|45|EZ-Thro Copper Bomb XL|Neutral
Engineering|145|45|No Slip SAF-T Padding|Neutral
Engineering|165|180|Satchel of Bronze Bombs|Friendly
Engineering|175|180|Clanking Cord|Friendly
Engineering|175|180|Gizmo Girdle|Friendly
Engineering|175|180|SAF-T Bell|Friendly
Engineering|175|180|Whimsical Waistwrap|Friendly
Engineering|190|180|EZ-Thro Fireproof Fuse|Friendly
Engineering|200|180|Bent Goggles|Friendly
Engineering|200|180|Dented Goggles|Friendly
Engineering|200|180|Floppy Goggles|Friendly
Engineering|200|180|Stuckbutton Goggles|Friendly
Engineering|225|270|Compact Critter Carrier|Honored
Engineering|225|270|Emergency Field Cloak|Honored
Engineering|230|270|Satchel of Iron Bombs|Honored
Engineering|250|270|Gnomish Army Knife|Honored
Engineering|250|270|SAF-T Disposable Parachute|Honored
Engineering|275|270|Loot-A-Rang|Honored
Engineering|285|270|Satchel of Dark Iron Bombs|Honored
Engineering|300|360|Gnomish Poultryizer|Honored
Engineering|300|360|Stealthman 52|Honored
Engineering|300|360|Ultralight Goblin Glider|Honored
Engineering|300|360|Ultrasafe Rechargeable Battery|Honored
Engineering|300|1000|Engineering Certification|Neutral
Cooking|25|30|Venomous Smoothie|Neutral
Cooking|100|30|Slimy Smoothie|Neutral
Cooking|125|30|Mrrggl Smrrthle|Neutral
Cooking|180|60|Calcified Smoothie|Friendly
Cooking|200|60|Spicy Smoothie|Friendly
Cooking|250|90|Wicked Smoothie|Honored]=]
  for line in raw:gmatch('[^\n]+') do
    local p,skill,favor,name,rep=line:match('^([^|]+)|(%d+)|(%d+)|([^|]+)|(%a+)$')
    if p then
      local cert=name:find(' Certification',1,true)~=nil
      SHOP[#SHOP+1]={vendor=p,name=name,rep=rep,skill=tonumber(skill),favor=tonumber(favor),
        itemName=(cert and name or (prefixes[p] or '')..name)}
    end
  end
  SHOP[#SHOP+1]={vendor='Special Rewards',name='Packmule Treat',rep='Revered',favor=1500,
    note='Companion pet: Minimule',npcAlliance='Tamelyn Aldridge',npcHorde='Gishah'}
  SHOP[#SHOP+1]={vendor='Special Rewards',name='Advertising License Application',
    favor=1200,rep='Honored',note='Quest leading to a faction tradeskill signpost toy',
    npcAlliance='Tamelyn Aldridge',npcHorde='Gishah'}
  SHOP[#SHOP+1]={vendor='Special Rewards',name='Reins of the Pack Kodo',rep='Exalted',favor=6000,
    need='Level 60 + Journeyman Riding',note='Pack Kodo mount',
    npcAlliance='Huey Sunnydale',npcHorde='Okamache'}
  SHOP[#SHOP+1]={vendor='Special Rewards',name='Trade Faction Tabard',favor=200,
    rep='Exalted',note='Costs an additional 5 gold; Alliance and Horde tabards differ',
    npcAlliance='Tamelyn Aldridge',npcHorde='Gishah'}

  rows.merchantShopCatalog=SHOP
  local function factionInfo()
    if UnitFactionGroup then
      local ok,result=pcall(UnitFactionGroup,'player')
      if ok and result=='Alliance' then return true end
    end
    return false
  end
  local function vendorName(row,alliance)
    if row.npcAlliance then return alliance and row.npcAlliance or row.npcHorde end
    for _,v in ipairs(trade) do
      if v[1]==row.vendor then return alliance and v[2] or v[4] end
    end
    return 'Trade camp vendor'
  end
  -- Only verified Forever item IDs belong here. The rest of the catalog
  -- can still show its reference text; a guessed ID must never show the stats
  -- of an unrelated item. IDs sourced from the game's item references.
  local knownShopIDs={
    -- v3.4.1: Verified WoW Forever Alchemy vendor RECIPE IDs (28).
    ['Elixir of Lesser Spirit']=250381,
    ['Lesser Mageblood Elixir']=250376,
    ['Elixir of Lesser Intellect']=250388,
    ['Lesser Cleric\'s Elixir']=250367,
    ['Lesser Arcane Elixir']=250378,
    ['Mender\'s Potion']=250990,
    ['Spellblasting Potion']=250978,
    ['Frenzy Potion']=250984,
    ['Elixir of Greater Spirit']=250383,
    ['Greater Mageblood Elixir']=250377,
    ['Greater Cleric\'s Elixir']=250369,
    ['Elixir of Greater Fortitude']=250371,
    ['Dragonfire Potion']=250997,
    ['Elixir of the Phalanx']=250365,
    ['Caustic Smog Potion']=250995,
    ['Elixir of Cunning']=250364,
    ['Elixir of Ferocity']=250386,
    ['Elixir of Sages']=250374,
    ['Elixir of the Whale']=250384,
    ['Potion of Venomous Blood']=250994,
    ['Elixir of the Owl']=250373,
    ['Major Mender\'s Potion']=250993,
    ['Potion of Elemental Purging']=250998,
    ['Elixir of Nature Power']=250379,
    ['Elixir of Wicked Regeneration']=250372,
    ['Major Spellblasting Potion']=250981,
    ['Major Frenzy Potion']=250987,
    ['Elixir of the Grizzly']=250387,
    ['Alchemy Certification']=271621,['Tailoring Certification']=271627,
    ['Leatherworking Certification']=271626,
    ['Packmule Treat']=284664,['Reins of the Pack Kodo']=262766,
    ['Azeroth Commerce Authority Tabard']=262765,
    ['Mystic Mushroom']=249476,['Glimmering Staff']=249482,
    ["Crusader's Silvered Chain Helm"]=251384,
    ["Crusader's Chain Belt"]=251369,
    ["Protector's Chain Belt"]=251367,
    ['Pristine Circlet']=253950,['Pristine Sash']=253926,
    ['Pristine Gloves']=253914,['Shadow Circlet']=253956,
    ['Silky Circlet']=253952,['Flame Boots']=253894,
    ['Venomous Smoothie']=249885,['Slimy Smoothie']=249886,
    ['Mrrggl Smrrthle']=249887,['Calcified Smoothie']=249888,
    ['Spicy Smoothie']=249889,['Wicked Smoothie']=249890,
    ['Loot-A-Rang']=264222,['SAF-T Disposable Parachute']=264220,
    ["Brawler's Leather Belt"]=252765,
    ["Brawler's Leather Gloves"]=252777,
    ["Brawler's Leather Hood"]=252798,
  }
  local knownCraftedIDs={
    -- v3.4.1: Corresponding CRAFTED consumable IDs (28).
    ['Elixir of Lesser Spirit']=250345,
    ['Lesser Mageblood Elixir']=250340,
    ['Elixir of Lesser Intellect']=250353,
    ['Lesser Cleric\'s Elixir']=250331,
    ['Lesser Arcane Elixir']=250342,
    ['Mender\'s Potion']=250946,
    ['Spellblasting Potion']=250934,
    ['Frenzy Potion']=250940,
    ['Elixir of Greater Spirit']=250347,
    ['Greater Mageblood Elixir']=250341,
    ['Greater Cleric\'s Elixir']=250333,
    ['Elixir of Greater Fortitude']=250335,
    ['Dragonfire Potion']=250953,
    ['Elixir of the Phalanx']=250329,
    ['Caustic Smog Potion']=250951,
    ['Elixir of Cunning']=250328,
    ['Elixir of Ferocity']=250350,
    ['Elixir of Sages']=250338,
    ['Elixir of the Whale']=250348,
    ['Potion of Venomous Blood']=250950,
    ['Elixir of the Owl']=250337,
    ['Major Mender\'s Potion']=250949,
    ['Potion of Elemental Purging']=250954,
    ['Elixir of Nature Power']=250343,
    ['Elixir of Wicked Regeneration']=250336,
    ['Major Spellblasting Potion']=250937,
    ['Major Frenzy Potion']=250943,
    ['Elixir of the Grizzly']=250351,
    ['Mystic Mushroom']=249396,['Polished Driftwood Icon']=249398,
    ['Tenets of the Silver Hand']=249397,['Glimmering Staff']=249392,
    ["Crusader's Silvered Chain Helm"]=250532,
    ['Pristine Circlet']=253949,['Pristine Sash']=253925,
    ['Shadow Circlet']=253955,['Silky Circlet']=253951,
    ['Silky Gloves']=253915,
    ['Venomous Smoothie']=249871,['Slimy Smoothie']=249872,
    ['Mrrggl Smrrthle']=249873,
  }
  rows.merchantShopScanner=(function()
  -- Only trust IDs observed in the game at a recognized Merchant's Favor
  -- merchant and matched to the catalog by exact normalized item name.
  -- Persist in the existing per-character DB; never overwrite built-in IDs.
  local function shopScanKey(entry)
    return tostring(entry.vendor)..'|'..tostring(entry.name)
  end
  local function scannedShopID(entry)
    local store=DB and DB.merchantShopScannedItems
    local saved=store and store[shopScanKey(entry)]
    local id=saved and tonumber(saved.itemID)
    if id and id>0 then return id end
  end
  local function scanName(value)
    return trim(tostring(value or '')):lower():gsub('’',"'")
      :gsub('[`]',"'"):gsub('%s+',' ')
  end
  local function scanCategory(npc)
    npc=scanName(npc)
    if npc=='' then return nil end
    for _,info in ipairs(trade) do
      if info[1]~='Special Rewards' and
         (scanName(info[2])==npc or scanName(info[4])==npc) then
        return info[1]
      end
    end
    local extras={'Tamelyn Aldridge','Huey Sunnydale','Gishah','Okamache'}
    for _,name in ipairs(extras) do
      if scanName(name)==npc then return 'Special Rewards' end
    end
  end
  local function merchantSlotCount()
    if type(GetMerchantNumItems)=='function' then
      local ok,n=pcall(GetMerchantNumItems)
      if ok and tonumber(n) then return math.max(0,tonumber(n)) end
    end
    if C_MerchantFrame and type(C_MerchantFrame.GetNumItems)=='function' then
      local ok,n=pcall(C_MerchantFrame.GetNumItems)
      if ok and tonumber(n) then return math.max(0,tonumber(n)) end
    end
    return 0
  end
  local function merchantSlotItem(index)
    local info
    if C_MerchantFrame and type(C_MerchantFrame.GetItemInfo)=='function' then
      local ok,data=pcall(C_MerchantFrame.GetItemInfo,index)
      if ok and type(data)=='table' then info=data end
    end
    local name=info and info.name
    local id=info and tonumber(info.itemID or info.itemId)
    if id and id<=0 then id=nil end
    local link
    if C_MerchantFrame and type(C_MerchantFrame.GetItemLink)=='function' then
      local ok,result=pcall(C_MerchantFrame.GetItemLink,index)
      if ok and type(result)=='string' then link=result end
    end
    if not link and type(GetMerchantItemLink)=='function' then
      local ok,result=pcall(GetMerchantItemLink,index)
      if ok and type(result)=='string' then link=result end
    end
    if not id and C_MerchantFrame and type(C_MerchantFrame.GetItemID)=='function' then
      local ok,result=pcall(C_MerchantFrame.GetItemID,index)
      if ok then id=tonumber(result) end
    end
    if not id and type(GetMerchantItemID)=='function' then
      local ok,result=pcall(GetMerchantItemID,index)
      if ok then id=tonumber(result) end
    end
    if id and id<=0 then id=nil end
    if not id and link then id=idFromLink(link) end
    if not name and type(GetMerchantItemInfo)=='function' then
      -- Older Classic exposes the legacy function, but Forever can throw
      -- when invoking it: always guard the fallback with pcall.
      local ok,result=pcall(GetMerchantItemInfo,index)
      if ok and type(result)=='string' then name=result end
    end
    if not name and link then name=link:match('|h%[([^%]]+)%]|h') end
    if not name and id then name=getName(id) end
    return id,name
  end
  local function scannedCount(category)
    local found,total=0,0
    for _,entry in ipairs(SHOP) do
      if category=='All Traders' or category==entry.vendor then
        total=total+1
        if scannedShopID(entry) then found=found+1 end
      end
    end
    return found,total
  end
  local function scanCurrentTrader(report)
    if not DB then return false end
    if MerchantFrame and MerchantFrame.IsShown and not MerchantFrame:IsShown() then
      if report then say('Open a Merchant\'s Favor trader first, then click Scan Open Trader.') end
      return false
    end
    local npc=type(UnitName)=='function' and UnitName('npc') or nil
    local category=scanCategory(npc)
    if not category then
      if report then say('Scan Open Trader: no recognized Merchant\'s Favor vendor is open.') end
      return false
    end
    local count=merchantSlotCount()
    if count==0 then
      if report then say('Trader inventory is not ready; try Scan Open Trader after it loads.') end
      return false
    end
    -- No fuzzy matches: a vendor's existing item must match its profession's
    -- catalog name (or recipe-scroll name). Ambiguous labels are ignored.
    local catalog={}
    for _,entry in ipairs(SHOP) do
      if entry.vendor==category then
        local full=entry.itemName or entry.name
        if entry.name=='Trade Faction Tabard' then
          full=(factionInfo() and 'Azeroth Commerce Authority Tabard' or
            'Durotar Supply and Logistics Tabard')
        end
        for _,word in ipairs({full,entry.name}) do
          local key=scanName(word)
          if key~='' then
            if catalog[key] and catalog[key]~=entry then
              catalog[key]=false
            elseif catalog[key]==nil then
              catalog[key]=entry
            end
          end
        end
      end
    end
    local newCount,matched,availableID,changed=0,0,0,0
    for index=1,math.min(count,400) do
      local itemID,name=merchantSlotItem(index)
      local entry=name and catalog[scanName(name)]
      if entry then
        matched=matched+1
        if itemID and itemID>0 then
          availableID=availableID+1
          local key=shopScanKey(entry)
          local prior=DB.merchantShopScannedItems and DB.merchantShopScannedItems[key]
          if not prior or tonumber(prior.itemID)~=itemID then
            DB.merchantShopScannedItems=DB.merchantShopScannedItems or {}
            DB.merchantShopScannedItems[key]={itemID=itemID,
              npc=npc,seen=(type(time)=='function' and time() or nil)}
            changed=changed+1
            if not prior then newCount=newCount+1 end
            if C_Item and type(C_Item.RequestLoadItemDataByID)=='function' then
              pcall(C_Item.RequestLoadItemDataByID,itemID)
            end
          end
        end
      end
    end
    if changed>0 then
      debugMessage('Merchant Favor scanner: '..tostring(npc)..' ('..category..') '..
        changed..' verified item ID update(s)')
      if rows.refreshMerchantShop then rows.refreshMerchantShop() end
    end
    if report or changed>0 then
      local n,total=scannedCount(category)
      say('Trader scan: '..tostring(npc)..' | '..availableID..' identified in this view | '..
        newCount..' newly saved | '..n..'/'..total..' catalog entries learned ('..category..').')
      if report and matched>availableID then
        say('Some matched items had no readable item ID. Try again after the vendor loads.')
      end
      if report and matched==0 then
        say('No exact catalog matches in this vendor view. Remove vendor filters and retry.')
      end
    end
    return true
  end
  -- Scans happen locally when the actual vendor opens or updates. Do not
  -- attempt remote queries, inspect unrelated merchants, or purchase items.
  rows.scanMerchantFavorTrader=scanCurrentTrader
  local scanner=CreateFrame('Frame')
  scanner:RegisterEvent('MERCHANT_SHOW')
  scanner:RegisterEvent('MERCHANT_UPDATE')
  scanner:SetScript('OnEvent',function(_,event)
    if not DB then return end
    scanCurrentTrader(false)
    if event=='MERCHANT_SHOW' and C_Timer and type(C_Timer.After)=='function' then
      C_Timer.After(.5,function()
        if MerchantFrame and MerchantFrame.IsShown and MerchantFrame:IsShown() then
          scanCurrentTrader(false)
        end
      end)
    end
  end)
  return {id=scannedShopID,count=scannedCount,scan=scanCurrentTrader}
  end)()
  local function shopName(entry)
    if entry.name=='Trade Faction Tabard' then
      return factionInfo() and 'Azeroth Commerce Authority Tabard' or
        'Durotar Supply and Logistics Tabard'
    end
    return entry.name
  end
  local function resolvedItemLink(name)
    if not name then return nil end
    local api=(C_Item and C_Item.GetItemInfo) or GetItemInfo
    if type(api)~='function' then return nil end
    local ok,_,link=pcall(api,name)
    if ok and type(link)=='string' and link:find('|Hitem:',1,true) then return link end
    return nil
  end
  local function shopTarget(entry,mode)
    local actual=shopName(entry)
    local special=entry.vendor=='Special Rewards' or
      (entry.name and entry.name:find(' Certification',1,true))
    -- Certifications and other direct goods have no separate crafted output.
    if mode=='recipe' or special then
      local id=rows.merchantShopScanner.id(entry) or knownShopIDs[actual] or knownShopIDs[entry.name]
      local name=entry.itemName or actual
      return id,name, 'Vendor item'
    end
    return knownCraftedIDs[actual] or knownCraftedIDs[entry.name],actual,'Crafted item'
  end
  local function shopItemLink(entry,mode)
    local id,name,kind=shopTarget(entry,mode)
    if id then
      local loaded=resolvedItemLink(id)
      -- Request an uncached known item from the server; it may arrive later.
      if not loaded and C_Item and type(C_Item.RequestLoadItemDataByID)=='function' then
        pcall(C_Item.RequestLoadItemDataByID,id)
      end
      return loaded,id,kind,name
    end
    -- A globally cached item can still be shown even without a verified ID.
    -- For vendor recipes use their full teaching-item name, not the product.
    return resolvedItemLink(name),nil,kind,name
  end
  -- Reputation thresholds are cumulative from the start of Neutral.
  local reputationThreshold={Neutral=0,Friendly=3000,Honored=9000,Revered=21000,Exalted=42000}
  local function traderRepProgress(rank)
    local factionID=factionInfo() and 2586 or 2587
    local value
    if C_Reputation and C_Reputation.GetFactionDataByID then
      local ok,data=pcall(C_Reputation.GetFactionDataByID,factionID)
      if ok and data then value=data.currentStanding end
    end
    if type(value)~='number' and GetFactionInfoByID then
      local ok,name,_,_,_,_,standing=pcall(GetFactionInfoByID,factionID)
      if ok and name then value=standing end
    end
    local target=reputationThreshold[rank]
    if type(value)=='number' then
      if value>=target then return rank..' (met)' end
      return rank..' ('..(target-value)..' rep to go)'
    end
    return rank..' ('..target..' total rep from Neutral)'
  end
  local function showShopTooltip(frame,entry,mode)
    if not GameTooltip or not entry then return end
    mode=mode or 'crafted'
    GameTooltip:SetOwner(frame,'ANCHOR_RIGHT')
    local link,id,kind,name=shopItemLink(entry,mode)
    local native=false
    if link and type(GameTooltip.SetHyperlink)=='function' then
      native=pcall(GameTooltip.SetHyperlink,GameTooltip,link)
    end
    -- An item ID is useful without first visiting a merchant: request its
    -- game-owned tooltip even if its full linked name is still loading.
    if not native and id and type(GameTooltip.SetHyperlink)=='function' then
      native=pcall(GameTooltip.SetHyperlink,GameTooltip,'item:'..id)
    end
    if not native then
      GameTooltip:ClearLines()
      GameTooltip:AddLine(name or entry.name,1,.84,.46)
      if id then
        GameTooltip:AddLine('Loading WoW item information...',.75,.82,.98,true)
      else
        GameTooltip:AddLine('Native '..kind:lower()..' tooltip not available: item ID is not verified or cached.',
          .75,.82,.98,true)
      end
    end
    GameTooltip:AddLine(' ',1,1,1)
    GameTooltip:AddLine(kind..' preview  |  '..entry.favor.." Merchant's Favor",1,.84,.43)
    if entry.skill and entry.skill>0 then
      GameTooltip:AddLine(entry.vendor..' skill to learn: '..entry.skill,.87,.87,.83)
    end
    GameTooltip:AddLine('Reputation: '..traderRepProgress(entry.rep),.85,.87,1,true)
    if entry.need then GameTooltip:AddLine('Requires: '..entry.need,1,.67,.46) end
    if entry.note then GameTooltip:AddLine(entry.note,.78,.83,.91,true) end
    GameTooltip:AddLine('Sold by: '..vendorName(entry,factionInfo()),.65,.89,.67)
    if entry.vendor~='Special Rewards' then
      GameTooltip:AddLine('Toggle Crafted / Recipe above the list; Shift-hover shows the other.',
        .70,.78,.91,true)
    end
    GameTooltip:AddLine('Favor prices are reference data; confirm stock in game.',.67,.67,.67,true)
    GameTooltip:Show()
  end
  rows.toggleMerchantShop=function()
    if DB and DB.experimentalTabbedUI and rows.experimentalTabs and not rows.experimentalTabs.switching then
      rows.experimentalTabs.open('Traders');return
    end
    if not rows.merchantShopFrame then
      local f=CreateFrame('Frame','WritThisMerchantShopFrame',UIParent,
        BackdropTemplateMixin and 'BackdropTemplate')
      f:SetSize(930,640);f:SetMovable(true);f:SetClampedToScreen(true)
      f:SetFrameStrata('DIALOG');f:EnableMouse(true)
      position(f,'merchantShopPos',10,0);skinFrame(f)
      makeDraggable(f,'merchantShopPos')
      local heading=textLine(f,'MERCHANT\'S FAVOR  |  TRADERS',650,true)
      heading:SetPoint('TOPLEFT',19,-17);heading:SetTextColor(1,.83,.45)
      local sub=textLine(f,'316 distinct recipes & certifications  |  4 special rewards  |  Reference only',825)
      sub:SetPoint('TOPLEFT',20,-47);sub:SetTextColor(.76,.79,.75)
      createButton(f,'X',26,25,function()rows.navigation.close(f)end):SetPoint('TOPRIGHT',-14,-13)
      local alliance=factionInfo()
      local location=textLine(f,'',870)
      location:SetPoint('TOPLEFT',21,-79);location:SetTextColor(.67,.86,1)
      local vendorDetail=textLine(f,'',650)
      vendorDetail:SetPoint('TOPLEFT',21,-103);vendorDetail:SetTextColor(.93,.86,.70)
      local scanButton=createButton(f,'Scan Open Trader',159,25,function()
        rows.merchantShopScanner.scan(true)
      end)
      scanButton:SetPoint('TOPRIGHT',-23,-70)
      local scanStatus=textLine(f,'',235)
      scanStatus:SetPoint('TOPRIGHT',-23,-105)
      scanStatus:SetJustifyH('RIGHT')
      scanStatus:SetTextColor(.65,.82,.75)
      local selected='Alchemy'
      local query=''
      local page=1
      local perPage=12
      -- Vendor scans discover recipe scrolls, not crafted product IDs. Default
      -- to Vendor Recipe so a new scan has an immediately visible result.
      local previewMode='recipe'
      local vendorButtons={}
      local listRows={}
      local results={}
      local update
      local categories={'All Traders','Alchemy','Blacksmithing','Cooking','Enchanting',
        'Engineering','Leatherworking','Tailoring','Special Rewards'}
      local function vendorSummary(cat)
        if cat=='All Traders' then return 'All seven profession traders and special rewards' end
        for _,v in ipairs(trade) do
          if v[1]==cat then
            return (alliance and v[2] or v[4])..'  |  '..
              (alliance and v[3] or v[5])
          end
        end
        return ''
      end
      local function selectCategory(cat)
        selected=cat;page=1
        if update then update() end
      end
      for i,cat in ipairs(categories) do
        local b=createButton(f,cat,174,31,function()selectCategory(cat)end)
        b:SetPoint('TOPLEFT',19,-(144+(i-1)*37))
        vendorButtons[i]=b
      end
      local sh=textLine(f,'Find:',44)
      sh:SetPoint('TOPLEFT',213,-151)
      local search=CreateFrame('EditBox',nil,f,'InputBoxTemplate')
      search:SetSize(280,24);search:SetPoint('LEFT',sh,'RIGHT',8,0)
      search:SetAutoFocus(false);search:SetMaxLetters(80)
      search:SetScript('OnEscapePressed',function(self)self:ClearFocus()end)
      search:SetScript('OnEnterPressed',function(self)self:ClearFocus()end)
      search:SetScript('OnTextChanged',function(self)
        query=(self:GetText() or ''):lower();page=1
        if update then update() end
      end)
      local labels=textLine(f,'ITEM / RECIPE',440,true)
      labels:SetPoint('TOPLEFT',220,-197)
      local previewButton=createButton(f,'Preview: Vendor Recipe',176,27,function()
        previewMode=previewMode=='crafted' and 'recipe' or 'crafted'
        if update then update() end
      end)
      previewButton:SetPoint('TOPRIGHT',-24,-142)
      local previewHelp=textLine(f,'Hover for native WoW item tooltips',350)
      previewHelp:SetPoint('TOPLEFT',220,-178)
      previewHelp:SetTextColor(.67,.75,.82)
      local repHeading=textLine(f,'REP',94,true)
      repHeading:SetPoint('TOPLEFT',617,-197)
      local skillHeading=textLine(f,'SKILL',70,true)
      skillHeading:SetPoint('TOPLEFT',733,-197)
      local favorHeading=textLine(f,'FAVOR',72,true)
      favorHeading:SetPoint('TOPLEFT',819,-197)
      local lineLabel=''
      for i=1,perPage do
        local y=-(222+(i-1)*29)
        local hit=CreateFrame('Button',nil,f,BackdropTemplateMixin and 'BackdropTemplate')
        hit:SetSize(685,28);hit:SetPoint('TOPLEFT',212,y)
        skinFrame(hit)
        local itemIcon=hit:CreateTexture(nil,'ARTWORK')
        itemIcon:SetSize(19,19);itemIcon:SetPoint('LEFT',8,0)
        local name=textLine(hit,'',359)
        name:SetPoint('LEFT',32,0)
        if name.SetWordWrap then name:SetWordWrap(false) end
        local rep=textLine(hit,'',99)
        rep:SetPoint('LEFT',405,0)
        local skill=textLine(hit,'',70)
        skill:SetPoint('LEFT',518,0)
        local favor=textLine(hit,'',75)
        favor:SetPoint('LEFT',606,0)
        favor:SetJustifyH('RIGHT')
        hit:SetScript('OnEnter',function(self)
          if self.SetBackdropColor then self:SetBackdropColor(.19,.17,.12,.98) end
          if self.item then
            local mode=previewMode
            if type(IsShiftKeyDown)=='function' and IsShiftKeyDown() then
              mode=mode=='crafted' and 'recipe' or 'crafted'
            end
            self.previewingMode=mode
            showShopTooltip(self,self.item,mode)
          end
        end)
        hit:SetScript('OnLeave',function(self)
          self.previewingMode=nil
          if self.SetBackdropColor then self:SetBackdropColor(unpack(skin().button)) end
          if GameTooltip and GameTooltip:GetOwner()==self then GameTooltip:Hide() end
        end)
        hit:SetScript('OnClick',function(self)
          if self.item then
            vendorDetail:SetText(self.item.name..'  |  '..self.item.favor..' Favor  |  '..traderRepProgress(self.item.rep)..
              (self.item.skill and ('  |  '..self.item.skill..' skill') or '')..
              '  |  '..vendorName(self.item,alliance))
          end
        end)
        listRows[i]={hit=hit,name=name,rep=rep,skill=skill,favor=favor,icon=itemIcon}
      end
      local pageLabel=textLine(f,'',180)
      pageLabel:SetPoint('BOTTOMRIGHT',-120,18)
      pageLabel:SetJustifyH('RIGHT')
      pageLabel:SetTextColor(.80,.80,.75)
      createButton(f,'Previous',90,29,function()
        page=math.max(1,page-1);update()
      end):SetPoint('BOTTOMLEFT',218,13)
      createButton(f,'Next',75,29,function()
        page=math.min(math.max(1,math.ceil(#results/perPage)),page+1);update()
      end):SetPoint('BOTTOMLEFT',320,13)
      local footer=textLine(f,'Vendor scans saved per character.',245)
      footer:SetPoint('BOTTOMLEFT',414,20);footer:SetTextColor(.65,.71,.73)
      -- Refresh only the currently hovered row after the client receives an
      -- item requested by ID. Never steal tooltips belonging to other frames.
      f:RegisterEvent('GET_ITEM_INFO_RECEIVED')
      f:SetScript('OnEvent',function(_,event,itemID,success)
        if event~='GET_ITEM_INFO_RECEIVED' or success==false or not f:IsShown() then return end
        for _,row in ipairs(listRows) do
          if row.hit.item and row.hit.previewingMode and GameTooltip and
            GameTooltip:GetOwner()==row.hit then
            local id=shopTarget(row.hit.item,row.hit.previewingMode)
            if id and tonumber(id)==tonumber(itemID) then
              showShopTooltip(row.hit,row.hit.item,row.hit.previewingMode)
            end
          end
        end
        if update then update() end
      end)
      update=function()
        alliance=factionInfo()
        location:SetText(alliance and
          'Alliance | Azeroth Commerce Authority | Redridge Mountains (Three Corners)' or
          'Horde | Durotar Supply and Logistics | The Barrens (west of Crossroads)')
        vendorDetail:SetText(vendorSummary(selected))
        local verified,total=rows.merchantShopScanner.count(selected)
        scanStatus:SetText('Scanned IDs: '..verified..'/'..total)
        for i,cat in ipairs(categories) do
          vendorButtons[i].text:SetTextColor(cat==selected and 1 or .80,
            cat==selected and .84 or .83,cat==selected and .43 or .81)
        end
        results={}
        for _,item in ipairs(SHOP) do
          if (selected=='All Traders' or selected==item.vendor) and
            (query=='' or (item.name..' '..(item.itemName or '')..' '..item.vendor..
              ' '..vendorName(item,alliance)):lower():find(query,1,true)) then
            results[#results+1]=item
          end
        end
        labels:SetText('ITEM / RECIPE ('..#results..' items)')
        previewButton.text:SetText(previewMode=='crafted' and
          'Preview: Crafted Item' or 'Preview: Vendor Recipe')
        page=math.min(page,math.max(1,math.ceil(#results/perPage)))
        pageLabel:SetText('Page '..page..' / '..math.max(1,math.ceil(#results/perPage)))
        for i,row in ipairs(listRows) do
          local e=results[(page-1)*perPage+i]
          row.hit.item=e
          if e then
            row.name:SetText(shopName(e))
            row.rep:SetText(e.rep)
            row.skill:SetText(e.skill and tostring(e.skill) or '-')
            row.favor:SetText(tostring(e.favor))
            local id,name=shopTarget(e,previewMode)
            local iconID=id
            -- Load known icon IDs locally; never request a whole catalog at once.
            if not iconID and GetItemInfo then
              local link=resolvedItemLink(name)
              iconID=link and tonumber(link:match('item:(%d+)'))
            end
            local icon
            if iconID and C_Item and type(C_Item.GetItemIconByID)=='function' then
              local ok,value=pcall(C_Item.GetItemIconByID,iconID)
              if ok then icon=value end
            end
            if not icon and iconID and type(GetItemIcon)=='function' then
              local ok,value=pcall(GetItemIcon,iconID)
              if ok then icon=value end
            end
            row.icon:SetTexture(icon or 'Interface\\Icons\\INV_Misc_QuestionMark')
            row.icon:SetVertexColor(icon and 1 or .52,icon and 1 or .52,icon and 1 or .52)
            row.hit:Show()
          else
            row.hit:Hide()
          end
        end
      end
      rows.refreshMerchantShop=update
      f:SetScript('OnShow',update)
      f:Hide();rows.registerPopup(f);rows.merchantShopFrame=f
      update()
    end
    local f=rows.merchantShopFrame
    f:SetShown(not f:IsShown())
  end
end -- merchant reference scope


-- WoW Forever writ reputation reference plus live character standing.
-- Read actual Durotar Supply and Logistics data from the Forever reputation API;
-- never estimate progress from completed writs or overwrite SavedVariables.
-- The reference columns remain ALTERNATIVE ways to satisfy a bracket.
rows.toggleRepChart=function()
    if DB and DB.experimentalTabbedUI and rows.experimentalTabs and not rows.experimentalTabs.switching then
      rows.experimentalTabs.open('Rep');return
    end
  if not rows.repChartFrame then
    local frame=CreateFrame('Frame','WritThisRepChartFrame',UIParent,
      BackdropTemplateMixin and 'BackdropTemplate')
    -- Remember independent sizes for expanded and compact modes. All sizes are
    -- clamped for compatibility with the minimum bounds on WoW Forever.
    local chartVisible=DB.repChartShowTable~=false
    local minimumHeight=chartVisible and 530 or 245
    local savedHeight=chartVisible and (DB.repChartHeight or 550) or (DB.repCompactHeight or 255)
    frame:SetSize(math.min(1320,math.max(740,DB.repChartWidth or 982)),
      math.min(900,math.max(minimumHeight,savedHeight)))
    frame:SetFrameStrata('DIALOG');frame:SetMovable(true)
    frame:SetClampedToScreen(true);frame:EnableMouse(true)
    position(frame,'repChartPos',0,0)
    skinFrame(frame)
    local title=textLine(frame,'REPUTATION CHART',570,true)
    title:SetPoint('TOPLEFT',18,-17)
    title:SetTextColor(1,.83,.45)
    makeDraggable(frame,'repChartPos')
    createButton(frame,'X',25,24,function()rows.navigation.close(frame)end):SetPoint('TOPRIGHT',-13,-12)
    local note=textLine(frame,'Writs needed for each reputation bracket',895)
    note:SetPoint('TOPLEFT',19,-48);note:SetTextColor(.79,.77,.71)
    local showChart=CreateFrame('CheckButton',nil,frame,'UICheckButtonTemplate')
    showChart:SetSize(24,24)
    showChart:SetPoint('TOPRIGHT',-137,-43)
    showChart:SetChecked(chartVisible)
    local showChartText=textLine(frame,'Show Chart',106)
    showChartText:SetPoint('LEFT',showChart,'RIGHT',2,0)
    -- Clicking the label works too, not only the checkbox square.
    local showChartLabel=CreateFrame('Button',nil,frame)
    showChartLabel:SetPoint('TOPLEFT',showChart,'TOPRIGHT',0,0)
    showChartLabel:SetSize(112,24)
    showChartLabel:SetScript('OnClick',function()showChart:Click()end)

    -- Live reputation display. Faction 2587 is Durotar Supply and Logistics.
    -- The client reports actual standing thresholds; no saved user data is used.
    local liveBG=frame:CreateTexture(nil,'BACKGROUND')
    liveBG:SetColorTexture(.080,.085,.091,.94)
    liveBG:SetPoint('TOPLEFT',24,-79);liveBG:SetSize(932,127)
    local liveTitle=textLine(frame,'DUROTAR SUPPLY AND LOGISTICS',885,true)
    liveTitle:SetPoint('TOPLEFT',37,-87);liveTitle:SetTextColor(1,.85,.53)
    local liveStanding=textLine(frame,'Standing: Checking reputation...',900)
    liveStanding:SetPoint('TOPLEFT',37,-116)
    local liveRemaining=textLine(frame,'To next rank: --',900)
    liveRemaining:SetPoint('TOPLEFT',37,-138)
    local liveWrits=textLine(frame,'Writs needed: --',900)
    liveWrits:SetPoint('TOPLEFT',37,-159)
    liveWrits:SetTextColor(.63,.84,1)
    local progress=CreateFrame('StatusBar',nil,frame)
    progress:SetSize(904,9)
    progress:SetPoint('TOPLEFT',38,-186)
    progress:SetStatusBarTexture('Interface\\Buttons\\WHITE8X8')
    progress:SetStatusBarColor(.35,.72,.48,.97)
    progress:SetMinMaxValues(0,1);progress:SetValue(0)

    -- Modern Forever uses C_Reputation; older compatible clients may expose
    -- GetFactionInfoByID or GetFactionInfo. Match the named faction, not the
    -- user's watched faction, to prevent reporting a different reputation.
    local names={'Hated','Hostile','Unfriendly','Neutral','Friendly','Honored','Revered','Exalted'}
    local function isDurotar(name)
      return type(name)=='string' and name:lower():find('durotar supply',1,true)~=nil
    end
    local function unpackModern(data)
      if type(data)~='table' or not isDurotar(data.name) then return nil end
      return data.reaction,data.currentReactionThreshold,
        data.nextReactionThreshold,data.currentStanding
    end
    local function getFaction()
      if C_Reputation and type(C_Reputation.GetFactionDataByID)=='function' then
        local ok,data=pcall(C_Reputation.GetFactionDataByID,2587)
        if ok and data then
          local r,a,b,c=unpackModern(data)
          if r then return r,a,b,c end
        end
      end
      if type(GetFactionInfoByID)=='function' then
        local ok,name,_,standing,low,high,value=pcall(GetFactionInfoByID,2587)
        if ok and isDurotar(name) then return standing,low,high,value end
      end
      -- Fallback: look up a matching faction in the client's visible list.
      if C_Reputation and type(C_Reputation.GetNumFactions)=='function' and
        type(C_Reputation.GetFactionDataByIndex)=='function' then
        local ok,count=pcall(C_Reputation.GetNumFactions)
        if ok then
          for i=1,math.min(500,tonumber(count) or 0) do
            local got,data=pcall(C_Reputation.GetFactionDataByIndex,i)
            if got and data then
              local r,a,b,c=unpackModern(data)
              if r then return r,a,b,c end
            end
          end
        end
      end
      if type(GetNumFactions)=='function' and type(GetFactionInfo)=='function' then
        local ok,count=pcall(GetNumFactions)
        if ok then
          for i=1,math.min(500,tonumber(count) or 0) do
            local got,name,_,standing,low,high,value=pcall(GetFactionInfo,i)
            if got and isDurotar(name) then return standing,low,high,value end
          end
        end
      end
      return nil
    end
    local function commas(value)
      local s=tostring(math.floor((tonumber(value) or 0)+.5))
      while true do
        local replaced,n=s:gsub('^(%-?%d+)(%d%d%d)','%1,%2')
        s=replaced
        if n==0 then break end
      end
      return s
    end
    function frame.refresh()
      local rank,low,high,amount=getFaction()
      rank=tonumber(rank);low=tonumber(low);high=tonumber(high);amount=tonumber(amount)
      if not rank then
        liveStanding:SetText('Standing: Not available (faction not discovered yet)')
        liveRemaining:SetText('To next rank: --')
        liveWrits:SetText('Writs needed: --')
        progress:SetMinMaxValues(0,1);progress:SetValue(0)
        return
      end
      local name=names[rank] or ('Standing '..rank)
      if rank>=8 then
        liveStanding:SetText('Standing: '..name..'  |  Maximum reputation rank')
        liveRemaining:SetText('To next rank: None - Exalted reached!')
        liveWrits:SetText('Journeyman: 0     Expert: 0     Artisan: 0')
        progress:SetMinMaxValues(0,1);progress:SetValue(1)
        return
      end
      if not low or not high or not amount or high<=low then
        liveStanding:SetText('Standing: '..name..'  |  Reputation values unavailable')
        liveRemaining:SetText('To next rank: --')
        liveWrits:SetText('Writs needed: --')
        progress:SetMinMaxValues(0,1);progress:SetValue(0)
        return
      end
      local width=high-low
      local inRank=math.max(0,math.min(width,amount-low))
      local remaining=math.max(0,math.ceil(high-amount))
      local percent=math.floor(100*inRank/width+.5)
      local nextRank=names[rank+1] or 'next rank'
      liveStanding:SetText('Standing: '..name..'  |  '..commas(inRank)..' / '..commas(width)..' rep ('..percent..'%)')
      liveRemaining:SetText('To '..nextRank..': '..commas(remaining)..' reputation')
      liveWrits:SetText('Writs to '..nextRank..':  Journeyman '..math.ceil(remaining/75)..
        '     |     Expert '..math.ceil(remaining/125)..'     |     Artisan '..math.ceil(remaining/200))
      progress:SetMinMaxValues(0,width);progress:SetValue(inRank)
    end
    frame:RegisterEvent('UPDATE_FACTION')
    frame:SetScript('OnEvent',function(self,event)
      if event=='UPDATE_FACTION' and self:IsShown() then self.refresh() end
    end)
    frame:SetScript('OnShow',function(self) self.refresh() end)

    local proportions={198,143,126,126,126,213}
    local columns={
      'Step','Reputation\nneeded','Journeyman\nwrits',
      'Expert\nwrits','Artisan\nwrits','Forged Delivery\nReceipts'
    }
    local data={
      {'Neutral to Friendly\n(after Shipping Label)','1,000','14','8','5','Not available\nbefore Friendly'},
      {'Friendly to Honored','6,000','80','48','30','120 (1,800 Favor)'},
      {'Honored to Revered','12,000','160','96','60','240 (3,600 Favor)'},
      {'Revered to Exalted','21,000','280','168','105','420 (6,300 Favor)'},
      {'Total, Neutral to Exalted','40,000','534','320','200','780 from Friendly\n(11,700 Favor)'},
    }
    -- Keep a handle to each visual, so resizing affects labels AND backgrounds.
    -- In compact mode only the live faction summary stays on screen.
    local chartPieces={}
    local headerCells,bodyCells,bodyBackgrounds={}, {}, {}
    local function gridCell(value,isHeading,isTotal)
      local cell=textLine(frame,value,nil,isHeading or isTotal)
      cell:SetJustifyH('CENTER')
      if cell.SetJustifyV then cell:SetJustifyV('MIDDLE') end
      if isHeading then cell:SetTextColor(.95,.86,.71)
      elseif isTotal then cell:SetTextColor(1,.86,.49)
      else cell:SetTextColor(.91,.91,.89) end
      chartPieces[#chartPieces+1]=cell
      return cell
    end
    local head=frame:CreateTexture(nil,'ARTWORK')
    head:SetColorTexture(.17,.17,.18,.93)
    chartPieces[#chartPieces+1]=head
    for i=1,#columns do headerCells[i]=gridCell(columns[i],true,false) end
    for r,values in ipairs(data) do
      local bg=frame:CreateTexture(nil,'BACKGROUND')
      if r==5 then bg:SetColorTexture(.16,.13,.085,.90)
      elseif r%2==1 then bg:SetColorTexture(.045,.050,.064,.90)
      else bg:SetColorTexture(.065,.070,.077,.90) end
      bodyBackgrounds[r]=bg;chartPieces[#chartPieces+1]=bg
      bodyCells[r]={}
      for c=1,#values do bodyCells[r][c]=gridCell(values[c],false,r==5) end
    end
    local foot=textLine(frame,
      'Writ columns are alternate paths, not amounts to add together. Receipts become available at Friendly.',nil)
    foot:SetTextColor(.76,.73,.65)
    chartPieces[#chartPieces+1]=foot

    local function applyResizeBounds()
      local minHeight=DB.repChartShowTable==false and 245 or 530
      if frame.SetResizeBounds then frame:SetResizeBounds(740,minHeight,1320,900)
      else
        if frame.SetMinResize then frame:SetMinResize(740,minHeight) end
        if frame.SetMaxResize then frame:SetMaxResize(1320,900) end
      end
    end
    -- Fluid six-column layout: labels, shaded rows, background and live-progress
    -- bar all fit the chosen width. Expanded height adds space to the guide rows.
    local function layoutChart(w,h)
      w=w or frame:GetWidth();h=h or frame:GetHeight()
      local inner=math.max(690,w-48)
      liveBG:SetWidth(inner)
      liveTitle:SetWidth(w-78)
      liveStanding:SetWidth(w-78)
      liveRemaining:SetWidth(w-78)
      liveWrits:SetWidth(w-78)
      progress:SetWidth(math.max(150,w-78))
      note:SetWidth(math.max(200,w-300))
      if DB.repChartShowTable==false then return end
      local widths={}
      local total=0
      for i=1,#proportions do
        widths[i]=math.floor(inner*proportions[i]/932)
        total=total+widths[i]
      end
      widths[#widths]=widths[#widths]+inner-total
      local top=226
      local headerHeight=47
      local rowHeight=math.max(43,math.floor((h-top-headerHeight-42)/5))
      head:ClearAllPoints();head:SetPoint('TOPLEFT',24,-top)
      head:SetSize(inner,headerHeight)
      local x=24
      for i,cell in ipairs(headerCells) do
        cell:ClearAllPoints();cell:SetPoint('TOPLEFT',x,-top)
        cell:SetSize(widths[i],headerHeight)
        x=x+widths[i]
      end
      for r,cells in ipairs(bodyCells) do
        local y=top+headerHeight+(r-1)*rowHeight
        local bg=bodyBackgrounds[r]
        bg:ClearAllPoints();bg:SetPoint('TOPLEFT',24,-y)
        bg:SetSize(inner,rowHeight)
        x=24
        for c,cell in ipairs(cells) do
          cell:ClearAllPoints();cell:SetPoint('TOPLEFT',x,-y)
          cell:SetSize(widths[c],rowHeight)
          x=x+widths[c]
        end
      end
      foot:ClearAllPoints();foot:SetPoint('BOTTOMLEFT',25,29)
      foot:SetWidth(w-62)
    end
    local function setChartVisible(visible)
      DB.repChartShowTable=visible and true or false
      showChart:SetChecked(visible)
      for _,element in ipairs(chartPieces) do
        if visible then element:Show() else element:Hide() end
      end
      applyResizeBounds()
      -- Save each mode's height before switching: collapsed mode does not
      -- discard the previous expanded dimensions (or vice versa).
      local target=visible and (DB.repChartHeight or 550) or (DB.repCompactHeight or 255)
      target=math.min(900,math.max(visible and 530 or 245,target))
      frame:SetHeight(target)
      layoutChart(frame:GetWidth(),frame:GetHeight())
    end
    showChart:SetScript('OnClick',function(self)
      local want=self:GetChecked() and true or false
      if DB.repChartShowTable==false then
        DB.repCompactHeight=math.floor(frame:GetHeight()+.5)
      else
        DB.repChartHeight=math.floor(frame:GetHeight()+.5)
      end
      setChartVisible(want)
    end)
    frame:SetResizable(true)
    applyResizeBounds()
    local grip=CreateFrame('Button',nil,frame)
    grip:SetSize(20,20);grip:SetPoint('BOTTOMRIGHT',-2,2)
    grip:SetFrameLevel(frame:GetFrameLevel()+6)
    grip:SetNormalTexture('Interface\\ChatFrame\\UI-ChatIM-SizeGrabber-Up')
    grip:SetHighlightTexture('Interface\\ChatFrame\\UI-ChatIM-SizeGrabber-Highlight')
    grip:SetPushedTexture('Interface\\ChatFrame\\UI-ChatIM-SizeGrabber-Down')
    grip:SetScript('OnMouseDown',function()frame:StartSizing('BOTTOMRIGHT')end)
    grip:SetScript('OnMouseUp',function()
      frame:StopMovingOrSizing()
      DB.repChartWidth=math.floor(frame:GetWidth()+.5)
      if DB.repChartShowTable==false then
        DB.repCompactHeight=math.floor(frame:GetHeight()+.5)
      else
        DB.repChartHeight=math.floor(frame:GetHeight()+.5)
      end
      savePosition(frame,'repChartPos')
    end)
    frame:SetScript('OnSizeChanged',function(self,w,h)layoutChart(w,h)end)
    layoutChart(frame:GetWidth(),frame:GetHeight())
    -- Initial visibility without resetting the previously stored dimensions.
    for _,element in ipairs(chartPieces) do
      if chartVisible then element:Show() else element:Hide() end
    end
    frame:Hide()
    rows.registerPopup(frame)
    rows.repChartFrame=frame
  end
  local frame=rows.repChartFrame
  frame:SetShown(not frame:IsShown())
end

local function buildUI()
  window=CreateFrame('Frame','WritTrackerMainFrame',UIParent,BackdropTemplateMixin and 'BackdropTemplate')
  local mainExpanded=DB.mainShowDetails~=false
  local initialHeight=mainExpanded and (DB.mainExpandedHeight or DB.mainHeight or BASE_H)
    or (DB.mainCompactHeight or math.max(350,(DB.mainHeight or BASE_H)-186))
  window:SetSize(math.min(1000,math.max(580,DB.mainWidth or BASE_W)),
    math.min(1000,math.max(mainExpanded and 500 or 350,initialHeight)))
  window:SetFrameStrata('MEDIUM')
  window:SetMovable(true);window:EnableMouse(true);window:SetClampedToScreen(true)
  position(window,'mainPos',200,20)
  skinFrame(window)
  local heading=window:CreateTexture(nil,'BORDER')
  heading:SetTexture('Interface\\Buttons\\WHITE8X8')
  rows.skinHeaders[heading]=true
  heading:SetColorTexture(unpack(skin().header))
  heading:SetPoint('TOPLEFT',5,-5);heading:SetPoint('TOPRIGHT',-5,-5);heading:SetHeight(46)
  local name=textLine(window,'Writ This',195,true)
  name:SetPoint('TOPLEFT',17,-10)
  -- Blizzard's Morpheus display face gives this an ornate fantasy-book title.
  -- No fonts are packaged or redistributed; the game supplies the font.
  if name.SetFont then
    local ok,loaded=pcall(name.SetFont,name,'Fonts\\MORPHEUS.TTF',24,'OUTLINE')
    if not ok or loaded==false then
      name:SetFont(STANDARD_TEXT_FONT or 'Fonts\\FRIZQT__.TTF',21,'OUTLINE')
    end
  end
  name:SetTextColor(1,.83,.46)
  if name.SetShadowColor then name:SetShadowColor(0,0,0,.95) end
  if name.SetShadowOffset then name:SetShadowOffset(1,-1) end
  makeDraggable(window)
  createButton(window,'X',26,26,function()rows.navigation.close(window)end):SetPoint('TOPRIGHT',-13,-13)
  local live=textLine(window,'ACTIVE',80)
  live:SetJustifyH('RIGHT')
  live:SetTextColor(.5,.86,.55);live:SetPoint('TOPRIGHT',-21,-55);window.live=live
  -- A quiet counter left of ACTIVE, near the close button; the footer is too
  -- crowded by Send Data / RIP Shady at the default window width.
  local users=textLine(window,'Users: 1',102)
  users:SetJustifyH('RIGHT');users:SetTextColor(.67,.85,.74)
  users:SetPoint('TOPRIGHT',-107,-55)
  window.userCount=users
  local usersHover=CreateFrame('Button',nil,window)
  usersHover:SetSize(106,23);usersHover:SetPoint('TOPRIGHT',-103,-50)
  usersHover:EnableMouse(true)
  usersHover:RegisterForClicks('LeftButtonUp')
  usersHover:SetScript('OnClick',function() rows.toggleUserList() end)
  usersHover:SetScript('OnEnter',function(self)
    users:SetTextColor(1,.86,.47)
    if not GameTooltip then return end
    GameTooltip:SetOwner(self,'ANCHOR_BOTTOMLEFT')
    GameTooltip:AddLine('Writ This users detected',1,.82,.35)
    GameTooltip:AddLine('Active users: '..tostring(community.detectedUsers()),.62,.92,.70)
    GameTooltip:AddLine('All-time users: '..tostring(community.allTimeUsers()),1,.82,.40)
    GameTooltip:Show()
  end)
  usersHover:SetScript('OnLeave',function()
    users:SetTextColor(.67,.85,.74)
    if GameTooltip then GameTooltip:Hide() end
  end)

  -- One prominent row of equal-size counters, rather than two misaligned
  -- labels. Smaller financial data lives in an aligned second row.
  local first=textLine(window,'Active: 0',126,true)
  first:SetPoint('TOPLEFT',18,-76);window.total=first
  local posted=textLine(window,'Posted: 0',120,true)
  posted:SetPoint('TOPLEFT',170,-76);window.postedCount=posted
  local completedCount=textLine(window,'Completed: 0',148,true)
  completedCount:SetPoint('TOPLEFT',315,-76);window.completedCount=completedCount
  local unknown=textLine(window,'Unverified: 0',112)
  unknown:SetJustifyH('RIGHT')
  unknown:SetPoint('TOPRIGHT',-18,-79);window.unknown=unknown
  local spent=textLine(window,'AH buys: 0   |   Looted: 0',185)
  spent:SetPoint('TOPLEFT',18,-105);window.spent=spent
  local totalSpent=textLine(window,'Total Costs: 0g 00s 00c',185)
  totalSpent:SetPoint('TOPLEFT',225,-105);window.totalSpent=totalSpent
  local profit=textLine(window,'Total Profit: 0g 00s 00c',180)
  profit:SetPoint('TOPLEFT',450,-105);window.totalProfit=profit

  local function makeSummaryDivider()
    local mark=window:CreateTexture(nil,'ARTWORK')
    mark:SetColorTexture(.47,.42,.33,.55)
    mark:SetSize(1,20)
    return mark
  end
  local split1=makeSummaryDivider()
  local split2=makeSummaryDivider()
  local function arrangeSummaryColumns(w)
    local available=math.max(544,w-36)
    local x2=18+math.floor(available*.26)
    local x3=18+math.floor(available*.48)
    first:SetWidth(x2-30)
    posted:ClearAllPoints();posted:SetPoint('TOPLEFT',x2,-76)
    posted:SetWidth(x3-x2-14)
    completedCount:ClearAllPoints();completedCount:SetPoint('TOPLEFT',x3,-76)
    completedCount:SetWidth(math.max(125,w-18-114-x3-10))
    split1:ClearAllPoints();split1:SetPoint('TOPLEFT',x2-12,-76)
    split2:ClearAllPoints();split2:SetPoint('TOPLEFT',x3-12,-76)
    -- Financial columns retain enough width at the minimum 580px frame.
    local moneyX=18+math.floor(available*.35)
    local profitX=18+math.floor(available*.68)
    spent:SetWidth(moneyX-26)
    totalSpent:ClearAllPoints();totalSpent:SetPoint('TOPLEFT',moneyX,-105)
    totalSpent:SetWidth(profitX-moneyX-10)
    profit:ClearAllPoints();profit:SetPoint('TOPLEFT',profitX,-105)
    profit:SetWidth(w-profitX-18)
  end
  window.arrangeSummaryColumns=arrangeSummaryColumns
  arrangeSummaryColumns(window:GetWidth())

  -- Automatic tracking remains visible; details move to Settings. A compact
  -- shortcut button exposes the complete verified click/key combinations.
  local hint=textLine(window,'Tracking: Automatic',160)
  hint:SetTextColor(.67,.80,.70)
  hint:SetPoint('TOPLEFT',18,-124);window.hint=hint
  local shortcut=createButton(window,'Keybinds ?',84,19,function()
    if not settings then return end
    -- The shortcut is a toggle: clicking again closes the Settings panel.
    if settings:IsShown() then
      settings:Hide()
    elseif settings.showKeybindList then
      settings.showKeybindList()
    end
  end)
  shortcut:SetPoint('TOPLEFT',167,-119)
  if shortcut.HookScript then
    shortcut:HookScript('OnEnter',function(self)
      if not GameTooltip then return end
      GameTooltip:SetOwner(self,'ANCHOR_RIGHT')
      GameTooltip:AddLine('Writ This row shortcuts',1,.82,.35)
      GameTooltip:AddLine('Shift + Left-click: Delete a writ',.92,.92,.88)
      GameTooltip:AddLine('Shift + Right-click: Manual sale recovery',.92,.92,.88)
      GameTooltip:AddLine('Shift + Middle-click: Record missed Coin Pouch payout',.92,.92,.88)
      GameTooltip:AddLine('Click to toggle Settings > Show Keybinds.',.72,.83,.97)
      GameTooltip:Show()
    end)
    shortcut:HookScript('OnLeave',function()
      if GameTooltip then GameTooltip:Hide() end
    end)
  end
  -- Independent compact view for the MAIN writ-details panel (not the
  -- Items & Locations book). Existing users start with full details shown.
  local detailsCheck=CreateFrame('CheckButton',nil,window,'UICheckButtonTemplate')
  detailsCheck:SetSize(24,24)
  detailsCheck:SetPoint('TOPLEFT',261,-117)
  detailsCheck:SetChecked(DB.mainShowDetails~=false)
  window.detailsCheckbox=detailsCheck
  local detailsText=textLine(window,'Details',63)
  detailsText:SetPoint('LEFT',detailsCheck,'RIGHT',1,0)
  local detailsLabelClick=CreateFrame('Button',nil,window)
  detailsLabelClick:SetPoint('LEFT',detailsCheck,'RIGHT',0,0)
  detailsLabelClick:SetSize(62,23)
  local consoleButton=createButton(window,'Console',75,20,function()
    if rows.openConsole then rows.openConsole() end
  end)
  consoleButton:SetPoint('TOPLEFT',363,-120)
  local function setMainDetailsVisible(enabled)
    local prior=DB.mainShowDetails~=false
    if prior==enabled then return end
    local oldHeight=math.floor(window:GetHeight()+.5)
    if prior then DB.mainExpandedHeight=oldHeight
    else DB.mainCompactHeight=oldHeight end
    DB.mainShowDetails=enabled
    local minHeight=enabled and 500 or 350
    if window.SetResizeBounds then window:SetResizeBounds(580,minHeight,1000,1000)
    else
      if window.SetMinResize then window:SetMinResize(580,minHeight) end
      if window.SetMaxResize then window:SetMaxResize(1000,1000) end
    end
    local target=enabled and (DB.mainExpandedHeight or BASE_H)
      or (DB.mainCompactHeight or math.max(350,oldHeight-186))
    window:SetHeight(math.min(1000,math.max(minHeight,target)))
    DB.mainHeight=math.floor(window:GetHeight()+.5)
    if window.applyMainDetailsVisibility then window:applyMainDetailsVisibility() end
    if refresh then refresh() end
  end
  detailsCheck:SetScript('OnClick',function(self)
    setMainDetailsVisible(self:GetChecked() and true or false)
  end)
  detailsLabelClick:SetScript('OnClick',function()
    local nextValue=DB.mainShowDetails==false
    detailsCheck:SetChecked(nextValue)
    setMainDetailsVisible(nextValue)
  end)
  if detailsCheck.HookScript then
    detailsCheck:HookScript('OnEnter',function(self)
      if not GameTooltip then return end
      GameTooltip:SetOwner(self,'ANCHOR_RIGHT')
      GameTooltip:AddLine('Show writ details',1,.82,.35)
      GameTooltip:AddLine('Uncheck to collapse the details and give the list more space.',.88,.88,.84)
      GameTooltip:AddLine('Expanded and compact sizes are saved separately.',.75,.80,.92)
      GameTooltip:Show()
    end)
    detailsCheck:HookScript('OnLeave',function() if GameTooltip then GameTooltip:Hide() end end)
  end
  local line=window:CreateTexture(nil,'ARTWORK');line:SetHeight(1)
  line:SetColorTexture(.42,.38,.28,.7)
  line:SetPoint('TOPLEFT',16,-140);line:SetPoint('TOPRIGHT',-16,-140)
  local h=textLine(window,'ACTIVE WRITS',180,true)
  h:SetPoint('TOPLEFT',18,-157);window.listTitle=h
  -- A single switch uses the same six-column list, selection and delete path.
  -- Posted writs stay in DB.orders for expiry, reposting and sale settlement.
  local switch=createButton(window,'> Posted',95,25,function()
    DB.listView=(DB.listView=='posted') and 'active' or 'posted'
    page=1;selectedID=nil;DB.selectedID=nil
    if refresh then refresh() end
  end)
  switch:SetPoint('TOPLEFT',202,-150)
  window.listSwitch=switch
  local hideBanked=CreateFrame('CheckButton',nil,window,'UICheckButtonTemplate')
  hideBanked:SetSize(22,22)
  hideBanked:SetPoint('LEFT',switch,'RIGHT',4,0)
  hideBanked:SetChecked(DB.hideBanked==true)
  local bankLabel=textLine(hideBanked,'Hide banked',nil)
  bankLabel:SetPoint('LEFT',hideBanked,'RIGHT',0,0)
  hideBanked:SetHitRectInsets(0,-65,0,0)
  hideBanked:SetScript('OnClick',function(self)
    DB.hideBanked=not not self:GetChecked()
    page=1
    refresh()
  end)
  window.hideBanked=hideBanked
  -- Column labels and cells share the same resizable layout. The list order is
  -- oldest acquisition first; row numbers describe that order, not DB IDs.
  window.listHeaders={}
  local headings={'#','ITEM','SOURCE','TOTAL COST','REP','LOCATION','MAP'}
  for i,title in ipairs(headings) do
    local heading=textLine(window,title,75)
    heading:SetTextColor(.65,.61,.51)
    if heading.SetFont then heading:SetFont(STANDARD_TEXT_FONT or 'Fonts\\FRIZQT__.TTF',9) end
    window.listHeaders[i]=heading
  end
  local nextB=createButton(window,'>',27,25,function()page=page+1;refresh()end)
  nextB:SetPoint('TOPRIGHT',-18,-151)
  local pageText=textLine(window,'Page 1 / 1',92);pageText:SetJustifyH('CENTER')
  pageText:SetPoint('RIGHT',nextB,'LEFT',-5,0);window.pageText=pageText
  createButton(window,'<',27,25,function()page=math.max(1,page-1);refresh()end):SetPoint('RIGHT',pageText,'LEFT',-5,0)
  for i=1,19 do
    local b=createButton(window,'',window:GetWidth()-38,28,function(self,mouseButton)
      if not self.recordID then return end
      if IsShiftKeyDown and IsShiftKeyDown() then
        if mouseButton=='MiddleButton' then
          if rows.openManualPouchRecovery then
            rows.openManualPouchRecovery(self.recordID)
          end
        elseif mouseButton=='RightButton' then
          resale.openManualSale(entryByID(self.recordID))
        elseif mouseButton=='LeftButton' then
          requestDeleteWrit(self.recordID) -- Shift + LEFT click = delete
        end
      elseif mouseButton=='LeftButton' then
        pendingDeleteID=nil;pendingDeleteAt=nil
        selectedID=self.recordID;refresh()
      end
    end)
    if b.RegisterForClicks then
      b:RegisterForClicks('LeftButtonUp','RightButtonUp','MiddleButtonUp')
    end
    b:SetPoint('TOPLEFT',18,-191-(i-1)*31)
    b.text:Hide()
    b.cells={}
    -- This button is a child of the row and does not select/delete the writ.
    local mapButton=createButton(b,'Map',43,23,function()
      local record=b.recordID and entryByID(b.recordID)
      if record then rows.openTurnInMap(record) end
    end)
    mapButton:SetPoint('RIGHT',b,'RIGHT',-5,0)
    if mapButton.SetFrameLevel then mapButton:SetFrameLevel(b:GetFrameLevel()+2) end
    b.mapButton=mapButton
    for col=1,6 do
      local label=textLine(b,'',90)
      label:SetJustifyH('LEFT')
      if label.SetWordWrap then label:SetWordWrap(false) end
      if col==2 then label:SetTextColor(.96,.92,.83)
      elseif col==3 then label:SetTextColor(.78,.75,.67)
      elseif col==6 then label:SetTextColor(.76,.82,.74) end
      b.cells[col]=label
    end
    -- A row is a Button (can own mouse scripts); font strings cannot.
    -- Show the price components of the currently displayed record.
    b:HookScript('OnEnter',function(self)
      local e=self.recordID and entryByID(self.recordID)
      if not e or not GameTooltip then return end
      GameTooltip:SetOwner(self,'ANCHOR_RIGHT')
      local isPosted=e.resaleListed and not e.complete
      GameTooltip:AddLine(isPosted and 'Posted listing costs' or 'Recorded total costs',1,.82,.32)
      GameTooltip:AddLine('Writ: '..(e.priceUnknown and 'Unverified' or fmtMoney(e.writCost or 0)))
      if e.complete and not e.pouchPaid then
        GameTooltip:AddLine('Shift + Middle-click: recover missed Coin Pouch payout',.80,.94,.70)
      end
      if isPosted then
        GameTooltip:AddLine('Saved record ID: #'..tostring(e.id),.76,.9,1)
        GameTooltip:AddLine('Linked AH ID: '..tostring(e.resaleAuctionID or 'not confirmed'),.76,.9,1)
        if resale.ownedEvidence then
          GameTooltip:AddLine('Fresh owned-AH check: '..tostring(resale.ownedEvidence(e)),.76,.9,1)
        end
        GameTooltip:AddLine('Lost AH deposits: '..fmtMoney(e.resaleLostDeposits or 0))
        GameTooltip:AddLine('Current unrefunded deposit: '..
          (e.resaleLastDeposit and fmtMoney(e.resaleLastDeposit) or 'Not captured'))
        GameTooltip:AddLine('Required item is excluded from Posted total.',.7,.7,.7)
      else
        if rows.itemPricePending(e) then
          GameTooltip:AddLine('Final cost waits for the buyer-mail invoice.',.72,.83,.97)
        end
        GameTooltip:AddLine('Required item: '..(rows.itemPricePending(e) and 'Price Pending' or
          (e.itemPriceUnknown and 'Unverified' or
          ((e.itemCostKnown or (tonumber(e.itemCost) or 0)>0) and fmtMoney(e.itemCost or 0) or 'Not purchased / unverified'))))
        GameTooltip:AddLine('Lost AH deposits: '..fmtMoney(e.resaleLostDeposits or 0))
      end
      GameTooltip:Show()
    end)
    b:HookScript('OnLeave',function()
      if GameTooltip then GameTooltip:Hide() end
    end)
    rows[#rows+1]=b
  end
  -- Keep all columns aligned and within the window as it is resized.
  local function arrangeListColumns(w)
    local available=math.max(510,w-36)
    -- Reserve a dedicated map-button column while keeping the zone readable.
    local widths={36,math.floor(available*.28),math.floor(available*.14),
                  math.floor(available*.17),math.floor(available*.10),0,51}
    local used=widths[7]
    for i=1,5 do used=used+widths[i] end
    widths[6]=math.max(60,available-used)
    local left=0
    for i,colWidth in ipairs(widths) do
      local heading=window.listHeaders[i]
      heading:ClearAllPoints()
      heading:SetPoint('TOPLEFT',window,'TOPLEFT',18+left+7,-178)
      heading:SetWidth(math.max(10,colWidth-9))
      if i<=6 then
        for _,b in ipairs(rows) do
          local cell=b.cells[i]
          cell:ClearAllPoints()
          cell:SetPoint('LEFT',b,'LEFT',left+7,0)
          cell:SetWidth(math.max(10,colWidth-9))
        end
      end
      left=left+colWidth
    end
  end
  window.arrangeListColumns=arrangeListColumns
  arrangeListColumns(window:GetWidth())
  local detailTitle=textLine(window,'SELECT A WRIT',215,true)
  detailTitle:SetPoint('BOTTOMLEFT',18,238)
  window.detailTitle=detailTitle
  local detail1=textLine(window,'Click a writ above to view its details.',620)
  detail1:SetPoint('BOTTOMLEFT',18,210);window.detail1=detail1
  local detail2=textLine(window,'',620);detail2:SetPoint('BOTTOMLEFT',18,186);window.detail2=detail2
  local detail3=textLine(window,'',620);detail3:SetPoint('BOTTOMLEFT',18,162);window.detail3=detail3
  local detail4=textLine(window,'',620);detail4:SetPoint('BOTTOMLEFT',18,138);window.detail4=detail4
  local detail5=textLine(window,'',620)
  detail5:SetPoint('BOTTOMLEFT',18,114);window.detail5=detail5
  local detail6=textLine(window,'',620)
  detail6:SetPoint('BOTTOMLEFT',18,90);window.detail6=detail6
  local searchAH=createButton(window,'Search AH',105,25,searchRequiredAtAH)
  searchAH:SetPoint('BOTTOMLEFT',18,53);window.searchAH=searchAH
  local editWrit=createButton(window,'Edit',91,25,openOrderEditor)
  editWrit:SetPoint('LEFT',searchAH,'RIGHT',10,0);window.editWrit=editWrit
  -- Refresh alone controls whether Search AH/Edit are available for a writ.
  -- This visibility gate only hides the detail area in compact mode.
  window.applyMainDetailsVisibility=function(self)
    local showing=DB.mainShowDetails~=false
    for _,part in ipairs({self.detailTitle,self.detail1,self.detail2,self.detail3,
                          self.detail4,self.detail5,self.detail6}) do
      if showing then part:Show() else part:Hide() end
    end
    if not showing then self.searchAH:Hide();self.editWrit:Hide() end
  end
  window:applyMainDetailsVisibility()
  local sep=window:CreateTexture(nil,'ARTWORK');sep:SetHeight(1);sep:SetColorTexture(.42,.38,.28,.7)
  sep:SetPoint('BOTTOMLEFT',16,47);sep:SetPoint('BOTTOMRIGHT',-16,47)
  -- Reset must require an explicit modal confirmation; an accidental second
  -- click on the button can never clear SavedVariables.
  local function performReset()
    DB.orders={};DB.completed={};DB.lastWritTurnIn={};DB.soldWrits={};DB.resaleAuctionIDs={};DB.resaleReturnsSeen={};DB.bookOverrides={};DB.pouchSamples={};DB.sharedSources={};DB.log={};DB.nextID=0;DB.unassigned={};DB.mailInvoiceSeen={};DB.ignoredBagCounts={};DB.ignoredWritGUIDs={};rows.duplicatePreview=nil;rows.mailMissing=nil;DB.archivedDuplicates={};DB.deletedMailWrits={};DB.requiredAuctionSeen={};DB.consoleLog={};DB.debugLog={};DB.resetAt=nil
    -- Retire old waypoint ownership: IDs are reused after reset. Leave any
    -- native player waypoint alone rather than deleting it unexpectedly.
    DB.writThisWaypoint=nil
    lastPouchCount,rows.lastPouchCounts=pouchBagCount();pouchUses={};rows.pouchGains={};rows.pouchLastActivity=0;recentPouchGains={};questScreen=nil
    pendingTurnIn=nil;recentFactionGain=nil
    selectedID=nil;page=1;DB.listView='active'
    local snapshot={};for id,v in pairs(bagBefore) do snapshot[id]=v.count end
    DB.lastBag=snapshot
    pendingBid={};openedQueue={};recentConfirmed={};confirmedItems={};pendingItemEvents={}
    pendingSuccess={};sealedActions={};sealedLossConsumed={};pendingCommodity=nil
    say('Writ records and personal reference overrides cleared. Tracking remains active.')
    refresh()
    if bookRefresh then bookRefresh() end
  end
  if StaticPopupDialogs then
    StaticPopupDialogs.WRITTHIS_FULL_RESET_CONFIRM={
      text='Reset Writ This tracking data?\nThis permanently deletes your active/posted writs, completed history, sales, cost records, synced statistics and personal History/Records edits.\nThis cannot be undone. Back up SavedVariables first.',
      button1='Delete All Records',button2='Cancel',
      OnAccept=function() if DB then performReset() end end,
      timeout=0,whileDead=true,hideOnEscape=true,preferredIndex=3,
    }
  end
  local reset=createButton(settings,'Reset Data',96,24,function()
    if not (StaticPopupDialogs and StaticPopup_Show) then
      say('Reset confirmation is unavailable; NO records were deleted.')
      return
    end
    StaticPopup_Show('WRITTHIS_FULL_RESET_CONFIRM')
  end)
  reset:SetPoint('TOPLEFT',190,-12)
  local openSettings=createButton(window,'Settings',95,29,function()
    settings:SetShown(not settings:IsShown())
  end)
  openSettings:SetPoint('TOPRIGHT',-49,-12)
  createButton(window,'Commands',95,29,function() settings.showCommandList() end)
    :SetPoint('RIGHT',openSettings,'LEFT',-6,0)
  local openItems=createButton(window,'History/Records',132,29,toggleItemsBook)
  local soldBtn=createButton(window,'Sold Log',80,29,function() resale.open() end)
  local repBtn=createButton(window,'Reputation',99,29,function()
    rows.toggleRepChart()
  end)
  window.repChart=repBtn
  local writBtn=createButton(window,'Writs',61,29,rows.toggleWritPrices)
  local crateBtn=createButton(window,'Crates',105,29,function()
    rows.toggleWaylaidCrates()
  end)
  window.waylaidCrates=crateBtn
  local shopBtn=createButton(window,'Traders',62,29,function()
    rows.toggleMerchantShop()
  end)
  window.merchantShop=shopBtn
  local miniCheck=CreateFrame('CheckButton',nil,window,'UICheckButtonTemplate')
  miniCheck:SetSize(25,25)
  miniCheck:SetChecked(DB.miniMode==true)
  miniCheck:SetScript('OnClick',function(self) setMiniMode(self:GetChecked()) end)
  window.miniCheckbox=miniCheck
  local miniLabel=textLine(window,'Mini',39)
  miniLabel:SetPoint('LEFT',miniCheck,'RIGHT',1,0)
  local miniClick=CreateFrame('Button',nil,window)
  miniClick:SetPoint('LEFT',miniCheck,'RIGHT',0,0);miniClick:SetSize(40,25)
  miniClick:SetScript('OnClick',function()setMiniMode(not DB.miniMode)end)
  local footerButtons={writBtn,crateBtn,shopBtn,repBtn,soldBtn,openItems}
  window.classicFooterButtons=footerButtons
  window.arrangeFooterButtons=function(width)
    local narrow=(width or window:GetWidth())<850
    local gap=narrow and 5 or 8
    openItems:SetWidth(narrow and 111 or 132)
    soldBtn:SetWidth(narrow and 64 or 80)
    repBtn:SetWidth(narrow and 76 or 99)
    crateBtn:SetWidth(narrow and 62 or 75)
    shopBtn:SetWidth(narrow and 58 or 72)
    for i,button in ipairs(footerButtons) do
      button:ClearAllPoints()
      if i==1 then button:SetPoint('BOTTOMLEFT',18,12)
      else button:SetPoint('LEFT',footerButtons[i-1],'RIGHT',gap,0) end
    end
    miniCheck:SetSize(narrow and 20 or 25,narrow and 20 or 25)
    miniCheck:ClearAllPoints();miniCheck:SetPoint('LEFT',openItems,'RIGHT',gap,0)
  end
  window.arrangeFooterButtons(window:GetWidth())
  if repBtn.HookScript then
    repBtn:HookScript('OnEnter',function(self)
      if not GameTooltip then return end
      GameTooltip:SetOwner(self,'ANCHOR_TOPLEFT')
      GameTooltip:AddLine('Reputation',1,.82,.35)
      GameTooltip:AddLine('Compare Journeyman, Expert and Artisan writ counts',.91,.91,.88)
      GameTooltip:AddLine('See live standing, next-rank writs and the optional full chart.',.91,.91,.88)
      GameTooltip:Show()
    end)
    repBtn:HookScript('OnLeave',function()
      if GameTooltip then GameTooltip:Hide() end
    end)
  end
  if crateBtn.HookScript then
    crateBtn:HookScript('OnEnter',function(self)
      if not GameTooltip then return end
      GameTooltip:SetOwner(self,'ANCHOR_TOPLEFT')
      GameTooltip:AddLine('Waylaid Crates',1,.82,.35)
      GameTooltip:AddLine('30 known crates, material options and Merchant\'s Favor.',.91,.91,.88)
      GameTooltip:AddLine('Artisan Favor payouts remain unconfirmed.',.93,.75,.48)
      GameTooltip:Show()
    end)
    crateBtn:HookScript('OnLeave',function()if GameTooltip then GameTooltip:Hide() end end)
  end
  local foot=textLine(window,'RIP Shady',91)
  -- The memorial sits beneath the bottom button row, clear of Mini.
  foot:SetTextColor(.58,.54,.44);foot:SetPoint('BOTTOMRIGHT',-18,1)
  local version=textLine(window,'v'..VERSION,49)
  version:SetTextColor(.54,.50,.42);version:SetPoint('BOTTOMLEFT',18,2)
  if version.SetFont then version:SetFont(STANDARD_TEXT_FONT or 'Fonts\\FRIZQT__.TTF',9) end
  window.versionLabel=version
  makeResizable(window)
  window:SetScript('OnSizeChanged',function(self,w,h)
    local reserved=DB.mainShowDetails==false and 234 or 420
    self.visibleRows=math.max(2,math.min(19,math.floor((h-reserved)/31)))
    self.detail1:SetWidth(w-36);self.detail2:SetWidth(w-36);self.detail3:SetWidth(w-36);self.detail4:SetWidth(w-36);self.detail5:SetWidth(w-36);self.detail6:SetWidth(w-36)
    self.hint:SetWidth(w-36)
    for _,b in ipairs(rows) do b:SetWidth(w-36) end
    if self.arrangeListColumns then self.arrangeListColumns(w) end
    if self.arrangeSummaryColumns then self.arrangeSummaryColumns(w) end
    if self.arrangeFooterButtons then self.arrangeFooterButtons(w) end
    if refresh then refresh() end
  end)
  window.visibleRows=math.max(2,math.min(19,math.floor((window:GetHeight()-
    (DB.mainShowDetails==false and 234 or 420))/31)))
  window:Hide()
  rows.registerEscapeWindow(window)
end

-- 4.0 Beta tab shell. The legacy page frames themselves are reparented, never
-- cloned or rewritten, so all their existing controls and saved records remain
-- the only source of truth. No auction/mail/bag hooks are registered here.
rows.createExperimentalTabs=function()
  if rows.experimentalTabs then return end
  local tabs={embedded={},hookedPanels=setmetatable({},{__mode='k'}),switching=false,active='Tracking'}
  rows.experimentalTabs=tabs
  local names={'Tracking','Writs','Crates','Traders','Rep','Sold Log','History/Records'}
  local widths={89,65,67,75,54,78,127}
  local posKeys={['Tracking']='mainPos',['Writs']='writPricesPos',
    ['Crates']='waylaidCratesPos',['Traders']='merchantShopPos',
    ['Rep']='repChartPos',['Sold Log']='soldPos',
    ['History/Records']='bookPos'}
  local host=CreateFrame('Frame','WritThisTabbedFrame',UIParent,
    BackdropTemplateMixin and 'BackdropTemplate')
  host:SetSize(720,650);host:SetFrameStrata('MEDIUM')
  host:SetMovable(true);host:EnableMouse(true);host:SetClampedToScreen(true)
  position(host,'experimentalTabsPos',0,0);skinFrame(host)
  tabs.host=host
  local strip=host:CreateTexture(nil,'BORDER')
  strip:SetColorTexture(.16,.115,.06,1)
  strip:SetPoint('TOPLEFT',3,-3);strip:SetPoint('TOPRIGHT',-3,-3)
  strip:SetHeight(40)
  -- Drag exclusively in the right margin, leaving all seven tabs clickable.
  local drag=CreateFrame('Button',nil,host)
  drag:SetPoint('TOPRIGHT',-44,-4);drag:SetSize(32,35)
  drag:RegisterForDrag('LeftButton')
  drag:SetScript('OnDragStart',function()host:StartMoving()end)
  drag:SetScript('OnDragStop',function()host:StopMovingOrSizing();savePosition(host,'experimentalTabsPos')end)
  createButton(host,'X',26,25,function()host:Hide()end):SetPoint('TOPRIGHT',-11,-9)
  tabs.buttons={}
  local offset=12
  for i,name in ipairs(names) do
    local b=createButton(host,name,widths[i],27,function()tabs.open(name)end)
    b:SetPoint('TOPLEFT',offset,-9)
    tabs.buttons[name]=b
    offset=offset+widths[i]+5
  end
  local function showFooter(classic)
    if window and window.classicFooterButtons then
      for _,button in ipairs(window.classicFooterButtons) do
        button:SetShown(classic)
      end
    end
  end
  local function findPanel(name)
    if name=='Tracking' then return window end
    if name=='History/Records' then return itemsBook end
    if name=='Sold Log' then
      if not rows.soldLogFrame then return nil end
      if not rows.soldLogFrame:IsShown() then resale.open() end
      return rows.soldLogFrame
    end
    local mappings={
      ['Writs']={'writPrices',rows.toggleWritPrices},
      ['Crates']={'waylaidCratesFrame',rows.toggleWaylaidCrates},
      ['Traders']={'merchantShopFrame',rows.toggleMerchantShop},
      ['Rep']={'repChartFrame',rows.toggleRepChart},
    }
    local m=mappings[name]
    if not m then return nil end
    local panel=rows[m[1]]
    if not panel then m[2]();panel=rows[m[1]] end
    return panel
  end
  function tabs.fit(panel)
    if not panel then return end
    local w,h=panel:GetWidth(),panel:GetHeight()
    host:SetSize(math.max(700,w+4),h+51)
    local availW=math.max(500,UIParent:GetWidth()-30)
    local availH=math.max(400,UIParent:GetHeight()-40)
    host:SetScale(math.min(1,availW/host:GetWidth(),availH/host:GetHeight()))
    host:Raise()
  end
  local function restore(panel,name)
    if not panel then return end
    local saved=tabs.embedded[panel]
    if not saved then return end
    panel:Hide();panel:SetParent(saved.parent or UIParent)
    panel:SetFrameStrata(saved.strata or 'DIALOG')
    panel:SetMovable(saved.movable)
    panel:SetResizable(saved.resizable)
    position(panel,posKeys[name] or saved.key,0,0)
    tabs.embedded[panel]=nil
  end
  function tabs.open(name)
    if not DB.experimentalTabbedUI then return end
    if tabs.switching then return end
    miniWindow:Hide()
    tabs.switching=true
    local wasBusy=rows.navigation.busy
    rows.navigation.busy=true
    -- Hide the old page before creating or revealing the new one. The native
    -- popup-exclusive OnShow path is deliberately bypassed while switching.
    for panel in pairs(tabs.embedded) do panel:Hide() end
    if not host:IsShown() then host:Show() end
    local panel=findPanel(name)
    if not panel then
      name='Tracking';panel=window
    end
    if not tabs.embedded[panel] then
      tabs.embedded[panel]={parent=panel:GetParent(),strata=panel:GetFrameStrata(),
        movable=panel:IsMovable(),resizable=panel:IsResizable(),name=name}
      panel:SetParent(host)
      -- Host handles movement; keep existing page resizing functional.
      panel:SetMovable(false)
      panel:SetResizable(tabs.embedded[panel].resizable)
      panel:SetFrameStrata('MEDIUM')
      -- HookScript cannot be undone. Register once per panel, not every time
      -- the user switches Classic <-> Tabbed. Resolve the current tab from
      -- embedded state instead of retaining an old tab-name closure.
      if not tabs.hookedPanels[panel] then
        tabs.hookedPanels[panel]=true
        panel:HookScript('OnSizeChanged',function(self)
          local state=tabs.embedded[self]
          if DB.experimentalTabbedUI and state and
             tabs.active==state.name and host:IsShown() then tabs.fit(self) end
        end)
        panel:HookScript('OnHide',function(self)
          local state=tabs.embedded[self]
          if DB.experimentalTabbedUI and state and not tabs.switching and
             tabs.active==state.name and host:IsShown() then host:Hide() end
        end)
      end
    end
    panel:ClearAllPoints()
    panel:SetPoint('TOPLEFT',host,'TOPLEFT',2,-47)
    panel:Show()
    tabs.active=name
    for tab,b in pairs(tabs.buttons) do
      if b.text then
        if tab==name then b.text:SetTextColor(1,.84,.40)
        else b.text:SetTextColor(.80,.72,.55) end
      end
      if b.SetBackdropBorderColor then
        if tab==name then b:SetBackdropBorderColor(1,.72,.27,1)
        else b:SetBackdropBorderColor(unpack(skin().edge)) end
      end
    end
    tabs.fit(panel)
    rows.navigation.busy=wasBusy
    tabs.switching=false
    if name=='Tracking' and refresh then refresh() end
    if name=='History/Records' and bookRefresh then bookRefresh() end
    if name=='Sold Log' then resale.refresh() end
  end
  function tabs.setEnabled(enabled,show)
    enabled=not not enabled
    local wasShown=host:IsShown()
    DB.experimentalTabbedUI=enabled
    if settings and settings.experimentalTabsCheckbox then
      settings.experimentalTabsCheckbox:SetChecked(enabled)
    end
    if enabled then
      rows.navigation.history={};rows.navigation.current=nil
      miniWindow:Hide()
      DB.miniMode=false
      if window.miniCheckbox then window.miniCheckbox:SetChecked(false) end
      if miniWindow.miniCheckbox then miniWindow.miniCheckbox:SetChecked(false) end
      for panel in pairs(rows.popupWindows) do
        if panel~=settings and panel:IsShown() then panel:Hide() end
      end
      showFooter(false)
      if show then tabs.open('Tracking') end
    else
      tabs.switching=true
      host:Hide()
      for _,name in ipairs(names) do
        local p=({['Tracking']=window,['Writs']=rows.writPrices,
          ['Crates']=rows.waylaidCratesFrame,['Traders']=rows.merchantShopFrame,
          ['Rep']=rows.repChartFrame,['Sold Log']=rows.soldLogFrame,
          ['History/Records']=itemsBook})[name]
        if p then restore(p,name) end
      end
      tabs.active='Tracking'
      tabs.switching=false
      showFooter(true)
      if show or wasShown then window:Show() end
    end
  end
  host:Hide()
  rows.registerEscapeWindow(host)
end
-- Financial overview uses the same existing records as the active list and
-- completed archive. Partial known spending is included even if another
-- component of a writ's total is missing. No data is written by this summary.
local function financialOverview()
  local totals={costs=0,pouches=0,bought=0,looted=0,pendingItems=0}
  for _,group in ipairs({DB.orders or {},DB.completed or {}}) do
    for _,e in ipairs(group) do
      if e.acquired=='Auction House' then totals.bought=totals.bought+1
      elseif e.acquired=='Loot' then totals.looted=totals.looted+1 end
      -- Cost of the writ itself, when the purchase price is known.
      if not e.priceUnknown and tonumber(e.writCost) then
        totals.costs=totals.costs+math.max(0,tonumber(e.writCost))
      end
      -- Provisional required-item costs are retained in the record for
      -- matching buyer mail, but must not inflate on-screen totals.
      if rows.itemPricePending(e) then
        totals.pendingItems=totals.pendingItems+1
      elseif not e.itemPriceUnknown and tonumber(e.itemCost) and
         (e.itemCostKnown or tonumber(e.itemCost)>0) then
        totals.costs=totals.costs+math.max(0,tonumber(e.itemCost))
      end
      -- Historic archived records may have an authoritative combined total
      -- but lack component fields (never add it on top of the components).
      if e.pouchPaid and e.totalCost and
         (e.priceUnknown or not tonumber(e.writCost)) and
         (not e.itemCostKnown or e.itemPriceUnknown) then
        totals.costs=totals.costs+math.max(0,tonumber(e.totalCost) or 0)
      end
      if e.pouchPaid and tonumber(e.pouchAmount) then
        totals.pouches=totals.pouches+math.max(0,tonumber(e.pouchAmount))
      end
    end
  end
  totals.profit=totals.pouches-totals.costs
  return totals
end
rows.drawMain=function()
  if not window or not DB then return end
  if community.refreshPresenceCount then community.refreshPresenceCount() end
  local activeCount,postedCount=0,0
  for _,e in ipairs(DB.orders or {}) do
    if e.resaleListed and not e.complete then postedCount=postedCount+1
    else activeCount=activeCount+1 end
  end
  -- Incurred is different from future full cost: show what has been paid so
  -- far, even if the required item has not been purchased. Unknown prices do
  -- not silently become zero-cost purchases.
  local function incurredCost(e)
    -- Never show a combined total containing an unreliable item price.
    if rows.itemPricePending(e) then return 'Price Pending' end
    if e.itemPriceUnknown and (tonumber(e.itemPurchases) or 0)>0 then return 'Unverified' end
    local known=false
    local total=0
    if not e.priceUnknown and tonumber(e.writCost) then
      total=total+math.max(0,tonumber(e.writCost));known=true
    end
    if not e.itemPriceUnknown and tonumber(e.itemCost) and
       (e.itemCostKnown or tonumber(e.itemCost)>0) then
      total=total+math.max(0,tonumber(e.itemCost));known=true
    end
    if tonumber(e.resaleLostDeposits) and e.resaleLostDeposits>0 then
      total=total+math.max(0,tonumber(e.resaleLostDeposits));known=true
    end
    -- The latest listing deposit is refundable, and must not be charged
    -- a second time unless the auction actually expires/cancels.
    return known and fmtMoney(total) or 'None'
  end
  -- Posted listing cost is intentionally *not* the cost of turning in a
  -- writ. Only count what is spent on obtaining the writ plus unrefunded
  -- deposits (past lost postings and the currently outstanding listing).
  -- The required crafted item is still displayed separately for reference.
  local function postedCost(e)
    local total=0
    local known=false
    if not e.priceUnknown and tonumber(e.writCost) then
      total=total+math.max(0,tonumber(e.writCost));known=true
    end
    local lost=math.max(0,tonumber(e.resaleLostDeposits) or 0)
    local outstanding=(e.resaleListed and math.max(0,tonumber(e.resaleLastDeposit) or 0)) or 0
    total=total+lost+outstanding
    if lost>0 or outstanding>0 then known=true end
    return known and fmtMoney(total) or 'None'
  end
  local view=(DB.listView=='posted') and 'posted' or 'active'
  local hideBanked=view=='active' and DB.hideBanked
  window.hideBanked:SetShown(view=='active')
  local overview=financialOverview()
  window.total:SetText('Active: '..activeCount)
  window.postedCount:SetText('Posted: '..postedCount)
  window.completedCount:SetText('Completed: '..#DB.completed)
  window.spent:SetText('AH buys: '..overview.bought..'   |   Looted: '..overview.looted)
  window.totalSpent:SetText('Total Costs: '..fmtMoney(overview.costs)..(overview.pendingItems>0 and ' *' or ''))
  window.totalProfit:SetText('Total Profit: '..fmtNetMoney(overview.profit)..(overview.pendingItems>0 and ' *' or ''))
  if overview.profit<0 then window.totalProfit:SetTextColor(.98,.46,.40)
  elseif overview.profit>0 then window.totalProfit:SetTextColor(.42,.87,.54)
  else window.totalProfit:SetTextColor(unpack(skin().text)) end
  local unverified,otherUnverified=0,0
  for _,e in ipairs(DB.orders) do
    local pending=rows.itemPricePending(e)
    if e.priceUnknown or e.itemPriceUnknown or pending then
      unverified=unverified+1
      if not pending or e.priceUnknown then otherUnverified=otherUnverified+1 end
    end
  end
  -- Keep existing Unverified alerts visible if they coexist with pending mail.
  window.unknown:SetText(overview.pendingItems>0 and otherUnverified==0 and
    ('Pending: '..overview.pendingItems) or ('Unverified: '..unverified))
  window.listTitle:SetText(view=='posted' and 'POSTED WRITS' or 'ACTIVE WRITS')
  window.listSwitch.text:SetText(view=='posted' and '< Active' or '> Posted')
  local visible=window.visibleRows or 6
  -- DB.orders is append-only for acquisition, but sort a temporary copy by
  -- stable record ID to preserve the first-to-last numbering across reloads.
  -- Never reorder the saved DB: other purchase/turn-in logic uses that list.
  local ordered={}
  for _,entry in ipairs(DB.orders) do
    local listed=entry.resaleListed and not entry.complete
    if (view=='posted') == (listed and true or false) and not (hideBanked and entry.banked) then
      ordered[#ordered+1]=entry
    end
  end
  local maxPage=math.max(1,math.ceil(#ordered/visible))
  page=math.max(1,math.min(page,maxPage))
  window.pageText:SetText('Page '..page..' / '..maxPage)
  table.sort(ordered,function(a,b)
    local x,y=tonumber(a.id) or 0,tonumber(b.id) or 0
    if x==y then return (tonumber(a.createdEpoch) or 0)<(tonumber(b.createdEpoch) or 0) end
    return x<y
  end)
  for i,b in ipairs(rows) do
    local index=(page-1)*visible+i
    local e=(i<=visible) and ordered[index] or nil
    b.recordID=e and e.id or nil
    if e then
      b:Show()
      local itemName=(e.writ or '(unknown writ)'):gsub("^Craftsman's Writ:%s*",'')
      local itemWidth=math.floor(((window:GetWidth() or BASE_W)-36)*.30)
      local maxName=math.max(12,math.floor((itemWidth-14)/6.0))
      if #itemName>maxName then itemName=itemName:sub(1,maxName-2)..'..' end
      local source=e.acquired or e.source or 'Manual'
      if view=='posted' and e.banked then
        source='BANK CONFLICT' -- This physical copy cannot be both banked and posted.
      elseif view=='posted' and resale.ownedEvidence and resale.ownedEvidence(e)=='MISSING_TWICE' then
        source='VERIFY AH ID' -- Never automatically unpost a record.
      elseif source=='Auction House' and window:GetWidth()<780 then source='AH' end
      -- Show actual expenditure to date. Writ-only is a valid current cost;
      -- later purchase of the required item increases the same displayed cost.
      local cost=(view=='posted') and postedCost(e) or incurredCost(e)
      local rep='Unknown'
      if not e.repNeedsReview and tonumber(e.rep) then
        rep=tostring(math.floor(tonumber(e.rep)))..' rep'
      end
      local zone=writLocation(e)
      if e.complete and not e.pouchPaid then zone=zone..' *' end
      b.cells[1]:SetText((selectedID==e.id and '> ' or '')..tostring(index))
      b.cells[2]:SetText(itemName)
      b.cells[3]:SetText(source)
      b.cells[4]:SetText(cost)
      b.cells[5]:SetText(rep)
      b.cells[6]:SetText(zone)
      if b.mapButton then
        -- No turn-in map for sealed or undocumented writs.
        if zone~='Unknown' and zone~='Not revealed' then b.mapButton:Show()
        else b.mapButton:Hide() end
      end
      b.cells[4]:SetTextColor(cost=='None' and .70 or .94,cost=='None' and .66 or .87,cost=='None' and .61 or .68)
      b.cells[5]:SetTextColor(rep=='Unknown' and .70 or .57,rep=='Unknown' and .66 or .83,rep=='Unknown' and .61 or .52)
      if b.SetBackdropBorderColor then
        if selectedID==e.id then b:SetBackdropBorderColor(1,.73,.27,1)
        else b:SetBackdropBorderColor(unpack(skin().edge)) end
      end
    else
      b:Hide()
    end
  end
  local e=selected()
  if e and hideBanked and e.banked then e=nil end
  if e then
    window.detailTitle:SetText(e.sealed and 'SEALED WRIT' or 'WRIT DETAILS')
    window.detail1:SetText(e.writ or '')
    local tier=writTier(e)
    window.detail2:SetText((tier and ('Tier: '..tier..'   |   ') or '')..'Reputation: '..reputationLabel(e)..'   |   '..(e.complete and 'COMPLETED - AWAITING POUCH' or (e.resaleListed and e.banked and 'BANK / POSTED CONFLICT' or (e.resaleListed and 'POSTED ON AUCTION HOUSE' or (e.banked and 'IN BANK - withdraw to turn in' or 'Ready to turn in')))))
    window.detail3:SetText('Source: '..(e.acquired or 'Manual')..'   |   '..((e.resalePostings or 0)>0 and ('AH posts: '..tostring(e.resalePostings)..' ('..tostring(e.resaleListingStatus or 'Unknown')..')') or ('Coin Pouch: '..(e.complete and 'Awaiting payout' or 'Not yet earned'))))
    local cost=e.priceUnknown and 'None' or fmtMoney(e.writCost or 0)
    local itemCost=rows.itemPricePending(e) and 'Price Pending' or
      (e.itemPriceUnknown and 'Unverified' or
      (e.itemCostKnown and fmtMoney(e.itemCost or 0) or 'None'))
    local isPosted=e.resaleListed and not e.complete
    local totalCost=isPosted and postedCost(e) or incurredCost(e)
    window.detail4:SetText('Writ cost: '..cost..'   |   Item cost: '..itemCost..
      '   |   '..(isPosted and 'Posted total: ' or 'Total cost: ')..totalCost)
    local required=requiredItemName(e)
    window.detail5:SetText(required and ('Required item: '..required) or 'Required item: Open sealed writ to reveal')
    local zone,npc,x,y=writLocation(e)
    local destination='Turn-in zone: '..zone
    if npc then destination=destination..'   |   NPC: '..npc end
    if x and y then destination=destination..string.format('   |   Coordinates: %.1f, %.1f',x,y)
    else destination=destination..'   |   Coordinates: Not verified' end
    window.detail6:SetText(destination)
    if required then window.searchAH:Show() else window.searchAH:Hide() end
    window.editWrit:Show()
  else
    window.detailTitle:SetText('SELECT A WRIT')
    window.detail1:SetText('Click a writ above to view acquisition and writ details.')
    window.detail2:SetText('Quest turn-ins wait for a matched Coin Pouch payout before archiving.')
    window.detail3:SetText('Use /writ finish if a turn-in is missed, or /writ payout 20s for a missed pouch.')
    window.detail4:SetText('Select a writ to view Writ cost | Item cost | Total cost.')
    window.detail5:SetText('Actual item buyout prices are recorded when detected.')
    window.detail6:SetText('Location shows in the writ list; coordinates show here when verified.')
    window.searchAH:Hide()
    window.editWrit:Hide()
  end
  if window.applyMainDetailsVisibility then window:applyMainDetailsVisibility() end
end
refresh=function(defer)
  rows.paint(window,rows.drawMain,defer)
  rows.paint(miniWindow,miniRefresh,defer)
  if resale then resale.refresh(defer) end
end
local function requiredItemsInBags()
  local counts={}
  for bag=0,(NUM_BAG_SLOTS or 4) do
    local slots=0
    if C_Container and C_Container.GetContainerNumSlots then
      slots=C_Container.GetContainerNumSlots(bag) or 0
    elseif GetContainerNumSlots then slots=GetContainerNumSlots(bag) or 0 end
    for slot=1,slots do
      local id=bagID(bag,slot)
      if id then
        local link=bagLink(bag,slot)
        local name=namedItem(link) or getName(id)
        if name and not recognize(id,link) then
          local key=requiredKey(name)
          counts[key]=(counts[key] or 0)+math.max(1,tonumber(bagCount(bag,slot)) or 1)
        end
      end
    end
  end
  return counts
end
local function buildMiniUI()
  miniWindow=CreateFrame('Frame','WritThisMiniFrame',UIParent,BackdropTemplateMixin and 'BackdropTemplate')
  miniWindow:SetSize(465,327)
  miniWindow:SetFrameStrata('MEDIUM');miniWindow:SetMovable(true)
  miniWindow:EnableMouse(true);miniWindow:SetClampedToScreen(true)
  position(miniWindow,'miniPos',135,-20);skinFrame(miniWindow)
  local heading=miniWindow:CreateTexture(nil,'BORDER')
  heading:SetTexture('Interface\\Buttons\\WHITE8X8')
  rows.skinHeaders[heading]=true
  heading:SetColorTexture(unpack(skin().header))
  heading:SetPoint('TOPLEFT',5,-5);heading:SetPoint('TOPRIGHT',-5,-5);heading:SetHeight(45)
  local title=textLine(miniWindow,'Writ This',150,true);title:SetPoint('TOPLEFT',17,-14)
  makeDraggable(miniWindow,'miniPos')
  local cb=CreateFrame('CheckButton',nil,miniWindow,'UICheckButtonTemplate')
  cb:SetSize(25,25);cb:SetPoint('TOPLEFT',212,-14);cb:SetChecked(DB.miniMode==true)
  cb:SetScript('OnClick',function(self)setMiniMode(self:GetChecked())end)
  miniWindow.miniCheckbox=cb
  local cblabel=textLine(miniWindow,'Mini',47);cblabel:SetPoint('LEFT',cb,'RIGHT',2,0)
  local cblabelClick=CreateFrame('Button',nil,miniWindow)
  cblabelClick:SetSize(45,25);cblabelClick:SetPoint('LEFT',cb,'RIGHT',0,0)
  cblabelClick:SetScript('OnClick',function()setMiniMode(false)end)
  createButton(miniWindow,'X',26,26,function()rows.navigation.close(miniWindow)end):SetPoint('TOPRIGHT',-13,-12)
  local columns=textLine(miniWindow,'TURN-IN ZONE (MAP)                 ITEM NEEDED       IN BAG',432)
  columns:SetPoint('TOPLEFT',17,-58)
  for i=1,8 do
    local row=CreateFrame('Frame',nil,miniWindow)
    row:SetSize(425,24);row:SetPoint('TOPLEFT',17,-81-(i-1)*25)
    local zone=textLine(row,'',171);zone:SetPoint('LEFT',row,'LEFT',2,0)
    local item=textLine(row,'',198);item:SetPoint('LEFT',row,'LEFT',179,0)
    local ready=row:CreateTexture(nil,'OVERLAY')
    ready:SetSize(17,17);ready:SetPoint('RIGHT',row,'RIGHT',-5,0)
    ready:SetTexture('Interface\\RaidFrame\\ReadyCheck-Ready')
    ready:Hide()
    -- Invisible click target over zone text; no extra column or visual button.
    -- The backing record ID keeps multiple identical item names independent.
    local zoneButton=CreateFrame('Button',nil,row)
    zoneButton:SetSize(173,24)
    zoneButton:SetPoint('LEFT',row,'LEFT',0,0)
    zoneButton:RegisterForClicks('LeftButtonUp')
    zoneButton:SetScript('OnClick',function(self)
      if not self.recordID then return end
      local record=entryByID(self.recordID)
      if record then rows.openTurnInMap(record) end
    end)
    zoneButton:SetScript('OnEnter',function(self)
      if not self.recordID then return end
      zone:SetTextColor(1,.84,.42)
      if GameTooltip then
        GameTooltip:SetOwner(self,'ANCHOR_RIGHT')
        GameTooltip:AddLine('Open turn-in map',1,.82,.35)
        GameTooltip:AddLine(self.fullZone or 'Writ location',.95,.93,.87)
        GameTooltip:AddLine('Uses saved coordinates when available',.72,.77,.86)
        GameTooltip:Show()
      end
    end)
    zoneButton:SetScript('OnLeave',function(self)
      if self.recordID then zone:SetTextColor(.72,.85,1)
      else zone:SetTextColor(unpack(skin().text)) end
      if GameTooltip then GameTooltip:Hide() end
    end)
    miniRows[#miniRows+1]={frame=row,zone=zone,item=item,ready=ready,zoneButton=zoneButton}
  end
  local prev=createButton(miniWindow,'<',26,24,function()miniPage=math.max(1,miniPage-1);miniRefresh()end)
  prev:SetPoint('BOTTOMLEFT',17,16)
  local pager=textLine(miniWindow,'Page 1 / 1',125)
  pager:SetJustifyH('CENTER');pager:SetPoint('LEFT',prev,'RIGHT',9,0)
  miniWindow.pageText=pager
  createButton(miniWindow,'>',26,24,function()miniPage=miniPage+1;miniRefresh()end):SetPoint('LEFT',pager,'RIGHT',6,0)
  local version=textLine(miniWindow,'v'..VERSION,55)
  version:SetPoint('BOTTOMRIGHT',-19,19);version:SetTextColor(.54,.50,.42)
  if version.SetFont then version:SetFont(STANDARD_TEXT_FONT or 'Fonts\\FRIZQT__.TTF',9) end
  miniWindow:Hide()
  rows.registerEscapeWindow(miniWindow)
end
miniRefresh=function()
  if not miniWindow or not miniWindow:IsShown() or not DB then return end
  local entries={}
  for _,e in ipairs(DB.orders or {}) do
    if not e.complete and not e.resaleListed then
      local zone=writLocation(e)
      local item=requiredItemName(e) or 'Open sealed writ'
      entries[#entries+1]={zone=zone or 'Unknown',item=item,recordID=e.id}
    end
  end
  table.sort(entries,function(a,b)
    if a.zone~=b.zone then return a.zone:lower()<b.zone:lower() end
    return a.item:lower()<b.item:lower()
  end)
  local bagItems=requiredItemsInBags()
  for _,entry in ipairs(entries) do
    local key=requiredKey(entry.item)
    entry.inBag=(bagItems[key] or 0)>0
    if entry.inBag then bagItems[key]=bagItems[key]-1 end
  end
  local perPage=#miniRows
  local maxPage=math.max(1,math.ceil(#entries/perPage))
  miniPage=math.max(1,math.min(miniPage,maxPage))
  miniWindow.pageText:SetText('Page '..miniPage..' / '..maxPage)
  for i,row in ipairs(miniRows) do
    local entry=entries[(miniPage-1)*perPage+i]
    if entry then
      local zone=entry.zone
      local item=entry.item
      if #zone>23 then zone=zone:sub(1,21)..'..' end
      if #item>27 then item=item:sub(1,25)..'..' end
      row.zone:SetText(zone)
      row.item:SetText(item)
      -- Resolve the map at click-time so newly recorded coordinates are used
      -- immediately without copying them into the mini list or saved orders.
      local available=entry.zone~='Unknown' and entry.zone~='Not revealed' and entry.zone~=''
      row.zoneButton.recordID=available and entry.recordID or nil
      row.zoneButton.fullZone=entry.zone
      row.zoneButton:EnableMouse(available)
      if available then row.zone:SetTextColor(.72,.85,1)
      else row.zone:SetTextColor(unpack(skin().text)) end
      if entry.inBag then row.ready:Show() else row.ready:Hide() end
      row.frame:Show()
    else
      row.zoneButton.recordID=nil
      row.zoneButton.fullZone=nil
      row.zoneButton:EnableMouse(false)
      row.ready:Hide();row.frame:Hide()
    end
  end
end
setMiniMode=function(yes)
  if not window or not miniWindow then return end
  if DB.experimentalTabbedUI and rows.experimentalTabs then
    yes=not not yes
    DB.miniMode=yes
    window.miniCheckbox:SetChecked(yes)
    miniWindow.miniCheckbox:SetChecked(yes)
    if yes then
      rows.experimentalTabs.host:Hide();miniPage=1;miniWindow:Show()
    else
      miniWindow:Hide();rows.experimentalTabs.open('Tracking')
    end
    return
  end
  yes=not not yes
  DB.miniMode=yes
  window.miniCheckbox:SetChecked(yes)
  miniWindow.miniCheckbox:SetChecked(yes)
  if yes then
    miniPage=1
    window:Hide();miniWindow:Show()
  else
    miniWindow:Hide();window:Show()
  end
end
-- Alt+Shift+left-click a bagged writ to import ONE untracked copy.
-- Hook the stock container-item modified click handler, without replacing it.
local function manualBagWritClick(button,mouseButton)
  if not DB or not button then return end
  if mouseButton and mouseButton~='LeftButton' then return end
  if not (IsAltKeyDown and IsAltKeyDown() and IsShiftKeyDown and IsShiftKeyDown()) then return end
  local slot=button.GetID and button:GetID()
  local bag=button.GetBagID and button:GetBagID()
  if bag==nil and button.GetParent then
    local parent=button:GetParent()
    bag=parent and parent.GetID and parent:GetID()
  end
  if not bag or not slot then return end
  local id=bagID(bag,slot)
  local name,rep,sealed=recognize(id,bagLink(bag,slot))
  if not name then return end
  local current=bagSnapshot()
  local count=current[id] and current[id].count or 0
  local tracked=0
  for _,e in ipairs(DB.orders) do
    if not e.complete and e.bagPresent and
      (tonumber(e.itemID)==tonumber(id) or tonumber(e.openedItemID)==tonumber(id)) then
      tracked=tracked+1
    end
  end
  if count<=tracked then say('All bagged copies of '..name..' are already tracked.');return end
  local e=markWrit(id,name,rep,sealed,'Manual',nil,true,'Alt+Shift-click bag import')
  e.priceUnknown=true;e.priceSource='Manual bag import';e.manualAdded=true
  addLog('MANUAL IMPORT',e,'Added one existing bagged writ without inventing a buyout price')
  say('Added one bagged writ: '..name..' (price None).')
  if refresh then refresh() end
end
local bagClickPrimaryHooked=false
local bagClickFallbackHooked=false
local function installBagClickHook()
  if not hooksecurefunc then return end
  if not bagClickPrimaryHooked and type(ContainerFrameItemButton_OnModifiedClick)=='function' then
    hooksecurefunc('ContainerFrameItemButton_OnModifiedClick',manualBagWritClick)
    bagClickPrimaryHooked=true
  end
  if not bagClickFallbackHooked and type(ContainerFrameItemButton_OnClick)=='function' then
    hooksecurefunc('ContainerFrameItemButton_OnClick',manualBagWritClick)
    bagClickFallbackHooked=true
  end
  if (bagClickPrimaryHooked or bagClickFallbackHooked) and not bagClickHooked then
    bagClickHooked=true
    debugMessage('Alt+Shift bag click writ import hook installed')
  end
end
-- Login bag inventory can arrive later than SavedVariables. Never interpret a
-- cross-login difference as Loot/Collected: stale bag snapshots would invent a
-- second record for the same writ. While the client is loading, repeatedly
-- reconcile visible bags with records already saved, without creating rows.
-- Normal in-session BAG_UPDATE tracking resumes after the short load window.
local function restoreBagBaseline()
  local current=bagSnapshot()
  local previous=DB.lastBag
  if (DB.nextID or 0)==0 and #(DB.orders or {})==0 and (not previous or not next(previous)) then
    -- Fresh installation only: preserve original discovery of untracked writs
    -- that were already in inventory when Writ This was first installed.
    bagBefore={}
    scanChanges(true)
    return
  end
  local assigned={}
  local reused=0
  for id,item in pairs(current) do
    local remaining=math.max(0,tonumber(item.count) or 0)
    -- Prefer records known to be in bags, then previously banked/pending
    -- records. Each saved record is assigned at most once. Multiple legitimate
    -- identical copies remain distinct and keep their original costs/IDs.
    local freeGUIDs={}
    for _,guid in ipairs(item.guids or {}) do freeGUIDs[guid]=true end
    for pass=0,3 do
      for _,e in ipairs(DB.orders or {}) do
        if remaining>0 and not assigned[e] and not e.complete and
           not e.resaleSold and not e.resaleListed and
           writMatchesRecord(e,id,item.name,item.sealed) and
           ((pass==0 and freeGUIDs[e.bagGUID]) or
            ((not e.bagGUID or not item.guids) and ((pass==1 and e.acquired=='Auction House' and not e.banked) or (pass==2 and e.bagPresent) or (pass==3 and not e.bagPresent)))) then
          local guid=pass==0 and e.bagGUID or next(freeGUIDs)
          if guid then e.bagGUID=guid;freeGUIDs[guid]=nil end
          assigned[e]=true
          e.bagPresent=true
          e.banked=false
          e.writLostAt=nil
          e.sealLostAt=nil
          if id then e.itemID=id end
          remaining=remaining-1
          reused=reused+1
        end
      end
    end
    if remaining>0 then
      debugMessage('Login inventory: '..remaining..' unpaired '..tostring(item.name)..
        ' not auto-imported; Alt+Shift-click to add a genuinely missing copy')
    end
  end
  -- Do not clear unmatched records: the bag API may still be loading or the
  -- writ may be in the bank/mail. Only an observed IN-SESSION change can
  -- establish that it was moved or opened.
  bagBefore=current
  local serial={}
  for id,item in pairs(current) do serial[id]=item.count end
  DB.lastBag=serial
  debugMessage('Login inventory reconciled '..reused..' saved writ copies; no new records created')
end

-- Native minimap launcher: does not require LibDBIcon, an extra TOC file,
-- or a separate SavedVariables table. Kept in a table to stay under the
-- Classic client limit on top-level local variables.
rows.toggleFullWindow=function()
  if DB and DB.experimentalTabbedUI and rows.experimentalTabs then
    local tabs=rows.experimentalTabs
    if tabs.host:IsShown() then tabs.host:Hide()
    else
      miniWindow:Hide()
      tabs.open(tabs.active or 'Tracking')
    end
    return
  end
  if window:IsShown() then
    window:Hide()
    return
  end
  if DB.miniMode then
    setMiniMode(false)
  else
    miniWindow:Hide()
    window:Show()
  end
end

rows.updateEdgeButton=function()
    local button = rows.edgeButton
    if not DB.leftEdgeButton then
        if button then button:Hide() end
        return
    end
    if not button then
        button = CreateFrame("Button", nil, UIParent)
        rows.edgeButton = button
        button:SetSize(15, 30)
        button:SetFrameStrata("MEDIUM")
        button:SetClampedToScreen(true)
        button:RegisterForDrag("LeftButton")
        button:RegisterForClicks("LeftButtonUp")
        local bg = button:CreateTexture(nil, "BACKGROUND")
        bg:SetAllPoints()
        bg:SetColorTexture(.07, .05, .03, .94)
        local edge = button:CreateTexture(nil, "ARTWORK")
        edge:SetPoint("TOPRIGHT")
        edge:SetPoint("BOTTOMRIGHT")
        edge:SetWidth(2)
        edge:SetColorTexture(.78, .59, .23, .95)
        local label = button:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
        label:SetPoint("CENTER", -1, 0)
        function button:RefreshLabel()
            label:SetText(self.expanded and "Writ This" or (DB.leftEdgeUseW and "W" or ">"))
        end
        local function expand(open)
            button.expanded=open
            button:SetWidth(open and 94 or 15)
            button:RefreshLabel()
        end
        local function place(y)
            local height = UIParent:GetHeight()
            if height <= 0 then return end
            local half = button:GetHeight() / 2
            y = math.max(half, math.min(height - half, y))
            button:ClearAllPoints()
            button:SetPoint("LEFT", UIParent, "BOTTOMLEFT", 0, y)
            return y / height
        end
        function button:RestoreHeight()
            place((tonumber(DB.leftEdgeHeight) or .43) * UIParent:GetHeight())
        end
        local function cursorY()
            local _, y = GetCursorPosition()
            return y / UIParent:GetEffectiveScale()
        end
        local function drag(self)
            local height = place(cursorY() - self.grabOffset)
            if height then DB.leftEdgeHeight = height end
        end
        button:SetScript("OnEnter", function() expand(true) end)
        button:SetScript("OnLeave", function(self) if not self.dragging then expand(false) end end)
        button:SetScript("OnMouseDown", function(self)
            self.suppressClick = false
            self.grabOffset = cursorY() - select(2, self:GetCenter())
        end)
        button:SetScript("OnDragStart", function(self)
            self.dragging, self.suppressClick = true, true
            self:SetScript("OnUpdate", drag)
        end)
        button:SetScript("OnDragStop", function(self)
            drag(self)
            self.dragging = false
            self:SetScript("OnUpdate", nil)
            expand(self:IsMouseOver())
        end)
        button:SetScript("OnClick", function(self)
            if not self.suppressClick then rows.toggleFullWindow() end
        end)
        button:SetScript("OnHide", function(self)
            self.dragging = false
            self:SetScript("OnUpdate", nil)
            expand(false)
        end)
        UIParent:HookScript("OnSizeChanged", function()
            if button:IsShown() and not button.dragging then button:RestoreHeight() end
        end)
        expand(false)
    end
    button:RestoreHeight()
    button:Show()
end
local minimapLauncher={}
minimapLauncher.install=function()
  if not Minimap or not DB or minimapLauncher.button then return end

  local button=CreateFrame('Button','WritThisMinimapLauncher',Minimap)
  minimapLauncher.button=button
  button:SetSize(31,31)
  button:SetFrameStrata('MEDIUM')
  button:SetFrameLevel((Minimap:GetFrameLevel() or 1)+8)
  button:EnableMouse(true)
  button:RegisterForClicks('LeftButtonUp','RightButtonUp')
  button:RegisterForDrag('LeftButton')

  local icon=button:CreateTexture(nil,'ARTWORK')
  icon:SetTexture('Interface\\Icons\\INV_Scroll_03')
  icon:SetSize(19,19)
  icon:SetPoint('CENTER',button,'CENTER',0,0)
  if icon.SetTexCoord then icon:SetTexCoord(.08,.92,.08,.92) end
  local ring=button:CreateTexture(nil,'OVERLAY')
  ring:SetTexture('Interface\\Minimap\\MiniMap-TrackingBorder')
  ring:SetSize(52,52)
  ring:SetPoint('TOPLEFT',button,'TOPLEFT',0,0)
  button:SetHighlightTexture('Interface\\Minimap\\UI-Minimap-ZoomButton-Highlight')

  local function arrange(x,y)
    local radius=((Minimap:GetWidth() or 140)/2)+11
    local len=math.sqrt(x*x+y*y)
    if len<.01 then x=.8;y=-.6;len=1 end
    x=x/len;y=y/len
    button:ClearAllPoints()
    button:SetPoint('CENTER',Minimap,'CENTER',x*radius,y*radius)
    return x,y
  end
  local saved=DB.minimapPosition
  arrange(saved and tonumber(saved.x) or .8,saved and tonumber(saved.y) or -.6)

  local function updateDrag(self)
    if not GetCursorPosition or not Minimap:GetCenter() then return end
    local px,py=GetCursorPosition()
    local scale=Minimap.GetEffectiveScale and Minimap:GetEffectiveScale() or 1
    if not scale or scale<=0 then scale=1 end
    local cx,cy=Minimap:GetCenter()
    local dx,dy=px/scale-cx,py/scale-cy
    if dx*dx+dy*dy>4 then
      local x,y=arrange(dx,dy)
      DB.minimapPosition={x=x,y=y}
    end
  end
  button:SetScript('OnDragStart',function(self)
    self.isDragging=true
    self:SetScript('OnUpdate',updateDrag)
    updateDrag(self)
  end)
  button:SetScript('OnDragStop',function(self)
    self.isDragging=nil
    self:SetScript('OnUpdate',nil)
    self.lastDragEnd=clock()
  end)
  button:SetScript('OnClick',function(self,mouseButton)
    if self.isDragging or (self.lastDragEnd and clock()-self.lastDragEnd<.3) then return end
    if mouseButton=='RightButton' then
      toggleItemsBook()
    else
      rows.toggleFullWindow()
    end
  end)
  button:SetScript('OnEnter',function(self)
    if not GameTooltip then return end
    GameTooltip:SetOwner(self,'ANCHOR_LEFT')
    GameTooltip:AddLine('Writ This v'..VERSION,1,.82,.32)
    GameTooltip:AddLine('Left-click: Open / close Writ This',1,1,1)
    GameTooltip:AddLine('Right-click: History/Records',1,1,1)
    GameTooltip:AddLine('Drag: Move minimap button',.72,.72,.72)
    GameTooltip:Show()
  end)
  button:SetScript('OnLeave',function()
    if GameTooltip then GameTooltip:Hide() end
  end)
  button:SetShown(DB.minimapHidden~=true)
end
minimapLauncher.toggleVisibility=function()
  if not DB then return end
  DB.minimapHidden=not DB.minimapHidden
  if minimapLauncher.button then
    minimapLauncher.button:SetShown(not DB.minimapHidden)
  end
  say('Minimap button '..(DB.minimapHidden and 'hidden' or 'shown')..'. Use /writ minimap to toggle.')
end

-- Mailbox reminder is non-blocking and never disables the Open All action.
-- The actual sale detector always runs whether this banner is shown or not.
-- Some Forever clients hide MailFrame without a reliable MAIL_CLOSED event:
-- parenting to MailFrame and watching OnHide both stop a stale warning.
mailAlert.install=function()
  if mailAlert.frame then return end
  local f=CreateFrame('Frame','WritThisMailReminder',MailFrame or UIParent,
    BackdropTemplateMixin and 'BackdropTemplate')
  f:SetSize(515,35);f:SetFrameStrata('HIGH');f:SetFrameLevel(100)
  if f.SetBackdrop then
    f:SetBackdrop({bgFile='Interface\\Buttons\\WHITE8X8',edgeFile='Interface\\Buttons\\WHITE8X8',edgeSize=1})
    f:SetBackdropColor(.24,.08,.05,.94);f:SetBackdropBorderColor(.95,.58,.20,1)
  end
  local t=f:CreateFontString(nil,'OVERLAY','GameFontNormal')
  t:SetPoint('CENTER',f,'CENTER',0,0)
  t:SetText('PLEASE OPEN WRIT MAIL INDIVIDUALLY - NOT WITH OPEN ALL')
  t:SetTextColor(1,.85,.43)
  mailAlert.frame=f
  f:Hide()
end
mailAlert.bindMailbox=function()
  local f=mailAlert.frame
  if not f or not MailFrame then return end
  -- The MailFrame may load after addon login, so attach when it first exists.
  -- A child warning cannot remain visible after its mailbox parent is hidden.
  if f:GetParent()~=MailFrame then f:SetParent(MailFrame) end
  if mailAlert.hookedMailFrame~=MailFrame then
    mailAlert.hookedMailFrame=MailFrame
    MailFrame:HookScript('OnHide',function()
      mailOpen=false
      rows.mailMissing=nil
      rows.mailInvoiceRetryAt=nil
      if mailAlert.frame then mailAlert.frame:Hide() end
    end)
    MailFrame:HookScript('OnShow',function()
      -- MAIL_SHOW and UI OnShow can arrive in either order.
      if mailOpen then mailAlert.refresh() end
    end)
  end
end
mailAlert.refresh=function()
  if not DB then return end
  mailAlert.install()
  local f=mailAlert.frame
  if not f then return end
  mailAlert.bindMailbox()
  -- The option is authoritative; the window itself must also be onscreen.
  if mailOpen and DB.mailWarningEnabled~=false and
     MailFrame and MailFrame:IsShown() then
    f:ClearAllPoints()
    f:SetPoint('BOTTOM',MailFrame,'TOP',0,8)
    f:Show()
  else
    f:Hide()
  end
end
-- Conservative one-time recovery for legacy v3.0 wallet/invoice conflicts.
-- The ORIGINAL buyer receipt must already be attached to the same writ,
-- contain an exact AH purchase subject/item ID, and have a reliable quantity.
-- This never changes manual prices, any other unverified entry, or receipts
-- assigned to two different writs. Keeps all saved records and their IDs.
local function recoverKnownItemInvoiceConflicts()
  if not DB or not DB.orders then return end
  local references={}
  for _,e in ipairs(DB.orders) do
    if e.itemInvoiceKey then
      references[e.itemInvoiceKey]=(references[e.itemInvoiceKey] or 0)+1
    end
  end
  for _,e in ipairs(DB.orders) do
    if not e.itemManual and e.itemPriceUnknown==true and
       e.itemPriceSource=='Wallet/invoice conflict: VERIFY' and
       type(e.itemInvoiceKey)=='string' and
       references[e.itemInvoiceKey]==1 then
      local invoiceID,sender,subject,bid,buyout,qty= e.itemInvoiceKey:match(
        '^([^|]*)|([^|]*)|([^|]*)|([^|]*)|([^|]*)|([^|]*)|[^|]*$')
      local name=subject and subject:match('^[Aa]uction won:%s*(.+)$')
      local count=tonumber(qty)
      local total=tonumber(bid)
      local idOK=(tonumber(e.requiredItemID)==nil or
                  tonumber(invoiceID)==tonumber(e.requiredItemID))
      if name and sameRequired(name,requiredItemName(e)) and idOK and
         sender and sender:find('Auction House',1,true) and
         total and total>1 and count and count==math.floor(count) and
         count>=1 and count<=200 then
        local price=unitPrice(total,count)
        local oldPrice=tonumber(e.itemCost)
        if price then
          e.itemPriceWalletEstimate=oldPrice
          e.itemCost=price
          e.itemCostKnown=true
          e.itemPriceUnknown=false
          e.itemPriceVerifiedWallet=false
          e.itemPriceSource='Buyer invoice (paid)'
          e.itemAwaitingMail=false
          addLog('ITEM PRICE FIX',e,'Recovered previously attached buyer invoice '..
            fmtMoney(price)..' (prior erroneous provisional price '..
            fmtMoney(oldPrice or 0)..'); no new purchase assigned')
          debugMessage('Recovered saved buyer invoice for required item #'..
            tostring(e.id)..': '..tostring(oldPrice)..' -> '..tostring(price))
        end
      end
    end
  end
end
local function initialize()
  WritTrackerDB=WritTrackerDB or {}
  DB=WritTrackerDB
  DB.orders=DB.orders or {};DB.completed=DB.completed or {};DB.soldWrits=DB.soldWrits or {}
  DB.bookOverrides=DB.bookOverrides or {}
  DB.merchantShopScannedItems=DB.merchantShopScannedItems or {}
  DB.pouchSamples=DB.pouchSamples or {}
  DB.sharedSources=DB.sharedSources or {}
  -- Drop self-broadcasts saved by v2.9. Other players' snapshots remain intact.
  if community.pruneSelfSnapshots then community.pruneSelfSnapshots() end
  -- One-time backfill of already verified community contributors. The saved
  -- unique set grows only when a *new* sender actually uses addon messaging.
  if community.seedAllTimeUsers then community.seedAllTimeUsers() end
  if DB.bookShowCommunity==nil then DB.bookShowCommunity=false end
  if DB.bookShowDetails==nil then DB.bookShowDetails=true end
  if DB.mainShowDetails==nil then DB.mainShowDetails=true end
  if DB.miniMode==nil then DB.miniMode=false end
  if DB.listView~='posted' then DB.listView='active' end
  DB.log=DB.log or {};DB.unassigned=DB.unassigned or {}
  DB.mailInvoiceSeen=DB.mailInvoiceSeen or {}
  DB.deletedMailWrits=DB.deletedMailWrits or {}
  DB.session=DB.session or 1;DB.nextID=tonumber(DB.nextID) or 0;DB.skin=DB.skin=='Default' and 'default' or (SKINS[DB.skin] and DB.skin or 'wow')
  if DB.startOnLogin==nil then DB.startOnLogin=false end
  if DB.mailWarningEnabled==nil then DB.mailWarningEnabled=true end
  if DB.showCommands==nil then DB.showCommands=false end
  if DB.multiScreen==nil then DB.multiScreen=true end
  if DB.experimentalTabbedUI==nil then DB.experimentalTabbedUI=false end
  -- This map contains only peer-advertised versions; all existing tracking
  -- and community-user identity tables retain their previous formats.
  if type(DB.allTimeAddonVersions)~='table' then DB.allTimeAddonVersions={} end
  -- The record counter is shared by active, completed, sold and restorable rows.
  for _,group in ipairs({DB.orders,DB.completed,DB.soldWrits,DB.archivedDuplicates or {}}) do
    for _,entry in ipairs(group) do
      DB.nextID=math.max(DB.nextID,tonumber(entry.id) or 0)
    end
  end
  for _,e in ipairs(DB.orders) do
    -- GetTime is session-relative: losses from a prior login are stale.
    e.sealLostAt=nil
    if e.itemCostKnown==nil then e.itemCostKnown=tonumber(e.itemCost)~=nil and tonumber(e.itemCost)>0 or false end
    if e.itemPriceUnknown==nil then e.itemPriceUnknown=false end
    if e.priceSource=='Mail invoice' and tonumber(e.writCost)==1 then
      e.priceUnknown=true
      e.priceSource='Legacy invoice: VERIFY price'
    end
    if not e.itemID then
      for id,seal in pairs(SEALS) do if seal[1]==e.writ then e.itemID=id;break end end
      if not e.itemID and e.openedItemID then e.itemID=e.openedItemID end
    end
  end
  DB.consoleLog=DB.consoleLog or {}
  -- One-time reconciliation of exact attached buyer invoices that older 3.0
  -- builds incorrectly rejected due to AH listing quantity / wallet conflicts.
  recoverKnownItemInvoiceConflicts()
  -- This runs once on load and only repairs proven old multi-envelope lots.
  -- Unclear groups remain untouched for optional /writ repairbatch <count>.
  if WritBatch.autoRepair then WritBatch.autoRepair() end
  if GetMoney then lastMoney=GetMoney() end
  lastPouchCount,rows.lastPouchCounts=pouchBagCount()
  makeSettings();makeOrderEditor();makeBookEditor();makePouchEditor();makeReferenceLog();makeItemsBook();buildUI();buildMiniUI();resale.init();rows.initConsole()
  rows.createExperimentalTabs()
  window:HookScript('OnShow',function() rows.paint(window,rows.drawMain) end)
  miniWindow:HookScript('OnShow',function() rows.paint(miniWindow,miniRefresh) end)
  itemsBook:HookScript('OnShow',function() bookRefresh() end)
  minimapLauncher.install()
  rows.updateEdgeButton()
  mailAlert.install()
  community.syncPrefixReady=community.registerSyncPrefix()
  if community.startPresence then community.startPresence() end
  selectedID=DB.selectedID
  if not selected() then selectedID=nil end
  TIER.installHover()
  BankGuard.loginSettling=true
  BankGuard.loginUntil=clock()+6
  restoreBagBaseline()
  -- Retrospective scan on login/reload; no need to re-buy or re-add a writ.
  TIER.rescanBags(false)
  installHooks();installBagClickHook();resale.installHooks()
  refresh()
  if DB.experimentalTabbedUI then
    rows.experimentalTabs.setEnabled(true,DB.startOnLogin)
  elseif DB.startOnLogin then
    if DB.miniMode then miniWindow:Show() else window:Show() end
  end
  say(VERSION..' loaded. Merchant Favor Traders: /writ traders. Coin Pouch burst safety active.')
end
local events=CreateFrame('Frame')
for _,ev in ipairs({'ADDON_LOADED','PLAYER_LOGIN','PLAYER_LOGOUT','BAG_UPDATE_DELAYED','AUCTION_HOUSE_SHOW','AUCTION_HOUSE_CLOSED',
                   'ITEM_SEARCH_RESULTS_UPDATED','ITEM_SEARCH_RESULTS_ADDED',
                   'AUCTION_HOUSE_PURCHASE_COMPLETED','ITEM_PURCHASED','COMMODITY_PURCHASE_SUCCEEDED','COMMODITY_PURCHASE_FAILED','PLAYER_MONEY','CHAT_MSG_LOOT','GET_ITEM_INFO_RECEIVED',
                   'MAIL_SHOW','MAIL_INBOX_UPDATE','MAIL_CLOSED',
                   'AUCTION_HOUSE_AUCTION_CREATED','OWNED_AUCTIONS_UPDATED','AUCTION_CANCELED',
                   'QUEST_COMPLETE','QUEST_PROGRESS','QUEST_TURNED_IN',
                   'BANKFRAME_OPENED','BANKFRAME_CLOSED','PLAYERBANKSLOTS_CHANGED',
                   'CHAT_MSG_COMBAT_FACTION_CHANGE','CHAT_MSG_ADDON',
                   'GROUP_ROSTER_UPDATE','RAID_ROSTER_UPDATE','GUILD_ROSTER_UPDATE','FRIENDLIST_UPDATE'}) do
  events:RegisterEvent(ev)
end
-- Mail, money, bag reconciliation and purchase confirmations retain immediate
-- event handlers. Only scheduled retries and housekeeping use this clock.
rows.runMaintenance=function()
  if not DB then return end
  local now=clock()
  -- Forever's buyer invoices may be populated after the first inbox event.
  -- Retry gently while the mailbox is open, before attachments disappear.
  if mailOpen and rows.mailInvoiceRetryAt and clock()>=rows.mailInvoiceRetryAt then
    rows.mailInvoiceRetryAt=clock()+2.0
    local needsInvoice=false
    for _,entry in ipairs(DB.orders or {}) do
      if entry.itemAwaitingMail and not entry.itemInvoiceKey then
        needsInvoice=true;break
      end
    end
    if needsInvoice then scanMailInvoices() end
  end
  community.tickBackground()
  if pendingTurnIn and clock()-pendingTurnIn.at>12 then pendingTurnIn=nil end
  for i=#pendingItemEvents,1,-1 do
    local e=pendingItemEvents[i]
    if now>=(e.nextCheck or (e.at+2.5)) then
      e.nextCheck=math.min(now+1,e.at+30.01)
      local name,rep,sealed=recognize(e.id)
      local requiredName=not name and getName(e.id) or nil
      if name or (requiredName and isRequiredPurchaseName(requiredName)) then
        table.remove(pendingItemEvents,i)
        -- No guessed match from a nearby PlaceBid: a same-item auction may
        -- have a different amount, and ITEM_PURCHASED lacks an auction ID.
        do
          local recentPriced=false
          if name then
            local now=time and time() or 0
            for j=#DB.orders,1,-1 do
              local order=DB.orders[j]
              if order.acquired=='Auction House' and not order.priceUnknown and
                 writMatchesRecord(order,e.id,name,sealed) and order.auctionID and
                 now-(tonumber(order.createdEpoch) or 0)<8 then
                recentPriced=true;break
              end
            end
          end
          if recentPriced then
            debugMessage('Ignored late duplicate ITEM_PURCHASED (already has priced AH record): '..tostring(name))
          elseif name then
            -- Non-unique ITEM_PURCHASED can fire repeatedly for the same
            -- named writ. Wait for an AH confirmation or mail attachment;
            -- otherwise a single purchase may create many PRICE? rows.
            debugMessage('Unpaired ITEM_PURCHASED writ notification deferred to AH/mail: '..tostring(name))
          else
            recordRequiredPurchase(e.id,requiredName,nil,nil,'Item purchased event; price unavailable')
          end
        end
      elseif clock()-e.at>30 then
        table.remove(pendingItemEvents,i)
        debugMessage('Could not resolve purchased item ID '..tostring(e.id))
      end
    end
  end
  for auctionID,p in pairs(pendingBid) do
    if now-(p.at or 0)>120 then pendingBid[auctionID]=nil end
  end
  for auctionID,t in pairs(pendingSuccess) do
    if now-t>120 then pendingSuccess[auctionID]=nil end
  end
  for i=#sealedActions,1,-1 do
    if now-sealedActions[i].at>180 then table.remove(sealedActions,i) end
  end
end
-- At most ten maintenance passes per second, even after a long frame.
events:SetScript('OnUpdate',function()
  if not DB then return end
  local now=clock()
  if now>=(rows.nextMaintenanceAt or 0) then
    rows.nextMaintenanceAt=now+.1
    rows.runMaintenance()
  end
  if BankGuard.loginSettling and clock()>=BankGuard.loginUntil then
    restoreBagBaseline()
    BankGuard.loginSettling=false
  end
  if rows.bagInfoScanAt and clock()>=rows.bagInfoScanAt then
    rows.bagInfoScanAt=nil
    if BankGuard.open then BankGuard.schedule()
    elseif BankGuard.loginSettling then restoreBagBaseline()
    else scanChanges(false) end
  end
  if #pouchUses>0 then settlePouchEvents() end
  if BankGuard.pendingAt and clock()>=BankGuard.pendingAt then
    BankGuard.pendingAt=nil
    if BankGuard.open then scanChanges(false) end
  end
  if pendingCommodity then
    if pendingCommodity.succeeded then
      resolveCommodityPurchase()
      if pendingCommodity and clock()-(pendingCommodity.successAt or pendingCommodity.at)>10 then
        local p=pendingCommodity;pendingCommodity=nil
        local name=getName(p.id)
        if name and isRequiredPurchaseName(name) then
          recordRequiredPurchase(p.id,name,nil,nil,'Commodity purchased; wallet price not captured',p.quantity)
        end
      end
    elseif clock()-(pendingCommodity.at or 0)>30 then
      pendingCommodity=nil
    end
  end
  if resale and resale.hasPendingWork() then resale.tick() end
end)
events:SetScript('OnEvent',function(_,event,...)
  if event=='ADDON_LOADED' then
    local addonName=...
    if DB and (addonName=='Auctionator' or addonName=='AuctionCompanion') then
      rows.updateProviderChecks()
      if rows.waylaidCratesFrame and rows.waylaidCratesFrame.refreshProvider then
        rows.waylaidCratesFrame.refreshProvider()
      end
      if rows.writPrices and rows.writPrices.refreshProvider then
        rows.writPrices.refreshProvider()
      end
    end
    return
  end
  if event=='PLAYER_LOGIN' then if not DB then initialize() end;return end
  if not DB then return end
  if event=='CHAT_MSG_ADDON' then
    if community.onSyncMessage then community.onSyncMessage(...) end
    return
  end
  if event=='FRIENDLIST_UPDATE' then
    if community.scheduleFriends then community.scheduleFriends() end
    return
  end
  if event=='GROUP_ROSTER_UPDATE' or event=='RAID_ROSTER_UPDATE' or
     event=='GUILD_ROSTER_UPDATE' then
    if community.schedulePresence then community.schedulePresence() end
    return
  end
  if event=='BANKFRAME_OPENED' then
    -- Finish ordinary pending changes, then start a stable bank baseline.
    if BankGuard.loginSettling then restoreBagBaseline() else scanChanges(false) end
    BankGuard.open=true;BankGuard.prior=BankGuard.snapshot()
    BankGuard.pendingAt=nil
    debugMessage('Bank opened: writ deposits/withdrawals are transfers, not new records')
    return
  elseif event=='PLAYERBANKSLOTS_CHANGED' and BankGuard.open then
    BankGuard.schedule()
    return
  elseif event=='BANKFRAME_CLOSED' then
    if BankGuard.open then
      -- The first close event normally still exposes bank data. Flush any
      -- remaining transfer before forgetting the bank snapshot.
      if BankGuard.pendingAt then scanChanges(false) end
      BankGuard.open=false;BankGuard.prior=nil;BankGuard.pendingAt=nil
    end
    return
  end
  if resale then resale.onEvent(event,...) end
  if event=='CHAT_MSG_COMBAT_FACTION_CHANGE' then
    local msg=tostring((...) or '')
    local lower=msg:lower()
    if lower:find('azeroth commerce authority',1,true) or lower:find('durotar supply',1,true) then
      local earned=tonumber(msg:match('[Ii]ncreased by%s+(%d+)'))
      if earned and earned>0 and earned<=2000 then
        recentFactionGain={amount=earned,at=clock()}
        local e
        for i=#DB.orders,1,-1 do
          local row=DB.orders[i]
          if row.complete and not row.pouchPaid and
             row.completedClock and clock()-row.completedClock<12 then
            e=row;break
          end
        end
        if e then
          e.repEarned=earned;e.rep=earned;e.repNeedsReview=false;e.repSource='Reputation chat'
          debugMessage('Observed '..earned..' actual writ reputation for #'..e.id)
          if refresh then refresh(true) end
        end
      end
    end
  elseif event=='QUEST_COMPLETE' then
    onQuestCompleteScreen()
  elseif event=='QUEST_PROGRESS' then
    -- Capture name/quest ID before the final quest reward page when available.
    onQuestCompleteScreen()
  elseif event=='QUEST_TURNED_IN' then
    onQuestTurnedIn((...))
  elseif event=='GET_ITEM_INFO_RECEIVED' then
    local id,success=...
    if success~=false and (rows.bagItemIDs[id] or (BankGuard.open and rows.bankItemIDs[id])) then
      rows.bagInfoScanAt=rows.bagInfoScanAt or (clock()+.2)
    end
  elseif event=='BAG_UPDATE_DELAYED' then
    installBagClickHook()
    if BankGuard.open then BankGuard.schedule()
    elseif BankGuard.loginSettling then restoreBagBaseline()
    else scanChanges(false) end
  elseif event=='PLAYER_MONEY' then
    if GetMoney then
      local newMoney=GetMoney()
      local delta=lastMoney and (lastMoney-newMoney) or 0
      lastMoney=newMoney
      if resale then resale.onMoney(-delta) end
      if delta<0 then
        -- An increase in gold can be the Coin Pouch being opened. Never
        -- treat normal quest moneyReward as the pouch's value.
        local gain=-delta
        if #pouchUses>0 and clock()-pouchUses[#pouchUses].at<10 then
          table.insert(rows.pouchGains,{amount=gain,at=clock()})
          rows.pouchLastActivity=clock()
          debugMessage('Coin Pouch candidate wallet gain '..fmtMoney(gain)..
            ' (event '..#rows.pouchGains..'; awaiting bag-count verification)')
        elseif pendingPayoutWrit() and lastPouchCount>0 then
          -- A wallet event may precede BAG_UPDATE_DELAYED. Keep this briefly,
          -- but never archive from the money change alone.
          local now=clock()
          for i=#recentPouchGains,1,-1 do
            if now-recentPouchGains[i].at>=2 then table.remove(recentPouchGains,i) end
          end
          table.insert(recentPouchGains,{amount=gain,at=now})
        end
      end
      if delta>0 then
        if pendingCommodity and clock()-(pendingCommodity.at or 0)<15 and not pendingCommodity.paid then
          pendingCommodity.paid=delta
          resolveCommodityPurchase()
        end
        local possibleID
        for auctionID,p in pairs(pendingBid) do
          if not recentConfirmed[auctionID] and p.isBuyout and p.id and p.price==delta and clock()-p.at<15 then
            if possibleID then possibleID=false;break end
            possibleID=auctionID
          end
        end
        if possibleID then
          pendingBid[possibleID].walletVerified=true
          debugMessage('Gold decreased by exact AH buyout '..tostring(delta))
          confirmed(possibleID,nil,'Matched wallet deduction to AH buyout')
        end
      end
    end
  elseif event=='AUCTION_HOUSE_SHOW' then
    ahOpen=true
    installHooks();installBagClickHook();resale.installHooks()
  elseif event=='AUCTION_HOUSE_CLOSED' then
    ahOpen=false
  elseif event=='MAIL_SHOW' then
    mailOpen=true
    rows.mailInvoiceRetryAt=clock()+1
    mailAlert.refresh()
    debugMessage('Mailbox opened')
    scanMailInvoices()
    if resale then resale.onEvent('MAIL_SHOW') end
  elseif event=='MAIL_INBOX_UPDATE' then
    -- Inbox contents have refreshed; disappeared invoices may be retired.
    rows.mailInvoiceRetryAt=clock()+1
    scanMailInvoices(true)
    if mailOpen then mailAlert.refresh() end
  elseif event=='MAIL_CLOSED' then
    mailOpen=false
    rows.mailMissing=nil
    rows.mailInvoiceRetryAt=nil
    mailAlert.refresh()
  elseif event=='ITEM_SEARCH_RESULTS_UPDATED' or event=='ITEM_SEARCH_RESULTS_ADDED' then
    cacheAuctions(...)
  elseif event=='AUCTION_HOUSE_PURCHASE_COMPLETED' then
    debugMessage('AUCTION_HOUSE_PURCHASE_COMPLETED '..tostring((...)))
    confirmed(...)
  elseif event=='COMMODITY_PURCHASE_SUCCEEDED' then
    local purchasedID,quantity=...
    if not pendingCommodity and tonumber(purchasedID) then
      -- Last-resort event when the client skipped both commodity hooks.
      -- An unknown price remains unverified until a matching buyer invoice.
      pendingCommodity={id=tonumber(purchasedID),quantity=tonumber(quantity) or 1,
        at=clock(),succeeded=true,successAt=clock()}
      debugMessage('Recovered commodity success without preceding hook: '..tostring(purchasedID))
    elseif pendingCommodity then
      pendingCommodity.succeeded=true;pendingCommodity.successAt=clock()
    end
    if pendingCommodity then resolveCommodityPurchase() end
  elseif event=='COMMODITY_PURCHASE_FAILED' then
    pendingCommodity=nil
  elseif event=='ITEM_PURCHASED' then
    -- Some clients fire this without the auction ID. Never create a duplicate
    -- if the authoritative AUCTION_HOUSE_PURCHASE_COMPLETED already ran.
    local id=tonumber(...)
    if id and pendingCommodity and pendingCommodity.id==id and clock()-(pendingCommodity.at or 0)<15 then
      return -- Commodity has a dedicated success event and wallet-cost matcher.
    end
    if id then
      debugMessage('ITEM_PURCHASED id='..tostring(id))
      if (confirmedItems[id] or 0)>0 then
        confirmedItems[id]=confirmedItems[id]-1
      else
        -- Auctionator and Blizzard use PlaceBid; match the purchase's
        -- item ID with the actual amount passed at the moment of purchase.
        -- ITEM_PURCHASED provides an item ID but no reliable price/auction ID.
        -- Do not finalize a PlaceBid estimate here. Wait for an exact wallet
        -- debit, AUCTION_HOUSE_PURCHASE_COMPLETED, or matching buyer invoice.
        pendingItemEvents[#pendingItemEvents+1]={id=id,at=clock()}
        debugMessage('ITEM_PURCHASED deferred until purchase price is verified: '..tostring(id))
      end
    end
  elseif event=='CHAT_MSG_LOOT' then
    local msg=select(1,...)
    if type(msg)=='string' then
      local lower=msg:lower()
      if lower:find('you loot') or lower:find('you receive loot') then
        local id=idFromLink(msg)
        if id then lootHints[id]=clock() end
      end
    end
  elseif event=='PLAYER_LOGOUT' then
    DB.selectedID=selectedID
    local serial={};for id,e in pairs(bagBefore) do serial[id]=e.count end
    DB.lastBag=serial
  end
end)
parseMoney=function(arg)
  arg=trim(arg):lower()
  if arg:match('^%d+$') then
    local value=tonumber(arg)
    return value and value<=9007199254740991 and value or nil
  end
  local units={g=10000,s=100,c=1}
  local seen,total={},0
  while arg~='' do
    local digits,unit,rest=arg:match('^(%d+)%s*([gsc])%s*(.*)$')
    if not unit or seen[unit] then return nil end
    seen[unit]=true
    local quantity=tonumber(digits)
    if quantity>(9007199254740991-total)/units[unit] then return nil end
    total=total+quantity*units[unit]
    if total>9007199254740991 then return nil end
    arg=rest
  end
  return next(seen) and total or nil
end
SLASH_WRITTHIS1='/writ'
SLASH_WRITTHIS2='/writthis'
SLASH_WRITTHIS3='/writtracker'
SlashCmdList.WRITTHIS=function(input)
  if not DB then return end
  local rawCommand=trim(input)
  local cmd=rawCommand:lower()
  if cmd=='' or cmd=='show' then
    if DB.experimentalTabbedUI and rows.experimentalTabs then
      rows.toggleFullWindow();return
    end
    local frame=DB.miniMode and miniWindow or window
    frame:SetShown(not frame:IsShown())
    if frame:IsShown() then
      if frame==window then miniWindow:Hide() else window:Hide() end
    end
  elseif cmd:match('^duplicates%s+') then
    local arg=trim(rawCommand:sub(12))
    local archive=DB.archivedDuplicates or {}
    if arg:lower()=='undo' then
      for _,e in ipairs(archive) do
        if not entryByID(e.id) then table.insert(DB.orders,e) end
      end
      DB.archivedDuplicates={}
      rows.duplicatePreview=nil
      say('Restored '..#archive..' archived writs.')
    else
      local confirm=arg:lower()=='confirm'
      local preview=rows.duplicatePreview
      if confirm and not preview then say('Preview first with /writ duplicates <item name>.');return end
      local target=confirm and preview.name or arg
      local eligible={}
      local paid=false
      for _,e in ipairs(DB.orders) do
        if sameWritName(e.writ,target) and e.acquired=='Auction House' and
           (tonumber(e.writCost) or 0)>0 and not e.priceUnknown then paid=true end
      end
      for index=#DB.orders,1,-1 do
        local e=DB.orders[index]
        if paid and sameWritName(e.writ,target) and e.acquired=='Collected' and e.priceUnknown
           and not e.sealed and not e.complete and not e.banked and not e.openedAt and not e.manualAdded
           and not e.bagGUID and not e.resaleListed and not e.resaleSold and not e.resaleLastPostAt
           and not e.itemCostKnown and not e.itemManual and not e.auctionID and not e.itemInvoiceKey
           and (tonumber(e.itemPurchases) or 0)==0 and (tonumber(e.writCost) or 0)==0 and (tonumber(e.itemCost) or 0)==0 then
          if not confirm or preview.ids[e.id] then
            eligible[#eligible+1]=e.id
            if confirm then table.insert(archive,table.remove(DB.orders,index)) end
          end
        end
      end
      if confirm then
        DB.archivedDuplicates=archive
        rows.duplicatePreview=nil
        say('Archived '..#eligible..' copies. Restore with /writ duplicates undo.')
      else
        local ids={}
        for _,id in ipairs(eligible) do ids[id]=true end
        rows.duplicatePreview={ids=ids,name=target}
        say(target..': '..#eligible..' unpriced Collected copies eligible. /writ duplicates confirm to archive.')
      end
    end
    if refresh then refresh() end
  elseif cmd:match('^repairsale%s+') then resale.repairSale(trim(rawCommand:sub(12)))
  elseif cmd=='minimap' then minimapLauncher.toggleVisibility()
  elseif cmd=='mailwarning on' or cmd=='mailwarning off' then
    DB.mailWarningEnabled=(cmd=='mailwarning on')
    if settings and settings.mailWarningCheckbox then settings.mailWarningCheckbox:SetChecked(DB.mailWarningEnabled) end
    mailAlert.refresh()
  elseif cmd=='mini' then setMiniMode(true)
  elseif cmd=='full' then setMiniMode(false)
  elseif cmd=='settings' then settings:SetShown(not settings:IsShown())
  elseif cmd=='tabs on' or cmd=='tabs off' then
    if rows.experimentalTabs then
      rows.experimentalTabs.setEnabled(cmd=='tabs on',true)
      say('Experimental Tabbed UI '..(cmd=='tabs on' and 'ON' or 'OFF')..'.')
    end
  elseif cmd=='writs' then rows.toggleWritPrices()
  elseif cmd=='repchart' or cmd=='rep chart' or cmd=='reputation' then rows.toggleRepChart()
  elseif cmd=='crates' or cmd=='waylaid' or cmd=='waylaid crates' then rows.toggleWaylaidCrates()
  elseif cmd=='traders' or cmd=='shop' or cmd=='vendors' or cmd=='favor' then rows.toggleMerchantShop()
  elseif cmd=='scantrader' or cmd=='traderscan' then rows.merchantShopScanner.scan(true)
  elseif cmd=='commands' or cmd=='help' then settings.showCommandList()
  elseif cmd=='items' or cmd=='locations' or cmd=='book' then toggleItemsBook()
  elseif cmd=='active' or cmd=='listed' or cmd=='postings' then
    DB.listView=(cmd=='active') and 'active' or 'posted'
    page=1;selectedID=nil;DB.selectedID=nil
    if DB.experimentalTabbedUI and rows.experimentalTabs then
      rows.experimentalTabs.open('Tracking')
    elseif window then window:Show() end
    if refresh then refresh() end
  elseif cmd=='sold' or cmd=='sales' then resale.open()
  elseif cmd=='send' or cmd=='sync' or cmd=='share' then community.startDataSend('')
  elseif cmd=='send guild' then community.startDataSend('guild')
  elseif cmd=='send group' or cmd=='send party' then community.startDataSend('group')
  elseif cmd:match('^send%s+') then community.startDataSend(rawCommand:match('^%S+%s+(.+)$'))
  elseif cmd=='console' or cmd=='diagnostics' or cmd=='logconsole' then
    if rows.openConsole then rows.openConsole() end
  elseif cmd=='syncposts' or cmd=='sync posts' then
    resale.requestOwnedSync()
  elseif cmd=='inspectposts' or cmd:match('^inspectposts%s+') then
    resale.inspectPosts(trim(rawCommand:sub(13)))
  elseif cmd=='unpost' then
    local e=selected()
    if e and e.resaleListed then
      say('Only if this entry is NOT actually posted: /writ unpost confirm '..tostring(e.id))
    else say('Select the incorrect row under Posted Writs first.') end
  elseif cmd:match('^unpost%s+confirm%s+%d+$') then
    resale.manualUnpost(selected(),tonumber(cmd:match('^unpost%s+confirm%s+(%d+)$')))
  elseif (cmd:match('^posted%s+') or cmd:match('^expired%s+') or cmd:match('^cancell?ed%s+'))
      and not parseMoney(cmd:match('^%S+%s+(.+)$')) then
    say('Enter an amount such as 1g25s or a whole number of copper.')
  elseif cmd=='posted' or cmd:match('^posted%s+') then
    resale.manualPosted(selected(),parseMoney(cmd:match('^posted%s+(.+)$') or ''))
  elseif cmd=='expired' or cmd:match('^expired%s+') then
    resale.manualReturn(selected(),'Expired',parseMoney(cmd:match('^expired%s+(.+)$') or ''))
  elseif cmd=='cancelled' or cmd=='canceled' or cmd:match('^cancell?ed%s+') then
    resale.manualReturn(selected(),'Cancelled',parseMoney(cmd:match('^%S+%s+(.+)$') or ''))
  elseif cmd=='startup on' then
    DB.startOnLogin=true
    if settings and settings.startupCheckbox then settings.startupCheckbox:SetChecked(true) end
    say('Open on Login ON')
  elseif cmd=='startup off' then
    DB.startOnLogin=false
    if settings and settings.startupCheckbox then settings.startupCheckbox:SetChecked(false) end
    say('Open on Login OFF')
  elseif cmd:match('^repairbatch%s+%d+$') then
    local qty=tonumber(cmd:match('^repairbatch%s+(%d+)$'))
    local e=selected()
    if e and e.priceUnknown then
      say('Select the PRICED sealed-writ entry before using /writ repairbatch '..tostring(qty)..'.')
    else
      local ok,message=WritBatch.repair(e,qty,false)
      say((ok and '|cFF8EE49F' or '|cFFFF8A8A')..(message or 'Unable to repair this batch.')..'|r')
    end
  elseif cmd=='tierscan' or cmd=='tier scan' or cmd=='rep scan' then TIER.rescanBags(true)
  elseif cmd=='scan' then scanChanges(false);TIER.rescanBags(false);say('Bag scan complete; tracking active.')
  elseif cmd=='size reset' then
    window:SetSize(BASE_W,BASE_H);DB.mainWidth=BASE_W;DB.mainHeight=BASE_H
  elseif cmd=='debug on' then
    DB.debugEnabled=true;settings.muteDebug:SetChecked(false);say('Debug ON. AH events and invoice values will appear in chat.')
  elseif cmd=='debug off' then
    DB.debugEnabled=false;settings.muteDebug:SetChecked(true);say('Debug OFF.')
  elseif cmd=='debug' then
    say('Last debug events (newest first):')
    for i=1,math.min(12,#(DB.debugLog or {})) do say(DB.debugLog[i]) end
  elseif cmd=='finish' or cmd=='complete' then
    local e=selected()
    if e and not e.complete and not e.sealed then
      finishWrit(e,'Manually confirmed completion',nil)
    else say('Select an opened, active writ to mark completed.') end
  elseif cmd:match('^payout%s+') or cmd:match('^pouch%s+') then
    local amount=parseMoney(cmd:match('^%S+%s+(.+)$'))
    local e=selected()
    if e and e.complete and not e.pouchPaid and amount and amount>0 then
      archivePouch(e,amount,'Manual payout correction')
    else say('Select a completed writ awaiting Coin Pouch, then /writ payout 25s.') end
  elseif cmd:match('^rep%s+') then
    local e=selected()
    local amount=tonumber(cmd:match('^rep%s+(%d+)$'))
    if e and amount and amount>=1 and amount<=10000 then
      e.rep=math.floor(amount)
      e.repNeedsReview=false
      e.repSource='Manual correction'
      addLog('REP',e,'Reputation set to '..tostring(e.rep))
      refresh();say('Reputation to earn for '..e.writ..' set to '..e.rep..'.')
    else
      say('Select a writ first, then use /writ rep 75, /writ rep 125, or /writ rep 200.')
    end
  elseif cmd:match('^itemcost%s+') then
    local e=selected()
    local v=parseMoney(cmd:match('^itemcost%s+(.+)$'))
    if e and v then
      e.itemCost=v;e.itemCostKnown=true;e.itemPriceUnknown=false
      e.itemPurchases=math.max(1,tonumber(e.itemPurchases) or 0)
      e.itemManual=true;e.itemAwaitingMail=false
      addLog('ITEM PRICE',e,'Required item cost corrected to '..fmtMoney(v))
      refresh();say('Required item cost for '..e.writ..': '..fmtMoney(v))
    else say('Select a writ first, then type /writ itemcost 15s50c.') end
  elseif cmd:match('^price%s+') then
    local e=selected()
    local v=parseMoney(cmd:match('^price%s+(.+)$'))
    if e and v then
      e.writCost=v;e.priceUnknown=false;e.priceSource='Manual correction'
      addLog('PRICE',e,'Purchase cost corrected to '..fmtMoney(v))
      refresh();say('Updated '..e.writ..' to '..fmtMoney(v))
    else say('Select a writ first, then use /writ price 20s50c (or a copper value).') end
  elseif cmd=='history' then
    say('Most recent paid completions (newest first):')
    local records=DB.completed or {}
    if #records==0 then say('No Coin Pouch payouts archived yet.') end
    for i=#records,math.max(1,#records-7),-1 do
      local e=records[i]
      say(tostring(e.writ)..' | Total: '..(e.totalCost and fmtMoney(e.totalCost) or 'None')..
        ' | Pouch: '..fmtMoney(e.pouchAmount or 0)..
        ' | Net: '..(e.netCost and fmtNetMoney(e.netCost) or 'None')..
        ' | Rep: '..tostring(e.repEarned or 'Unknown'))
    end
  elseif cmd=='status' then
    say('Tracking ACTIVE | '..#DB.orders..' writs recorded | AH hook '..(auctionHooked and 'ready' or 'unavailable')..' | Seal-use hook '..(sealedHooked and 'ready' or 'unavailable'))
  else say('Use /writ commands to see every available Writ This command in Settings.') end
end
