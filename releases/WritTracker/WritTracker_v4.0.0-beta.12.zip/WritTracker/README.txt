Writ This 4.0.0-beta.12 — WoW Forever (Interface 16001)

Stability fixes in Beta 12:
- Writs' AC winner uses only two verified quotes from the current Writs Live Scan.
  An incomplete, cancelled, old or missing scan remains provisional. The
  WINNER label requires full live catalogue coverage; cached AC prices remain
  visible estimates and cannot certify the winner.
- AC price sources now distinguish cached search and cached snapshot quotes.
  The selected-provider toggle and Auctionator-only support are unchanged.
- Classic/Tabbed toggles install window size and hide hooks just once, even
  after repeated switching. No SavedVariables migration or reset is needed.

AC Live Scan All remains a read-only scan; Search Both remains interactive.
The original Auctionator Shopping workflows are available independently.
Please back up SavedVariables and test in game before distributing as stable.

Historical changelog from the original bundled README:

Writ This 3.5.22 for WoW Forever (Interface 16001)

3.5.22 tracks the three writ Coin Pouch reward IDs and matches known tiers during payout.

3.5.21 reorders the main footer and renames Items & Locations to History/Records.

3.5.20 adds a searchable turn-in NPC and a Map button to Writs.

3.5.19 keeps the Writs window open when using Search both at AH.

3.5.18 shows turn-in locations on AH writ rows. Sort by Location for the cheapest total first in each zone.

3.5.17 marks personal daily turn-ins in the AH list and skips them for Winner. Shift-click a row for Items & Locations.

3.5.16 adds Commands beside Settings. Duplicate sale and active writ commands appear first.

3.5.15 checks for a matching unpriced seller receipt during manual sale entry.
Use /writ repairsale Cindercloth Robe to review an existing duplicate pair.

3.5.14 adds a per-character Hide banked checkbox to the Active Writs list.

3.5.13 adds the Writs AH Winner. Click to select the lowest cost per 100
reputation across fully priced writs with known rewards. Shift-click to copy.

3.5.12 batches tracking-driven window redraws per frame and repaints hidden
windows when opened. Purchases, receipts and bag events are processed immediately.

3.5.11 reduces idle maintenance and skips empty resale, pouch and sync queues.

3.5.10 adds Scan all at AH and separate missing-price filters. Scan all searches
the complete catalogue through Auctionator, including hidden rows.

3.5.9 reads exact-name AH browse results for writs and required items and saves
their item IDs for later Auctionator lookups. Browse quotes last one AH visit.

3.5.8 adds Writs beside Reputation and Crates. Compare cached Auctionator prices
for one named writ plus one required item, or search the pair at the AH.
Settings is in the main header. Reset Data is inside Settings.

3.5.7 tracks named writs by physical item identity when the client supplies it.
For legacy unpriced copies, run /writ duplicates Cindercloth Robe to preview,
then /writ duplicates confirm to archive. /writ duplicates undo restores all
archived rows. Results are also available in the Writ This console.

Install the WritTracker folder in Interface/AddOns, then /reload.
The folder name and per-character WritTrackerDB are the same as in 3.4.3.

Open Writ This with /writ. Open Settings for the skin selector, Solid windows,
Start on Login, Multi-Screen, command list, and keybind list.
Skin and window opacity are saved per character.

Payouts are matched to the oldest eligible completed writ. If several wallet
gains or pouch openings make the amount ambiguous, the writ stays pending.
To record a verified payout yourself, Shift+Middle-click its awaiting-payout
row, enter the actual amount (for example 1g25s), and confirm.

Enable Left-edge launcher in /writ settings. Hover to expand the tab, click
to toggle the full tracker, or drag it vertically to save its position.
Use Settings beside Left-edge launcher to choose W for the collapsed tab.
