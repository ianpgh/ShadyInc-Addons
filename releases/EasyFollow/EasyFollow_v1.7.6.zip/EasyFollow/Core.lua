-- EasyFollow 1.7.6 - WoW Forever (1.60.1)
-- One secure /follow button per party member, plus sit/stand and mount buttons for self.
-- 1.7.6: Reject secret frame values before scoring or geometry checks.
-- 1.7.5: Limit expensive generic frame searches with a shared scan cache,
-- reuse stable ClickCleanse/FrameSwitch anchors, debounce mount-aura work,
-- and reduce continuous range checks without changing any click actions.
-- 1.3.0: Follow event indicator, colorblind-safe marker, hover feedback,
-- utility-button gap command, and S/M centered under the player's ClickCleanse icon.
-- 1.4.0: Opt-out smart follow: recognize mount auras outside combat,
-- first click mounts if a party member is riding; next click follows.
-- WoW blocks deferred protected /follow, so never auto-follow after a timer.
-- 1.5.0: /ef bind X|Z (also supports modifiers) to securely click M.
-- 1.5.1: S alternates /sit and /stand on successive clicks (either mouse button).
-- 1.6.0: /ef modify opens a small translucent editor for S right-click.
-- Custom slash commands are saved and executed by the protected right-click
-- action; left-click still alternates sit/stand. Clear resets the old behavior.
-- 1.6.1: Stable party layout: never park F at arbitrary screen coordinates,
-- do not chain F/S/M to ClickCleanse's temporary parked frames, and defer
-- roster repositioning until third-party party frames have settled.
-- 1.6.2: Prefer ClickCleanse's own verified anchor frame for every button.
-- F stays adjacent to its teammate's C square; S/M center BELOW the player's.
-- Parked/unready C squares cause a brief hide instead of a wrong fallback.
-- 1.6.3: Fix reordering regression: player/party controls are anchored with
-- CC's ACTUAL SetPoint relative frame/point, not a measured screen coordinate.
-- F stays under partyN's ClickCleanse square; S/M stay under player's square.
-- 1.6.4: If a party member's ClickCleanse square is still parked or cannot be
-- resolved, anchor to that SAME party unit's verified visible unit frame instead
-- of hiding the F indefinitely. CC remains the preferred anchor whenever ready.
-- 1.6.5: Self-healing visibility and anchors. Previous one-shot roster retry
-- schedule stopped after eight seconds, leaving some missing buttons hidden
-- indefinitely until /reload. A slow, conditional recovery check now retries
-- only when a visible party unit's control is missing, hidden or misanchored.
-- Re-sync secure driver visibility after restoring an anchor; never change
-- protected frame positions or visibility from insecure code during combat.
-- 1.6.6: Follow the matching ClickCleanse square DIRECTLY, after verifying it
-- is attached, so asynchronous movement/resize doesn't leave F behind.
-- When that square is temporarily unavailable, the verified-party fallback
-- reproduces ClickCleanse's square geometry before positioning F BELOW it,
-- rather than drawing F over the ClickCleanse square.
-- /ef unbind removes only the addon override; choice persists over reloads.
-- Independent from ClickCleanse. If ClickCleanse is installed, follow buttons
-- sit immediately OUTSIDE its squares, using the same row/unit alignment.
-- No automatic follow, background movement, or target manipulation.

local ADDON_NAME = ...
local PREFIX = "|cff44d7a5[EasyFollow]|r "
local PLAYER_UNIT = "player"
local MOUNT_KEY = "easyfollow_mount"
local PARTY_UNITS = { "party1", "party2", "party3", "party4" }
local SIDE = {
    left   = { point = "RIGHT", relPoint = "LEFT",   x = -4, y = 0 },
    right  = { point = "LEFT",  relPoint = "RIGHT",  x =  4, y = 0 },
    top    = { point = "BOTTOM",relPoint = "TOP",    x =  0, y = 4 },
    bottom = { point = "TOP",   relPoint = "BOTTOM", x =  0, y = -4 },
}

local db
local buttons = {}
local inspectButtons = {}
local lastInspect = -100
local InspectPartyMember
local pendingLayout = false
local refreshQueued = false
local rosterRefreshGeneration = 0
local RECOVERY_CHECK_SECONDS = 2.75
local lastAnchor = {}
-- FrameSwitch can move/reorder party frames without requiring a new
-- EnumerateFrames walk. Cache only VERIFIED matching frames, and never keep
-- an old match after a roster change. One fallback sweep serves all units.
local FRAME_SCAN_INTERVAL = 8
local FRAME_SCAN_LIMIT = 6000
local frameCache = {}
local lastGenericScanTime = -10000
local genericScanCount = 0
local FRAME_SCAN_UNITS = { PLAYER_UNIT, "party1", "party2", "party3", "party4" }
local followingName = nil  -- Set ONLY by AUTOFOLLOW_BEGIN/END, not guesses on clicks.
local FOLLOW_MARKER_SIZE = 6
local pendingSmartUpdate = false
local ApplyMountBinding -- assigned after layout function (needs the M button)
local mountBindingOwner = CreateFrame("Frame", "EasyFollowMountBindingOwner", UIParent)
local activeMountBinding = nil
local pendingBindingUpdate = false
local warnedBindingAPI = false
local pendingSitRightUpdate = false

local function Message(msg)
    if DEFAULT_CHAT_FRAME then
        DEFAULT_CHAT_FRAME:AddMessage(PREFIX .. tostring(msg))
    end
end

local function GetDB()
    if not db then
        if type(_G.EasyFollowDB) ~= "table" then
            _G.EasyFollowDB = {}
        end
        db = _G.EasyFollowDB
    end
    if type(db.size) ~= "number" or db.size < 14 or db.size > 70 then db.size = 23 end
    if not SIDE[db.side] then db.side = "left" end
    if type(db.enabled) ~= "boolean" then db.enabled = true end
    for _, key in ipairs({"showFollow", "showInspect", "showSit", "showMount"}) do
        if type(db[key]) ~= "boolean" then db[key] = true end
    end
    if type(db.useClickCleanse) ~= "boolean" then db.useClickCleanse = true end
    if type(db.mountName) ~= "string" then db.mountName = "" end
    if type(db.mountBind) ~= "string" then db.mountBind = "" end
    if type(db.sitRightCommand) ~= "string" or #db.sitRightCommand > 255
        or db.sitRightCommand:find("[%c]")
        or (db.sitRightCommand ~= "" and db.sitRightCommand:sub(1, 1) ~= "/") then
        db.sitRightCommand = ""
    end
    if db.skin ~= "wow" and db.skin ~= "teal" and db.skin ~= "ac" then db.skin = "teal" end
    if db.skin == "ac" then db.skin = "wow" end
    if type(db.smartFollow) ~= "boolean" then db.smartFollow = true end
    if type(db.utilityGap) ~= "number" or db.utilityGap < 0 or db.utilityGap > 24 then
        db.utilityGap = 3
    end
    return db
end

-- Configure the S button's right-click protected macro ONLY out of combat.
-- Empty means its legacy behavior: both mouse buttons alternate sit/stand.
-- The secure PreClick handler controls left-click independently and will never
-- overwrite a custom right-click command.
local function ApplySitRightCommand()
    if InCombatLockdown() then
        pendingSitRightUpdate = true
        return false
    end
    local sit = buttons[PLAYER_UNIT]
    if not sit then
        pendingSitRightUpdate = true
        return false
    end
    local custom = GetDB().sitRightCommand
    sit:SetAttribute("ef_rightCustom", custom ~= "")
    if custom ~= "" then
        sit:SetAttribute("macrotext2", custom)
    else
        -- Reset the right-click action to the NEXT posture action, not /sit
        -- unconditionally: this retains the current toggle sequence.
        local nextSit = sit:GetAttribute("ef_nextSit")
        sit:SetAttribute("macrotext2", nextSit and "/sit" or "/stand")
    end
    pendingSitRightUpdate = false
    return true
end

local function GetMountMacro()
    local name = GetDB().mountName
    if name ~= "" then
        -- Use a learned mount spell or a mount item by its exact name.
        -- /use only runs while unmounted, so the same button can also dismount.
        return "/use [nomounted] " .. name .. "\n/dismount [mounted]"
    end
    -- Forever 1.60.1 supports C_MountJournal.SummonByID(0):
    -- summons a random favorite mount or dismisses your current mount.
    return "/run C_MountJournal.SummonByID(0)"
end

-- When the target is visibly mounted, a single click cannot both wait for
-- a mount cast to complete AND issue /follow: WoW protects deferred movement.
-- Instead use secure macro conditionals. While on foot it mounts and stops;
-- once mounted the NEXT click follows. In combat it always follows.
local function GetSmartFollowMacro(unit)
    local mountName = GetDB().mountName
    if mountName ~= "" then
        return "/use [nocombat,nomounted] " .. mountName
            .. "\n/stopmacro [nocombat,nomounted]\n/follow " .. unit
    end
    return "/run if not IsMounted() and not InCombatLockdown() then C_MountJournal.SummonByID(0) end"
        .. "\n/stopmacro [nocombat,nomounted]\n/follow " .. unit
end

local function ReadableValue(value, expectedType)
    if _G.issecretvalue and _G.issecretvalue(value) then return false end
    if _G.canaccessvalue and not _G.canaccessvalue(value) then return false end
    return not expectedType or type(value) == expectedType
end

local function SafeVisible(frame)
    if not frame then return false end
    local ok, result = pcall(function()
        return frame:IsShown() == true and frame:IsVisible() == true
    end)
    return ok and result == true
end

local function SafeUnitExists(unit)
    local ok, exists = pcall(function() return UnitExists(unit) == true end)
    return ok and exists == true
end

local function SafeUnitName(unit)
    local ok, name = pcall(UnitName, unit)
    if not ok or type(name) ~= "string" then return nil end
    if _G.canaccessvalue and not _G.canaccessvalue(name) then return nil end
    return name
end

-- There is no generally exposed Blizzard party-unit equivalent of IsMounted().
-- Outside combat we can recognize a mount buff with the journal spell-ID
-- mapping. This may miss special mounts, mounts unavailable to the journal,
-- or auras the client marks secret. In those cases we keep ordinary /follow.
-- Never infer a positive result from an unreadable aura.
local function IsKnownPartyMount(unit)
    if InCombatLockdown() then return nil end
    -- Some alternate builds may provide this helper; ordinary Forever does not.
    if type(_G.UnitIsMounted) == "function" then
        local ok, result = pcall(_G.UnitIsMounted, unit)
        if ok and type(result) == "boolean" then return result end
    end
    local auras = _G.C_UnitAuras
    local journal = _G.C_MountJournal
    if not auras or not auras.GetBuffDataByIndex
        or not journal or not journal.GetMountFromSpell then
        return nil
    end
    for i = 1, 60 do
        local ok, aura = pcall(auras.GetBuffDataByIndex, unit, i)
        if not ok then return nil end
        if not aura then return false end
        local spellID = aura.spellId
        if type(spellID) ~= "number" then return nil end
        if _G.canaccessvalue and not _G.canaccessvalue(spellID) then
            return nil
        end
        local found, mountID = pcall(journal.GetMountFromSpell, spellID)
        if found and type(mountID) == "number" and mountID > 0 then
            return true
        end
    end
    return false
end

-- AUTOFOLLOW_BEGIN returns a *name*, not a party unit ID. Compare display
-- names, including names with an optional realm suffix. Never display a guessed
-- follow state if the game has not sent the event since login/reload.
local function NameKey(name)
    local ok, key = pcall(function()
        if type(name) ~= "string" or name == "" then return nil end
        if _G.canaccessvalue and not _G.canaccessvalue(name) then return nil end
        return string.lower((name:match("^[^-]+") or name))
    end)
    return ok and key or nil
end

local function IsFollowedUnit(unit)
    local name = SafeUnitName(unit)
    local followKey = NameKey(followingName)
    return name and followKey and NameKey(name) == followKey or false
end

-- Follow interaction range is index 4 (roughly 28 yards).
-- Unknown/restricted results must never be treated as out of range.
local function UpdateFollowRange(button)
    if not button or not button.rangeCross then return end
    local outside = false
    if not InCombatLockdown() and SafeVisible(button) and SafeUnitExists(button.partyUnit)
        and type(CheckInteractDistance) == "function" then
        local ok, result = pcall(function()
            local value = CheckInteractDistance(button.partyUnit, 4)
            if _G.canaccessvalue and not _G.canaccessvalue(value) then return nil end
            if value == false or value == 0 then return false end
            if value == true or value == 1 then return true end
        end)
        outside = ok and result == false
    end
    if button.rangeOutside ~= outside then
        button.rangeOutside = outside
        button.rangeCross:SetShown(outside)
    end
end

local function PaintButton(button)
    if not button or not button.bg then return end
    local isFollowing = button.isFollowButton and IsFollowedUnit(button.partyUnit)
    button.isFollowing = isFollowing and true or false
    local hovered = button.isHovered == true

    if isFollowing then
        button.bg:SetColorTexture(0.17, 0.26, 0.25, 1)
    elseif hovered then
        button.bg:SetColorTexture(0.08, 0.32, 0.26, 1)
    else
        button.bg:SetColorTexture(0.035, 0.14, 0.14, 0.93)
    end

    local r, g, b = isFollowing and 1 or 0.24,
                    isFollowing and 1 or 0.83,
                    isFollowing and 1 or 0.65
    if not isFollowing and hovered then r, g, b = 0.65, 1, 0.85 end
    if button.borderEdges then
        for _, edge in ipairs(button.borderEdges) do
            edge:SetColorTexture(r, g, b, 1)
            edge:SetShown(true)
        end
    end

    -- Cosmetic regions only: never alter protected actions or anchors.
    local styled = GetDB().skin == "wow" or GetDB().skin == "ac"
    if button.acBase then
        local baseR, baseG, baseB = 0.30, 0.06, 0.06
        local topR, topG, topB, topA = 0.82, 0.50, 0.18, 0.18
        local goldR, goldG, goldB = 0.93, 0.73, 0.28
        local textR, textG, textB = 1.00, 0.90, 0.58
        if hovered then
            baseR, baseG, baseB = 0.38, 0.09, 0.09
            topR, topG, topB, topA = 0.95, 0.60, 0.24, 0.24
            goldR, goldG, goldB = 0.98, 0.80, 0.36
            textR, textG, textB = 1.00, 0.94, 0.68
        end
        if isFollowing then
            baseR, baseG, baseB = 0.42, 0.11, 0.08
            topR, topG, topB, topA = 1.00, 0.68, 0.30, 0.30
            goldR, goldG, goldB = 1.00, 0.84, 0.42
            textR, textG, textB = 1.00, 0.96, 0.72
        end
        button.acBase:SetColorTexture(baseR, baseG, baseB, 0.98)
        button.acTopGlow:SetColorTexture(topR, topG, topB, topA)
        button.acBottomShade:SetColorTexture(0, 0, 0, 0.28)
        if button.acInnerEdges then
            for _, edge in ipairs(button.acInnerEdges) do
                edge:SetColorTexture(goldR, goldG, goldB, 1)
                edge:SetShown(styled)
            end
        end
        if button.acOuterEdges then
            for _, edge in ipairs(button.acOuterEdges) do edge:SetShown(styled) end
        end
        button.acBase:SetShown(styled)
        button.acTopGlow:SetShown(styled)
        button.acBottomShade:SetShown(styled)
        button.bg:SetShown(not styled)
        for _, edge in ipairs(button.borderEdges) do edge:SetShown(not styled) end
        if styled then button.font:SetTextColor(textR, textG, textB, 1)
        else button.font:SetTextColor(0.70, 1, 0.91, 1) end
    end
    if button.followMarker then
        button.followMarker:SetShown(isFollowing and true or false)
    end
    if button.smartMountMarker then
        local showMount = button.mountDetected and GetDB().smartFollow
            and not InCombatLockdown()
        local ok, mounted = pcall(IsMounted)
        if ok and mounted == true then showMount = false end
        button.smartMountMarker:SetShown(showMount and true or false)
    end
end

local function UpdateFollowIndicators()
    for _, unit in ipairs(PARTY_UNITS) do
        if buttons[unit] then PaintButton(buttons[unit]) end
    end
end

-- Rebind the protected F buttons only outside combat. Avoid changing an
-- attribute unless its content actually differs. This is event-driven rather
-- than scanning four teammates continuously.
local function UpdateSmartFollowActions(changedUnit)
    if InCombatLockdown() then
        pendingSmartUpdate = true
        return
    end
    pendingSmartUpdate = false
    local smartEnabled = GetDB().smartFollow
    for _, unit in ipairs(PARTY_UNITS) do
        local button = (not changedUnit or changedUnit == unit) and buttons[unit] or nil
        if button then
            local detected = smartEnabled and SafeUnitExists(unit)
                and IsKnownPartyMount(unit) == true
            button.mountDetected = detected and true or false
            local macro = button.mountDetected and GetSmartFollowMacro(unit)
                or ("/follow " .. unit)
            if button.currentFollowMacro ~= macro then
                button:SetAttribute("macrotext1", macro)
                button.currentFollowMacro = macro
            end
            PaintButton(button)
        end
    end
end

local function FrameUnit(frame)
    if not frame then return nil end
    local ok, unit = pcall(function()
        local value = frame.unit
        if ReadableValue(value, "string") then return value end
        value = frame.displayedUnit
        if ReadableValue(value, "string") then return value end
    end)
    if ok and unit then return unit end
    if frame.GetAttribute then
        local attrOK, value = pcall(frame.GetAttribute, frame, "unit")
        if attrOK and ReadableValue(value, "string") then return value end
    end
    return nil
end

local function FrameMatchesUnit(frame, unit)
    local frameUnit = FrameUnit(frame)
    if not frameUnit then return false end
    local ok, matched = pcall(function()
        return frameUnit == unit or UnitIsUnit(frameUnit, unit) == true
    end)
    return ok and matched == true
end

local function GetHealthBar(frame)
    if not frame then return nil end
    local direct = frame.healthBar or frame.HealthBar or frame.healthbar
    if direct and direct.GetWidth then return direct end
    if frame.HealthBarContainer and frame.HealthBarContainer.HealthBar then
        return frame.HealthBarContainer.HealthBar
    end
    -- Unknown third-party frames: the outer secure unit button is still a
    -- safe, stable anchor. Never parent our button to it.
    return frame
end

local function FindBlizzardPartyFrame(unit)
    local compact = _G.CompactPartyFrame
    if compact then
        for _, child in ipairs({compact:GetChildren()}) do
            if SafeVisible(child) and FrameMatchesUnit(child, unit) then
                return child
            end
        end
    end
    local party = _G.PartyFrame
    if party then
        for i = 1, 4 do
            local child = party["MemberFrame" .. i]
            if child and SafeVisible(child) and FrameMatchesUnit(child, unit) then
                return child
            end
        end
    end
    return nil
end

local function FindERFFrame(unit)
    local header = _G.ERFPartyHeader
    if not header then return nil end
    for i = 1, 5 do
        local frame = header[i]
        if frame and SafeVisible(frame) and FrameMatchesUnit(frame, unit) then
            return frame
        end
    end
    return nil
end

local function FrameScore(frame)
    local nameOK, name = pcall(function() return frame:GetName() end)
    if not nameOK or not ReadableValue(name) then return -100 end
    name = type(name) == "string" and string.lower(name) or ""
    -- NEVER discover our own secure action buttons (they have a `unit`
    -- attribute). Otherwise F can be anchored to itself during a roster
    -- transition and end up at an invalid screen position.
    if name:find("easyfollow") or name:find("clickcleanse")
        or name:find("nameplate") or name:find("castbar") or name:find("aura")
        or name:find("debuff") or name:find("tooltip") then return -100 end
    local score = 0
    if name:find("dander") or name:find("erf") or name:find("ellesmere") then
        score = score + 30
    elseif name:find("party") or name:find("raid") then
        score = score + 20
    elseif name:find("unit") then
        score = score + 10
    end
    local ok, width, height = pcall(function() return frame:GetWidth(), frame:GetHeight() end)
    if not ok or not ReadableValue(width, "number") or not ReadableValue(height, "number") then return -100 end
    if ok then
        if width >= 60 and width <= 700 and height >= 15 and height <= 180 then
            score = score + 5
        end
    end
    if frame.IsObjectType then
        local buttonOK, isButton = pcall(frame.IsObjectType, frame, "Button")
        if buttonOK and ReadableValue(isButton, "boolean") and isButton then score = score + 3 end
    end
    return score
end

-- The ordinary path is a cheap lookup of ClickCleanse's unit-specific
-- square, or an ERF/Blizzard frame. Only missing/parked squares need the
-- generic fallback below. A single scan fills the cache for the whole group;
-- repeated recovery ticks must NOT walk the UI 4-5 times.
local function ValidCachedUnitFrame(unit)
    local frame = frameCache[unit]
    if frame and SafeVisible(frame) and FrameMatchesUnit(frame, unit) then
        return frame
    end
    frameCache[unit] = nil
    return nil
end

local function ScanGenericPartyFrames()
    if type(_G.EnumerateFrames) ~= "function" then return end
    local now = GetTime()
    if now - lastGenericScanTime < FRAME_SCAN_INTERVAL then return end
    lastGenericScanTime = now
    genericScanCount = genericScanCount + 1

    local winners, scores = {}, {}
    local ok, candidate = pcall(_G.EnumerateFrames)
    if not ok then return end
    local seen = 0
    while candidate and seen < FRAME_SCAN_LIMIT do
        seen = seen + 1
        if SafeVisible(candidate) then
            -- Cheaply reject non-unit frames BEFORE scoring their geometry.
            local candidateUnit = FrameUnit(candidate)
            if candidateUnit and not candidateUnit:match("^nameplate") then
                local score = FrameScore(candidate)
                if score >= 5 then
                    for _, unit in ipairs(FRAME_SCAN_UNITS) do
                        local matchedOK, matched = pcall(function()
                            return candidateUnit == unit or UnitIsUnit(candidateUnit, unit) == true
                        end)
                        if matchedOK and matched and (not scores[unit] or score > scores[unit]) then
                            winners[unit], scores[unit] = candidate, score
                        end
                    end
                end
            end
        end
        local nextOK, nextFrame = pcall(_G.EnumerateFrames, candidate)
        if not nextOK then break end
        candidate = nextFrame
    end
    for unit, frame in pairs(winners) do frameCache[unit] = frame end
end

local function FindUnitFrame(unit)
    if unit == PLAYER_UNIT and _G.ERFPartySelfButton
        and SafeVisible(_G.ERFPartySelfButton) then
        return _G.ERFPartySelfButton
    end
    local frame = FindERFFrame(unit) or FindBlizzardPartyFrame(unit)
    if frame then
        frameCache[unit] = frame
        return frame
    end
    frame = ValidCachedUnitFrame(unit)
    if frame then return frame end
    ScanGenericPartyFrames()
    frame = ValidCachedUnitFrame(unit)
    if frame then return frame end
    if unit == PLAYER_UNIT and SafeVisible(_G.PlayerFrame) then
        return _G.PlayerFrame
    end
    return nil
end

local function CreateButton(unit, index, inspectParent)
    local isInspect = inspectParent ~= nil
    local isSit = unit == PLAYER_UNIT
    local isMount = unit == MOUNT_KEY
    local visibleUnit = isMount and PLAYER_UNIT or unit
    -- S has a restricted secure PreClick toggle so the game selects /sit or
    -- /stand before executing the same secure click, including in combat.
    -- Keep existing templates for M and all F buttons unchanged.
    local template = isSit and "SecureActionButtonTemplate,SecureHandlerBaseTemplate"
        or "SecureActionButtonTemplate"
    local button
    if isInspect then
        button = CreateFrame("Button", "EasyFollow_Inspect_" .. unit, UIParent, "SecureHandlerStateTemplate")
    else
        button = CreateFrame("Button", "EasyFollow_" .. unit, UIParent, template)
    end
    button:SetSize(GetDB().size, GetDB().size)
    button:RegisterForClicks("AnyUp")
    if not isInspect then
    button:SetAttribute("useOnKeyDown", false)

    -- Fixed secure macro actions; no target switching needed for Follow.
    -- The player square is reserved for /sit rather than /follow player.
    button:SetAttribute("type1", "macro")
    button:SetAttribute("macrotext1", isMount and GetMountMacro()
        or (isSit and "/sit" or ("/follow " .. unit)))
    if isSit then
        -- Left-click toggles regardless of the configured right-click command.
        -- Until customized, right-click retains the previous shared toggle.
        button:SetAttribute("type2", "macro")
        local customRight = GetDB().sitRightCommand
        button:SetAttribute("macrotext2", customRight ~= "" and customRight or "/sit")
        button:SetAttribute("ef_rightCustom", customRight ~= "")
        button:SetAttribute("ef_nextSit", true)

        local secureToggle = [[
            local custom = self:GetAttribute("ef_rightCustom")
            if button == "LeftButton" or (button == "RightButton" and not custom) then
                local sit = self:GetAttribute("ef_nextSit")
                local action = sit and "/sit" or "/stand"
                self:SetAttribute("macrotext1", action)
                if not custom then
                    self:SetAttribute("macrotext2", action)
                end
                self:SetAttribute("ef_nextSit", not sit)
            end
        ]]
        local wrapped = false
        if type(_G.SecureHandlerWrapScript) == "function" then
            wrapped = pcall(_G.SecureHandlerWrapScript,
                button, "PreClick", button, secureToggle)
        end
        if not wrapped then
            -- Conservative compatibility fallback if this Forever build lacks
            -- restricted handlers: still toggles out of combat without tainting
            -- protected attributes during combat lockdown.
            button:SetScript("PreClick", function(self, mouseButton)
                if InCombatLockdown() then return end
                local custom = self:GetAttribute("ef_rightCustom")
                if mouseButton ~= "LeftButton"
                    and (mouseButton ~= "RightButton" or custom) then return end
                local sit = self:GetAttribute("ef_nextSit")
                local action = sit and "/sit" or "/stand"
                self:SetAttribute("macrotext1", action)
                if not custom then self:SetAttribute("macrotext2", action) end
                self:SetAttribute("ef_nextSit", not sit)
            end)
        end
    elseif not isMount then
        button:SetAttribute("type2", "target")
        button:SetAttribute("unit", unit)
        button:SetAttribute("type3", "macro")
        button:SetAttribute("macrotext3", "/follow " .. unit)
        button.currentFollowMacro = "/follow " .. unit
    end
    end -- secure actions are not used by Inspect
    button.isFollowButton = not isSit and not isMount and not isInspect
    button.partyUnit = visibleUnit

    button:SetFrameStrata("MEDIUM")
    button:SetFrameLevel(120)

    local bg = button:CreateTexture(nil, "BACKGROUND")
    bg:SetAllPoints(button)
    bg:SetColorTexture(0.035, 0.14, 0.14, 0.93)
    button.bg = bg

    local borderColor = {0.24, 0.83, 0.65, 1}
    button.borderEdges = {}
    for i = 1, 4 do
        local edge = button:CreateTexture(nil, "BORDER")
        edge:SetColorTexture(unpack(borderColor))
        button.borderEdges[i] = edge
        if i == 1 then
            edge:SetPoint("TOPLEFT", button)
            edge:SetPoint("TOPRIGHT", button)
            edge:SetHeight(1.5)
        elseif i == 2 then
            edge:SetPoint("BOTTOMLEFT", button)
            edge:SetPoint("BOTTOMRIGHT", button)
            edge:SetHeight(1.5)
        elseif i == 3 then
            edge:SetPoint("TOPLEFT", button)
            edge:SetPoint("BOTTOMLEFT", button)
            edge:SetWidth(1.5)
        else
            edge:SetPoint("TOPRIGHT", button)
            edge:SetPoint("BOTTOMRIGHT", button)
            edge:SetWidth(1.5)
        end
    end

    -- Optional AC Search-style skin: dark red face with gold bevel.
    -- Purely cosmetic; it never changes protected click actions or anchors.
    local acBase = button:CreateTexture(nil, "ARTWORK")
    acBase:SetAllPoints(button)
    acBase:SetColorTexture(0.30, 0.06, 0.06, 0.98)
    acBase:Hide()
    button.acBase = acBase

    local acTopGlow = button:CreateTexture(nil, "ARTWORK", nil, 1)
    acTopGlow:SetPoint("TOPLEFT", button, "TOPLEFT", 1, -1)
    acTopGlow:SetPoint("TOPRIGHT", button, "TOPRIGHT", -1, -1)
    acTopGlow:SetHeight(math.max(5, math.floor(GetDB().size * 0.42)))
    acTopGlow:SetColorTexture(0.82, 0.50, 0.18, 0.18)
    acTopGlow:Hide()
    button.acTopGlow = acTopGlow

    local acBottomShade = button:CreateTexture(nil, "ARTWORK", nil, 1)
    acBottomShade:SetPoint("BOTTOMLEFT", button, "BOTTOMLEFT", 1, 1)
    acBottomShade:SetPoint("BOTTOMRIGHT", button, "BOTTOMRIGHT", -1, 1)
    acBottomShade:SetHeight(math.max(4, math.floor(GetDB().size * 0.28)))
    acBottomShade:SetColorTexture(0, 0, 0, 0.28)
    acBottomShade:Hide()
    button.acBottomShade = acBottomShade

    button.acOuterEdges = {}
    for i = 1, 4 do
        local edge = button:CreateTexture(nil, "BORDER")
        edge:SetColorTexture(0.08, 0.02, 0.02, 1)
        edge:Hide()
        button.acOuterEdges[i] = edge
        if i == 1 then
            edge:SetPoint("TOPLEFT", button)
            edge:SetPoint("TOPRIGHT", button)
            edge:SetHeight(1)
        elseif i == 2 then
            edge:SetPoint("BOTTOMLEFT", button)
            edge:SetPoint("BOTTOMRIGHT", button)
            edge:SetHeight(1)
        elseif i == 3 then
            edge:SetPoint("TOPLEFT", button)
            edge:SetPoint("BOTTOMLEFT", button)
            edge:SetWidth(1)
        else
            edge:SetPoint("TOPRIGHT", button)
            edge:SetPoint("BOTTOMRIGHT", button)
            edge:SetWidth(1)
        end
    end

    button.acInnerEdges = {}
    for i = 1, 4 do
        local edge = button:CreateTexture(nil, "BORDER")
        edge:SetColorTexture(0.93, 0.73, 0.28, 1)
        edge:Hide()
        button.acInnerEdges[i] = edge
        if i == 1 then
            edge:SetPoint("TOPLEFT", button, "TOPLEFT", 1, -1)
            edge:SetPoint("TOPRIGHT", button, "TOPRIGHT", -1, -1)
            edge:SetHeight(1)
        elseif i == 2 then
            edge:SetPoint("BOTTOMLEFT", button, "BOTTOMLEFT", 1, 1)
            edge:SetPoint("BOTTOMRIGHT", button, "BOTTOMRIGHT", -1, 1)
            edge:SetHeight(1)
        elseif i == 3 then
            edge:SetPoint("TOPLEFT", button, "TOPLEFT", 1, -1)
            edge:SetPoint("BOTTOMLEFT", button, "BOTTOMLEFT", 1, 1)
            edge:SetWidth(1)
        else
            edge:SetPoint("TOPRIGHT", button, "TOPRIGHT", -1, -1)
            edge:SetPoint("BOTTOMRIGHT", button, "BOTTOMRIGHT", -1, 1)
            edge:SetWidth(1)
        end
    end

    local font = button:CreateFontString(nil, "OVERLAY", "GameFontNormal")
    font:SetPoint("CENTER", button, "CENTER", 0, 0)
    font:SetText(isInspect and "I" or (isMount and "M" or (isSit and "S" or "F")))
    font:SetTextColor(0.70, 1, 0.91, 1)
    font:SetFont("Fonts\\FRIZQT__.TTF", math.max(10, math.floor(GetDB().size * 0.62)), "OUTLINE")
    button.font = font

    if button.isFollowButton then
        -- Extra high-contrast white square, independent of class/color settings.
        -- We deliberately do NOT place new overlays on the party health bars.
        local marker = button:CreateTexture(nil, "OVERLAY")
        marker:SetColorTexture(1, 1, 1, 1)
        marker:SetSize(FOLLOW_MARKER_SIZE, FOLLOW_MARKER_SIZE)
        marker:SetPoint("TOPRIGHT", button, "TOPRIGHT", -2, -2)
        marker:Hide()
        button.followMarker = marker

        -- White M = first click will mount, not follow. Small and separate
        -- from the white top-right marker indicating an active follow.
        local mountMarker = button:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
        mountMarker:SetPoint("BOTTOMLEFT", button, "BOTTOMLEFT", 2, 1)
        mountMarker:SetFont("Fonts\\FRIZQT__.TTF", 9, "OUTLINE")
        mountMarker:SetText("M")
        mountMarker:SetTextColor(1, 1, 1, 1)
        mountMarker:Hide()
        button.smartMountMarker = mountMarker

        -- Visual-only overlay; does not intercept clicks or move secure frames.
        local cross = button:CreateFontString(nil, "OVERLAY", "GameFontNormal", 7)
        cross:SetPoint("CENTER", button, "CENTER", 0, 0)
        cross:SetFont("Fonts\\FRIZQT__.TTF", math.max(14, math.floor(GetDB().size * 0.92)), "THICKOUTLINE")
        cross:SetText("X")
        cross:SetTextColor(1, 0.2, 0.2, 1)
        cross:Hide()
        button.rangeCross = cross

    end

    button:SetScript("OnEnter", function(self)
        self.isHovered = true
        PaintButton(self)
        GameTooltip:SetOwner(self, "ANCHOR_RIGHT")
        GameTooltip:AddLine("EasyFollow", 0.35, 1, 0.72)
        if isInspect then
            GameTooltip:AddLine(SafeUnitName(unit) or "Party member", 1, 1, 1)
            GameTooltip:AddLine("Left-click: Inspect (out of combat)", 0.90, 0.95, 1)
        elseif isSit then
            GameTooltip:AddLine(SafeUnitName(unit) or "Your character", 1, 1, 1)
            GameTooltip:AddLine("Left-click: Sit / Stand (alternates)", 0.90, 0.95, 1)
            local rightCmd = GetDB().sitRightCommand
            if rightCmd ~= "" then
                local shortCmd = #rightCmd > 64 and (rightCmd:sub(1, 61) .. "...") or rightCmd
                GameTooltip:AddLine("Right-click: " .. shortCmd, 0.75, 0.92, 1)
            else
                GameTooltip:AddLine("Right-click: Sit / Stand (default)", 0.75, 0.92, 1)
            end
            GameTooltip:AddLine("Change: /ef modify", 0.65, 0.75, 0.75)
        elseif isMount then
            GameTooltip:AddLine("Left-click: Mount / Dismount", 0.90, 0.95, 1)
            local name = GetDB().mountName
            GameTooltip:AddLine(name ~= "" and ("Mount: " .. name)
                or "Mount: Random favorite", 0.75, 0.92, 1)
            local boundKey = GetDB().mountBind
            GameTooltip:AddLine(boundKey ~= "" and ("Keybind: " .. boundKey)
                or "Keybind: None (use /ef bind X)", 0.65, 1, 0.8)
            GameTooltip:AddLine("/ef mount <name> to choose a mount", 0.65, 0.75, 0.75)
        else
            GameTooltip:AddLine(SafeUnitName(unit) or ("Party member " .. index), 1, 1, 1)
            if GetDB().smartFollow and self.mountDetected then
                local ok, mounted = pcall(IsMounted)
                if ok and mounted == true then
                    GameTooltip:AddLine("Left-click: Follow (already mounted)", 0.90, 0.95, 1)
                else
                    GameTooltip:AddLine("Left-click: Mount first, click again to follow", 1, 1, 1)
                    GameTooltip:AddLine("Mounted teammate detected (out of combat)", 0.75, 0.92, 1)
                end
            else
                GameTooltip:AddLine("Left-click: Follow", 0.90, 0.95, 1)
            end
            UpdateFollowRange(self)
            if self.rangeOutside then GameTooltip:AddLine("Outside follow range", 1, 0.25, 0.25) end
            GameTooltip:AddLine("Right-click: Target", 0.90, 0.95, 1)
            GameTooltip:AddLine("Middle-click: Force Follow", 0.90, 0.95, 1)
            if IsFollowedUnit(unit) then
                GameTooltip:AddLine("FOLLOWING NOW  [white marker]", 1, 1, 1)
            end
        end
        GameTooltip:Show()
    end)
    button:SetScript("OnLeave", function(self)
        self.isHovered = false
        PaintButton(self)
        GameTooltip:Hide()
    end)

    -- Protected buttons cannot be arbitrarily shown/hidden during combat.
    -- The game's secure driver handles new/removed party members itself.
    if isInspect then
        button:RegisterForClicks("LeftButtonUp")
        button:SetScript("OnClick", function() InspectPartyMember(unit, inspectParent, button) end)
        button:Hide()
        PaintButton(button)
        return button
    end
    if _G.RegisterStateDriver then
        local condition = string.format("[group:raid] hide; [@%s,exists] show; hide", visibleUnit)
        local success = pcall(_G.RegisterStateDriver, button, "visibility", condition)
        button.hasVisibilityDriver = success
    end
    if not button.hasVisibilityDriver then
        button:SetShown(GetDB().enabled and SafeUnitExists(visibleUnit) and not IsInRaid())
    end
    PaintButton(button)
    return button
end

local function UnregisterDriver(button)
    if button.hasVisibilityDriver then
        pcall(_G.UnregisterStateDriver, button, "visibility")
        button.hasVisibilityDriver = false
    end
end

local function RegisterDriver(button)
    if button.hasVisibilityDriver then return end
    if _G.RegisterStateDriver then
        local condition = string.format("[group:raid] hide; [@%s,exists] show; hide", button.partyUnit)
        local success = pcall(_G.RegisterStateDriver, button, "visibility", condition)
        button.hasVisibilityDriver = success
    end
    if not button.hasVisibilityDriver then
        button:SetShown(SafeUnitExists(button.partyUnit) and not IsInRaid())
    end
end

local function AnchorToSide(button, anchor, side, gap)
    local a = SIDE[side]
    button:ClearAllPoints()
    local x, y = a.x, a.y
    if gap then
        local sign = (x < 0 or y < 0) and -1 or 1
        if x ~= 0 then x = sign * gap end
        if y ~= 0 then y = sign * gap end
    end
    button:SetPoint(a.point, anchor, a.relPoint, x, y)
end

-- Reject frames that exist before their layout has been finalized, and never
-- trust off-screen placeholder anchors after a party-header rebuild.
local function HasUsableGeometry(frame)
    if not SafeVisible(frame) then return false end
    local ok, x, y, w, h = pcall(function()
        local cx, cy = frame:GetCenter()
        return cx, cy, frame:GetWidth(), frame:GetHeight()
    end)
    if not ok or not ReadableValue(x, "number") or not ReadableValue(y, "number")
        or not ReadableValue(w, "number") or not ReadableValue(h, "number")
        or w < 1 or h < 1 then return false end
    local okRoot, cx, cy, rw, rh = pcall(function()
        local ux, uy = UIParent:GetCenter()
        return ux, uy, UIParent:GetWidth(), UIParent:GetHeight()
    end)
    if not okRoot or not ReadableValue(cx, "number") or not ReadableValue(cy, "number")
        or not ReadableValue(rw, "number") or not ReadableValue(rh, "number") then return false end
    return math.abs(x - cx) <= rw / 2 + 60
        and math.abs(y - cy) <= rh / 2 + 60
end

-- ClickCleanse *already resolved* the appropriate DandersFrames/party health
-- bar for a given unit. Re-resolving that unit with EnumerateFrames can pick a
-- different party/target/secure frame, causing a one-frame-wide drift. Take
-- ClickCleanse's actual attachment frame from :GetPoint() instead.
-- NEVER anchor to CC's BUTTON itself: CC can temporarily park it when the
-- roster changes. Instead copy its relative SetPoint to the health frame.
local function GetClickCleanseContext(unit)
    if not GetDB().useClickCleanse then return nil, nil, nil, "absent" end
    local cc = _G["ClickCleanse_" .. unit]
    if not cc then return nil, nil, nil, "absent" end
    -- CC permanently binds a unitToken when creating its squares. Reject
    -- mismatched/recycled controls rather than attach to another person's row.
    if cc.unitToken and cc.unitToken ~= unit then
        return nil, nil, nil, "waiting"
    end
    if cc.parked == true or not HasUsableGeometry(cc) then
        return nil, nil, nil, "waiting"
    end

    local cfg = _G.ClickCleanseDB
    local side = (type(cfg) == "table" and cfg.anchor) or "left"
    if not SIDE[side] then side = "left" end

    local ok, ref = pcall(function()
        local _, relative = cc:GetPoint(1)
        return relative
    end)
    if not ok or not ReadableValue(ref) or not ref or ref == UIParent or not HasUsableGeometry(ref) then
        return nil, nil, nil, "waiting"
    end
    local okPos, cx, cy, fx, fy, cw, ch, fw, fh = pcall(function()
        local x1, y1 = cc:GetCenter()
        local x2, y2 = ref:GetCenter()
        return x1, y1, x2, y2,
            cc:GetWidth(), cc:GetHeight(), ref:GetWidth(), ref:GetHeight()
    end)
    if not okPos or not ReadableValue(cx, "number") or not ReadableValue(cy, "number")
        or not ReadableValue(fx, "number") or not ReadableValue(fy, "number")
        or not ReadableValue(cw, "number") or not ReadableValue(ch, "number")
        or not ReadableValue(fw, "number") or not ReadableValue(fh, "number") then
        return nil, nil, nil, "waiting"
    end
    -- A real health-bar attachment must be a substantial frame, near its C.
    -- Detect temporary parking/incorrect recycling even when .parked is stale.
    if fw < 25 or fh < 3
        or math.abs(cx - fx) > fw / 2 + cw + 45
        or math.abs(cy - fy) > fh / 2 + ch + 45 then
        return nil, nil, nil, "waiting"
    end
    return cc, side, ref, "ready"
end

-- Keep the F or S anchored DIRECTLY to the *matching* ClickCleanse square.
-- The earlier approach copied cc:GetPoint() to the health-bar reference.
-- That looked right initially, but CC can re-layout or resize independently
-- during group changes without replacing its reference frame. An offset copied
-- once is then stale: some F buttons appear on TOP of the grey CC squares.
-- Verify the square is attached to a usable frame first, and never use its
-- parked position. A direct SetPoint then follows subsequent CC motion exactly.
-- M remains attached to S, which centers the two buttons under the player CC.
local function AnchorUnderClickCleanse(button, cc, ref, xShift)
    if not cc or cc.parked == true or not HasUsableGeometry(cc)
        or not HasUsableGeometry(ref) then return false end
    local wantedX = xShift or 0
    local ok, point, relative, relativePoint, x, y = pcall(function()
        return button:GetPoint(1)
    end)
    if ok and ReadableValue(point, "string") and ReadableValue(relative)
        and ReadableValue(relativePoint, "string") and ReadableValue(x, "number")
        and ReadableValue(y, "number") and point == "TOP" and relative == cc and relativePoint == "BOTTOM"
        and x == wantedX and y == -5 then
        return true -- parent frame moved; anchor already follows it
    end
    button:ClearAllPoints()
    button:SetPoint("TOP", cc, "BOTTOM", wantedX, -5)
    return true
end

-- A party square can be temporarily parked while the real unit frame exists.
-- Mirror ClickCleanse's placement in this case (same health-bar anchor, side,
-- offset and square size); then position F *below the virtual square*.
-- The previous fallback put F only 6px below the HEALTH FRAME and caused the
-- F to overlap the grey ClickCleanse square, as seen with Scotty Mac.
-- Refuse to guess a different party member or an off-screen frame.
local function AnchorUnderVerifiedUnitFrame(button, unit, xShift)
    local frame = FindUnitFrame(unit)
    if not HasUsableGeometry(frame) then return false, nil end
    if not FrameMatchesUnit(frame, unit) then return false, nil end

    local bar = GetHealthBar(frame)
    if not HasUsableGeometry(bar) then bar = frame end

    local cfg = _G.ClickCleanseDB
    local side = (type(cfg) == "table" and cfg.anchor) or "left"
    if not SIDE[side] then side = "left" end
    local squareSize = (type(cfg) == "table" and type(cfg.size) == "number"
        and cfg.size >= 10 and cfg.size <= 100) and cfg.size or 30
    local parkedSquare = _G["ClickCleanse_" .. unit]
    if parkedSquare and parkedSquare.GetWidth then
        local ok, width = pcall(parkedSquare.GetWidth, parkedSquare)
        if ok and ReadableValue(width, "number") and width >= 10 and width <= 100 then
            squareSize = width
        end
    end

    -- Reproduce the defaults in ClickCleanse's ANCHORS table, independent of
    -- where a *parked* square currently happens to be on the screen.
    local squarePoint, refPoint, dx, dy
    if side == "left" then
        squarePoint, refPoint, dx, dy = "RIGHT", "LEFT", -5, 0
    elseif side == "right" then
        squarePoint, refPoint, dx, dy = "LEFT", "RIGHT", 5, 0
    elseif side == "top" then
        squarePoint, refPoint, dx, dy = "BOTTOM", "TOP", 0, 5
    else
        squarePoint, refPoint, dx, dy = "TOP", "BOTTOM", 0, -5
    end

    -- Translate the square's anchor to its center, then down to the TOP of F.
    -- Because both positions are relative to the live health bar, the fallback
    -- moves with the party frame until ClickCleanse becomes ready again.
    if squarePoint == "RIGHT" then
        dx = dx - squareSize / 2
    elseif squarePoint == "LEFT" then
        dx = dx + squareSize / 2
    end
    if squarePoint == "TOP" then
        dy = dy - squareSize / 2
    elseif squarePoint == "BOTTOM" then
        dy = dy + squareSize / 2
    end
    button:ClearAllPoints()
    button:SetPoint("TOP", bar, refPoint,
        dx + (xShift or 0), dy - squareSize / 2 - 5)
    return true, bar, frame
end

-- Standalone mode: no ClickCleanse button exists (or /ef link is off).
-- F goes beside the unit frame; S/M go beneath the player's REAL frame,
-- centered as one group. Never park at arbitrary UIParent screen coordinates.
local function AnchorStandalone(button, unit, size, gap, side)
    local frame = FindUnitFrame(unit)
    if not HasUsableGeometry(frame) then return false, nil end
    local health = GetHealthBar(frame)
    if not HasUsableGeometry(health) then health = frame end
    if unit == PLAYER_UNIT then
        -- Declarative anchor: follow player's frame center even if the group
        -- header moves again after the refresh. M is pinned to S separately.
        button:ClearAllPoints()
        button:SetPoint("TOP", frame, "BOTTOM", -(size + gap) / 2, -6)
    else
        AnchorToSide(button, health, side)
    end
    return true, frame
end

-- Native inspection is exclusively user-click driven; no target changes.
InspectPartyMember = function(unit, follow, inspect)
    if InCombatLockdown() or not GetDB().enabled or IsInRaid() then return end
    if not GetDB().showInspect or not SafeUnitExists(unit) or not SafeVisible(inspect) or not follow.efHasAnchor then return end
    local cc, _, _, state = GetClickCleanseContext(unit)
    if follow.efAnchorKind == "clickcleanse" then
        if state ~= "ready" or cc ~= follow.efAnchorFrame then return end
    elseif not FrameMatchesUnit(follow.efUnitFrame, unit) then return end
    if not HasUsableGeometry(follow.efAnchorFrame) then return end
    if type(_G.CanInspect) ~= "function" or type(_G.InspectUnit) ~= "function" then
        Message("Native inspection is unavailable on this client.")
        return
    end
    local ok, allowed = pcall(_G.CanInspect, unit, false)
    if not ok or not allowed then Message("Cannot inspect this party member (range or availability)."); return end
    local now = GetTime()
    if now - lastInspect < 1.5 then return end
    lastInspect = now
    local opened = pcall(_G.InspectUnit, unit)
    if not opened then Message("Inspection unavailable; try again outside combat.") end
end

local function RefreshLayout()
    local settings = GetDB()
    if InCombatLockdown() then
        pendingLayout = true
        return
    end
    pendingLayout = false

    -- Each F is bound permanently to partyN. Never use a different unit's
    -- frame just because another secure frame with the same unit appears.
    -- If ClickCleanse exists but is parked, wait instead of guessing.
    for index = 0, #PARTY_UNITS do
        local unit = (index == 0) and PLAYER_UNIT or PARTY_UNITS[index]
        local button = buttons[unit]
        if not button then
            button = CreateButton(unit, index)
            buttons[unit] = button
        end

        local showPrimary = (index == 0 and settings.showSit) or (index > 0 and settings.showFollow)
        local showSecondary = (index == 0 and settings.showMount) or (index > 0 and settings.showInspect)
        if not settings.enabled or not (showPrimary or showSecondary) then
            button.efHasAnchor = false
            button.efAnchorFrame = nil
            button.efAnchorKind = nil
            button.efCCButton = nil
            button.efUnitFrame = nil
            UnregisterDriver(button)
            button:Hide()
        else
            button:SetSize(settings.size, settings.size)
            button.font:SetFont("Fonts\\FRIZQT__.TTF", math.max(10, math.floor(settings.size * 0.62)), "OUTLINE")
            if button.rangeCross then
                button.rangeCross:SetFont("Fonts\\FRIZQT__.TTF", math.max(14, math.floor(settings.size * 0.92)), "THICKOUTLINE")
            end
            local cc, ccSide, ccFrame, ccState = GetClickCleanseContext(unit)
            local anchored, reference, reason = false, nil, "waiting for ClickCleanse"
            local anchorKind, unitFrame = nil, nil
            local pairShift = -(settings.size + settings.utilityGap) / 2
            if ccState == "ready" then
                if unit == PLAYER_UNIT then
                    anchored = AnchorUnderClickCleanse(button, cc, ccFrame,
                        -(settings.size + settings.utilityGap) / 2)
                else
                    anchored = AnchorUnderClickCleanse(button, cc, ccFrame, pairShift)
                end
                reference = anchored and cc or nil
                if anchored then
                    reason = "direct matching ClickCleanse square"
                    anchorKind = "clickcleanse"
                end
            end
            if not anchored and unit ~= PLAYER_UNIT and settings.useClickCleanse then
                -- Recover F from THIS party unit's verified frame when its
                -- corresponding ClickCleanse square is parked/loading/missing.
                -- Leave S/M tied to the player's ClickCleanse square so their
                -- alignment never jumps to an unrelated default PlayerFrame.
                anchored, reference, unitFrame = AnchorUnderVerifiedUnitFrame(button, unit, pairShift)
                if anchored then
                    reason = "verified party-row fallback (CC " .. ccState .. ")"
                    anchorKind = "partyfallback"
                end
            end
            if not anchored and ccState == "absent" then
                -- No ClickCleanse square: preserve standalone layout.
                anchored, reference = AnchorStandalone(button, unit,
                    settings.size, settings.utilityGap, settings.side)
                if anchored then
                    reason = "standalone party frame"
                    anchorKind = "standalone"
                    unitFrame = reference
                end
            end

            button.efUnitFrame = anchored and unitFrame or nil
            button.efHasAnchor = anchored == true
            button.efAnchorFrame = anchored and reference or nil
            button.efAnchorKind = anchored and anchorKind or nil
            button.efCCButton = (anchored and anchorKind == "clickcleanse") and cc or nil
            if anchored then
                if showPrimary then RegisterDriver(button) else UnregisterDriver(button) end
                if reference and reference.GetFrameLevel then
                    button:SetFrameLevel(math.max(120, reference:GetFrameLevel() + 30))
                end
                lastAnchor[unit] = reason
                -- A previous waiting state explicitly hid this secure button.
                -- Re-registering a driver alone doesn't guarantee a Show until
                -- its condition is re-evaluated, so re-sync NOW out of combat.
                button:SetShown(showPrimary and SafeUnitExists(unit) and not IsInRaid())
            else
                -- No guessed positions: hide until a verified anchor appears.
                -- The periodic recovery checker will retry even if no roster
                -- event fires after ClickCleanse/DandersFrames finish loading.
                UnregisterDriver(button)
                button:Hide()
                lastAnchor[unit] = "no verified visible anchor (CC " .. tostring(ccState) .. ")"
            end
        end
        if index > 0 then
            local inspect = inspectButtons[unit]
            if not inspect then
                inspect = CreateButton(unit, index, button)
                inspectButtons[unit] = inspect
            end
            inspect:SetSize(settings.size, settings.size)
            inspect.font:SetFont("Fonts\\FRIZQT__.TTF", math.max(10, math.floor(settings.size * 0.62)), "OUTLINE")
            inspect:ClearAllPoints()
            if button.efAnchorKind == "standalone" and settings.side == "left" then
                inspect:SetPoint("RIGHT", button, "LEFT", -settings.utilityGap, 0)
            else
                inspect:SetPoint("LEFT", button, "RIGHT", settings.utilityGap, 0)
            end
            inspect:SetFrameLevel(button:GetFrameLevel() + 1)
            -- I owns its visibility independently; its position still uses F's
            -- verified anchor, even when F itself is hidden.
            if settings.enabled and settings.showInspect and button.efHasAnchor then
                RegisterDriver(inspect)
                inspect:SetShown(SafeUnitExists(unit) and not IsInRaid())
            else
                UnregisterDriver(inspect)
                inspect:Hide()
            end
        end
    end

    if pendingSitRightUpdate then ApplySitRightCommand() end

    local sit = buttons[PLAYER_UNIT]
    local mount = buttons[MOUNT_KEY]
    if not mount then
        mount = CreateButton(MOUNT_KEY, 0)
        buttons[MOUNT_KEY] = mount
    end
    if not settings.enabled or not settings.showMount or not sit.efHasAnchor or not SafeUnitExists(PLAYER_UNIT) then
        UnregisterDriver(mount)
        mount:Hide()
    else
        mount:SetSize(settings.size, settings.size)
        mount.font:SetFont("Fonts\\FRIZQT__.TTF", math.max(10, math.floor(settings.size * 0.62)), "OUTLINE")
        mount:SetAttribute("macrotext1", GetMountMacro())
        mount:ClearAllPoints()
        mount:SetPoint("LEFT", sit, "RIGHT", settings.utilityGap, 0)
        mount:SetFrameLevel(math.max(120, sit:GetFrameLevel() + 1))
        RegisterDriver(mount)
        -- Same visibility re-sync as S/F; fixes M staying hidden after S
        -- gets re-anchored following a UI rebuild.
        mount:SetShown(SafeUnitExists(PLAYER_UNIT) and not IsInRaid())
    end

    UpdateFollowIndicators()
    UpdateSmartFollowActions()
    ApplyMountBinding()
end

-- Bind to the EXACT same protected M button used for mouse clicks. This
-- means a keypress uses the selected mount and identical mount/dismount logic.
-- Override bindings are local to the addon, don't modify WoW's binding set,
-- and are cleared when EasyFollow is disabled or /ef unbind is used.
ApplyMountBinding = function()
    if InCombatLockdown() then
        pendingBindingUpdate = true
        return false
    end
    pendingBindingUpdate = false
    local settings = GetDB()
    local wanted = settings.enabled and settings.showMount and settings.mountBind or ""
    if activeMountBinding == wanted then return true end

    if type(_G.ClearOverrideBindings) ~= "function"
        or type(_G.SetOverrideBindingClick) ~= "function" then
        if wanted ~= "" and not warnedBindingAPI then
            Message("Keybinding API unavailable on this client; M remains clickable.")
            warnedBindingAPI = true
        end
        return false
    end

    -- Only clear bindings owned by EasyFollow, never the player's normal binds.
    local cleared = pcall(_G.ClearOverrideBindings, mountBindingOwner)
    if not cleared then
        Message("Couldn't update M's keybind; try /reload outside combat.")
        return false
    end
    activeMountBinding = ""
    if wanted == "" then return true end

    local mount = buttons[MOUNT_KEY]
    if not mount then
        pendingBindingUpdate = true -- created by RefreshLayout on next refresh
        return false
    end
    local setOK, result = pcall(_G.SetOverrideBindingClick,
        mountBindingOwner, true, wanted, mount:GetName(), "LeftButton")
    if not setOK or result == false then
        Message("Could not bind " .. wanted .. "; check the key and try /reload.")
        return false
    end
    activeMountBinding = wanted
    return true
end

-- Keep command syntax simple and reject invalid/unusable key names. Examples:
-- X, Z, SHIFT-X, CTRL-Z, ALT-SHIFT-M, F1-F12. Never bind to mouse buttons.
local function NormalizeMountKey(raw)
    local value = (raw or ""):upper():gsub("%s+", "")
    if value == "" or value:find("[^A-Z0-9%-]") or value:find("%-%-")
        or value:sub(1, 1) == "-" or value:sub(-1) == "-" then
        return nil
    end
    local seen, base = {}, nil
    for part in value:gmatch("[^-]+") do
        if part == "SHIFT" or part == "CTRL" or part == "ALT" then
            if seen[part] or base then return nil end
            seen[part] = true
        elseif not base then
            base = part
        else
            return nil
        end
    end
    if not base then return nil end
    if not base:match("^[A-Z]$") and not base:match("^[0-9]$")
        and not base:match("^F[1-9]$") and not base:match("^F1[0-2]$") then
        return nil
    end
    return (seen.ALT and "ALT-" or "")
        .. (seen.CTRL and "CTRL-" or "")
        .. (seen.SHIFT and "SHIFT-" or "") .. base
end

local function ScheduleRefresh(delay)
    if delay and delay > 0 then
        if C_Timer and C_Timer.After then
            C_Timer.After(delay, RefreshLayout)
        end
        return
    end
    if refreshQueued then return end
    refreshQueued = true
    if C_Timer and C_Timer.After then
        C_Timer.After(0.1, function()
            refreshQueued = false
            RefreshLayout()
        end)
    else
        refreshQueued = false
        RefreshLayout()
    end
end

-- Let the game's party header (and ClickCleanse) finish rebuilding before
-- choosing new positions. Each roster event supersedes the previous retry set.
-- Retried layouts are intentionally sparse; no perpetual OnUpdate scan.
local function ScheduleRosterSettle()
    rosterRefreshGeneration = rosterRefreshGeneration + 1
    local generation = rosterRefreshGeneration
    if C_Timer and C_Timer.After then
        for _, delay in ipairs({0.30, 0.90, 1.80, 3.00, 5.00, 8.00}) do
            C_Timer.After(delay, function()
                if generation == rosterRefreshGeneration then RefreshLayout() end
            end)
        end
    else
        ScheduleRefresh()
    end
end

-- Lightweight watchdog for late/asynchronous third-party party-frame rebuilds.
-- It DOES NOT run a full layout search in steady state: only cheap comparisons
-- of five fixed buttons and their ClickCleanse anchors. RefreshLayout() runs
-- when a control is missing, wrongly hidden, or its validated anchor changed.
-- A party header can rebuild well after the 8s roster retry window; without
-- this check such buttons could remain hidden until a UI reload.
local function NeedsLayoutRecovery()
    local settings = GetDB()
    if not settings.enabled or InCombatLockdown() or IsInRaid() then return false end

    for index = 0, #PARTY_UNITS do
        local unit = (index == 0) and PLAYER_UNIT or PARTY_UNITS[index]
        local showPrimary = (index == 0 and settings.showSit) or (index > 0 and settings.showFollow)
        local showSecondary = (index == 0 and settings.showMount) or (index > 0 and settings.showInspect)
        if SafeUnitExists(unit) and (showPrimary or showSecondary) then
            local button = buttons[unit]
            if not button or not button.efHasAnchor then return true end
            if showPrimary and not HasUsableGeometry(button) then return true end
            if not showPrimary and SafeVisible(button) then return true end
            if index > 0 and showSecondary then
                local inspect = inspectButtons[unit]
                if not HasUsableGeometry(inspect) then return true end
            end
            if button.efAnchorFrame and not HasUsableGeometry(button.efAnchorFrame) then
                return true
            end
            -- A direct CC-relative anchor moves automatically with CC's
            -- positions and size; only a changed/unusable square needs a refresh.
            if settings.useClickCleanse then
                local cc, _, _, state = GetClickCleanseContext(unit)
                if state == "ready" then
                    if button.efAnchorKind ~= "clickcleanse"
                        or button.efAnchorFrame ~= cc
                        or button.efCCButton ~= cc then
                        return true
                    end
                    local okPoint, p, rel, rp, x, y = pcall(function()
                        return button:GetPoint(1)
                    end)
                    local xShift = -(settings.size + settings.utilityGap) / 2
                    if not okPoint or not ReadableValue(p, "string") or not ReadableValue(rel)
                        or not ReadableValue(rp, "string") or not ReadableValue(x, "number")
                        or not ReadableValue(y, "number") or p ~= "TOP" or rel ~= cc
                        or rp ~= "BOTTOM" or x ~= xShift or y ~= -5 then
                        return true
                    end
                elseif button.efAnchorKind == "clickcleanse" then
                    return true
                end
            end
            if (button.efAnchorKind == "partyfallback" or button.efAnchorKind == "standalone")
                and not FrameMatchesUnit(button.efUnitFrame, unit) then
                return true
            end
        end
    end

    local sit, mount = buttons[PLAYER_UNIT], buttons[MOUNT_KEY]
    if settings.showMount and sit and sit.efHasAnchor and SafeUnitExists(PLAYER_UNIT) then
        if not mount or not SafeVisible(mount) or not HasUsableGeometry(mount) then
            return true
        end
    end
    return false
end

-- A 2.75-second check costs almost nothing when everything is healthy and
-- gives indefinite self-healing when the roster/UI changes without an event.
-- Use a single throttled OnUpdate rather than creating new recurring timers.
local recoveryFrame = CreateFrame("Frame")
local recoveryElapsed = 0
local rangeElapsed = 0
recoveryFrame:SetScript("OnUpdate", function(_, elapsed)
    rangeElapsed = rangeElapsed + (elapsed or 0)
    if rangeElapsed >= 0.75 then
        rangeElapsed = 0
        for _, unit in ipairs(PARTY_UNITS) do UpdateFollowRange(buttons[unit]) end
    end
    recoveryElapsed = recoveryElapsed + (elapsed or 0)
    if recoveryElapsed < RECOVERY_CHECK_SECONDS then return end
    recoveryElapsed = 0
    if not refreshQueued and NeedsLayoutRecovery() then
        ScheduleRefresh()
    end
end)

local auraPending = {}
local auraTimerQueued = false
local function QueueSmartFollowAura(unit)
    if not GetDB().smartFollow then return end
    if unit == PLAYER_UNIT then
        auraPending.all = true
    else
        auraPending[unit] = true
    end
    if auraTimerQueued then return end
    if not (C_Timer and C_Timer.After) then
        if unit == PLAYER_UNIT then UpdateSmartFollowActions()
        else UpdateSmartFollowActions(unit) end
        wipe(auraPending)
        return
    end
    auraTimerQueued = true
    C_Timer.After(0.25, function()
        auraTimerQueued = false
        if auraPending.all then
            wipe(auraPending)
            UpdateSmartFollowActions()
            return
        end
        for _, partyUnit in ipairs(PARTY_UNITS) do
            if auraPending[partyUnit] then
                UpdateSmartFollowActions(partyUnit)
            end
        end
        wipe(auraPending)
    end)
end

local eventFrame = CreateFrame("Frame")
for _, event in ipairs({
    "ADDON_LOADED", "PLAYER_LOGIN", "PLAYER_ENTERING_WORLD",
    "GROUP_ROSTER_UPDATE", "PLAYER_REGEN_DISABLED", "PLAYER_REGEN_ENABLED", "DISPLAY_SIZE_CHANGED",
    "AUTOFOLLOW_BEGIN", "AUTOFOLLOW_END",
    "UNIT_AURA", "PLAYER_MOUNT_DISPLAY_CHANGED", "COMPANION_UPDATE",
    "UI_SCALE_CHANGED",
}) do
    pcall(eventFrame.RegisterEvent, eventFrame, event)
end

eventFrame:SetScript("OnEvent", function(self, event, arg1)
    if event == "ADDON_LOADED" and arg1 == ADDON_NAME then
        GetDB()
        return
    end
    if event == "AUTOFOLLOW_BEGIN" then
        followingName = NameKey(arg1)
        UpdateFollowIndicators()
        return
    end
    if event == "AUTOFOLLOW_END" then
        followingName = nil
        UpdateFollowIndicators()
        return
    end
    if event == "UNIT_AURA" then
        if arg1 == PLAYER_UNIT or (type(arg1) == "string"
            and arg1:match("^party[1-4]$")) then
            QueueSmartFollowAura(arg1)
        end
        return
    end
    if event == "PLAYER_MOUNT_DISPLAY_CHANGED" or event == "COMPANION_UPDATE" then
        UpdateSmartFollowActions()
        return
    end
    if event == "PLAYER_REGEN_DISABLED" then
        for _, unit in ipairs(PARTY_UNITS) do UpdateFollowRange(buttons[unit]) end
        return
    end
    if event == "GROUP_ROSTER_UPDATE" then
        wipe(frameCache)
        lastGenericScanTime = -10000
        for _, unit in ipairs(PARTY_UNITS) do
            local b = buttons[unit]
            if b and b.rangeCross then b.rangeCross:Hide(); b.rangeOutside = nil end
        end
        -- Never measure/reanchor to half-created party frames on this event.
        ScheduleRosterSettle()
        return
    end
    if event == "PLAYER_LOGIN" then
        GetDB()
        RefreshLayout()
        -- Third-party party frames can finish initializing after PLAYER_LOGIN.
        ScheduleRosterSettle()
        Message("Loaded. F: follow/target, I: inspect, S: left-click sit/stand, M: mount. /ef opens settings; /ef modify edits S.")
        return
    end
    if event == "PLAYER_REGEN_ENABLED" then
        if pendingSitRightUpdate then
            ApplySitRightCommand()
        end
        if pendingLayout then
            ScheduleRefresh()
        end
        if pendingSmartUpdate or GetDB().smartFollow then
            UpdateSmartFollowActions()
        end
        if pendingBindingUpdate then
            ApplyMountBinding()
        end
        return
    end
    ScheduleRefresh()
end)

-- Small, translucent command editor. It does not modify any protected
-- button's attributes until ApplySitRightCommand runs outside combat.
local modifyFrame
local function OpenSitRightEditor()
    if not modifyFrame then
        local frame = CreateFrame("Frame", "EasyFollowModifyFrame", UIParent)
        frame:SetSize(352, 170)
        frame:SetPoint("CENTER", UIParent, "CENTER", 0, 100)
        frame:SetFrameStrata("DIALOG")
        frame:SetClampedToScreen(true)
        frame:SetMovable(true)
        frame:EnableMouse(true)
        frame:RegisterForDrag("LeftButton")
        frame:SetScript("OnDragStart", function(self) self:StartMoving() end)
        frame:SetScript("OnDragStop", function(self) self:StopMovingOrSizing() end)
        frame:Hide()

        local shade = frame:CreateTexture(nil, "BACKGROUND")
        shade:SetAllPoints()
        shade:SetColorTexture(0.015, 0.025, 0.035, 0.58) -- deliberately non-opaque

        local function AddEdge(owner, where)
            local edge = owner:CreateTexture(nil, "BORDER")
            edge:SetColorTexture(0.32, 0.71, 0.59, 0.75)
            if where == "TOP" then
                edge:SetPoint("TOPLEFT"); edge:SetPoint("TOPRIGHT"); edge:SetHeight(1)
            elseif where == "BOTTOM" then
                edge:SetPoint("BOTTOMLEFT"); edge:SetPoint("BOTTOMRIGHT"); edge:SetHeight(1)
            elseif where == "LEFT" then
                edge:SetPoint("TOPLEFT"); edge:SetPoint("BOTTOMLEFT"); edge:SetWidth(1)
            else
                edge:SetPoint("TOPRIGHT"); edge:SetPoint("BOTTOMRIGHT"); edge:SetWidth(1)
            end
        end
        for _, edge in ipairs({"TOP", "BOTTOM", "LEFT", "RIGHT"}) do
            AddEdge(frame, edge)
        end

        local title = frame:CreateFontString(nil, "OVERLAY", "GameFontNormal")
        title:SetPoint("TOPLEFT", frame, "TOPLEFT", 14, -13)
        title:SetText("EasyFollow - S Right-Click")
        title:SetTextColor(0.60, 1, 0.84)

        local hint = frame:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
        hint:SetPoint("TOPLEFT", frame, "TOPLEFT", 14, -39)
        hint:SetText("Enter a slash command, e.g. /dance or /say hello")

        local edit = CreateFrame("EditBox", nil, frame)
        edit:SetSize(324, 27)
        edit:SetPoint("TOP", frame, "TOP", 0, -64)
        edit:SetAutoFocus(false)
        edit:SetFontObject(ChatFontNormal)
        edit:SetTextInsets(8, 8, 0, 0)
        edit:SetMaxLetters(255)
        edit:SetTextColor(1, 1, 1, 1)
        edit:SetScript("OnEscapePressed", function(self)
            self:ClearFocus()
            frame:Hide()
        end)
        local fieldShade = edit:CreateTexture(nil, "BACKGROUND")
        fieldShade:SetAllPoints()
        fieldShade:SetColorTexture(0.02, 0.06, 0.07, 0.32)
        for _, edge in ipairs({"TOP", "BOTTOM", "LEFT", "RIGHT"}) do
            AddEdge(edit, edge)
        end
        frame.edit = edit

        local function SaveCommand(value)
            local command = (value or ""):match("^%s*(.-)%s*$")
            if #command > 255 or command:find("[%c]") then
                Message("Please use a single-line command up to 255 characters.")
                return
            end
            if command ~= "" and command:sub(1, 1) ~= "/" then
                Message("Right-click command must start with / (example: /dance).")
                edit:SetFocus()
                return
            end
            GetDB().sitRightCommand = command
            local applied = ApplySitRightCommand()
            if command == "" then
                Message("S right-click reset to the Sit/Stand toggle.")
            else
                Message("S right-click set to: " .. command)
            end
            if not applied and InCombatLockdown() then
                Message("The new command will activate after combat.")
            end
            edit:ClearFocus()
            frame:Hide()
        end

        edit:SetScript("OnEnterPressed", function(self) SaveCommand(self:GetText()) end)
        local function AddButton(text, x, width, onClick)
            local button = CreateFrame("Button", nil, frame, "UIPanelButtonTemplate")
            button:SetSize(width, 23)
            button:SetPoint("BOTTOMLEFT", frame, "BOTTOMLEFT", x, 37)
            button:SetText(text)
            button:SetScript("OnClick", onClick)
            return button
        end
        AddButton("Save", 14, 86, function() SaveCommand(edit:GetText()) end)
        AddButton("Reset", 105, 86, function() SaveCommand("") end)
        AddButton("Close", 254, 84, function()
            edit:ClearFocus()
            frame:Hide()
        end)

        local footer = frame:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
        footer:SetPoint("BOTTOM", frame, "BOTTOM", 0, 10)
        if not footer:SetFont("Fonts\\MORPHEUS.TTF", 11) then
            footer:SetFontObject(GameFontNormalSmall)
        end
        footer:SetText("RIP Shady")
        footer:SetTextColor(0.80, 0.66, 0.35, 0.85)

        modifyFrame = frame
    end
    modifyFrame.edit:SetText(GetDB().sitRightCommand)
    modifyFrame:Show()
    modifyFrame.edit:SetFocus()
    modifyFrame.edit:HighlightText()
end

-- Standalone settings, independent of the protected party buttons.
local settingsFrame
local function OpenSettings()
    if not settingsFrame then
        local frame = CreateFrame("Frame", "EasyFollowSettingsFrame", UIParent)
        frame:SetSize(350, 310)
        frame:SetPoint("CENTER")
        frame:SetFrameStrata("DIALOG")
        frame:SetClampedToScreen(true)
        frame:SetMovable(true)
        frame:EnableMouse(true)
        frame:RegisterForDrag("LeftButton")
        frame:SetScript("OnDragStart", function(self) self:StartMoving() end)
        frame:SetScript("OnDragStop", function(self) self:StopMovingOrSizing() end)
        local border = frame:CreateTexture(nil, "BACKGROUND")
        border:SetAllPoints()
        border:SetColorTexture(0.28, 0.50, 0.43, 1)
        local bg = frame:CreateTexture(nil, "BORDER")
        bg:SetPoint("TOPLEFT", 1, -1)
        bg:SetPoint("BOTTOMRIGHT", -1, 1)
        bg:SetColorTexture(0.035, 0.055, 0.065, 1)
        local title = frame:CreateFontString(nil, "OVERLAY", "GameFontNormalLarge")
        title:SetPoint("TOPLEFT", 16, -15)
        title:SetText("EasyFollow |cff9bada8v1.7.6|r")
        local close = CreateFrame("Button", nil, frame, "UIPanelCloseButton")
        close:SetPoint("TOPRIGHT", -2, -2)
        close:SetScript("OnClick", function() frame:Hide() end)
        local heading = frame:CreateFontString(nil, "OVERLAY", "GameFontNormal")
        heading:SetPoint("TOPLEFT", 16, -50)
        heading:SetText("Button visibility")
        frame.checks = {}
        local options = {
            {"showFollow", "F - Follow / Target"},
            {"showInspect", "I - Inspect"},
            {"showSit", "S - Sit / Stand"},
            {"showMount", "M - Mount / Dismount"},
        }
        local hint = frame:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
        hint:SetPoint("TOPLEFT", 16, -207)
        hint:SetWidth(318)
        hint:SetJustifyH("LEFT")
        local function RefreshChecks()
            local cfg = GetDB()
            for key, check in pairs(frame.checks) do check:SetChecked(cfg[key]) end
            hint:SetText(InCombatLockdown() and "Changes apply after combat."
                or "Hidden buttons keep their positions. Hiding M pauses its saved keybind.")
        end
        for i, option in ipairs(options) do
            local key, label = option[1], option[2]
            local check = CreateFrame("CheckButton", nil, frame, "UICheckButtonTemplate")
            check:SetSize(28, 28)
            check:SetPoint("TOPLEFT", 13, -69 - (i - 1) * 32)
            local text = check:CreateFontString(nil, "OVERLAY", "GameFontHighlight")
            text:SetPoint("LEFT", check, "RIGHT", 5, 0)
            text:SetText(label)
            check:SetHitRectInsets(0, -240, 0, 0)
            check:SetScript("OnClick", function(self)
                GetDB()[key] = self:GetChecked() and true or false
                RefreshLayout()
                RefreshChecks()
            end)
            frame.checks[key] = check
        end
        local reset = CreateFrame("Button", nil, frame, "UIPanelButtonTemplate")
        reset:SetSize(110, 24)
        reset:SetPoint("BOTTOMLEFT", 16, 42)
        reset:SetText("Show all")
        reset:SetScript("OnClick", function()
            local cfg = GetDB()
            for key in pairs(frame.checks) do cfg[key] = true end
            RefreshLayout()
            RefreshChecks()
        end)
        local footer = frame:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
        footer:SetPoint("BOTTOM", 0, 12)
        footer:SetText("RIP Shady")
        frame:SetScript("OnShow", RefreshChecks)
        frame:RegisterEvent("PLAYER_REGEN_ENABLED")
        frame:RegisterEvent("PLAYER_REGEN_DISABLED")
        frame:SetScript("OnEvent", function(self) if self:IsShown() then RefreshChecks() end end)
        UISpecialFrames = UISpecialFrames or {}
        table.insert(UISpecialFrames, "EasyFollowSettingsFrame")
        frame:Hide()
        settingsFrame = frame
    end
    settingsFrame:Show()
end

SLASH_EASYFOLLOW1 = "/ef"
SLASH_EASYFOLLOW2 = "/easyfollow"
SlashCmdList.EASYFOLLOW = function(raw)
    local trimmed = (raw or ""):match("^%s*(.-)%s*$")
    local msg = trimmed:lower()
    local settings = GetDB()
    local numericSize = tonumber(msg)
    if msg == "" or msg == "settings" or msg == "config" then
        OpenSettings()
        return
    end

    if msg == "skin" or msg == "skin wow" or msg == "skin teal" or msg == "skin ac" then
        if msg == "skin" then
            settings.skin = settings.skin == "teal" and "wow" or "teal"
        else
            settings.skin = msg:sub(6)
            if settings.skin == "ac" then settings.skin = "wow" end
        end
        for _, button in pairs(buttons) do PaintButton(button) end
        for _, button in pairs(inspectButtons) do PaintButton(button) end
        Message("Button skin: " .. (settings.skin == "wow" and "AC/WoW red-gold" or "Classic teal")
            .. ". /ef skin [wow|teal].")
        return
    end
    if msg == "modify" then
        OpenSitRightEditor()
        return
    end
    if msg == "bind" then
        Message("M keybind: " .. (settings.mountBind ~= "" and settings.mountBind or "None")
            .. ". Set /ef bind X or /ef bind Z; remove with /ef unbind.")
        return
    end
    if msg == "unbind" or msg == "bind none" or msg == "bind off" then
        settings.mountBind = ""
        local applied = ApplyMountBinding()
        Message("M keybind removed." .. (not applied and InCombatLockdown()
            and " Applies after combat." or ""))
        return
    end
    if msg:sub(1, 5) == "bind " then
        local key = NormalizeMountKey(trimmed:sub(6))
        if not key then
            Message("Invalid key. Use X, Z, SHIFT-X, CTRL-Z, ALT-X, or F1-F12.")
            return
        end
        settings.mountBind = key
        local applied = ApplyMountBinding()
        if not settings.enabled then
            Message("M keybind saved as " .. key .. "; enable EasyFollow with /ef on to activate.")
        elseif not settings.showMount then
            Message("M keybind saved as " .. key .. "; show M in /ef settings to activate.")
        elseif applied then
            Message("M mount/dismount bound to " .. key
                .. ". Any existing action on that key is overridden while EasyFollow is enabled.")
        elseif InCombatLockdown() then
            Message("M keybind set to " .. key .. "; applies when combat ends.")
        else
            Message("M keybind saved as " .. key .. "; /reload if not active yet.")
        end
        return
    end

    if msg == "smart" then
        Message("Smart Follow: " .. (settings.smartFollow and "ON" or "OFF")
            .. ". Use /ef smart on|off. Mounted teammates require two clicks.")
        return
    end
    if msg == "smart on" or msg == "smart off" then
        settings.smartFollow = (msg == "smart on")
        Message("Smart Follow " .. (settings.smartFollow and "enabled" or "disabled") .. ".")
        UpdateSmartFollowActions()
        return
    end

    local gapArg = msg:match("^gap%s+(%d+)$")
    if gapArg then
        local n = tonumber(gapArg)
        if n < 0 or n > 24 then
            Message("S/M gap must be between 0 and 24. Example: /ef gap 4")
            return
        end
        settings.utilityGap = n
        Message("S/M gap set to " .. n .. " pixels.")
        ScheduleRefresh()
        return
    end
    if msg == "gap" then
        Message("S/M gap is " .. settings.utilityGap .. ". Use /ef gap 0-24.")
        return
    end
    if msg == "mount" then
        Message("M uses " .. (settings.mountName ~= "" and settings.mountName or "a random favorite mount") .. ".")
        Message("Set: /ef mount <exact mount name> | Reset: /ef mount random")
        return
    end
    if msg:sub(1, 6) == "mount " then
        local name = trimmed:sub(7):match("^%s*(.-)%s*$")
        if name:lower() == "random" or name:lower() == "favorites" then
            settings.mountName = ""
            Message("M now summons a random favorite mount (or dismounts).")
        elseif name ~= "" and #name <= 180 and not name:find("[\r\n]") then
            settings.mountName = name
            Message("M now uses: " .. name .. " (or dismounts).")
        else
            Message("Enter a valid mount name (up to 180 characters).")
            return
        end
        ScheduleRefresh()
        UpdateSmartFollowActions()
        return
    end

    if numericSize then
        if numericSize < 14 or numericSize > 70 then
            Message("Size must be between 14 and 70. Example: /ef 24")
            return
        end
        settings.size = math.floor(numericSize + 0.5)
        Message("Button size set to " .. settings.size .. ".")
        ScheduleRefresh()
        return
    end
    if SIDE[msg] then
        settings.side = msg
        Message("Standalone position: " .. msg .. ". Linked buttons follow ClickCleanse's side.")
        ScheduleRefresh()
        return
    end
    if msg == "on" or msg == "off" then
        settings.enabled = (msg == "on")
        Message((settings.enabled and "Enabled." or "Disabled.")
            .. (InCombatLockdown() and " Change applies after combat." or ""))
        ApplyMountBinding() -- Clear/restore the shortcut immediately out of combat.
        ScheduleRefresh()
        return
    end
    if msg == "link" then
        settings.useClickCleanse = not settings.useClickCleanse
        Message(settings.useClickCleanse
            and "Attach beside ClickCleanse: ON (when available)."
            or "Attach beside ClickCleanse: OFF.")
        ScheduleRefresh()
        return
    end
    if msg == "refresh" then
        Message("Refreshing button positions.")
        ScheduleRefresh()
        return
    end
    if msg == "status" then
        -- Report both anchor and actual visibility; a state driver may be
        -- anchored correctly but leave its button hidden during a rebuild.
        -- No party names are read (some Forever values are restricted).
        for index = 0, #PARTY_UNITS do
            local unit = (index == 0) and PLAYER_UNIT or PARTY_UNITS[index]
            local b = buttons[unit]
            local exists = SafeUnitExists(unit)
            local state = (b and b.efHasAnchor) and "anchored" or "waiting"
            local visible = b and SafeVisible(b) and "shown" or "hidden"
            Message(unit .. ": " .. (exists and "present" or "absent")
                .. ", " .. state .. ", " .. visible
                .. " (" .. (lastAnchor[unit] or "not checked") .. ")")
        end
        local mount = buttons[MOUNT_KEY]
        Message("M: " .. (mount and SafeVisible(mount) and "shown" or "hidden")
            .. ", recovery check every " .. RECOVERY_CHECK_SECONDS .. "s"
            .. ", generic fallback sweeps: " .. genericScanCount)
        return
    end

    Message("Commands: /ef 23 (size), /ef left|right|top|bottom, /ef link,")
    Message("/ef modify (edit S right-click command), /ef gap 0-24 (S/M spacing),")
    Message("/ef skin [wow|teal] (button appearance), /ef mount <name>|random,")
    Message("/ef bind X|Z|SHIFT-X (M keybind), /ef unbind (clear),")
    Message("/ef smart on|off (detect mounted teammates; two-click mount then follow),")
    Message("/ef on|off, /ef refresh, /ef status (party button diagnostics).")
    Message("ClickCleanse attachment: "
        .. (settings.useClickCleanse and "ON" or "OFF") .. ".")
end
