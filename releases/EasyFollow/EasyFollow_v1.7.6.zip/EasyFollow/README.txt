EasyFollow 1.7.6
- Guard protected frame names, unit tokens, dimensions and anchor coordinates. Skip nameplate units in generic discovery. Preserve saved settings and secure actions.

EasyFollow 1.7.5
- /ef or /ef settings opens an opaque settings window with F, I, S and M visibility checkboxes.
- All four default to shown on upgrade; preferences persist in EasyFollowDB.
- I can stay visible with F hidden; M can stay visible with S hidden. Existing slots remain fixed.
- Hiding M pauses its override keybinding; showing M restores the saved key.
- Combat changes are saved and applied when combat ends. Show all resets visibility only.
- /ef help lists the existing slash commands. ESC closes settings.

EasyFollow 1.7.3
- Red X on F outside follow range; checks every 0.25s outside combat. Unknown range clears the X. Visual only.

EasyFollow 1.7.2

- Updated the optional wow skin to a darker red-and-gold AC Search-style button look.
- Added /ef skin ac as an alias for /ef skin wow.
- Cosmetic-only change: layout, anchoring, clicks and combat safety are unchanged.

EasyFollow v1.7.1 — WoW Forever

INSTALL
Extract EasyFollow/ into World of Warcraft/_forever_/Interface/AddOns/,
replacing the old EasyFollow folder. Then /reload outside combat.

FIX: BUTTONS DISAPPEARING UNTIL RELOAD
- Periodically checks whether expected F/S/M buttons are missing, hidden, or
  anchored to an old ClickCleanse/party frame after a group change.
- Automatically repositions missing buttons once the correct verified frame
  becomes available, even if the rebuild takes longer than eight seconds.
- Re-synchronizes secure visibility after a button's anchor recovers; previously
  a hidden button could remain hidden after a successful re-anchor.
- Only runs expensive frame discovery when recovery is actually needed.
- Never guesses which party member owns a frame or repositions protected
  buttons in combat; deferred recovery happens outside combat.

S/M remain centered under the player's ClickCleanse square; F stays under
its matching teammate. Existing Smart Follow, keybinding, sit/stand toggle,
/ef modify, and settings are preserved.

TEST
Have party members join, leave, swap party order, and enter/leave combat.
If a button disappears, it should return automatically without /reload.
Use /ef status while the problem is happening if it persists.

KNOWN LIMITATION
Protected buttons cannot be repositioned by addon code during combat.
Please test in live WoW Forever; simulated tests cannot reproduce all secure
state-driver and third-party frame behavior.

1.6.6: Follow buttons track the matching ClickCleanse square directly. Temporary fallback uses the actual square-size/placement so it does not overlap the gray square.

1.7.0: I opens native inspection on click outside combat. F/I share F visibility and anchor; S/M unchanged. Recovery validates the owning unit frame rather than its health bar. Inspect is rate limited; no target switching.

1.7.1: Optional Blizzard red/gold button skin. /ef skin toggles, /ef skin wow or /ef skin teal selects explicitly. Saved across reloads. No layout or action changes.

1.7.5 Performance: verified frame cache, throttled fallback scan, event-coalesced mount detection, 0.75s range checks; FrameSwitch/ClickCleanse compatible.
