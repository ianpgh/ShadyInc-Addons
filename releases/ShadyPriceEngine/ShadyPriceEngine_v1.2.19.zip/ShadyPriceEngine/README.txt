Shady Price Engine / Index 1.2.19
Merged expanded 1.2.18 catalog and 1.2.18-beta.1 TK pricing branch.
Full ShadyItemCatalog.lua preserved byte-for-byte. Legacy price tables are not shipped.
Requires Shady's Thoughts 0.27.6 for compatible snapshot preservation/publication; AC 1.3.5 for freshness comparison.
Install through manager (Stable channel), preserving ShadyPriceDB. Do not install either older branch over this build. If no snapshot is installed, wait for next eligible successful SPU live publication, then /reload.
/shady tk us-pvp-horde enables TK pricing; /shady tk off disables it.
/shady freshness on|off controls the green checkmark. Shift reveals observation times when both comparable prices exist. /shady search opens the full index.
Prices are display-only. The public pricing API returns no experimental quotes. AHledger is used only for listing/sales context, not prices.
No bundled current prices: the manager writes ShadyPriceSnapshot.lua.
Stable promotion: version and release documentation only; no pricing or catalog logic changed. Extended native WoW validation not independently verified.

Catalog update: New vs. Classic Era shows 335 items with Forever acquisition evidence. Preserve your current manager-written ShadyPriceSnapshot.lua when installing manually.
