-- Optional offline catalog: item ID to English name. No prices.
ShadyForeverItemCatalog = {}
