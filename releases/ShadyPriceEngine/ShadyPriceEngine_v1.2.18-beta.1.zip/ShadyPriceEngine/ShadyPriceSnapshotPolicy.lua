local _, addon = ...
local MARKET = "forever.pvp.horde.us"
local HOUSE = "us-2-113"

local function integer(n, low, high)
    return type(n) == "number" and n >= low and n <= high and n % 1 == 0
end

local function validate(data)
    if type(data) ~= "table" or data.schema ~= 2 or
        data.source ~= "auctionhouse.tk.gg" or data.origin ~= "blizzard" or
        data.market ~= MARKET or data.house ~= HOUSE or data.complete ~= true or
        type(data.stale) ~= "boolean" or type(data.rows) ~= "table" or
        not integer(data.maxAgeSec, 3600, 21600) or
        not integer(data.observedMs, 1600000000000, 9007199254740991) or
        not integer(data.fetchedMs, data.observedMs, data.observedMs + data.maxAgeSec * 1000) or
        not integer(data.attemptedMs, 1600000000000, 9007199254740991) or
        (data.stale and data.attemptedMs < data.fetchedMs) or
        (not data.stale and data.attemptedMs > data.fetchedMs) or
        not integer(data.itemCount, 0, 200000) or
        not integer(data.missingBuyout, 0, 200000 - data.itemCount) then
        return
    end
    local count = 0
    for id, copper in pairs(data.rows) do
        if not integer(id, 1, 5000000) or not integer(copper, 1, 99999999999999) then return end
        count = count + 1
        if count > data.itemCount then return end
    end
    if count == data.itemCount then return data end
end

local snapshot = validate(ShadyPriceSnapshot)
addon.externalMarket = MARKET
addon.externalSnapshot = snapshot
addon.externalHealth = function(enabled)
    if not enabled then return nil, "TK market disabled" end
    if not GetCurrentRegion or GetCurrentRegion() ~= 1 or
        not UnitFactionGroup or UnitFactionGroup("player") ~= "Horde" then
        return nil, "TK market requires a US Horde character"
    end
    if not snapshot then return nil, "No valid TK snapshot installed" end
    if snapshot.stale then return nil, "Last TK refresh failed" end
    local now = ((GetServerTime and GetServerTime()) or time()) * 1000 + 999
    local age = now - snapshot.observedMs
    if snapshot.attemptedMs > now or age < 0 then return nil, "TK snapshot clock mismatch" end
    if age > snapshot.maxAgeSec * 1000 then return nil, "TK snapshot expired" end
    return snapshot, nil, math.floor(age / 1000)
end
