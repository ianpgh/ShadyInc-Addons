-- Managed by the verified Shady price updater when explicitly enabled.
-- This companion preview starts with an empty snapshot.
ShadyPriceSnapshot = nil
