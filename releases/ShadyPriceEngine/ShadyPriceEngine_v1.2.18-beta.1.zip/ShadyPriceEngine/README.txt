Shady Price Engine / Shady Price Index 1.2.18-beta.1
Unified SPI 1.2.17 discovery + SPE 1.2.16-beta.2 snapshot branch.
Install manager 0.27.6 or newer FIRST; close WoW for the addon replacement.
Install as ONE ShadyPriceEngine addon. Do not reinstall legacy SPI 1.2.17.
Keep ShadyPriceDB (SavedVariables). Existing locale name archives remain usable.
The empty snapshot placeholder is intentional; compatible manager upgrades preserve
an existing recognized snapshot under the price lock. If the previous branch
was legacy or no valid snapshot exists, wait for the next successful SPU fetch.
No packaged November 24 prices. 6,908 old item IDs seed metadata discovery only;
item names are resolved through the game cache. This is NOT the comprehensive
Forever catalog expansion. Catalog and bag/equipment/hover discovery work without prices.
Use Live (test) in the manager, confirm SPE published, then /reload. On US Horde
PvP use /shady tk us-pvp-horde if needed; /shady tk off hides the TK quote.
With AC 1.3.5, the newer displayed price gets a green check, ties get neither.
Hold Shift for observation timestamps and ages; /shady freshness off|on controls
both labels. Expired TK quotes are omitted rather than crossed out. No price is
selected on behalf of either addon. A check means fresher, not necessarily correct.
SPE public price/buy-cost APIs remain unavailable (comparison only). AHledger
listed/sold-day context is retained when its existing validity checks pass.
TK upstream bid-only filtering and exact game realm match remain unverified.
Lua 5.4 mock tests passed; actual WoW Forever Lua client and font rendering pending.
