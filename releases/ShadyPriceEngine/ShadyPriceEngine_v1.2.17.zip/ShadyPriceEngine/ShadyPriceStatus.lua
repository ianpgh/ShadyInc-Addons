ShadyPriceStatus = {market="forever.pvp.horde.us", attempted=1795562782, outcome="partial", ah="unavailable", tk="ok", ahSnapshot=0, tkSnapshot=1795559178}
