-- Shady Price Engine v1.2.16-beta.2 for WoW Forever
local ADDON, policy = ...
local addon = CreateFrame("Frame")
local ADDON_NAME = "Shady Price Engine"
local DATA = policy.externalSnapshot or {}
local DEFAULT = { tooltips = true, details = false, solid = true, alpha = 1, coinIcons = true, showIndicator = false, autoIndex = true, hideNativeSell = true, tkMarketOptIn = false }
local db
local C = { gold = {1, 0.82, 0.16}, white = {1, 1, 1}, gray = {0.66,0.66,0.66} }

local function chat(msg)
    if DEFAULT_CHAT_FRAME then DEFAULT_CHAT_FRAME:AddMessage("|cffffd152Shady:|r " .. tostring(msg)) end
end

local function getData()
    return policy.externalHealth(db and db.tkMarketOptIn == true)
end

-- Texture tokens are built explicitly. Some WoW Forever builds (or compatibility
-- replacements) do not provide GetCoinTextureString, so relying on it alone
-- makes price rows fall back to g/s/c instead of showing coin icons.
local MONEY_ICON = {
    gold = "|TInterface\\MoneyFrame\\UI-GoldIcon:0:0:2:0|t",
    silver = "|TInterface\\MoneyFrame\\UI-SilverIcon:0:0:2:0|t",
    copper = "|TInterface\\MoneyFrame\\UI-CopperIcon:0:0:2:0|t",
}

local function money(copper)
    copper = tonumber(copper)
    if not copper or copper < 0 then return "--" end
    copper = math.floor(copper)
    local g = math.floor(copper / 10000)
    local s = math.floor((copper % 10000) / 100)
    local c = copper % 100

    -- Old saved profiles receive coin icons by default (nil = enabled).
    if not db or db.coinIcons ~= false then
        local parts = {}
        if g > 0 then parts[#parts + 1] = tostring(g) .. MONEY_ICON.gold end
        if s > 0 then parts[#parts + 1] = tostring(s) .. MONEY_ICON.silver end
        if c > 0 or #parts == 0 then parts[#parts + 1] = tostring(c) .. MONEY_ICON.copper end
        return table.concat(parts, " ")
    end
    return string.format("%dg %ds %dc", g, s, c)
end

local function itemIDFromLink(link)
    if type(link) == "number" then return link end
    if type(link) ~= "string" then return nil end
    return tonumber(link:match("item:(%d+)")) or tonumber(link)
end

local function wrongFaction(market)
    if type(market) ~= "string" or not UnitFactionGroup then return false end
    local expected = market:match("%.([^.]+)%.[^.]+$")
    local faction = UnitFactionGroup("player")
    return faction and (expected == "horde" or expected == "alliance")
        and expected ~= faction:lower()
end

local QUOTE_AGE = 6 * 3600
local auctionOpen = false

local function liveQuotes()
    if not db or not GetRealmName or not UnitFactionGroup then return end
    local realm, faction = GetRealmName(), UnitFactionGroup("player")
    if not realm or realm == "" or not faction then return end
    faction = faction:lower()
    local key = ":" .. realm .. ":" .. faction
    db.liveQuotes = db.liveQuotes or {}
    if not db.liveQuotes[key] then db.liveQuotes[key] = {} end
    return db.liveQuotes[key]
end

local function captureBuyout(itemKey, commodity)
    if not auctionOpen or not C_AuctionHouse then return end
    local quotes = liveQuotes()
    local id = commodity and itemKey or type(itemKey) == "table" and itemKey.itemID
    if not quotes or type(id) ~= "number" or id <= 0 then return end
    -- Item-ID pricing cannot safely generalize a search for one gear variant.
    if not commodity and ((itemKey.itemSuffix or 0) ~= 0 or
        (itemKey.itemLevel or 0) ~= 0 or (itemKey.battlePetSpeciesID or 0) ~= 0) then return end
    local ah = C_AuctionHouse
    local countResults, getResult, hasFullResults
    if commodity then
        countResults, getResult, hasFullResults = ah.GetNumCommoditySearchResults,
            ah.GetCommoditySearchResultInfo, ah.HasFullCommoditySearchResults
    else
        countResults, getResult, hasFullResults = ah.GetNumItemSearchResults,
            ah.GetItemSearchResultInfo, ah.HasFullItemSearchResults
    end
    if not countResults or not getResult then return end
    local best
    local tiers = commodity and {}
    for index = 1, countResults(itemKey) or 0 do
        local result = getResult(itemKey, index)
        if result and not result.containsOwnerItem then
            local price = commodity and result.unitPrice or (not commodity and result.buyoutAmount)
            local quantity = commodity and 1 or result.quantity or 1
            if type(price) == "number" and price > 0 and quantity > 0 then
                local unitPrice = math.max(1, math.floor(price / quantity + 0.5))
                if not best or unitPrice < best then best = unitPrice end
                if tiers and type(result.quantity) == "number" and result.quantity > 0 then
                    tiers[price] = (tiers[price] or 0) + result.quantity
                end
            end
        end
    end
    if best then
        quotes[id] = { best, time(), tiers or nil }
    elseif hasFullResults and hasFullResults(itemKey) then
        quotes[id] = nil
    end
end

local function priceFor(item)
    local data, _, age = getData()
    local id = itemIDFromLink(item)
    local price = data and id and data.rows[id]
    if price then return price, age, data end
end

local clearHooks = setmetatable({}, {__mode = "k"})
local tooltipRows = setmetatable({}, {__mode = "k"})

local function tooltipLine(tt, side, index)
    local name = tt.GetName and tt:GetName()
    return name and _G[name .. "Text" .. side .. index]
end

local function readableTooltipText(line)
    if not line or not line.GetText then return nil end
    local value = line:GetText()
    if issecretvalue and issecretvalue(value) then return nil end
    if canaccessvalue and not canaccessvalue(value) then return nil end
    if type(value) == "string" then return value end
end

local function tooltipContext(tt)
    local context = {}
    for i = 1, tt:NumLines() do
        local left = tooltipLine(tt, "Left", i)
        local text = readableTooltipText(left)
        if text then
            local label = text:gsub("|c%x%x%x%x%x%x%x%x", ""):gsub("|r", ""):lower()
            if label:find("^shady") then context.shady = true end
            if label:find("^ahledger") then context.ahledger = true end
            if label:match("^vendor%s*$") or label:match("^vendor%s+x%d+%s*$") then
                context.vendor = true
                context.vendorIndex = context.vendorIndex or i
                local right = tooltipLine(tt, "Right", i)
                local rightText = readableTooltipText(right)
                -- A right FontString can contain a price but still be hidden:
                -- native SetTooltipMoney inserts an AddLine, not AddDoubleLine.
                if rightText and rightText ~= "" and
                    (not right.IsShown or right:IsShown()) then
                    context.vendorPriced = true
                end
            end
            if label:match("^auction%s*$") or label:match("^auction%s+x%d+") or label:match("^auction%s+price") then
                context.auction = i
            end
            local count = label:match("^vendor%s+x(%d+)%s*$") or label:match("^auction%s+x(%d+)%s*$")
            if count then context.count = tonumber(count) end
        end
    end
    return context
end

-- Read the item's real per-unit vendor sell value.  Blizzard's tooltip
-- MoneyFrame is not a FontString on some clients, so renaming its left label
-- cannot preserve the price after other addons call GameTooltip_ClearMoney.
local function vendorPriceFor(item)
    if not item then return nil end
    local function fromGetter(getter)
        if type(getter) ~= "function" then return nil end
        local ok, price = pcall(function() return select(11, getter(item)) end)
        if ok and type(price) == "number" and price > 0 then
            return math.floor(price)
        end
    end
    return fromGetter(C_Item and C_Item.GetItemInfo) or fromGetter(GetItemInfo)
end

-- Exactly one vendor row: keep Auctionator's if it has a visible price, or
-- convert Blizzard's existing Sell Price line to a genuine double-column row.
-- Don't suppress a native price unless we have a verified replacement.
-- Return the existing row as a tracked price so Shift updates its stack value.
local function normalizeNativeVendor(tt, context, item)
    if not db or not db.hideNativeSell or not tt or not tt.NumLines then return end
    local price = vendorPriceFor(item)
    local function writeVendor(index)
        if not price then return end
        local left = tooltipLine(tt, "Left", index)
        local right = tooltipLine(tt, "Right", index)
        if not left or not right or not right.SetText then return end
        left:SetText("Vendor")
        left:SetTextColor(C.gold[1], C.gold[2], C.gold[3])
        right:SetText(money(price))
        if right.SetTextColor then right:SetTextColor(1, 1, 1) end
        -- Blizzard's native Sell Price is an AddLine with a separate
        -- MoneyFrame. Its right FontString is often HIDDEN, even when text
        -- has been assigned to it. Show() is essential for a real 2-column
        -- Vendor price without introducing another row.
        if right.Show then right:Show() end
        return {index=index, label="Vendor", value=price, suffix="", lastLabel="Vendor"}
    end

    -- Repair a blank Vendor line left behind by a previous tooltip callback.
    if context.vendor and not context.vendorPriced and context.vendorIndex then
        local entry = writeVendor(context.vendorIndex)
        if entry then context.vendorPriced = true end
        -- Do not create a second Vendor row; handling native Sell Price below
        -- will only hide it if the existing row now has its actual amount.
        if not entry then return end
        for i = 1, tt:NumLines() do
            local left = tooltipLine(tt, "Left", i)
            local raw = readableTooltipText(left)
            if raw and raw:lower():match("^%s*sell%s+price%s*:") then
                left:SetText("")
                local right = tooltipLine(tt, "Right", i)
                if right and right.SetText then right:SetText("") end
            end
        end
        return entry
    end

    for i = 1, tt:NumLines() do
        local left = tooltipLine(tt, "Left", i)
        local raw = readableTooltipText(left)
        if raw then
            local plain = raw:gsub("|c%x%x%x%x%x%x%x%x", ""):gsub("|r", "")
            if plain:match("^%s*[Ss]ell%s+[Pp]rice%s*:") then
                if context.vendor and context.vendorPriced then
                    -- Another addon already supplies a complete Vendor row.
                    left:SetText("")
                    local right = tooltipLine(tt, "Right", i)
                    if right and right.SetText then right:SetText("") end
                else
                    -- Remove the native coin widget BEFORE filling/showing
                    -- the price FontString, so a money-frame cleanup cannot
                    -- disturb our replacement after it is displayed.
                    if price and tooltipLine(tt, "Right", i) and GameTooltip_ClearMoney then
                        pcall(GameTooltip_ClearMoney, tt)
                    end
                    local entry = writeVendor(i)
                    if entry then return entry end
                    -- Missing item info or no right column: keep native price.
                end
            end
        end
    end
end

local function stackCount(tt, item)
    if not C_Container or not C_Container.GetContainerItemInfo or not tt.GetOwner then return end
    local owner = tt:GetOwner()
    if not owner or not owner.GetID then return end
    local slot = owner:GetID()
    local bag = owner.GetBagID and owner:GetBagID()
    if type(bag) ~= "number" and owner.GetParent then
        local parent = owner:GetParent()
        bag = parent and parent.GetID and parent:GetID()
    end
    if type(bag) ~= "number" or type(slot) ~= "number" or slot < 1 then return end
    local ok, info = pcall(C_Container.GetContainerItemInfo, bag, slot)
    if ok and info and info.itemID == itemIDFromLink(item) then return info.stackCount end
end

local function priceRowText(entry, count)
    local label = entry.label
    if count > 1 then label = label .. " |cff8fa9dbx" .. count .. "|r" end
    local amount = money(entry.value * count) .. entry.suffix
    return label, amount
end

local function addPriceRow(tt, tracked, label, value, suffix, count, auctionIndex)
    local entry = {index = tt:NumLines() + 1, label = label, value = value, suffix = suffix}
    local shownLabel, amount = priceRowText(entry, count)
    tt:AddDoubleLine(shownLabel, amount, C.gold[1], C.gold[2], C.gold[3], C.white[1], C.white[2], C.white[3])
    entry.lastLabel = shownLabel
    tracked[#tracked + 1] = entry
    if auctionIndex then
        for _, side in ipairs({"Left", "Right"}) do
            local field = tooltipLine(tt, side, entry.index)
            local reference = tooltipLine(tt, side, auctionIndex)
            local font = reference and reference.GetFontObject and reference:GetFontObject()
            if field and font then field:SetFontObject(font) end
        end
    end
end

local function redrawShiftMarketIfNeeded()
    if AHledgerAPI and type(AHledgerAPI.IsTooltipOn) == "function" then
        local ok, on = pcall(AHledgerAPI.IsTooltipOn)
        if ok and on then return end
    end
    local tip = GameTooltip
    if not tip or (tip.IsForbidden and tip:IsForbidden()) or not tip.IsShown or not tip:IsShown() or not tip.GetOwner then return end
    local owner = tip:GetOwner()
    if not owner then return end
    if owner.IsProtected and owner:IsProtected() then
        local action = owner.action or (owner.GetAttribute and owner:GetAttribute("action"))
        local slot = owner.GetID and owner:GetID()
        local bag = owner.GetBagID and owner:GetBagID()
        if type(bag) ~= "number" and owner.GetParent and owner:GetParent() and owner:GetParent().GetID then
            bag = owner:GetParent():GetID()
        end
        if type(action) == "number" and tip.SetAction then
            tip:Hide(); tip:SetOwner(owner, "ANCHOR_RIGHT"); tip:SetAction(action)
        elseif type(bag) == "number" and type(slot) == "number" and tip.SetBagItem then
            tip:Hide(); tip:SetOwner(owner, "ANCHOR_RIGHT"); tip:SetBagItem(bag, slot)
        end
        return
    end
    if tip.GetItem and tip.SetHyperlink then
        local _, link = tip:GetItem()
        if type(link) == "string" and link:find("|Hitem:", 1, true) then tip:SetHyperlink(link) end
    end
end

local function updateStackRows()
    if not db or not db.tooltips then return end
    for tt, tracked in pairs(tooltipRows) do
        if tt:IsShown() and (not tt.IsForbidden or not tt:IsForbidden()) then
            local count = IsShiftKeyDown and IsShiftKeyDown() and tracked.count or 1
            local changed = false
            for _, entry in ipairs(tracked) do
                local left = tooltipLine(tt, "Left", entry.index)
                local right = tooltipLine(tt, "Right", entry.index)
                if left and right and readableTooltipText(left) == entry.lastLabel then
                    if entry == tracked.quote and not priceFor(tracked.item) then
                        left:SetText("")
                        right:SetText("")
                        entry.lastLabel = nil
                    else
                        if entry == tracked.quote then entry.suffix = count > 1 and " (est.)" or "" end
                        local label, amount = priceRowText(entry, count)
                        left:SetText(label)
                        right:SetText(amount)
                        if right.Show then right:Show() end
                        entry.lastLabel = label
                    end
                    changed = true
                end
            end
            if changed then tt:Show() end
        end
    end
end

-- Always-visible AHledger market context.  Listed is observed listed *units*,
-- never the number of individual auction posts.  Sold/day is an inference
-- from repeated scans, NOT confirmed purchases.  No values are fabricated.
local function commaNumber(n)
    n = math.floor(n + 0.5)
    local t = tostring(n):reverse():gsub("(%d%d%d)", "%1,"):reverse()
    return (t:gsub("^,", ""))
end

local function approxCount(n)
    if n <= 0 then return "0" end
    if n < 1 then return "<1" end
    if n < 10 then return tostring(math.floor(n + 0.5)) end
    local exponent = math.floor(math.log(n) / math.log(10)) - 1
    local step = 10 ^ exponent
    return commaNumber(math.floor(n / step + 0.5) * step)
end

local function paceSummary(qty, perDay)
    if not perDay then return "Sales speed: unavailable", "|cff9d9d9d" end
    local tier
    if not qty or qty <= 0 then
        tier = perDay >= 1 and "fast" or "barely"
    elseif perDay <= 0 then
        tier = "barely"
    else
        local days = qty / perDay
        if days < 1 then tier = "fast"
        elseif days <= 3 then tier = "steady"
        elseif days <= 14 then tier = "slow"
        else tier = "barely" end
    end
    local descriptions = {
        fast = "Sells fast", steady = "Sells steadily",
        slow = "Sells slowly", barely = "Barely sells",
    }
    local colors = {
        fast = "|cff3ddc6a", steady = "|cffededf2",
        slow = "|cffffd23f", barely = "|cff9d9d9d",
    }
    return descriptions[tier], colors[tier]
end

local function appendMarketStats(tt, item)
    if not AHledgerAPI or type(AHledgerAPI.GetPrice) ~= "function" then return end
    local ok, v = pcall(AHledgerAPI.GetPrice, item)
    if not ok or type(v) ~= "table" or type(v.market) ~= "string" then return end
    local market = v.market:gsub("/", ".")
    local expected = db and db.tkMarketOptIn and policy.externalMarket or nil
    if wrongFaction(market) or (expected and expected ~= "" and market ~= expected) then return end
    local stamp = tonumber(v.updated) or 0
    local ageSeconds = time() - stamp
    if stamp <= 0 or ageSeconds < 0 or ageSeconds > 7 * 86400 then return end

    local listed = tonumber(v.quantity)
    if not listed or listed < 0 or listed >= math.huge then listed = nil end
    local sold = tonumber(v.soldPerDay)
    if not sold or sold < 0 or sold >= math.huge then sold = nil end
    if not listed and not sold then return end

    local label, color = paceSummary(listed, sold)
    tt:AddLine(color .. label .. "|r")
    if listed then tt:AddLine("|cff9d9d9dListed: |r" .. commaNumber(listed)) end
    if sold then
        local volumeText = sold == 0 and "0" or ("~" .. approxCount(sold))
        tt:AddLine("|cff9d9d9dSold/day: |r" .. volumeText)
    end


end

local function addInfo(tt, linkOrId)
    if not db or not db.tooltips then return end
    if not tt or type(tt.AddDoubleLine) ~= "function" or type(tt.NumLines) ~= "function" then return end
    if not linkOrId then return end
    if tt.IsForbidden and tt:IsForbidden() then return end
    local originalLines = tt:NumLines()
    local context = tooltipContext(tt)
    if context.shady or tooltipRows[tt] then return end
    local vendorEntry = normalizeNativeVendor(tt, context, linkOrId)
    -- AC can add Vendor Sells before the native sell-price row is normalized.
    -- Swap adjacent plain price rows only, before tracking stack updates.
    if vendorEntry then
        local i = vendorEntry.index
        local l1, r1 = tooltipLine(tt, "Left", i), tooltipLine(tt, "Right", i)
        local l2, r2 = tooltipLine(tt, "Left", i+1), tooltipLine(tt, "Right", i+1)
        if readableTooltipText(l2) == "Vendor Sells" and readableTooltipText(r2)
            and r1 and r2 and r1:IsShown() and r2:IsShown() then
            local function swap(a,b)
                local x,y = a:GetText(), b:GetText()
                local ar,ag,ab,aa = a:GetTextColor()
                local br,bg,bb,ba = b:GetTextColor()
                a:SetText(y); a:SetTextColor(br,bg,bb,ba)
                b:SetText(x); b:SetTextColor(ar,ag,ab,aa)
            end
            swap(l1,l2); swap(r1,r2)
            vendorEntry.index = i+1
        end
    end
    local value, _, data = priceFor(linkOrId)
    local tracked = {count = stackCount(tt, linkOrId) or context.count or 1, item = linkOrId}
    if vendorEntry then
        -- Existing native row (not an added row); use the same Shift math as Shady.
        local stack = IsShiftKeyDown and IsShiftKeyDown() and tracked.count or 1
        local left = tooltipLine(tt, "Left", vendorEntry.index)
        local right = tooltipLine(tt, "Right", vendorEntry.index)
        if left and right then
            local label, amount = priceRowText(vendorEntry, stack)
            left:SetText(label)
            right:SetText(amount)
            if right.Show then right:Show() end
            vendorEntry.lastLabel = label
            tracked[#tracked + 1] = vendorEntry
        end
    end
    if tt.HookScript then
        tooltipRows[tt] = tracked
        if not clearHooks[tt] then
            clearHooks[tt] = true
            tt:HookScript("OnTooltipCleared", function(frame) tooltipRows[frame] = nil end)
            tt:HookScript("OnHide", function(frame) tooltipRows[frame] = nil end)
        end
    end
    local count = IsShiftKeyDown and IsShiftKeyDown() and tracked.count or 1
    if value then
        addPriceRow(tt, tracked, "Shady", value, count > 1 and " (est.)" or "", count, context.auction)
        tracked.quote = tracked[#tracked]
    end
    appendMarketStats(tt, linkOrId)
    if value and db.details and IsShiftKeyDown and IsShiftKeyDown() then
        local observed = date("%b %d %I:%M %p", math.floor(data.observedMs / 1000))
        tt:AddLine("  Lowest buyout · auctionhouse.tk.gg · " .. observed, 0.67, 0.67, 0.67)
        if count > 1 then tt:AddLine("  Quantity estimate at the lowest unit buyout", 0.67, 0.67, 0.67) end
    end

    if type(tt.Show) == "function" then tt:Show() end
end

-- Support modern TooltipDataProcessor and classic tooltip hook as fallback.
local function installTooltipHook()
    if TooltipDataProcessor and TooltipDataProcessor.AddTooltipPostCall and Enum
        and Enum.TooltipDataType and Enum.TooltipDataType.Item then
        TooltipDataProcessor.AddTooltipPostCall(Enum.TooltipDataType.Item, function(tt, tooltipData)
            local link
            if tt and tt.GetItem then
                local _, itemLink = tt:GetItem()
                link = itemLink
            end
            addInfo(tt, link or (tooltipData and tooltipData.id))
        end)
    else
        local tooltips = { GameTooltip, ItemRefTooltip, ShoppingTooltip1, ShoppingTooltip2 }
        for _, tt in ipairs(tooltips) do
            if tt and tt.HookScript then
                tt:HookScript("OnTooltipSetItem", function(t)
                    local _, link = t:GetItem()
                    addInfo(t, link)
                end)
            end
        end
    end
end

local function buyCost(item, quantity)
    quantity = quantity or 1
    if type(quantity) ~= "number" or quantity < 1 or quantity >= math.huge or quantity % 1 ~= 0 then
        return nil, "invalid_quantity"
    end
    local price = priceFor(item)
    if not price then return nil, "unavailable" end
    local cost = price * quantity
    if cost > 9007199254740991 then return nil, "invalid_quantity" end
    return cost, "buyout_estimate"
end

-- Comparison build: external snapshot prices are available to SPE's own UI
-- only. Other addons cannot consume these experimental quotes through this API.
ShadyPriceAPI = {
    VERSION = 3,
    GetBuyCost = function() return nil, "comparison_only" end,
    GetMarketValue = function() return nil end,
    GetPrice = function() return nil end,
    GetPriceSources = function() return {buyMethod = "comparison_only"} end,
    GetMarket = function() return nil end,
    GetRecord = function() return nil end,
}

local GREEN = {0, 1, 0}
local RED = {1, 0.12, 0.12}
local STATUS_SYMBOLS = {
    [GREEN] = {"....#", "...#.", "#.#..", ".#...", "....."},
    [RED] = {"#...#", ".#.#.", "..#..", ".#.#.", "#...#"},
}

local function dataHealth()
    local data, reason = getData()
    if not data then return RED, reason end
    return GREEN, "Current TK snapshot"
end

local function statusTime(stamp)
    return type(stamp) == "number" and stamp > 0 and date("%b %d %I:%M %p", stamp) or "unavailable"
end

local function showStatusTooltip(frame)
    if not GameTooltip then return end
    local color, label = dataHealth()
    GameTooltip:SetOwner(frame, "ANCHOR_BOTTOM")
    GameTooltip:AddLine("Shady price data")
    GameTooltip:AddLine(label, unpack(color))
    GameTooltip:AddLine("Loaded market: " .. (DATA.market or "none"))
    GameTooltip:AddLine("Blizzard observation: " .. statusTime(DATA.observedMs and math.floor(DATA.observedMs / 1000)))
    GameTooltip:AddLine("Last successful fetch: " .. statusTime(DATA.fetchedMs and math.floor(DATA.fetchedMs / 1000)))
    GameTooltip:AddLine("Last updater attempt: " .. statusTime(DATA.attemptedMs and math.floor(DATA.attemptedMs / 1000)))
    GameTooltip:AddLine("Shows the status loaded at /reload.", 0.72, 0.72, 0.72)
    GameTooltip:AddLine("Click to search prices.", 0.72, 0.72, 0.72)
    GameTooltip:Show()
end

local openSearch
local indicator
local function updateIndicator()
    if not db.showIndicator then
        if indicator then indicator:Hide() end
        return
    end
    if not indicator then
        indicator = CreateFrame("Button", "ShadyPriceStatusIndicator", UIParent)
        indicator:SetSize(16, 16)
        indicator:SetFrameStrata("MEDIUM")
        indicator:SetClampedToScreen(true)
        indicator:SetMovable(true)
        indicator:RegisterForDrag("LeftButton")
        indicator:SetScript("OnClick", function() openSearch() end)
        indicator:SetPoint("CENTER", UIParent, "CENTER", db.indicatorX or 0, db.indicatorY or 120)
        local border = indicator:CreateTexture(nil, "BACKGROUND")
        border:SetSize(16, 16)
        border:SetPoint("CENTER")
        border:SetColorTexture(0.06, 0.06, 0.06, 0.85)
        local dot = indicator:CreateTexture(nil, "ARTWORK")
        dot:SetSize(14, 14)
        dot:SetPoint("CENTER")
        indicator.dot = dot
        indicator.symbols = {}
        for color, pattern in pairs(STATUS_SYMBOLS) do
            local pixels = {}
            for row, line in ipairs(pattern) do
                for column = 1, #line do
                    if line:sub(column, column) == "#" then
                        local pixel = indicator:CreateTexture(nil, "OVERLAY")
                        pixel:SetSize(2, 2)
                        pixel:SetPoint("CENTER", (column - 3) * 2, (3 - row) * 2)
                        pixel:SetColorTexture(0, 0, 0)
                        pixels[#pixels + 1] = pixel
                    end
                end
            end
            indicator.symbols[color] = pixels
        end
        indicator:SetScript("OnEnter", showStatusTooltip)
        indicator:SetScript("OnLeave", function() GameTooltip:Hide() end)
        indicator:SetScript("OnDragStart", indicator.StartMoving)
        indicator:SetScript("OnDragStop", function(frame)
            frame:StopMovingOrSizing()
            local x, y = frame:GetCenter()
            local parentX, parentY = UIParent:GetCenter()
            db.indicatorX, db.indicatorY = x - parentX, y - parentY
            frame:ClearAllPoints()
            frame:SetPoint("CENTER", UIParent, "CENTER", db.indicatorX, db.indicatorY)
        end)
    end
    local color = dataHealth()
    indicator.dot:SetColorTexture(unpack(color))
    for symbolColor, pixels in pairs(indicator.symbols) do
        for _, pixel in ipairs(pixels) do pixel:SetShown(color == symbolColor) end
    end
    indicator:Show()
end

local settings
local function updateSettingsAppearance()
    if not settings then return end
    settings.bg:SetColorTexture(0,0,0,db.solid and 1 or 0.85)
    settings.tick1:SetText((db.tooltips and "[x] " or "[ ] ") .. "Show Shady on item tooltips")
    settings.tick2:SetText((db.details and "[x] " or "[ ] ") .. "Show source details while Shift is held")
    settings.tick3:SetText((db.solid and "[x] " or "[ ] ") .. "Solid black settings background")
    local color, label = dataHealth()
    settings.hint:SetText("Price data: " .. label)
    settings.hint:SetTextColor(unpack(color))
    settings.tick6:SetText(db.autoIndex and "Search index: Auto on open" or "Search index: Manual")
    settings.tick5:SetText((db.showIndicator and "[x] " or "[ ] ") .. "Show movable price data indicator")
    settings.tick4:SetText((db.coinIcons ~= false and "[x] " or "[ ] ") .. "Use gold/silver/copper coin icons")
end

local function makeButton(parent, x, y, w, caption, click)
    local b = CreateFrame("Button", nil, parent, "UIPanelButtonTemplate")
    b:SetWidth(w); b:SetHeight(23)
    b:SetPoint("TOPLEFT", parent, "TOPLEFT", x, y)
    b:SetText(caption)
    b:SetScript("OnClick", click)
    return b
end

local searchFrame, detailsFrame
local searchResults = {}
local itemNames, requestedItems = {}, {}
local searchItems, indexPosition = {}, 1
local searchTicker, searchDebounce, searchQuery
local indexReady, indexStarted, archive
local selectedResult = 1
local MAX_RESULTS = 7

local function itemInfo(id)
    local api = C_Item and C_Item.GetItemInfo or GetItemInfo
    if api then
        local name, link, _, _, _, _, _, _, _, icon = api(id)
        if name then return name, link, icon end
    end
end

local function refreshItemIndex()
    if indexReady then return end
    indexReady = true
    local ids = {}
    local data = getData()
    for id in pairs(data and data.rows or {}) do ids[id] = true end
    for id in pairs(liveQuotes() or {}) do ids[id] = true end
    for id in pairs(ids) do
        local saved = archive[id]
        if saved and type(saved[1]) == "string" then
            itemNames[id] = {id = id, name = saved[1], lower = saved[1]:lower(), icon = (tonumber(saved[2]) or 0) > 0 and saved[2] or nil}
        else
            searchItems[#searchItems + 1] = id
        end
    end
end

local function rememberItem(id)
    local name, link, icon = itemInfo(id)
    if name then
        if not itemNames[id] then searchQuery = nil end
        itemNames[id] = {id = id, name = name, link = link, icon = icon, lower = name:lower()}
        archive[id] = {name, type(icon) == "number" and icon or 0}
        requestedItems[id] = nil
    elseif not itemNames[id] and not requestedItems[id] then
        requestedItems[id] = true
        if C_Item and C_Item.RequestLoadItemDataByID then C_Item.RequestLoadItemDataByID(id) end
    end
    return itemNames[id]
end

local function makeSearchWindow(name, height)
    local frame = CreateFrame("Frame", name, UIParent, "BackdropTemplate")
    frame:SetSize(392, height)
    frame:SetPoint("CENTER", 0, 110)
    frame:SetFrameStrata("DIALOG")
    frame:SetClampedToScreen(true)
    frame:SetMovable(true)
    frame:EnableMouse(true)
    frame:RegisterForDrag("LeftButton")
    frame:SetScript("OnDragStart", frame.StartMoving)
    frame:SetScript("OnDragStop", frame.StopMovingOrSizing)
    frame:SetBackdrop({bgFile = "Interface\\Buttons\\WHITE8X8",
        edgeFile = "Interface\\DialogFrame\\UI-DialogBox-Border", edgeSize = 18,
        insets = {left = 4, right = 4, top = 4, bottom = 4}})
    frame:SetBackdropColor(0.045, 0.045, 0.06, db.solid and 1 or 0.86)
    frame:Hide()
    if UISpecialFrames then UISpecialFrames[#UISpecialFrames + 1] = name end
    return frame
end

local function searchText(frame, font, x, y)
    local label = frame:CreateFontString(nil, "OVERLAY", font)
    label:SetPoint("TOPLEFT", x, y)
    label:SetWidth(352)
    label:SetJustifyH("LEFT")
    return label
end

local function showItemTip(frame, item)
    if not GameTooltip then return end
    GameTooltip:SetOwner(frame, "ANCHOR_RIGHT")
    if item.link then GameTooltip:SetHyperlink(item.link)
    elseif GameTooltip.SetItemByID then GameTooltip:SetItemByID(item.id) end
    GameTooltip:Show()
end

local function linkItem(item)
    if not item.link then return false end
    if HandleModifiedItemClick and HandleModifiedItemClick(item.link) then return true end
    if ChatEdit_InsertLink then ChatEdit_InsertLink(item.link) end
    return true
end

local function displayDetails(item)
    if not detailsFrame then
        local frame = makeSearchWindow("ShadyPriceSearchDetails", 362)
        detailsFrame = frame
        local close = CreateFrame("Button", nil, frame, "UIPanelCloseButton")
        close:SetPoint("TOPRIGHT", -4, -4)
        close:SetScript("OnClick", function()
            frame.closeAll = true
            frame:Hide()
        end)
        makeButton(frame, 18, -14, 64, "Back", function() frame:Hide() end)
        frame.itemButton = makeButton(frame, 18, -46, 356, "", function()
            if IsShiftKeyDown and IsShiftKeyDown() then linkItem(frame.item) end
        end)
        frame.itemButton:SetScript("OnEnter", function(self) showItemTip(self, frame.item) end)
        frame.itemButton:SetScript("OnLeave", function() if GameTooltip then GameTooltip:Hide() end end)
        local qtyLabel = searchText(frame, "GameFontNormal", 18, -85)
        qtyLabel:SetText("Quantity")
        local quantity = CreateFrame("EditBox", nil, frame, "InputBoxTemplate")
        quantity:SetSize(64, 23)
        quantity:SetPoint("TOPLEFT", 99, -79)
        quantity:SetAutoFocus(false)
        quantity:SetNumeric(true)
        quantity:SetMaxLetters(5)
        quantity:SetScript("OnEnterPressed", function(self) self:ClearFocus() end)
        quantity:SetScript("OnEscapePressed", function(self) self:ClearFocus(); frame:Hide() end)
        frame.quantity = quantity
        frame.prices = searchText(frame, "GameFontHighlight", 18, -114)
        frame.prices:SetSpacing(3)
        local tribute = searchText(frame, "GameFontDisableSmall", 18, -335)
        tribute:SetJustifyH("CENTER")
        tribute:SetFont("Fonts\\MORPHEUS.ttf", 12, "OUTLINE")
        tribute:SetTextColor(0.92, 0.73, 0.28)
        tribute:SetText("RIP Shady")
        frame:SetScript("OnHide", function(self)
            if GameTooltip and GameTooltip:IsOwned(self.itemButton) then GameTooltip:Hide() end
            if self.closeAll then self.closeAll = nil; return end
            searchFrame:Show()
            searchFrame.input:SetFocus()
        end)
        frame.quantity:SetScript("OnTextChanged", function()
            if not frame.item then return end
            local id = frame.item.id
            local qty = math.max(1, tonumber(quantity:GetText()) or 1)
            local unit, _, data = priceFor(id)
            local cost = buyCost(id, qty)
            if not cost then
                frame.prices:SetText("No current TK buyout available")
                return
            end
            frame.prices:SetText(table.concat({
                "Lowest buyout / item  " .. money(unit),
                "Buyout estimate ×" .. qty .. "  " .. money(cost),
                "Observed  " .. statusTime(math.floor(data.observedMs / 1000)),
                "Source  auctionhouse.tk.gg",
            }, "\n"))
        end)
    end
    searchFrame:Hide()
    local frame = detailsFrame
    frame.item = item
    frame.itemButton:SetText(item.name)
    frame.quantity:SetText("1")
    local update = frame.quantity:GetScript("OnTextChanged")
    update()
    frame:Show()
end

local function refreshSearch()
    if not searchFrame or not searchFrame:IsShown() then return end
    local input = searchFrame.input:GetText():match("^%s*(.-)%s*$")
    local id = itemIDFromLink(input)
    local query = input:lower()
    if searchQuery ~= query then
        searchQuery = query
        local matches, total = {}, 0
        if id and id > 0 and id % 1 == 0 and id <= 5000000 then
            matches[1] = rememberItem(id) or {id = id, name = "Item #" .. id}
            total = 1
        elseif #query >= 2 then
            local words = {}
            for word in query:gmatch("[^%s:]+") do words[#words + 1] = word end
            local function matchesWords(name)
                for _, word in ipairs(words) do
                    if not name:find(word, 1, true) then return false end
                end
                return #words > 0
            end
            local function precedes(a, b)
                local aStart = a.lower:sub(1, #query) == query
                local bStart = b.lower:sub(1, #query) == query
                if aStart ~= bStart then return aStart end
                local aPhrase, bPhrase = a.lower:find(query, 1, true), b.lower:find(query, 1, true)
                if (aPhrase ~= nil) ~= (bPhrase ~= nil) then return aPhrase ~= nil end
                if a.lower ~= b.lower then return a.lower < b.lower end
                return a.id < b.id
            end
            for _, item in pairs(itemNames) do
                if matchesWords(item.lower) then
                    total = total + 1
                    local position = #matches + 1
                    while position > 1 and precedes(item, matches[position - 1]) do
                        position = position - 1
                    end
                    if position <= MAX_RESULTS then
                        table.insert(matches, position, item)
                        matches[MAX_RESULTS + 1] = nil
                    end
                end
            end
        end
        searchResults = matches
        searchFrame.matchCount = total
    end
    local matches = searchResults
    selectedResult = math.max(1, math.min(selectedResult, #matches, MAX_RESULTS))
    for i, button in ipairs(searchFrame.rows) do
        local item = matches[i]
        if item then
            button:SetText(item.name)
            button.icon:SetTexture(item.icon or 134400)
            button.icon:Show()
            if i == selectedResult then button:LockHighlight() else button:UnlockHighlight() end
            button:Show()
        else
            button:Hide()
        end
    end
    local message = ""
    if input == "" or (not id and #query < 2) then
        message = "Enter an item name, ID, or item link."
    elseif not id and indexPosition <= #searchItems then
        message = indexStarted and "Loading missing item names…" or "Build Index to load missing names."
    elseif #matches == 0 then
        message = "No matching items found."
    elseif searchFrame.matchCount > MAX_RESULTS then
        message = "Keep typing to narrow the results."
    end
    searchFrame.message:SetText(message)
    searchFrame.indexButton:SetText(id and "Look Up" or "Build Index")
end

local function queueSearch()
    if searchDebounce then return end
    if C_Timer and C_Timer.NewTimer then
        searchDebounce = C_Timer.NewTimer(0.12, function()
            searchDebounce = nil
            refreshSearch()
        end)
    else
        refreshSearch()
    end
end

local function startSearchIndex()
    indexStarted = true
    if searchTicker or indexPosition > #searchItems or not C_Timer or not C_Timer.NewTicker then return end
    searchTicker = C_Timer.NewTicker(0.05, function()
        for _ = 1, 40 do
            local id = searchItems[indexPosition]
            if not id then break end
            rememberItem(id)
            indexPosition = indexPosition + 1
        end
        if indexPosition > #searchItems then
            searchTicker:Cancel()
            searchTicker = nil
        end
        queueSearch()
    end)
end

-- Key by the recipe item ID so a crafted item cannot inherit its pattern's source.
local ITEM_SOURCES = {
    [14497] = {{label = "Creature drop (Classic source)"}},
    [14499] = {{label = "World drop · no fixed waypoint"}},
    [14509] = {{label = "Creature drop · no verified waypoint"}},
    [14526] = {{label = "Qia · Everlook, Winterspring", map = 1452, x = 0.612, y = 0.372}},
    [18487] = {{label = "Shen'dralar Provisioner · Dire Maul"}},
}

local function openSourceMap(source)
    local mapID = source.map
    local map = WorldMapFrame
    if map and map.SetMapID then
        if ShowUIPanel then ShowUIPanel(map) else map:Show() end
        map:SetMapID(mapID)
    elseif OpenWorldMap then
        OpenWorldMap(mapID)
    end
    local placed
    if C_Map and C_Map.SetUserWaypoint and UiMapPoint and UiMapPoint.CreateFromCoordinates
        and (not C_Map.CanSetUserWaypointOnMap or C_Map.CanSetUserWaypointOnMap(mapID)) then
        local ok, result = pcall(function()
            return C_Map.SetUserWaypoint(UiMapPoint.CreateFromCoordinates(mapID, source.x, source.y))
        end)
        placed = ok and result ~= false
        if placed and C_SuperTrack and C_SuperTrack.SetSuperTrackedUserWaypoint then
            pcall(C_SuperTrack.SetSuperTrackedUserWaypoint, true)
        end
    end
    if not placed and TomTom and TomTom.AddWaypoint then
        local ok, result = pcall(TomTom.AddWaypoint, TomTom, mapID, source.x, source.y,
            {title = source.label, persistent = false})
        placed = ok and result
    end
    if not placed then
        chat(string.format("%s (%.1f, %.1f). Waypoint unavailable.", source.label, source.x * 100, source.y * 100))
    end
end

local sourcePopup
local function setSearchEscape(enabled)
    if not UISpecialFrames then return end
    local name = "ShadyPriceItemSearch"
    for i, entry in ipairs(UISpecialFrames) do
        if entry == name then
            if not enabled then table.remove(UISpecialFrames, i) end
            return
        end
    end
    if enabled then UISpecialFrames[#UISpecialFrames + 1] = name end
end
local function showItemSources(item)
    local sources = ITEM_SOURCES[item.id]
    if sources and #sources == 1 and sources[1].map then
        if sourcePopup then sourcePopup:Hide() end
        openSourceMap(sources[1])
        return
    end
    if not sourcePopup then
        sourcePopup = makeSearchWindow("ShadyPriceItemSources", 116)
        sourcePopup:SetFrameStrata("FULLSCREEN_DIALOG")
        sourcePopup:SetScript("OnHide", function(self)
            -- Restore Search after Blizzard finishes dispatching this Escape.
            local function restore()
                if self:IsShown() then return end
                setSearchEscape(true)
                if searchFrame:IsShown() then searchFrame.input:SetFocus() end
            end
            if C_Timer and C_Timer.After then C_Timer.After(0, restore) else restore() end
        end)
        local close = CreateFrame("Button", nil, sourcePopup, "UIPanelCloseButton")
        close:SetPoint("TOPRIGHT", -4, -4)
        sourcePopup.title = searchText(sourcePopup, "GameFontNormal", 16, -16)
        sourcePopup.title:SetWidth(325)
        sourcePopup.rows = {}
        searchFrame:HookScript("OnHide", function() sourcePopup:Hide() end)
    end
    sourcePopup.title:SetText(item.name .. " sources")
    for _, row in ipairs(sourcePopup.rows) do row:Hide() end
    sources = sources or {{label = "No source recorded for this item."}}
    for i, source in ipairs(sources) do
        local row = sourcePopup.rows[i]
        if not row then
            row = makeButton(sourcePopup, 16, -45 - (i - 1) * 27, 356, "", function(self)
                openSourceMap(self.source)
                sourcePopup:Hide()
            end)
            sourcePopup.rows[i] = row
        end
        row.source = source
        row:SetText(source.label)
        row:SetEnabled(source.map ~= nil)
        row:Show()
    end
    sourcePopup:SetHeight(64 + #sources * 27)
    setSearchEscape(false)
    searchFrame.input:ClearFocus()
    sourcePopup:Show()
    sourcePopup:Raise()
end

local function selectItem(index)
    local item = searchResults[index]
    if not item then return end
    item = rememberItem(item.id) or item
    if IsShiftKeyDown and IsShiftKeyDown() then linkItem(item); return end
    displayDetails(item)
end

openSearch = function()
    if detailsFrame and detailsFrame:IsShown() then return end
    if not searchFrame then
        local frame = makeSearchWindow("ShadyPriceItemSearch", 307)
        searchFrame = frame
        local title = searchText(frame, "GameFontNormalLarge", 18, -15)
        title:SetText("Shady Price Search")
        local close = CreateFrame("Button", nil, frame, "UIPanelCloseButton")
        close:SetPoint("TOPRIGHT", -4, -4)
        local input = CreateFrame("EditBox", nil, frame, "InputBoxTemplate")
        input:SetSize(236, 25)
        input:SetPoint("TOPLEFT", 25, -46)
        input:SetAutoFocus(false)
        input:SetMaxLetters(255)
        input:SetAltArrowKeyMode(false)
        frame.input = input
        frame.indexButton = makeButton(frame, 274, -46, 100, "Build Index", function()
            local inputText = input:GetText():match("^%s*(.-)%s*$")
            if itemIDFromLink(inputText) then
                refreshSearch()
                selectItem(1)
            else
                startSearchIndex()
                refreshSearch()
            end
        end)
        frame.rows = {}
        for i = 1, MAX_RESULTS do
            local index = i
            local button = makeButton(frame, 18, -81 - (i - 1) * 26, 356, "", function(_, mouseButton)
                if searchDebounce then return end
                if mouseButton == "RightButton" then
                    local item = searchResults[index]
                    if item then showItemSources(item) end
                else
                    selectItem(index)
                end
            end)
            button:RegisterForClicks("LeftButtonUp", "RightButtonUp")
            local icon = button:CreateTexture(nil, "OVERLAY")
            icon:SetSize(18, 18)
            icon:SetPoint("LEFT", 5, 0)
            button.icon = icon
            button:SetScript("OnEnter", function(self)
                if searchResults[index] then
                    showItemTip(self, searchResults[index])
                    if GameTooltip then
                        GameTooltip:AddLine("Right-click for sources", 0.7, 0.7, 0.7)
                        GameTooltip:Show()
                    end
                end
            end)
            button:SetScript("OnLeave", function() if GameTooltip then GameTooltip:Hide() end end)
            frame.rows[i] = button
        end
        frame.message = searchText(frame, "GameFontDisableSmall", 18, -273)
        local tribute = searchText(frame, "GameFontDisableSmall", 18, -289)
        tribute:SetJustifyH("CENTER")
        tribute:SetFont("Fonts\\MORPHEUS.ttf", 12, "OUTLINE")
        tribute:SetTextColor(0.92, 0.73, 0.28)
        tribute:SetText("RIP Shady")
        input:SetScript("OnTextChanged", function() selectedResult = 1; queueSearch() end)
        input:SetScript("OnArrowPressed", function(_, key)
            if key == "UP" then selectedResult = selectedResult - 1
            elseif key == "DOWN" then selectedResult = selectedResult + 1
            else return end
            refreshSearch()
        end)
        input:SetScript("OnEnterPressed", function() refreshSearch(); selectItem(selectedResult) end)
        input:SetScript("OnEscapePressed", function()
            if sourcePopup and sourcePopup:IsShown() then sourcePopup:Hide() else frame:Hide() end
        end)
        frame:SetScript("OnHide", function()
            input:ClearFocus()
            if searchDebounce then searchDebounce:Cancel(); searchDebounce = nil end
            if searchTicker then searchTicker:Cancel(); searchTicker = nil end
        end)
        frame:SetScript("OnShow", function()
            refreshItemIndex()
            refreshSearch()
            if db.autoIndex or indexStarted then startSearchIndex() end
        end)
    end
    searchFrame:Show()
    searchFrame.input:SetFocus()
end

ShadyPriceAPI.OpenSearch = function()
    if db then openSearch() end
end

-- Bag addons can offer a link before dispatching their own Shift-left-click.
ShadyPriceAPI.TrySearchItem = function(link)
    if not searchFrame or (not searchFrame:IsShown()
        and not (detailsFrame and detailsFrame:IsShown())) then return false end
    local id = itemIDFromLink(link)
    if not id or id <= 0 then return false end
    local item = rememberItem(id)
    if type(link) == "string" and link:find("|Hitem:", 1, true) then
        item = {id = id, link = link, icon = item and item.icon,
            name = link:match("|h%[(.-)%]|h") or (item and item.name) or ("Item #" .. id)}
    end
    searchFrame.input:SetText(type(link) == "string" and link or tostring(id))
    displayDetails(item or {id = id, name = "Item #" .. id})
    return true
end

local function makeSettings()
    if settings then return settings end
    settings = CreateFrame("Frame", "ShadyPriceSettings", UIParent)
    settings:SetSize(365, 310)
    settings:SetPoint("CENTER", UIParent, "CENTER")
    settings:SetFrameStrata("DIALOG")
    settings:SetMovable(true)
    settings:EnableMouse(true)
    settings:RegisterForDrag("LeftButton")
    settings:SetScript("OnDragStart", settings.StartMoving)
    settings:SetScript("OnDragStop", settings.StopMovingOrSizing)
    settings:SetClampedToScreen(true)
    settings.bg = settings:CreateTexture(nil,"BACKGROUND")
    settings.bg:SetAllPoints()
    local title = settings:CreateFontString(nil, "OVERLAY", "GameFontNormalLarge")
    title:SetPoint("TOPLEFT", 14, -13)
    title:SetText("Shady Price Engine")
    local close = CreateFrame("Button", nil, settings, "UIPanelCloseButton")
    close:SetPoint("TOPRIGHT", -2, -2)
    settings.hint = settings:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
    settings.hint:SetPoint("TOPLEFT", 14, -44)
    settings.hint:SetWidth(340)
    settings.hint:SetJustifyH("LEFT")
    local statusHover = CreateFrame("Button", nil, settings)
    statusHover:SetPoint("TOPLEFT", 14, -40)
    statusHover:SetSize(336, 20)
    statusHover:SetScript("OnEnter", showStatusTooltip)
    statusHover:SetScript("OnLeave", function() GameTooltip:Hide() end)
    settings.tick1 = makeButton(settings, 12, -70, 336, "", function() db.tooltips = not db.tooltips; updateSettingsAppearance() end)
    settings.tick2 = makeButton(settings, 12, -100, 336, "", function() db.details = not db.details; updateSettingsAppearance() end)
    settings.tick4 = makeButton(settings, 12, -130, 336, "", function() db.coinIcons = not db.coinIcons; updateSettingsAppearance() end)
    settings.tick3 = makeButton(settings, 12, -160, 336, "", function() db.solid = not db.solid; updateSettingsAppearance() end)
    settings.tick5 = makeButton(settings, 12, -190, 336, "", function()
        db.showIndicator = not db.showIndicator
        updateIndicator()
        updateSettingsAppearance()
    end)
    settings.tick6 = makeButton(settings, 12, -220, 336, "", function()
        db.autoIndex = not db.autoIndex
        updateSettingsAppearance()
    end)
    local footer = settings:CreateFontString(nil, "OVERLAY", "GameFontDisableSmall")
    footer:SetPoint("BOTTOMLEFT", 14, 30)
    footer:SetText("Prices: auctionhouse.tk.gg + ahledger.com")
    local memorial = settings:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
    memorial:SetPoint("BOTTOM", 0, 10)
    memorial:SetFont("Fonts\\MORPHEUS.ttf", 12, "OUTLINE")
    memorial:SetTextColor(0.92, 0.73, 0.28)
    memorial:SetText("RIP Shady")
    settings:Hide()
    updateSettingsAppearance()
    return settings
end

local function status()
    local _, label = dataHealth()
    chat("Price data: " .. label)
    local d = getData()
    if not d or not d.market or d.market == "" then
        chat("No market prices installed yet. Install a verified TK snapshot and reload.")
        return
    end
    local ago = 0
    if d.observedMs and d.observedMs > 0 then ago = math.max(0, math.floor((time() - d.observedMs / 1000) / 3600)) end
    chat(string.format("Market %s | %d items | newest snapshot %dh old | details %s",
        d.market, tonumber(d.itemCount) or 0, ago, db.details and "on" or "off"))
end

SLASH_SHADYPRICE1 = "/shady"
SLASH_SHADYPRICE2 = "/shadyprice"
SlashCmdList.SHADYPRICE = function(input)
    local command, arg = (input or ""):match("^(%S*)%s*(.-)%s*$")
    command = (command or ""):lower()
    if command == "search" then
        openSearch()
        if arg ~= "" and searchFrame:IsShown() then searchFrame.input:SetText(arg) end
    elseif command == "settings" or command == "options" then
        local f = makeSettings()
        if f:IsShown() then f:Hide() else updateSettingsAppearance(); f:Show() end
    elseif command == "detail" or command == "details" then
        db.details = not db.details
        updateSettingsAppearance()
        chat("Shift-only tooltip source details: " .. (db.details and "ON" or "OFF"))
    elseif command == "coins" or command == "coin" then
        if arg == "on" then db.coinIcons = true
        elseif arg == "off" then db.coinIcons = false
        else db.coinIcons = not db.coinIcons end
        updateSettingsAppearance()
        chat("Coin icons: " .. (db.coinIcons and "ON" or "OFF") .. " (reopen the tooltip to see the change)")
    elseif command == "tip" then
        db.tooltips = arg ~= "off"
        updateSettingsAppearance()
        chat("Item tooltips: " .. (db.tooltips and "ON" or "OFF"))
    elseif command == "native" or command == "sellprice" then
        db.hideNativeSell = (arg ~= "off")
        chat("Normalize native Vendor line: " .. (db.hideNativeSell and "ON" or "OFF") .. " (rehover item)")
    elseif command == "tk" then
        if arg == "us-pvp-horde" then db.tkMarketOptIn = true
        elseif arg == "off" then db.tkMarketOptIn = false end
        updateStackRows()
        status()
    elseif command == "test" then
        local price = priceFor(arg)
        if price then
            chat("Item " .. tostring(arg) .. ": " .. money(price) .. " (TK buyout)")
        else chat("No recent price for item " .. tostring(arg)) end
    else status() end
end

addon:RegisterEvent("ADDON_LOADED")
addon:RegisterEvent("PLAYER_LOGIN")
addon:RegisterEvent("GET_ITEM_INFO_RECEIVED")
addon:RegisterEvent("MODIFIER_STATE_CHANGED")
addon:RegisterEvent("AUCTION_HOUSE_SHOW")
addon:RegisterEvent("AUCTION_HOUSE_CLOSED")
if C_AuctionHouse then
    addon:RegisterEvent("COMMODITY_SEARCH_RESULTS_UPDATED")
    addon:RegisterEvent("ITEM_SEARCH_RESULTS_UPDATED")
end
addon:SetScript("OnEvent", function(self, event, arg1)
    if event == "ADDON_LOADED" and arg1 == ADDON then
        ShadyPriceDB = ShadyPriceDB or {}
        for k, v in pairs(DEFAULT) do
            if ShadyPriceDB[k] == nil then ShadyPriceDB[k] = v end
        end
        db = ShadyPriceDB
        -- Apply the user's three-price-row layout once.  The value remains
        -- editable with /shady tip on|off after migration.
        if not db.shadyUnifiedTooltipV2 then
            db.shadyUnifiedTooltipV2 = true
            db.tooltips = true
        end
        local locale = GetLocale and GetLocale() or "enUS"
        db.itemNameArchives = db.itemNameArchives or {}
        db.itemNameArchives[locale] = db.itemNameArchives[locale] or {}
        archive = db.itemNameArchives[locale]
        self:UnregisterEvent("ADDON_LOADED")
        installTooltipHook()
    elseif event == "GET_ITEM_INFO_RECEIVED" and requestedItems[arg1] then
        if rememberItem(arg1) and searchFrame and searchFrame:IsShown() then
            queueSearch()
        end
    elseif event == "MODIFIER_STATE_CHANGED" then
        if arg1 == "LSHIFT" or arg1 == "RSHIFT" then
            updateStackRows()
            redrawShiftMarketIfNeeded()
        end
    elseif event == "AUCTION_HOUSE_SHOW" then
        auctionOpen = true
    elseif event == "AUCTION_HOUSE_CLOSED" then
        auctionOpen = false
    elseif event == "COMMODITY_SEARCH_RESULTS_UPDATED" then
        captureBuyout(arg1, true)
    elseif event == "ITEM_SEARCH_RESULTS_UPDATED" then
        captureBuyout(arg1, false)
    elseif event == "PLAYER_LOGIN" and db then
        for _, quotes in pairs(db.liveQuotes or {}) do
            for id, quote in pairs(quotes) do
                if type(quote) ~= "table" or type(quote[2]) ~= "number" or time() - quote[2] > QUOTE_AGE then
                    quotes[id] = nil
                end
            end
        end
        updateIndicator()
        if C_Timer and C_Timer.NewTicker then
            C_Timer.NewTicker(60, function()
                if db.showIndicator then updateIndicator() end
                if settings and settings:IsShown() then updateSettingsAppearance() end
                if not getData() then
                    updateStackRows()
                    if detailsFrame and detailsFrame:IsShown() then
                        detailsFrame.quantity:GetScript("OnTextChanged")()
                    end
                end
            end)
        end
        if type(DATA.market) == "string" and DATA.market ~= "" and UnitFactionGroup then
            local faction = UnitFactionGroup("player")
            faction = faction and faction:lower() or ""
            if faction ~= "" and DATA.market:find("%.horde%.") and faction ~= "horde" then
                chat("WARNING: downloaded prices are for Horde but this character is " .. faction .. ". Confirm the market before using TK prices.")
            elseif faction ~= "" and DATA.market:find("%.alliance%.") and faction ~= "alliance" then
                chat("WARNING: downloaded prices are for Alliance but this character is " .. faction .. ". Confirm the market before using TK prices.")
            end
        end
    end
end)
