-- Independent, read-only player-centered world map overlay.
local _, addon = ...
local runner = {}
addon.MapRunner = runner
local frame, panel, cfg, art, arrow, waypoint, status
local tiles, cache = {}, nil
local elapsed, retry, warned = 0, 0, false
local function plain(v) return not (issecretvalue and issecretvalue(v)) end
local function num(v) return plain(v) and type(v)=='number' and v==v and math.abs(v)<math.huge end
local function clamp(v, lo, hi, default) if not num(v) then return default end return math.max(lo, math.min(hi,v)) end
local function call(fn, ...)
    if type(fn)~='function' then return nil end
    local ok,a,b=pcall(fn,...)
    if ok and plain(a) and plain(b) then return a,b end
end
local function position(p)
    if not p or not plain(p) then return end
    local x,y=call(p.GetXY,p)
    if num(x) and num(y) and x>=0 and x<=1 and y>=0 and y<=1 then return x,y end
end
local function clear(msg)
    for _,t in ipairs(tiles) do t:Hide() end
    arrow:Hide(); waypoint:Hide(); status:SetText(msg or 'Map unavailable'); status:Show()
end
local function paint()
    local api=C_Map
    if not api then clear(); return end
    local id=call(api.GetBestMapForUnit,'player')
    if not num(id) then clear(); return end
    local x,y=position(call(api.GetPlayerMapPosition,id,'player'))
    if not x then clear('Player position unavailable'); return end
    if not cache or cache.id~=id then
        if GetTime()<retry then clear('Loading zone map'); return end
        retry=GetTime()+1
        local layers=call(api.GetMapArtLayers,id)
        local layer=type(layers)=='table' and layers[1]
        local assets=call(api.GetMapArtLayerTextures,id,1)
        if not plain(layer) or type(layer)~='table' or type(assets)~='table' then clear(); return end
        local w,h,tw,th=layer.layerWidth,layer.layerHeight,layer.tileWidth,layer.tileHeight
        if not (num(w) and num(h) and num(tw) and num(th)) or math.min(w,h,tw,th)<=0 or math.ceil(w/tw)*math.ceil(h/th)>512 then clear(); return end
        cache={id=id,w=w,h=h,tw=tw,th=th,assets=assets}
    end
    local c=cache
    local w,h=cfg.width,cfg.height
    local s=cfg.zoom*math.min(w,h)/math.min(c.w,c.h)
    local left,top=x*c.w-w/(2*s),y*c.h-h/(2*s)
    local right,bottom=left+w/s,top+h/s
    local cols,rows=math.ceil(c.w/c.tw),math.ceil(c.h/c.th)
    local used=0
    for row=math.max(0,math.floor(top/c.th)),math.min(rows-1,math.ceil(bottom/c.th)-1) do
        for col=math.max(0,math.floor(left/c.tw)),math.min(cols-1,math.ceil(right/c.tw)-1) do
            local asset=c.assets[row*cols+col+1]
            local tx,ty=col*c.tw,row*c.th
            local x1,y1=math.max(tx,left),math.max(ty,top)
            local x2,y2=math.min(tx+c.tw,right,c.w),math.min(ty+c.th,bottom,c.h)
            if plain(asset) and ((num(asset) and asset>0) or (type(asset)=='string' and asset~='')) and x2>x1 and y2>y1 then
                used=used+1
                local t=tiles[used]
                if not t then t=art:CreateTexture(nil,'ARTWORK'); tiles[used]=t end
                if t.asset~=asset then t:SetTexture(asset); t.asset=asset end
                t:ClearAllPoints(); t:SetPoint('TOPLEFT',art,'TOPLEFT',(x1-left)*s,(top-y1)*s)
                t:SetSize((x2-x1)*s,(y2-y1)*s)
                t:SetTexCoord((x1-tx)/c.tw,(x2-tx)/c.tw,(y1-ty)/c.th,(y2-ty)/c.th); t:Show()
            end
        end
    end
    for i=used+1,#tiles do tiles[i]:Hide() end
    if used==0 then clear(); return end
    local facing=call(GetPlayerFacing)
    arrow:SetRotation(num(facing) and facing or 0); arrow:Show(); status:Hide()
    waypoint:Hide()
    local wp=call(api.GetUserWaypoint)
    if type(wp)=='table' and num(wp.uiMapID) and wp.uiMapID==id then
        local wx,wy=position(wp.position)
        if wx then
            local px,py=(wx*c.w-left)*s,(wy*c.h-top)*s
            if px>=8 and px<=w-8 and py>=8 and py<=h-8 then
                waypoint:ClearAllPoints(); waypoint:SetPoint('CENTER',frame,'TOPLEFT',px,-py); waypoint:Show()
            end
        end
    end
end
local function update()
    local ok=pcall(paint)
    if not ok then clear('Map Runner paused: map data unavailable'); if not warned then warned=true; print('MiniMappin: Map Runner could not read map data; overlay will retry.') end end
end
local function apply()
    frame:SetSize(cfg.width,cfg.height); art:SetAlpha(cfg.opacity/100)
    arrow:SetSize(cfg.arrow,cfg.arrow)
    frame:EnableMouse(not cfg.clickThrough); frame:EnableMouseWheel(not cfg.clickThrough)
    if frame:IsShown() then update() end
end
local function init()
    if frame then return true end
    if type(MiniMappinDB)~='table' then return end
    if type(MiniMappinDB.mapRunner)~='table' then MiniMappinDB.mapRunner={} end
    cfg=MiniMappinDB.mapRunner
    cfg.width=clamp(cfg.width,120,1200,450); cfg.height=clamp(cfg.height,100,900,350)
    cfg.opacity=clamp(cfg.opacity,10,100,45); cfg.zoom=clamp(cfg.zoom,1,12,3); cfg.arrow=clamp(cfg.arrow,12,50,24)
    cfg.x=clamp(cfg.x,-2000,2000,0); cfg.y=clamp(cfg.y,-1500,1500,0)
    if cfg.clickThrough==nil then cfg.clickThrough=true end
    if cfg.locked==nil then cfg.locked=true end
    frame=CreateFrame('Frame',nil,UIParent); frame:Hide(); frame:SetFrameStrata('LOW'); frame:SetMovable(true); frame:SetClampedToScreen(true)
    frame:SetPoint('CENTER',UIParent,'CENTER',cfg.x,cfg.y)
    art=CreateFrame('Frame',nil,frame); art:SetAllPoints(); art:EnableMouse(false)
    arrow=frame:CreateTexture(nil,'OVERLAY'); arrow:SetTexture('Interface\\AddOns\\MiniMappin\\AtlasArrow.tga'); arrow:SetPoint('CENTER'); arrow:SetVertexColor(.25,.95,1)
    waypoint=frame:CreateFontString(nil,'OVERLAY','GameFontNormalLarge'); waypoint:SetText('◆'); waypoint:SetTextColor(1,1,0)
    status=frame:CreateFontString(nil,'OVERLAY','GameFontNormal'); status:SetPoint('CENTER',0,-28)
    frame:RegisterForDrag('LeftButton')
    frame:SetScript('OnDragStart',function() if not cfg.locked and not cfg.clickThrough then frame:StartMoving() end end)
    local function stop()
        frame:StopMovingOrSizing(); local x,y=frame:GetCenter(); local ux,uy=UIParent:GetCenter()
        if num(x) and num(y) and num(ux) and num(uy) then cfg.x,cfg.y=x-ux,y-uy; frame:ClearAllPoints(); frame:SetPoint('CENTER',UIParent,'CENTER',cfg.x,cfg.y) end
    end
    frame:SetScript('OnDragStop',stop)
    frame:SetScript('OnMouseWheel',function(_,d) cfg.zoom=clamp(cfg.zoom+d*.5,1,12,3); apply() end)
    frame:SetScript('OnShow',function(self) elapsed=0; retry=0; self:SetScript('OnUpdate',function(_,dt) elapsed=elapsed+dt; if elapsed>=.1 then elapsed=0; update() end end); update() end)
    frame:SetScript('OnHide',function(self) self:SetScript('OnUpdate',nil); self:StopMovingOrSizing() end)
    apply(); return true
end
function runner.Toggle() if init() then frame:SetShown(not frame:IsShown()) end end
function runner.Settings()
    if not init() then return end
    if panel then panel:SetShown(not panel:IsShown()); return end
    panel=CreateFrame('Frame','MiniMappinRunnerSettings',UIParent,BackdropTemplateMixin and 'BackdropTemplate' or nil)
    panel:SetSize(330,340); panel:SetPoint('CENTER'); panel:SetFrameStrata('DIALOG'); panel:EnableMouse(true); panel:SetMovable(true); panel:RegisterForDrag('LeftButton'); panel:SetScript('OnDragStart',panel.StartMoving); panel:SetScript('OnDragStop',panel.StopMovingOrSizing)
    local bg=panel:CreateTexture(nil,'BACKGROUND'); bg:SetAllPoints(); bg:SetColorTexture(.045,.045,.045,1)
    local function text(value,x,y) local t=panel:CreateFontString(nil,'OVERLAY','GameFontNormal'); t:SetPoint('TOPLEFT',x,y); t:SetText(value); return t end
    local function button(value,x,y,w,fn) local b=CreateFrame('Button',nil,panel,'UIPanelButtonTemplate'); b:SetSize(w,24); b:SetPoint('TOPLEFT',x,y); b:SetText(value); b:SetScript('OnClick',fn); return b end
    text('Map Runner | v2.0.0 preview',16,-15); button('X',290,-9,25,function() panel:Hide() end)
    local labels={}
    local function refresh() for k,t in pairs(labels) do t:SetText(t.label..': '..cfg[k]) end end
    local function step(key,label,y,lo,hi,delta) local t=text('',94,y-5); t.label=label; labels[key]=t; button('-',16,y,32,function() cfg[key]=clamp(cfg[key]-delta,lo,hi,lo); apply(); refresh() end); button('+',51,y,32,function() cfg[key]=clamp(cfg[key]+delta,lo,hi,hi); apply(); refresh() end) end
    step('opacity','Opacity %',-48,10,100,5); step('zoom','Zoom',-77,1,12,.5); step('width','Width',-106,120,1200,20); step('height','Height',-135,100,900,20); step('arrow','Arrow size',-164,12,50,2)
    local function check(key,label,y) local b=CreateFrame('CheckButton',nil,panel,'UICheckButtonTemplate'); b:SetSize(24,24); b:SetPoint('TOPLEFT',14,y); b:SetChecked(cfg[key]); text(label,44,y-5); b:SetScript('OnClick',function(self) cfg[key]=not not self:GetChecked(); apply() end) end
    check('clickThrough','Click-through',-196); check('locked','Lock position',-224)
    button('Toggle overlay',16,-258,145,runner.Toggle); button('Center overlay',168,-258,145,function() cfg.x,cfg.y=0,0; frame:ClearAllPoints(); frame:SetPoint('CENTER') end)
    text('Unlock + disable click-through to drag.',16,-291); text('RIP Shady',132,-318); refresh()
    if type(UISpecialFrames)=='table' then table.insert(UISpecialFrames,'MiniMappinRunnerSettings') end
end
SLASH_MINIMAPPINRUNNER1='/maprunner'
SlashCmdList.MINIMAPPINRUNNER=function(msg) if msg=='toggle' then runner.Toggle() else runner.Settings() end end
