local _,addon=...
local G=addon.RoadGraph
local N={modeNames={roads="Follow Roads",fast="Fastest Route",direct="Direct Route"}}
addon.Nav=N
local function safe(v) return not (issecretvalue and issecretvalue(v)) end
local function number(v) return safe(v) and type(v)=="number" and math.abs(v)<1e8 end
local function call(fn,...)
    if type(fn)~="function" then return end
    local ok,a,b,c=pcall(fn,...)
    if ok and safe(a) and safe(b) and safe(c) then return a,b,c end
end
N.call,N.number=call,number
local function xy(p)
    if not safe(p) or (type(p)~="table" and type(p)~="userdata") then return end
    local x,y
    if p.GetXY then x,y=call(p.GetXY,p) else x,y=p.x,p.y end
    if number(x) and number(y) then return x,y end
end
N.xy=xy
local function validMap(id) return number(id) and id>0 and id%1==0 end
local function validDest(id,x,y) return validMap(id) and number(x) and number(y) and x>=0 and x<=1 and y>=0 and y<=1 end
local function name(s) return type(s)=="string" and s:gsub("[%c|]",""):sub(1,48) or "Destination" end
local function world(id,x,y)
    local c,p=call(C_Map and C_Map.GetWorldPosFromMapPos,id,call(CreateVector2D,x,y))
    local wx,wy=xy(p)
    if number(c) and wx then return {c=c,x=wx,y=wy} end
end
local basis={}
N.world=world
function N.basis(id)
    if not validMap(id) then return end
    if basis[id] then return basis[id] end
    local o,r,d=world(id,.25,.25),world(id,.75,.25),world(id,.25,.75)
    if not o or not r or not d or r.c~=o.c or d.c~=o.c then return end
    local ax,ay,bx,by=2*(r.x-o.x),2*(r.y-o.y),2*(d.x-o.x),2*(d.y-o.y)
    local det=ax*by-ay*bx
    if math.abs(det)<.01 then return end
    basis[id]=function(p)
        if p.c and p.c~=o.c then return end
        local x,y=p.x-o.x,p.y-o.y
        return .25+(x*by-y*bx)/det,.25+(ax*y-ay*x)/det
    end
    return basis[id]
end
function N.player()
    local id=call(C_Map and C_Map.GetBestMapForUnit,"player")
    if not validMap(id) then return end
    local x,y=xy(call(C_Map.GetPlayerMapPosition,id,"player"))
    if validDest(id,x,y) then return id,x,y end
end
local graph,continent,record,driver
local function validPoint(p)
    return type(p)=="table" and number(p.x) and number(p.y) and math.abs(p.x)<=50000 and math.abs(p.y)<=50000
end
local kinds={road=true,trail=true,shortcut=true}
local function validRecord(r)
    if type(r)~="table" or not number(r.c) or r.c%1~=0 or r.c<0 or not kinds[r.kind] or type(r.points)~="table" or #r.points<2 or #r.points>512 then return end
    for i=1,#r.points do
        if not validPoint(r.points[i]) or (i>1 and G.distance(r.points[i-1],r.points[i])>100) then return end
    end
    return true
end
function N.init()
    if N.db then return end
    if type(MiniMappinDB)~="table" then return end
    local db=type(MiniMappinDB.navigation)=="table" and MiniMappinDB.navigation or {}
    MiniMappinDB.navigation=db; N.db=db
    if not N.modeNames[db.mode] then db.mode="roads" end
    for k,v in pairs({fallback=true,reroute=false,static=true,runner=true,map=true,info=true,personal=false,enabledMapClick=true,zoom=false,hidden=false,compass=false,shade=false,crumbs=false,minimap=false,hud=true,hudLocked=true,hudCompact=false}) do
        if type(db[k])~="boolean" then db[k]=v end
    end
    for k,range in pairs({radius={5,35,12},width={2,8,4},opacity={25,100,100},walkZoom={1,12,3},mountZoom={1,12,5},palette={1,3,1},hudScale={70,160,100},hudFont={12,24,16},hudOpacity={25,100,100},miniWidth={2,8,3}}) do
        db[k]=number(db[k]) and math.floor(math.max(range[1],math.min(range[2],db[k]))) or range[3]
    end
    if not db.staticMigration4 then db.static=true;db.reroute=false;db.staticMigration4=true end
    local d=db.dest
    if type(d)~="table" or not validDest(d.id,d.x,d.y) then db.dest=nil else d.name=name(d.name) end
    local routes={}
    if type(db.routes)=="table" then
        for i=1,math.min(40,#db.routes) do
            local r=db.routes[i]
            if validRecord(r) then r.name=name(r.name); r.reviewed=r.reviewed==true; routes[#routes+1]=r end
        end
    end
    db.forever=db.forever==true and db.dest~=nil
    local reports={}
    if type(db.reports)=="table" then
        for i=1,math.min(40,#db.reports) do
            local r=db.reports[i]
            if type(r)=="table" and validDest(r.id,r.x,r.y) then
                reports[#reports+1]={id=r.id,x=r.x,y=r.y,name=name(r.name)}
            end
        end
    end
    db.reports=reports
    db.routes=routes
end
function N.invalidate(dropGraph)
    if dropGraph then graph,continent=nil,nil end
    N.path,N.lastPlan,N.index=nil,nil,1;N.track=nil;N.guidance=nil;N.retryAt=nil;N.retryCount=0
end
function N.clear()
    N.previewRecord=nil;N.pos,N.goal,N.progress,N.localDirect=nil,nil,nil,nil;N.guidance=nil;N.arrivedUntil=nil
    N.db.dest=nil; N.db.forever=nil; N.foreverKey=nil; N.status=nil; N.invalidate(); N.crumb=nil
    if driver and not record then driver:Hide() end
    if N.hideLayers then N.hideLayers() end
    if N.updateMapDriver then N.updateMapDriver() end
end
function N.set(id,x,y,label,mode)
    if not N.db or not validDest(id,x,y) then return false end
    N.clear();N.arrivedUntil=nil
    if N.modeNames[mode] then N.db.mode=mode end
    N.db.dest={id=id,x=x,y=y,name=name(label)}
    driver:Show(); N.tick(); if N.updateMapDriver then N.updateMapDriver() end; return true
end
function N.debug()
    local id,x,y=N.player()
    local p=id and world(id,x,y)
    if not p then print("MiniMappin GPS: player world position unavailable");return end
    print(string.format("MiniMappin GPS: map %d, continent %d, world %.1f %.1f, map %.2f %.2f",id,p.c,p.x,p.y,x*100,y*100))
    local data=addon.roadText[p.c]
    local g=G.build(data,N.db.personal and N.db.routes,p.c)
    local distance=G.nearest(g,p,N.db.mode=="fast")
    print("MiniMappin GPS: nearest road "..(distance and string.format("%.1f yd",distance) or ">300 yd").."; bundled data "..(data and "available" or "unavailable"))
    local inv=N.basis(id)
    if inv then local u,v=inv(p); if u and v then print(string.format("MiniMappin GPS: projection error %.4f / %.4f map %%",math.abs(u-x)*100,math.abs(v-y)*100)) end end
    print("MiniMappin GPS: requested "..tostring(N.db.mode).."; effective "..tostring(N.effective).."; destination map "..tostring(N.db.dest and N.db.dest.id))
    if N.db.dest then local d=N.db.dest;local goal=world(d.id,d.x,d.y);if goal then local dist=goal.c==p.c and G.nearest(g,goal,N.db.mode=="fast");print("MiniMappin GPS: destination continent "..goal.c.."; nearest road "..(dist and string.format("%.1f yd",dist) or "unavailable / >300 yd")) end end
    if N.status then print("MiniMappin GPS: "..N.status) end
end
local function sample(p,id)
    if not record or record.paused then return end
    if not p or record.c~=p.c or record.id~=id or call(UnitOnTaxi,"player") or call(IsFlying) or call(UnitIsDeadOrGhost,"player") then
        record.paused=true; print("MiniMappin: recording paused. Stop and start a new segment after travel."); return
    end
    local pts=record.points
    local last=pts[#pts]
    local distance=last and G.distance(last,p) or 0
    if last and distance>100 or #pts>=512 then
        record.paused=true; print("MiniMappin: segment limit reached. Stop to save."); return
    end
    if last and distance<8 then return end
    p={x=math.floor(p.x+.5),y=math.floor(p.y+.5)}
    local before=pts[#pts-1]
    if before and G.distance(before,p)<60 then
        local _,err=G.project(last,before,p)
        if err<1.5 then pts[#pts]=p; return end
    end
    pts[#pts+1]=p
end
function N.record(kind,label)
    if record or not kinds[kind] or #N.db.routes>=40 then return false end
    local id,x,y=N.player()
    local p=id and world(id,x,y)
    if not p then return false end
    record={kind=kind,name=name(label),c=p.c,id=id,points={},reviewed=false}
    driver:Show(); sample(p,id); return true
end
function N.pause()
    if not record then return "No active recording." end
    if record.paused then
        local id,x,y=N.player()
        local p=id and world(id,x,y)
        local last=record.points[#record.points]
        if not p or not last or id~=record.id or p.c~=record.c or G.distance(p,last)>8 then
            return "Return within 8 yards of the last sample to resume, or stop and save."
        end
        record.paused=false;return "Recording resumed."
    end
    record.paused=true;return "Recording paused."
end
function N.stop()
    if not record then return false end
    local ok=validRecord(record)
    if ok then record.paused=nil; table.insert(N.db.routes,record) end
    record=nil
    if not N.db.dest then driver:Hide() end
    return ok
end
function N.export(i)
    local r=N.db.routes[i]; if not r then return end
    local s={"MMR1",r.c,r.kind,(r.name:gsub("[;]"," "))}
    for _,p in ipairs(r.points) do s[#s+1]=p.x..","..p.y end
    return table.concat(s,";")
end
function N.import(s)
    if type(s)~="string" or #s>14000 or #N.db.routes>=40 then return false end
    local c,k,label,tail=s:match("^MMR1;(%d+);(%a+);([^;]+);(.+)$")
    if not c then return false end
    local r={c=tonumber(c),kind=k,name=name(label),points={},reviewed=false}
    for pair in (tail..";"):gmatch("(.-);") do
        local x,y=pair:match("^(-?%d+),(-?%d+)$")
        if not x or #r.points>=512 then return false end
        table.insert(r.points,{x=tonumber(x),y=tonumber(y)})
    end
    if not validRecord(r) then return false end
    table.insert(N.db.routes,r);return true
end

-- Read the active provider leg in zone coordinates. This API cannot create a trip.
local function mirror(p)
    local api=ForeverMaps_API
    if type(api)~="table" or type(api.VERSION)~="string" or not api.VERSION:match("^5%.") then return false end
    local route=call(api.GetRoute)
    if type(route)~="table" or not number(route.points) or route.points>2048 or route.points<1 or not number(route.index) then return false end
    local stamp=GetTime()
    if not N.foreverKey or stamp-N.foreverKey>=2 or N.providerIndex~=route.index then
        local ahead=call(api.GetUpcoming,route.points)
        if type(ahead)~="table" or #ahead<1 or #ahead>2048 then return false end
        local path={p}
        for _,point in ipairs(ahead) do
            if type(point)~="table" or not validDest(point.mapID,point.mapX,point.mapY) then return false end
            local w=world(point.mapID,point.mapX,point.mapY)
            if not w or w.c~=p.c then return false end
            path[#path+1]=w
        end
        local last=ahead[#ahead]
        N.db.dest={id=last.mapID,x=last.mapX,y=last.mapY,name=name(route.name)}
        N.path,N.goal,N.foreverKey,N.providerIndex=path,path[#path],stamp,route.index
    end
    N.pos,N.progress,N.effective,N.index=p,p,"provider",1
    N.path[1]=p
    local node=call(api.GetNode)
    local kind=type(node)=="table" and (node.transport or node.name)
    N.status="Forever Maps • current leg"..(type(kind)=="string" and " • "..name(kind) or "")..(number(route.remaining) and string.format(" • %.0f yd",route.remaining) or "")
    return true
end
function N.followForever()
    local id,x,y=N.player()
    local p=id and world(id,x,y)
    if not p or not ForeverMaps_API or not call(ForeverMaps_API.IsNavigating) then return false end
    N.foreverKey=nil
    if not mirror(p) then return false end
    N.db.forever=true;driver:Show();if N.updateMapDriver then N.updateMapDriver() end;return true
end
local function plan(p,dest)
    local db=N.db
    N.path,N.reason,N.index=nil,nil,1;N.track=nil;N.guidance=nil
    N.roadStart,N.roadEnd=nil,nil
    if p.c~=dest.c then N.reason="No verified continent connection";return end
    local function indoor(id)
        local info=call(C_Map and C_Map.GetMapInfo,id)
        local kind=type(info)=="table" and info.mapType
        return number(kind) and (kind==4 or kind==5)
    end
    if db.mode~="direct" and (indoor(N.zone) or indoor(db.dest.id)) then
        N.reason="No verified interior road coverage"
    elseif db.mode~="direct" then
        if continent~=p.c then
            graph=G.build(addon.roadText[p.c],db.personal and db.routes,p.c);continent=p.c
        end
        if not addon.roadText[p.c] and not db.personal then
            N.reason="No road data for continent "..tostring(p.c)
        else
            N.path,N.reason,N.roadStart,N.roadEnd=G.solve(graph,p,dest,db.mode=="fast")
        end
    end
    if N.path then
        N.effective=db.mode
        table.insert(N.path,1,p);N.path[#N.path+1]=dest
        for _,point in ipairs(N.path) do point.c=p.c end
    elseif db.mode=="direct" or db.fallback then N.effective="direct";N.path={p,dest} end
    if N.path then
        N.lengths={};local n=#N.path; N.lengths[n]=G.distance(N.path[n],dest)
        for i=n-1,1,-1 do N.lengths[i]=N.lengths[i+1]+G.distance(N.path[i],N.path[i+1]) end
    end
end
function N.tick()
    local db=N.db
    local id,x,y=N.player()
    local p=id and world(id,x,y)
    sample(p,id)
    local d=db.dest
    if not d then return end
    N.localDirect=nil;N.guidance=nil
    if not id or not p then
        N.path=nil;N.lastPlan=nil;N.status="Player position unavailable"
        if id==d.id and (db.mode=="direct" or db.fallback) then
            N.localDirect={id=id,{x=x,y=y},{x=d.x,y=d.y}};N.effective="direct";N.status="Direct • terrain unchecked"
        end
        return
    end
    if db.forever then
        if not mirror(p) then N.path=nil;N.foreverKey=nil;N.status="Waiting for Forever Maps route" end
        return
    end
    local goal=world(d.id,d.x,d.y)
    if not goal then
        N.path=nil;N.lastPlan=nil;N.status="Destination position unavailable"
        if id==d.id and (db.mode=="direct" or db.fallback) then
            N.localDirect={id=id,{x=x,y=y},{x=d.x,y=d.y}};N.effective="direct";N.status="Direct • terrain unchecked"
        end
        return
    end
    if p.c==goal.c and G.distance(p,goal)<=db.radius then print("MiniMappin: arrived at "..d.name); N.clear();N.arrivedUntil=GetTime()+5;return end
    local now=GetTime()
    -- A direct fallback is not a successful static road plan. Retry on movement,
    -- zone change, or a bounded delay while world coordinates settle.
    local failedRoad=db.mode~="direct" and (not N.path or N.effective=="direct")
    local retry=failedRoad and N.lastPlan and (N.zone~=id or
        (now>=(N.retryAt or 0) and (not N.origin or G.distance(p,N.origin)>=25 or (N.retryCount or 0)<3)))
    if not N.lastPlan or retry or (not db.static and N.zone~=id) or (N.origin and N.origin.c~=p.c) or N.dirty or (not N.path or N.reason) and db.reroute and not db.static and now-N.lastPlan>=5 and G.distance(p,N.origin)>20 then
        N.origin,N.zone,N.lastPlan,N.dirty=p,id,now,nil; plan(p,goal)
        if db.mode~="direct" and (not N.path or N.effective=="direct") then
            N.retryCount=(N.retryCount or 0)+1;N.retryAt=now+math.min(30,3*N.retryCount)
        else N.retryCount=0;N.retryAt=nil end
    end
    N.pos,N.goal=p,goal
    if db.crumbs then
        N.crumb=N.crumb or {}
        local last=N.crumb[#N.crumb]
        if not last or last.c~=p.c or G.distance(last,p)>100 then N.crumb={} end
        if #N.crumb==0 or G.distance(N.crumb[#N.crumb],p)>10 then
            table.insert(N.crumb,p); if #N.crumb>40 then table.remove(N.crumb,1) end
        end
    end
    if not N.path then N.status=N.reason;return end
    local path=N.path
    local remaining
    if N.effective=="direct" then if not db.static then path[1]=p end;remaining=G.distance(p,goal)
    else
        local i,q,err,remainingRoad=N.trackRoute(path,p,now)
        N.index,N.progress=i,q
        if db.reroute and not db.static and err>40 and now-N.lastPlan>=4 then N.dirty=true end
        remaining=remainingRoad
    end
    local speed,run=call(GetUnitSpeed,"player")
    speed=number(speed) and speed>0 and speed or number(run) and run>0 and run or 7
    local turn=""
    if N.effective=="direct" then N.guidance={text="Head toward destination",state="Terrain unchecked",distance=remaining,arrow="↑"}
    else N.guidance=N.maneuver(path,p,remaining) end
    N.guidance.remaining=remaining;N.guidance.seconds=remaining/speed
    turn=" • "..N.guidance.text
    N.status=string.format("%s%s • %.0f yd • est. %d:%02d%s",N.modeNames[N.effective],N.effective=="direct" and " (terrain unchecked)" or "",remaining,math.floor(remaining/speed/60),math.floor(remaining/speed)%60,turn)
    local clock=call(GetServerTime)
    if type(clock)=="number" and clock>0 and clock<1e11 then
        local arrival=call(date,"%I:%M %p",clock+math.floor(remaining/speed))
        if type(arrival)=="string" then N.guidance.eta=arrival:gsub("^0","");N.status=N.status.." • ETA "..N.guidance.eta end
    end
    if N.reason then N.status=N.reason.." • "..N.status
    elseif N.roadStart then N.status=N.status..string.format(" • off-road %.0f/%.0f yd",N.roadStart,N.roadEnd) end
end
driver=CreateFrame("Frame"); driver:Hide()
local elapsed=0
driver:SetScript("OnUpdate",function(_,dt)
    elapsed=elapsed+dt
    if elapsed>=.35 then elapsed=0;N.tick() end
end)
driver:RegisterEvent("PLAYER_LOGIN");driver:RegisterEvent("PLAYER_ENTERING_WORLD");driver:RegisterEvent("PLAYER_ALIVE");driver:RegisterEvent("PLAYER_UNGHOST");driver:RegisterEvent("PLAYER_DEAD")
driver:SetScript("OnEvent",function(_,event)
    N.init(); if event=="PLAYER_LOGIN" or (N.db and N.db.mode~="direct" and (not N.path or N.effective=="direct")) then N.dirty=true end
    if N.db and N.db.dest then driver:Show() end
    if record then record.paused=true end
end)
MiniMappinNavigation={Navigate=N.set}
