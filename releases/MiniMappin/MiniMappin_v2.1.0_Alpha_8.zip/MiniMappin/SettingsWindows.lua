-- Shared settings window lifecycle. Does not touch route or overlay state.
local _, addon = ...
local W = {panels={}}
addon.SettingsWindows = W
function W.register(panel)
    for _,p in ipairs(W.panels) do if p==panel then return end end
    panel:Hide()
    panel:SetFrameStrata('FULLSCREEN_DIALOG')
    panel:SetClampedToScreen(true)
    local name=panel:GetName()
    if name and type(UISpecialFrames)=='table' then
        local found=false
        for _,v in ipairs(UISpecialFrames) do if v==name then found=true;break end end
        if not found then table.insert(UISpecialFrames,name) end
    end
    table.insert(W.panels,panel)
end
function W.open(panel)
    for _,p in ipairs(W.panels) do if p~=panel then p:Hide() end end
    panel:Show()
    if panel.Raise then panel:Raise() end
end
local help,previous
local function label(parent,value,x,y,font,width)
    local t=parent:CreateFontString(nil,'OVERLAY',font or 'GameFontHighlight')
    t:SetPoint('TOPLEFT',x,-y);t:SetText(value);t:SetJustifyH('LEFT')
    if width then t:SetWidth(width) end
    return t
end
local function button(parent,value,x,y,w,fn)
    local b=CreateFrame('Button',nil,parent,'UIPanelButtonTemplate')
    b:SetSize(w,24);b:SetPoint('TOPLEFT',x,-y);b:SetText(value);b:SetScript('OnClick',fn);return b
end
local groups={
    {'M button shortcuts',{
        {'Left-click','MiniMappin settings'}, {'Right-click','Switch map / cycle map views'},
        {'Middle-click','Toggle Map Runner overlay'}, {'Shift + left-click','Toggle minimap route'},
        {'Shift + right-click','Toggle navigation HUD'}, {'Shift + drag / scroll','Move / resize the M button'},
    }},
    {'Map controls',{
        {'Alt + middle-click','Select destination on world map / OpenMap'},
        {'Alt + middle-click (overlay)','Select destination; disable click-through first'},
        {'Mouse wheel (overlay)','Zoom; disable click-through first'},
    }},
    {'Slash commands',{
        {'/minimappin','MiniMappin settings'}, {'/maprunner','Map Runner settings'},
        {'/maprunner toggle','Toggle Map Runner overlay'}, {'/mmnav','Navigation settings'},
        {'/mmnav minimap','Toggle minimap route'}, {'/mmnav hud','Toggle navigation HUD'},
        {'/mmnav X Y [name]','Navigate to coordinates in current zone'},
        {'/mmnav mapID X Y [name]','Navigate to coordinates on specified map'},
        {'/mmnav waypoint','Navigate to native world map waypoint'},
        {'/mmnav clear','Clear active route'}, {'/mmnav recalc','Recalculate active route'},
        {'/mmnav debug','Print route diagnostics'}, {'/mmhelp or /mmnav help','Open this reference'},
    }},
}
function W.help(back)
    if not help then
        help=CreateFrame('Frame','MiniMappinCommandsSettings',UIParent,BackdropTemplateMixin and 'BackdropTemplate' or nil)
        W.register(help);help:SetSize(540,680);help:SetPoint('CENTER');help:EnableMouse(true);help:SetMovable(true);help:RegisterForDrag('LeftButton')
        help:SetScale(math.min(1,UIParent:GetWidth()/560,UIParent:GetHeight()/700))
        help:SetScript('OnDragStart',help.StartMoving);help:SetScript('OnDragStop',help.StopMovingOrSizing)
        local bg=help:CreateTexture(nil,'BACKGROUND');bg:SetAllPoints();bg:SetColorTexture(.035,.035,.04,1)
        label(help,'Commands / Keybinds',16,14,'GameFontNormalLarge')
        button(help,'X',501,8,27,function() help:Hide() end)
        local y=47
        for _,group in ipairs(groups) do
            label(help,group[1],16,y,'GameFontNormal');y=y+24
            for _,r in ipairs(group[2]) do
                label(help,r[1],16,y,'GameFontNormalSmall',215)
                label(help,r[2],238,y,'GameFontHighlightSmall',286)
                y=y+21
            end
            y=y+8
        end
        button(help,'Back',16,642,90,function() local p=previous;previous=nil;help:Hide();if p then W.open(p) elseif addon.OpenMainSettings then addon.OpenMainSettings() end end)
        label(help,'RIP Shady',235,651,'GameFontDisableSmall')
        label(help,'Alpha 8',463,651,'GameFontDisableSmall')
    end
    if help:IsShown() and not back then help:Hide();return end
    previous=back
    W.open(help)
end
SLASH_MINIMAPPINHELP1='/mmhelp'
SlashCmdList.MINIMAPPINHELP=function() W.help() end
