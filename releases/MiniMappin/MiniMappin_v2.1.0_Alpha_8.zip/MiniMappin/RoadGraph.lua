local _, addon = ...
local G = {}
addon.RoadGraph = G
local floor, sqrt = math.floor, math.sqrt
local function dist(a,b) return sqrt((a.x-b.x)^2+(a.y-b.y)^2) end
G.distance=dist
function G.project(p,a,b)
    local dx,dy=b.x-a.x,b.y-a.y
    local len=dx*dx+dy*dy
    local t=len>0 and math.max(0,math.min(1,((p.x-a.x)*dx+(p.y-a.y)*dy)/len)) or 0
    local q={x=a.x+dx*t,y=a.y+dy*t}
    return q, dist(p,q)
end
local function key(x,y) return x..":"..y end
function G.build(data,personal,continent)
    local grid,nodes={},{}
    local function node(x,y)
        local k=key(x,y)
        if not nodes[k] then nodes[k]={x=x,y=y,edges={}} end
        return nodes[k]
    end
    local function edge(a,b,shortcut)
        if a==b or dist(a,b)>1800 then return end
        local e={a=a,b=b,cost=dist(a,b),shortcut=shortcut}
        a.edges[#a.edges+1]=e
        b.edges[#b.edges+1]=e
        for i=floor(math.min(a.x,b.x)/100),floor(math.max(a.x,b.x)/100) do
            for j=floor(math.min(a.y,b.y)/100),floor(math.max(a.y,b.y)/100) do
                local k=key(i,j)
                grid[k]=grid[k] or {}
                table.insert(grid[k],e)
            end
        end
    end
    for line in (data or ""):gmatch("[^\n]+") do
        local prev
        for x,y in line:gmatch("(-?%d+),(-?%d+)") do
            local n=node(tonumber(x),tonumber(y))
            if prev then edge(prev,n,false) end
            prev=n
        end
    end
    for _,r in ipairs(personal or {}) do
        if r.c==continent and r.reviewed then
            local prev
            for _,p in ipairs(r.points) do
                local n=node(p.x,p.y)
                if prev then edge(prev,n,r.kind=="shortcut") end
                prev=n
            end
        end
    end
    return grid
end
local function snap(grid,p,fast)
    local ix,iy=floor(p.x/100),floor(p.y/100)
    local candidates,seen={},{}
    for x=ix-3,ix+3 do for y=iy-3,iy+3 do
        for _,e in ipairs(grid[key(x,y)] or {}) do
            if not seen[e] and (fast or not e.shortcut) then
                seen[e]=true
                local q,d=G.project(p,e.a,e.b)
                if d<=300 then candidates[#candidates+1]={edge=e,p=q,d=d} end
            end
        end
    end end
    table.sort(candidates,function(a,b) return a.d<b.d end)
    return candidates
end
function G.nearest(grid,p,fast)
    local candidates=snap(grid,p,fast)
    return candidates[1] and candidates[1].d
end
-- Binary min-heap. No search state is written back to the graph.
local function push(h,v)
    local i=#h+1
    while i>1 do
        local parent=floor(i/2)
        if h[parent][1]<=v[1] then break end
        h[i]=h[parent]; i=parent
    end
    h[i]=v
end
local function pop(h)
    local top,last=h[1],table.remove(h)
    if #h==0 then return top end
    local i=1
    while i*2<=#h do
        local child=i*2
        if child<#h and h[child+1][1]<h[child][1] then child=child+1 end
        if last[1]<=h[child][1] then break end
        h[i]=h[child]; i=child
    end
    h[i]=last
    return top
end
function G.solve(grid,start,goal,fast)
    local starts,goals=snap(grid,start,fast),snap(grid,goal,fast)
    local sd,td=starts[1] and starts[1].d,goals[1] and goals[1].d
    if not sd or not td then return nil,string.format("Road match: start %s / end %s yd",sd and math.floor(sd) or ">300",td and math.floor(td) or ">300") end
    -- Prefer nearby roads; widen only when the closer matches are disconnected.
    for _,radius in ipairs({35,100,200,300}) do
        if sd<=radius and td<=radius then
            local heap,cost,prev,source,targets={},{},{},{},{}
            local best,bestNode,bestTarget,bestSource=math.huge
            local function visit(n,d,parent,src)
                if not cost[n] or d<cost[n] then
                    cost[n],prev[n],source[n]=d,parent,src
                    push(heap,{d+dist(n,goal),n,d})
                end
            end
            local penalty=fast and 2 or 5
            local goalEdges={}
            for _,t in ipairs(goals) do
                if t.d>radius then break end
                goalEdges[t.edge]=t
                for _,n in ipairs({t.edge.a,t.edge.b}) do
                    local d=dist(n,t.p)+penalty*t.d
                    if not targets[n] or d<targets[n].d then targets[n]={d=d,t=t} end
                end
            end
            for _,s in ipairs(starts) do
                if s.d>radius then break end
                local t=goalEdges[s.edge]
                if t then
                    local d=penalty*(s.d+t.d)+dist(s.p,t.p)
                    if d<best then best,bestNode,bestTarget,bestSource=d,nil,t,s end
                end
                visit(s.edge.a,penalty*s.d+dist(s.p,s.edge.a),nil,s)
                visit(s.edge.b,penalty*s.d+dist(s.p,s.edge.b),nil,s)
            end
            local count=0
            while #heap>0 and count<90000 do
                count=count+1
                local v=pop(heap)
                if v[1]>=best then break end
                local n=v[2]
                if v[3]==cost[n] then
                    local t=targets[n]
                    if t and v[3]+t.d<best then best,bestNode,bestTarget,bestSource=v[3]+t.d,n,t.t,source[n] end
                    for _,e in ipairs(n.edges) do
                        if fast or not e.shortcut then visit(e.a==n and e.b or e.a,cost[n]+e.cost,n,source[n]) end
                    end
                end
            end
            if bestTarget then
                local path,back={bestSource.p},{}
                local n=bestNode
                while n do back[#back+1]={x=n.x,y=n.y};n=prev[n] end
                for i=#back,1,-1 do path[#path+1]=back[i] end
                path[#path+1]=bestTarget.p
                return path,nil,bestSource.d,bestTarget.d
            end
        end
    end
    return nil,string.format("No connected road path (nearest %.0f / %.0f yd)",sd,td)
end
