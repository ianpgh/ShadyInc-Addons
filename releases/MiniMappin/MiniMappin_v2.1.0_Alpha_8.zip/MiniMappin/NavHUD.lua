local _,addon=...
local N=addon.Nav
local call,num=N.call,N.number
local hud,headline,detail,stats,arrow
local function toggle(k)
    if not N.db then return end
    N.db[k]=not N.db[k]
    if k=="minimap" and not N.db[k] then N.hide("minimap");N.hide("atlas") end
end
N.toggleDisplay=toggle
function N.resetHUD()
    if not N.db then return end
    N.db.hudX,N.db.hudY=nil,nil
    if hud then hud:ClearAllPoints();hud:SetPoint("TOP",UIParent,"TOP",0,-150) end
end
local function build()
    if hud or InCombatLockdown() then return end
    hud=CreateFrame("Frame",nil,UIParent,"BackdropTemplate");hud:SetSize(330,104);hud:SetFrameStrata("HIGH")
    hud:SetClampedToScreen(true);hud:SetMovable(true);hud:EnableMouse(true);hud:RegisterForDrag("LeftButton")
    hud:SetBackdrop({bgFile="Interface\\Buttons\\WHITE8X8",edgeFile="Interface\\Buttons\\WHITE8X8",edgeSize=1});hud:SetBackdropBorderColor(.55,.55,.55,1)
    local db=N.db
    if num(db.hudX) and num(db.hudY) then hud:SetPoint("CENTER",UIParent,"CENTER",db.hudX,db.hudY) else hud:SetPoint("TOP",UIParent,"TOP",0,-150) end
    hud:SetScript("OnDragStart",function() if not N.db.hudLocked and not InCombatLockdown() then hud:StartMoving() end end)
    hud:SetScript("OnDragStop",function() hud:StopMovingOrSizing();local x,y=hud:GetCenter();local a,b=UIParent:GetCenter();local s=hud:GetEffectiveScale()/UIParent:GetEffectiveScale();if x and y and a and b then N.db.hudX,N.db.hudY=x-a/s,y-b/s end end)
    arrow=hud:CreateTexture(nil,"OVERLAY");arrow:SetTexture("Interface\\AddOns\\MiniMappin\\AtlasArrow.tga");arrow:SetSize(32,32);arrow:SetPoint("TOPLEFT",10,-10);arrow:SetVertexColor(1,.86,.15)
    local function text(y,font)
        local t=hud:CreateFontString(nil,"OVERLAY",font);t:SetPoint("TOPLEFT",52,y);t:SetPoint("RIGHT",-12,0);t:SetJustifyH("LEFT");t:SetShadowColor(0,0,0,1);t:SetShadowOffset(1,-1);return t
    end
    headline=text(-10,"GameFontNormalLarge");detail=text(-44,"GameFontHighlight");stats=text(-72,"GameFontHighlightSmall")
    hud:Hide()
end
local function updateHUD()
    local db=N.db
    if not db or not db.hud or not (db.dest or N.arrivedUntil and GetTime()<N.arrivedUntil) then if hud then hud:Hide() end;return end
    build();if not hud then return end
    local g=N.guidance
    local title=not db.dest and "Destination reached" or g and g.text or N.status or "Locating route…"
    local direction=g and g.arrow
    arrow:SetShown(direction=="↑" or direction=="←" or direction=="→" or direction=="↶")
    arrow:SetRotation(direction=="←" and math.pi/2 or direction=="→" and -math.pi/2 or direction=="↶" and math.pi or 0)
    headline:SetText(title);headline:SetTextColor(1,.86,.15)
    local state=g and g.state or (db.dest and "Navigation" or "Arrived")
    detail:SetText(state);detail:SetTextColor(1,1,1)
    if state:find("Off route",1,true) or state=="Wrong direction" then detail:SetTextColor(1,.35,.25) elseif state=="On route" then detail:SetTextColor(.4,1,.5) end
    if g and g.seconds then stats:SetText(string.format("%.0f yd  •  %d:%02d  •  ETA %s",g.remaining,math.floor(g.seconds/60),math.floor(g.seconds)%60,g.eta or "--")) else stats:SetText(db.dest and db.dest.name or "") end
    local font=select(1,headline:GetFont());headline:SetFont(font,db.hudFont,"OUTLINE");detail:SetFont(font,math.max(12,db.hudFont-2),"OUTLINE");stats:SetFont(font,math.max(11,db.hudFont-4),"OUTLINE")
    hud:SetScale(db.hudScale/100);hud:SetWidth(math.max(370,db.hudFont*23));hud:SetHeight((db.hudCompact and 65 or 104)+math.max(0,db.hudFont-16)*2);stats:SetShown(not db.hudCompact);hud:SetBackdropColor(.025,.025,.025,db.hudOpacity/100);hud:EnableMouse(not db.hudLocked);hud:Show()
end
local outside={466.6667,400,333.3333,266.6667,200,133.3333}
local inside={300,240,180,120,80,50}
function N.nativeMini(map)
    local db=N.db
    if not db or not db.minimap or not db.dest or db.hidden or not map or not map:IsVisible() then N.hide("minimap");return end
    local id,x,y=N.player();local p=id and N.world(id,x,y)
    if not p or not N.pos or N.pos.c~=p.c or not N.path then N.hide("minimap");return end
    local radius=call(C_Minimap and C_Minimap.GetViewRadius) or call(map.GetViewRadius,map)
    if not num(radius) or radius<=0 then
        local z=call(map.GetZoom,map);if not num(z) then N.hide("minimap");return end
        local iz=tonumber(call(GetCVar,"minimapInsideZoom"));local oz=tonumber(call(GetCVar,"minimapZoom"));local indoor=call(IsIndoors)
        local diam=(indoor==true or iz==z and oz~=z) and inside or outside
        radius=diam[z+1] and diam[z+1]/2
    end
    if not radius or radius<=0 then N.hide("minimap");return end
    local w,h=map:GetSize();local rotation=call(GetCVarBool,"rotateMinimap")
    local facing=rotation and call(GetPlayerFacing) or 0
    if not num(facing) then N.hide("minimap");return end
    local c,s=math.cos(facing),math.sin(facing)
    local function project(q)
        if q.c and q.c~=p.c then return end
        local east,north=p.y-q.y,q.x-p.x
        return w/2+(east*c+north*s)*w/(2*radius),h/2-(-east*s+north*c)*h/(2*radius)
    end
    N.draw("minimap",map,id,project,function(u,v) local q=N.world(id,u,v);if q then return project(q) end end)
end
local ticker=CreateFrame("Frame");local elapsed=0
ticker:SetScript("OnUpdate",function(_,dt) elapsed=elapsed+dt;if elapsed>=.15 then elapsed=0;updateHUD() end end)
