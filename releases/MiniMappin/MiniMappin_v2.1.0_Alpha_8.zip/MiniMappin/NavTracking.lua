local _,addon=...
local N,G=addon.Nav,addon.RoadGraph
local abs,sqrt=math.abs,math.sqrt
local function unit(a,b)
    local x,y=b.x-a.x,b.y-a.y;local d=sqrt(x*x+y*y)
    if d<.01 then return 0,0 end
    return x/d,y/d
end
local function at(path,lengths,along)
    local total=lengths[1];local target=total-along
    for i=1,#path-1 do
        if target>=lengths[i+1] then
            local a,b=path[i],path[i+1];local d=lengths[i]-lengths[i+1]
            local t=d>0 and math.max(0,math.min(1,(lengths[i]-target)/d)) or 0
            return {x=a.x+(b.x-a.x)*t,y=a.y+(b.y-a.y)*t}
        end
    end
    return path[#path]
end
function N.trackRoute(path,p,now)
    local L=N.lengths;local total=L[1];local old=N.track
    local moved=old and G.distance(old.pos,p) or 0
    local hx,hy=0,0
    if old and moved>=2 and moved<100 then hx,hy=unit(old.pos,p) end
    local best,bq,be,ba,score
    local function scan(localOnly)
        for i=1,#path-1 do
            if not localOnly or (L[i]>=total-old.along-160 and L[i+1]<=total-old.along+100) then
                local q,e=G.project(p,path[i],path[i+1]);local a=total-L[i]+G.distance(path[i],q)
                local dx,dy=unit(path[i],path[i+1]);local penalty=0
                if old then penalty=math.min(35,math.max(0,abs(a-old.along)-moved-15)*.15) end
                if moved>=2 and moved<100 then penalty=penalty+math.max(0,-(hx*dx+hy*dy))*5 end
                local v=e+penalty
                if not score or v<score then best,bq,be,ba,score=i,q,e,a,v end
            end
        end
    end
    if old then scan(true) end
    if not best or be>65 or moved>100 then best,bq,be,ba,score=nil,nil,nil,nil,nil;scan(false) end
    local tolerance=30
    local t={pos=p,along=ba,error=be,off=old and old.off or false,offSince=old and old.offSince,wrongSince=old and old.wrongSince,wrong=old and old.wrong or false}
    if be>tolerance+10 then t.offSince=t.offSince or now;if now-t.offSince>=1.2 then t.off=true end
    elseif be<tolerance-10 then t.off=false;t.offSince=nil else t.offSince=nil end
    if old and moved>=2 and moved<100 and ba<old.along-1 and not t.off then t.wrongSince=t.wrongSince or now;if now-t.wrongSince>=2 then t.wrong=true end
    elseif moved>=2 or t.off then t.wrongSince=nil;t.wrong=false end
    N.track=t
    return best,bq,be,math.max(0,total-ba)+be
end
local function turns(path,L)
    local out={};local total=L[1];local last=-100
    for i=2,#path-1 do
        local a=total-L[i]
        if a-last>=30 and a>=15 and total-a>=15 then
            local before,after=at(path,L,a-18),at(path,L,a+18)
            local ux,uy=unit(before,path[i]);local vx,vy=unit(path[i],after)
            local dot=ux*vx+uy*vy;local cross=ux*vy-uy*vx
            if dot<.77 and abs(cross)>.25 then
                out[#out+1]={along=a,left=cross>0};last=a
            end
        end
    end
    return out
end
function N.maneuver(path,p,remaining)
    local t=N.track;local L=N.lengths
    if not t.turns then
        if N.turnPath~=path then N.turnPath=path;N.turnList=turns(path,L) end
        t.turns=N.turnList
    end
    local g={text="Continue straight",state="On route",arrow="↑"}
    if t.off then g.text="Return to highlighted path";g.state=string.format("Off route • %.0f yd",t.error);g.arrow="!";return g end
    if t.wrong then g.text="Turn around";g.state="Wrong direction";g.arrow="↶";return g end
    if N.index==1 and G.distance(path[1],path[2])>15 then g.text="Approach mapped road";g.state="Unchecked terrain";return g end
    if N.index==#path-1 and G.distance(path[#path-1],path[#path])>15 then g.text="Approach destination";g.state="Unchecked terrain";return g end
    for _,v in ipairs(t.turns) do
        local d=v.along-t.along
        if d>=-5 then
            g.arrow=v.left and "←" or "→";g.distance=math.max(0,d)
            local label=v.left and "Turn left" or "Turn right"
            g.text=d<=15 and label.." now" or label..string.format(" in %.0f yd",d)
            return g
        end
    end
    if remaining<=50 then g.text="Approach destination" end
    return g
end
