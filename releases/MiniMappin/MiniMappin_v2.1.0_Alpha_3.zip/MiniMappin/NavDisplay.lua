local _,addon=...
local N=addon.Nav
local call,num=N.call,N.number
local layers={}
local function hide(key) if layers[key] then layers[key]:Hide() end end
function N.hideLayers() hide("map"); hide("runner") end
N.hide=hide
local function layer(key,parent)
    local f=layers[key]
    if not f then
        if InCombatLockdown() then return end
        f=CreateFrame("Frame",nil,parent); f:SetAllPoints();f:EnableMouse(false)
        f.pool={}; layers[key]=f
        f.mark=f:CreateFontString(nil,"OVERLAY","GameFontNormalLarge")
        f.start=f:CreateFontString(nil,"OVERLAY","GameFontNormalLarge")
        f.info=f:CreateFontString(nil,"OVERLAY","GameFontHighlightSmall")
        f.info:SetPoint("BOTTOM",0,8);f.info:SetWidth(math.max(100,parent:GetWidth()-18))
        for _,t in ipairs({f.mark,f.start,f.info}) do t:SetShadowColor(0,0,0,1);t:SetShadowOffset(2,-2) end
    end
    f:Show();return f
end
-- Liang-Barsky clipping keeps lines within each visible viewport.
local function clip(x,y,X,Y,w,h)
    local dx,dy=X-x,Y-y
    local a,b=0,1
    local function side(p,q)
        if p==0 then return q>=0 end
        local t=q/p
        if p<0 then a=math.max(a,t) else b=math.min(b,t) end
        return a<=b
    end
    if side(-dx,x) and side(dx,w-x) and side(-dy,y) and side(dy,h-y) then
        return x+a*dx,y+a*dy,x+b*dx,y+b*dy
    end
end
local palettes={{roads={1,1,0},fast={0,1,1}},{roads={1,.55,0},fast={1,.3,.9}},{roads={.3,1,.65},fast={.45,.7,1}}}
local white={1,1,1}
function N.draw(key,parent,id,project,localProject)
    local db=N.db
    if not db or (not db.dest and not N.previewRecord) or db.hidden or not db[key] then hide(key);return end
    local f=layer(key,parent)
    if not f then return end
    if not InCombatLockdown() then
        local level=parent:GetFrameLevel()+1
        if key=="runner" then level=parent:GetFrameLevel()-1 end
        if key=="map" and OpenMapAPI then local art=call(OpenMapAPI.ArtTopLevel);if num(art) then level=math.max(level,art+1) end end
        if f:GetFrameLevel()~=level then f:SetFrameLevel(level) end
    end
    local w,h=f:GetSize()
    local count=0
    local mode=N.effective or "direct"
    local color=palettes[db.palette][mode] or white
    local function stroke(x,y,X,Y,col,width)
        if count>=900 then return end
        count=count+1
        local l=f.pool[count]
        if not l then
            l={f:CreateLine(nil,"ARTWORK",nil,-1),f:CreateLine(nil,"ARTWORK",nil,1)}; f.pool[count]=l
        end
        for i=1,2 do
            local t=l[i];t:SetStartPoint("TOPLEFT",f,x,-y);t:SetEndPoint("TOPLEFT",f,X,-Y)
            t:SetThickness(width+(i==1 and 3 or 0))
            if i==1 then t:SetColorTexture(0,0,0,db.opacity/100)
            else t:SetColorTexture(col[1],col[2],col[3],db.opacity/100) end
            t:Show()
        end
    end
    local function segment(x,y,X,Y,dash,col,width)
        if not (num(x) and num(y) and num(X) and num(Y)) then return end
        x,y,X,Y=clip(x,y,X,Y,w,h)
        if not x then return end
        local dx,dy=X-x,Y-y
        local length=math.sqrt(dx*dx+dy*dy)
        if length<.3 then return end
        if not dash then stroke(x,y,X,Y,col,width);return end
        for a=0,length,dash+5 do
            local b=math.min(length,a+dash)
            stroke(x+dx*a/length,y+dy*a/length,x+dx*b/length,y+dy*b/length,col,width)
        end
    end
    local function connect(p,q,dash,col,width)
        local x,y=project(p);local X,Y=project(q);segment(x,y,X,Y,dash,col,width)
    end
    local goalX,goalY,px,py
    local rec=N.previewRecord
    if rec then
        for i=1,#rec.points-1 do
            local a,b=rec.points[i],rec.points[i+1]
            connect({x=a.x,y=a.y,c=rec.c},{x=b.x,y=b.y,c=rec.c},8,white,db.width)
        end
    elseif N.localDirect and N.localDirect.id==id then
        local a,b=N.localDirect[1],N.localDirect[2]
        px,py=localProject(a.x,a.y);goalX,goalY=localProject(b.x,b.y)
        segment(px,py,goalX,goalY,12,white,db.width)
    elseif N.path and N.pos and N.goal then
        local path=N.path
        local i=N.index or 1
        if db.shade and mode~="direct" then
            for j=1,i-1 do connect(path[j],path[j+1],nil,{.5,.5,.5},2) end
        end
        local last=mode=="direct" and N.pos or N.progress or path[i]
        if mode~="direct" then connect(N.pos,last,5,white,2) end
        local sx,sy=project(last)
        for j=i+1,#path do
            local X,Y=project(path[j])
            if num(X) and num(Y) and (not sx or (X-sx)^2+(Y-sy)^2>=9 or j==#path) then
                segment(sx,sy,X,Y,mode=="direct" and 12 or mode=="fast" and 24 or nil,color,db.width)
                sx,sy=X,Y
            end
        end
        if mode~="direct" then connect(path[#path],N.goal,5,white,2) end
        px,py=project(N.pos);goalX,goalY=project(N.goal)
        if db.crumbs and N.crumb then
            for j=2,#N.crumb do connect(N.crumb[j-1],N.crumb[j],3,{1,.6,1},2) end
        end
    end
    for i=count+1,#f.pool do f.pool[i][1]:Hide();f.pool[i][2]:Hide() end
    f.mark:Hide();f.start:Hide()
    if num(goalX) and num(goalY) then
        local X,Y=goalX,goalY
        local off=X<8 or Y<8 or X>w-8 or Y>h-8
        if off then
            local cx,cy=w/2,h/2
            local scale=math.min((cx-10)/math.max(.001,math.abs(X-cx)),(cy-10)/math.max(.001,math.abs(Y-cy)))
            X,Y=cx+(X-cx)*scale,cy+(Y-cy)*scale
        end
        f.mark:SetText(off and (math.abs(goalX-X)>math.abs(goalY-Y) and (goalX>X and ">" or "<") or (goalY>Y and "v" or "^")) or "X");f.mark:SetTextColor(1,1,1)
        f.mark:ClearAllPoints();f.mark:SetPoint("CENTER",f,"TOPLEFT",X,-Y);f.mark:Show()
    end
    if key=="map" and num(px) and num(py) and px>=0 and py>=0 and px<=w and py<=h then
        f.start:SetText("+");f.start:ClearAllPoints();f.start:SetPoint("CENTER",f,"TOPLEFT",px,-py);f.start:Show()
    end
    f.info:SetWidth(math.max(60,w-20))
    local facing=call(GetPlayerFacing)
    local compass=db.compass and num(facing) and ({"N","NW","W","SW","S","SE","E","NE"})[math.floor(facing*4/math.pi+.5)%8+1].."  |  " or ""
    f.info:SetText(rec and ("Personal path preview • "..rec.name) or db.info and compass..(db.dest and db.dest.name or "").."\n"..(N.status or "Locating…") or compass)
end
local function stitched()
    return OpenMapAPI and OpenMapAPI.major==1 and call(OpenMapAPI.IsStitched)
end
-- Normalized host-canvas positions survive pan/zoom. Weak keys release old routes.
local hostMap,hostAPI,hostCache
local function paintMap()
    local m=WorldMapFrame
    if not (N.db and (N.db.dest or N.previewRecord) and m and m:IsShown() and m.ScrollContainer and m.GetCanvas) then hide("map");return end
    local c=m:GetCanvas();local scroll=m.ScrollContainer
    if not c then hide("map");return end
    local id=call(m.GetMapID,m)
    local inv=N.basis(id)
    local scale=c:GetEffectiveScale()/scroll:GetEffectiveScale()
    local left,top=c:GetLeft(),c:GetTop()
    if not left or not top or not scroll:GetLeft() then hide("map");return end
    local function loc(x,y)
        return (left+x*c:GetWidth())*scale-scroll:GetLeft(),scroll:GetTop()-(top-y*c:GetHeight())*scale
    end
    local om=stitched() and OpenMapAPI
    if hostMap~=id or hostAPI~=om or not hostCache then
        hostMap,hostAPI=id,om;hostCache=setmetatable({},{__mode="k"})
    end
    local function project(p)
        local x,y
        local cont=p.c or N.pos and N.pos.c
        if om and om.CanvasFromWorldPos then
            local hit=hostCache[p]
            if hit and hit[3]==cont then x,y=hit[1],hit[2]
            else
                x,y=call(om.CanvasFromWorldPos,cont,p.x,p.y)
                if num(x) and num(y) then hostCache[p]={x,y,cont} end
            end
        elseif inv then x,y=inv(p) end
        if num(x) and num(y) then return loc(x,y) end
    end
    N.draw("map",scroll,id,project,loc)
end
local mapDriver=CreateFrame("Frame")
mapDriver:Hide()
function N.updateMapDriver()
    mapDriver:SetShown(not not (WorldMapFrame and WorldMapFrame:IsShown() and N.db and (N.db.dest or N.previewRecord)))
    if not mapDriver:IsShown() then hide("map") end
end
local function hookMap()
    local m=WorldMapFrame
    if not m or mapDriver.bound or InCombatLockdown() then return end
    mapDriver.bound=true
    m:HookScript("OnShow",N.updateMapDriver)
    m:HookScript("OnHide",function() mapDriver:Hide();hide("map") end)
    N.updateMapDriver()
end
local elapsed=0
mapDriver:SetScript("OnUpdate",function(_,dt)
    if not N.db or not (N.db.dest or N.previewRecord) then hide("map");return end
    elapsed=elapsed+dt
    if elapsed>=.12 then elapsed=0;paintMap() end
end)
-- Capture before OpenMap's middle-button release can recenter its canvas.
local pendingClick
local function captureRouteClick()
    if not N.db or not N.db.enabledMapClick or InCombatLockdown() then return end
    local m=WorldMapFrame
    if not (m and m:IsShown() and m.ScrollContainer and m.ScrollContainer:IsMouseOver()) then return end
    local id,x,y,name,view
    if stitched() then
        local om=OpenMapAPI
        local u,v=call(om.CursorPosition)
        if num(u) and num(v) then id=call(om.MapAt,u,v);x,y=call(om.MapFromWorld,id,u,v) end
        local vu,vv,z=call(om.GetView)
        if num(vu) and num(vv) and num(z) then view={vu,vv,z,api=om} end
    else
        id=call(m.GetMapID,m);x,y=call(m.ScrollContainer.GetNormalizedCursorPosition,m.ScrollContainer)
    end
    local focus=call(GetMouseFoci)
    focus=type(focus)=="table" and focus[1] or call(GetMouseFocus)
    if PinMeDB and focus and not (focus.IsForbidden and focus:IsForbidden()) then
        local r=call(function() return focus.record end)
        if type(r)=="table" and (call(function() return r.graveyard end)==true or call(function() return focus.custom end)==true) and num(focus.mapID) and num(r.x) and num(r.y) then
            id,x,y,name=focus.mapID,r.x,r.y,r.name
        end
    end
    if num(id) and num(x) and num(y) and x>=0 and x<=1 and y>=0 and y<=1 then
        return {id=id,x=x,y=y,name=name,view=view}
    end
end
for _,e in ipairs({"PLAYER_LOGIN","ADDON_LOADED","PLAYER_REGEN_ENABLED","GLOBAL_MOUSE_DOWN","GLOBAL_MOUSE_UP"}) do mapDriver:RegisterEvent(e) end
mapDriver:SetScript("OnEvent",function(_,event,button)
    if event~="GLOBAL_MOUSE_DOWN" and event~="GLOBAL_MOUSE_UP" then hookMap();N.updateMapDriver();return end
    if button~="MiddleButton" then return end
    if event=="GLOBAL_MOUSE_DOWN" then
        pendingClick=nil
        if IsAltKeyDown() then pendingClick=captureRouteClick() end
        return
    end
    local click=pendingClick;pendingClick=nil
    if not click or not N.db or not N.db.enabledMapClick or InCombatLockdown() then return end
    local m=WorldMapFrame
    if not (m and m:IsShown() and m.ScrollContainer and m.ScrollContainer:IsMouseOver()) then return end
    N.choose(click.id,click.x,click.y,click.name)
    -- OpenMap has no public click-consumption API. Restore the saved view
    -- after its own mouse-up handler, without replacing protected scripts.
    local v=click.view
    if v and C_Timer and C_Timer.After then
        C_Timer.After(0,function()
            if not InCombatLockdown() and WorldMapFrame and WorldMapFrame:IsShown() and stitched() and OpenMapAPI==v.api then
                call(v.api.ShowWorld,v[1],v[2],v[3])
            end
        end)
    end
end)
