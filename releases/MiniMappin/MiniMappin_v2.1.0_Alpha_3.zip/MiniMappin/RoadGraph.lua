local _, addon = ...
local G = {}
addon.RoadGraph = G
local floor, sqrt = math.floor, math.sqrt
local function dist(a,b) return sqrt((a.x-b.x)^2+(a.y-b.y)^2) end
G.distance=dist
function G.project(p,a,b)
    local dx,dy=b.x-a.x,b.y-a.y
    local len=dx*dx+dy*dy
    local t=len>0 and math.max(0,math.min(1,((p.x-a.x)*dx+(p.y-a.y)*dy)/len)) or 0
    local q={x=a.x+dx*t,y=a.y+dy*t}
    return q, dist(p,q)
end
local function key(x,y) return x..":"..y end
function G.build(data,personal,continent)
    local grid,nodes={},{}
    local function node(x,y)
        local k=key(x,y)
        if not nodes[k] then nodes[k]={x=x,y=y,edges={}} end
        return nodes[k]
    end
    local function edge(a,b,shortcut)
        if a==b or dist(a,b)>1800 then return end
        local e={a=a,b=b,cost=dist(a,b),shortcut=shortcut}
        a.edges[#a.edges+1]=e
        b.edges[#b.edges+1]=e
        for i=floor(math.min(a.x,b.x)/100),floor(math.max(a.x,b.x)/100) do
            for j=floor(math.min(a.y,b.y)/100),floor(math.max(a.y,b.y)/100) do
                local k=key(i,j)
                grid[k]=grid[k] or {}
                table.insert(grid[k],e)
            end
        end
    end
    for line in (data or ""):gmatch("[^\n]+") do
        local prev
        for x,y in line:gmatch("(-?%d+),(-?%d+)") do
            local n=node(tonumber(x),tonumber(y))
            if prev then edge(prev,n,false) end
            prev=n
        end
    end
    for _,r in ipairs(personal or {}) do
        if r.c==continent and r.reviewed then
            local prev
            for _,p in ipairs(r.points) do
                local n=node(p.x,p.y)
                if prev then edge(prev,n,r.kind=="shortcut") end
                prev=n
            end
        end
    end
    return grid
end
local function snap(grid,p,fast)
    local ix,iy=floor(p.x/100),floor(p.y/100)
    local best,limit=nil,35
    for x=ix-1,ix+1 do for y=iy-1,iy+1 do
        for _,e in ipairs(grid[key(x,y)] or {}) do
            if fast or not e.shortcut then
                local q,d=G.project(p,e.a,e.b)
                if d<limit then best,limit={edge=e,p=q},d end
            end
        end
    end end
    return best
end
-- Binary min-heap. No search state is written back to the graph.
local function push(h,v)
    local i=#h+1
    while i>1 do
        local parent=floor(i/2)
        if h[parent][1]<=v[1] then break end
        h[i]=h[parent]; i=parent
    end
    h[i]=v
end
local function pop(h)
    local top,last=h[1],table.remove(h)
    if #h==0 then return top end
    local i=1
    while i*2<=#h do
        local child=i*2
        if child<#h and h[child+1][1]<h[child][1] then child=child+1 end
        if last[1]<=h[child][1] then break end
        h[i]=h[child]; i=child
    end
    h[i]=last
    return top
end
function G.solve(grid,start,goal,fast)
    local s,t=snap(grid,start,fast),snap(grid,goal,fast)
    if not s or not t then return nil,"Outside mapped roads" end
    if s.edge==t.edge then return {s.p,t.p} end
    local heap,cost,prev={},{},{}
    local function visit(n,d,parent)
        if not cost[n] or d<cost[n] then
            cost[n],prev[n]=d,parent
            push(heap,{d+dist(n,t.p),n,d})
        end
    end
    visit(s.edge.a,dist(s.p,s.edge.a)); visit(s.edge.b,dist(s.p,s.edge.b))
    local count=0
    while #heap>0 and count<90000 do
        count=count+1
        local v=pop(heap)
        local n=v[2]
        if v[3]==cost[n] then
            if n==t.edge.a or n==t.edge.b then
                local back={t.p}
                while n do back[#back+1]={x=n.x,y=n.y}; n=prev[n] end
                local path={s.p}
                for i=#back,1,-1 do path[#path+1]=back[i] end
                return path
            end
            for _,e in ipairs(n.edges) do
                if fast or not e.shortcut then visit(e.a==n and e.b or e.a,cost[n]+e.cost,n) end
            end
        end
    end
    return nil,"No connected road path"
end
