local _,addon=...
local N=addon.Nav
local panel,page,selected,kind,buttons,edit,hint,title
local sections={"General","Routing","Map Visibility","Appearance","Advanced","Road Database"}
local modes={"roads","fast","direct"}
local chosen,original
local function nextValue(v,list)
    for i,k in ipairs(list) do if k==v then return list[i%#list+1] end end
    return list[1]
end
local function frame(name,w,h)
    local f=CreateFrame("Frame",name,UIParent,"BackdropTemplate")
    f:Hide();f:SetSize(w,h);f:SetPoint("CENTER");f:SetFrameStrata("FULLSCREEN_DIALOG")
    f:SetBackdrop({bgFile="Interface\\Buttons\\WHITE8X8",edgeFile="Interface\\Buttons\\WHITE8X8",edgeSize=2})
    f:SetBackdropColor(.045,.045,.055,1);f:SetBackdropBorderColor(.5,.52,.57,1)
    f:SetClampedToScreen(true);f:EnableMouse(true);f:SetMovable(true);f:RegisterForDrag("LeftButton")
    f:SetScript("OnDragStart",f.StartMoving);f:SetScript("OnDragStop",f.StopMovingOrSizing)
    table.insert(UISpecialFrames,name);return f
end
local function label(f,text,x,y,font)
    local t=f:CreateFontString(nil,"OVERLAY",font or "GameFontHighlight")
    t:SetPoint("TOPLEFT",x,-y);t:SetText(text);t:SetJustifyH("LEFT");return t
end
local function button(f,x,y,w,caption,fn)
    local b=CreateFrame("Button",nil,f,"UIPanelButtonTemplate")
    b:SetSize(w,25);b:SetPoint("TOPLEFT",x,-y);b:SetText(caption);b:SetScript("OnClick",fn);return b
end
local function message(s) print("|cffffff00MiniMappin|r "..s) end
local function rollback()
    if not original then return end
    N.db=original;original=nil;N.invalidate()
    if N.db.dest then N.tick() else N.clear() end
end
local picker,pickTitle
function N.choose(id,x,y,labelText)
    if InCombatLockdown() or not N.number(x) or not N.number(y) or x<0 or y<0 or x>1 or y>1 then return end
    if not picker then
        picker=frame("MiniMappinRoutePicker",330,202)
        pickTitle=label(picker,"",14,12,"GameFontNormal");pickTitle:SetWidth(290)
        button(picker,292,7,26,"X",function() picker:Hide() end)
        for i,m in ipairs(modes) do
            button(picker,12+(i-1)*104,59,102,N.modeNames[m],function()
                chosen.mode=m;pickTitle:SetText(chosen.name.."\n"..N.modeNames[m])
            end)
        end
        button(picker,12,95,150,"Preview Route",function()
            rollback(); original=N.db; local tmp={}
            for k,v in pairs(original) do tmp[k]=v end
            N.db=tmp; N.set(chosen.id,chosen.x,chosen.y,chosen.name,chosen.mode)
            pickTitle:SetText("Preview • "..(N.status or "Locating…"))
        end)
        button(picker,166,95,150,"Navigate Here",function()
            rollback();N.set(chosen.id,chosen.x,chosen.y,chosen.name,chosen.mode);picker:Hide()
        end)
        button(picker,12,129,150,"Clear Route",function() rollback();N.clear();picker:Hide() end)
        button(picker,166,129,150,"Cancel",function() picker:Hide() end)
        label(picker,"Navigation replaces your current destination.",14,168,"GameFontHighlightSmall")
        picker:SetScript("OnHide",rollback)
    end
    rollback()
    chosen={id=id,x=x,y=y,mode=N.db.mode,name=type(labelText)=="string" and labelText:gsub("[|%c]",""):sub(1,48) or string.format("%.1f, %.1f",x*100,y*100)}
    pickTitle:SetText(chosen.name.."\n"..N.modeNames[chosen.mode])
    picker:Show()
end
local function native()
    local p=N.call(C_Map and C_Map.GetUserWaypoint)
    if type(p)=="table" then
        local x,y=N.xy(p.position)
        if x and N.set(p.uiMapID,x,y,"World waypoint") then return true end
    end
    return false
end
local function navigate(text)
    local id,a,b,desc=text:match("^%s*(%d+)%s+([%d.]+)[ ,]+([%d.]+)%s*(.*)$")
    if not id then a,b,desc=text:match("^%s*([%d.]+)[ ,]+([%d.]+)%s*(.*)$");id=N.player() end
    a,b=tonumber(a),tonumber(b)
    return a and b and N.set(tonumber(id),a/100,b/100,desc~="" and desc or "Coordinates")
end
local function refresh()
    local db=N.db; local rows={}
    local function row(text,fn,tip) rows[#rows+1]={text,fn,tip} end
    local function toggle(k,text,tip)
        row(text.."   ["..(db[k] and "ON" or "OFF").."]",function() db[k]=not db[k];N.dirty=true end,tip)
    end
    local function cycle(k,text,list)
        row(text.."   "..tostring(db[k]),function() db[k]=nextValue(db[k],list);N.dirty=true end)
    end
    local function action(text,fn,tip) row(text,fn,tip) end
    title:SetText(sections[page]);edit:Hide()
    hint:SetText("")
    if page==1 then
        edit:Show();hint:SetText("Enter X Y or MapID X Y, in percent. Add a name if desired.")
        action("Navigate to entered coordinates",function() if not navigate(edit:GetText()) then message("Use X Y, for example 52.5 42.") end end)
        action("Use native world waypoint",function() if not native() then message("No native waypoint available.") end end)
        action("Follow current Forever Maps route",function() if not N.followForever() then message("Start a route in Forever Maps 5.x API first.") end end)
        action("Clear active route",N.clear)
        toggle("enabledMapClick","Alt + middle-click on world map")
        action("Center navigation settings",function() panel:ClearAllPoints();panel:SetPoint("CENTER") end)
    elseif page==2 then
        action("Preferred mode   "..N.modeNames[db.mode],function() db.mode=nextValue(db.mode,modes);db.forever=nil;N.invalidate() end)
        toggle("fallback","Use Direct when coverage ends","Draws a dashed line through unchecked terrain.")
        toggle("reroute","Recalculate after deviation")
        cycle("radius","Arrival radius (yards)",{5,8,12,20,35})
        toggle("personal","Include reviewed personal paths")
        hint:SetText("Follow Roads uses mapped road segments. Fastest also considers reviewed shortcuts at current ground speed.")
    elseif page==3 then
        toggle("map","World map / OpenMap");toggle("runner","Map Runner")
        toggle("hidden","Temporarily hide all routes");toggle("info","Compact route information")
        hint:SetText("Middle-click M to toggle Map Runner. Routes stay active when either map closes.")
    elseif page==4 then
        cycle("width","Line thickness",{2,3,4,6,8});cycle("opacity","Line opacity (%)",{25,50,75,100})
        cycle("palette","Color palette",{1,2,3})
        toggle("compass","Compass heading");toggle("crumbs","Recent breadcrumb trail");toggle("shade","Shade completed road")
        hint:SetText("1 Yellow / cyan     2 Orange / pink     3 Mint / blue\nRoads are solid, fastest uses long dashes, direct uses short white dashes.")
    elseif page==5 then
        edit:Show()
        action("Report road at player position",function()
            local id,x,y=N.player()
            if not id or #db.reports>=40 then message("No position or report limit reached.");return end
            local note=edit:GetText():gsub("[|%c]"," "):sub(1,48)
            table.insert(db.reports,{id=id,x=x,y=y,name=note})
            message("Saved report. Copy the latest report to share it.")
        end)
        action("Copy latest road report",function()
            local r=db.reports[#db.reports]
            if r then edit:SetText(string.format("Road DB fb756a1 • map %d • %.3f %.3f • %s",r.id,r.x*100,r.y*100,r.name));edit:SetFocus();edit:HighlightText() end
        end)
        toggle("zoom","Use movement-based overlay zoom")
        cycle("walkZoom","Walking zoom",{1,2,3,4,5,6,8,10,12});cycle("mountZoom","Mounted zoom",{1,2,3,4,5,6,8,10,12})
        action("Open Map Runner position controls",function() panel:Hide();addon.MapRunner.Settings() end)
        hint:SetText("Map Runner keeps its manual zoom when dynamic zoom is off. Use Center overlay in its position controls to rescue it.")
    else
        edit:Show()
        local r=db.routes[selected]
        hint:SetText("Road DB fb756a1 • Eastern Kingdoms, Kalimdor, Zephras Isle\n"..(r and string.format("%d/%d  %s • %s • %d points%s",selected,#db.routes,r.name,r.kind,#r.points,r.reviewed and " • reviewed" or "") or "No personal path selected"))
        action("Class   "..kind,function() kind=nextValue(kind,{"road","trail","shortcut"}) end)
        action("Record road using entered name",function() if not N.record(kind,edit:GetText()~="" and edit:GetText() or "Recorded road") then message("Recording unavailable or already active.") else message("Recording started.") end end)
        action("Pause / resume recording",function() message(N.pause()) end)
        action("Stop and save",function() if N.stop() then selected=#db.routes;message("Saved personal path.") else message("No path with two valid samples.") end end)
        action("Select next personal path",function() selected=selected%math.max(1,#db.routes)+1 end)
        action("Export selected to text field",function() edit:SetText(N.export(selected) or "");edit:SetFocus();edit:HighlightText() end)
        action("Import path from text field",function() if N.import(edit:GetText()) then selected=#db.routes else message("Invalid path or storage limit.") end end)
        action("Rename / apply selected class",function() if r and #edit:GetText()>0 and #edit:GetText()<=48 then r.name=edit:GetText():gsub("[;|%c]"," ");r.kind=kind;r.reviewed=false;N.invalidate(true) end end)
        action(r and r.reviewed and "Withdraw personal review" or "Mark personally verified",function() if r then r.reviewed=not r.reviewed;N.invalidate(true) end end)
        action("Delete selected (Shift-click)",function() if r and IsShiftKeyDown() then table.remove(db.routes,selected);selected=1;N.invalidate(true) end end)
        action("Preview selected recorded path",function() if r then N.previewRecord=r;N.updateMapDriver();panel:Hide();message("Recorded path preview on map. Reopen Navigation to finish.") end end)
    end
    for i,b in ipairs(buttons) do
        local item=rows[i];b:SetShown(item~=nil)
        if item then
            b:SetText(item[1]);b.tip=item[3]
            b:SetScript("OnClick",function() item[2](); if db.personal~=N.personalState then N.personalState=db.personal;N.invalidate(true) end;refresh() end)
        end
    end
end
function N.settings()
    if InCombatLockdown() or not N.db then return end
    N.previewRecord=nil;N.updateMapDriver()
    if not panel then
        panel=frame("MiniMappinNavigationSettings",470,464)
        panel:SetScale(math.min(1,UIParent:GetWidth()/480,UIParent:GetHeight()/475))
        label(panel,"MiniMappin Navigation   v2.1.0 Alpha 3",14,14,"GameFontNormalLarge")
        button(panel,430,8,27,"X",function() panel:Hide() end)
        for i,t in ipairs(sections) do
            button(panel,12,50+(i-1)*32,124,t,function() page=i;edit:SetText("");refresh() end)
        end
        title=label(panel,"",149,49,"GameFontNormal")
        edit=CreateFrame("EditBox",nil,panel,"InputBoxTemplate");edit:SetPoint("TOPLEFT",153,-73);edit:SetSize(292,23);edit:SetAutoFocus(false);edit:SetMaxLetters(14000)
        edit:SetScript("OnEscapePressed",function() edit:ClearFocus();panel:Hide() end)
        buttons={}
        for i=1,11 do
            local b=button(panel,149,102+(i-1)*26,305,"",function() end);buttons[i]=b
            b:SetScript("OnEnter",function(self) if self.tip then GameTooltip:SetOwner(self,"ANCHOR_RIGHT");GameTooltip:SetText(self.tip,nil,nil,nil,nil,true);GameTooltip:Show() end end)
            b:SetScript("OnLeave",function() GameTooltip:Hide() end)
        end
        hint=label(panel,"",15,400);hint:SetWidth(440)
        label(panel,"RIP Shady",15,441,"GameFontDisableSmall")
        page,selected,kind=1,1,"road"
    end
    refresh();panel:Show()
end
SLASH_MINIMAPPINGPS1="/mmnav"
SlashCmdList.MINIMAPPINGPS=function(text)
    N.init();if not N.db then return end
    if text=="clear" then N.clear()
    elseif text=="waypoint" then if not native() then message("No native waypoint.") end
    elseif text=="" then N.settings()
    elseif not navigate(text) then message("/mmnav [mapID] X Y [name]  |  /mmnav waypoint  |  /mmnav clear") end
end
