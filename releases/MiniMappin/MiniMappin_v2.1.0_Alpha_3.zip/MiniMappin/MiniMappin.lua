local _, addon = ...
local events = CreateFrame("Frame")
local db, map, home, border, sidebar, bar, resets, settings
local nativeSize, terrainTint
local atlas, atlasMapID, atlasLayer, atlasAssets
local atlasElapsed = 0
local viewSelector
local mapViews = {"Default", "Atlas", "Navigation Atlas", "Zone Overview"}
local questPins, questMapID, questRefreshAt
local scanDelay, scanAttempt
local scanIntervals = {0.15, 0.35, 0.75, 1.5, 3, 6}
local buttons, managed = {}, {}
local dragButton, movingEdge
local dragHooks = {}
local ApplyIcons
local hoverMode, secureSidebarHover
local elapsed, resetElapsed, hoverUntil = 0, 0, 0
local white = "Interface\\Buttons\\WHITE8X8"
local modes = {"Current placement", "Hover sidebar", "Movable bar", "Hover around map"}
local delayNames = {"Fast", "Normal", "Slow"}
local delaySeconds = {0.2, 0.4, 0.75}
local sidebarLocations = {"Minimap", "Left edge", "Right edge"}
local blocked = {
    MiniMapMailFrame = true, MinimapMailFrame = true, MinimapZoomIn = true,
    MinimapZoomOut = true, MiniMapTracking = true, MiniMapTrackingButton = true,
    MiniMapWorldMapButton = true, MinimapZoneTextButton = true,
    MiniMapBattlefieldFrame = true, MiniMapLFGFrame = true, QueueStatusMinimapButton = true,
}

local function MakeBackdrop(frame, opacity, edgeSize)
    if not frame.SetBackdrop then return end
    frame:SetBackdrop({
        bgFile = white, edgeFile = white, edgeSize = edgeSize or 1,
        insets = {left = 1, right = 1, top = 1, bottom = 1},
    })
    frame:SetBackdropColor(0.035, 0.032, 0.028, opacity)
    frame:SetBackdropBorderColor(0.46, 0.39, 0.27, 0.95)
end

local function Panel(parent)
    return CreateFrame("Frame", nil, parent, BackdropTemplateMixin and "BackdropTemplate" or nil)
end

local function Label(parent, font, value)
    local label = parent:CreateFontString(nil, "OVERLAY", font)
    label:SetText(value)
    return label
end

local function Button(parent, value, width, onClick)
    local button = CreateFrame("Button", nil, parent, "UIPanelButtonTemplate")
    button:SetSize(width, 23)
    button:SetText(value)
    button:SetScript("OnClick", onClick)
    return button
end

local function InCombat()
    return InCombatLockdown and InCombatLockdown()
end

local function Points(frame)
    local points = {}
    for index = 1, frame:GetNumPoints() do
        points[index] = {frame:GetPoint(index)}
    end
    return points
end

local function RestorePoints(frame, points)
    frame:ClearAllPoints()
    for _, point in ipairs(points) do frame:SetPoint(unpack(point)) end
end

local function HideCircularArt()
    local cluster = MinimapCluster
    local backdrop = _G.MinimapBackdrop
    local function Hide(region)
        if region and region:IsObjectType("Texture") then
            region:Hide()
        end
    end

    Hide(_G.MinimapBorder)
    Hide(_G.MinimapBorderTop)
    Hide(_G.MinimapCompassTexture)
    Hide(map.Border)
    Hide(map.CompassTexture)
    if cluster then
        Hide(cluster.Border)
        Hide(cluster.BorderTop)
        Hide(cluster.CompassTexture)
    end

    local function Scan(frame)
        if not frame then return end
        for _, region in ipairs({frame:GetRegions()}) do
            if region:IsObjectType("Texture") then
                local texture = region:GetTexture()
                local atlas = region.GetAtlas and region:GetAtlas()
                local path = type(texture) == "string" and texture:lower():gsub("/", "\\")
                if path == "interface\\minimap\\minimap-border"
                    or path == "interface\\minimap\\minimap-compass"
                    or atlas == "Minimap-Compass"
                    or atlas == "Minimap-Border" then
                    Hide(region)
                end
            end
        end
    end
    Scan(map)
    Scan(cluster)
    Scan(backdrop)
end

local function ApplyBorder()
    if InCombat() then return end
    local thickness = db.borderThickness
    border:ClearAllPoints()
    border:SetPoint("TOPLEFT", map, "TOPLEFT", -thickness, thickness)
    border:SetPoint("BOTTOMRIGHT", map, "BOTTOMRIGHT", thickness, -thickness)
    MakeBackdrop(border, 0, thickness)
end

local function ApplyMap()
    if InCombat() then return end
    local appliedSize = math.max(90, math.min(300, nativeSize + db.size))
    map:SetMaskTexture(white)
    HideCircularArt()
    if db.size == 0 and db.x == 0 and db.y == 0 then
        if map:GetPoint(1) == "CENTER" and select(2, map:GetPoint(1)) == home then
            RestorePoints(map, Points(home))
            map:SetSize(home:GetWidth(), home:GetHeight())
        end
    else
        map:SetSize(appliedSize, appliedSize)
        map:ClearAllPoints()
        map:SetPoint("CENTER", home, "CENTER", db.x, db.y)
    end
end

local function ButtonName(button)
    local name = button:GetName()
    if not name or blocked[name] then return end
    -- Questie creates a numbered button for each map pin.
    if name:match("^QuestieFrame%d+$") then return end
    return name
end

local function DiscoverButtons()
    buttons = {}
    local seen = {}
    local function Add(button)
        if not button or seen[button] or not button:IsObjectType("Button") then return end
        local name = ButtonName(button)
        if not name then return end
        -- Action Hero's secure click still belongs to the original button.
        -- Other protected frames are excluded from addon icon management.
        if button.IsProtected and button:IsProtected() and button ~= _G.ActionHeroMinimapButton then return end
        seen[button] = true
        buttons[#buttons + 1] = {frame = button, name = name}
    end
    local function Scan(parent)
        if not parent then return end
        for _, child in ipairs({parent:GetChildren()}) do Add(child) end
    end
    Scan(map)
    Scan(MinimapCluster)
    Add(_G.ActionHeroMinimapButton)
    for button in pairs(managed) do Add(button) end
    if LibStub then
        local library = LibStub("LibDBIcon-1.0", true)
        if library and library.GetButtonList and library.GetMinimapButton then
            for _, key in ipairs(library:GetButtonList()) do Add(library:GetMinimapButton(key)) end
        end
    end
    table.sort(buttons, function(a, b) return a.name < b.name end)
end

local function RestoreButtons()
    dragButton = nil
    for button, state in pairs(managed) do
        button:SetScript("OnDragStart", state.dragStart)
        button:SetScript("OnDragStop", state.dragStop)
        button:SetParent(state.parent)
        RestorePoints(button, state.points)
        button:SetFrameStrata(state.strata)
        button:SetFrameLevel(state.level)
    end
    managed = {}
end

local function PlaceDock(frame, key, point, relative, relativePoint, x, y)
    frame:ClearAllPoints()
    local saved = db[key]
    if saved then
        frame:SetPoint(saved.point, UIParent, saved.relative, saved.x, saved.y)
    else
        frame:SetPoint(point, relative, relativePoint, x, y)
    end
end

local function RingPoint(index, count)
    local half = map:GetWidth() / 2 + 14
    local side = (index - 0.5) * 4 / count
    local offset = (side % 1 * 2 - 1) * half
    if side < 1 then return -half, offset end
    if side < 2 then return offset, half end
    if side < 3 then return half, -offset end
    return -offset, -half
end

local function PlaceSidebar()
    if InCombat() then return end
    local location = db.sidebarLocation
    local content = sidebar.content
    sidebar:ClearAllPoints()
    content:ClearAllPoints()
    if location == 1 then
        sidebar:SetPoint("RIGHT", border, "LEFT", -2, 0)
        content:SetPoint("RIGHT", sidebar, "LEFT", 0, 0)
    else
        local height = UIParent:GetHeight()
        local side = location == 2 and "LEFT" or "RIGHT"
        local inner = location == 2 and "RIGHT" or "LEFT"
        local screenAnchor = "BOTTOM" .. side
        local halfTab = sidebar:GetHeight() / 2
        local y = math.max(halfTab, math.min(height - halfTab, db.sidebarHeight[location] * height))
        local halfPanel = math.min(content:GetHeight(), height) / 2
        local panelY = math.max(halfPanel, math.min(height - halfPanel, y))
        sidebar:SetPoint(side, UIParent, screenAnchor, 0, y)
        content:SetPoint(side, sidebar, inner, 0, panelY - y)
    end
    sidebar.arrow:SetText(location == 2 and ">" or "<")
end

local ring
local function FinishDrag(button)
    if dragButton ~= button then return end
    dragButton = nil
    if InCombat() or not managed[button] then return end
    local x, y = GetCursorPosition()
    local closest, distance
    for candidate, state in pairs(managed) do
        local cx, cy = candidate:GetCenter()
        if cx and cy and candidate:IsVisible() then
            local scale = candidate:GetEffectiveScale()
            local delta = (x - cx * scale)^2 + (y - cy * scale)^2
            if not distance or delta < distance then
                closest, distance = state, delta
            end
        end
    end
    local source = managed[button]
    if not closest or closest == source then return end
    local order = db.iconOrder[db.mode]
    order[source.index], order[closest.index] = order[closest.index], order[source.index]
    ApplyIcons()
end

local function InstallDrag(button)
    if not dragHooks[button] then
        dragHooks[button] = true
        button:HookScript("OnMouseDown", function(self, mouse)
            if managed[self] and mouse == "LeftButton" and IsShiftKeyDown() and not InCombat() then
                dragButton = self
            end
        end)
        button:HookScript("OnMouseUp", function(self, mouse)
            if mouse == "LeftButton" then FinishDrag(self) end
        end)
    end
    button:SetScript("OnDragStart", function(self, mouse)
        if mouse == "LeftButton" and not InCombat() then dragButton = self end
    end)
    button:SetScript("OnDragStop", FinishDrag)
end

-- Some addon buttons set their own anchors outside their drag handlers.
local function UpdateManagedAnchors()
    for button, state in pairs(managed) do
        local point, relative, relativePoint, x, y = button:GetPoint(1)
        local anchor = state.anchor
        if button:GetParent() ~= state.layoutParent then button:SetParent(state.layoutParent) end
        if point ~= anchor[1] or relative ~= anchor[2] or relativePoint ~= anchor[3]
            or x ~= anchor[4] or y ~= anchor[5] or button:GetNumPoints() ~= 1 then
            button:ClearAllPoints()
            button:SetPoint(unpack(anchor))
        end
    end
end

ApplyIcons = function()
    if InCombat() then return end
    if secureSidebarHover then sidebar:SetAttribute("hoverDelay", delaySeconds[db.sidebarDelay]) end
    hoverMode, hoverUntil = nil, 0
    RestoreButtons()
    sidebar:Hide()
    bar:Hide()
    ring:Hide()
    if db.mode == 1 then return end
    local available, selected = {}, {}
    local slot = db.iconSlotSize[db.mode] or 33
    for _, entry in ipairs(buttons) do
        if db.icons[entry.name] then
            available[entry.name] = entry.frame
            slot = math.max(slot, entry.frame:GetWidth() + 4, entry.frame:GetHeight() + 4)
        end
    end
    local order, placed = {}, {}
    for _, name in ipairs(db.iconOrder[db.mode] or {}) do
        if db.icons[name] and not placed[name] then
            order[#order + 1], placed[name] = name, true
        end
    end
    for _, entry in ipairs(buttons) do
        if available[entry.name] and not placed[entry.name] then
            order[#order + 1], placed[entry.name] = entry.name, true
        end
    end
    db.iconOrder[db.mode] = order
    db.iconSlotSize[db.mode] = #order > 0 and slot or nil
    for index, name in ipairs(order) do
        if available[name] then
            selected[#selected + 1] = {name = name, frame = available[name], index = index}
        end
    end
    local count = #order
    if #selected == 0 then return end
    local parent = db.mode == 2 and sidebar.content or db.mode == 3 and bar or ring
    local columns = math.min(6, count)
    sidebar.content:SetSize(slot * math.ceil(count / 8) + 6, slot * math.min(count, 8) + 6)
    PlaceSidebar()
    bar:SetSize(slot * columns + 8, slot * math.ceil(count / columns) + 8)
    for _, entry in ipairs(selected) do
        local index = entry.index
        local button = entry.frame
        local state = {
            name = entry.name, index = index, layoutParent = parent,
            dragStart = button:GetScript("OnDragStart"), dragStop = button:GetScript("OnDragStop"),
            parent = button:GetParent(), points = Points(button),
            strata = button:GetFrameStrata(), level = button:GetFrameLevel(),
        }
        managed[button] = state
        InstallDrag(button)
        button:SetParent(parent)
        button:SetFrameStrata(parent:GetFrameStrata())
        button:SetFrameLevel(parent:GetFrameLevel() + 1)
        button:ClearAllPoints()
        if db.mode == 2 then
            button:SetPoint("TOPLEFT", parent, "TOPLEFT",
                3 + slot * math.floor((index - 1) / 8), -3 - slot * ((index - 1) % 8))
        elseif db.mode == 3 then
            button:SetPoint("TOPLEFT", parent, "TOPLEFT",
                4 + slot * ((index - 1) % columns), -4 - slot * math.floor((index - 1) / columns))
        else
            local x, y = RingPoint(index, count)
            button:SetPoint("CENTER", map, "CENTER", x, y)
        end
        state.anchor = {button:GetPoint(1)}
    end
    sidebar:SetShown(db.mode == 2)
    sidebar.content:Hide()
    bar:SetShown(db.mode == 3)
    if db.mode == 2 or db.mode == 4 then hoverMode = db.mode end
end

local function Over(frame)
    return frame:IsVisible() and frame:IsMouseOver()
end

local function UpdateHover()
    if not hoverMode or (hoverMode == 2 and secureSidebarHover) then return end
    local content = hoverMode == 2 and sidebar.content or ring
    if InCombat() and content.IsProtected and content:IsProtected() then return end
    local over = hoverMode == 2 and (Over(sidebar) or Over(content))
        or hoverMode == 4 and Over(map)
    if not over then
        for button in pairs(managed) do
            if Over(button) then over = true break end
        end
    end
    local now = GetTime()
    if over or dragButton or movingEdge then hoverUntil = now + (hoverMode == 2 and delaySeconds[db.sidebarDelay] or 0.4) end
    local show = now < hoverUntil
    if content:IsShown() ~= show then content:SetShown(show) end
end

local function ReadSeconds(callback)
    if not callback then return end
    local ok, value = pcall(callback)
    if ok and type(value) == "number" and value >= 0 then return value end
end

local function FormatReset(seconds)
    if not seconds then return "Unavailable" end
    if seconds < 60 then return "<1m" end
    local minutes = math.floor(seconds / 60)
    local hours = math.floor(minutes / 60)
    if hours >= 24 then return ("%dd %dh"):format(math.floor(hours / 24), hours % 24) end
    return ("%dh %02dm"):format(hours, minutes % 60)
end

local function SizeResetDisplay()
    local scale = db.resetScale
    local text = resets.text
    local baseSize = math.max(5, (resets.fontSize or 10) * scale)
    if resets.font then text:SetFont(resets.font, baseSize, resets.fontFlags) end
    local width = text:GetStringWidth() + math.max(6, 16 * scale)
    local height = 21 * scale
    if resets.font then
        local maxWidth = width - math.max(4, 5 * scale)
        local low, high = baseSize, math.min(baseSize * 1.18, height - 2)
        for _ = 1, 4 do
            if high <= low then break end
            local candidate = (low + high) / 2
            text:SetFont(resets.font, candidate, "OUTLINE")
            if text:GetStringWidth() <= maxWidth and text:GetStringHeight() <= height - 2 then
                low = candidate
            else
                high = candidate
            end
        end
        text:SetFont(resets.font, low, "OUTLINE")
    end
    resets:SetSize(width, height)
end

local function UpdateResets()
    local showDaily = db.showDailyReset ~= false
    local showWeekly = db.showWeeklyReset ~= false
    local visible = db.resets and (showDaily or showWeekly) or false
    resets:SetShown(visible)
    if not visible then return end
    local api = C_DateAndTime or {}
    local timers = {}
    if showDaily then
        local daily = ReadSeconds(api.GetSecondsUntilDailyReset) or ReadSeconds(GetQuestResetTime)
        timers[#timers + 1] = "Daily " .. FormatReset(daily)
    end
    if showWeekly then
        timers[#timers + 1] = "Weekly " .. FormatReset(ReadSeconds(api.GetSecondsUntilWeeklyReset))
    end
    resets.text:SetText(table.concat(timers, "  |  "))
    SizeResetDisplay()
end

local function HideOwnedTooltip(frame)
    if GameTooltip:IsOwned(frame) then GameTooltip:Hide() end
end

local function ResetTooltip(self)
    GameTooltip:SetOwner(self, "ANCHOR_LEFT")
    GameTooltip:SetText("Instance lockouts")
    if GetNumSavedInstances and GetSavedInstanceInfo then
        local count = 0
        for index = 1, GetNumSavedInstances() do
            local name, _, remaining, _, locked, extended = GetSavedInstanceInfo(index)
            if name and type(remaining) == "number" and (locked or extended) then
                GameTooltip:AddDoubleLine(name, FormatReset(remaining), 1, 1, 1, 1, 0.82, 0.25)
                count = count + 1
            end
        end
        if count == 0 then GameTooltip:AddLine("No saved lockouts reported.", 0.8, 0.8, 0.8) end
    else
        GameTooltip:AddLine("Saved lockouts unavailable.", 0.8, 0.8, 0.8)
    end
    GameTooltip:AddLine("Shift-left-drag: Move")
    GameTooltip:AddLine("Shift-right-drag: Resize")
    GameTooltip:Show()
end

local function MakeMovable(frame, key, grip)
    grip = grip or frame
    frame:SetMovable(true)
    frame:SetClampedToScreen(true)
    grip:EnableMouse(true)
    grip:RegisterForDrag("LeftButton")
    local dragging
    grip:SetScript("OnDragStart", function()
        if not InCombat() and IsShiftKeyDown() then
            dragging = true
            frame:StartMoving()
        end
    end)
    grip:SetScript("OnDragStop", function()
        if not dragging then return end
        dragging = false
        frame:StopMovingOrSizing()
        local point, _, relative, x, y = frame:GetPoint()
        db[key] = {point = point, relative = relative, x = x, y = y}
    end)
end

local function MakeResetResizable()
    local moveStart = resets:GetScript("OnDragStart")
    local moveStop = resets:GetScript("OnDragStop")
    local startX, startScale, pixelsPerScale
    resets:RegisterForDrag("LeftButton", "RightButton")
    resets:SetScript("OnDragStart", function(self, mouse)
        if mouse ~= "RightButton" then
            moveStart(self, mouse)
        elseif IsShiftKeyDown() then
            startX = GetCursorPosition()
            startScale = db.resetScale
            pixelsPerScale = math.max(1, self:GetWidth() * self:GetEffectiveScale() / startScale)
            HideOwnedTooltip(self)
            self:SetScript("OnUpdate", function()
                local x = GetCursorPosition()
                local scale = math.max(0.45, math.min(1.75, startScale + (x - startX) / pixelsPerScale))
                if scale ~= db.resetScale then
                    db.resetScale = scale
                    SizeResetDisplay()
                end
            end)
        end
    end)
    resets:SetScript("OnDragStop", function(self)
        if startX then
            startX = nil
            self:SetScript("OnUpdate", nil)
        else
            moveStop(self)
        end
    end)
    resets:HookScript("OnHide", function(self)
        if startX then
            startX = nil
            self:SetScript("OnUpdate", nil)
        end
    end)
end

local function Reflow()
    if InCombat() then return end
    RestoreButtons()
    DiscoverButtons()
    ApplyMap()
    ApplyBorder()
    ApplyIcons()
    UpdateResets()
end

local function Check(parent, label, x, y, checked, callback)
    local check = CreateFrame("CheckButton", nil, parent, "UICheckButtonTemplate")
    check:SetSize(24, 24)
    check:SetPoint("TOPLEFT", x, y)
    check:SetChecked(checked)
    local text = Label(check, "GameFontHighlight", label)
    text:SetPoint("LEFT", check, "RIGHT", 2, 0)
    check:SetScript("OnClick", function(self) callback(self:GetChecked() and true or false) end)
    return check, text
end

local function AtlasMarker(marker, x, y, width, height)
    local halfWidth, halfHeight = marker:GetWidth() / 2, marker:GetHeight() / 2
    marker:SetShown(x >= halfWidth and x <= width - halfWidth and y >= halfHeight and y <= height - halfHeight)
    marker:SetPoint("CENTER", atlas, "TOPLEFT", x, -y)
end

local function UpdateAtlasMarkers(api, mapID, x, y, left, top, scale, artWidth, artHeight, width, height)
    local navigation = db.mapView == 3
    local facing = navigation and GetPlayerFacing and GetPlayerFacing()
    atlas.player:SetTexture(facing and "Interface\\AddOns\\MiniMappin\\AtlasArrow.tga" or white)
    atlas.player:SetSize(facing and 16 or 7, facing and 16 or 7)
    atlas.player:SetRotation(facing or 0)
    atlas.player:SetPoint("CENTER", atlas, "TOPLEFT", (x * artWidth - left) * scale, (top - y * artHeight) * scale)

    local waypoint = api.GetUserWaypoint and api.GetUserWaypoint()
    if waypoint and waypoint.uiMapID == mapID and waypoint.position then
        local wx, wy = waypoint.position:GetXY()
        AtlasMarker(atlas.waypoint, (wx * artWidth - left) * scale, (wy * artHeight - top) * scale, width, height)
    else
        atlas.waypoint:Hide()
    end

    for index, marker in ipairs(atlas.partyMarkers) do
        local unit = "party" .. index
        local px, py
        if UnitExists(unit) then
            local ok, position = pcall(api.GetPlayerMapPosition, mapID, unit)
            if ok and position then px, py = position:GetXY() end
        end
        if type(px) == "number" and type(py) == "number"
            and not (issecretvalue and (issecretvalue(px) or issecretvalue(py)))
            and px >= 0 and px <= 1 and py >= 0 and py <= 1 then
            AtlasMarker(marker, (px * artWidth - left) * scale, (py * artHeight - top) * scale, width, height)
        else
            marker:Hide()
        end
    end

    local used = 0
    if navigation and C_QuestLog and C_QuestLog.GetQuestsOnMap then
        local now = GetTime()
        if questMapID ~= mapID or now >= questRefreshAt then
            questPins = C_QuestLog.GetQuestsOnMap(mapID) or {}
            questMapID, questRefreshAt = mapID, now + 1
        end
        for _, quest in ipairs(questPins) do
            if type(quest.x) == "number" and type(quest.y) == "number" then
                local px, py = (quest.x * artWidth - left) * scale, (quest.y * artHeight - top) * scale
                if px >= 6 and px <= width - 6 and py >= 6 and py <= height - 6 then
                    used = used + 1
                    local pin = atlas.questMarkers[used]
                    if not pin then
                        pin = Label(atlas, "GameFontNormal", "!")
                        atlas.questMarkers[used] = pin
                    end
                    pin:SetPoint("CENTER", atlas, "TOPLEFT", px, -py)
                    pin:Show()
                end
            end
        end
    end
    for i = used + 1, #atlas.questMarkers do atlas.questMarkers[i]:Hide() end
end

local function UpdateAtlas()
    if db.mapView == 1 or not map:IsVisible() then
        atlas:Hide()
        return
    end
    local api = C_Map
    if not api or not (api.GetBestMapForUnit and api.GetPlayerMapPosition
        and api.GetMapArtLayers and api.GetMapArtLayerTextures) then
        atlas:Hide()
        return
    end
    local mapID = api.GetBestMapForUnit("player")
    local position = mapID and api.GetPlayerMapPosition(mapID, "player")
    if not position then
        atlas:Hide()
        return
    end
    if mapID ~= atlasMapID then
        local layers = api.GetMapArtLayers(mapID)
        atlasLayer = layers and layers[1]
        atlasAssets = atlasLayer and api.GetMapArtLayerTextures(mapID, 1)
        atlasMapID = mapID
    end
    local layer = atlasLayer
    if not layer or not atlasAssets or #atlasAssets == 0 then
        atlas:Hide()
        return
    end
    local x, y = position:GetXY()
    local width, height = map:GetWidth(), map:GetHeight()
    local artWidth, artHeight = layer.layerWidth or 0, layer.layerHeight or 0
    local tileWidth, tileHeight = layer.tileWidth or 0, layer.tileHeight or 0
    if not x or not y or x < 0 or x > 1 or y < 0 or y > 1 or width <= 0 or height <= 0
        or artWidth <= 0 or artHeight <= 0 or tileWidth <= 0 or tileHeight <= 0 then
        atlas:Hide()
        return
    end

    -- Keep the same player-centered distance in both Atlas views.
    local scale = 3 * math.min(width, height) / math.min(artWidth, artHeight)
    local left, top = x * artWidth - width / (2 * scale), y * artHeight - height / (2 * scale)
    if db.mapView == 4 then
        scale = math.min(width / artWidth, height / artHeight) * 0.92
        left, top = (artWidth - width / scale) / 2, (artHeight - height / scale) / 2
    end
    local right, bottom = left + width / scale, top + height / scale
    local columns = math.ceil(artWidth / tileWidth)
    local rows = math.ceil(artHeight / tileHeight)
    local used = 0
    for row = math.max(0, math.floor(top / tileHeight)), math.min(rows - 1, math.ceil(bottom / tileHeight) - 1) do
        for column = math.max(0, math.floor(left / tileWidth)), math.min(columns - 1, math.ceil(right / tileWidth) - 1) do
            local asset = atlasAssets[row * columns + column + 1]
            local tileX, tileY = column * tileWidth, row * tileHeight
            local x1, y1 = math.max(tileX, left), math.max(tileY, top)
            local x2 = math.min(tileX + tileWidth, right, artWidth)
            local y2 = math.min(tileY + tileHeight, bottom, artHeight)
            if asset and asset ~= 0 and x2 > x1 and y2 > y1 then
                used = used + 1
                local tile = atlas.tiles[used]
                if not tile then
                    tile = atlas:CreateTexture(nil, "ARTWORK")
                    atlas.tiles[used] = tile
                end
                if tile.asset ~= asset then
                    tile:SetTexture(asset)
                    tile.asset = asset
                end
                tile:SetPoint("TOPLEFT", atlas, "TOPLEFT", (x1 - left) * scale, (top - y1) * scale)
                tile:SetSize((x2 - x1) * scale, (y2 - y1) * scale)
                tile:SetTexCoord((x1 - tileX) / tileWidth, (x2 - tileX) / tileWidth,
                    (y1 - tileY) / tileHeight, (y2 - tileY) / tileHeight)
                tile:Show()
            end
        end
    end
    for i = used + 1, #atlas.tiles do atlas.tiles[i]:Hide() end
    if used > 0 then
        UpdateAtlasMarkers(api, mapID, x, y, left, top, scale, artWidth, artHeight, width, height)
    end
    atlas:SetShown(used > 0)
end

local function KeepAtlasZoom()
    if db.mapView == 1 or not (map.GetZoom and map.SetZoom) then return end
    local zoom = map:GetZoom()
    if type(db.atlasZoom) ~= "number" then db.atlasZoom = zoom end
    if zoom ~= db.atlasZoom then map:SetZoom(db.atlasZoom) end
end

local function SetMapView(index)
    if db.mapView == 1 then
        db.atlasZoom = map.GetZoom and map:GetZoom()
    end
    db.mapView = index
    KeepAtlasZoom()
    if viewSelector then viewSelector:SetText("Map: " .. mapViews[db.primaryMapView]) end
    UpdateAtlas()
end

local function CyclePrimaryMap()
    db.primaryMapView = db.primaryMapView % #mapViews + 1
    SetMapView(db.primaryMapView)
end

local function RightClickMap()
    if db.secondaryMapView == 0 then
        db.primaryMapView = db.mapView
        CyclePrimaryMap()
    elseif db.mapView == db.secondaryMapView then
        SetMapView(db.primaryMapView)
    else
        SetMapView(db.secondaryMapView)
    end
end

local function Map2Label()
    return "Map 2: " .. (mapViews[db.secondaryMapView] or "None")
end

local function ShowSettings()
    if not db then return end
    if settings and settings:IsShown() then settings:Hide() return end
    if not settings then
        settings = Panel(UIParent)
        settings:SetSize(382, 617)
        settings:SetPoint("CENTER")
        settings:SetFrameStrata("DIALOG")
        MakeBackdrop(settings, db.solid and 1 or 0.86)
        settings:EnableMouse(true)
        settings:SetMovable(true)
        settings:RegisterForDrag("LeftButton")
        settings:SetScript("OnDragStart", settings.StartMoving)
        settings:SetScript("OnDragStop", settings.StopMovingOrSizing)
        local title = Label(settings, "GameFontNormalLarge", "MiniMappin")
        title:SetPoint("TOPLEFT", 17, -16)
        local close = Button(settings, "X", 25, function() settings:Hide() end)
        close:SetPoint("TOPRIGHT", -10, -10)
        Button(settings, "Navigation", 89, function() settings:Hide(); addon.Nav.settings() end):SetPoint("TOPRIGHT", -152, -10)
        Button(settings, "Map Runner", 108, addon.MapRunner.Settings):SetPoint("TOPRIGHT", -42, -10)

        local function Stepper(y, titleText, key, low, high, step, apply)
            step = step or 5
            apply = apply or Reflow
            local caption = Label(settings, "GameFontHighlight", "")
            local function Change(amount)
                db[key] = math.min(high, math.max(low, db[key] + amount))
                caption:SetText(titleText .. "  " .. db[key])
                apply()
            end
            caption:SetPoint("TOPLEFT", 98, y - 5)
            Button(settings, "-", 29, function() Change(IsShiftKeyDown() and -1 or -step) end)
                :SetPoint("TOPLEFT", 18, y)
            Button(settings, "+", 29, function() Change(IsShiftKeyDown() and 1 or step) end)
                :SetPoint("TOPLEFT", 51, y)
            Change(0)
        end
        Stepper(-44, "Size adjustment", "size", -100, 130)
        Stepper(-70, "Horizontal offset", "x", -326, 300)
        Stepper(-96, "Vertical offset", "y", -326, 300)
        Stepper(-122, "Border thickness", "borderThickness", 1, 8, 1, ApplyBorder)

        local menu = Panel(settings)
        menu:SetSize(184, 104)
        menu:SetFrameStrata("FULLSCREEN_DIALOG")
        MakeBackdrop(menu, 1)
        menu:EnableMouse(true)
        menu:Hide()
        local mode = Button(settings, modes[db.mode] .. "  v", 180, function()
            menu:SetShown(not menu:IsShown())
        end)
        mode:SetPoint("TOPLEFT", 18, -156)
        menu:SetPoint("TOPLEFT", mode, "BOTTOMLEFT", 0, -2)
        settings:HookScript("OnHide", function() menu:Hide() end)
        for index, name in ipairs(modes) do
            Button(menu, name, 176, function()
                db.mode = index
                mode:SetText(name .. "  v")
                menu:Hide()
                Reflow()
            end):SetPoint("TOPLEFT", 4, -4 - (index - 1) * 24)
        end
        Check(settings, "Instance reset timers", 14, -186, db.resets, function(value)
            db.resets = value
            if value and RequestRaidInfo then RequestRaidInfo() end
            UpdateResets()
        end)
        Check(settings, "Solid background", 205, -186, db.solid, function(value)
            db.solid = value
            MakeBackdrop(settings, value and 1 or 0.86)
        end)
        Check(settings, "Muted terrain", 14, -213, db.mutedTerrain, function(value)
            db.mutedTerrain = value
            terrainTint:SetShown(value)
        end)
        local function SidebarLabel()
            return "Sidebar: " .. sidebarLocations[db.sidebarLocation]
        end
        Button(settings, SidebarLabel(), 174, function(self)
            db.sidebarLocation = db.sidebarLocation % #sidebarLocations + 1
            self:SetText(SidebarLabel())
            PlaceSidebar()
        end):SetPoint("TOPLEFT", 178, -214)
        viewSelector = Button(settings, "Map: " .. mapViews[db.primaryMapView], 174, CyclePrimaryMap)
        viewSelector:SetPoint("TOPLEFT", 18, -239)
        local mapMenu = Panel(settings)
        mapMenu:SetSize(182, 128)
        mapMenu:SetFrameStrata("FULLSCREEN_DIALOG")
        MakeBackdrop(mapMenu, 1)
        mapMenu:EnableMouse(true)
        mapMenu:Hide()
        local mapRows = {}
        local mapPicker = Button(settings, Map2Label(), 174, function()
            menu:Hide()
            for index = 0, #mapViews do
                mapRows[index]:SetText((index == db.secondaryMapView and "* " or "") .. (mapViews[index] or "None"))
            end
            mapMenu:SetShown(not mapMenu:IsShown())
        end)
        mapPicker:SetPoint("TOPLEFT", 18, -265)
        mapMenu:SetPoint("TOPLEFT", mapPicker, "BOTTOMLEFT", 0, -2)
        menu:HookScript("OnShow", function() mapMenu:Hide() end)
        settings:HookScript("OnHide", function() mapMenu:Hide() end)
        for index = 0, #mapViews do
            local row = Button(mapMenu, mapViews[index] or "None", 174, function()
                db.secondaryMapView = index
                if index == 0 then db.primaryMapView = db.mapView end
                SetMapView(db.primaryMapView)
                mapPicker:SetText(Map2Label())
                mapMenu:Hide()
            end)
            row:SetPoint("TOPLEFT", 4, -4 - index * 24)
            mapRows[index] = row
        end
        Button(settings, "Delay: " .. delayNames[db.sidebarDelay], 174, function(self)
            db.sidebarDelay = db.sidebarDelay % #delayNames + 1
            self:SetText("Delay: " .. delayNames[db.sidebarDelay])
            if secureSidebarHover and not InCombat() then
                sidebar:SetAttribute("hoverDelay", delaySeconds[db.sidebarDelay])
            end
        end):SetPoint("TOPLEFT", 178, -239)
        Check(settings, "Show tooltips", 205, -266, db.showTooltips, function(value)
            db.showTooltips = value
        end)
        Check(settings, "Daily reset", 14, -294, db.showDailyReset ~= false, function(value)
            db.showDailyReset = value
            UpdateResets()
        end)
        Check(settings, "Weekly reset", 205, -294, db.showWeeklyReset ~= false, function(value)
            db.showWeeklyReset = value
            UpdateResets()
        end)
        local hint = Label(settings, "GameFontDisableSmall", "Shift-drag icons to swap, or the edge tab, bar and resets to move.")
        hint:SetPoint("TOPLEFT", 18, -325)
        local section = Label(settings, "GameFontNormal", "Addon buttons")
        section:SetPoint("TOPLEFT", 18, -353)
        local search = CreateFrame("EditBox", nil, settings, "InputBoxTemplate")
        search:SetSize(230, 23)
        search:SetPoint("TOPLEFT", 22, -379)
        search:SetAutoFocus(false)
        search:SetFontObject("GameFontHighlight")
        local placeholder = Label(settings, "GameFontDisable", "Search addon buttons")
        placeholder:SetPoint("LEFT", search, "LEFT", 3, 0)
        local scroll = CreateFrame("ScrollFrame", nil, settings, "UIPanelScrollFrameTemplate")
        scroll:SetPoint("TOPLEFT", 16, -410)
        scroll:SetPoint("BOTTOMRIGHT", -37, 40)
        local list = CreateFrame("Frame", nil, scroll)
        list:SetSize(310, 1)
        scroll:SetScrollChild(list)
        local empty = Label(list, "GameFontDisable", "")
        empty:SetPoint("TOPLEFT", 6, -6)
        local rows = {}
        settings.RefreshButtons = function()
            local query = search:GetText():lower():match("^%s*(.-)%s*$")
            local matches = {}
            for _, entry in ipairs(buttons) do
                local label = entry.name == "ActionHeroMinimapButton" and "Action Hero"
                    or entry.name:gsub("^LibDBIcon10_", "")
                if label:lower():find(query, 1, true) or entry.name:lower():find(query, 1, true) then
                    matches[#matches + 1] = {name = entry.name, label = label}
                end
            end
            for index, entry in ipairs(matches) do
                if not rows[index] then
                    local row, label = Check(list, "", 0, -(index - 1) * 24, false, function() end)
                    row.label = label
                    rows[index] = row
                end
                local row = rows[index]
                row.label:SetText(entry.label)
                row:SetChecked(db.icons[entry.name])
                row:SetScript("OnClick", function(self)
                    db.icons[entry.name] = self:GetChecked() and true or nil
                    ApplyIcons()
                end)
                row:Show()
            end
            for index = #matches + 1, #rows do rows[index]:Hide() end
            empty:SetText(query == "" and "No addon buttons detected." or "No matching addon buttons.")
            empty:SetShown(#matches == 0)
            list:SetHeight(math.max(24, #matches * 24))
        end
        search:SetScript("OnTextChanged", function(self)
            placeholder:SetShown(self:GetText() == "")
            scroll:SetVerticalScroll(0)
            settings.RefreshButtons()
        end)
        search:SetScript("OnEscapePressed", function(self) self:ClearFocus() end)
        search:SetScript("OnEnterPressed", function(self) self:ClearFocus() end)
        Button(settings, "Clear", 57, function()
            search:SetText("")
            search:ClearFocus()
        end):SetPoint("LEFT", search, "RIGHT", 8, 0)
        Button(settings, "Rescan", 69, function()
            Reflow()
            settings.RefreshButtons()
        end):SetPoint("TOPRIGHT", -16, -343)
        local memorial = Label(settings, "GameFontNormalSmall", "RIP Shady")
        memorial:SetPoint("BOTTOM", 0, 12)
        memorial:SetFont("Fonts\\MORPHEUS.TTF", 11)
        memorial:SetTextColor(0.76, 0.61, 0.31)
    end
    Reflow()
    settings.RefreshButtons()
    settings:Show()
end

local function CreateShortcut()
    local button = Button(map, "M", 13, function(_, mouse)
        if IsShiftKeyDown() then return end
        if mouse == "MiddleButton" then
            addon.MapRunner.Toggle()
        elseif mouse == "RightButton" then
            RightClickMap()
        else
            ShowSettings()
        end
    end)
    button:SetFrameLevel(map:GetFrameLevel() + 8)
    button:RegisterForClicks("LeftButtonUp", "RightButtonUp", "MiddleButtonUp")
    button:SetNormalFontObject("GameFontNormalSmall")
    button:SetHighlightFontObject("GameFontHighlightSmall")
    local function Resize()
        button:SetSize(db.shortcutSize, db.shortcutSize)
    end
    Resize()
    PlaceDock(button, "shortcutPosition", "BOTTOMRIGHT", map, "TOPRIGHT", -33, 2)
    MakeMovable(button, "shortcutPosition")
    button:EnableMouseWheel(true)
    button:SetScript("OnMouseWheel", function(_, delta)
        if IsShiftKeyDown() and delta ~= 0 then
            db.shortcutSize = math.max(10, math.min(32, db.shortcutSize + (delta > 0 and 1 or -1)))
            Resize()
        end
    end)
    button:SetScript("OnEnter", function(self)
        if not db.showTooltips then return end
        GameTooltip:SetOwner(self, "ANCHOR_LEFT")
        GameTooltip:SetText("MiniMappin")
        GameTooltip:AddLine("Left-click: Settings")
        GameTooltip:AddLine("Middle-click: Map Runner")
        if db.secondaryMapView == 0 then
            GameTooltip:AddLine("Right-click: Next map view")
        else
            local target = db.mapView == db.secondaryMapView and db.primaryMapView or db.secondaryMapView
            GameTooltip:AddLine("Right-click: " .. mapViews[target])
        end
        GameTooltip:AddLine("Shift-drag: Move")
        GameTooltip:AddLine("Shift-scroll: Resize")
        GameTooltip:Show()
    end)
    button:SetScript("OnLeave", HideOwnedTooltip)
end

local function Initialize()
    local isLoaded = C_AddOns and C_AddOns.IsAddOnLoaded or IsAddOnLoaded
    if isLoaded and isLoaded("Miniminimap") then
        print("MiniMappin: Disable Miniminimap and reload to use MiniMappin.")
        return
    end
    if not Minimap or not Minimap.SetMaskTexture then return end
    map = Minimap
    MiniMappinDB = MiniMappinDB or FrameSquareDB or {}
    FrameSquareDB = nil
    db = MiniMappinDB
    addon.Nav.init()
    db.size, db.x, db.y = db.size or 0, db.x or 0, db.y or 0
    db.borderThickness = math.max(1, math.min(8, math.floor(tonumber(db.borderThickness) or 1)))
    db.resetScale = math.max(0.45, math.min(1.75, tonumber(db.resetScale) or 1))
    db.shortcutSize = math.max(10, math.min(32, math.floor(tonumber(db.shortcutSize) or 13)))
    db.iconOrder = db.iconOrder or {}
    db.iconSlotSize = db.iconSlotSize or {}
    db.mapView = mapViews[db.mapView] and db.mapView or (db.atlasView and 2 or 1)
    db.primaryMapView = mapViews[db.primaryMapView] and db.primaryMapView or db.mapView
    db.secondaryMapView = mapViews[db.secondaryMapView] and db.secondaryMapView or 0
    db.atlasView = nil
    db.sidebarDelay = delayNames[db.sidebarDelay] and db.sidebarDelay or 2
    db.sidebarLocation = sidebarLocations[db.sidebarLocation] and db.sidebarLocation or 1
    db.sidebarHeight = db.sidebarHeight or {}
    db.sidebarHeight[2] = db.sidebarHeight[2] or 0.5
    db.sidebarHeight[3] = db.sidebarHeight[3] or 0.5
    db.mode, db.icons = modes[db.mode] and db.mode or 1, db.icons or {}
    if db.solid == nil then db.solid = true end

    nativeSize = map:GetWidth()
    home = CreateFrame("Frame", nil, map:GetParent())
    home:SetSize(map:GetWidth(), map:GetHeight())
    RestorePoints(home, Points(map))

    -- Draw over the minimap canvas at the bottom of the artwork layer.
    terrainTint = map:CreateTexture(nil, "ARTWORK", nil, -8)
    terrainTint:SetAllPoints(map)
    terrainTint:SetTexture(white)
    terrainTint:SetVertexColor(0.075, 0.085, 0.10, 0.36)
    terrainTint:SetShown(db.mutedTerrain == true)

    atlas = CreateFrame("Frame", nil, map)
    atlas:SetAllPoints(map)
    atlas:EnableMouseWheel(true)
    atlas:SetScript("OnMouseWheel", function() end)
    local nativeWheel = map:GetScript("OnMouseWheel")
    if nativeWheel then
        map:SetScript("OnMouseWheel", function(self, delta)
            if db.mapView == 1 then nativeWheel(self, delta) end
        end)
    end
    atlas:SetFrameLevel(map:GetFrameLevel() + 4)
    atlas.tiles, atlas.questMarkers = {}, {}
    local background = atlas:CreateTexture(nil, "BACKGROUND")
    background:SetAllPoints(atlas)
    background:SetTexture(white)
    background:SetVertexColor(0.04, 0.04, 0.035, 1)
    local player = atlas:CreateTexture(nil, "OVERLAY")
    player:SetTexture(white)
    player:SetVertexColor(1, 0.85, 0.25, 1)
    player:SetSize(7, 7)
    atlas.player = player
    atlas.partyMarkers = {}
    for index = 1, 4 do
        local marker = atlas:CreateTexture(nil, "OVERLAY")
        marker:SetTexture(white)
        marker:SetVertexColor(0.3, 1, 0.4, 1)
        marker:SetSize(6, 6)
        marker:Hide()
        atlas.partyMarkers[index] = marker
    end
    atlas.waypoint = atlas:CreateTexture(nil, "OVERLAY")
    atlas.waypoint:SetTexture(white)
    atlas.waypoint:SetVertexColor(0.25, 0.85, 1, 1)
    atlas.waypoint:SetSize(7, 7)
    atlas.waypoint:SetRotation(math.pi / 4)
    atlas:Hide()

    border = Panel(map)
    ApplyBorder()
    CreateShortcut()

    local sidebarTemplate = BackdropTemplateMixin and "BackdropTemplate" or nil
    if type(SecureHandlerWrapScript) == "function" and type(SecureHandlerSetFrameRef) == "function" then
        sidebarTemplate = sidebarTemplate and sidebarTemplate .. ",SecureHandlerBaseTemplate" or "SecureHandlerBaseTemplate"
        secureSidebarHover = true
    end
    sidebar = CreateFrame("Frame", nil, UIParent, sidebarTemplate)
    sidebar:SetSize(15, 26)
    sidebar:SetFrameStrata("MEDIUM")
    MakeBackdrop(sidebar, 0.95)
    sidebar.arrow = Label(sidebar, "GameFontNormal", "<")
    sidebar.arrow:SetPoint("CENTER")
    sidebar.content = CreateFrame("Frame", nil, sidebar, sidebarTemplate)
    if secureSidebarHover then
        SecureHandlerSetFrameRef(sidebar, "content", sidebar.content)
        sidebar:SetScript("OnEnter", function() end)
        SecureHandlerWrapScript(sidebar, "OnEnter", sidebar, [[
            local content = self:GetFrameRef("content")
            content:UnregisterAutoHide()
            content:Show()
            content:RegisterAutoHide(self:GetAttribute("hoverDelay") or 0.4)
            content:AddToAutoHide(self)
        ]])
    end
    MakeBackdrop(sidebar.content, 0.93)
    PlaceSidebar()
    sidebar:SetMovable(true)
    sidebar:SetClampedToScreen(true)
    sidebar:EnableMouse(true)
    sidebar:RegisterForDrag("LeftButton")
    sidebar:SetScript("OnDragStart", function(self)
        if not InCombat() and db.sidebarLocation ~= 1 and IsShiftKeyDown() then
            movingEdge = db.sidebarLocation
            self:StartMoving()
        end
    end)
    sidebar:SetScript("OnDragStop", function(self)
        if not movingEdge then return end
        self:StopMovingOrSizing()
        local _, y = self:GetCenter()
        local bottom = UIParent:GetBottom()
        local height = UIParent:GetHeight()
        if y and bottom and height > 0 then
            db.sidebarHeight[movingEdge] = math.max(0, math.min(1, (y - bottom) / height))
        end
        movingEdge = nil
        PlaceSidebar()
    end)

    ring = CreateFrame("Frame", nil, UIParent)
    ring:SetFrameStrata("MEDIUM")
    bar = Panel(UIParent)
    bar:SetFrameStrata("MEDIUM")
    MakeBackdrop(bar, 0.93)
    PlaceDock(bar, "barPosition", "TOPRIGHT", map, "TOPLEFT", -15, 0)
    local grip = Panel(bar)
    grip:SetSize(16, 25)
    grip:SetPoint("RIGHT", bar, "LEFT", 0, 0)
    MakeBackdrop(grip, 0.93)
    Label(grip, "GameFontNormal", "::"):SetPoint("CENTER")
    MakeMovable(bar, "barPosition", grip)

    resets = CreateFrame("Button", nil, UIParent, BackdropTemplateMixin and "BackdropTemplate" or nil)
    resets:SetSize(180, 21)
    resets:SetFrameStrata("MEDIUM")
    MakeBackdrop(resets, 0.9)
    PlaceDock(resets, "resetPosition", "BOTTOMRIGHT", map, "BOTTOMLEFT", -16, 0)
    resets.text = Label(resets, "GameFontHighlightSmall", "")
    resets.text:SetPoint("CENTER")
    resets.font, resets.fontSize, resets.fontFlags = resets.text:GetFont()
    MakeMovable(resets, "resetPosition")
    MakeResetResizable()
    resets:RegisterForClicks("LeftButtonUp")
    resets:SetScript("OnEnter", function(self)
        if db.showTooltips then ResetTooltip(self) end
    end)
    resets:SetScript("OnClick", function(self)
        if IsShiftKeyDown() then return end
        if not db.showTooltips and GameTooltip:IsOwned(self) then
            HideOwnedTooltip(self)
            return
        end
        ResetTooltip(self)
        if RequestRaidInfo then RequestRaidInfo() end
    end)
    resets:HookScript("OnHide", HideOwnedTooltip)
    resets:SetScript("OnLeave", HideOwnedTooltip)

    -- LibDBIcon and other addons use this helper to position their own buttons.
    local previousShape = GetMinimapShape
    GetMinimapShape = function(...)
        if map:IsVisible() then return "SQUARE" end
        return previousShape and previousShape(...) or "ROUND"
    end
    if db.resets and RequestRaidInfo then RequestRaidInfo() end
    Reflow()
end

local function ScheduleButtonScan()
    scanAttempt = 1
    scanDelay = scanIntervals[scanAttempt]
end

local function ScanForLateButtons(delta)
    if not scanDelay or InCombat() then return end
    scanDelay = scanDelay - delta
    if scanDelay > 0 then return end

    scanAttempt = scanAttempt + 1
    scanDelay = scanIntervals[scanAttempt]
    if settings and settings:IsShown() then
        DiscoverButtons()
        settings.RefreshButtons()
    end
    if db.mode == 1 then return end
    local attached = {}
    for _, state in pairs(managed) do attached[state.name] = true end
    for name in pairs(db.icons) do
        if not attached[name] then
            local button = _G[name]
            if button and button.IsObjectType and button:IsObjectType("Button") and ButtonName(button) then
                Reflow()
                if settings and settings:IsShown() then settings.RefreshButtons() end
                return
            end
        end
    end
end

SLASH_MINIMAPPIN1 = "/minimappin"
SlashCmdList.MINIMAPPIN = ShowSettings

events:RegisterEvent("ADDON_LOADED")
events:RegisterEvent("PLAYER_LOGIN")
events:RegisterEvent("PLAYER_ENTERING_WORLD")
events:RegisterEvent("PLAYER_REGEN_ENABLED")
events:RegisterEvent("UPDATE_INSTANCE_INFO")
events:SetScript("OnEvent", function(_, event)
    if event == "PLAYER_LOGIN" then
        Initialize()
        if resets then ScheduleButtonScan() end
    elseif map and bar then
        if event == "UPDATE_INSTANCE_INFO" then
            UpdateResets()
            if GameTooltip:IsOwned(resets) then ResetTooltip(resets) end
        elseif event == "ADDON_LOADED" then
            ScheduleButtonScan()
        else
            Reflow()
            ScheduleButtonScan()
        end
    end
end)
events:SetScript("OnUpdate", function(_, delta)
    if not resets then return end
    ScanForLateButtons(delta)
    elapsed = elapsed + delta
    resetElapsed = resetElapsed + delta
    if db.mapView ~= 1 then
        atlasElapsed = atlasElapsed + delta
        if atlasElapsed >= 0.05 then
            atlasElapsed = 0
            KeepAtlasZoom()
            UpdateAtlas()
        end
    end
    if elapsed >= 0.05 then
        elapsed = 0
        if not InCombat() and next(managed) then UpdateManagedAnchors() end
        UpdateHover()
    end
    if resetElapsed >= 15 then
        resetElapsed = 0
        if db.resets then UpdateResets() end
    end
end)
