-- Bagnon Hide 1.0.26 - WoW Forever (Interface 16001)
-- Slot-aware hiding: consumables return when their item leaves; equipment swaps stay hidden.
-- Middle-click casts Disenchant on the hovered live inventory slot.
-- Right-click Show Hidden to edit highlight color / strength; click outside to close.

local ADDON = ...
local mod = CreateFrame('Frame')
local hiddenSlots = {}     -- keyed by "bag:slot"; {itemID = N, equipment = bool}
local legacyItems = {}     -- v1.0.1 per-item-ID hides, converted once
local migrationDone = false
local inWorld = false
local hiddenEquipment = {} -- persistent GUID -> item record, including equipped items
local readyAt = 0
local debugEnabled = false
local stats = {passes = 0, retired = 0, swaps = 0, promoted = 0}
local ItemIsHidden, CheckBags
local pendingRemoval = {}
local confirmTimer
local showHidden = false
local inventory
local checkbox
local attached = false
local labelButton
local dismissLayer
local settingsPopup
local colorSwatch
local intensitySlider
local intensityText
local highlight = {r = 0.73, g = 0.35, b = 1.0, intensity = 95}

local function Clamp(value, low, high)
    return math.max(low, math.min(high, tonumber(value) or low))
end

local questSlots = {}
local hideQuestItems = false

local function UpdateCount()
    if not labelButton or not labelButton.text then return end
    local count = 0
    if inventory and not (inventory.IsCached and inventory:IsCached()) and ItemIsHidden and C_Container and C_Container.GetContainerNumSlots and C_Container.GetContainerItemID then
        for _, bag in ipairs(inventory.Bags or {}) do
            for slot = 1, C_Container.GetContainerNumSlots(bag) or 0 do
                local key = bag .. ':' .. slot
                local id = C_Container.GetContainerItemID(bag, slot)
                if id and questSlots[key] ~= id and ItemIsHidden(bag, slot, id) then count = count + 1 end
            end
        end
    end
    labelButton.text:SetText('Show Hidden (' .. count .. ')')
    labelButton:SetWidth(math.max(88, labelButton.text:GetStringWidth() + 5))
end

local function Print(message)
    DEFAULT_CHAT_FRAME:AddMessage('|cffb988e8Bagnon Hide|r: ' .. tostring(message))
end

local function IsCombat()
    return InCombatLockdown and InCombatLockdown()
end

local function GetItemID(button)
    local info = button and button.info
    if info and type(info.itemID) == 'number' then
        return info.itemID
    end
    if button and button.GetBag and button.GetID and C_Container and C_Container.GetContainerItemID then
        return C_Container.GetContainerItemID(button:GetBag(), button:GetID())
    end
end

-- Bagnon buttons refer to actual bag + slot positions. This is important:
-- hiding a potion must not hide other stacks of that same potion elsewhere.
local function SlotKey(bag, slot)
    if type(bag) ~= 'number' or type(slot) ~= 'number' then return end
    return bag .. ':' .. slot
end

local function IsEquipment(itemID)
    if not itemID or not C_Item or not C_Item.GetItemInfoInstant then return nil end
    -- Forever provides the equipment location as result #4, e.g. INVTYPE_CLOAK.
    local ok, _, _, _, equipLoc = pcall(C_Item.GetItemInfoInstant, itemID)
    if ok and type(equipLoc) == 'string' then return equipLoc ~= '' end
end

local function SlotItemID(bag, slot)
    if not C_Container or not C_Container.GetContainerItemID then return nil, false end
    local ok, itemID = pcall(C_Container.GetContainerItemID, bag, slot)
    if not ok then return nil, false end
    return itemID, true
end

-- Classify by item class so ordinary materials used by objectives stay visible.
local function UpdateQuestSlots()
    local slots = {}
    if hideQuestItems and inventory and C_Item and C_Item.GetItemInfoInstant then
        for _, bag in ipairs(inventory.Bags or {}) do
            local size = C_Container.GetContainerNumSlots(bag) or 0
            for slot = 1, size do
                local id = SlotItemID(bag, slot)
                if id and select(6, C_Item.GetItemInfoInstant(id)) == ((Enum and Enum.ItemClass and Enum.ItemClass.Questitem) or 12) then
                    slots[SlotKey(bag, slot)] = id
                end
            end
        end
    end
    local changed = false
    for k,v in pairs(slots) do if questSlots[k] ~= v then changed = true; break end end
    if not changed then
        for k in pairs(questSlots) do if not slots[k] then changed = true; break end end
    end
    questSlots = slots
    UpdateCount()
    return changed
end

local function SafeGUID(locationFactory, ...)
    if not locationFactory or not C_Item or not C_Item.GetItemGUID then return end
    local ok, location = pcall(locationFactory, ItemLocation, ...)
    if not ok or not location then return end
    local readable, guid = pcall(C_Item.GetItemGUID, location)
    if readable and type(guid) == 'string' and guid ~= '' then return guid end
end

local function SlotGUID(bag, slot)
    return SafeGUID(ItemLocation and ItemLocation.CreateFromBagAndSlot, bag, slot)
end

local function Debug(message)
    if debugEnabled then Print(message) end
end

local worn, transitions, recentlyRemoved = {}, {}, {}
local function TrackEquipment(slot, initialize)
    local id = GetInventoryItemID('player', slot)
    local guid = id and SafeGUID(ItemLocation and ItemLocation.CreateFromEquipmentSlot, slot)
    local old = worn[slot]
    -- Do not overwrite a known identity on a transient GUID read failure.
    if id and not guid then return end
    if not initialize then
        if old and not id then
            recentlyRemoved[slot] = {item = old, time = GetTime()}
        elseif guid then
            local recent = recentlyRemoved[slot]
            if not old and recent and GetTime() - recent.time <= 2 then old = recent.item end
            recentlyRemoved[slot] = nil
            if old and old.guid ~= guid then
                transitions[#transitions + 1] = {old = old, id = id, guid = guid, time = GetTime()}
            end
        end
    end
    worn[slot] = id and guid and {id = id, guid = guid} or nil
end

local function ResolveSwaps()
    -- Resolve in event order so rapid verified equipment exchanges can chain.
    local remaining = {}
    local changed = false
    for _, swap in ipairs(transitions) do
        local incoming = hiddenEquipment[swap.guid]
        if incoming and incoming.itemID == swap.id then
            if not hiddenEquipment[swap.old.guid] then
                hiddenEquipment[swap.old.guid] = {itemID = swap.old.id, equipment = true, guid = swap.old.guid}
                stats.swaps = stats.swaps + 1
                changed = true
                Debug('Preserved hidden equipment exchange: ' .. swap.old.id .. ' / ' .. swap.id)
            end
        elseif GetTime() - swap.time < 10 then
            remaining[#remaining + 1] = swap
        end
    end
    transitions = remaining
    return changed
end

ItemIsHidden = function(bag, slot, itemID)
    if not itemID then return false end
    local key = SlotKey(bag, slot)
    if not key then return false end
    -- Bagnon may still be holding the previous slot contents during an update.
    local live, readable = SlotItemID(bag, slot)
    if not readable or live ~= itemID then return false end
    local guid = SlotGUID(bag, slot)
    local identity = guid and hiddenEquipment[guid]
    if identity and identity.itemID == itemID then return true end
    local record = hiddenSlots[key]
    if type(record) ~= 'table' or record.itemID ~= itemID then return false end
    if record.guid then return guid == record.guid end
    -- Legacy equipment without an available GUID is slot-scoped only.
    return true
end

local function ApplyMark(button)
    if not button or not button.BagnonHideMark then return end
    local key = SlotKey(button:GetBag(), button:GetID())
    local id = GetItemID(button)
    button.BagnonHideMark:SetVertexColor(highlight.r, highlight.g, highlight.b, highlight.intensity / 100)
    button.BagnonHideMark:SetShown(showHidden and id and
        questSlots[key] ~= id and ItemIsHidden(button:GetBag(), button:GetID(), id) and true or false)
end

-- Known equipment identities never expire because of a bag-slot mismatch.
-- Consumables retain their existing slot-specific semantics, but only retire
-- after a quiet interval and after world-entry inventory initialization.
local function SyncHiddenSlots(confirm)
    if not inWorld or not C_Container or not C_Container.GetContainerNumSlots then return false end
    stats.passes = stats.passes + 1
    local changed = false
    for key, record in pairs(hiddenSlots) do
        local bag, slot
        if type(key) == 'string' then bag, slot = key:match('^(%-?%d+):(%d+)$') end
        bag, slot = tonumber(bag), tonumber(slot)
        local candidate
        if bag and slot and type(record) == 'table' then
            if record.equipment == nil then record.equipment = IsEquipment(record.itemID) end
            local ok, size = pcall(C_Container.GetContainerNumSlots, bag)
            local id, readable
            if ok and type(size) == 'number' and slot >= 1 and slot <= size then
                id, readable = SlotItemID(bag, slot)
            end
            if record.equipment then
                local guid = record.guid
                if not guid and readable and id == record.itemID and GetTime() >= readyAt then
                    guid = SlotGUID(bag, slot)
                end
                if guid then
                    if not hiddenEquipment[guid] then
                        hiddenEquipment[guid] = {itemID = record.itemID, equipment = true, guid = guid}
                        stats.promoted = stats.promoted + 1
                    end
                    hiddenSlots[key] = nil
                    changed = true
                end
                -- Unresolved legacy equipment is retained, never guessed across slots.
            elseif record.equipment == false and readable and id ~= record.itemID then
                candidate = id or 0
                if confirm and GetTime() >= readyAt and pendingRemoval[key] == candidate then
                    hiddenSlots[key] = nil
                    stats.retired = stats.retired + 1
                    Debug('Retired departed stack at ' .. key)
                    candidate = nil
                    changed = true
                end
            end
        end
        pendingRemoval[key] = candidate
    end
    for slot = 1, 19 do TrackEquipment(slot) end
    if ResolveSwaps() then changed = true end
    UpdateCount()
    return changed
end

-- Convert existing v1.0.1 item-ID hides to position-based hides without asking
-- the user to re-hide all of the items that are currently in their inventory.
local function MigrateLegacyItems()
    if migrationDone or not inWorld or GetTime() < readyAt or not inventory or not C_Container or
       not C_Container.GetContainerNumSlots then return end
    if inventory.IsCached and inventory:IsCached() then return end
    local bags = inventory.Bags
    if type(bags) ~= 'table' then return end
    local scanned = false
    for _, bag in ipairs(bags) do
        if type(bag) == 'number' then
            local ok, size = pcall(C_Container.GetContainerNumSlots, bag)
            if ok and type(size) == 'number' and size > 0 then
                scanned = true
                for slot = 1, size do
                    local itemID, readable = SlotItemID(bag, slot)
                    if readable and itemID and legacyItems[itemID] then
                        local key = SlotKey(bag, slot)
                        if key and not hiddenSlots[key] then
                            hiddenSlots[key] = {itemID = itemID, equipment = IsEquipment(itemID)}
                        end
                    end
                end
            end
        end
    end
    if scanned then
        BagnonHideDB.items = {} -- the old list is no longer used after conversion
        legacyItems = BagnonHideDB.items
        BagnonHideDB.schemaVersion = 2
        migrationDone = true
        UpdateCount()
    end
end

-- Bagnon uses class tables as the initial BagGroup / ItemGroup fields.
-- Only a widget stored directly on the inventory frame is a live UI object.
-- Poncho/Blizzard frames expose [0]; a class table does not.
local function GetLiveWidget(key)
    if not inventory then return end
    local widget = rawget(inventory, key)
    if widget and widget[0] then
        return widget
    end
end

local function Refresh(userRequested)
    if IsCombat() then return end
    if not inventory or (inventory.IsCached and inventory:IsCached()) then return end
    local group = GetLiveWidget('ItemGroup')
    if group and group.Layout then
        group:Layout() -- native Bagnon filtering / grid reflow
    end
end

-- Debounce inventory bursts and always repaint once Bagnon settles, including
-- equipment-only changes and bags opened after a closed-bag inventory update.
CheckBags = function()
    if not inWorld then return end
    if confirmTimer then confirmTimer:Cancel() end
    confirmTimer = nil
    SyncHiddenSlots(false)
    local delay = math.max(2, readyAt - GetTime() + 0.1)
    confirmTimer = C_Timer.NewTimer(delay, function()
        confirmTimer = nil
        if not inWorld then return end
        MigrateLegacyItems()
        SyncHiddenSlots(true)
        if hideQuestItems then UpdateQuestSlots() end
        Refresh()
    end)
end

-- Capture only the mouse button needed for the current modifier.
local disenchant = CreateFrame('Button', 'BagnonHideDisenchant', UIParent,
    'SecureActionButtonTemplate,SecureHandlerStateTemplate')
disenchant:Hide()
disenchant:SetFrameStrata('TOOLTIP')
disenchant:SetMouseMotionEnabled(false)
disenchant:RegisterForClicks('MiddleButtonDown', 'MiddleButtonUp', 'LeftButtonUp')
disenchant:SetAttribute('spell', 13262)
disenchant:SetAttribute('_onstate-combat', [[
    if newstate == 'combat' then self:Hide() end
]])
RegisterStateDriver(disenchant, 'combat', '[combat] combat; idle')

local targetButton, targetItem
local function TargetItem(button)
    if not button or not button:IsVisible() or not button:IsMouseOver() then return end
    if not inventory or not inventory:IsVisible() or (inventory.IsCached and inventory:IsCached()) then return end
    local bag, slot = button:GetBag(), button:GetID()
    if not SlotKey(bag, slot) then return end
    local id = SlotItemID(bag, slot)
    if id and id == GetItemID(button) then return id, bag, slot end
end

local function ClearTarget()
    if IsCombat() then return end
    targetButton, targetItem = nil, nil
    disenchant:Hide()
    disenchant:SetAttribute('type3', nil)
end

local function PrepareTarget(button)
    if IsCombat() then return end
    if IsAltKeyDown() and not IsShiftKeyDown() then ClearTarget() return end
    local id, bag, slot = TargetItem(button)
    if not id then ClearTarget() return end
    -- Keep the secure action button independent of Bagnon's frame tree.
    -- Copy the slot's rectangle in UIParent coordinates while out of combat.
    local left, bottom, width, height = button:GetRect()
    if not left or not bottom or not width or not height then ClearTarget() return end
    local scale = button:GetEffectiveScale() / UIParent:GetEffectiveScale()
    disenchant:ClearAllPoints()
    disenchant:SetPoint('BOTTOMLEFT', UIParent, 'BOTTOMLEFT', left * scale, bottom * scale)
    disenchant:SetSize(width * scale, height * scale)
    targetButton, targetItem = button, id
    disenchant:SetAttribute('target-bag', bag)
    disenchant:SetAttribute('target-slot', slot)
    if IsShiftKeyDown() then
        disenchant:SetPassThroughButtons('MiddleButton', 'RightButton', 'Button4', 'Button5')
        disenchant:SetAttribute('type3', nil)
    else
        disenchant:SetPassThroughButtons('LeftButton', 'RightButton', 'Button4', 'Button5')
        disenchant:SetAttribute('type3', 'spell')
    end
    disenchant:Show()
end

-- Resolve only a hooked button in the current live inventory. Never walk
-- forbidden Blizzard frames (for example the world ping listener).
local function ResolveMouseItem()
    local group = GetLiveWidget('ItemGroup')
    if not group or not group.buttons then return end
    local focus
    if GetMouseFoci then
        local foci = GetMouseFoci()
        focus = foci and foci[1]
    elseif GetMouseFocus then
        focus = GetMouseFocus()
    end
    for depth = 1, 32 do
        if not focus or (focus.IsForbidden and focus:IsForbidden()) then return end
        for _, button in ipairs(group.buttons) do
            if focus == button and button.BagnonHideHooked then return button end
        end
        if focus == inventory or focus == UIParent or not focus.GetParent then return end
        focus = focus:GetParent()
    end
end

-- Shift can be pressed after the mouse has already entered the item.
local function UpdateMouseTarget()
    if IsCombat() then return end
    if not inventory or not inventory:IsVisible() or (inventory.IsCached and inventory:IsCached()) then
        ClearTarget()
        return
    end
    -- Some client frames can reject even property reads. Fail closed without
    -- changing protected frames or attempting to bypass their restrictions.
    local ok, button = pcall(ResolveMouseItem)
    if ok and button and TargetItem(button) then PrepareTarget(button) return end
    ClearTarget()
end

disenchant:SetScript('PreClick', function(self)
    if IsCombat() then return end
    local id, bag, slot = TargetItem(targetButton)
    if not id or id ~= targetItem or bag ~= self:GetAttribute('target-bag')
        or slot ~= self:GetAttribute('target-slot') or IsShiftKeyDown()
        or IsAltKeyDown() or IsControlKeyDown()
        or (GetCursorInfo and GetCursorInfo()) or (SpellIsTargeting and SpellIsTargeting()) then
        self:SetAttribute('type3', nil)
    else
        self:SetAttribute('type3', 'spell')
    end
end)

local function DeleteAvailable()
    return not IsCombat() and inventory and inventory:IsVisible()
        and not (inventory.IsCached and inventory:IsCached())
        and not GetCursorInfo() and not (SpellIsTargeting and SpellIsTargeting())
end



local function ActiveChatInput()
    local box = ChatFrameUtil and ChatFrameUtil.GetActiveWindow and ChatFrameUtil.GetActiveWindow()
    if not box and ChatEdit_GetActiveWindow then box = ChatEdit_GetActiveWindow() end
    if box and box:IsVisible() and box:HasFocus() then return box end

    -- Check docked and floating inputs when the active-window lookup misses the focused box.
    for i = 1, NUM_CHAT_WINDOWS or 0 do
        box = _G['ChatFrame' .. i .. 'EditBox']
        if box and box:IsVisible() and box:HasFocus() then return box end
    end
end

StaticPopupDialogs.BAGNONHIDE_DELETE_SLOT = {
    text = 'Delete %s?',
    button1 = DELETE or 'Delete',
    button2 = CANCEL or 'Cancel',
    timeout = 0,
    whileDead = false,
    hideOnEscape = true,
    OnAccept = function(_, request)
        if not request or ActiveChatInput() or not DeleteAvailable() then return end
        local live = C_Container.GetContainerItemInfo(request.bag, request.slot)
        if not live or live.isLocked or live.itemID ~= request.id
            or live.stackCount ~= request.count or live.hyperlink ~= request.link
            or (request.guid and SlotGUID(request.bag, request.slot) ~= request.guid) then
            Print('That stack changed. Shift-left-click it again to delete it.')
            return
        end
        C_Container.PickupContainerItem(request.bag, request.slot)
        local kind, id = GetCursorInfo()
        if kind == 'item' and id == request.id then
            DeleteCursorItem()
        elseif kind == 'item' then
            ClearCursor()
        end
    end,
}

disenchant:HookScript('PostClick', function(self, mouseButton, down)
    if mouseButton ~= 'LeftButton' or down or not IsShiftKeyDown()
        or IsAltKeyDown() or IsControlKeyDown() or not DeleteAvailable() then return end
    local id, bag, slot = TargetItem(targetButton)
    if not id or id ~= targetItem or bag ~= self:GetAttribute('target-bag')
        or slot ~= self:GetAttribute('target-slot') then return end
    local live = C_Container.GetContainerItemInfo(bag, slot)
    if not live or live.itemID ~= id or not live.hyperlink then return end
    local chat = ActiveChatInput()
    if chat then
        chat:Insert(live.hyperlink)
        return
    end
    if live.isLocked or not live.stackCount or live.stackCount < 1 then return end
    local shady = _G.ShadyPriceAPI
    if shady and type(shady.TrySearchItem) == 'function' and shady.TrySearchItem(live.hyperlink) then
        return
    end
    local request = {bag = bag, slot = slot, id = id, count = live.stackCount,
        link = live.hyperlink, guid = SlotGUID(bag, slot)}
    StaticPopup_Show('BAGNONHIDE_DELETE_SLOT', live.hyperlink .. ' x' .. live.stackCount, nil, request)
end)

local function LeaveItem(button)
    if targetButton == button then ClearTarget() end
end

local function SetSlotHidden(bag, slot, id, hide)
    local key = SlotKey(bag, slot)
    if not key or SlotItemID(bag, slot) ~= id then return end
    local guid = SlotGUID(bag, slot)
    local existing = hiddenSlots[key]
    if hide then
        -- A new manual hide must not retroactively classify an earlier swap.
        for i = #transitions, 1, -1 do
            if guid and transitions[i].guid == guid then table.remove(transitions, i) end
        end
        local equipment = IsEquipment(id)
        if equipment and guid then
            hiddenEquipment[guid] = {itemID = id, equipment = true, guid = guid}
            -- Do not erase an unrelated unresolved legacy record on this slot.
            if existing and existing.itemID == id then hiddenSlots[key] = nil end
        else
            hiddenSlots[key] = {itemID = id, equipment = equipment}
        end
    else
        if guid then hiddenEquipment[guid] = nil end
        if existing and existing.itemID == id and (not existing.guid or existing.guid == guid) then
            hiddenSlots[key] = nil
        end
        -- Explicit unhide wins over a pending automatic exchange for this item.
        for i = #transitions, 1, -1 do
            if guid and transitions[i].old.guid == guid then table.remove(transitions, i) end
        end
    end
    pendingRemoval[key] = nil
end

local SetItemTracking
local function ItemMiddleMouse(button, mouseButton)
    if mouseButton ~= 'MiddleButton' or not inventory then return end
    if inventory.IsCached and inventory:IsCached() then
        return -- do not change hidden list while browsing another character
    end
    if CursorHasItem and CursorHasItem() then return end
    if IsAltKeyDown() and not IsShiftKeyDown() and not IsControlKeyDown() then
        local id = TargetItem(button)
        if id then SetItemTracking('track', id) end
        return
    end
    if not IsShiftKeyDown() then return end
    local bag, slot, id = button:GetBag(), button:GetID(), GetItemID(button)
    if not SlotKey(bag, slot) or not id or id <= 0 then return end
    SetSlotHidden(bag, slot, id, not ItemIsHidden(bag, slot, id))
    UpdateCount()
    Refresh(true)
end

-- Stack-only changes can arrive without a layout change. Read the quantity
-- from this physical slot, even when another stack has the same item ID.
local function SyncStackLabel(button)
    local overlay = button.BagnonHideQuantity
    local info = button.info
    local count
    if info and info.itemID and inventory and inventory:IsVisible() and button:IsVisible()
        and not (inventory.IsCached and inventory:IsCached()) then
        local live = C_Container.GetContainerItemInfo(button:GetBag(), button:GetID())
        if live and live.itemID == info.itemID then count = live.stackCount end
    end
    if type(count) ~= 'number' or count <= 1 then
        if overlay then
            overlay:Hide()
            if overlay.native and overlay.oldAlpha ~= nil then
                overlay.native:SetAlpha(overlay.oldAlpha)
                overlay.oldAlpha = nil
            end
        end
        return
    end

    if not overlay then
        overlay = CreateFrame('Frame', nil, button)
        overlay:SetAllPoints(button)
        overlay:SetFrameLevel(button:GetFrameLevel() + 5)
        overlay:EnableMouse(false)
        local native = button.Count or (button:GetName() and _G[button:GetName() .. 'Count'])
        overlay.native = native
        local label = overlay:CreateFontString(nil, 'OVERLAY', 'NumberFontNormal')
        label:SetPoint('BOTTOMRIGHT', button, 'BOTTOMRIGHT', -1, 1)
        if native and native.GetFont then
            local font, size, flags = native:GetFont()
            if font then label:SetFont(font, size, flags) end
        end
        overlay.label = label
        button.BagnonHideQuantity = overlay
    end
    if overlay.native and overlay.oldAlpha == nil then
        overlay.oldAlpha = overlay.native:GetAlpha()
        overlay.native:SetAlpha(0)
    end
    overlay.label:SetText(count)
    overlay:Show()
end

-- Reloading with existing items may produce no later bag event. Re-read the
-- displayed physical slots once the first layout and its skin updates settle.
local verificationPending = false
local function QueueCountVerification()
    if verificationPending then return end
    verificationPending = true
    C_Timer.After(0.5, function()
        verificationPending = false
        local group = GetLiveWidget('ItemGroup')
        if inventory and inventory:IsVisible() and group and group.buttons then
            for _, button in ipairs(group.buttons) do
                SyncStackLabel(button)
            end
        end
    end)
end

-- Let Bagnon finish its own bag-update batch before using the same layout
-- path as Show Hidden. This binds newly filled slots before repainting counts.
local stackRefreshPending = false
local function QueueStackRefresh()
    if stackRefreshPending or not inventory or not inventory:IsVisible() then return end
    stackRefreshPending = true
    C_Timer.After(0.15, function()
        stackRefreshPending = false
        if not inventory or not inventory:IsVisible() or (inventory.IsCached and inventory:IsCached()) then return end
        Refresh() -- combat is deferred to the existing PLAYER_REGEN_ENABLED refresh
    end)
end

local function HookItem(button)
    if not button or button.BagnonHideHooked then return end
    if not button.GetID or not button.GetBag then return end
    button.BagnonHideHooked = true

    local mark = button:CreateTexture(nil, 'OVERLAY', nil, 7)
    mark:SetTexture('Interface/Buttons/UI-ActionButton-Border')
    mark:SetBlendMode('ADD')
    mark:SetVertexColor(highlight.r, highlight.g, highlight.b, highlight.intensity / 100)
    mark:SetPoint('CENTER', button, 'CENTER', 0, 0)
    mark:SetSize(59, 59)
    mark:Hide()
    button.BagnonHideMark = mark

    -- OnMouseUp observes middle-clicks without replacing Bagnon's secure click script,
    -- so regular left/right clicks, modifiers and dragging remain untouched.
    button:HookScript('OnMouseUp', ItemMiddleMouse)
    button:HookScript('OnEnter', PrepareTarget)
    button:HookScript('OnLeave', LeaveItem)
    button:HookScript('OnHide', LeaveItem)
    if button.Update then
        hooksecurefunc(button, 'Update', function(self)
            ApplyMark(self)
            SyncStackLabel(self)
        end)
    end
end

local function UpdateDisplayedButtons(group)
    if group and group.buttons then
        for _, button in ipairs(group.buttons) do
            HookItem(button)
            ApplyMark(button)
            if button.BagnonHideHooked then SyncStackLabel(button) end
        end
    end
end

local function AttachGroup()
    local group = GetLiveWidget('ItemGroup')
    if not group then return end
    if not group.BagnonHideGroupHooked then
        group.BagnonHideGroupHooked = true
        if group.Layout then
            hooksecurefunc(group, 'Layout', function(self)
                UpdateDisplayedButtons(self)
                QueueCountVerification()
            end)
        end
    end
    UpdateDisplayedButtons(group)
    QueueCountVerification()
end

local function FindKeyringButton()
    if not KEYRING_CONTAINER then return end
    local group = GetLiveWidget('BagGroup')
    if not group then return end
    for _, child in ipairs({group:GetChildren()}) do
        if child.GetID and child:GetID() == KEYRING_CONTAINER then
            return child
        end
    end
end

local function RefreshHighlightMarks()
    local group = GetLiveWidget('ItemGroup')
    if not group or not group.buttons then return end
    for _, button in ipairs(group.buttons) do
        ApplyMark(button)
    end
end

local function SaveHighlight()
    if not BagnonHideDB then return end
    BagnonHideDB.highlight = {
        r = highlight.r, g = highlight.g, b = highlight.b,
        intensity = highlight.intensity
    }
    if colorSwatch and colorSwatch.texture then
        colorSwatch.texture:SetColorTexture(highlight.r, highlight.g, highlight.b, 1)
    end
    if intensityText then
        intensityText:SetText('Intensity: ' .. highlight.intensity .. '%')
    end
    RefreshHighlightMarks()
end

local function OpenColorPicker()
    if not ColorPickerFrame then return end
    local old = {r = highlight.r, g = highlight.g, b = highlight.b}
    if dismissLayer then dismissLayer:Hide() end

    local function Changed()
        local r, g, b = ColorPickerFrame:GetColorRGB()
        highlight.r, highlight.g, highlight.b = r, g, b
        SaveHighlight()
    end
    local function Cancel(previous)
        -- Retail-style pickers pass a color table. Older Classic clients
        -- use either a numerical tuple or their saved previousValues.
        if type(previous) == 'table' then
            highlight.r = previous.r or previous[1] or old.r
            highlight.g = previous.g or previous[2] or old.g
            highlight.b = previous.b or previous[3] or old.b
        else
            highlight.r, highlight.g, highlight.b = old.r, old.g, old.b
        end
        SaveHighlight()
    end

    if ColorPickerFrame.SetupColorPickerAndShow then
        ColorPickerFrame:SetupColorPickerAndShow({
            r = old.r, g = old.g, b = old.b,
            hasOpacity = false,
            swatchFunc = Changed, cancelFunc = Cancel,
        })
    else
        -- Compatible fallback for earlier Classic color picker API.
        ColorPickerFrame:Hide()
        ColorPickerFrame.func = Changed
        ColorPickerFrame.swatchFunc = Changed
        ColorPickerFrame.cancelFunc = Cancel
        ColorPickerFrame.hasOpacity = false
        ColorPickerFrame.opacityFunc = nil
        ColorPickerFrame.previousValues = {old.r, old.g, old.b}
        ColorPickerFrame:SetColorRGB(old.r, old.g, old.b)
        ColorPickerFrame:Show()
    end
end

local function AddBorder(panel)
    local bg = panel:CreateTexture(nil, 'BACKGROUND')
    bg:SetAllPoints(panel)
    bg:SetColorTexture(0.055, 0.045, 0.075, 0.97)
    for _, edge in ipairs({'TOP', 'BOTTOM', 'LEFT', 'RIGHT'}) do
        local t = panel:CreateTexture(nil, 'BORDER')
        t:SetColorTexture(0.55, 0.42, 0.68, 1)
        if edge == 'TOP' then
            t:SetPoint('TOPLEFT'); t:SetPoint('TOPRIGHT'); t:SetHeight(1)
        elseif edge == 'BOTTOM' then
            t:SetPoint('BOTTOMLEFT'); t:SetPoint('BOTTOMRIGHT'); t:SetHeight(1)
        elseif edge == 'LEFT' then
            t:SetPoint('TOPLEFT'); t:SetPoint('BOTTOMLEFT'); t:SetWidth(1)
        else
            t:SetPoint('TOPRIGHT'); t:SetPoint('BOTTOMRIGHT'); t:SetWidth(1)
        end
    end
end

local function EnsureSettingsPopup()
    if dismissLayer then return end

    -- A transparent click-catcher allows a single outside click anywhere
    -- on the screen to dismiss the menu, including over other UI frames.
    dismissLayer = CreateFrame('Button', 'BagnonHideOutsideClick', UIParent)
    dismissLayer:SetAllPoints(UIParent)
    dismissLayer:SetFrameStrata('FULLSCREEN_DIALOG')
    dismissLayer:SetFrameLevel(20)
    dismissLayer:EnableMouse(true)
    dismissLayer:SetScript('OnMouseDown', function(self) self:Hide() end)
    dismissLayer:Hide()

    settingsPopup = CreateFrame('Frame', 'BagnonHideHighlightOptions', dismissLayer)
    settingsPopup:SetSize(235, 121)
    settingsPopup:SetFrameLevel(dismissLayer:GetFrameLevel() + 2)
    settingsPopup:EnableMouse(true)
    settingsPopup:SetClampedToScreen(true)
    AddBorder(settingsPopup)

    local title = settingsPopup:CreateFontString(nil, 'OVERLAY', 'GameFontNormal')
    title:SetPoint('TOPLEFT', settingsPopup, 'TOPLEFT', 13, -12)
    title:SetText('Hidden item highlight')

    local colorLabel = settingsPopup:CreateFontString(nil, 'OVERLAY', 'GameFontHighlightSmall')
    colorLabel:SetPoint('TOPLEFT', title, 'BOTTOMLEFT', 1, -16)
    colorLabel:SetText('Color')

    colorSwatch = CreateFrame('Button', nil, settingsPopup)
    colorSwatch:SetSize(38, 20)
    colorSwatch:SetPoint('LEFT', colorLabel, 'RIGHT', 16, 0)
    colorSwatch.texture = colorSwatch:CreateTexture(nil, 'ARTWORK')
    colorSwatch.texture:SetPoint('TOPLEFT', 2, -2)
    colorSwatch.texture:SetPoint('BOTTOMRIGHT', -2, 2)
    colorSwatch.texture:SetColorTexture(highlight.r, highlight.g, highlight.b, 1)
    local swatchBorder = colorSwatch:CreateTexture(nil, 'OVERLAY')
    swatchBorder:SetAllPoints(colorSwatch)
    swatchBorder:SetTexture('Interface/Buttons/UI-Quickslot2')
    colorSwatch:SetHighlightTexture('Interface/Buttons/ButtonHilight-Square', 'ADD')
    colorSwatch:SetScript('OnClick', OpenColorPicker)

    intensityText = settingsPopup:CreateFontString(nil, 'OVERLAY', 'GameFontHighlightSmall')
    intensityText:SetPoint('TOPLEFT', colorLabel, 'BOTTOMLEFT', 0, -14)
    intensityText:SetText('Intensity: ' .. highlight.intensity .. '%')

    intensitySlider = CreateFrame('Slider', 'BagnonHideIntensity', settingsPopup, 'OptionsSliderTemplate')
    intensitySlider:SetSize(185, 16)
    intensitySlider:SetPoint('TOPLEFT', intensityText, 'BOTTOMLEFT', 5, -10)
    intensitySlider:SetMinMaxValues(0, 100)
    intensitySlider:SetValueStep(5)
    intensitySlider:SetValue(highlight.intensity)
    intensitySlider:SetScript('OnValueChanged', function(self, value)
        local nextValue = Clamp(math.floor(value / 5 + 0.5) * 5, 0, 100)
        if highlight.intensity ~= nextValue then
            highlight.intensity = nextValue
            SaveHighlight()
        end
    end)

    dismissLayer:SetScript('OnHide', function()
        if settingsPopup then settingsPopup:Hide() end
    end)
end

local function ToggleSettings()
    EnsureSettingsPopup()
    if dismissLayer:IsShown() then
        dismissLayer:Hide()
        return
    end
    if IsCombat() then
        Print('Highlight settings are unavailable during combat.')
        return
    end
    settingsPopup:ClearAllPoints()
    settingsPopup:SetPoint('TOPLEFT', checkbox, 'BOTTOMLEFT', 0, -6)
    settingsPopup:Show()
    dismissLayer:Show()
end

local function PositionCheckbox()
    if not checkbox or not inventory then return end
    checkbox:ClearAllPoints()
    local keyring = FindKeyringButton()
    if keyring and keyring:IsShown() then
        checkbox:SetPoint('LEFT', keyring, 'RIGHT', 7, 9)
    else
        local bagGroup = GetLiveWidget('BagGroup')
        if bagGroup and bagGroup:IsShown() then
            checkbox:SetPoint('LEFT', bagGroup, 'RIGHT', 7, 9)
        else
            checkbox:SetPoint('TOPRIGHT', inventory, 'TOPRIGHT', -128, -22)
        end
    end
end

local function EnsureCheckbox()
    if checkbox or not inventory then return end
    checkbox = CreateFrame('CheckButton', 'BagnonHideShowAllCheck', inventory, 'UICheckButtonTemplate')
    checkbox:SetSize(19, 19)
    checkbox:SetFrameStrata(inventory:GetFrameStrata())
    checkbox:SetFrameLevel(inventory:GetFrameLevel() + 12)
    checkbox:SetChecked(showHidden)
    checkbox:RegisterForClicks('LeftButtonUp', 'RightButtonUp')

    -- A clickable text label makes right-click work on either the check box
    -- or the words/hidden count, with no additional settings gear needed.
    labelButton = CreateFrame('Button', nil, inventory)
    labelButton:SetSize(100, 18)
    labelButton:SetPoint('LEFT', checkbox, 'RIGHT', 2, 0)
    labelButton:SetFrameLevel(checkbox:GetFrameLevel())
    labelButton:RegisterForClicks('LeftButtonUp', 'RightButtonUp')
    labelButton.text = labelButton:CreateFontString(nil, 'OVERLAY', 'GameFontNormalSmall')
    labelButton.text:SetPoint('LEFT', labelButton, 'LEFT', 0, 0)
    labelButton.text:SetJustifyH('LEFT')
    labelButton.text:SetTextColor(0.95, 0.85, 1)
    UpdateCount()

    local quest = CreateFrame('CheckButton', nil, inventory, 'UICheckButtonTemplate')
    quest:SetSize(19, 19)
    quest:SetPoint('TOPLEFT', checkbox, 'BOTTOMLEFT', 0, 1)
    quest:SetFrameLevel(checkbox:GetFrameLevel())
    quest:SetChecked(hideQuestItems)
    local caption = quest:CreateFontString(nil, 'OVERLAY', 'GameFontNormalSmall')
    caption:SetPoint('LEFT', quest, 'RIGHT', 2, 0)
    caption:SetText('Hide Quest Items')
    caption:SetTextColor(0.95, 0.85, 1)
    quest:SetHitRectInsets(0, -caption:GetStringWidth() - 3, 0, 0)
    quest:SetScript('OnClick', function(self)
        hideQuestItems = self:GetChecked() and true or false
        BagnonHideDB.hideQuestItems = hideQuestItems
        UpdateQuestSlots()
        Refresh(true)
    end)

    local function ToggleShowHidden()
        showHidden = not showHidden
        checkbox:SetChecked(showHidden)
        Refresh(true)
    end
    local function HandleClick(_, mouseButton)
        if mouseButton == 'RightButton' then
            -- CheckButton templates may toggle on a right-click; keep the value.
            checkbox:SetChecked(showHidden)
            ToggleSettings()
        else
            ToggleShowHidden()
        end
    end
    checkbox:SetScript('OnClick', HandleClick)
    labelButton:SetScript('OnClick', HandleClick)

    local function TooltipOnEnter(self)
        GameTooltip:SetOwner(self, 'ANCHOR_RIGHT')
        GameTooltip:SetText('Show Hidden', 1, 1, 1)
        GameTooltip:AddLine('Show manually hidden items. Hide Quest Items takes priority.', 0.8, 0.8, 0.8, true)
        GameTooltip:AddLine('Right-click: highlight color and intensity.', 0.8, 0.8, 0.8, true)
        GameTooltip:AddLine('Shift-left-click: link in open chat, search in open Shady Search, or confirm deletion.', 0.8, 0.8, 0.8, true)
        GameTooltip:AddLine('Alt-middle-click an item to track its bag count.', 0.8, 0.8, 0.8, true)
        GameTooltip:AddLine('Middle-click an item to disenchant it.', 0.8, 0.8, 0.8, true)
        GameTooltip:AddLine('Shift-middle-click an item to hide or unhide it.', 0.8, 0.8, 0.8, true)
        GameTooltip:Show()
    end
    checkbox:SetScript('OnEnter', TooltipOnEnter)
    labelButton:SetScript('OnEnter', TooltipOnEnter)
    checkbox:SetScript('OnLeave', function() GameTooltip:Hide() end)
    labelButton:SetScript('OnLeave', function() GameTooltip:Hide() end)
    PositionCheckbox()
end

local trackedItems = {}
local function ToggleTrackedItem(id)
    local matches = {}
    local hide = true
    for _, bag in ipairs(inventory.Bags or {}) do
        for slot = 1, C_Container.GetContainerNumSlots(bag) or 0 do
            if SlotItemID(bag, slot) == id then
                matches[#matches + 1] = {bag = bag, slot = slot}
                if ItemIsHidden(bag, slot, id) then hide = false end
            end
        end
    end
    if #matches == 0 then return end
    for _, match in ipairs(matches) do
        SetSlotHidden(match.bag, match.slot, id, hide)
    end
    UpdateCount()
    Refresh(true)
end

-- Keep the protected item action independent of the inventory's layout and visibility.
local useButton = CreateFrame('Button', nil, UIParent, 'SecureActionButtonTemplate,SecureHandlerStateTemplate')
useButton:Hide()
useButton:SetFrameStrata('TOOLTIP')
useButton:SetMouseMotionEnabled(false)
useButton:SetPassThroughButtons('MiddleButton', 'RightButton', 'Button4', 'Button5')
useButton:RegisterForClicks('LeftButtonDown', 'LeftButtonUp')
useButton:SetAttribute('_onstate-combat', [[if newstate == 'combat' then self:Hide() end]])
RegisterStateDriver(useButton, 'combat', '[combat] combat; idle')

local function PrepareTrackerAction(cell)
    if IsCombat() then return end
    local left, bottom, width, height = cell:GetRect()
    if not left or not bottom or not cell:IsVisible() or not cell:IsMouseOver() then return end
    local scale = cell:GetEffectiveScale() / UIParent:GetEffectiveScale()
    useButton:ClearAllPoints()
    useButton:SetPoint('BOTTOMLEFT', UIParent, 'BOTTOMLEFT', left * scale, bottom * scale)
    useButton:SetSize(width * scale, height * scale)
    useButton.cell = cell
    useButton:SetAttribute('item', 'item:' .. cell.itemID)
    useButton:Show()
end

local function ActiveTrackerCell()
    local cell = useButton.cell
    if cell and cell:IsVisible() and cell:IsMouseOver() and BagnonHideDB.clickableTracker
        and inventory and not inventory:IsCached() and useButton:GetAttribute('item') == 'item:' .. cell.itemID then
        return cell
    end
end

useButton:SetScript('PreClick', function(self)
    if IsCombat() then return end
    local cell = ActiveTrackerCell()
    local use = cell and not IsModifierKeyDown() and not GetCursorInfo()
        and C_Item.GetItemCount(cell.itemID) > 0
    self:SetAttribute('type1', use and 'item' or nil)
end)
useButton:HookScript('PostClick', function(_, mouse, down)
    if mouse == 'LeftButton' and not down and IsShiftKeyDown() and not IsAltKeyDown() and not IsControlKeyDown() then
        local cell = ActiveTrackerCell()
        if cell then ToggleTrackedItem(cell.itemID) end
    end
end)

local function TrackerCell(bar, index)
    local cell = bar.cells[index]
    if cell then return cell end
    cell = CreateFrame('Button', nil, bar)
    bar.cells[index] = cell
    cell:SetHeight(20)
    cell:SetScript('OnEnter', function(self)
        bar:GetScript('OnEnter')(bar)
        PrepareTrackerAction(self)
    end)
    local function Leave(self)
        if useButton.cell == self and not IsCombat() then useButton:Hide() end
        if GameTooltip:IsOwned(bar) then GameTooltip:Hide() end
    end
    cell:SetScript('OnLeave', Leave)
    cell:SetScript('OnHide', Leave)
    cell:SetScript('OnClick', function(self, mouse)
        if mouse == 'LeftButton' and IsShiftKeyDown() and not IsAltKeyDown() and not IsControlKeyDown()
            and BagnonHideDB.clickableTracker and not inventory:IsCached() then
            ToggleTrackedItem(self.itemID)
        elseif mouse == 'LeftButton' and IsCombat() and not IsModifierKeyDown() then
            Print('Use tracked items from the footer after combat.')
        end
    end)
    return cell
end

local function UpdateTracker()
    if not inventory or not inventory.Footer then return end
    local broker = inventory.BrokerCarrousel
    if broker and broker.BagnonHideReserved then
        if inventory:HasMoney() then
            broker:SetPoint('RIGHT', inventory.MoneyFrame, 'LEFT', -2, 0)
        else
            broker:SetPoint('RIGHT', inventory.Footer, 'RIGHT', -4, 0)
        end
        broker.BagnonHideReserved = nil
    end
    local bar = inventory.BagnonHideTracker
    if BagnonHideDB.trackingEnabled == false or #trackedItems == 0 or inventory:IsCached() or not inventory:IsVisible() then
        if bar then bar:Hide() end
        return
    end
    if not bar then
        bar = CreateFrame('Frame', nil, inventory.Footer)
        inventory.BagnonHideTracker = bar
        bar.cells = {}
        bar:SetHeight(20)
        bar.text = bar:CreateFontString(nil, 'OVERLAY', 'GameFontHighlightSmall')
        bar.text:SetPoint('CENTER')
        bar:EnableMouse(true)
        bar:SetScript('OnEnter', function(self)
            GameTooltip:SetOwner(self, 'ANCHOR_TOP')
            GameTooltip:SetText('Tracked items')
            for _, id in ipairs(trackedItems) do
                local name = C_Item.GetItemInfo(id)
                local count = C_Item.GetItemCount(id)
                GameTooltip:AddDoubleLine(name or ('Item ' .. id), tostring(count))
            end
            GameTooltip:Show()
        end)
        bar:SetScript('OnLeave', function() GameTooltip:Hide() end)
    end
    local footer = inventory.Footer
    local left, right = footer:GetLeft(), footer:GetRight()
    if not left or not right then bar:Hide() return end
    local currency, money = inventory.CurrencyTracker, inventory.MoneyFrame
    if currency and currency:IsShown() and currency:GetPoint(1) == 'TOPLEFT' then
        left = currency:GetRight() or left
    end
    if money and money:IsShown() then right = money:GetLeft() or right end
    if broker and broker:IsShown() then left = left + math.max(64, (right - left) / 2) end
    local width = right - left - 8
    if width < 20 then bar:Hide() return end
    local text = ''
    local visible = 0
    for i, id in ipairs(trackedItems) do
        local icon = C_Item.GetItemIconByID(id) or 134400
        local entry = '|T' .. icon .. ':16|t ' .. C_Item.GetItemCount(id)
        local more = i < #trackedItems and ('  +' .. (#trackedItems - i)) or ''
        local nextText = text == '' and entry or (text .. '   ' .. entry)
        bar.text:SetText(nextText .. more)
        if bar.text:GetStringWidth() > width then
            text = text .. '  +' .. (#trackedItems - i + 1)
            break
        end
        if BagnonHideDB.clickableTracker then
            visible = i
            local cell = TrackerCell(bar, i)
            bar.text:SetText(text == '' and '' or text .. '   ')
            local offset = bar.text:GetStringWidth()
            bar.text:SetText(entry)
            cell:SetWidth(bar.text:GetStringWidth())
            cell:ClearAllPoints()
            cell:SetPoint('LEFT', bar.text, 'LEFT', offset, 0)
            cell.itemID = id
            cell:Show()
        end
        text = nextText
    end
    bar.text:SetText(text)
    bar:SetWidth(math.min(width, bar.text:GetStringWidth() + 4))
    bar:ClearAllPoints()
    bar:SetPoint('TOP', footer, 'TOPLEFT', (left + right) / 2 - footer:GetLeft(), -2)
    if broker and broker:IsShown() then
        broker:SetPoint('RIGHT', bar, 'LEFT', -3, 0)
        broker.BagnonHideReserved = true
    end
    for i = visible + 1, #bar.cells do bar.cells[i]:Hide() end
    bar:Show()
    if not IsCombat() then
        useButton:Hide()
        for i = 1, visible do
            if bar.cells[i]:IsMouseOver() then PrepareTrackerAction(bar.cells[i]) break end
        end
    end
end

SetItemTracking = function(action, id)
    for index, tracked in ipairs(trackedItems) do
        if tracked == id then
            if action == 'untrack' then
                table.remove(trackedItems, index)
                UpdateTracker()
                Print('Removed item ' .. id .. ' from tracking.')
            else
                Print('Already tracking item ' .. id .. '.')
            end
            return
        end
    end
    if action == 'track' then
        table.insert(trackedItems, id)
        UpdateTracker()
        Print('Tracking item ' .. id .. '.')
    else
        Print('Item ' .. id .. ' is not tracked.')
    end
end

local function AttachInventory()
    local bagnon = _G.Bagnon
    if not bagnon or not bagnon.Frames or not bagnon.Frames.Get then return end
    local frame = bagnon.Frames:Get('inventory')
    if not frame or not frame[0] then return end -- Bagnon has not created the inventory yet

    if inventory ~= frame then
        inventory = frame
        attached = false
        if dismissLayer then dismissLayer:Hide() end
        checkbox = nil
        labelButton = nil
    end
    if not attached then
        attached = true
        local original = frame.IsShowingItem
        if type(original) == 'function' then
            frame.IsShowingItem = function(self, bag, slot, info, family)
                if not original(self, bag, slot, info, family) then return false end
                if self.IsCached and self:IsCached() then return true end
                local id = info and info.itemID
                if id and questSlots[SlotKey(bag, slot)] == id then return false end
                return showHidden or not ItemIsHidden(bag, slot, id)
            end
        end
        frame:HookScript('OnHide', function()
            if dismissLayer then dismissLayer:Hide() end
        end)
        frame:HookScript('OnShow', function()
            MigrateLegacyItems()
            CheckBags()
            UpdateQuestSlots()
            UpdateTracker()
            EnsureCheckbox()
            PositionCheckbox()
            AttachGroup()
            Refresh()
        end)
        -- Bagnon can lay out bags/keyring afresh when options change.
        if frame.Layout then
            hooksecurefunc(frame, 'Layout', function()
                UpdateTracker()
                if checkbox then PositionCheckbox() end
                AttachGroup()
            end)
        end
    end

    MigrateLegacyItems()
    UpdateQuestSlots()
    UpdateTracker()
    EnsureCheckbox()
    AttachGroup()
    PositionCheckbox()
    Refresh()
end

local function Start()
    BagnonHideDB = type(BagnonHideDB) == 'table' and BagnonHideDB or {}
    BagnonHideDB.items = type(BagnonHideDB.items) == 'table' and BagnonHideDB.items or {}
    BagnonHideDB.slots = type(BagnonHideDB.slots) == 'table' and BagnonHideDB.slots or {}
    hideQuestItems = BagnonHideDB.hideQuestItems == true
    BagnonHideDB.trackedItems = type(BagnonHideDB.trackedItems) == 'table' and BagnonHideDB.trackedItems or {}
    trackedItems = BagnonHideDB.trackedItems
    hiddenSlots = BagnonHideDB.slots
    BagnonHideDB.equipment = type(BagnonHideDB.equipment) == 'table' and BagnonHideDB.equipment or {}
    hiddenEquipment = BagnonHideDB.equipment
    -- Promote exact legacy GUIDs before any Bagnon filter or equipment event.
    for key, record in pairs(hiddenSlots) do
        if type(record) == 'table' and record.equipment and record.guid then
            hiddenEquipment[record.guid] = hiddenEquipment[record.guid] or record
            hiddenSlots[key] = nil
        end
    end
    legacyItems = BagnonHideDB.items
    migrationDone = BagnonHideDB.schemaVersion == 2
    local saved = type(BagnonHideDB.highlight) == 'table' and BagnonHideDB.highlight or {}
    highlight.r = Clamp(saved.r or highlight.r, 0, 1)
    highlight.g = Clamp(saved.g or highlight.g, 0, 1)
    highlight.b = Clamp(saved.b or highlight.b, 0, 1)
    highlight.intensity = Clamp(saved.intensity or highlight.intensity, 0, 100)

    local bagnon = _G.Bagnon
    if bagnon and bagnon.Frames and bagnon.Frames.New then
        hooksecurefunc(bagnon.Frames, 'New', AttachInventory)
        -- Also handle a bag window created before this module attached.
        AttachInventory()
    else
        Print('Bagnon was not detected. Make sure Bagnon is enabled.')
    end
end

mod:RegisterEvent('MODIFIER_STATE_CHANGED')
mod:RegisterEvent('PLAYER_EQUIPMENT_CHANGED')
mod:RegisterEvent('PLAYER_LOGIN')
mod:RegisterEvent('PLAYER_ENTERING_WORLD')
mod:RegisterEvent('PLAYER_LEAVING_WORLD')
mod:RegisterEvent('PLAYER_MONEY')
mod:RegisterEvent('BAG_UPDATE_DELAYED')
mod:RegisterEvent('PLAYER_REGEN_ENABLED')
mod:RegisterEvent('PLAYER_REGEN_DISABLED')
mod:SetScript('OnEvent', function(self, event, key)
    if event == 'MODIFIER_STATE_CHANGED' then
        if key == 'LSHIFT' or key == 'RSHIFT' or key == 'LALT' or key == 'RALT' then UpdateMouseTarget() end
    elseif event == 'PLAYER_EQUIPMENT_CHANGED' then
        if inWorld then TrackEquipment(key); CheckBags(); QueueStackRefresh() end
    elseif event == 'PLAYER_LOGIN' then
        Start()
    elseif event == 'PLAYER_LEAVING_WORLD' then
        inWorld = false
        if confirmTimer then confirmTimer:Cancel() end
        confirmTimer = nil
        pendingRemoval, worn, transitions, recentlyRemoved = {}, {}, {}, {}
    elseif event == 'PLAYER_ENTERING_WORLD' then
        inWorld = true
        readyAt = GetTime() + 5
        worn, transitions, recentlyRemoved = {}, {}, {}
        for slot = 1, 19 do TrackEquipment(slot, true) end
        CheckBags()
        Refresh()
    elseif event == 'PLAYER_MONEY' then
        UpdateTracker()
    elseif event == 'BAG_UPDATE_DELAYED' then
        UpdateTracker()
        MigrateLegacyItems()
        CheckBags()
        if hideQuestItems and UpdateQuestSlots() then Refresh() end
        QueueStackRefresh()
        if targetButton then UpdateMouseTarget() end
    elseif event == 'PLAYER_REGEN_DISABLED' then
        if dismissLayer then dismissLayer:Hide() end
    elseif event == 'PLAYER_REGEN_ENABLED' then
        UpdateTracker()
        UpdateMouseTarget()
        MigrateLegacyItems()
        Refresh()
    end
end)

local helpWindow
local function ToggleHelp()
    if helpWindow then
        helpWindow:SetShown(not helpWindow:IsShown())
        return
    end
    local panel = CreateFrame('Frame', 'BagnonHideHelp', UIParent)
    helpWindow = panel
    panel:SetSize(480, 550)
    panel:SetPoint('CENTER')
    panel:SetFrameStrata('DIALOG')
    panel:EnableMouse(true)
    local background = panel:CreateTexture(nil, 'BACKGROUND')
    background:SetAllPoints()
    background:SetColorTexture(.065, .055, .05, 1)
    local close = CreateFrame('Button', nil, panel, 'UIPanelCloseButton')
    close:SetPoint('TOPRIGHT', -3, -3)
    table.insert(UISpecialFrames, panel:GetName())

    local function Line(font, y, text)
        local label = panel:CreateFontString(nil, 'OVERLAY', font)
        label:SetPoint('TOPLEFT', 18, -y)
        label:SetWidth(442)
        label:SetJustifyH('LEFT')
        label:SetText(text)
        return label
    end
    Line('GameFontNormalLarge', 16, 'Bagnon Hide  1.0.26')
    Line('GameFontNormal', 52, 'Bag shortcuts')
    Line('GameFontHighlight', 74, 'Middle-click an item to disenchant it.')
    Line('GameFontHighlight', 96, 'Shift-middle-click an item to hide or unhide it.')
    Line('GameFontHighlight', 118, 'Shift-left-click to link in active chat, search in open Shady Search, or confirm deletion of the stack.')
    Line('GameFontHighlight', 158, 'Click Show Hidden to reveal hidden items. Right-click it to adjust their highlight. Click outside the options to close them.')
    Line('GameFontHighlight', 198, 'Hide Quest Items also applies while Show Hidden is checked.')
    Line('GameFontHighlight', 216, 'Alt-middle-click an item to add it to the bottom tracker.')
    Line('GameFontNormal', 238, 'Commands')
    Line('GameFontHighlight', 260, '/bagnonhide or /bgh    Open or close this window.')
    Line('GameFontHighlight', 282, '/bgh show    Reveal manually hidden items.')
    Line('GameFontHighlight', 304, '/bgh hide    Conceal manually hidden items again.')
    local tracking = CreateFrame('CheckButton', nil, panel, 'UICheckButtonTemplate')
    tracking:SetSize(22, 22)
    tracking:SetPoint('TOPLEFT', 15, -326)
    tracking:SetChecked(BagnonHideDB.trackingEnabled ~= false)
    tracking:SetScript('OnClick', function(self)
        BagnonHideDB.trackingEnabled = not not self:GetChecked()
        UpdateTracker()
    end)
    local trackingLabel = tracking:CreateFontString(nil, 'OVERLAY', 'GameFontNormal')
    trackingLabel:SetPoint('LEFT', tracking, 'RIGHT', 3, 0)
    trackingLabel:SetText('Show tracked item counts between Favor and gold')
    Line('GameFontHighlight', 359, '/bgh track <item ID or link>    Add an item and its bag count.')
    Line('GameFontHighlight', 381, '/bgh untrack <item ID or link>    Remove it from the footer.')
    Line('GameFontHighlightSmall', 408, 'Hover over the counts to see the full list.')
    local clicks = CreateFrame('CheckButton', nil, panel, 'UICheckButtonTemplate')
    clicks:SetSize(22, 22)
    clicks:SetPoint('TOPLEFT', 15, -428)
    clicks:SetChecked(BagnonHideDB.clickableTracker == true)
    clicks:SetScript('OnClick', function(self)
        BagnonHideDB.clickableTracker = not not self:GetChecked()
        UpdateTracker()
    end)
    local caption = clicks:CreateFontString(nil, 'OVERLAY', 'GameFontNormal')
    caption:SetPoint('LEFT', clicks, 'RIGHT', 3, 0)
    caption:SetText('Clickable icons: left-click to use, Shift-left-click to hide/show stacks')
    Line('GameFontHighlightSmall', 464, '/bgh audit  |  /bgh debug  |  /bgh resync')
    Line('GameFontHighlightSmall', 484, 'Equipment follows item identity; stacks remain slot-specific.')
    Line('GameFontDisableSmall', 524, 'RIP Shady')
end

SLASH_BAGNONHIDE1 = '/bagnonhide'
SLASH_BAGNONHIDE2 = '/bgh'
SlashCmdList.BAGNONHIDE = function(cmd)
    cmd = (cmd or ''):lower():match('^%s*(.-)%s*$')
    local action, arg = cmd:match('^(%S+)%s*(.*)$')
    if action == 'track' or action == 'untrack' then
        local id = tonumber(arg:match('^%d+$') or arg:match('item:(%d+)'))
        if not id or id < 1 then
            Print('Use /bgh ' .. action .. ' followed by an item ID or item link.')
            return
        end
        SetItemTracking(action, id)
    elseif cmd == 'audit' then
        local identities, slots, pending = 0, 0, 0
        for _ in pairs(hiddenEquipment) do identities = identities + 1 end
        for _ in pairs(hiddenSlots) do slots = slots + 1 end
        for _ in pairs(pendingRemoval) do pending = pending + 1 end
        Print('1.0.26 | Equipment identities: ' .. identities .. ' | Slot records: ' .. slots .. ' | Pending: ' .. pending)
        Print('Session passes: ' .. stats.passes .. ' | Exchanges: ' .. stats.swaps .. ' | Promoted: ' .. stats.promoted .. ' | Retired stacks: ' .. stats.retired)
    elseif cmd == 'debug' then
        debugEnabled = not debugEnabled
        Print('Inventory diagnostics ' .. (debugEnabled and 'enabled' or 'disabled'))
    elseif cmd == 'resync' then
        CheckBags()
        Refresh()
        Print('Reconciliation requested; hidden preferences retained.')
    elseif cmd == 'show' then
        showHidden = true
        if checkbox then checkbox:SetChecked(true) end
        Refresh(true)
    elseif cmd == 'hide' then
        showHidden = false
        if checkbox then checkbox:SetChecked(false) end
        Refresh(true)
    else
        ToggleHelp()
    end
end
