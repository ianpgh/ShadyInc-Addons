local A='CampfireSongs'
local event=CreateFrame('Frame')
local db, state, preview, hidden, settings
local rows={}
local fireIcon='Interface\\Icons\\Spell_Fire_Fire'
local bagIcon='Interface\\Icons\\INV_Misc_Bag_10'
local function say(s) print('|cffffb65cCampfire Songs:|r '..s) end
local function clock(s) s=math.max(0,math.ceil(s)); return string.format('%d:%02d',math.floor(s/60),s%60) end
local function now() return GetTime() end
local function spell(id)
 if C_Spell and C_Spell.GetSpellInfo then local x=C_Spell.GetSpellInfo(id); if x then return x.name,x.iconID end end
 if GetSpellInfo then local n,_,i=GetSpellInfo(id); return n,i end
end
local frame=CreateFrame('Frame','CampfireSongsWindow',UIParent,'BackdropTemplate')
frame:SetSize(300,60); frame:SetFrameStrata('MEDIUM'); frame:SetMovable(true); frame:SetClampedToScreen(true); frame:EnableMouse(true); frame:RegisterForDrag('LeftButton')
frame:SetBackdrop({bgFile='Interface\\Buttons\\WHITE8X8',edgeFile='Interface\\Tooltips\\UI-Tooltip-Border',edgeSize=13,insets={left=3,right=3,top=3,bottom=3}}); frame:SetBackdropColor(.045,.035,.025,1); frame:SetBackdropBorderColor(.75,.48,.23,1)
frame:SetScript('OnDragStart',function(self) if db and not db.locked then self:StartMoving() end end)
frame:SetScript('OnDragStop',function(self) self:StopMovingOrSizing(); local p,_,r,x,y=self:GetPoint(); db.point={p,r,x,y} end)
local title=frame:CreateFontString(nil,'OVERLAY','GameFontNormalLarge'); title:SetPoint('TOPLEFT',12,-10); title:SetText('Campfire Songs')
local gear=CreateFrame('Button',nil,frame,'UIPanelButtonTemplate'); gear:SetSize(25,22); gear:SetPoint('TOPRIGHT',-8,-6); gear:SetText('*'); gear:SetScript('OnClick',function() if settings then settings:SetShown(not settings:IsShown()) end end)
local headerArt=frame:CreateTexture(nil,'ARTWORK'); headerArt:SetTexture('Interface\\AddOns\\CampfireSongs\\HeaderCampfire'); headerArt:SetPoint('RIGHT',gear,'LEFT',-3,0); headerArt:SetSize(88,22); headerArt:Hide()
local function validIcon(ic)
 if not ic or ic==0 or ic==134400 then return false end
 if type(ic)=='string' and ic:lower():find('questionmark',1,true) then return false end
 return true
end
local function rowIcon(v)
 if validIcon(v.ic) then return v.ic end
 local n=v.n:lower()
 if n:find('campfire',1,true) then return fireIcon end
 if n:find('sleeping bag',1,true) then return bagIcon end
 if n:find('mana',1,true) then return 'Interface\\Icons\\INV_Potion_76' end
 if n:find('faction banner',1,true) then
  return UnitFactionGroup('player')=='Horde' and 'Interface\\Icons\\INV_BannerPVP_01' or 'Interface\\Icons\\INV_BannerPVP_02'
 end
 if n:find('camp benefit',1,true) or n:find('camp buff',1,true) then return 'Interface\\Icons\\INV_Misc_Food_15' end
 if v.effect=='Spirit' then return 'Interface\\Icons\\Spell_Holy_DivineSpirit' end
 if v.effect=='Strength' then return 'Interface\\Icons\\Spell_Nature_Strength' end
 if v.effect=='Stamina' then return 'Interface\\Icons\\Spell_Holy_WordFortitude' end
 if v.effect=='Intellect' then return 'Interface\\Icons\\Spell_Holy_MagicalSentry' end
 return nil
end
-- Never inspect or retain secret aura values. A blocked scan is not an empty scan.
local function secret(v)
 return issecretvalue and issecretvalue(v) or false
end
local function auraBlocked()
 return InCombatLockdown and InCombatLockdown()
end
local function readAura(i)
 if auraBlocked() then return nil,false end
 local ok,a=pcall(function()
  local n,icon,count,duration,expires,id
  if C_UnitAuras and C_UnitAuras.GetAuraDataByIndex then
   local x=C_UnitAuras.GetAuraDataByIndex('player',i,'HELPFUL')
   if secret(x) then error('restricted aura') end
   if not x then return nil end
   n,icon,count,duration,expires,id=x.name,x.icon,x.applications,x.duration,x.expirationTime,x.spellId
  elseif UnitBuff then
   local ignored1,ignored2,ignored3,ignored4
   n,icon,count,ignored1,duration,expires,ignored2,ignored3,ignored4,id=UnitBuff('player',i)
  else error('aura API unavailable') end
  if secret(n) or secret(icon) or secret(count) or secret(duration) or secret(expires) or secret(id) then error('restricted aura fields') end
  if not n then return nil end
  if type(n)~='string' then error('invalid aura name') end
  return {name=n,icon=icon,count=count or 0,duration=duration or 0,ends=expires or 0,id=id,index=i}
 end)
 if not ok then return nil,false end
 return a,true
end
local function row(i)
 if rows[i] then return rows[i] end
 local r=CreateFrame('Frame',nil,frame); r:SetPoint('TOPLEFT',10,-34-(i-1)*33); r:SetPoint('RIGHT',frame,'RIGHT',-10,0); r:SetHeight(30)
 r.icon=r:CreateTexture(nil,'ARTWORK'); r.icon:SetSize(23,23); r.icon:SetPoint('LEFT',0,1)
 r.label=r:CreateFontString(nil,'OVERLAY','GameFontHighlightSmall'); r.label:SetPoint('TOPLEFT',29,-1); r.label:SetWidth(175); r.label:SetJustifyH('LEFT'); r.label:SetWordWrap(false)
 r.time=r:CreateFontString(nil,'OVERLAY','GameFontNormal'); r.time:SetPoint('TOPRIGHT',-1,-1)
 r.bar=CreateFrame('StatusBar',nil,r); r.bar:SetPoint('BOTTOMLEFT',29,5); r.bar:SetPoint('BOTTOMRIGHT',-1,5); r.bar:SetHeight(6); r.bar:SetStatusBarTexture('Interface\\Buttons\\WHITE8X8'); r.bar:SetMinMaxValues(0,1)
 local bg=r.bar:CreateTexture(nil,'BACKGROUND'); bg:SetAllPoints(); bg:SetColorTexture(.16,.16,.16,1)
 r:EnableMouse(true)
 r:SetScript('OnEnter',function(self)
  local v=self.data; if not v then return end
  GameTooltip:SetOwner(self,'ANCHOR_RIGHT')
  if v.aura and GameTooltip.SetUnitAura then
   local index
   for i=1,80 do
    local a,ok=readAura(i); if not ok or not a then break end
    if a.name==v.aura.name and (not v.aura.id or a.id==v.aura.id) then index=i; break end
   end
   if not index or not pcall(GameTooltip.SetUnitAura,GameTooltip,'player',index,'HELPFUL') then GameTooltip:SetText(v.n) end
  else GameTooltip:SetText(v.n); if v.effect then GameTooltip:AddLine('Provides: '..v.effect,1,1,1,true) end; if v.estimated then GameTooltip:AddLine('Estimated timer',1,.8,.2) end end
  GameTooltip:Show()
 end)
 r:SetScript('OnLeave',function() GameTooltip:Hide() end)
 rows[i]=r; return r
end
local features={}
for _,n in ipairs({'Mana Well','Fermenter','Alchemy Laboratory','Sharpening Wheel','Anvil','Forge','First Aid Kit','Toxin Study',"Plague Doctor's Laboratory",'Fish Bowl','Fishing Rack','Fishing Hut','Incense Candle','Greenhouse','Seed Hybridizer','Camp Tent','Tanning Rack','Camp Chair','Field Guide',"Trapper's Workbench",'Faction Banner','Rock Garden',"Cookie's Feast",'Iron Oven'}) do features[n:lower()]=true end
local effects={}
local function group(effect,names)
 for _,name in ipairs(names) do features[name:lower()]=true; effects[name:lower()]=effect end
end
group('Mana regeneration',{'Mana Well','Fermenter','Alchemy Laboratory'})
group('Strength',{'Sharpening Wheel','Anvil','Forge','Master Forge'})
group('Spirit',{'Faction Banner','Faction Banner (Horde)','Faction Banner (Alliance)','Spinning Wheel','Loom'})
group('Armor, stats and resistances',{'Enchanted Lute','Arcane Salvager','Arcane Forge'})
group('Attack power',{'Lodestone','Rock Garden','Molten Foundry'})
group('Intellect',{'Incense Candle','Greenhouse','Seed Hybridizer'})
group('Critical strike',{'Camp Chair','Field Guide',"Trapper's Workbench"})
group('Stamina',{'First Aid Kit','Toxin Study',"Plague Doctor's Laboratory"})
group('All attributes',{'Fish Bowl','Fishing Rack','Fishing Hut'})
group('Rested XP shelter',{'Camp Tent','Tanning Rack','Sewing Machine'})
group('Field services',{'Reagent Bot','Repair Bot',"Anarchist's Workbench"})
local auraNames={['honed edge']=true,['rallying morale']=true,['campfire ballad']=true}
local function normalize(n)
 return n:lower():gsub('^place ',''):gsub('^build ',''):gsub('^deploy ',''):gsub('^create ',''):gsub('^construct ','')
end
local function classify(n)
 n=normalize(n)
 if n:find('sleeping bag',1,true) then return 'bag' end
 if n:find('campfire',1,true) and not n:find('nearby',1,true) then return 'fire' end
 if features[n] or (db.learned and db.learned[n]) then return 'feature' end
end
local history={}
local function record(s) history[#history+1]=s; if #history>35 then table.remove(history,1) end end
local function start(kind,name,icon)
 local t=now()
 if kind=='fire' then state.fire={name=name,icon=icon,ends=t+db.fireDuration,duration=db.fireDuration}; state.parts={}; hidden=false
 elseif kind=='feature' then state.parts[name]={name=name,effect=effects[normalize(name)],icon=icon,ends=t+db.partDuration,duration=db.partDuration}; hidden=false
 elseif kind=='bag' then state.bag={ends=t+180,next=t+60,base=state.stacks or 0,waiting=true}; hidden=false end
end
local function scan()
 if auraBlocked() then return end
 local rested,near,welcome,sleep
 local campBuffs={}
 for i=1,80 do
  local a,ok=readAura(i)
  if not ok then return end
  if not a then break end
  local l=a.name:lower()
  if l=='well-rested' or l=='well rested' then rested=a elseif l=='campfire nearby' then near=a elseif l=='welcoming campfire' then welcome=a elseif l:find('sleeping bag',1,true) then sleep=a elseif l~='camp benefits' and (auraNames[l] or (db.buffNames and db.buffNames[l]) or features[l] or (db.learned and db.learned[l]) or l:find('campfire',1,true)) and a.ends>now() then campBuffs[#campBuffs+1]=a end
 end
 if (near and not state.near) or (welcome and not state.welcome) then hidden=false end
 state.near=near; state.welcome=welcome; state.rested=rested; state.campBuffs=campBuffs
 local count=rested and math.max(1,rested.count) or 0
 local prev=state.stacks or 0
 if sleep and not state.sleep and count<3 then state.bag={ends=now()+180,next=now()+60,base=count,waiting=false}; hidden=false end
 if state.sleep and not sleep then state.bag=nil end
 if count>prev and count<=3 then
  if sleep then
   if count<3 then state.bag={ends=now()+(3-count)*60,next=now()+60,base=count,waiting=not sleep} else state.bag=nil; if db.sound and PlaySound then PlaySound(12867) end end
  end
 end
 state.sleep=sleep; state.stacks=count
end
local function render()
 if not db then return end
 headerArt:SetShown(db.headerArt and true or false)
 local t=now(); local list={}
 local function add(n,ic,left,total,c,estimated,override,aura,effect)
  list[#list+1]={n=n,ic=ic,left=left,total=total,c=c,estimated=estimated,override=override,aura=aura,effect=effect}
 end
 local f=state.fire
 if f and f.ends<=t then state.fire=nil; f=nil end
 if f then add('Campfire',f.icon or fireIcon,f.ends-t,f.duration,{1,.51,.15},true) end
 local keys={}; for k,p in pairs(state.parts) do if p.ends<=t then state.parts[k]=nil else keys[#keys+1]=k end end; table.sort(keys)
 for _,k in ipairs(keys) do local p=state.parts[k]; add(p.effect and (p.name..' - '..p.effect) or p.name,p.icon,p.ends-t,p.duration,{.25,.65,1},true,nil,nil,p.effect) end
 local w=state.welcome; if w and w.ends>t then add('Camp Benefits in',w.icon,w.ends-t,w.duration,{.9,.65,.2},false,nil,w) end
 for _,a in ipairs(state.campBuffs or {}) do if a.ends>t then add(a.name,a.icon,a.ends-t,a.duration,{.9,.65,.2},false,nil,a) end end
 local b=state.bag; if b and b.ends<t then state.bag=nil; b=nil end
 local count=state.stacks or 0
 if b and state.sleep and count<3 then local left=b.next-t; add('Sleeping bag: '..count..'/3 stacks',bagIcon,left,60,{.35,.8,.42},true,left<=0 and 'Waiting' or nil) end
 if preview then list={}; add('Campfire',fireIcon,222,600,{1,.51,.15},true); add('Mana Well - Mana regeneration',nil,258,900,{.25,.65,1},true,nil,nil,'Mana regeneration'); add('Faction Banner - Spirit',nil,272,900,{.25,.65,1},true,nil,nil,'Spirit'); add('Camp Benefits in',nil,24,60,{.9,.65,.2},false); add('Sleeping bag: 2/3 stacks',bagIcon,24,60,{.35,.8,.42},true) end
 for i,v in ipairs(list) do local r=row(i); r.data=v; r:Show(); local ic=rowIcon(v); r.icon:SetTexture(ic); r.icon:SetShown(ic~=nil); r.label:SetText(v.n); r.time:SetText(v.override or ((v.estimated and '~' or '')..clock(v.left))); if v.left>0 and v.left<=30 then r.time:SetTextColor(1,1,0) else r.time:SetTextColor(1,1,1) end; r.bar:SetStatusBarColor(unpack(v.c)); r.bar:SetValue(math.max(0,math.min(1,v.left/math.max(1,v.total)))) end
 for i=#list+1,#rows do rows[i]:Hide() end
 frame:SetHeight(42+math.max(1,#list)*33); frame:SetShown(preview or (not hidden and (#list>0 or not db.locked)))
end
local function makeSettings()
 settings=CreateFrame('Frame','CampfireSongsSettings',UIParent,'BackdropTemplate'); settings:SetSize(330,330); settings:SetPoint('CENTER'); settings:SetFrameStrata('DIALOG'); settings:EnableMouse(true); settings:SetBackdrop({bgFile='Interface\\Buttons\\WHITE8X8',edgeFile='Interface\\Tooltips\\UI-Tooltip-Border',edgeSize=14}); settings:SetBackdropColor(.06,.06,.06,1); settings:Hide(); tinsert(UISpecialFrames,'CampfireSongsSettings')
 local h=settings:CreateFontString(nil,'OVERLAY','GameFontNormalLarge'); h:SetPoint('TOP',0,-16); h:SetText('Campfire Songs 1.0.6')
 local close=CreateFrame('Button',nil,settings,'UIPanelCloseButton'); close:SetPoint('TOPRIGHT',-3,-3)
 local function check(label,key,y) local c=CreateFrame('CheckButton',nil,settings,'UICheckButtonTemplate'); c:SetPoint('TOPLEFT',15,y); local l=c:CreateFontString(nil,'OVERLAY','GameFontHighlight'); l:SetPoint('LEFT',c,'RIGHT',2,0); l:SetText(label); c:SetChecked(db[key]); c:SetScript('OnClick',function(self) db[key]=self:GetChecked() and true or false; render() end) end
 check('Lock tracker','locked',-45); check('Sound at 3 sleeping bag stacks','sound',-77); check('Campfire header artwork (experimental)','headerArt',-109)
 local function button(label,y,fn) local b=CreateFrame('Button',nil,settings,'UIPanelButtonTemplate'); b:SetSize(270,25); b:SetPoint('TOP',0,y); b:SetText(label); b:SetScript('OnClick',fn) end
 button('Toggle preview / move tracker',-145,function() preview=not preview; render() end); button('Show / hide live timers',-175,function() hidden=not hidden; preview=false; render() end)
 button('Scale: cycle 80 / 100 / 120 / 140%',-205,function() db.scale=({[.8]=1,[1]=1.2,[1.2]=1.4,[1.4]=.8})[db.scale] or 1; frame:SetScale(db.scale) end)
 button('Clear estimated campsite timers',-235,function() state.fire=nil; state.parts={}; state.bag=nil; render() end)
 local note=settings:CreateFontString(nil,'OVERLAY','GameFontHighlightSmall'); note:SetPoint('BOTTOM',0,32); note:SetText('~ = estimated  |  /cfs help for commands')
 local foot=settings:CreateFontString(nil,'OVERLAY','GameFontDisableSmall'); foot:SetPoint('BOTTOM',0,12); foot:SetText('RIP Shady')
end
frame:Hide()
local elapsed=0
frame:SetScript('OnUpdate',function() end)
event:SetScript('OnUpdate',function(_,dt) if not db then return end; if not (state.fire or next(state.parts) or state.bag or state.welcome or (state.campBuffs and #state.campBuffs>0) or preview) then return end; elapsed=elapsed+dt; if elapsed>=.25 then elapsed=0; render() end end)
event:RegisterEvent('ADDON_LOADED'); event:RegisterEvent('PLAYER_ENTERING_WORLD'); event:RegisterEvent('UNIT_AURA'); event:RegisterEvent('UNIT_SPELLCAST_SUCCEEDED'); event:RegisterEvent('PLAYER_DEAD'); event:RegisterEvent('PLAYER_REGEN_ENABLED')
event:SetScript('OnEvent',function(_,e,u,_,id)
 if e=='ADDON_LOADED' then if u~=A then return end; CampfireSongsDB=CampfireSongsDB or {}; db=CampfireSongsDB; local defaults={locked=true,sound=false,headerArt=true,scale=1,fireDuration=600,partDuration=900,learned={},buffNames={}}; for k,v in pairs(defaults) do if db[k]==nil then db[k]=v end end; state={parts={},stacks=0}; frame:SetScale(db.scale); if db.point then frame:SetPoint(db.point[1],UIParent,db.point[2],db.point[3],db.point[4]) else frame:SetPoint('CENTER',UIParent,'CENTER',250,80) end; makeSettings(); scan(); render()
 elseif not db then return
 elseif e=='UNIT_AURA' and u=='player' then scan(); render()
 elseif e=='UNIT_SPELLCAST_SUCCEEDED' and u=='player' then local n,ic=spell(id); if n then record('Cast '..n..' ['..tostring(id)..']'); local kind=classify(n); if kind then start(kind,n,ic); render() end end
 elseif e=='PLAYER_ENTERING_WORLD' or e=='PLAYER_REGEN_ENABLED' then scan(); render()
 elseif e=='PLAYER_DEAD' then state.bag=nil; state.sleep=nil; render() end
end)
SLASH_CAMPFIRESONGS1='/cfs'; SLASH_CAMPFIRESONGS2='/campfiresongs'
SlashCmdList.CAMPFIRESONGS=function(msg)
 if not db then return end; local cmd,arg=msg:match('^%s*(%S*)%s*(.-)%s*$'); cmd=cmd:lower()
 if cmd=='' then settings:SetShown(not settings:IsShown())
 elseif cmd=='test' then preview=not preview; render()
 elseif cmd=='show' or cmd=='hide' then hidden=cmd=='hide'; preview=false; render()
 elseif cmd=='lock' or cmd=='unlock' then db.locked=cmd=='lock'; render()
 elseif cmd=='fire' or cmd=='placement' then local n=tonumber(arg); if n and n>=10 and n<=3600 then db[cmd=='fire' and 'fireDuration' or 'partDuration']=n; say('Duration set to '..n..' seconds for future casts.') else say('Enter seconds (10–3600).') end
 elseif cmd=='learn' and arg~='' then db.learned[arg:lower()]=true; say('Tracking placement spell: '..arg)
 elseif cmd=='learnbuff' and arg~='' then db.buffNames[arg:lower()]=true; scan(); render(); say('Tracking camp aura: '..arg)
 elseif cmd=='sleep' then start('bag','Cozy Sleeping Bag',bagIcon); render()
 elseif cmd=='stop' then state.bag=nil; state.fire=nil; state.parts={}; preview=false; render()
 elseif cmd=='diag' then local v,b,_,toc=GetBuildInfo(); say('1.0.6 | '..v..' / '..b..' / '..toc); say('Nearby: '..tostring(state.near~=nil)..' | Sleep aura: '..tostring(state.sleep~=nil)..' | Stacks: '..state.stacks); for _,s in ipairs(history) do print(s) end; for i=1,80 do local a,ok=readAura(i); if not ok then say('Aura data currently unavailable.'); break end; if not a then break end; print(a.name..' ['..tostring(a.id)..'] x'..tostring(a.count)..' duration '..tostring(a.duration)) end
 else say('/cfs settings (no argument), test, show, hide, lock, unlock, fire <seconds>, placement <seconds>, learn <spell name>, learnbuff <aura name>, sleep, stop, diag') end
end
