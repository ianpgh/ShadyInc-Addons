-- HideThisManager 1.3.6 | World of Warcraft: Forever (Interface 16001)
-- Keep new UI-cleanup options in OPTIONS and provide an APPLIERS handler.
-- Account-wide settings are saved by Blizzard as HideThisManagerDB.

local ADDON_NAME = ...
local PREFIX = "|cffd9a64bHideThisManager|r"
local VERSION = "1.3.6"

local OPTIONS = {
    {
        key = "hideRaidManager",
        category = "BLIZZARD UI",
        label = "Original Party / Raid Manager",
        description = "Hide Blizzard's slide-out party controls and side arrow. Group frames are unaffected.",
        default = true,
    },
    {
        key = "hideBagButtons",
        category = "BLIZZARD UI",
        label = "Bag Bar (Bag Buttons + Keyring)",
        description = "Hide the backpack, bag buttons, keyring and their surrounding bar.",
        default = false,
    },
    {
        key = "hideMicroMenu",
        category = "BLIZZARD UI",
        label = "Menu Buttons (Micro Menu)",
        description = "Hide the character, spells, talents, map, options and other menu buttons.",
        default = false,
    },
    {
        key = "hideDielFrame",
        category = "MINIMAP",
        label = "Minimap Sun / Moon Icon",
        description = "Hide the day/night orb on the minimap border; other minimap icons stay visible.",
        default = false,
        compact = true,
    },
    {
        key = "hideMinimap",
        category = "MINIMAP",
        label = "Entire Minimap",
        description = "Hide Blizzard's entire minimap, its border and header. Does not disable the world map hotkey.",
        default = false,
        compact = true,
    },
    {
        key = "hideMailIcon",
        category = "MINIMAP",
        label = "Hide New Mail Icon",
        description = "Hide Blizzard's new-mail envelope without affecting other minimap icons.",
        default = false,
        compact = true,
    },
    {
        key = "moveMailIcon",
        category = "MINIMAP",
        label = "Move New Mail Icon",
        description = "Detach the mail envelope from the minimap. Use Place to drag its position.",
        default = false,
        compact = true,
    },
    {
        key = "hideMinimapIcons",
        category = "MINIMAP",
        label = "Addon Icons Around Minimap",
        description = "Hide addon-owned minimap buttons only. Blizzard minimap controls are excluded.",
        default = false,
        compact = true,
    },
    {
        key = "showMinimapIconRow",
        category = "MINIMAP",
        label = "Show Movable Addon Icon Row",
        description = "When the minimap is hidden, place addon buttons in a slim draggable strip. Hide Icons overrides it.",
        default = false,
        requiresHiddenMinimap = true,
        compact = true,
    },
    {
        key = "hideMinimapTracking",
        category = "MINIMAP HEADER",
        label = "Tracking Button",
        description = "Hide the native minimap tracking/filter button in the header.",
        default = false,
        compact = true,
    },
    {
        key = "hideMinimapHeader",
        category = "MINIMAP HEADER",
        label = "Map / Zone / Time Header",
        description = "Hide the world-map button, location/zone label and clock, but not the calendar.",
        default = false,
        compact = true,
    },
    {
        key = "hideMinimapCalendar",
        category = "MINIMAP HEADER",
        label = "Calendar Button",
        description = "Hide just Blizzard's calendar/date button (GameTimeFrame).",
        default = false,
        compact = true,
    },
    {
        key = "centerMainActionBar",
        category = "ACTION BAR",
        label = "Center Original Action Bar",
        description = "Center only the 1-to-= row; leave other action bars and XP/status bars in place.",
        default = false,
        requiresHiddenBars = true,
        compact = true,
    },
    {
        key = "solidBackground",
        category = "SETTINGS",
        label = "Use Solid / Opaque Background",
        description = "Give the settings windows a fully solid dark background instead of translucent art.",
        default = false,
        compact = true,
    },
}

local DB
local settingsWindow, statusText
local optionChecks, optionRows, settingsPages, tabButtons = {}, {}, {}, {}
local activeTab = "BLIZZARD UI"
local mailNative, mailGuide, mailGuideActive
local mailLayoutHooked = setmetatable({}, {__mode = "k"})
local waitingForCombat = false

-- Native Blizzard controls are hidden by moving their containers.
-- Addon minimap buttons may be moved separately to an optional icon row.
local hiddenParent = CreateFrame("Frame")
hiddenParent:Hide()
local originalRaidManagerParent
local capturedRaidManagerParent = false
local originalBagParents, originalMenuParents = {}, {}
local originalDielParents = {}
local originalMinimapParents = {}
local originalTrackingParents = {}
local originalMapHeaderParents = {}
local originalCalendarParents = {}
-- Keep the actual addon buttons and their original anchors. Never create dummy buttons.
local iconEntries = {}
local iconRow, iconRowHandle
local iconTickerStarted = false
local iconManagerWindow, iconManagerContent
local iconManagerRows = {}
local RefreshIconManager, OpenIconManager

local savedActionBarPoints
local centeredActionBar
local actionBarOldPositionProxy
local savedDependentPoints = {}
local editModeExitHooked = false

local function Message(message)
    if DEFAULT_CHAT_FRAME then
        DEFAULT_CHAT_FRAME:AddMessage(PREFIX .. ": " .. message)
    end
end

-- A 100%-opaque WHITE8X8 layer is needed: WoW's standard dark dialog
-- background texture itself contains transparency, even at alpha 1.
local function ApplyWindowBackground(window)
    if not window then return end
    if not window.opaqueBacking then
        local backing = window:CreateTexture(nil, "BACKGROUND", nil, -7)
        backing:SetColorTexture(0.035, 0.030, 0.025, 1)
        backing:SetPoint("TOPLEFT", window, "TOPLEFT", 12, -12)
        backing:SetPoint("BOTTOMRIGHT", window, "BOTTOMRIGHT", -12, 12)
        window.opaqueBacking = backing
    end
    window.opaqueBacking:SetShown(DB and DB.solidBackground or false)
end

local function AddShadyFooter(window, y)
    local tribute = window:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
    tribute:SetPoint("BOTTOM", window, "BOTTOM", 0, y or 17)
    if not pcall(tribute.SetFont, tribute, "Fonts\\MORPHEUS.TTF", 12, "") then
        -- GameFontNormalSmall remains in place when Morpheus is unavailable.
    end
    tribute:SetText("RIP Shady")
    tribute:SetTextColor(0.83, 0.64, 0.33, 0.8)
    return tribute
end

local function InCombat()
    return type(InCombatLockdown) == "function" and InCombatLockdown()
end

local function ActionHeroShowsDefaultBottomUI()
    local isLoaded = C_AddOns and C_AddOns.IsAddOnLoaded or IsAddOnLoaded
    return isLoaded and isLoaded("ActionHero")
        and type(ActionHeroDB) == "table" and ActionHeroDB.defaultBottomView == true
end

local function BothBarsHidden()
    return DB and DB.hideBagButtons and DB.hideMicroMenu
end

local function UpdateStatus()
    if not statusText then return end
    if waitingForCombat and InCombat() then
        statusText:SetText("|cffffc36aChange queued until combat ends.|r")
    else
        statusText:SetText("Changes save automatically. Press Esc to close.")
    end
end

local function HideWithParent(frame, originalParents)
    if not frame then return end
    if originalParents[frame] == nil then
        originalParents[frame] = frame:GetParent() or UIParent
    end
    if frame:GetParent() ~= hiddenParent then
        frame:SetParent(hiddenParent)
    end
end

local function RestoreParents(originalParents)
    for frame, parent in pairs(originalParents) do
        if frame:GetParent() == hiddenParent then
            frame:SetParent(parent)
        end
        originalParents[frame] = nil
    end
end

local function ApplyRaidManager()
    local manager = _G.CompactRaidFrameManager
    if not manager then return end
    if DB.hideRaidManager then
        if not capturedRaidManagerParent then
            originalRaidManagerParent = manager:GetParent()
            capturedRaidManagerParent = true
        end
        if manager:GetParent() ~= hiddenParent then
            manager:SetParent(hiddenParent)
        end
    elseif capturedRaidManagerParent and manager:GetParent() == hiddenParent then
        manager:SetParent(originalRaidManagerParent or UIParent)
    end
end

-- Native Forever container. Avoid hiding/hooking individual protected bag slots.
local FALLBACK_BAG_BUTTONS = {
    "MainMenuBarBackpackButton", "CharacterBag0Slot", "CharacterBag1Slot",
    "CharacterBag2Slot", "CharacterBag3Slot", "CharacterBag4Slot",
    "ReagentBagSlot", "KeyRingButton", "BagBarExpandToggle",
}

local function ApplyBagButtons()
    if not DB.hideBagButtons or ActionHeroShowsDefaultBottomUI() then
        RestoreParents(originalBagParents)
    elseif _G.BagsBar then
        HideWithParent(_G.BagsBar, originalBagParents)
    else
        for _, frameName in ipairs(FALLBACK_BAG_BUTTONS) do
            HideWithParent(_G[frameName], originalBagParents)
        end
    end
end

-- Forever exposes MicroMenu; some layouts expose MicroMenuContainer instead.
-- Move only the shared menu container: directly hiding micro buttons can taint combat UI.
local function ApplyMicroMenu()
    if not DB.hideMicroMenu or ActionHeroShowsDefaultBottomUI() then
        RestoreParents(originalMenuParents)
        return
    end
    local menu = _G.MicroMenu or _G.MicroMenuContainer
    if menu then
        HideWithParent(menu, originalMenuParents)
    end
end

-- WoW Forever's native day/night orb is MinimapCluster.DielFrame.
-- Reparent just this indicator to our hidden frame, preserving the current
-- minimap/addon parent so unchecking returns it to its previous location.
-- Reparenting is reliable even when Blizzard refreshes the indicator for
-- Edit Mode or sunrise/sunset; no other minimap button is touched.
local function ApplyDayNightIcon()
    if not DB.hideDielFrame then
        RestoreParents(originalDielParents)
        return
    end
    local cluster = _G.MinimapCluster
    local diel = cluster and cluster.DielFrame
    if diel then
        HideWithParent(diel, originalDielParents)
    end
end

-- Blizzard Forever can anchor the entire bottom *stack* to MainActionBar.
-- Move only MainActionBar, then redirect the *other* bars' anchor references
-- to a stationary, invisible placeholder at MainActionBar's original location.
-- This keeps Action Bar 2+, experience/reputation bars, etc. exactly in place.
local function CaptureActionBarPoints(frame)
    local points = {}
    for i = 1, frame:GetNumPoints() do
        local point, relativeFrame, relativePoint, x, y = frame:GetPoint(i)
        if point then
            points[#points + 1] = {point, relativeFrame, relativePoint, x or 0, y or 0}
        end
    end
    if #points == 0 then return nil end
    return points
end

local function SetFramePoints(frame, points)
    if not frame or not points then return end
    frame:ClearAllPoints()
    for _, point in ipairs(points) do
        frame:SetPoint(point[1], point[2], point[3], point[4], point[5])
    end
end


-- Forever's minimap header consists of separate child frames. The calendar is
-- GameTimeFrame and is intentionally NOT part of the Map/Zone/Time toggle.
local function ApplyTrackingButton()
    if not DB.hideMinimapTracking then
        RestoreParents(originalTrackingParents)
        return
    end
    local cluster = _G.MinimapCluster
    local tracking = cluster and cluster.Tracking
    if tracking then
        HideWithParent(tracking, originalTrackingParents)
    else
        HideWithParent(_G.MiniMapTrackingButton, originalTrackingParents)
    end
end

local function ApplyMapHeader()
    if not DB.hideMinimapHeader then
        RestoreParents(originalMapHeaderParents)
        return
    end
    local cluster = _G.MinimapCluster
    if cluster and cluster.ZoneTextButton then
        HideWithParent(cluster.ZoneTextButton, originalMapHeaderParents)
    else
        HideWithParent(_G.MinimapZoneTextButton, originalMapHeaderParents)
    end
    HideWithParent(_G.MiniMapWorldMapButton, originalMapHeaderParents)
    HideWithParent(_G.TimeManagerClockButton, originalMapHeaderParents)
end

local function ApplyCalendar()
    if DB.hideMinimapCalendar then
        HideWithParent(_G.GameTimeFrame, originalCalendarParents)
    else
        RestoreParents(originalCalendarParents)
    end
end

-- Support both Forever's modern MinimapCluster indicator and legacy
-- MiniMapMailFrame. Never move the mailbox/inbox window itself.
local function FindMailIconFrame()
    local cluster = _G.MinimapCluster
    local candidates = {
        cluster and cluster.IndicatorFrame and cluster.IndicatorFrame.MailFrame,
        _G.MiniMapMailFrame,
        cluster and cluster.MailFrame,
    }
    -- Do not use ipairs here: the first layout may be absent while a later
    -- candidate exists, and ipairs would stop at the first nil entry.
    for index = 1, 3 do
        local candidate = candidates[index]
        if candidate and candidate.GetObjectType then
            local kind = candidate:GetObjectType()
            if kind == "Frame" or kind == "Button" or kind == "CheckButton" then
                return candidate
            end
        end
    end
    -- In some client layouts only the texture is exported globally.
    local icon = _G.MiniMapMailIcon
    return icon and icon.GetParent and icon:GetParent() or nil
end

local function MailDefaultPosition(frame)
    local x, y
    if frame and frame.GetCenter then x, y = frame:GetCenter() end
    local uiX, uiY = UIParent:GetCenter()
    if x and y and uiX and uiY then
        local effective = frame:GetEffectiveScale() / UIParent:GetEffectiveScale()
        return x * effective - uiX, y * effective - uiY
    end
    -- Fallback only for client layouts where the mail indicator is not yet made.
    local map = _G.Minimap
    if map and map.GetCenter then
        x, y = map:GetCenter()
        if x and y then
            local ratio = map:GetEffectiveScale() / UIParent:GetEffectiveScale()
            return x * ratio - (uiX or 0), y * ratio - (uiY or 0)
        end
    end
    return UIParent:GetWidth() / 2 - 200, UIParent:GetHeight() / 2 - 145
end

-- The mail frame is a child of MinimapCluster.IndicatorFrame, which uses
-- HorizontalLayoutFrame. Blizzard's UPDATE_PENDING_MAIL handler calls
-- self:GetParent():Layout(). NEVER reparent that native frame to UIParent or
-- to hiddenParent: UIParent has no Layout method and mail updates will error.
local function EnsureMailNativeParent(frame)
    local cluster = _G.MinimapCluster
    local indicator = cluster and cluster.IndicatorFrame
    if indicator and indicator.MailFrame == frame and frame:GetParent() ~= indicator then
        -- Repair a frame detached by an older HideThisManager mail mover.
        frame:SetParent(indicator)
    end
end

local function CaptureMailNative(frame)
    if mailNative and mailNative.frame == frame then return end
    mailNative = {
        frame = frame,
        parent = frame:GetParent() or UIParent,
        points = CaptureActionBarPoints(frame),
        strata = frame:GetFrameStrata(),
        alpha = frame:GetAlpha(),
        mouseEnabled = frame:IsMouseEnabled(),
    }
end

-- Reanchor the child only; leave its parent and Blizzard OnEvent/mixins intact.
local function PositionMailIcon(frame)
    if not DB or InCombat() or DB.hideMailIcon or not DB.moveMailIcon then return end
    if type(DB.mailX) ~= "number" or type(DB.mailY) ~= "number" then return end
    frame:ClearAllPoints()
    frame:SetPoint("CENTER", UIParent, "CENTER", DB.mailX, DB.mailY)
end

local function HookMailLayout(frame)
    local parent = frame and frame:GetParent()
    if not parent or type(parent.Layout) ~= "function"
        or mailLayoutHooked[parent] or type(hooksecurefunc) ~= "function" then
        return
    end
    -- Blizzard's layout may reanchor its mail child after UPDATE_PENDING_MAIL.
    -- Reapply our screen position *after* the native layout has finished.
    local ok = pcall(hooksecurefunc, parent, "Layout", function()
        if DB and mailNative and mailNative.frame == frame and DB.moveMailIcon
            and not DB.hideMailIcon and not InCombat() then
            PositionMailIcon(frame)
        end
    end)
    if ok then mailLayoutHooked[parent] = true end
end

local function RestoreMailNative()
    if not mailNative or not mailNative.frame then return end
    local frame = mailNative.frame
    if frame:GetParent() ~= mailNative.parent then
        frame:SetParent(mailNative.parent or UIParent)
    end
    frame:SetAlpha(mailNative.alpha or 1)
    frame:EnableMouse(mailNative.mouseEnabled)
    if mailNative.strata then frame:SetFrameStrata(mailNative.strata) end
    local parent = frame:GetParent()
    if parent and type(parent.Layout) == "function" then
        parent:Layout()   -- Let Blizzard reestablish its own native layout.
    elseif mailNative.points then
        SetFramePoints(frame, mailNative.points)
    end
end

local function ApplyMailIcon()
    if not DB or InCombat() then
        if DB and InCombat() then waitingForCombat = true; UpdateStatus() end
        return
    end
    local frame = FindMailIconFrame()
    if not frame then return end
    EnsureMailNativeParent(frame)
    if not (DB.hideMailIcon or DB.moveMailIcon) then
        if mailNative and mailNative.frame == frame then
            RestoreMailNative()
            mailNative = nil
        end
        return
    end
    CaptureMailNative(frame)
    -- Alpha+mouse hiding preserves Blizzard's mandatory Layout() parent.
    -- This leaves the native indicator slot reserved in its layout.
    if DB.hideMailIcon then
        frame:SetAlpha(0)
        frame:EnableMouse(false)
        return
    end
    frame:SetAlpha(mailNative.alpha or 1)
    frame:EnableMouse(mailNative.mouseEnabled)
    if type(DB.mailX) ~= "number" or type(DB.mailY) ~= "number" then
        DB.mailX, DB.mailY = MailDefaultPosition(frame)
    end
    HookMailLayout(frame)
    PositionMailIcon(frame)
end

local function UpdateMailGuidePosition()
    if not mailGuide or not DB then return end
    local x, y = DB.mailX, DB.mailY
    if type(x) ~= "number" or type(y) ~= "number" then
        x, y = MailDefaultPosition(FindMailIconFrame())
    end
    mailGuide:ClearAllPoints()
    mailGuide:SetPoint("CENTER", UIParent, "CENTER", x, y)
end

local function BuildMailGuide()
    if mailGuide then return mailGuide end
    local guide = CreateFrame("Frame", "HideThisManagerMailPositionGuide", UIParent, "BackdropTemplate")
    mailGuide = guide
    guide:SetSize(100, 42)
    guide:SetMovable(true)
    guide:SetClampedToScreen(true)
    guide:EnableMouse(true)
    guide:SetFrameStrata("TOOLTIP")
    guide:SetBackdrop({
        bgFile = "Interface\\Buttons\\WHITE8X8",
        edgeFile = "Interface\\Tooltips\\UI-Tooltip-Border",
        edgeSize = 13,
        insets = {left = 3, right = 3, top = 3, bottom = 3},
    })
    guide:SetBackdropColor(0.05, 0.035, 0.02, 0.8)
    guide:SetBackdropBorderColor(0.92, 0.72, 0.3, 1)
    local label = guide:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
    label:SetPoint("CENTER", guide, "CENTER", 0, 0)
    label:SetText("DRAG MAIL")
    guide:RegisterForDrag("LeftButton")
    guide:SetScript("OnDragStart", function(self)
        if not InCombat() then self:StartMoving() end
    end)
    guide:SetScript("OnDragStop", function(self)
        self:StopMovingOrSizing()
        if InCombat() then return end
        local x, y = self:GetCenter()
        local ux, uy = UIParent:GetCenter()
        if x and y and ux and uy then
            DB.mailX, DB.mailY = x - ux, y - uy
            UpdateMailGuidePosition()
            ApplyMailIcon()
        end
    end)
    guide:SetScript("OnEnter", function(self)
        if GameTooltip then
            GameTooltip:SetOwner(self, "ANCHOR_BOTTOM")
            GameTooltip:SetText("Drag to position Blizzard's mail notification")
            GameTooltip:AddLine("The normal envelope still only shows when mail arrives.", 0.8, 0.8, 0.8)
            GameTooltip:Show()
        end
    end)
    guide:SetScript("OnLeave", function() if GameTooltip then GameTooltip:Hide() end end)
    guide:Hide()
    return guide
end

local function ShowMailGuide(enabled)
    mailGuideActive = enabled and DB and DB.moveMailIcon or false
    if mailGuideActive then
        if InCombat() then
            mailGuideActive = false
            Message("Mail icon movement is unavailable in combat.")
        else
            ApplyMailIcon()
            local guide = BuildMailGuide()
            UpdateMailGuidePosition()
            guide:Show()
            guide:Raise()
        end
    end
    if not mailGuideActive and mailGuide then mailGuide:Hide() end
    if settingsWindow and settingsWindow.placeMailButton then
        settingsWindow.placeMailButton:SetText(mailGuideActive and "Done" or "Place")
    end
end

local function ResetMailPosition()
    if not DB then return end
    DB.mailX, DB.mailY = nil, nil
    DB.moveMailIcon = false
    ShowMailGuide(false)
    ApplyMailIcon()
end

-- Only collect demonstrable addon-owned buttons. v1.3.0 also captured every
-- small Button beneath MinimapCluster, which included Blizzard event icons,
-- tracking buttons, pings and alerts. The row must NEVER use size alone.
local BUILTIN_ICON_NAMES = {
    GameTimeFrame = true, MiniMapWorldMapButton = true,
    MiniMapTrackingButton = true, MinimapZoneTextButton = true,
    TimeManagerClockButton = true, MiniMapMailFrame = true,
    AddonCompartmentFrame = true, QueueStatusMinimapButton = true,
    MiniMapBattlefieldFrame = true, MinimapZoomIn = true,
    MinimapZoomOut = true, MinimapBackdrop = true,
    ExpansionLandingPageMinimapButton = true,
    GarrisonLandingPageMinimapButton = true,
    GuildInstanceDifficulty = true, GuildInstanceDifficultyIndicator = true,
    MiniMapInstanceDifficulty = true, MiniMapChallengeMode = true,
    MiniMapLFGFrame = true, MinimapCluster = true,
    HideThisManagerIconRow = true,
}

local BUILTIN_ICON_PREFIXES = {
    "MiniMapMail", "MiniMapTracking", "MiniMapWorldMap", "MinimapZoom",
    "MinimapZone", "MinimapCluster", "GameTime", "QueueStatus",
    "AddonCompartment", "GuildInstance", "ExpansionLanding",
    "GarrisonLanding", "TimeManager", "BattlefieldMinimap",
    "DurabilityFrame", "VehicleSeatIndicator",
    "UIWidget", "LFGMinimap", "LookingForGroup",
}

local function NormalizedName(value)
    if type(value) ~= "string" then return "" end
    return value:lower():gsub("[^%w]", "")
end

local function IsAddonNamedButton(name)
    if type(name) ~= "string" then return false end
    local lower = name:lower()
    -- This form is used by many standalone minimap button implementations.
    -- Reject generic 'MinimapButton' which may belong to Blizzard.
    if lower:match("^libdbicon10_.+") then return true end
    local suffix = lower:find("minimap", 1, true) or lower:find("broker", 1, true)
        or lower:find("button", 1, true) or lower:find("icon", 1, true)
    if not suffix then return false end

    -- Check that its name is actually associated with an installed addon,
    -- rather than assuming every small icon is an addon button.
    local count = (C_AddOns and C_AddOns.GetNumAddOns and C_AddOns.GetNumAddOns())
        or (GetNumAddOns and GetNumAddOns()) or 0
    for index = 1, count do
        local addonName
        if C_AddOns and C_AddOns.GetAddOnInfo then
            local info = C_AddOns.GetAddOnInfo(index)
            addonName = type(info) == "table" and info.name or info
        elseif GetAddOnInfo then
            addonName = GetAddOnInfo(index)
        end
        local token = NormalizedName(addonName)
        if #token >= 4 and name ~= "HideThisManagerIconRow" then
            local frameToken = NormalizedName(name)
            if frameToken:sub(1, #token) == token then
                return true
            end
        end
    end
    return false
end

local function IsBlizzardMinimapControl(button)
    local name = button.GetName and button:GetName()
    if name then
        if BUILTIN_ICON_NAMES[name] then return true end
        for _, prefix in ipairs(BUILTIN_ICON_PREFIXES) do
            if name:sub(1, #prefix) == prefix then return true end
        end
    end
    local cluster = _G.MinimapCluster
    local ancestor = button
    for _ = 1, 9 do
        ancestor = ancestor and ancestor.GetParent and ancestor:GetParent()
        if not ancestor then break end
        if cluster and (ancestor == cluster.Tracking or ancestor == cluster.ZoneTextButton
            or ancestor == cluster.IndicatorFrame or ancestor == cluster.DielFrame
            or ancestor == cluster.Clock or ancestor == cluster.Calendar
            or ancestor == cluster.MailFrame or ancestor == cluster.InstanceDifficulty) then
            return true
        end
        if ancestor == _G.GameTimeFrame or ancestor == _G.MiniMapMailFrame
            or ancestor == _G.MiniMapTrackingButton
            or ancestor == _G.AddonCompartmentFrame then
            return true
        end
    end
    return false
end

-- Do not mistake an addon action button elsewhere on screen for one of
-- its *minimap* buttons. Its parent or an anchor must belong to the minimap.
local function IsNearMinimap(button)
    local cluster = _G.MinimapCluster
    local minimap = _G.Minimap
    local ancestor = button
    for _ = 1, 8 do
        if ancestor == minimap or ancestor == cluster or ancestor == _G.MinimapBackdrop then
            return true
        end
        ancestor = ancestor and ancestor.GetParent and ancestor:GetParent()
        if not ancestor then break end
    end
    if button.GetNumPoints and button.GetPoint then
        for i = 1, button:GetNumPoints() do
            local _, relative = button:GetPoint(i)
            if relative == minimap or relative == cluster or relative == _G.MinimapBackdrop
                or relative == (cluster and cluster.MinimapContainer) then
                return true
            end
        end
    end
    return false
end

-- Blizzard can return forbidden/tainted frames from GetChildren(), including
-- completely unrelated dialogs parented to UIParent. Never call any widget
-- method on one without an accessibility guard; a thrown widget error is a
-- skipped candidate, not an error propagated through the addon scanner.
local function IsAccessibleIconCandidate(button)
    if not button then return false end
    local ok, allowed = pcall(function()
        return not (button.IsForbidden and button:IsForbidden())
    end)
    return ok and allowed
end

local function SafeIconName(button)
    if not IsAccessibleIconCandidate(button) then return nil end
    local ok, name = pcall(function()
        return button.GetName and button:GetName()
    end)
    return ok and type(name) == "string" and name or nil
end

local function IsAddonMinimapIcon(button)
    if not button or not button.GetObjectType then return false end
    local kind = button:GetObjectType()
    if kind ~= "Button" and kind ~= "CheckButton" then return false end
    if button == iconRow or button == iconRowHandle then return false end
    if button.IsProtected and button:IsProtected() then return false end
    if IsBlizzardMinimapControl(button) then return false end
    if not iconEntries[button] and not IsNearMinimap(button) then return false end
    local name = button.GetName and button:GetName()

    -- Strong evidence: registered LibDataBroker icon or genuine data object.
    if name and name:match("^LibDBIcon10_.+") then return true end
    if button.dataObject then return true end
    if button.db and (button.db.minimapPos or button.db.minimap) then return true end

    -- Non-LibDB buttons need a name linked to an installed addon.
    return IsAddonNamedButton(name)
end

-- A frame name is persistent between sessions, unlike tostring(frame). In the
-- uncommon case of an unnamed data object, use its explicitly registered name.
local function IconPersistentKey(button)
    local name = SafeIconName(button)
    if name and name ~= "" then return name end
    if not IsAccessibleIconCandidate(button) then return nil end
    local ok, dataName = pcall(function()
        return button.dataObject and button.dataObject.name
    end)
    if ok and type(dataName) == "string" and dataName ~= "" then
        return "DataObject:" .. dataName
    end
    return nil
end

local function ArrangeAddonIcons(icons)
    local order = {}
    if DB and type(DB.iconOrder) == "table" then
        for index, key in ipairs(DB.iconOrder) do
            if type(key) == "string" then order[key] = index end
        end
    end
    table.sort(icons, function(a, b)
        local aKey = IconPersistentKey(a) or ""
        local bKey = IconPersistentKey(b) or ""
        local aPos, bPos = order[aKey], order[bKey]
        if aPos and bPos and aPos ~= bPos then return aPos < bPos end
        if aPos then return true end
        if bPos then return false end
        return aKey:lower() < bKey:lower()
    end)
    return icons
end

local function CollectAddonIcons()
    local icons, seen = {}, {}
    local function Add(button)
        if not button or seen[button] or not IsAccessibleIconCandidate(button) then return end
        -- Do not let one inaccessible/forbidden frame break the entire scan.
        -- A generic Blizzard UI dialog is never a valid minimap icon.
        local ok, isAddonIcon = pcall(IsAddonMinimapIcon, button)
        if not ok or not isAddonIcon then return end
        seen[button] = true
        icons[#icons + 1] = button
    end
    local cluster = _G.MinimapCluster
    local roots = {}
    local function AddRoot(root)
        if root and IsAccessibleIconCandidate(root) then roots[#roots + 1] = root end
    end
    AddRoot(_G.Minimap)
    AddRoot(_G.MinimapBackdrop)
    AddRoot(cluster and cluster.MinimapContainer)
    AddRoot(cluster)
    -- Scan UIParent at depth 1 only. Crucially, filter on a safe, verified
    -- addon-like name BEFORE trying GetObjectType on its thousands of children.
    -- This retains addon buttons anchored to Minimap but parented to UIParent.
    AddRoot(_G.UIParent)
    local visited = {}
    local function Scan(parent, depth)
        if not IsAccessibleIconCandidate(parent) or depth > 3 or visited[parent] then return end
        visited[parent] = true
        local ok, children = pcall(function()
            return parent.GetChildren and {parent:GetChildren()} or {}
        end)
        if not ok then return end
        for _, child in ipairs(children) do
            if IsAccessibleIconCandidate(child) then
                local underUIParent = parent == _G.UIParent
                if not underUIParent then
                    Add(child)
                else
                    -- No GetObjectType / GetParent on a random top-level frame.
                    local name = SafeIconName(child)
                    if name and IsAddonNamedButton(name) then Add(child) end
                end
                -- Do not recurse into third-party UI windows or built-in
                -- minimap controls which never contain addon buttons.
                if (not underUIParent or child == cluster or child == _G.Minimap
                    or child == _G.MinimapBackdrop)
                    and child ~= _G.MinimapBackdrop
                    and child ~= (cluster and cluster.Tracking)
                    and child ~= (cluster and cluster.ZoneTextButton)
                    and child ~= (cluster and cluster.DielFrame)
                    and child ~= (cluster and cluster.IndicatorFrame)
                    and child ~= _G.GameTimeFrame and child ~= _G.AddonCompartmentFrame then
                    Scan(child, depth + 1)
                end
            end
        end
    end
    for _, root in ipairs(roots) do Scan(root, 1) end

    -- LibDBIcon exposes registered buttons even after another addon has moved
    -- them. Calls into third-party registries may themselves throw, so each
    -- collection access is guarded and an invalid entry is skipped by Add().
    local stub = _G.LibStub
    if type(stub) == "table" or type(stub) == "function" then
        local ok, lib = pcall(stub, "LibDBIcon-1.0", true)
        if ok and lib then
            if type(lib.GetButtonList) == "function" then
                local namesOK, names = pcall(lib.GetButtonList, lib)
                if namesOK and type(names) == "table" then
                    for _, name in pairs(names) do
                        if type(name) == "string" then
                            local button = _G["LibDBIcon10_" .. name]
                            if type(lib.GetMinimapButton) == "function" then
                                local success, registered = pcall(lib.GetMinimapButton, lib, name)
                                if success and registered then button = registered end
                            end
                            Add(button)
                        end
                    end
                end
            end
            if type(lib.objects) == "table" then
                for _, button in pairs(lib.objects) do Add(button) end
            end
        end
    end
    for button in pairs(iconEntries) do Add(button) end
    return ArrangeAddonIcons(icons)
end

-- Compact, transparent, one-line-first strip. No big panel or black backing.
local ICON_SIZE, ICON_STEP, ICON_PER_LINE = 25, 31, 14
local ICON_HANDLE_WIDTH, ICON_PADDING = 12, 3
local function BuildIconRow()
    if iconRow then return iconRow end
    local row = CreateFrame("Frame", "HideThisManagerIconRow", UIParent)
    row:SetSize(48, 31)
    row:SetFrameStrata("HIGH")
    row:SetClampedToScreen(true)
    row:SetMovable(true)
    row:EnableMouse(false)
    if DB.iconRowX and DB.iconRowY then
        row:SetPoint("CENTER", UIParent, "CENTER", DB.iconRowX, DB.iconRowY)
    else
        row:SetPoint("TOPRIGHT", UIParent, "TOPRIGHT", -36, -110)
    end
    local handle = CreateFrame("Button", nil, row, "BackdropTemplate")
    handle:SetSize(ICON_HANDLE_WIDTH, ICON_SIZE)
    handle:SetPoint("TOPLEFT", row, "TOPLEFT", 0, -3)
    handle:SetBackdrop({bgFile = "Interface\\Buttons\\WHITE8X8"})
    handle:SetBackdropColor(0.1, 0.1, 0.1, 0.35)
    local text = handle:CreateFontString(nil, "OVERLAY", "GameFontDisableSmall")
    text:SetPoint("CENTER", handle, "CENTER", 0, 0)
    text:SetText("::")
    handle:RegisterForDrag("LeftButton")
    handle:SetScript("OnDragStart", function()
        if not InCombat() then row:StartMoving() end
    end)
    handle:SetScript("OnDragStop", function()
        row:StopMovingOrSizing()
        local x, y = row:GetCenter()
        local ux, uy = UIParent:GetCenter()
        if x and y and ux and uy then
            DB.iconRowX, DB.iconRowY = x - ux, y - uy
            row:ClearAllPoints()
            row:SetPoint("CENTER", UIParent, "CENTER", DB.iconRowX, DB.iconRowY)
        end
    end)
    handle:SetScript("OnEnter", function()
        if GameTooltip then
            GameTooltip:SetOwner(handle, "ANCHOR_LEFT")
            GameTooltip:SetText("Drag icon row  |  Right-click grip to organize")
            GameTooltip:Show()
        end
    end)
    handle:SetScript("OnLeave", function() if GameTooltip then GameTooltip:Hide() end end)
    handle:RegisterForClicks("AnyUp")
    handle:SetScript("OnClick", function(_, mouseButton)
        if mouseButton == "RightButton" and type(OpenIconManager) == "function" then
            OpenIconManager()
        end
    end)
    iconRow = row
    iconRowHandle = handle
    row:Hide()
    return row
end

local function RestoreIconButton(button, entry)
    if not button or not entry or not button.GetParent then return end
    if button:GetParent() == hiddenParent or button:GetParent() == iconRow then
        button:SetParent(entry.parent or _G.Minimap or UIParent)
        SetFramePoints(button, entry.points)
    end
    if entry.scale and button.SetScale then button:SetScale(entry.scale) end
    if entry.dragChanged and button.SetScript then
        button:SetScript("OnDragStart", entry.dragStart)
        button:SetScript("OnDragStop", entry.dragStop)
    end
end

local function RestoreAddonIcons()
    for button, entry in pairs(iconEntries) do
        RestoreIconButton(button, entry)
        iconEntries[button] = nil
    end
    if iconRow then iconRow:Hide() end
end

local function ApplyAddonIcons()
    local hideIcons = DB.hideMinimapIcons
    local makeRow = DB.hideMinimap and DB.showMinimapIconRow and not hideIcons
    if not hideIcons and not makeRow then
        RestoreAddonIcons()
        return
    end
    local row = makeRow and BuildIconRow() or nil
    local target = row or hiddenParent
    local icons = CollectAddonIcons()
    local shownIcons = {}
    for _, button in ipairs(icons) do
        if not iconEntries[button] then
            if button.IsShown and button:IsShown() then
                iconEntries[button] = {
                    parent = button:GetParent(),
                    points = CaptureActionBarPoints(button),
                    scale = button.GetScale and button:GetScale() or 1,
                    dragStart = button.GetScript and button:GetScript("OnDragStart"),
                    dragStop = button.GetScript and button:GetScript("OnDragStop"),
                }
            end
        end
        local entry = iconEntries[button]
        if entry then
            if button:GetParent() ~= target then button:SetParent(target) end
            if makeRow and not (DB.iconHidden and DB.iconHidden[IconPersistentKey(button)]) then
                -- Disable button-specific minimap repositioning while in row.
                -- Left-click still invokes the original addon icon action.
                if not entry.dragChanged and button.SetScript then
                    button:SetScript("OnDragStart", nil)
                    button:SetScript("OnDragStop", nil)
                    entry.dragChanged = true
                end
                if button.SetScale then
                    local w = button.GetWidth and button:GetWidth() or ICON_SIZE
                    local h = button.GetHeight and button:GetHeight() or ICON_SIZE
                    local maxSide = math.max(w, h, 1)
                    button:SetScale((entry.scale or 1) * math.min(1, ICON_SIZE / maxSide))
                end
                shownIcons[#shownIcons + 1] = button
            else
                -- An individually excluded icon stays hidden, without being
                -- deleted or disabled. Its original parent/points remain saved.
                if button:GetParent() ~= hiddenParent then
                    button:SetParent(hiddenParent)
                end
                if entry.scale and button.SetScale then button:SetScale(entry.scale) end
            end
        end
    end
    if iconRow then
        if makeRow then
            -- Even if all shortcuts are unchecked, retain the little grip so
            -- the user can right-click it and restore icons.
            local count = math.min(#shownIcons, ICON_PER_LINE)
            local lines = math.ceil(#shownIcons / ICON_PER_LINE)
            local width = ICON_HANDLE_WIDTH + ICON_PADDING * 2 + count * ICON_STEP
            local height = ICON_PADDING * 2 + math.max(lines, 1) * ICON_STEP
            row:SetSize(width, height)
            for index, button in ipairs(shownIcons) do
                button:ClearAllPoints()
                button:SetPoint("TOPLEFT", row, "TOPLEFT",
                    ICON_HANDLE_WIDTH + ICON_PADDING + ((index - 1) % ICON_PER_LINE) * ICON_STEP,
                    -ICON_PADDING - math.floor((index - 1) / ICON_PER_LINE) * ICON_STEP)
            end
            row:Show()
        else
            iconRow:Hide()
        end
    end
end

-- Organization is intentionally separated from the on-screen strip. The
-- strip keeps its v1.3.2 25px icons, 31px spacing and tiny transparent grip.
-- Moving any minimap button during combat can taint protected UI. Save user
-- choices immediately and apply the change after PLAYER_REGEN_ENABLED.
local function RequestIconRowUpdate()
    if InCombat() then
        waitingForCombat = true
        UpdateStatus()
    else
        ApplyAddonIcons()
    end
end

local function PrettyIconName(key)
    key = tostring(key or "Unknown addon")
    key = key:gsub("^LibDBIcon10_", "")
    key = key:gsub("^DataObject:", "")
    return key
end

local function MoveIconInOrder(key, direction)
    local icons = CollectAddonIcons()
    local keys = {}
    local position
    for _, button in ipairs(icons) do
        local itemKey = IconPersistentKey(button)
        if itemKey then
            keys[#keys + 1] = itemKey
            if itemKey == key then position = #keys end
        end
    end
    if not position or not keys[position + direction] then return end
    keys[position], keys[position + direction] = keys[position + direction], keys[position]
    DB.iconOrder = keys
    RequestIconRowUpdate()
    if RefreshIconManager then RefreshIconManager() end
end

RefreshIconManager = function()
    if not iconManagerWindow or not iconManagerContent or not DB then return end
    local icons = CollectAddonIcons()
    local index = 0
    local showing = 0
    for _, button in ipairs(icons) do
        local key = IconPersistentKey(button)
        if key then
            index = index + 1
            local row = iconManagerRows[index]
            if not row then
                row = CreateFrame("Frame", nil, iconManagerContent, "BackdropTemplate")
                row:SetSize(389, 34)
                row:SetBackdrop({bgFile = "Interface\\Buttons\\WHITE8X8"})
                row:SetBackdropColor(1, 1, 1, 0.055)
                local check = CreateFrame("CheckButton", nil, row, "UICheckButtonTemplate")
                check:SetSize(24, 24)
                check:SetPoint("LEFT", row, "LEFT", 5, 0)
                row.check = check
                local label = row:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
                label:SetPoint("LEFT", row, "LEFT", 38, 0)
                label:SetWidth(256)
                label:SetJustifyH("LEFT")
                row.label = label
                local up = CreateFrame("Button", nil, row, "UIPanelButtonTemplate")
                up:SetSize(34, 24)
                up:SetPoint("RIGHT", row, "RIGHT", -43, 0)
                up:SetText("^")
                row.up = up
                local down = CreateFrame("Button", nil, row, "UIPanelButtonTemplate")
                down:SetSize(34, 24)
                down:SetPoint("RIGHT", row, "RIGHT", -6, 0)
                down:SetText("v")
                row.down = down
                iconManagerRows[index] = row
            end
            row:ClearAllPoints()
            row:SetPoint("TOPLEFT", iconManagerContent, "TOPLEFT", 0, -((index - 1) * 37))
            row:Show()
            local enabled = not DB.iconHidden[key]
            if enabled then showing = showing + 1 end
            row.check:SetChecked(enabled)
            row.label:SetText(PrettyIconName(key))
            row.check:SetScript("OnClick", function(self)
                if self:GetChecked() then
                    DB.iconHidden[key] = nil
                else
                    DB.iconHidden[key] = true
                end
                RequestIconRowUpdate()
                RefreshIconManager()
            end)
            row.up:SetEnabled(index > 1)
            row.down:SetEnabled(index < #icons)
            row.up:SetScript("OnClick", function() MoveIconInOrder(key, -1) end)
            row.down:SetScript("OnClick", function() MoveIconInOrder(key, 1) end)
        end
    end
    for i = index + 1, #iconManagerRows do iconManagerRows[i]:Hide() end
    iconManagerContent:SetHeight(math.max(40, index * 37))
    if iconManagerWindow.counter then
        iconManagerWindow.counter:SetText(showing .. " / " .. index .. " addon icons in row")
    end
end

OpenIconManager = function()
    if not DB then return end
    if not iconManagerWindow then
        local window = CreateFrame("Frame", "HideThisManagerIconManager", UIParent, "BackdropTemplate")
        iconManagerWindow = window
        window:SetSize(466, 540)
        window:SetPoint("CENTER", UIParent, "CENTER", 190, 30)
        window:SetClampedToScreen(true)
        window:SetFrameStrata("DIALOG")
        window:SetMovable(true)
        window:EnableMouse(true)
        window:RegisterForDrag("LeftButton")
        window:SetScript("OnDragStart", function(self) self:StartMoving() end)
        window:SetScript("OnDragStop", function(self) self:StopMovingOrSizing() end)
        window:SetBackdrop({
            bgFile = "Interface\\DialogFrame\\UI-DialogBox-Background-Dark",
            edgeFile = "Interface\\DialogFrame\\UI-DialogBox-Border",
            tile = true, tileSize = 32, edgeSize = 32,
            insets = {left = 10, right = 10, top = 10, bottom = 10},
        })
        window:SetBackdropColor(0.075, 0.085, 0.10, 0.98)
        ApplyWindowBackground(window)
        local title = window:CreateFontString(nil, "OVERLAY", "GameFontNormalLarge")
        title:SetPoint("TOPLEFT", window, "TOPLEFT", 23, -28)
        title:SetText("Manage Addon Icons")
        local subtitle = window:CreateFontString(nil, "OVERLAY", "GameFontDisableSmall")
        subtitle:SetPoint("TOPLEFT", window, "TOPLEFT", 23, -56)
        subtitle:SetText("Uncheck to remove from row. Use ^ / v to reorder.")
        local close = CreateFrame("Button", nil, window, "UIPanelCloseButton")
        close:SetPoint("TOPRIGHT", window, "TOPRIGHT", -8, -8)
        close:SetScript("OnClick", function() window:Hide() end)
        local scroll = CreateFrame("ScrollFrame", nil, window, "UIPanelScrollFrameTemplate")
        scroll:SetPoint("TOPLEFT", window, "TOPLEFT", 22, -93)
        scroll:SetPoint("BOTTOMRIGHT", window, "BOTTOMRIGHT", -42, 83)
        iconManagerContent = CreateFrame("Frame", nil, scroll)
        iconManagerContent:SetSize(389, 40)
        scroll:SetScrollChild(iconManagerContent)
        local counter = window:CreateFontString(nil, "OVERLAY", "GameFontDisableSmall")
        counter:SetPoint("BOTTOMLEFT", window, "BOTTOMLEFT", 25, 61)
        window.counter = counter
        local showAll = CreateFrame("Button", nil, window, "UIPanelButtonTemplate")
        showAll:SetSize(122, 25)
        showAll:SetPoint("BOTTOMLEFT", window, "BOTTOMLEFT", 24, 23)
        showAll:SetText("Show All")
        showAll:SetScript("OnClick", function()
            DB.iconHidden = {}
            RequestIconRowUpdate()
            RefreshIconManager()
        end)
        local resetOrder = CreateFrame("Button", nil, window, "UIPanelButtonTemplate")
        resetOrder:SetSize(128, 25)
        resetOrder:SetPoint("BOTTOMRIGHT", window, "BOTTOMRIGHT", -23, 23)
        resetOrder:SetText("Reset Order")
        resetOrder:SetScript("OnClick", function()
            DB.iconOrder = {}
            RequestIconRowUpdate()
            RefreshIconManager()
        end)
        AddShadyFooter(window, 13)
        if type(UISpecialFrames) == "table" then
            table.insert(UISpecialFrames, "HideThisManagerIconManager")
        end
        window:Hide()
    end
    RefreshIconManager()
    ApplyWindowBackground(iconManagerWindow)
    iconManagerWindow:Show()
    iconManagerWindow:Raise()
end

local function ApplyEntireMinimap()
    if DB.hideMinimap then
        HideWithParent(_G.MinimapCluster, originalMinimapParents)
    else
        RestoreParents(originalMinimapParents)
    end
end

local function GatherBottomBarDependents()
    local result, seen = {}, {}
    local function Add(frame)
        if frame and not seen[frame] then
            seen[frame] = true
            result[#result + 1] = frame
        end
    end
    -- Prefer the exact bottom-bar roster of this client's Edit Mode.
    local util = _G.EditModeUtil
    if util and type(util.GetBottomActionBars) == "function" then
        for _, frame in ipairs(util:GetBottomActionBars()) do
            Add(frame)
        end
    end
    -- Cover layouts/versions where a bar isn't in Edit Mode's current roster.
    for _, name in ipairs({
        "MultiBarBottomLeft", "MultiBarBottomRight", "MultiBar5", "MultiBar6",
        "MultiBar7", "MultiBar8", "MainStatusTrackingBarContainer",
        "SecondaryStatusTrackingBarContainer", "StatusTrackingBarManager",
        "PetActionBar", "StanceBar", "PossessActionBar",
    }) do
        Add(_G[name])
    end
    return result
end

local function RestoreActionBarPosition()
    if not centeredActionBar or not savedActionBarPoints then return end
    -- Put the original base frame back first, then restore other bars' anchors.
    SetFramePoints(centeredActionBar, savedActionBarPoints)
    for frame, points in pairs(savedDependentPoints) do
        SetFramePoints(frame, points)
        savedDependentPoints[frame] = nil
    end
    centeredActionBar = nil
    savedActionBarPoints = nil
    if actionBarOldPositionProxy then
        actionBarOldPositionProxy:ClearAllPoints()
    end
end

local function ConfigureStationaryProxy(bar)
    if not actionBarOldPositionProxy then
        actionBarOldPositionProxy = CreateFrame("Frame", nil, UIParent)
        actionBarOldPositionProxy:EnableMouse(false)
    end
    local proxy = actionBarOldPositionProxy
    proxy:SetSize(bar:GetWidth(), bar:GetHeight())
    if proxy.SetScale then proxy:SetScale(bar:GetScale()) end
    SetFramePoints(proxy, savedActionBarPoints)
    return proxy
end

local function IsCurrentCenterOverride(bar)
    if centeredActionBar ~= bar or not savedActionBarPoints then return false end
    local point, relativeFrame, relativePoint, x = bar:GetPoint(1)
    return point == "CENTER" and relativeFrame == UIParent
        and relativePoint == "CENTER" and math.abs(x or 0) < 0.5
end

local function FixBottomStackAnchors(bar, proxy)
    for _, frame in ipairs(GatherBottomBarDependents()) do
        if frame ~= bar and frame.GetNumPoints and frame.GetPoint then
            local points = CaptureActionBarPoints(frame)
            if points then
                local found = false
                for _, point in ipairs(points) do
                    if point[2] == bar then
                        found = true
                        break
                    end
                end
                if found then
                    -- Save each Blizzard-authored anchor so turning the option
                    -- off fully restores the built-in stack behavior.
                    savedDependentPoints[frame] = points
                    local remapped = {}
                    for i, p in ipairs(points) do
                        remapped[i] = {p[1], p[2] == bar and proxy or p[2],
                            p[3], p[4], p[5]}
                    end
                    SetFramePoints(frame, remapped)
                end
            end
        end
    end
end

local function ApplyActionBarCenter()
    if ActionHeroShowsDefaultBottomUI() or not (BothBarsHidden() and DB.centerMainActionBar) then
        RestoreActionBarPosition()
        return
    end

    local bar = _G.MainActionBar
    if not bar or not bar.GetCenter then return end
    -- Do not fight Edit Mode; it can change the bar layout while it is open.
    if _G.EditModeManagerFrame and _G.EditModeManagerFrame:IsShown() then
        RestoreActionBarPosition()
        return
    end

    local barX, barY = bar:GetCenter()
    local uiX, uiY = UIParent:GetCenter()
    if not barX or not barY or not uiX or not uiY then return end

    if not IsCurrentCenterOverride(bar) then
        -- Either first activation or Blizzard rebuilt its layout: keep the
        -- new native anchor as the one to restore to when the option is off.
        local points = CaptureActionBarPoints(bar)
        if not points then return end
        savedActionBarPoints = points
        centeredActionBar = bar
    end

    local proxy = ConfigureStationaryProxy(bar)
    -- Prevent the extra bars from following MainActionBar. We do this BEFORE
    -- moving it, so the visible stack doesn't move even for one frame.
    FixBottomStackAnchors(bar, proxy)

    -- Only the 12 primary buttons, their border and paging arrows move.
    -- Leave their Y position unchanged, and keep their secure frames intact.
    bar:ClearAllPoints()
    bar:SetPoint("CENTER", UIParent, "CENTER", 0, barY - uiY)
end

local APPLIERS = {
    hideRaidManager = ApplyRaidManager,
    hideBagButtons = ApplyBagButtons,
    hideMicroMenu = ApplyMicroMenu,
    hideDielFrame = ApplyDayNightIcon,
    hideMailIcon = ApplyMailIcon,
    moveMailIcon = ApplyMailIcon,
    hideMinimap = ApplyEntireMinimap,
    hideMinimapIcons = ApplyAddonIcons,
    hideMinimapTracking = ApplyTrackingButton,
    hideMinimapHeader = ApplyMapHeader,
    hideMinimapCalendar = ApplyCalendar,
    showMinimapIconRow = ApplyAddonIcons,
    centerMainActionBar = ApplyActionBarCenter,
}

local TAB_DEFS = {
    {id = "BLIZZARD UI", label = "Blizzard UI"},
    {id = "MINIMAP", label = "Minimap"},
    {id = "MINIMAP HEADER", label = "Map Header"},
    {id = "ACTION BAR", label = "Action Bar"},
    {id = "SETTINGS", label = "Settings"},
}

local function SelectSettingsTab(category)
    if not settingsPages[category] then category = "BLIZZARD UI" end
    activeTab = category
    if DB then DB.lastTab = category end
    for _, tab in ipairs(TAB_DEFS) do
        local page, button = settingsPages[tab.id], tabButtons[tab.id]
        if page then page:SetShown(tab.id == category) end
        if button then
            if tab.id == category then
                button:LockHighlight()
                button:GetFontString():SetTextColor(1, 0.8, 0.4)
            else
                button:UnlockHighlight()
                button:GetFontString():SetTextColor(0.92, 0.87, 0.74)
            end
        end
    end
end

local function RefreshSettingsLayout()
    if not settingsWindow or not DB then return end
    local offsets = {}
    for _, tab in ipairs(TAB_DEFS) do offsets[tab.id] = -34 end
    for _, option in ipairs(OPTIONS) do
        local page = settingsPages[option.category]
        local row = optionRows[option.key]
        if page and row then
            local visible = (not option.requiresHiddenBars or BothBarsHidden())
                and (not option.requiresHiddenMinimap or DB.hideMinimap)
            row:SetShown(visible)
            if visible then
                row:ClearAllPoints()
                row:SetPoint("TOPLEFT", page, "TOPLEFT", 0, offsets[option.category])
                offsets[option.category] = offsets[option.category]
                    - (option.compact and 60 or 82)
            end
            optionChecks[option.key]:SetChecked(DB[option.key])
        end
    end
    for category, page in pairs(settingsPages) do
        if page.emptyHint then
            page.emptyHint:SetShown(category == "ACTION BAR" and not BothBarsHidden())
        end
    end
    if settingsWindow.manageIconsButton then
        settingsWindow.manageIconsButton:SetShown(activeTab == "MINIMAP"
            and DB.hideMinimap and DB.showMinimapIconRow and not DB.hideMinimapIcons)
    end
    if settingsWindow.placeMailButton then
        settingsWindow.placeMailButton:SetEnabled(DB.moveMailIcon)
        settingsWindow.placeMailButton:SetText(mailGuideActive and "Done" or "Place")
        settingsWindow.resetMailButton:SetEnabled(DB.moveMailIcon
            or (DB.mailX ~= nil and DB.mailY ~= nil))
    end
    SelectSettingsTab(activeTab)
end

local function ApplyAll()
    if not DB then return end
    if InCombat() then
        waitingForCombat = true
        UpdateStatus()
        return
    end
    waitingForCombat = false
    -- Temporarily restore the cluster so newly registered icons can be seen
    -- and collected even if the minimap was hidden by this addon previously.
    RestoreParents(originalMinimapParents)
    ApplyAddonIcons()
    for _, option in ipairs(OPTIONS) do
        local apply = APPLIERS[option.key]
        if apply and option.key ~= "hideMinimapIcons"
            and option.key ~= "showMinimapIconRow"
            and option.key ~= "moveMailIcon" then
            apply()
        end
    end
    UpdateStatus()
end

local function SetOption(key, enabled)
    if not DB then return end
    DB[key] = not not enabled
    if key == "moveMailIcon" and not DB.moveMailIcon then
        ShowMailGuide(false)
    end
    if key == "solidBackground" then
        ApplyWindowBackground(settingsWindow)
        ApplyWindowBackground(iconManagerWindow)
    else
        ApplyAll()
    end
    RefreshSettingsLayout()
end

local function MakeFont(parent, template, value, anchor, relativeTo, relativePoint, x, y)
    local label = parent:CreateFontString(nil, "OVERLAY", template)
    label:SetPoint(anchor, relativeTo, relativePoint, x, y)
    label:SetText(value)
    label:SetJustifyH("LEFT")
    return label
end

local function BuildSettings()
    if settingsWindow then return settingsWindow end
    local window = CreateFrame("Frame", "HideThisManagerSettings", UIParent, "BackdropTemplate")
    settingsWindow = window
    window:SetSize(540, 640)
    window:SetPoint("CENTER", UIParent, "CENTER", 0, 0)
    window:SetFrameStrata("DIALOG")
    window:SetClampedToScreen(true)
    window:SetMovable(true)
    window:EnableMouse(true)
    window:RegisterForDrag("LeftButton")
    window:SetScript("OnDragStart", function(self) self:StartMoving() end)
    window:SetScript("OnDragStop", function(self) self:StopMovingOrSizing() end)
    window:SetScript("OnHide", function() ShowMailGuide(false) end)
    window:SetBackdrop({
        bgFile = "Interface\\DialogFrame\\UI-DialogBox-Background-Dark",
        edgeFile = "Interface\\DialogFrame\\UI-DialogBox-Border",
        tile = true, tileSize = 32, edgeSize = 32,
        insets = {left = 10, right = 10, top = 10, bottom = 10},
    })
    window:SetBackdropColor(0.075, 0.085, 0.10, 0.98)
    ApplyWindowBackground(window)
    MakeFont(window, "GameFontNormalLarge", "HideThisManager", "TOPLEFT", window, "TOPLEFT", 25, -26)
    MakeFont(window, "GameFontHighlightSmall", "Choose which original UI elements to hide.",
        "TOPLEFT", window, "TOPLEFT", 25, -53)
    local version = MakeFont(window, "GameFontDisableSmall", "v" .. VERSION,
        "TOPRIGHT", window, "TOPRIGHT", -54, -30)
    version:SetJustifyH("RIGHT")

    local manage = CreateFrame("Button", nil, window, "UIPanelButtonTemplate")
    manage:SetSize(108, 24)
    manage:SetPoint("TOPRIGHT", window, "TOPRIGHT", -30, -130)
    manage:SetText("Manage Icons")
    manage:SetScript("OnClick", function() OpenIconManager() end)
    window.manageIconsButton = manage

    local close = CreateFrame("Button", nil, window, "UIPanelCloseButton")
    close:SetPoint("TOPRIGHT", window, "TOPRIGHT", -8, -8)
    close:SetScript("OnClick", function() window:Hide() end)

    local line = window:CreateTexture(nil, "ARTWORK")
    line:SetColorTexture(0.62, 0.48, 0.25, 0.65)
    line:SetPoint("TOPLEFT", window, "TOPLEFT", 24, -77)
    line:SetPoint("TOPRIGHT", window, "TOPRIGHT", -24, -77)
    line:SetHeight(1)

    for index, tab in ipairs(TAB_DEFS) do
        local button = CreateFrame("Button", nil, window, "UIPanelButtonTemplate")
        button:SetSize(94, 26)
        button:SetPoint("TOPLEFT", window, "TOPLEFT", 25 + (index - 1) * 98, -88)
        button:SetText(tab.label)
        button:SetScript("OnClick", function()
            SelectSettingsTab(tab.id)
            RefreshSettingsLayout()
        end)
        tabButtons[tab.id] = button
        local page = CreateFrame("Frame", nil, window)
        page:SetPoint("TOPLEFT", window, "TOPLEFT", 29, -130)
        page:SetPoint("BOTTOMRIGHT", window, "BOTTOMRIGHT", -29, 90)
        settingsPages[tab.id] = page
        local heading = MakeFont(page, "GameFontNormal", tab.id,
            "TOPLEFT", page, "TOPLEFT", 1, -5)
        heading:SetTextColor(0.95, 0.72, 0.35)
    end

    local actionPage = settingsPages["ACTION BAR"]
    actionPage.emptyHint = MakeFont(actionPage, "GameFontDisableSmall",
        "Hide both the Bag Bar and Micro Menu in Blizzard UI to reveal action-bar centering.",
        "TOPLEFT", actionPage, "TOPLEFT", 12, -48)
    actionPage.emptyHint:SetWidth(430)

    for _, option in ipairs(OPTIONS) do
        local page = settingsPages[option.category]
        local row = CreateFrame("Frame", nil, page, "BackdropTemplate")
        row:SetSize(476, option.compact and 53 or 73)
        row:SetBackdrop({bgFile = "Interface\\Buttons\\WHITE8X8"})
        row:SetBackdropColor(1, 1, 1, option.compact and 0.055 or 0.035)
        optionRows[option.key] = row

        local check = CreateFrame("CheckButton", nil, row, "UICheckButtonTemplate")
        check:SetPoint("TOPLEFT", row, "TOPLEFT", option.compact and 16 or 5,
            option.compact and -7 or -11)
        check:SetSize(option.compact and 25 or 30, option.compact and 25 or 30)
        check:SetChecked(DB[option.key])
        check:SetScript("OnClick", function(self)
            SetOption(option.key, self:GetChecked())
        end)
        optionChecks[option.key] = check

        local textX = option.compact and 52 or 41
        local label = MakeFont(row, "GameFontHighlight", option.label,
            "TOPLEFT", row, "TOPLEFT", textX, option.compact and -9 or -13)
        label:SetWidth(option.key == "moveMailIcon" and 247 or 420)
        local description = MakeFont(row, "GameFontDisableSmall", option.description,
            "TOPLEFT", row, "TOPLEFT", textX, option.compact and -29 or -35)
        description:SetWidth(408)
        description:SetJustifyV("TOP")

        if option.key == "moveMailIcon" then
            local place = CreateFrame("Button", nil, row, "UIPanelButtonTemplate")
            place:SetSize(69, 23)
            place:SetPoint("TOPRIGHT", row, "TOPRIGHT", -85, -4)
            place:SetText("Place")
            place:SetScript("OnClick", function()
                ShowMailGuide(not mailGuideActive)
                RefreshSettingsLayout()
            end)
            window.placeMailButton = place
            local reset = CreateFrame("Button", nil, row, "UIPanelButtonTemplate")
            reset:SetSize(72, 23)
            reset:SetPoint("TOPRIGHT", row, "TOPRIGHT", -6, -4)
            reset:SetText("Reset")
            reset:SetScript("OnClick", function()
                ResetMailPosition()
                RefreshSettingsLayout()
                Message("Mail icon restored to Blizzard's default position.")
            end)
            window.resetMailButton = reset
        end

        row:EnableMouse(true)
        row:SetScript("OnMouseUp", function(_, button)
            if button == "LeftButton" then
                SetOption(option.key, not DB[option.key])
            end
        end)
        row:SetScript("OnEnter", function(self)
            self:SetBackdropColor(1, 1, 1, 0.085)
        end)
        row:SetScript("OnLeave", function(self)
            self:SetBackdropColor(1, 1, 1, option.compact and 0.055 or 0.035)
        end)
    end

    local bottomLine = window:CreateTexture(nil, "ARTWORK")
    bottomLine:SetColorTexture(0.45, 0.45, 0.45, 0.4)
    bottomLine:SetPoint("BOTTOMLEFT", window, "BOTTOMLEFT", 24, 73)
    bottomLine:SetPoint("BOTTOMRIGHT", window, "BOTTOMRIGHT", -24, 73)
    bottomLine:SetHeight(1)
    statusText = MakeFont(window, "GameFontDisableSmall", "",
        "BOTTOMLEFT", window, "BOTTOMLEFT", 25, 47)
    statusText:SetWidth(475)
    AddShadyFooter(window, 18)
    UpdateStatus()
    activeTab = (DB and DB.lastTab) or "BLIZZARD UI"
    RefreshSettingsLayout()

    window:Hide()
    if type(UISpecialFrames) == "table" then
        table.insert(UISpecialFrames, "HideThisManagerSettings")
    end
    return window
end

local function OpenSettings()
    if not DB then return end
    local window = BuildSettings()
    RefreshSettingsLayout()
    UpdateStatus()
    window:Show()
    window:Raise()
end

SLASH_HIDETHISMANAGER1 = "/htm"
SLASH_HIDETHISMANAGER2 = "/hidethismanager"
SlashCmdList.HIDETHISMANAGER = function(input)
    input = (input or ""):lower():match("^%s*(.-)%s*$")
    if input == "" or input == "settings" then
        if settingsWindow and settingsWindow:IsShown() then
            settingsWindow:Hide()
        else
            OpenSettings()
        end
    elseif input == "on" then
        SetOption("hideRaidManager", true)
        Message("Party / Raid Manager hiding enabled.")
    elseif input == "off" then
        SetOption("hideRaidManager", false)
        Message("Party / Raid Manager hiding disabled.")
    elseif input == "bags on" then
        SetOption("hideBagButtons", true)
        Message("Bag bar hiding enabled.")
    elseif input == "bags off" then
        SetOption("hideBagButtons", false)
        Message("Bag bar hiding disabled.")
    elseif input == "menu on" or input == "micro on" then
        SetOption("hideMicroMenu", true)
        Message("Micro Menu hiding enabled.")
    elseif input == "menu off" or input == "micro off" then
        SetOption("hideMicroMenu", false)
        Message("Micro Menu hiding disabled.")
    elseif input == "sun on" or input == "moon on" or input == "daynight on" then
        SetOption("hideDielFrame", true)
        Message("Minimap sun/moon icon hiding enabled.")
    elseif input == "sun off" or input == "moon off" or input == "daynight off" then
        SetOption("hideDielFrame", false)
        Message("Minimap sun/moon icon hiding disabled.")
    elseif input == "minimap on" or input == "maphide on" then
        SetOption("hideMinimap", true)
        Message("Entire minimap hiding enabled.")
    elseif input == "minimap off" or input == "maphide off" then
        SetOption("hideMinimap", false)
        Message("Entire minimap hiding disabled.")
    elseif input == "mail move" then
        SetOption("moveMailIcon", true)
        OpenSettings()
        SelectSettingsTab("MINIMAP")
        ShowMailGuide(true)
        RefreshSettingsLayout()
    elseif input == "mail reset" then
        ResetMailPosition()
        RefreshSettingsLayout()
        Message("Mail icon restored to Blizzard's default position.")
    elseif input == "mail hide" then
        SetOption("hideMailIcon", true)
        Message("New-mail icon hiding enabled.")
    elseif input == "mail show" then
        SetOption("hideMailIcon", false)
        Message("New-mail icon hiding disabled.")
    elseif input == "icons on" then
        SetOption("hideMinimapIcons", true)
        Message("Addon minimap icon hiding enabled.")
    elseif input == "icons off" then
        SetOption("hideMinimapIcons", false)
        Message("Addon minimap icon hiding disabled.")
    elseif input == "tracking on" then
        SetOption("hideMinimapTracking", true)
        Message("Tracking button hiding enabled.")
    elseif input == "tracking off" then
        SetOption("hideMinimapTracking", false)
        Message("Tracking button hiding disabled.")
    elseif input == "header on" then
        SetOption("hideMinimapHeader", true)
        Message("Map / Zone / Time header hiding enabled.")
    elseif input == "header off" then
        SetOption("hideMinimapHeader", false)
        Message("Map / Zone / Time header hiding disabled.")
    elseif input == "calendar on" then
        SetOption("hideMinimapCalendar", true)
        Message("Calendar button hiding enabled.")
    elseif input == "calendar off" then
        SetOption("hideMinimapCalendar", false)
        Message("Calendar button hiding disabled.")
    elseif input == "iconrow on" then
        SetOption("showMinimapIconRow", true)
        Message("Icon row enabled when minimap is hidden (unless icons are hidden).")
    elseif input == "iconrow off" then
        SetOption("showMinimapIconRow", false)
        Message("Icon row disabled.")
    elseif input == "refresh" then
        ApplyAll()
        if iconManagerWindow and iconManagerWindow:IsShown() then RefreshIconManager() end
        Message("Minimap buttons rescanned.")
    elseif input == "manage" or input == "iconmanage" then
        OpenIconManager()
    elseif input == "center on" then
        SetOption("centerMainActionBar", true)
        if BothBarsHidden() then
            Message("Original Action Bar centering enabled.")
        else
            Message("Centering saved; activate both hide options to apply it.")
        end
    elseif input == "center off" then
        SetOption("centerMainActionBar", false)
        Message("Original Action Bar centering disabled.")
    elseif input == "reset" then
        for _, option in ipairs(OPTIONS) do
            DB[option.key] = option.default
        end
        DB.mailX, DB.mailY = nil, nil
        DB.lastTab = "BLIZZARD UI"
        DB.iconHidden, DB.iconOrder = {}, {}
        ShowMailGuide(false)
        ApplyAll()
        ApplyWindowBackground(settingsWindow)
        ApplyWindowBackground(iconManagerWindow)
        RefreshSettingsLayout()
        if iconManagerWindow and iconManagerWindow:IsShown() then RefreshIconManager() end
        Message("Settings restored to defaults.")
    else
        Message("Commands: /htm, /htm mail move|reset|hide|show, /htm bags|menu|sun|icons|tracking|header|calendar|iconrow on/off, /htm minimap on/off, /htm refresh, /htm manage, /htm center on/off, /htm reset")
    end
end

local function HookEditModeExit()
    if editModeExitHooked then return end
    local editMode = _G.EditModeManagerFrame
    if not editMode then return end
    editModeExitHooked = true
    editMode:HookScript("OnShow", function()
        -- Let Edit Mode present the actual Blizzard layout, not our override.
        if not InCombat() then RestoreActionBarPosition() end
    end)
    editMode:HookScript("OnHide", function()
        -- Edit Mode may overwrite the position after our original apply.
        -- Re-apply only when its layout has finished updating.
        if C_Timer and C_Timer.After then
            C_Timer.After(0, ApplyAll)
        else
            ApplyAll()
        end
    end)
end

local function ApplyAfterBlizzardLayout()
    HookEditModeExit()
    if C_Timer and C_Timer.After then
        C_Timer.After(0, ApplyAll)
    else
        ApplyAll()
    end
end

local eventFrame = CreateFrame("Frame")
eventFrame:RegisterEvent("ADDON_LOADED")
eventFrame:RegisterEvent("PLAYER_ENTERING_WORLD")
eventFrame:RegisterEvent("GROUP_ROSTER_UPDATE")
eventFrame:RegisterEvent("PLAYER_REGEN_ENABLED")
eventFrame:RegisterEvent("EDIT_MODE_LAYOUTS_UPDATED")
eventFrame:RegisterEvent("UPDATE_PENDING_MAIL")
eventFrame:SetScript("OnEvent", function(_, event, addonName)
    if event == "ADDON_LOADED" then
        if addonName == ADDON_NAME or addonName == "HideThisManager" then
            if type(HideThisManagerDB) ~= "table" then
                HideThisManagerDB = {}
            end
            DB = HideThisManagerDB
            if type(DB.iconHidden) ~= "table" then DB.iconHidden = {} end
            if type(DB.iconOrder) ~= "table" then DB.iconOrder = {} end
            if type(DB.mailX) ~= "number" then DB.mailX = nil end
            if type(DB.mailY) ~= "number" then DB.mailY = nil end
            for _, option in ipairs(OPTIONS) do
                if DB[option.key] == nil then
                    DB[option.key] = option.default
                end
            end
            ApplyAll()
            if C_Timer and C_Timer.NewTicker and not iconTickerStarted then
                iconTickerStarted = true
                C_Timer.NewTicker(8, function()
                    if DB and (DB.hideMinimapIcons or
                        (DB.hideMinimap and DB.showMinimapIconRow)) and not InCombat() then
                        RestoreParents(originalMinimapParents)
                        ApplyAddonIcons()
                        ApplyEntireMinimap()
                    end
                    if DB and (DB.hideMailIcon or DB.moveMailIcon) and not InCombat() then
                        ApplyMailIcon()
                    end
                end)
            end
        elseif addonName == "Blizzard_CompactRaidFrames" or addonName == "Blizzard_RaidUI"
            or addonName == "Blizzard_MainMenuBarBagButtons" or addonName == "Blizzard_MicroMenu"
            or addonName == "Blizzard_EditMode" or addonName == "Blizzard_Minimap" then
            ApplyAfterBlizzardLayout()
        elseif DB and (DB.hideMinimapIcons or DB.hideMinimap or
            DB.hideMinimapTracking or DB.hideMinimapCalendar or DB.hideMinimapHeader) then
            -- Most addons register their minimap buttons late during ADDON_LOADED.
            ApplyAfterBlizzardLayout()
        end
    elseif event == "UPDATE_PENDING_MAIL" then
        if DB and (DB.hideMailIcon or DB.moveMailIcon) then ApplyMailIcon() end
    elseif event == "PLAYER_REGEN_ENABLED" then
        if waitingForCombat then ApplyAll() end
    elseif event == "PLAYER_ENTERING_WORLD" or event == "EDIT_MODE_LAYOUTS_UPDATED" then
        ApplyAfterBlizzardLayout()
    else
        ApplyAll()
    end
end)
