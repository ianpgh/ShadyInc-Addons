SHADY AIRLINES v1.4.2 - ROUTE-SAFE MANUAL CORRECTIONS
- Correct flight time targets the active ticket while flying; otherwise the most recent completed, valid flight. Never silently falls back to an unrelated older route.
- The popup locks the route and speed profile; Save, Enter and Remove use that same target. A changed or invalid flight requires reopening the popup.
- Enter the total flight duration, not remaining time. Active countdown refreshes immediately after a correction.
- Existing history, calibrations, fares, settings and textures are unchanged.

SHADY AIRLINES v1.4.1 - VERIFIED LANDINGS (2026-11-24)
- Map-reported intermediate flight points are routing waypoints, not confirmed
  landings. They remain in full-route keys/segment estimates and route diagnostics,
  but are never counted as observed stops.
- New completed flights store 1 observed taxi-end landing and 0 confirmed
  intermediate landings; an unknown intermediate is NOT assumed to be a stop.
- Early-landing requests show "Next available landing" without inventing a
  destination name or landing ETA from fly-through nodes. A learned full-route
  ETA still takes precedence during normal, uninterrupted flights.
- Full History labels via points as unverified fly-through waypoints and shows
  observed landing counts on newly recorded flights.
- Existing histories, fares, calibrated times, measured routes, speed profiles,
  and display settings are retained. Older early-stop predictions are not
  shown as actual stops in recent-history summaries.

NEW IN v1.3.9 - THREE NEW CHOOSEABLE SKINS
- New illustrations: Stealthed Tauren Druid (feral cat stalking a human), Orc Forgemaster (axe sharpening), and Shadow Rogue Heist (stealthy orc rogue with blades and a loot crate).
- Open /sft > Illustrated skin to choose from five options. Enable Experimental: Illustrated Shady Airlines UI for illustrations.
- Live destination-only plaque, countdown, ETA and paid fare (sample numbers removed from images).
- Skins are presentation-only; do not alter taxi tracking, Action Hero landing, history, spending, timer position, or Mini Mode. All art rendered as 1024x512 TGA textures.

SHADY AIRLINES - FLIGHT TIMER v1.3.9
For WoW Forever / Interface 16001

NEW IN v1.3.8 - ALWAYS-ON-TOP DISPLAY
- Full timer and Mini Mode use a higher frame strata so they render over
  ordinary game UI, unit frames, and action bars when visible.
- Settings, skin list, text sizes, and calibration dialogs stay above the timer.
- Tooltips remain above the timer.
- No changes to flight data, positioning, resizing, or image assets.

NEW IN v1.3.7 - TEXT ALIGNMENT POLISH
- Wyvern route and ETA moved away from the gold plate borders.
- Less heavy outlines for small text improve readability.
- ETA no longer duplicates the countdown's approximate (~) marker.
- Thin flight progress bar moved below the ETA line.
- All illustration textures and existing settings retained.

PREVIOUS: v1.3.5 - ADAPTIVE LIVE TEXT, UNCHANGED ARTWORK
- Both illustrated skins retain their original 1024x512 artwork and frame size.
- Flight origin/destination labels auto-fit their route plaque. On the Wyvern
  skin, a longer route uses two centered lines rather than shrinking into an
  unreadable single line or overlapping the countdown.
- Remaining time / ETA and confirmed fare each fit their own plaques, including
  long times and amounts. Normal short values remain comfortably readable.
- /sft > Text sizes... offers three saved and independent live-text controls:
  Flight locations, Countdown and ETA, and Gold paid (75% to 150%). Auto-fit
  takes precedence if the preferred font size would overflow the panel.
- Full names stay in the existing flight hover tooltip. Mini Mode, skins,
  independent saved positions, Action Hero landing and trip/expense history
  are unchanged. Text-size settings do not affect Mini Mode.
- All text remains live FontStrings; this update does NOT change the artwork.

INSTALL
Replace Interface/AddOns/ShadyFlightTimer with the folder in this ZIP.
Keep your account SavedVariables/ShadyFlightTimer.lua file under WTF unchanged.
All saved settings, route measurements, manual corrections, and fare history persist.

NEW IN v1.3.3 — SKIN LIST AND INDEPENDENT MINI POSITION
- /sft -> Illustrated skin selector: Classic Shadow Priest or Shadow Wyvern.
- Wyvern art keeps the wyvern rider, gold frame and SHADY AIRLINES crest.
- Flight route, countdown, ETA and confirmed paid fare are all live text.
- Mini Mode is freely draggable, even with full-timer Lock enabled.
- Mini Mode saves miniX/miniY independently of the full timer x/y.
- Switching skins or toggling Mini Mode restores each saved location.
- Reset position applies only to the CURRENT mode.
- Old Classic skin, saved flights, fare history and Action Hero support preserved.

PREVIOUS v1.3.2 — FRAME AND TIMER POLISH
- Replaces the old placeholder mascot window with the approved purple/gold
  SHADY AIRLINES art, ornate winged title plaque, thumbs-up Shadow Priest,
  sky, scenery, and gold-framed in-game timer and fare plaques.
- Enable /sft > Experimental: Illustrated Shady Airlines UI.
- The art is a native WoW .tga texture. No separate addon or font required.
- Destination, countdown, ETA, and confirmed cost PAID are LIVE text over
  clean blank artwork. The artwork contains no example fare or route values.
- The red three-dot top-right artwork has an invisible clickable settings
  button aligned to it (it is not a dead decorative mockup).
- The progress indicator remains active along the bottom of the timer.
- Standard view, Mini Mode (countdown only), and their visibility controls
  remain available; Mini Mode takes priority over illustrated view.
- The "Show Shady Airlines header" checkbox now explicitly applies to
  standard view. Illustrated art includes its own permanent decorative title.
- Reduced the old mascot layout to one illustrated background texture.
- Flight timing, manual calibration, early landing, expense totals, and
  Action Hero integration are unchanged.

COMMANDS
/sft (settings) /sft preview (toggle preview) /sft stats
/sft status /sft calibrate M:SS /sft uncalibrate

NOTES
- This is client-side visual integration, not a new picture rendered inside
  ChatGPT. Client-side texture display needs actual in-game testing.
- If the illustrated art fails to appear, verify the file
  Textures/ShadyAirlines.tga exists under Interface/AddOns/ShadyFlightTimer.
- MaxDPS route timing spline data is not bundled; unknown route timings are
  estimates until flights are measured or calibrated.

RIP Shady

REFINED IN v1.3.2
- All four rounded corners now have matching, continuous gold/purple trim.
- Timer has a centered illuminated glass plaque with gold edges.
- Fare text is centered between the two gold coin stacks.
- The new illustrated background uses the full native 1024x512 texture.
- No sample text is burned into the new background; live labels still update.
- Mini Mode and non-illustrated display are unchanged.
- No SavedVariables changes or required data migration.

REFINED IN v1.3.2
- New seamless single-piece outer gold frame: every edge and corner is continuous.
- Illustration is no longer cropped from a larger screenshot; complete border remains within texture bounds.
- Timer and fare plates have clean glass centers and preserved gold outlines.
- Repositioned four live values for the new art.
- No changes to routes, expenses, Mini Mode, early landing, or SavedVariables.


v1.3.4 - Shadow Wyvern readability
- Current Flight plaque now shows origin > destination without redundant zone names.
- Long routes shrink slightly to fit, with ellipsis as a last resort instead of wrapping into the countdown.
- Hover the full Wyvern view for exact unshortened departure/destination names.
- Brighter ivory/gold route, ETA and payment text with stronger outlined timer.
- Does not change saved flight/expense records, skins, mini mode or positions.


v1.3.7: Destination display repair
- The Wyvern skin's top plaque now shows the destination only; the departure remains in the hover tooltip.
- Prevent the taxi origin from being displayed as a destination when a client slot is invalid.
- Where possible, recover an invalid slot from the flight point just hovered before purchase.
- The preview now demonstrates destination-only display.


Shady Airlines 1.4.0:
- Full History opens from the settings footer, with mouse-wheel browsing and selection; /sft history is a shortcut.
- Exclude timing on any incorrectly labeled flight. Fare, flight total, and original record remain intact.
- Rebuilds the affected route's learned average from non-excluded recorded flights. Existing unrelated routes and calibrations are left alone.
- Landing-zone mismatch marks the trip for review rather than teaching the wrong duration.
- Longer grace period for transient loss of taxi control at multi-hop transition; true duration measured at first landing-control loss.
- Always retain full flight history (old versions retained at most 500 entries).
- The selected ticket destination stays separate from any fly-by legs.

- History shows map-reported intermediate fly-by stops as unverified diagnostics (e.g., Camp Taurajo > Camp Mojache > Silithus).
- Clear route correction is a separate button; excluding incorrect timing does not silently delete manual overrides.
- Compact recent-flight list makes room for the Full History button at the bottom of settings.

v1.5.0 - Classic database / Forever learning
881 directional numeric node-ID timings from InFlight Classic Era defaults
(https://github.com/LudiusMaximus/InFlight, Defaults.lua blob
8352a73c4284e0b3ac5bea17f2af281eda1cecec). See InFlight-LICENSE.txt.
Manual corrections and existing learned full-route times have priority.
Classic timing is a provisional endpoint estimate only, faction-specific,
and skipped if any reported waypoint is not in the Classic faction database.
Frequent Flier uses the existing manual speed setting (1.2x speed).
Unknown routes with no measured hop estimate count as learning rather than
using straight-line distance. Existing completed-flight learning, expenses,
settings and history are preserved. No Cataclysm/TBC or Forever-specific
source records are imported. Actual Forever timings need live validation.


v1.6.0 - Learning reliability and route review
- Keeps existing Classic timings, settings, fares, route direction and speed-profile data.
- Interrupted flights (reload/logout, world transition, death or observation gap over 15 seconds) do not train route durations. History and booked fares are retained.
- After three accepted samples, a duration differing from the learned mean by more than 25% or 15 seconds (whichever is larger) is retained for review but does not train the route. Reset a genuinely changed route to relearn.
- Learned timing confidence and recent mean absolute deviation are displayed in hover tooltips. Recent samples start accumulating on upgrade; old averages/counts are retained.
- Shift-click the timer to open route-filtered history. All routes clears the filter.
- Select a history row and click Reset learned twice within eight seconds to clear that direction and speed profile only. Historical rows remain, marked RESET, and will not be used to rebuild timing. Manual corrections remain until cleared separately. Reset is blocked during a flight.
- Settings show recorded flight hours (excluding newly flagged interruptions).
- Multi-stop flight debounce and conservative early landing handling retained; fly-through nodes are not treated as confirmed landings.
- Offline Lua parsing and mocked core regression tests passed; live WoW Forever UI and flight behavior require validation.

v1.7.0 - Cinematic flight experience
- /sft opens Flight Tracking and Cinematics tabs. Cinematics auto-starts on actual taxi flights by default; disable in the Cinematics tab if desired.
- Camera styles: dynamic directional shots, slow orbit, wide follow (native camera heading), scenic (wide static view), first person. Zoom/rotation/interval/black-bar controls, optional UI hiding, destination/countdown/progress and zone titles.
- ESC or the on-screen Exit button returns to gameplay; /sft cinema or the optional Shady Airlines key binding toggles during flight. Exit before using normal early-landing controls.
- Cinematic countdown uses the existing route estimator, including manual corrections and learned timings. Unknown/overdue/early landing times remain unknown; no invented ETA.
- Separate runtime and saved settings; existing flight history and timing tables are untouched. Stops its camera motion and restores saved zoom settings and UI visibility on exit, landing or world transition. Recovery snapshot handles interrupted reloads; exact camera yaw/pitch restoration is not supported by the exposed camera API used here.
- Actual camera zoom limits, movement speed, keyboard propagation and full UI restoration depend on the Forever client; verify in game. The Exit button is the fallback if ESC is intercepted by another addon.

v1.7.1 - Cinematic Reliability & Smoothness
- Eased camera speed requests, uninterrupted orbit, overlay and zone fades.
- Optional mouse-button rotation pause; debounced settings; cached ETA.
- Verified camera/UI recovery with retry; world transition gating; immediate manual exit.
- New cinematic settings default to manual activation; existing choices retained.
- Live client validation still required: camera speed API behavior, zoom restoration,
  keyboard propagation, visual smoothness and UI compatibility. Exact heading is not saved.
