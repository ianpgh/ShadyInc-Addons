local ADDON, SFT = ...
local C = { modes = {"Cinematic", "Orbit", "Follow", "Scenic", "First Person"} }
SFT.Cinematics = C
local function call(fn, ...)
    if type(fn) ~= "function" then return nil end
    local ok, result = pcall(fn, ...)
    if ok then return result end
end
local function clamp(v, low, high, default)
    return math.max(low, math.min(high, tonumber(v) or default))
end
local function taxi() return call(UnitOnTaxi, "player") and true or false end
local function combat() return call(InCombatLockdown) and true or false end
local function font(parent, template, point, relative, relativePoint, x, y)
    local f = parent:CreateFontString(nil, "OVERLAY", template)
    f:SetPoint(point, relative, relativePoint, x, y)
    return f
end
function C:Settings()
    local db = SFT.db
    if type(db.cinematics) ~= "table" then db.cinematics = {} end
    local s = db.cinematics
    local defaults = { enabled=false, mode="Cinematic", zoom=4, speed=15, bars=true, barSize=9,
        hideUI=true, info=true, zones=true, smooth=true, interval=12, manual=true }
    for k,v in pairs(defaults) do if s[k] == nil then s[k]=v end end
    s.zoom=clamp(s.zoom,1,4,4); s.speed=clamp(s.speed,0,100,15)
    s.barSize=clamp(s.barSize,4,18,9); s.interval=clamp(s.interval,6,30,12)
    local valid=false; for _, mode in ipairs(self.modes) do if mode==s.mode then valid=true end end
    if not valid then s.mode="Cinematic" end
    return s
end
local moves = {
    right={"MoveViewRightStart","MoveViewRightStop"}, left={"MoveViewLeftStart","MoveViewLeftStop"},
    up={"MoveViewUpStart","MoveViewUpStop"}, down={"MoveViewDownStart","MoveViewDownStop"},
}
local function attempt(fn,...)
    return type(fn)=="function" and pcall(fn,...) or false
end
function C:StopMotion()
    if not self.motion then return true end
    if not attempt(_G[moves[self.motion][2]]) then return false end
    self.motion=nil; self.motionSpeed=nil
    return true
end
function C:Move(direction, speed)
    if speed<=0 then return self:StopMotion() end
    local pair=moves[direction]
    if not pair or type(_G[pair[1]])~="function" or type(_G[pair[2]])~="function" then return false end
    if self.motion and self.motion~=direction and not self:StopMotion() then return false end
    if self.motion==direction and math.abs((self.motionSpeed or 0)-speed)<.012 then return true end
    -- Reissue the same direction at a new speed, without stop/start gaps.
    self.motion=direction
    if not attempt(_G[pair[1]],speed) then return false end
    self.motionSpeed=speed; return true
end
local function setZoom(target)
    local z=call(GetCameraZoom)
    if type(z)~="number" or type(target)~="number" then return false end
    if target>z+.25 then return attempt(CameraZoomOut,target-z)
    elseif target<z-.25 then return attempt(CameraZoomIn,z-target) end
    return true
end
local function restoreCVar(key,value)
    if value==nil then return true end
    local actual=call(GetCVar,key)
    if tostring(actual)==tostring(value) or (tonumber(actual) and tonumber(actual)==tonumber(value)) then return true end
    attempt(SetCVar,key,value)
    actual=call(GetCVar,key)
    return tostring(actual)==tostring(value) or (tonumber(actual)~=nil and tonumber(actual)==tonumber(value))
end
function C:Restore(immediate)
    local stopped=self:StopMotion()
    self.active=false; self.pendingApply=nil; self.etaTrip=nil; self.etaAt=nil
    if self.overlay then
        if not immediate and self.overlay.SetPropagateKeyboardInput and not combat() then attempt(self.overlay.SetPropagateKeyboardInput,self.overlay,true) end
        if immediate then self.overlay:Hide(); self.fadeOut=nil
        elseif not self.fadeOut and self.overlay:IsShown() then self.fadeOut=GetTime() end
    end
    local r=SFT.db and SFT.db.cinematicRecovery
    if not r then return stopped end
    local uiOK=true
    if r.hiddenByUs and UIParent and not UIParent:IsShown() then
        uiOK=not combat() and attempt(UIParent.Show,UIParent) and UIParent:IsShown()
    end
    if uiOK then r.hiddenByUs=false end
    local factorOK=restoreCVar("cameraDistanceMaxZoomFactor",r.factor)
    local speedOK=restoreCVar("cameraZoomSpeed",r.zoomSpeed)
    local zoomOK=true
    if r.zoom~=nil then
        local actual=call(GetCameraZoom)
        zoomOK=type(actual)=="number" and math.abs(actual-r.zoom)<=.35
        if not zoomOK and factorOK then
            local now=GetTime()
            if not self.restoreZoomAt or now-self.restoreZoomAt>=.5 or immediate then
                self.restoreZoomAt=now; setZoom(r.zoom)
            end
            actual=call(GetCameraZoom)
            zoomOK=type(actual)=="number" and math.abs(actual-r.zoom)<=.35
        end
    end
    if stopped and uiOK and factorOK and speedOK and zoomOK then
        SFT.db.cinematicRecovery=nil; self.restoreZoomAt=nil; return true
    end
    return false
end
function C:MakeOverlay()
    if self.overlay then return end
    local f=CreateFrame("Frame","ShadyFlightTimerCinematicOverlay",WorldFrame)
    f:SetAllPoints(WorldFrame); f:SetFrameStrata("FULLSCREEN_DIALOG"); f:SetFrameLevel(100)
    f:EnableMouse(false)
    for _, side in ipairs({"TOP","BOTTOM"}) do
        local t=f:CreateTexture(nil,"BACKGROUND"); t:SetColorTexture(0,0,0,1)
        t:SetPoint(side.."LEFT",f,side.."LEFT"); t:SetPoint(side.."RIGHT",f,side.."RIGHT")
        f[side]=t
    end
    f.route=font(f,"GameFontNormalLarge","BOTTOM",f,"BOTTOM",0,51)
    f.time=font(f,"GameFontHighlight","BOTTOM",f,"BOTTOM",0,31)
    f.zone=font(f,"GameFontNormalLarge","TOP",f,"TOP",0,-30)
    local bar=CreateFrame("StatusBar",nil,f); bar:SetSize(280,3); bar:SetPoint("BOTTOM",f,"BOTTOM",0,24)
    bar:SetStatusBarTexture("Interface\\TargetingFrame\\UI-StatusBar"); bar:SetStatusBarColor(.83,.68,.36); bar:SetMinMaxValues(0,1); f.bar=bar
    local b=CreateFrame("Button",nil,f,"UIPanelButtonTemplate"); b:SetSize(132,23); b:SetPoint("TOPRIGHT",f,"TOPRIGHT",-12,-10); b:SetText("Exit cinematic (Esc)")
    b:SetScript("OnClick",function() C:Exit() end)
    if f.SetPropagateKeyboardInput then
        f:EnableKeyboard(true)
        f:SetPropagateKeyboardInput(true)
        f:SetScript("OnKeyDown",function(_,key)
            if key=="ESCAPE" and C.active and not combat() then f:SetPropagateKeyboardInput(false); C:Exit()
            elseif not combat() then f:SetPropagateKeyboardInput(true) end
        end)
    elseif UISpecialFrames then table.insert(UISpecialFrames,f:GetName()) end
    f:SetScript("OnHide",function() if C.active then C:Exit() end end)
    f:Hide(); self.overlay=f
end
function C:Apply()
    local s=self:Settings(); local f=self.overlay; local r=SFT.db.cinematicRecovery
    if not self.active or not r then return end
    local cameraChanged=self.appliedMode~=s.mode or self.appliedZoom~=s.zoom or self.appliedSmooth~=s.smooth
    if cameraChanged then
        if not self:StopMotion() then error("Unable to stop camera motion") end
        if r.factor~=nil then call(SetCVar,"cameraDistanceMaxZoomFactor",s.zoom) end
        if r.zoomSpeed~=nil then call(SetCVar,"cameraZoomSpeed",s.smooth and 12 or r.zoomSpeed) end
        if r.zoom~=nil then
            if s.mode=="First Person" then setZoom(0) else call(CameraZoomOut,50) end
        end
        self.appliedMode=s.mode; self.appliedZoom=s.zoom; self.appliedSmooth=s.smooth
        self.shotStart=GetTime(); self.shot=1
    end
    if s.hideUI and UIParent:IsShown() and not combat() then
        r.hiddenByUs=true
        if not attempt(UIParent.Hide,UIParent) or UIParent:IsShown() then error("Unable to hide interface") end
    elseif not s.hideUI and r.hiddenByUs and not combat() then
        if attempt(UIParent.Show,UIParent) and UIParent:IsShown() then r.hiddenByUs=false else error("Unable to restore interface") end
    end
    local height=math.max(1,f:GetHeight())*s.barSize/100
    f.TOP:SetHeight(height); f.BOTTOM:SetHeight(height)
    if s.bars then f.TOP:Show(); f.BOTTOM:Show() else f.TOP:Hide(); f.BOTTOM:Hide() end
end
function C:Start()
    if self.active or not self.ready or not taxi() or combat() or not SFT.db then return end
    if SFT.db.cinematicRecovery or self.motion then if not self:Restore(true) then return end end
    self:MakeOverlay()
    SFT.db.cinematicRecovery={factor=call(GetCVar,"cameraDistanceMaxZoomFactor"),zoomSpeed=call(GetCVar,"cameraZoomSpeed"),zoom=call(GetCameraZoom),hiddenByUs=false}
    self.active=true; self.lastZone=nil; self.zoneUntil=0; self.fadeOut=nil; self.started=GetTime()
    self.appliedMode=nil; self.manualUntil=nil; self.etaAt=nil
    if self.overlay.SetPropagateKeyboardInput then self.overlay:SetPropagateKeyboardInput(true) end
    self.overlay:SetAlpha(self:Settings().smooth and 0 or 1); self.overlay:Show(); self:Apply()
end
function C:Exit()
    self.suppressed=true; self.suppressedTrip=SFT.current; self:Restore(true)
end
function C:Toggle()
    if self.active then self:Exit() elseif taxi() then self.suppressed=false; self.suppressedTrip=nil; self:Start() else SFT:Print("Cinematics are available during taxi flights.") end
end
local function ease(x) x=math.max(0,math.min(1,x)); return x*x*(3-2*x) end
function C:Animate(now)
    local f=self.overlay
    if self.fadeOut and f then
        local alpha=1-ease((now-self.fadeOut)/.35)
        f:SetAlpha(alpha); if alpha<=0 then f:Hide(); self.fadeOut=nil end
    end
    if not self.active then return end
    local s=SFT.db.cinematics
    f:SetAlpha(s.smooth and ease((now-self.started)/.65) or 1)
    if s.zones and now<self.zoneUntil then f.zone:SetAlpha(s.smooth and math.min(ease((now-(self.zoneUntil-5))/.5),ease((self.zoneUntil-now)/.8)) or 1) end
    if s.manual and (call(IsMouseButtonDown,"LeftButton") or call(IsMouseButtonDown,"RightButton")) then self.manualUntil=now+2 end
    if self.manualUntil and now<self.manualUntil then
        if not self:StopMotion() then error("Unable to pause camera") end
        self.shotStart=now; return
    end
    local t=now-(self.shotStart or now); local speed=s.speed/100
    local mode=self.appliedMode or s.mode
    if mode=="Orbit" then
        if s.smooth then speed=speed*ease(t/1.5) end
        if not self:Move("right",speed) then error("Camera rotation unavailable") end
    elseif mode=="Cinematic" then
        if t>=s.interval then self.shot=(self.shot or 1)%6+1; self.shotStart=now; t=0 end
        local shots={"right","left","right","up","left","down"}
        local duration=math.min(5,s.interval*.65)
        if t>=duration then if not self:StopMotion() then error("Unable to stop camera") end; return end
        if s.smooth then speed=speed*math.min(ease(t/.8),ease((duration-t)/.8)) end
        if not self:Move(shots[self.shot or 1],speed*((self.shot==4 or self.shot==6) and .45 or 1)) then error("Camera movement unavailable") end
    else if not self:StopMotion() then error("Unable to stop camera") end end
end
function C:Update()
    if not SFT.db or not self.ready then return end
    local on=taxi(); local now=GetTime(); local s=self:Settings()
    if not on then
        if self.active or SFT.db.cinematicRecovery or self.motion then self:Restore(not s.smooth) end
        if self.wasTaxi then self.offAt=now end
        self.wasTaxi=false
        if self.offAt and now-self.offAt>1 and (not SFT.current or SFT.current~=self.suppressedTrip) then self.suppressed=false; self.suppressedTrip=nil; self.offAt=nil end
        return
    end
    if self.suppressed and self.suppressedTrip and SFT.current and SFT.current~=self.suppressedTrip then self.suppressed=false; self.suppressedTrip=nil end
    if self.offAt and now-self.offAt>1 and not self.suppressedTrip then self.suppressed=false end
    self.wasTaxi=true; self.offAt=nil
    if not self.active and (SFT.db.cinematicRecovery or self.motion) and not self:Restore(true) then return end
    if not self.active and s.enabled and not self.suppressed then self:Start() end
    if not self.active then return end
    if combat() then self:Exit(); return end
    if self.pendingApply and now>=self.pendingApply then self.pendingApply=nil; self:Apply() end
    local f=self.overlay; local trip=SFT.current
    if trip~=self.etaTrip or not self.etaAt or now>=self.etaAt then
        self.etaTrip=trip; self.etaAt=now+1
        self.total,self.source=nil,nil
        if trip then self.total,self.source=SFT:EstimateRoute(trip.route,trip.frequentFlier) end
    end
    local total,source=self.total,self.source
    local elapsed=trip and math.max(0,now-(trip.startedClock or now)) or 0
    local known=trip and total and total>0 and elapsed<=total and not trip.early
    if s.info then
        f.route:SetText(trip and (trip.early and "Early landing requested" or "Flying to "..SFT:FlightDestination(trip)) or "In flight")
        f.time:SetText(known and ("Arrival in "..SFT:ClockText(total-elapsed)..((source=="learned" or source=="calibrated") and "" or " (est.)")) or "Arrival time unknown")
        f.route:Show(); f.time:Show()
        if known then f.bar:SetValue(math.min(1,elapsed/total)); f.bar:Show() else f.bar:Hide() end
    else f.route:Hide(); f.time:Hide(); f.bar:Hide() end
    local zone=call(GetRealZoneText) or call(GetZoneText)
    if zone and zone~="" and zone~=self.lastZone then self.lastZone=zone; self.zoneUntil=now+5; f.zone:SetText(zone) end
    if s.zones and now<self.zoneUntil then f.zone:Show() else f.zone:Hide() end
end
local function guarded(fn)
    local ok,err=pcall(fn,C)
    if not ok then
        C.suppressed=true; C.suppressedTrip=SFT.current; pcall(C.Restore,C,true)
        if not C.reported then C.reported=true; SFT:Print("Cinematics stopped: "..tostring(err)) end
    end
end
local watcher=CreateFrame("Frame",nil,WorldFrame)
watcher:RegisterEvent("PLAYER_LOGIN"); watcher:RegisterEvent("PLAYER_ENTERING_WORLD"); watcher:RegisterEvent("PLAYER_LEAVING_WORLD"); watcher:RegisterEvent("PLAYER_DEAD"); watcher:RegisterEvent("PLAYER_ALIVE"); watcher:RegisterEvent("PLAYER_UNGHOST"); watcher:RegisterEvent("PLAYER_REGEN_ENABLED"); watcher:RegisterEvent("PLAYER_LOGOUT")
watcher:SetScript("OnEvent",function(_,event)
    if not SFT.db then return end
    if event=="PLAYER_ENTERING_WORLD" or event=="PLAYER_ALIVE" or event=="PLAYER_UNGHOST" then
        C.ready=true; guarded(function() C:Restore(true) end)
    elseif event=="PLAYER_REGEN_ENABLED" then
        if not C.active and SFT.db.cinematicRecovery then guarded(function() C:Restore(true) end) end
    else
        C.ready=false; guarded(function() C:Restore(true) end)
    end
end)
local elapsed, animationElapsed=0,0
watcher:SetScript("OnUpdate",function(_,dt)
    elapsed=elapsed+dt; animationElapsed=animationElapsed+dt
    if elapsed>=.15 then elapsed=0; guarded(C.Update) end
    if animationElapsed>=.05 then animationElapsed=0; if C.ready and (C.active or C.fadeOut) then guarded(function() C:Animate(GetTime()) end) end end
end)
_G.ShadyFlightTimerToggleCinematics=function() guarded(C.Toggle) end
function C:CreateSettings(parent)
    local s=self:Settings()
    local function label(text,x,y,template) local f=parent:CreateFontString(nil,"OVERLAY",template or "GameFontHighlight"); f:SetPoint("TOPLEFT",x,y); f:SetText(text); return f end
    local function changed(key) if C.active then if key=="enabled" and not s.enabled then C:Exit() else C.pendingApply=GetTime()+.25 end end end
    local function check(text,key,y)
        local b=CreateFrame("CheckButton",nil,parent,"UICheckButtonTemplate"); b:SetSize(26,26); b:SetPoint("TOPLEFT",20,y); b:SetChecked(s[key]);
        local l=label(text,0,0); l:ClearAllPoints(); l:SetPoint("LEFT",b,"RIGHT",4,0)
        b:SetScript("OnClick",function() s[key]=not not b:GetChecked(); changed(key) end)
    end
    label("CINEMATIC FLIGHT EXPERIENCE",22,-54,"GameFontNormalLarge")
    check("Automatically activate on taxi flights","enabled",-84)
    label("Camera style",22,-122,"GameFontNormal")
    local modes={}
    for i,mode in ipairs(self.modes) do
        local m=mode; local b=CreateFrame("Button",nil,parent,"UIPanelButtonTemplate"); b:SetSize(135,24); b:SetPoint("TOPLEFT",22+((i-1)%3)*140,-145-math.floor((i-1)/3)*29); modes[m]=b
        b:SetScript("OnClick",function() s.mode=m; for name,btn in pairs(modes) do btn:SetText((name==m and "* " or "")..name) end; changed() end)
    end
    for name,b in pairs(modes) do b:SetText((name==s.mode and "* " or "")..name) end
    local function slider(title,key,y,low,high,step,suffix)
        label(title,22,y,"GameFontNormal")
        local name="ShadyFlightCinema"..key; local b=CreateFrame("Slider",name,parent,"OptionsSliderTemplate"); b:SetSize(220,16); b:SetPoint("TOPLEFT",22,y-25); b:SetMinMaxValues(low,high); b:SetValueStep(step); if b.SetObeyStepOnDrag then b:SetObeyStepOnDrag(true) end
        _G[name.."Low"]:SetText(tostring(low)); _G[name.."High"]:SetText(tostring(high)); _G[name.."Text"]:SetText("")
        local val=label("",267,y-25); b:SetValue(s[key]); val:SetText(tostring(s[key])..suffix)
        b:SetScript("OnValueChanged",function(_,v) s[key]=math.floor(v/step+.5)*step; val:SetText(string.format(step<1 and "%.1f%s" or "%d%s",s[key],suffix)); changed() end)
    end
    slider("Maximum camera zoom","zoom",-214,1,4,.1,"x")
    slider("Camera rotation speed","speed",-275,0,100,5,"%")
    slider("Camera angle interval","interval",-336,6,30,1," sec")
    slider("Black bar size","barSize",-397,4,18,1,"%")
    check("Cinematic black bars","bars",-457)
    check("Hide gameplay interface","hideUI",-486)
    check("Show destination, countdown and progress","info",-515)
    check("Show zone transition titles","zones",-544)
    check("Smooth camera transitions","smooth",-573)
    check("Pause rotation while using mouse","manual",-600)
    local b=CreateFrame("Button",nil,parent,"UIPanelButtonTemplate"); b:SetSize(190,26); b:SetPoint("TOPLEFT",22,-634); b:SetText("Toggle cinematic now"); b:SetScript("OnClick",function() guarded(C.Toggle) end)
    label("ESC exits  |  /sft cinema toggles",22,-668)
    label("Key Bindings > Shady Airlines > Toggle Cinematics",22,-690,"GameFontHighlightSmall")
    local footer=parent:CreateFontString(nil,"OVERLAY","GameFontDisableSmall"); footer:SetPoint("BOTTOM",0,10); footer:SetText("RIP Shady")
end
BINDING_HEADER_SHADYFLIGHTTIMER="Shady Airlines"
BINDING_NAME_SHADYFLIGHTTIMERCINEMA="Toggle Cinematics"
