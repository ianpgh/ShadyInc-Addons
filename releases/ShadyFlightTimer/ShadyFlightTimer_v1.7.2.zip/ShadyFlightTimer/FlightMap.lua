local ADDON, SFT = ...
local function try1(fn, ...)
    if type(fn) ~= "function" then return nil end
    local ok, a = pcall(fn, ...)
    if ok then return a end
end
local function try2(fn, ...)
    if type(fn) ~= "function" then return nil, nil end
    local ok, a, b = pcall(fn, ...)
    if ok then return a, b end
end
local function makeKey(mapID, name, x, y, nodeID)
    if type(nodeID) == "number" and nodeID > 0 then return "node:" .. nodeID end
    if type(x) == "number" and type(y) == "number" then
        return tostring(mapID or "world") .. ":" .. string.format("%.4f:%.4f", x, y)
    end
    return tostring(mapID or "world") .. ":name:" .. tostring(name or "?")
end
local function cleanNode(node)
    if not node then return nil end
    -- Only serializable primitives are placed in SavedVariables.
    return { key = node.key, name = node.name, x = node.x, y = node.y }
end

function SFT:TakeSnapshot()
    if not self.db then return end
    local count = try1(NumTaxiNodes)
    if type(count) ~= "number" or count < 1 then return end
    local mapID = try1(GetTaxiMapID)
    if not mapID and C_Map and C_Map.GetBestMapForUnit then mapID = try1(C_Map.GetBestMapForUnit, "player") end
    local rawIDs = {}
    if C_TaxiMap and C_TaxiMap.GetAllTaxiNodes and mapID then
        local result = try1(C_TaxiMap.GetAllTaxiNodes, mapID)
        if type(result) == "table" then
            for _, entry in pairs(result) do
                if type(entry) == "table" and type(entry.slotIndex) == "number" then
                    rawIDs[entry.slotIndex] = entry.nodeID
                end
            end
        end
    end
    local width, height = nil, nil
    if C_Map and C_Map.GetMapWorldSize and mapID then
        width, height = try2(C_Map.GetMapWorldSize, mapID)
    end
    local snap = {
        mapID = mapID, nodeCount = count, nodes = {}, routes = {},
        worldWidth = width, worldHeight = height,
        moneyAtOpen = try1(GetMoney), lastMoney = try1(GetMoney),
    }
    local sourceSlot
    for i = 1, count do
        local name = try1(TaxiNodeName, i)
        local state = try1(TaxiNodeGetType, i)
        local x, y = try2(TaxiNodePosition, i)
        local cost = try1(TaxiNodeCost, i)
        local node = {
            slot = i, name = type(name) == "string" and name or ("Flight node " .. i),
            state = state, cost = type(cost) == "number" and cost or nil,
            x = x, y = y, key = makeKey(mapID, name, x, y, rawIDs[i]),
        }
        snap.nodes[i] = node
        if state == "CURRENT" then sourceSlot = i end
    end
    snap.origin = sourceSlot and snap.nodes[sourceSlot] or nil
    if not snap.origin then
        -- We cannot reliably associate a route without a known origin.
        self.taxiSnapshot = snap
        return
    end
    for i, destination in ipairs(snap.nodes) do
        if destination.state == "REACHABLE" then
            local path = { cleanNode(snap.origin) }
            local hops = try1(GetNumRoutes, i)
            if type(hops) == "number" and hops > 0 and hops <= 32 and type(TaxiGetNodeSlot) == "function" then
                for j = 1, hops do
                    local slot = try1(TaxiGetNodeSlot, i, j, false)
                    local routeNode = slot and snap.nodes[slot]
                    if routeNode and path[#path].key ~= routeNode.key then
                        path[#path + 1] = cleanNode(routeNode)
                    end
                end
            end
            -- The clicked destination is the FINAL endpoint even when the
            -- client includes fly-by nodes in TaxiGetNodeSlot's intermediate legs.
            -- Duplicate/stale endpoints are rejected instead of learned.
            while #path > 1 and path[#path].key == destination.key do
                table.remove(path)
            end
            path[#path + 1] = cleanNode(destination)
            if #path > 1 then
                snap.routes[i] = { nodes = path, key = self:RouteKey(path),
                    worldWidth = snap.worldWidth, worldHeight = snap.worldHeight }
            end
        end
    end
    self.taxiSnapshot = snap
end

function SFT:HoverFlightNode(slot)
    if not self.db then return end
    local snap = self.taxiSnapshot
    local route = snap and snap.routes and snap.routes[slot]
    local node = snap and snap.nodes and snap.nodes[slot]
    if not node or node.state ~= "REACHABLE" then return end
    if snap then
        snap.lastHoveredSlot = slot
        snap.lastHoveredAt = GetTime and GetTime() or 0
    end
    if not self.db.settings.tooltips or not GameTooltip or not GameTooltip:IsShown() then return end
    local seconds, source, count = self:EstimateRoute(route)
    GameTooltip:AddLine(" ")
    GameTooltip:AddLine("Shady Flight Timer", 1, 0.86, 0.27)
    if seconds then
        local confidence = source == "calibrated" and "Manually corrected time"
            or source == "learned" and ("Measured - " .. count .. " flight(s)")
            or source == "speed_scaled" and "Estimated using other speed profile"
            or source == "classic" and "Classic database - Forever not yet measured"
            or source == "segments" and "Estimated from measured hops"
            or "~ Rough map-distance estimate (not timed yet)"
        GameTooltip:AddDoubleLine("Flight duration", ((source == "classic" or source == "geometry" or source == "speed_scaled" or source == "segments") and "~" or "") .. self:ClockText(seconds), 1, 1, 1, 1, 1, 0.25)
        GameTooltip:AddLine(confidence, 0.75, 0.85, 0.9)
        if source == "learned" and route then
            local _, deviation, n = self:TimingDetails(route.key, self.db.settings.frequentFlier == true)
            if deviation then GameTooltip:AddLine(string.format("Recent mean absolute deviation: %.1fs (%d flights)", deviation, n), 0.75, 0.85, 0.9) end
        end
    else
        GameTooltip:AddDoubleLine("Flight duration", "Not learned yet", 1, 1, 1, 1, 0.75, 0.3)
    end
    if node.cost ~= nil then
        GameTooltip:AddDoubleLine("Fare quoted", self:MoneyText(node.cost), 0.9, 0.9, 0.9, 1, 0.86, 0.4)
    end
    if route then
        local trips, copper = 0, 0
        for _, t in ipairs(self.db.history) do
            if t.routeKey == route.key and t.cost ~= nil then
                trips = trips + 1
                copper = copper + t.cost
            end
        end
        if trips > 0 then
            GameTooltip:AddDoubleLine("Paid on prior flights", self:MoneyText(copper) .. " / " .. trips, 0.8, 0.8, 0.8, 0.8, 1, 0.6)
        end
    end
    GameTooltip:Show()
end

function SFT:InstallMapHooks()
    if not self.db or not hooksecurefunc then return end
    if not self._hookTake and type(TakeTaxiNode) == "function" then
        hooksecurefunc("TakeTaxiNode", function(slot) SFT:StartFlight(slot) end)
        self._hookTake = true
    end
    if not self._hookEarly and type(TaxiRequestEarlyLanding) == "function" then
        hooksecurefunc("TaxiRequestEarlyLanding", function() SFT:RequestEarlyLanding("taxi API") end)
        self._hookEarly = true
    end
    if not self._hookEarlyModern and C_TaxiMap and type(C_TaxiMap.RequestEarlyLanding) == "function" then
        hooksecurefunc(C_TaxiMap, "RequestEarlyLanding", function() SFT:RequestEarlyLanding("taxi API") end)
        self._hookEarlyModern = true
    end
    if not self._hookLegacyHover and type(TaxiNodeOnButtonEnter) == "function" then
        hooksecurefunc("TaxiNodeOnButtonEnter", function(button)
            if button and button.GetID then
                SFT:HoverFlightNode(button:GetID())
            end
        end)
        self._hookLegacyHover = true
    end
    if not self._hookModernHover and type(FlightMap_FlightPointPinMixin) == "table" and type(FlightMap_FlightPointPinMixin.OnMouseEnter) == "function" then
        hooksecurefunc(FlightMap_FlightPointPinMixin, "OnMouseEnter", function(pin)
            local node = pin and pin.taxiNodeData
            local slot = node and (node.slotIndex or node.slot)
            if not slot and pin and pin.GetID then slot = pin:GetID() end
            if slot then
                SFT:HoverFlightNode(slot)
            end
        end)
        self._hookModernHover = true
    end
    local function watchFrame(frame, field)
        if frame and frame.HookScript and not self[field] then
            frame:HookScript("OnShow", function()
                SFT.taxiVisible = true
                SFT:TakeSnapshot()
                if C_Timer and C_Timer.After then
                    C_Timer.After(0.15, function() SFT:TakeSnapshot() end)
                end
            end)
            frame:HookScript("OnHide", function() SFT.taxiVisible = false end)
            self[field] = true
        end
    end
    watchFrame(_G.FlightMapFrame, "_hookFlightFrame")
    watchFrame(_G.TaxiFrame, "_hookTaxiFrame")
    -- The flight map can be loaded after this addon. ADDON_LOADED calls us again.
end
