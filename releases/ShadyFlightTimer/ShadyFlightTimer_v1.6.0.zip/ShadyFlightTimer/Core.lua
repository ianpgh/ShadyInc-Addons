local ADDON, SFT = ...
SFT = SFT or {}
_G.ShadyFlightTimer = SFT
SFT.VERSION = "1.6.0"
SFT.sessionSpent = 0
SFT.sessionFlights = 0
SFT.taxiSnapshot = nil
SFT.current = nil
SFT.taxiVisible = false
SFT.hookedActionHero = false
SFT.hooksInstalled = false

local floor, max, min = math.floor, math.max, math.min
local function safeCall(fn, ...)
    if type(fn) ~= "function" then return nil end
    local ok, value = pcall(fn, ...)
    if ok then return value end
end
local function stamp()
    return (GetServerTime and GetServerTime()) or time()
end
local function secClock()
    return GetTime and GetTime() or 0
end
local function playerKey()
    local name = UnitName and UnitName("player") or "Unknown"
    local realm = GetRealmName and GetRealmName() or "Unknown"
    return (name or "Unknown") .. "-" .. (realm or "Unknown")
end
local defaults = {
    visible = true, tooltips = true,
    showFallbackLanding = true, notify = true, lock = false,
    scale = 1, x = 0, y = 160, minimapAngle = 225,
    showMinimap = true, preview = false,
    showAirlinesHeader = true, experimentalMascot = false,
    miniMode = false, -- presentation only; own saved location, never move the full timer
    miniX = 0, miniY = 245, -- independent anchor for the mini countdown
    skin = "classic", -- classic, wyvern, druid, orc, rogue
    -- These scale the LIVE TEXT only; illustrated textures and panel dimensions do not change.
    routeTextScale = 1, timeTextScale = 1, fareTextScale = 1,
    frequentFlier = false, -- manual per-account setting; never infer a talent

}
local function copyDefaults(t, template)
    for k, v in pairs(template) do if t[k] == nil then t[k] = v end end
end

function SFT:InitDB()
    if type(ShadyFlightTimerDB) ~= "table" then ShadyFlightTimerDB = {} end
    local db = ShadyFlightTimerDB
    db.settings = type(db.settings) == "table" and db.settings or {}
    copyDefaults(db.settings, defaults)
    if db.settings.skin ~= "classic" and db.settings.skin ~= "wyvern" and
       db.settings.skin ~= "druid" and db.settings.skin ~= "orc" and db.settings.skin ~= "rogue" then
        db.settings.skin = "classic"
    end
    for _, field in ipairs({ "routeTextScale", "timeTextScale", "fareTextScale" }) do
        local scale = tonumber(db.settings[field]) or 1
        db.settings[field] = max(0.75, min(1.5, floor(scale * 20 + 0.5) / 20))
    end
    db.settings.miniX = tonumber(db.settings.miniX) or 0
    db.settings.miniY = tonumber(db.settings.miniY) or 245
    db.routes = type(db.routes) == "table" and db.routes or {}
    db.segments = type(db.segments) == "table" and db.segments or {}
    -- Keep older data intact; fast-profile samples must never replace normal ones.
    db.fastRoutes = type(db.fastRoutes) == "table" and db.fastRoutes or {}
    db.fastSegments = type(db.fastSegments) == "table" and db.fastSegments or {}
    db.calibrations = type(db.calibrations) == "table" and db.calibrations or {}
    db.history = type(db.history) == "table" and db.history or {}
    db.totals = type(db.totals) == "table" and db.totals or { copper = 0, flights = 0 }
    db.characters = type(db.characters) == "table" and db.characters or {}
    db.totals.copper = tonumber(db.totals.copper) or 0
    db.totals.flights = tonumber(db.totals.flights) or 0
    self.db = db
    if type(db.pending) == "table" and (stamp() - (db.pending.startedEpoch or 0)) < 3600 then
        self.current = db.pending
        self.current.timingInterrupted = "Flight resumed after logout or reload"
        self.current.startedClock = secClock() - max(0, stamp() - db.pending.startedEpoch)
        self.current.deadlineClock = secClock() + 10
        self.current.sawTaxi = self.current.sawTaxi or false
        self.current.notOnTaxiAt = nil
        if self.current.early then
            -- Prior versions predicted an early landing at the next map waypoint.
            -- Those waypoints are NOT confirmed stops, including on resumed trips.
            self.current.earlyStop = "Next available landing"
            self.current.earlyStopETA = nil
            self.current.earlyStopUntil = nil
            self.current.earlyEstimate = false
        end
    else
        db.pending = nil
    end
end

function SFT:Print(message)
    if DEFAULT_CHAT_FRAME then DEFAULT_CHAT_FRAME:AddMessage("|cffEEDD55Shady Flight Timer:|r " .. tostring(message)) end
end
function SFT:ClockText(seconds)
    if type(seconds) ~= "number" then return "--:--" end
    seconds = max(0, floor(seconds + 0.5))
    return string.format("%d:%02d", floor(seconds / 60), seconds % 60)
end
function SFT:MoneyText(copper)
    if type(copper) ~= "number" then return "unknown" end
    copper = max(0, floor(copper))
    return string.format("%dg %ds %dc", floor(copper / 10000), floor(copper / 100) % 100, copper % 100)
end
function SFT:ValidDuration(duration)
    return type(duration) == "number" and duration == duration and duration >= 3 and duration <= 3600
end
function SFT:OutlierReason(storage, key, duration)
    if not self:ValidDuration(duration) then return "Duration outside valid bounds" end
    local r = key and storage[key]
    if type(r) == "table" and type(r.avg) == "number" and (tonumber(r.count) or 0) >= 3 then
        if math.abs(duration - r.avg) > max(15, r.avg * 0.25) then
            return "Timing outlier; route average preserved"
        end
    end
end
function SFT:AverageRecord(storage, key, duration)
    if not key or not self:ValidDuration(duration) then return end
    local r = storage[key]
    if type(r) ~= "table" or not self:ValidDuration(r.avg) then
        storage[key] = { avg = duration, count = 1, last = duration, recent = {duration} }
    else
        local count = max(1, tonumber(r.count) or 1)
        local alpha = count < 5 and (1 / (count + 1)) or 0.2
        r.avg = r.avg * (1 - alpha) + duration * alpha
        r.count = count + 1
        r.last = duration
        r.recent = type(r.recent) == "table" and r.recent or {}
        r.recent[#r.recent+1] = duration
        while #r.recent > 10 do table.remove(r.recent, 1) end
    end
end
function SFT:TimingDetails(routeKey, fast)
    local r = routeKey and (fast and self.db.fastRoutes or self.db.routes)[routeKey]
    if type(r) ~= "table" or not self:ValidDuration(r.avg) then return nil end
    local samples = type(r.recent) == "table" and r.recent or {}
    local deviation, n = 0, 0
    for _, v in ipairs(samples) do
        if self:ValidDuration(v) then deviation = deviation + math.abs(v-r.avg); n=n+1 end
    end
    return r.count or 1, n >= 2 and deviation/n or nil, n
end
function SFT:ResetLearnedRoute(routeKey, fast)
    if type(routeKey) ~= "string" or routeKey == "" then return false end
    if self.current then return false end
    for _, trip in ipairs(self.db.history) do
        if trip.routeKey == routeKey and (trip.frequentFlier == true) == (fast == true) then
            trip.timingReset = true
        end
    end
    self:RebuildRouteTime(routeKey, fast)
    return true
end
function SFT:SegmentKey(a, b)
    if not a or not b or not a.key or not b.key then return nil end
    return a.key .. "->" .. b.key
end
function SFT:RouteKey(nodes)
    if type(nodes) ~= "table" or #nodes < 2 then return nil end
    local keys = {}
    for _, node in ipairs(nodes) do
        if not node.key then return nil end
        keys[#keys + 1] = node.key
    end
    return table.concat(keys, ">")
end
-- Flight map coordinates are normalized to the taxi continent map. Where the
-- client returns that map's world size, convert straight-line hops to yards and
-- estimate 30 yards/second with a modest turn/climb allowance. This is a rough
-- FIRST-FLIGHT estimate, not a preloaded database of actual flight splines.
local function geometrySeconds(route, a, b)
    if not route or type(a.x) ~= "number" or type(b.x) ~= "number"
        or type(a.y) ~= "number" or type(b.y) ~= "number" then return nil end
    local w, h = route.worldWidth, route.worldHeight
    if type(w) ~= "number" or type(h) ~= "number" or w <= 0 or h <= 0 then return nil end
    local dx, dy = (a.x-b.x) * w, (a.y-b.y) * h
    local distance = math.sqrt(dx*dx + dy*dy)
    if distance < 1 then return nil end
    return max(10, distance * 1.18 / 30)
end

-- Flight-time profiles are deliberately separate. WoW Forever's Frequent Flier
-- talent gives +20% taxi speed, or 1/1.2 of the baseline flight duration.
-- The toggle is manual: the Legacy talent APIs are not guaranteed on all builds.
local FAST_RATIO = 1.2
function SFT:RouteSeconds(key, fast)
    if not key then return nil, "unknown", 0 end
    local override = self.db.calibrations[key]
    local profile = fast and "fast" or "normal"
    local value = type(override) == "table" and tonumber(override[profile]) or nil
    if value and value >= 3 and value <= 3600 then
        return value, "calibrated", 1
    end
    local primary = (fast and self.db.fastRoutes or self.db.routes)[key]
    if primary and primary.avg then return primary.avg, "learned", primary.count or 1 end
    local alternate = (fast and self.db.routes or self.db.fastRoutes)[key]
    if alternate and alternate.avg then
        return alternate.avg * (fast and (1 / FAST_RATIO) or FAST_RATIO), "speed_scaled", alternate.count or 1
    end
    return nil, "unknown", 0
end
function SFT:SegmentSeconds(a, b, fast)
    local key = self:SegmentKey(a, b)
    if not key then return nil, "unknown" end
    -- A direct two-point calibration is also an exact segment calibration.
    local rk = self:RouteKey({a,b})
    local override = rk and self.db.calibrations[rk]
    local profile = fast and "fast" or "normal"
    local value = type(override) == "table" and tonumber(override[profile]) or nil
    if value then return value, "calibrated" end
    local primary = (fast and self.db.fastSegments or self.db.segments)[key]
    if primary and primary.avg then return primary.avg, "measured" end
    local alternate = (fast and self.db.segments or self.db.fastSegments)[key]
    if alternate and alternate.avg then
        return alternate.avg * (fast and (1/FAST_RATIO) or FAST_RATIO), "speed_scaled"
    end
    return nil, "unknown"
end
function SFT:LatestFullFlight()
    for _, trip in ipairs(self.db.history) do
        if not trip.early and not trip.excludeTiming and not trip.timingReset and trip.trainingValid ~= false and
           type(trip.routeKey)=="string" and trip.routeKey ~= "" then
            return trip
        end
    end
end
-- Rebuild an affected route's measured average from history whenever the user
-- excludes or restores an incorrectly labeled flight. Never rewrite fares.
function SFT:RebuildRouteTime(routeKey, fast)
    if type(routeKey) ~= "string" or routeKey == "" then return end
    local store = fast and self.db.fastRoutes or self.db.routes
    local segmentStore = fast and self.db.fastSegments or self.db.segments
    store[routeKey] = nil
    -- A direct, two-node route was also saved as a measured segment in
    -- earlier versions; remove its contaminated segment time as well.
    local first, last = routeKey:match("^(.-)>([^>]+)$")
    local segmentKey
    if first and not first:find(">", 1, true) then
        segmentKey = first .. "->" .. last
        segmentStore[segmentKey] = nil
    end
    for i = #self.db.history, 1, -1 do
        local trip = self.db.history[i]
        if trip.routeKey == routeKey and (trip.frequentFlier == true) == (fast == true) and
           not trip.early and not trip.excludeTiming and not trip.timingReset and trip.trainingValid ~= false and
           type(trip.duration) == "number" then
            self:AverageRecord(store, routeKey, trip.duration)
            if segmentKey then self:AverageRecord(segmentStore, segmentKey, trip.duration) end
        end
    end
end
-- A manual override can outlive the incorrect recorded trip that motivated
-- it; only clear an override with a separate, explicit user action.
function SFT:ClearHistoryRouteCorrection(trip)
    if not trip or not trip.routeKey then return false end
    local profile = trip.frequentFlier and "fast" or "normal"
    local record = self.db.calibrations[trip.routeKey]
    if type(record) ~= "table" or record[profile] == nil then return false end
    record[profile] = nil
    if not next(record) then self.db.calibrations[trip.routeKey] = nil end
    self:RefreshTimer()
    if self.historyFrame and self.historyFrame:IsShown() then self:RefreshHistory() end
    return true
end
function SFT:SetHistoryTimingExcluded(trip, excluded)
    if not trip then return false end
    trip.excludeTiming = excluded and true or nil
    if trip.excludeTiming then
        trip.reviewReason = trip.reviewReason or "Manually flagged incorrect route"
    elseif trip.reviewReason == "Manually flagged incorrect route" then
        trip.reviewReason = nil
    end
    self:RebuildRouteTime(trip.routeKey, trip.frequentFlier == true)
    self:RefreshTimer()
    if self.historyFrame and self.historyFrame:IsShown() then self:RefreshHistory() end
    if self.settingsFrame and self.settingsFrame:IsShown() then self:RefreshSettings() end
    return true
end

function SFT:ParseDuration(raw)
    if type(raw) ~= "string" then return nil end
    raw = raw:match("^%s*(.-)%s*$")
    local minutes, seconds = raw:match("^(%d+):(%d%d?)$")
    local value
    if minutes and seconds and tonumber(seconds) < 60 then
        value = tonumber(minutes) * 60 + tonumber(seconds)
    elseif raw:match("^%d+$") then
        value = tonumber(raw)
    end
    if value and value >= 3 and value <= 3600 then return value end
end
-- Capture a route and speed profile once. Never fall back to older history
-- when a live or most-recent trip cannot safely identify its route.
function SFT:CalibrationTarget()
    local f = self.current
    if f then
        local to = self:FlightDestination(f)
        local nodes = f.route and f.route.nodes
        local key = f.route and f.route.key
        if not f.sawTaxi or f.early or f.routeConsistent == false or
           type(key) ~= "string" or key == "" or not nodes or #nodes < 2 or
           not f.selectedNodeKey or nodes[#nodes].key ~= f.selectedNodeKey or
           self:RouteKey(nodes) ~= key or to == "Destination unknown" or
           not f.from or f.from == "Unknown" then
            return nil, "Active flight route is not confirmed; no previous route will be edited."
        end
        local fast = f.frequentFlier
        if fast == nil then fast = self.db.settings.frequentFlier == true end
        local estimate = self:EstimateRoute(f.route, fast)
        return {routeKey=key, from=f.from, to=to, frequentFlier=fast == true,
            duration=estimate, active=f, flightID=f.id}
    end
    if UnitOnTaxi and UnitOnTaxi("player") then
        return nil, "Active taxi route is unknown; no previous route will be edited."
    end
    local trip = self.db.history[1]
    if not trip then return nil, "No completed flight recorded yet." end
    if trip.early or trip.excludeTiming or trip.trainingValid == false or
       type(trip.routeKey) ~= "string" or trip.routeKey == "" then
        return nil, "Most recent flight is incomplete or unverified; no older route will be edited."
    end
    local fast = trip.frequentFlier
    if fast == nil then fast = self.db.settings.frequentFlier == true end
    return {routeKey=trip.routeKey, from=trip.from, to=trip.to,
        frequentFlier=fast == true, duration=trip.duration, trip=trip}
end

function SFT:ValidateCalibrationTarget(target)
    if not target then return false, "No confirmed route selected. Reopen the correction window." end
    local current = self.current
    if target.active then
        if current == target.active then
            local live = self:CalibrationTarget()
            if live and live.routeKey == target.routeKey and live.frequentFlier == target.frequentFlier then return true end
        elseif not current and target.flightID and not (UnitOnTaxi and UnitOnTaxi("player")) then
            local trip = self.db.history[1]
            if trip and trip.flightID == target.flightID and trip.routeKey == target.routeKey and
               not trip.early and not trip.excludeTiming and not trip.timingReset and trip.trainingValid ~= false and
               (trip.frequentFlier == true) == target.frequentFlier then return true end
        end
    elseif not current and not (UnitOnTaxi and UnitOnTaxi("player")) and
        self.db.history[1] == target.trip and not target.trip.early and
        not target.trip.excludeTiming and target.trip.trainingValid ~= false and
        target.trip.routeKey == target.routeKey then return true end
    return false, "Flight changed or is no longer valid. Reopen the correction window."
end

function SFT:CalibrateTarget(target, raw)
    local valid, reason = self:ValidateCalibrationTarget(target)
    if not valid then return false, reason end
    local value = self:ParseDuration(raw)
    if not value then return false, "Use M:SS (e.g. 1:40) or seconds (e.g. 100)." end
    local profile = target.frequentFlier and "fast" or "normal"
    local record = self.db.calibrations[target.routeKey]
    if type(record) ~= "table" then record = {} end
    record[profile] = value
    self.db.calibrations[target.routeKey] = record
    self:RefreshTimer()
    if self.settingsFrame then self:RefreshSettings() end
    return true, (target.from or "?") .. " -> " .. (target.to or "?") .. " [" .. profile .. "] set to " .. self:ClockText(value) .. "."
end
function SFT:ClearCalibrationTarget(target)
    local valid, reason = self:ValidateCalibrationTarget(target)
    if not valid then return false, reason end
    local profile = target.frequentFlier and "fast" or "normal"
    local record = self.db.calibrations[target.routeKey]
    if type(record) ~= "table" or record[profile] == nil then
        return false, "No manual correction exists for that route and speed profile."
    end
    record[profile] = nil
    if not next(record) then self.db.calibrations[target.routeKey] = nil end
    self:RefreshTimer()
    if self.settingsFrame then self:RefreshSettings() end
    return true, "Manual time cleared; learned time or estimate will be used."
end
function SFT:CalibrateLatest(raw)
    local target, reason = self:CalibrationTarget()
    if not target then return false, reason end
    return self:CalibrateTarget(target, raw)
end
function SFT:ClearLatestCalibration()
    local target, reason = self:CalibrationTarget()
    if not target then return false, reason end
    return self:ClearCalibrationTarget(target)
end

function SFT:LegPlan(flight)
    local route = flight and flight.route
    local nodes = route and route.nodes
    if not nodes or #nodes < 2 then return nil end
    local fast = flight.frequentFlier
    if fast == nil then fast = self.db.settings.frequentFlier == true end
    local measured = self:RouteSeconds(route.key, fast)
    local legs, knownTotal, approxTotal = {}, 0, 0
    for i = 1, #nodes - 1 do
        local a, b = nodes[i], nodes[i+1]
        local secs, source = self:SegmentSeconds(a, b, fast)
        if not secs then
            secs, source = geometrySeconds(route, a, b), "geometry"
            if secs and fast then secs = secs / FAST_RATIO end
        end
        if not secs then return nil end
        if source == "measured" or source == "calibrated" then knownTotal = knownTotal + secs
        else approxTotal = approxTotal + secs end
        legs[#legs+1] = {destination=b, seconds=secs, source=source}
    end
    -- Use the full-route measured/manual time to scale the unmeasured legs.
    -- This does not promote geometry-derived legs into individually timed data.
    if measured and approxTotal > 0 then
        local remaining = max(1, measured - knownTotal)
        for _, leg in ipairs(legs) do
            if leg.source ~= "measured" and leg.source ~= "calibrated" then
                leg.seconds = max(1, leg.seconds * remaining / approxTotal)
            end
        end
    end
    return legs
end

function SFT:EstimateRoute(route, fast)
    if not route or not route.key then return nil, "unknown", 0 end
    if fast == nil then fast = self.db.settings.frequentFlier == true end
    local time, source, count = self:RouteSeconds(route.key, fast)
    if time then return time, source, count end
    local classic = self:ClassicRouteSeconds(route, fast)
    if classic then return classic, "classic", 0 end
    local plan = self:LegPlan({route=route, frequentFlier=fast})
    if not plan then return nil, "unknown", 0 end
    local total, hasGeometry, scaled = 0, false, false
    for _, leg in ipairs(plan) do
        total = total + leg.seconds
        if leg.source == "geometry" then hasGeometry = true end
        if leg.source == "speed_scaled" then scaled = true end
    end
    if hasGeometry then return nil, "unknown", 0 end
    if scaled then return total, "speed_scaled", #plan end
    return total, "segments", #plan
end
function SFT:RequestEarlyLanding(source)
    local f = self.current
    if not f or not f.sawTaxi or f.early then return end
    f.early = true
    f.earlySource = source or "request"
    f.earlyRequestEpoch = stamp()
    f.earlyStopRequestClock = secClock()
    -- TaxiGetNodeSlot returns routing waypoints, NOT proof that the taxi
    -- actually lands at those nodes. Do not predict the early-landing stop
    -- or its ETA from LegPlan, even when a full-route time was learned.
    -- Full-route and segment measurements remain available for ordinary ETAs.
    f.earlyStop = "Next available landing"
    f.earlyStopETA = nil
    f.earlyStopUntil = nil
    f.earlyEstimate = false
    self:Print("Early landing requested. The next landing and ETA are not confirmed by the taxi map.")
    self:RefreshTimer()
end

function SFT:ConfirmFare(f, paid)
    if not f or f.farePaid ~= nil then return end
    if type(paid) ~= "number" or paid < 0 then return end
    paid = floor(paid)
    -- Prevent attributing unrelated purchases to the flight.
    if f.quote and f.quote > 0 and paid > f.quote * 2 + 1000 then return end
    f.farePaid = paid
    f.fareStatus = "confirmed"
    -- Book once at payment time rather than when the taxi lands: the charge
    -- persists if the player logs out or reloads while mid-flight.
    if not f.fareBooked then
        f.fareBooked = true
        self.db.totals.copper = (self.db.totals.copper or 0) + paid
        self.sessionSpent = self.sessionSpent + paid
        local key = f.character or playerKey()
        local c = self.db.characters[key] or {flights=0,copper=0}
        c.copper = (c.copper or 0) + paid
        self.db.characters[key] = c
    end
    self:RefreshTimer()
end
function SFT:CheckFare()
    local f = self.current
    if not f or f.farePaid ~= nil or not f.moneyBefore then return end
    if secClock() - (f.startedClock or secClock()) > 8 then return end
    local money = safeCall(GetMoney)
    if type(money) == "number" then
        local spent = f.moneyBefore - money
        if spent <= 0 and f.moneyAtOpen then spent = f.moneyAtOpen - money end
        if spent > 0 then self:ConfirmFare(f, spent) end
    end
end
-- One canonical destination getter for the timer and flight history.
-- It never substitutes the departure point for a missing destination.
local function sameStop(a, b)
    if type(a) ~= "string" or type(b) ~= "string" then return false end
    local aShort = (a:match("^%s*([^,]+)") or a):lower()
    local bShort = (b:match("^%s*([^,]+)") or b):lower()
    return aShort == bShort
end

function SFT:FlightDestination(f)
    if not f then return "Destination unknown" end
    local to = f.destination
    local route = f.route
    local endNode = route and route.nodes and route.nodes[#route.nodes]
    local lastName = endNode and endNode.name
    if (type(to) ~= "string" or to == "" or to == "Unknown" or sameStop(to, f.from))
        and type(lastName) == "string" and lastName ~= "" and not sameStop(lastName, f.from) then
        to = lastName
    end
    if type(to) ~= "string" or to == "" or to == "Unknown" or sameStop(to, f.from) then
        return "Destination unknown"
    end
    return to
end

function SFT:StartFlight(slot)
    local snapshot = self.taxiSnapshot
    if self.current and self.current.sawTaxi then return end
    local route = snapshot and snapshot.routes and snapshot.routes[slot]
    local dest = snapshot and snapshot.nodes and snapshot.nodes[slot]
    if not dest and not route then
        self:TakeSnapshot()
        snapshot = self.taxiSnapshot
        route = snapshot and snapshot.routes and snapshot.routes[slot]
        dest = snapshot and snapshot.nodes and snapshot.nodes[slot]
    end
    -- A taxi-map slot is only a destination if it is reachable and not
    -- the CURRENT (departure) stop. Recover an invalid selection from the
    -- flight point actually hovered immediately before purchase, if known.
    -- A map can change its slots while closing. A recorded node is only
    -- trustworthy if it agrees with the explicit click, or the still-open
    -- taxi node API. An old hover on its own is not sufficient to infer a stop.
    local hoveredSlot = snapshot and snapshot.lastHoveredSlot
    local hoveredAge = snapshot and (secClock() - (snapshot.lastHoveredAt or -100))
    local hovered = hoveredSlot and snapshot.nodes and snapshot.nodes[hoveredSlot]
    if (not dest or dest.state == "CURRENT" or
        (snapshot and snapshot.origin and dest.key == snapshot.origin.key)) and
        hovered and hovered.state == "REACHABLE" and hoveredAge and hoveredAge <= 3 then
        dest = hovered
        route = snapshot.routes and snapshot.routes[hoveredSlot]
    end
    if not route and dest and snapshot and snapshot.origin and
        dest.key ~= snapshot.origin.key and dest.state ~= "CURRENT" then
        route = { nodes = { snapshot.origin, dest } }
        route.key = self:RouteKey(route.nodes)
    end
    local now = secClock()
    -- The hook can run AFTER Blizzard has deducted the fare. Preserve the
    -- original balance at taxi-map open; lastMoney may already be updated.
    local before = snapshot and (snapshot.moneyAtOpen or snapshot.lastMoney) or safeCall(GetMoney)
    local f = {
        route = route, from = snapshot and snapshot.origin and snapshot.origin.name or "Unknown",
        destination = dest and dest.name or "Unknown", quote = dest and dest.cost,
        startedEpoch = stamp(), startedClock = now, deadlineClock = now + 12,
        sawTaxi = UnitOnTaxi and UnitOnTaxi("player") or false,
        moneyBefore = before, moneyAtOpen = snapshot and snapshot.moneyAtOpen, character = playerKey(), early = false,
        frequentFlier = self.db.settings.frequentFlier == true,
        id = tostring(stamp()) .. ":" .. tostring(now),
    }
    -- Store the ticket destination separately from any intermediate leg.
    -- Only an actual click on a reachable destination may identify the end.
    f.destination = self:FlightDestination(f)
    f.selectedSlot = slot
    f.selectedNodeKey = dest and dest.key
    f.selectedDestination = dest and dest.name
    f.expectedZone = dest and type(dest.name) == "string" and dest.name:match(",%s*([^,]+)%s*$") or nil
    f.zoneAtPurchase = (GetRealZoneText and GetRealZoneText()) or (GetZoneText and GetZoneText())
    f.routeConsistent = true
    if not dest or dest.state ~= "REACHABLE" or
       f.destination == "Destination unknown" then
        f.routeConsistent = false
    end
    if route and route.nodes and #route.nodes > 1 then
        local finalNode = route.nodes[#route.nodes]
        if dest and finalNode and finalNode.key ~= dest.key then
            f.routeConsistent = false
        end
    elseif not route then
        f.routeConsistent = false
    end
    self.current = f
    self.db.pending = f
    if f.quote == 0 then self:ConfirmFare(f, 0) end
    self:CheckFare()
    self:RefreshTimer()
end
function SFT:FinishFlight()
    local f = self.current
    if not f then return end
    self:CheckFare()
    -- Measure when taxi control first ended, not after the brief debounce.
    local taxiEndClock = f.notOnTaxiAt or secClock()
    local elapsed = max(0, (taxiEndClock - (f.startedClock or taxiEndClock)))
    self.current = nil
    self.db.pending = nil
    if not f.sawTaxi or elapsed < 3 then self:RefreshTimer() return end
    local landedZone = (GetRealZoneText and GetRealZoneText()) or (GetZoneText and GetZoneText())
    local function normalizedZone(zone)
        if type(zone) ~= "string" then return nil end
        zone = zone:match("^%s*(.-)%s*$")
        return zone and zone ~= "" and zone:lower() or nil
    end
    local expected = normalizedZone(f.expectedZone)
    local arrived = normalizedZone(landedZone)
    -- An apparent landing at an unrelated zone is not proof of arrival.
    -- Keep the fare/flight record but never teach that wrong route.
    local stopName = normalizedZone(f.selectedDestination and f.selectedDestination:match("^%s*([^,]+)"))
    local mismatch = expected and arrived and expected ~= arrived and stopName ~= arrived
    local verified = (not f.early) and f.routeConsistent == true and not mismatch and not f.timingInterrupted and f.route and f.route.key and f.destination ~= "Destination unknown"
    local reason = mismatch and ("Ticket target zone " .. tostring(f.expectedZone) ..
        ", landed in " .. tostring(landedZone))
        or (f.routeConsistent == false and "Taxi selection or route could not be verified") or nil
    local fast = f.frequentFlier == true
    local routes = fast and self.db.fastRoutes or self.db.routes
    local segments = fast and self.db.fastSegments or self.db.segments
    local outlier = verified and self:OutlierReason(routes, f.route.key, elapsed)
    if verified and not outlier and f.route.nodes and #f.route.nodes == 2 then
        outlier = self:OutlierReason(segments, self:SegmentKey(f.route.nodes[1], f.route.nodes[2]), elapsed)
    end
    reason = f.timingInterrupted or outlier or reason
    verified = verified and not outlier and true or false
    local trip = {
        when = stamp(), flightID = f.id, character = f.character, from = f.from, to = f.destination,
        duration = floor(elapsed + 0.5), cost = f.farePaid,
        quote = f.quote, early = f.early and true or false,
        earlyStop = f.earlyStop, routeKey = f.route and f.route.key,
        frequentFlier = f.frequentFlier == true,
        selectedDestination = f.selectedDestination, targetZone = f.expectedZone,
        landedZone = landedZone, selectedNodeKey = f.selectedNodeKey,
        -- Legacy path is a *map node* count, never a landing/stop count.
        path = f.route and f.route.nodes and #f.route.nodes or nil,
        reportedWaypointCount = 0,
        -- The taxi ended and the player remained off taxi through the debounce:
        -- one observed landing. Short transitions in the middle of a route are
        -- not counted as stops unless separately confirmed (currently none).
        confirmedLandingCount = 1,
        confirmedIntermediateLandings = 0,
        -- Diagnostics only. TaxiMap-reported fly-through waypoints do not
        -- establish that the taxi stopped or that the player landed there.
        reportedVia = {},
        trainingValid = verified, reviewReason = reason, timingInterrupted = f.timingInterrupted,
    }
    if f.route and type(f.route.nodes) == "table" then
        for i = 2, #f.route.nodes - 1 do
            local node = f.route.nodes[i]
            if node and type(node.name) == "string" then
                trip.reportedVia[#trip.reportedVia + 1] = node.name
            end
        end
    end
    trip.reportedWaypointCount = #trip.reportedVia
    table.insert(self.db.history, 1, trip)
    -- Full History deliberately retains all existing recorded flights.
    -- No automatic trimming; users can audit even the oldest entries.
    self.db.totals.flights = (self.db.totals.flights or 0) + 1
    self.sessionFlights = self.sessionFlights + 1
    local key = f.character or "Unknown"
    local character = self.db.characters[key] or { flights = 0, copper = 0 }
    character.flights = (character.flights or 0) + 1
    -- v1.0 bookings occurred on landing. v1.1 expenses are recorded immediately
    -- in ConfirmFare, which is idempotent via fareBooked.
    if f.farePaid ~= nil and not f.fareBooked then
        self.db.totals.copper = (self.db.totals.copper or 0) + f.farePaid
        self.sessionSpent = self.sessionSpent + f.farePaid
        character.copper = (character.copper or 0) + f.farePaid
        f.fareBooked = true
    end
    self.db.characters[key] = character
    -- Early landings or an unresolved destination must never contaminate
    -- the full-route average.
    if verified and f.destination ~= "Destination unknown" and
        f.route and f.route.key then
        local fast = f.frequentFlier == true
        local routes = fast and self.db.fastRoutes or self.db.routes
        local segments = fast and self.db.fastSegments or self.db.segments
        self:AverageRecord(routes, f.route.key, elapsed)
        if f.route.nodes and #f.route.nodes == 2 then
            self:AverageRecord(segments, self:SegmentKey(f.route.nodes[1], f.route.nodes[2]), elapsed)
        end
    end
    local trainingMessage = f.early and "Early stop; full-route time not trained."
        or (verified and "Route learned." or "Route NOT learned: " .. (reason or "requires review"))
    self:Print("Landed after " .. self:ClockText(elapsed) .. ". " .. trainingMessage ..
        " Fare: " .. (f.farePaid and self:MoneyText(f.farePaid) or "unconfirmed") .. ".")
    if self.historyFrame and self.historyFrame:IsShown() then self:RefreshHistory() end
    self:RefreshTimer()
    if self.settingsFrame and self.settingsFrame:IsShown() then self:RefreshSettings() end
    if self.db.settings.notify and PlaySound then
        if SOUNDKIT and SOUNDKIT.IG_MAINMENU_OPTION_CHECKBOX_ON then
            pcall(PlaySound, SOUNDKIT.IG_MAINMENU_OPTION_CHECKBOX_ON)
        end
    end
end
function SFT:Tick()
    local f = self.current
    if not f then
        self:WatchActionHero()
        return
    end
    local now = secClock()
    local onTaxi = UnitOnTaxi and UnitOnTaxi("player") or false
    if f.lastTickClock and now - f.lastTickClock > 15 then
        f.timingInterrupted = f.timingInterrupted or "Flight observation interrupted for over 15 seconds"
    end
    f.lastTickClock = now
    if onTaxi then
        f.sawTaxi = true
        f.notOnTaxiAt = nil
        self:CheckFare()
    elseif not f.sawTaxi then
        if now > (f.deadlineClock or now + 1) then
            self.current = nil
            self.db.pending = nil
        end
    else
        f.notOnTaxiAt = f.notOnTaxiAt or now
        -- Some multi-stop flights briefly release taxi control between legs.
        -- A longer debounce avoids splitting one ticket into bogus flights.
        if now - f.notOnTaxiAt > 4.5 then
            self:FinishFlight()
            return
        end
    end
    self:WatchActionHero()
    self:RefreshTimer()
end
function SFT:WatchActionHero()
    if self.hookedActionHero then return end
    local button = _G.ActionHeroFlightStop
    if button and button.HookScript then
        button:HookScript("OnClick", function()
            SFT:RequestEarlyLanding("Action Hero")
        end)
        self.hookedActionHero = true
    end
end
function SFT:OnMoneyEvent()
    self:CheckFare()
    if self.taxiSnapshot and self.taxiVisible then
        self.taxiSnapshot.lastMoney = safeCall(GetMoney)
    end
end
function SFT:OnUpdate(elapsed)
    self._accum = (self._accum or 0) + elapsed
    if self._accum < 0.20 then return end
    self._accum = 0
    if self.taxiVisible and self.taxiSnapshot then
        self.taxiSnapshot.lastMoney = safeCall(GetMoney)
    end
    self:Tick()
end
function SFT:Status()
    local map = self.taxiSnapshot
    local f = self.current
    self:Print("v" .. self.VERSION .. " | map " .. (map and tostring(map.mapID) or "not captured") ..
        " | nodes " .. (map and tostring(map.nodeCount) or "0") ..
        " | ticket destination " .. (f and tostring(f.selectedDestination or f.destination) or "none") ..
        " | route end " .. (f and f.route and f.route.nodes and f.route.nodes[#f.route.nodes] and tostring(f.route.nodes[#f.route.nodes].name) or "none") ..
        " | taxi " .. tostring(UnitOnTaxi and UnitOnTaxi("player")) ..
        " | AH hooked " .. tostring(self.hookedActionHero))
end

local events = CreateFrame("Frame")
events:RegisterEvent("ADDON_LOADED")
events:RegisterEvent("PLAYER_LOGIN")
events:RegisterEvent("PLAYER_ENTERING_WORLD")
events:RegisterEvent("PLAYER_CONTROL_LOST")
events:RegisterEvent("PLAYER_CONTROL_GAINED")
events:RegisterEvent("PLAYER_MONEY")
events:RegisterEvent("PLAYER_LEAVING_WORLD")
events:RegisterEvent("PLAYER_DEAD")
events:RegisterEvent("TAXIMAP_OPENED")
events:RegisterEvent("TAXIMAP_CLOSED")
events:SetScript("OnUpdate", function(_, elapsed) if SFT.db then SFT:OnUpdate(elapsed) end end)
events:SetScript("OnEvent", function(_, event, arg)
    if event == "ADDON_LOADED" then
        if arg == ADDON then SFT:InitDB() end
        if SFT.db then SFT:InstallMapHooks() end
    elseif event == "PLAYER_LOGIN" then
        if not SFT.db then SFT:InitDB() end
        SFT:InstallMapHooks()
        SFT:InitUI()
        SFT:Tick()
    elseif event == "TAXIMAP_OPENED" then
        SFT.taxiVisible = true
        SFT:TakeSnapshot()
        if C_Timer and C_Timer.After then C_Timer.After(0.15, function() SFT:TakeSnapshot() end) end
    elseif event == "TAXIMAP_CLOSED" then
        SFT.taxiVisible = false
    elseif event == "PLAYER_LEAVING_WORLD" or event == "PLAYER_DEAD" then
        if SFT.current then SFT.current.timingInterrupted = "World transition or death during flight" end
    elseif event == "PLAYER_MONEY" then
        SFT:OnMoneyEvent()
    elseif event == "PLAYER_ENTERING_WORLD" or event == "PLAYER_CONTROL_LOST" or event == "PLAYER_CONTROL_GAINED" then
        if SFT.db then SFT:Tick() end
    end
end)
