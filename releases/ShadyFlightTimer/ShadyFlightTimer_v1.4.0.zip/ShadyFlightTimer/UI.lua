local ADDON, SFT = ...
local floor, max, min = math.floor, math.max, math.min

local SKIN_NAMES = {
    classic = "Classic Shadow Priest",
    wyvern = "Shadow Wyvern",
    druid = "Stealthed Tauren Druid",
    orc = "Orc Forgemaster",
    rogue = "Shadow Rogue Heist",
}
local function panelSkin(skin)
    return skin == "wyvern" or skin == "druid" or skin == "orc" or skin == "rogue"
end
local SKIN_TEXTURES = {
    wyvern = "Interface\\AddOns\\ShadyFlightTimer\\Textures\\ShadyWyvern.tga",
    druid = "Interface\\AddOns\\ShadyFlightTimer\\Textures\\ShadyDruid.tga",
    orc = "Interface\\AddOns\\ShadyFlightTimer\\Textures\\ShadyOrc.tga",
    rogue = "Interface\\AddOns\\ShadyFlightTimer\\Textures\\ShadyRogue.tga",
}

-- Keep the timer label short; expense reports still use the existing full format.
local function shortMoney(copper)
    if type(copper) ~= "number" then return "not confirmed" end
    copper = max(0, floor(copper))
    local g, s, c = floor(copper / 10000), floor(copper / 100) % 100, copper % 100
    local parts = {}
    if g > 0 then parts[#parts+1] = g .. "g" end
    if s > 0 then parts[#parts+1] = s .. "s" end
    if c > 0 or #parts == 0 then parts[#parts+1] = c .. "c" end
    return table.concat(parts, " ")
end


local function makeSolid(frame, alpha)
    local bg = frame:CreateTexture(nil, "BACKGROUND")
    bg:SetAllPoints(frame)
    bg:SetColorTexture(0.055, 0.065, 0.075, alpha or 0.97)
    frame._solidBackground = bg
end
local function button(parent, label, width, height, func)
    local b = CreateFrame("Button", nil, parent, "UIPanelButtonTemplate")
    b:SetSize(width, height)
    b:SetText(label)
    b:SetScript("OnClick", func)
    return b
end
local function setMinimapPosition(btn, angle)
    if not btn or not Minimap then return end
    local r = math.rad(angle or 225)
    btn:ClearAllPoints()
    btn:SetPoint("CENTER", Minimap, "CENTER", math.cos(r) * 78, math.sin(r) * 78)
end
local function getAngle(y, x)
    if math.atan2 then return math.deg(math.atan2(y, x)) end
    if x == 0 then return y >= 0 and 90 or -90 end
    local a = math.deg(math.atan(y / x))
    if x < 0 then a = a + 180 end
    return a
end

function SFT:CreateMinimapButton()
    if self.minimapButton or not Minimap then return end
    local btn = CreateFrame("Button", "ShadyFlightTimerMinimap", Minimap)
    btn:SetSize(28, 28)
    btn:SetFrameStrata("MEDIUM")
    btn:SetFrameLevel(Minimap:GetFrameLevel() + 6)
    btn:RegisterForClicks("LeftButtonUp", "RightButtonUp")
    btn:RegisterForDrag("LeftButton")
    local icon = btn:CreateTexture(nil, "ARTWORK")
    icon:SetPoint("CENTER")
    icon:SetSize(18, 18)
    icon:SetTexture("Interface\\Icons\\Ability_Hunter_EagleEye")
    local ring = btn:CreateTexture(nil, "OVERLAY")
    ring:SetSize(52, 52)
    ring:SetPoint("CENTER")
    ring:SetTexture("Interface\\Minimap\\MiniMap-TrackingBorder")
    btn:SetScript("OnEnter", function(self)
        GameTooltip:SetOwner(self, "ANCHOR_LEFT")
        GameTooltip:AddLine("Shady Airlines - Flight Timer", 1, 0.86, 0.25)
        GameTooltip:AddLine("Left click: settings", 1, 1, 1)
        GameTooltip:AddLine("Right click: show / hide timer", 1, 1, 1)
        GameTooltip:AddLine("Drag: move minimap icon", 0.8, 0.8, 0.8)
        GameTooltip:Show()
    end)
    btn:SetScript("OnLeave", function() GameTooltip:Hide() end)
    btn:SetScript("OnClick", function(_, which)
        if which == "RightButton" then
            SFT.db.settings.visible = not SFT.db.settings.visible
            SFT:RefreshTimer()
            SFT:RefreshSettings()
        else
            SFT:ToggleSettings()
        end
    end)
    btn:SetScript("OnDragStart", function(self)
        self:SetScript("OnUpdate", function(self)
            local mx, my = Minimap:GetCenter()
            local cx, cy = GetCursorPosition()
            local scale = UIParent:GetEffectiveScale()
            local angle = getAngle(cy / scale - my, cx / scale - mx)
            SFT.db.settings.minimapAngle = angle
            setMinimapPosition(self, angle)
        end)
    end)
    btn:SetScript("OnDragStop", function(self)
        self:SetScript("OnUpdate", nil)
    end)
    self.minimapButton = btn
    setMinimapPosition(btn, self.db.settings.minimapAngle)
    if not self.db.settings.showMinimap then btn:Hide() end
end

-- A presentation-only switch. It never modifies current flight or account data.
-- Three presentation modes share the same flight and money state.  The
-- illustrated theme is ONE composited texture plus live, anchored FontStrings:
-- there are no baked-in route names, times, or fare amounts in the texture.
local function setFontSize(widget, size, flags)
    local path = GameFontNormal and GameFontNormal:GetFont()
    if path then widget:SetFont(path, size, flags or "OUTLINE") end
end

-- Taxi nodes commonly include a second zone after a comma. Retain the
-- complete labels in the hover tooltip; remove the redundant zone only in
-- the restricted painted plaques.
local function shortStop(name)
    if type(name) ~= "string" then return "?" end
    local value = name:gsub(",%s*[^,]+$", "")
    value = value:match("^%s*(.-)%s*$") or ""
    return value ~= "" and value or "?"
end

local function displayedWidth(fontString, text, fontSize)
    -- This ignores the constrained width of a FontString, if the client has it.
    if fontString.GetUnboundedStringWidth then
        local width = fontString:GetUnboundedStringWidth()
        if type(width) == "number" and width > 0 then return width end
    end
    if fontString.GetStringWidth then
        local width = fontString:GetStringWidth()
        if type(width) == "number" and width > 0 then return width end
    end
    return #text * fontSize * 0.61
end

local function textFits(widget, text, width, size, flags)
    setFontSize(widget, size, flags)
    widget:SetText(text)
    return displayedWidth(widget, text, size) <= width - 8
end

-- All text fitting is restricted to the existing illustrated plaques.
-- The backdrop texture and the dimensions of the parent frame NEVER change.
-- A user's slider sets the preferred upper size; the string is always
-- measured and reduced if needed. Do not allow wrapping/overflow by default.
local function fitOneLine(widget, text, width, preferred, minimum, flags, noTruncate)
    text = tostring(text or "")
    if widget.SetWordWrap then widget:SetWordWrap(false) end
    if widget.SetMaxLines then widget:SetMaxLines(1) end
    preferred = math.max(8, preferred)
    minimum = math.min(preferred, math.max(8, minimum))
    local size = preferred
    while size >= minimum do
        if textFits(widget, text, width, size, flags) then return true, size end
        size = size - 0.5
    end
    if textFits(widget, text, width, minimum, flags) then return true, minimum end
    if noTruncate then
        -- No countdown digits may ever be clipped or replaced with ellipses.
        for smaller = minimum - 0.5, 8, -0.5 do
            if textFits(widget, text, width, smaller, flags) then return true, smaller end
        end
        setFontSize(widget, 8, flags)
        widget:SetText(text)
        return false, 8
    end
    -- Only extreme place names or fare strings need ellipsizing. The full
    -- original route and fare remain visible in the existing hover tooltip.
    local cut = text
    while #cut > 2 do
        cut = cut:sub(1, -2)
        if textFits(widget, cut .. "..", width, minimum, flags) then return false, minimum end
    end
    setFontSize(widget, minimum, flags)
    widget:SetText("..")
    return false, minimum
end

local function fitSplitRoute(widget, fromStop, toStop, width, preferred)
    -- When one line gets cramped, put one stop per line INSIDE the top plaque.
    -- The full route is preserved in the hover tooltip, not discarded.
    local line1 = fromStop
    local line2 = "> " .. toStop
    local size = math.min(12.5, preferred)
    local minimum = math.min(size, math.max(9.0, preferred * 0.75))
    local function fitBoth(fontSize)
        return textFits(widget, line1, width, fontSize, "OUTLINE") and
            textFits(widget, line2, width, fontSize, "OUTLINE")
    end
    local selected
    while size >= minimum do
        if fitBoth(size) then selected = size break end
        size = size - 0.5
    end
    selected = selected or minimum
    -- Rare very long stop names: limit each line independently, never wrap a
    -- third line or overlap the middle timer plaque.
    local function shorten(text)
        if textFits(widget, text, width, selected, "OUTLINE") then return text end
        local short = text
        while #short > 3 do
            short = short:sub(1, -2)
            if textFits(widget, short .. "..", width, selected, "OUTLINE") then return short .. ".." end
        end
        return ".."
    end
    line1, line2 = shorten(line1), shorten(line2)
    setFontSize(widget, selected, "OUTLINE")
    if widget.SetWordWrap then widget:SetWordWrap(false) end
    if widget.SetMaxLines then widget:SetMaxLines(2) end
    widget:SetText(line1 .. "\n" .. line2)
    return selected
end

function SFT:SetFlightRouteLabel(full, display)
    local w = self.timerRoute
    if not w then return end
    local frame = self.timerFrame
    local settings = self.db.settings
    if frame then frame._fullRouteLabel = full end
    local mult = settings.routeTextScale or 1
    local key = (frame and frame._appearanceKey or "") .. "|" .. tostring(full) .. "|" ..
        tostring(display) .. "|" .. tostring(mult)
    if frame and frame._lastRouteFit == key then return end
    if frame then frame._lastRouteFit = key end
    local illustrated = settings.experimentalMascot and not settings.miniMode
    local wyvern = illustrated and panelSkin(settings.skin)
    if wyvern then
        local text = display or full or "?"
        local preferred = math.min(15, 12.5 * mult)
        w:ClearAllPoints()
        -- Keep the location below the painted CURRENT FLIGHT label and above
        -- the lower gold rail; the earlier -95 anchor pressed it into the rail.
        local newArt = settings.skin ~= "wyvern"
        w:SetPoint("TOPLEFT", frame, "TOPLEFT", newArt and 396 or 370, newArt and -84 or -88)
        w:SetPoint("TOPRIGHT", frame, "TOPRIGHT", newArt and -16 or -20, newArt and -84 or -88)
        w:SetHeight(16)
        w:SetJustifyH("CENTER")
        if newArt then frame.skinTitle:Hide() else frame.skinTitle:Show() end
        if w.SetWordWrap then w:SetWordWrap(false) end
        if w.SetMaxLines then w:SetMaxLines(1) end
        -- Try one readable line, but don't squash long route names to 8px.
        local oneLineMinimum = math.max(9, preferred - 0.75)
        for size = preferred, oneLineMinimum, -0.25 do
            if textFits(w, text, newArt and 145 or 170, size, "OUTLINE") then return end
        end
        local fromStop, toStop = text:match("^(.-)%s+>%s+(.+)$")
        if fromStop and toStop then
            -- Give both location names the entire plaque; the small CURRENT
            -- FLIGHT caption is suppressed only for this two-line variant.
            frame.skinTitle:Hide()
            w:ClearAllPoints()
            w:SetPoint("TOPLEFT", frame, "TOPLEFT", 370, -75)
            w:SetPoint("TOPRIGHT", frame, "TOPRIGHT", -20, -75)
            w:SetHeight(29)
            w:SetJustifyH("CENTER")
            fitSplitRoute(w, fromStop, toStop, 170, preferred)
        else
            fitOneLine(w, text, newArt and 145 or 170, preferred, math.max(9, preferred * 0.72), "OUTLINE")
        end
    elseif illustrated then
        fitOneLine(w, full, 274, 13 * mult, 9.5 * mult, "OUTLINE")
    elseif not settings.miniMode then
        fitOneLine(w, full, 260, 13, 10, "OUTLINE")
    else
        w:SetText(full or "")
    end
end

-- At most one measurement per distinct displayed value: the flight ticker
-- refreshes five times a second, but many ticks contain identical text.
-- Keep any shortened display string when reusing a cached fit.
local function fitLiveField(widget, width, preferred, minimum, flags, appearance)
    local original = tostring(widget:GetText() or "")
    local signature = tostring(appearance) .. "|" .. original .. "|" ..
        tostring(width) .. "|" .. tostring(preferred) .. "|" .. tostring(minimum)
    if widget._lastAutoFit == signature then
        if widget._lastAutoFitText then widget:SetText(widget._lastAutoFitText) end
        return
    end
    fitOneLine(widget, original, width, preferred, minimum, flags, true)
    -- Auto-fit should preserve real data instead of hiding a cost or time.
    widget._lastAutoFit = signature
    widget._lastAutoFitText = widget:GetText()
end

function SFT:FitLiveTimerFields()
    local settings = self.db and self.db.settings
    if not settings or settings.miniMode or not settings.experimentalMascot then return end
    local wyvern = panelSkin(settings.skin)
    -- The countdown, ETA and fare are never rasterized into the backdrop:
    -- every distinct live value is fitted to its own fixed plaque.
    local timeMult = settings.timeTextScale or 1
    local fareMult = settings.fareTextScale or 1
    local appearance = self.timerFrame and self.timerFrame._appearanceKey
    if wyvern then
        local newArt = settings.skin ~= "wyvern"
        fitLiveField(self.timerText, newArt and 150 or 174,
            math.min(newArt and 39 or 44, (newArt and 38 or 41) * timeMult), math.min(26, (newArt and 38 or 41) * timeMult), "THICKOUTLINE", appearance)
        fitLiveField(self.timerETA, newArt and 136 or 168,
            math.min(newArt and 12 or 13.5, (newArt and 10.5 or 11.5) * timeMult), math.min(9, (newArt and 10.5 or 11.5) * timeMult), "OUTLINE", appearance)
        fitLiveField(self.timerFare, newArt and 133 or 151,
            math.min(newArt and 14 or 17, (newArt and 12.5 or 15) * fareMult), math.min(9.5, (newArt and 12.5 or 15) * fareMult), "OUTLINE", appearance)
    else
        fitLiveField(self.timerText, 205,
            math.min(46, 44 * timeMult), math.min(25, 44 * timeMult), "OUTLINE", appearance)
        fitLiveField(self.timerETA, 257,
            math.min(14, 11 * timeMult), math.min(9, 11 * timeMult), "OUTLINE", appearance)
        fitLiveField(self.timerFare, 181,
            math.min(17, 15 * fareMult), math.min(9.5, 15 * fareMult), "OUTLINE", appearance)
    end
end

function SFT:UpdateTimerAppearance()
    local f = self.timerFrame
    if not f or not self.db then return end
    local settings = self.db.settings
    local themed = settings.experimentalMascot == true
    local header = settings.showAirlinesHeader ~= false
    local mini = settings.miniMode == true
    local skin = SKIN_NAMES[settings.skin] and settings.skin or "classic"
    local key = mini and "mini" or ((themed and ("illustrated:" .. skin) or "compact") .. (header and ":airlines" or ":plain"))
    if f._appearanceKey == key then return end
    f._appearanceKey = key
    for _, field in ipairs({ f.count, f.eta, f.fare }) do
        if field then field._lastAutoFit = nil end
    end
    -- Mini and full-sized views have independent coordinates. Switching skins
    -- does not move either view, and resizing the frame never overwrites them.
    local px = mini and settings.miniX or settings.x
    local py = mini and settings.miniY or settings.y
    f:ClearAllPoints()
    f:SetPoint("CENTER", UIParent, "CENTER", px or 0, py or 0)

    local function centered(widget, y, x1, x2)
        widget:ClearAllPoints()
        widget:SetPoint("TOPLEFT", f, "TOPLEFT", x1, y)
        widget:SetPoint("TOPRIGHT", f, "TOPRIGHT", x2, y)
        widget:SetJustifyH("CENTER")
    end
    -- Reset common elements first; hiding the art in Mini/Compact is important
    -- because even one static label from the template must never leak through.
    f.illustratedBackdrop:Hide()
    f.skinTitle:Hide()
    f.settingsButton:SetAlpha(1)
    f.settingsButton:SetSize(29, 20)
    f.settingsButton:ClearAllPoints()
    f.settingsButton:SetPoint("TOPRIGHT", -6, -5)
    f.topBorder:Show()
    f.header:Show()
    f.subheader:Show()
    f.route:Show()
    f.eta:Show()
    f.fare:Show()
    f.bar:Show()
    f.settingsButton:Show()
    f.count:Show()
    f.route:SetHeight(18)
    if f.route.SetWordWrap then f.route:SetWordWrap(false) end
    if f.route.SetMaxLines then f.route:SetMaxLines(1) end
    f.bar:SetHeight(7)

    if mini then
        f:SetSize(136, 50)
        f._solidBackground:SetColorTexture(0.065, 0.035, 0.105, 0.92)
        f.topBorder:Hide()
        f.header:Hide()
        f.subheader:Hide()
        f.route:Hide()
        f.eta:Hide()
        f.fare:Hide()
        f.bar:Hide()
        f.settingsButton:Hide()
        centered(f.count, -7, 4, -4)
        setFontSize(f.count, 31)
        f.count:SetTextColor(0.9, 0.78, 1)
        return
    end
    if themed and panelSkin(skin) then
        -- The wyvern texture has EMPTY live-data plaques; no baked route/time/price.
        -- 1024 x 512 source displayed at 560 x 280.
        f:SetSize(560, 280)
        f._solidBackground:SetColorTexture(0.045, 0.01, 0.08, 1)
        f.topBorder:Hide()
        f.illustratedBackdrop:SetTexture(SKIN_TEXTURES[skin])
        f.illustratedBackdrop:Show()
        f.settingsButton:SetAlpha(1)
        f.settingsButton:SetSize(27, 19)
        f.settingsButton:ClearAllPoints()
        f.settingsButton:SetPoint("TOPRIGHT", -11, -9)
        local newArt = skin ~= "wyvern"
        -- Original three new illustrations contain fixed caption artwork,
        -- but all data values (destination, countdown, ETA, paid fare) are live.
        if newArt then f.skinTitle:Hide() else f.skinTitle:Show() end
        centered(f.skinTitle, -75, 372, -22)
        centered(f.route, newArt and -84 or -88, newArt and 396 or 370, newArt and -16 or -20)
        centered(f.count, newArt and -118 or -117, newArt and 399 or 372, newArt and -17 or -19)
        centered(f.eta, newArt and -157 or -156, newArt and 403 or 370, newArt and -22 or -20)
        centered(f.fare, newArt and -192 or -189, newArt and 399 or 376, newArt and -23 or -25)
        -- A single-line route, never allowed to spill into the countdown.
        f.route:SetHeight(16)
        if f.route.SetWordWrap then f.route:SetWordWrap(false) end
        if f.route.SetMaxLines then f.route:SetMaxLines(1) end
        f.header:Hide()
        f.subheader:Hide()
        setFontSize(f.skinTitle, 10, "OUTLINE")
        setFontSize(f.route, 12.5, "OUTLINE")
        setFontSize(f.count, newArt and 38 or 41, "THICKOUTLINE")
        setFontSize(f.eta, newArt and 10.5 or 11.5, "OUTLINE")
        setFontSize(f.fare, newArt and 12.5 or 15, "OUTLINE")
        f.skinTitle:SetTextColor(1, 0.88, 0.42)
        f.route:SetTextColor(1, 1, 0.96)
        f.count:SetTextColor(1, 0.98, 1)
        f.eta:SetTextColor(1, 0.95, 0.8)
        f.fare:SetTextColor(1, 0.95, 0.55)
        for _, label in ipairs({f.skinTitle, f.route, f.count, f.eta, f.fare}) do
            if label.SetShadowColor then label:SetShadowColor(0.02, 0, 0.07, 1) end
            if label.SetShadowOffset then label:SetShadowOffset(1, -1) end
        end
        f.bar:SetHeight(2)
        f.bar:ClearAllPoints()
        -- The additional painted panels already have bright dividing rails.
        if newArt then
            f.bar:Hide()
        else
            f.bar:SetPoint("BOTTOMLEFT", f, "BOTTOMLEFT", 371, 100)
            f.bar:SetPoint("BOTTOMRIGHT", f, "BOTTOMRIGHT", -21, 100)
            f.bar:SetStatusBarColor(0.75, 0.25, 0.95, 0.85)
        end
        return
    end
    if themed then
        -- Classic: single-piece continuous gold border (no clipped joins).
        -- Timer, ETA, destination and fare labels are separate live FontStrings.
        -- Preserve the source aspect ratio (1024 x 512, exactly 2:1).
        f:SetSize(560, 280)
        f._solidBackground:SetColorTexture(0.05, 0.02, 0.08, 1)
        f.topBorder:Hide()
        f.illustratedBackdrop:SetTexture("Interface\\AddOns\\ShadyFlightTimer\\Textures\\ShadyAirlines.tga")
        f.illustratedBackdrop:Show()
        -- Invisible functional hit region over the illustrated ... control.
        f.settingsButton:SetAlpha(0)
        f.settingsButton:SetSize(30, 25)
        f.settingsButton:ClearAllPoints()
        f.settingsButton:SetPoint("TOPRIGHT", -29, -22)
        -- Anchor each text row INSIDE its own decorative plate.
        -- Widen the fare field and use a narrower font so silver/gold/copper
        -- amounts stay centered between, not over, the coin stacks.
        centered(f.route, -92, 238, -44)
        centered(f.count, -132, 255, -91)
        centered(f.eta, -181, 240, -49)
        centered(f.fare, -212, 290, -103)
        f.header:Hide()
        f.subheader:Hide()
        setFontSize(f.route, 13, "OUTLINE")
        setFontSize(f.count, 44, "OUTLINE")
        setFontSize(f.eta, 11, "OUTLINE")
        setFontSize(f.fare, 15, "OUTLINE")
        f.route:SetTextColor(1, 0.84, 0.36)
        f.count:SetTextColor(0.97, 0.90, 1)
        f.eta:SetTextColor(0.91, 0.86, 0.98)
        f.fare:SetTextColor(1, 0.88, 0.37)
        f.bar:SetHeight(2)
        f.bar:ClearAllPoints()
        f.bar:SetPoint("BOTTOMLEFT", f, "BOTTOMLEFT", 284, 109)
        f.bar:SetPoint("BOTTOMRIGHT", f, "BOTTOMRIGHT", -103, 109)
        f.bar:SetStatusBarColor(0.71, 0.31, 0.97, 0.82)
        return
    end

    -- Standard compact view stays independently available.
    f:SetSize(286, 175)
    f._solidBackground:SetColorTexture(0.055, 0.065, 0.075, 0.97)
    f.topBorder:SetColorTexture(0.55, 0.40, 0.19, 0.9)
    centered(f.header, -9, 10, -34)
    centered(f.subheader, -30, 12, -12)
    centered(f.route, header and -52 or -42, 12, -12)
    centered(f.count, -76, 12, -12)
    centered(f.eta, -117, 12, -12)
    centered(f.fare, -137, 12, -12)
    f.bar:ClearAllPoints()
    f.bar:SetPoint("BOTTOMLEFT", f, "BOTTOMLEFT", 12, 11)
    f.bar:SetPoint("BOTTOMRIGHT", f, "BOTTOMRIGHT", -12, 11)
    f.bar:SetStatusBarColor(0.95, 0.8, 0.15)
    setFontSize(f.count, 27)
    setFontSize(f.route, 13)
    setFontSize(f.eta, 11)
    setFontSize(f.fare, 13)
    f.count:SetTextColor(1, 0.94, 0.67)
    f.route:SetTextColor(1, 0.82, 0.28)
    f.fare:SetTextColor(1, 0.82, 0.28)
    f.header:SetText(header and "SHADY AIRLINES" or "FLIGHT TIMER")
    f.subheader:SetText("FLIGHT TIMER")
    f.subheader:SetShown(header)
    f.header:SetTextColor(1, 0.78, 0.36)
    f.subheader:SetTextColor(0.71, 0.56, 1)
    f.eta:SetTextColor(0.83, 0.82, 0.92)
end

function SFT:CreateTimer()
    if self.timerFrame then return end
    local f = CreateFrame("Frame", "ShadyFlightTimerPanel", UIParent)
    f:SetSize(286, 175)
    -- Keep the timer above ordinary UI, action bars and most addon frames.
    -- Do not use TOOLTIP strata: real item/spell tooltips must stay readable.
    -- The same frame is used for full view, preview and Mini Mode.
    f:SetFrameStrata("FULLSCREEN_DIALOG")
    f:SetFrameLevel(100)
    f:SetClampedToScreen(true)
    f:SetMovable(true)
    f:EnableMouse(true)
    f:RegisterForDrag("LeftButton")
    f:SetPoint("CENTER", UIParent, "CENTER", self.db.settings.x, self.db.settings.y)
    makeSolid(f)

    local border = f:CreateTexture(nil, "BORDER")
    border:SetColorTexture(0.55, 0.40, 0.19, 0.9)
    border:SetPoint("TOPLEFT", 0, 0)
    border:SetPoint("TOPRIGHT", 0, 0)
    border:SetHeight(3)
    f.topBorder = border

    -- Illustrated full-window backplate includes the fixed crest/title, flight
    -- scene, Shadow Priest mascot, decorative timer and fare plaques. The live
    -- labels are separate FontStrings, never part of this texture.
    local art = f:CreateTexture(nil, "BACKGROUND", nil, 1)
    art:SetTexture("Interface\\AddOns\\ShadyFlightTimer\\Textures\\ShadyAirlines.tga")
    art:SetAllPoints(f)
    art:SetTexCoord(0, 1, 0, 1) -- full 1024x512 texture, no padding
    art:Hide()
    f.illustratedBackdrop = art

    f:SetScript("OnDragStart", function(self)
        -- Mini is always draggable even when the full timer is locked.
        if SFT.db.settings.miniMode or not SFT.db.settings.lock then
            self:StartMoving()
        end
    end)
    -- The mini display has no gear icon: right-click it or use /sft for settings.
    f:SetScript("OnMouseUp", function(_, which)
        if which == "RightButton" and SFT.db.settings.miniMode then SFT:ToggleSettings() end
    end)
    f:SetScript("OnEnter", function(self)
        local settings = SFT.db.settings
        local mini = settings.miniMode
        local wyvern = settings.experimentalMascot and panelSkin(settings.skin)
        if not mini and not wyvern then return end
        GameTooltip:SetOwner(self, "ANCHOR_RIGHT")
        GameTooltip:AddLine("Shady Airlines", 1, 0.82, 0.32)
        if SFT.current and SFT.current.sawTaxi then
            local trip = SFT.current
            if wyvern and not mini and not trip.early then
                GameTooltip:AddLine("From: " .. (trip.from or "Unknown"), 1, 1, 1, true)
                GameTooltip:AddLine("To: " .. SFT:FlightDestination(trip), 1, 1, 1, true)
            else
                GameTooltip:AddLine("Destination: " .. (trip.early and (trip.earlyStop or "Next stop") or (trip.destination or "Unknown")), 1, 1, 1, true)
            end
            GameTooltip:AddLine("Paid: " .. shortMoney(trip.farePaid), 0.9, 0.9, 0.9)
        else
            GameTooltip:AddLine("Timer preview", 0.8, 0.8, 0.8)
        end
        if mini then GameTooltip:AddLine("Right-click: settings  |  Drag: move", 0.7, 0.7, 0.7) end
        GameTooltip:Show()
    end)
    f:SetScript("OnLeave", function() GameTooltip:Hide() end)
    f:SetScript("OnDragStop", function(self)
        self:StopMovingOrSizing()
        local fx, fy = self:GetCenter()
        local ux, uy = UIParent:GetCenter()
        if fx and fy and ux and uy then
            -- GetCenter is measured in effective-scale coordinates for each frame.
            -- Convert to UIParent units before saving the CENTER offset.
            local scale = (self:GetEffectiveScale() or 1) / (UIParent:GetEffectiveScale() or 1)
            local x = floor((fx * scale - ux) + 0.5)
            local y = floor((fy * scale - uy) + 0.5)
            if SFT.db.settings.miniMode then
                SFT.db.settings.miniX, SFT.db.settings.miniY = x, y
            else
                SFT.db.settings.x, SFT.db.settings.y = x, y
            end
            self:ClearAllPoints()
            self:SetPoint("CENTER", UIParent, "CENTER", x, y)
        end
    end)

    local skinTitle = f:CreateFontString(nil, "OVERLAY", "GameFontNormal")
    skinTitle:SetText("DESTINATION")
    skinTitle:Hide()
    f.skinTitle = skinTitle
    local title = f:CreateFontString(nil, "OVERLAY", "GameFontNormalLarge")
    local subtitle = f:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
    local gear = button(f, "...", 29, 20, function() SFT:ToggleSettings() end)
    gear:SetPoint("TOPRIGHT", -6, -5)
    f.settingsButton = gear
    local route = f:CreateFontString(nil, "OVERLAY", "GameFontNormal")
    local count = f:CreateFontString(nil, "OVERLAY", "GameFontNormalHuge")
    local eta = f:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
    local fare = f:CreateFontString(nil, "OVERLAY", "GameFontNormal")
    local bar = CreateFrame("StatusBar", nil, f)
    bar:SetHeight(7)
    bar:SetStatusBarTexture("Interface\\TARGETINGFRAME\\UI-StatusBar")
    bar:SetMinMaxValues(0, 1)
    bar:SetValue(0)
    local land = button(f, "Land at next stop", 145, 23, function()
        local action = TaxiRequestEarlyLanding or (C_TaxiMap and C_TaxiMap.RequestEarlyLanding)
        if UnitOnTaxi and UnitOnTaxi("player") and type(action) == "function" then
            action()
            SFT:RequestEarlyLanding("Flight Timer")
        end
    end)
    land:SetPoint("TOP", f, "BOTTOM", 0, -5)
    land:Hide()

    f.header, f.subheader, f.route, f.count, f.eta, f.fare, f.bar = title, subtitle, route, count, eta, fare, bar
    self.timerFrame = f
    self.timerText = count
    self.timerRoute = route
    self.timerETA = eta
    self.timerFare = fare
    self.timerBar = bar
    self.landButton = land
    self:UpdateTimerAppearance()
end

function SFT:RefreshTimer()
    if not self.db or not self.timerFrame then return end
    local settings = self.db.settings
    self:UpdateTimerAppearance()
    local f = self.current
    local active = f and f.sawTaxi
    local show = (settings.visible and active) or settings.preview
    if show then self.timerFrame:Show() else self.timerFrame:Hide() end
    self.timerFrame:SetScale(settings.scale)
    if self.minimapButton then
        if settings.showMinimap then self.minimapButton:Show() else self.minimapButton:Hide() end
    end
    if not show then self.landButton:Hide() return end
    if not active then
        local wyvern = settings.experimentalMascot and panelSkin(settings.skin) and not settings.miniMode
        self:SetFlightRouteLabel("Destination: Undercity (preview)",
            wyvern and "Undercity (preview)" or nil)
        self.timerText:SetText("~03:45")
        self.timerETA:SetText(wyvern and "ETA 10:30 PM (preview)" or "Estimated | ETA 10:30 PM (preview)")
        self.timerFare:SetText("Paid: 50c (preview)")
        self:FitLiveTimerFields()
        self.timerBar:SetValue(0)
        self.landButton:Hide()
        return
    end
    local total, source, count = self:EstimateRoute(f.route, f.frequentFlier)
    local elapsed = max(0, GetTime() - (f.startedClock or GetTime()))
    local remaining = total and max(0, total - elapsed) or nil
    local destination = self:FlightDestination(f)
    local routeTitle = "Destination: " .. destination
    local quality = source == "calibrated" and "Corrected time"
        or source == "learned" and "Measured"
        or source == "speed_scaled" and "Speed-adjusted estimate"
        or source == "segments" and "Measured hops"
        or source == "geometry" and "Rough estimate" or "Learning"
    if f.early then
        routeTitle = (settings.experimentalMascot and not settings.miniMode and "Next stop: " or "Requested next stop: ") .. (f.earlyStop or "unknown")
        quality = f.earlyStopETA and (f.earlyEstimate and "Rough estimate" or "Measured hop") or "Time unavailable"
        remaining = f.earlyStopUntil and max(0, f.earlyStopUntil - GetTime()) or nil
    end
    local wyvern = settings.experimentalMascot and panelSkin(settings.skin) and not settings.miniMode
    local displayRoute = routeTitle
    if wyvern and not f.early then
        -- The visible plaque displays WHERE you are going. The full route
        -- remains available from the timer's hover tooltip.
        displayRoute = shortStop(destination)
    elseif wyvern and f.early then
        displayRoute = shortStop(f.earlyStop or "Next stop")
    end
    self:SetFlightRouteLabel(routeTitle, displayRoute)
    local approx = (f.early and f.earlyEstimate) or (not f.early and (source == "geometry" or source == "speed_scaled"))
    self.timerText:SetText((approx and "~" or "") .. self:ClockText(remaining))
    -- Distinguish money actually deducted from the fare quoted on the taxi map.
    -- A quote must never be presented as a confirmed payment.
    if f.farePaid ~= nil then
        self.timerFare:SetText("Paid: " .. shortMoney(f.farePaid))
    else
        self.timerFare:SetText("Paid: not confirmed")
    end
    if remaining then
        local arrival = date("%I:%M %p", (GetServerTime and GetServerTime() or time()) + floor(remaining + 0.5))
        self.timerETA:SetText(wyvern and ("ETA " .. (arrival or "?"))
            or (quality .. "  |  ETA " .. (arrival or "?")))
    else
        self.timerETA:SetText(wyvern and "Measuring flight" or (quality .. "  |  Measuring this flight"))
    end
    self:FitLiveTimerFields()
    if total and total > 0 and not f.early then
        self.timerBar:SetMinMaxValues(0, total)
        self.timerBar:SetValue(min(total, elapsed))
    elseif f.early and f.earlyStopETA and f.earlyStopETA > 0 then
        local passed = max(0, GetTime() - (f.earlyStopRequestClock or GetTime()))
        self.timerBar:SetMinMaxValues(0, f.earlyStopETA)
        self.timerBar:SetValue(min(f.earlyStopETA, passed))
    else
        self.timerBar:SetMinMaxValues(0, 1)
        self.timerBar:SetValue(0)
    end
    if settings.notify and remaining and remaining <= 15 and remaining > 0 and not f.approachNotified then
        f.approachNotified = true
        self:Print("About 15 seconds to " .. (f.early and "the next stop" or "your destination") .. ".")
        if PlaySound and SOUNDKIT and SOUNDKIT.RAID_WARNING then
            pcall(PlaySound, SOUNDKIT.RAID_WARNING)
        end
    end
    local actionHeroVisible = _G.ActionHeroFlightStop and _G.ActionHeroFlightStop:IsShown()
    local apiAvailable = type(TaxiRequestEarlyLanding) == "function" or (C_TaxiMap and type(C_TaxiMap.RequestEarlyLanding) == "function")
    if not settings.miniMode and settings.showFallbackLanding and not f.early and not actionHeroVisible and apiAvailable then
        self.landButton:Show()
    else
        self.landButton:Hide()
    end
end

local function createToggle(parent, label, field, x, y)
    local cb = CreateFrame("CheckButton", nil, parent, "UICheckButtonTemplate")
    cb:SetPoint("TOPLEFT", x, y)
    cb:SetSize(26, 26)
    cb.text = cb:CreateFontString(nil, "OVERLAY", "GameFontHighlight")
    cb.text:SetPoint("LEFT", cb, "RIGHT", 4, 0)
    cb.text:SetText(label)
    cb:SetScript("OnClick", function(self)
        SFT.db.settings[field] = self:GetChecked() and true or false
        SFT:RefreshTimer()
        SFT:RefreshSettings()
    end)
    parent._toggles = parent._toggles or {}
    parent._toggles[field] = cb
    return cb
end
-- A separate opaque panel avoids crowding the main settings window. These
-- controls change only LIVE font strings, not the resolution, size, crop, or
-- location of the illustrated scene. Auto-fit remains active at every size.
function SFT:ShowTextSizes()
    if not self.db then return end
    local f = self.textSizesFrame
    if not f then
        f = CreateFrame("Frame", "ShadyFlightTimerTextSizes", UIParent)
        f:SetSize(384, 280)
        f:SetFrameStrata("FULLSCREEN_DIALOG")
        f:SetFrameLevel(250) -- Text-size dialog remains above the timer and settings.
        f:SetClampedToScreen(true)
        f:SetPoint("CENTER", UIParent, "CENTER", 0, 0)
        f:EnableMouse(true)
        makeSolid(f, 1)
        local title = f:CreateFontString(nil, "OVERLAY", "GameFontNormalLarge")
        title:SetPoint("TOPLEFT", 18, -15)
        title:SetText("Shady Airlines - Text Sizes")
        local close = button(f, "X", 25, 24, function() f:Hide() end)
        close:SetPoint("TOPRIGHT", -10, -10)
        local hint = f:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
        hint:SetPoint("TOPLEFT", 18, -47)
        hint:SetPoint("TOPRIGHT", -18, -47)
        hint:SetJustifyH("LEFT")
        hint:SetText("Text adjusts automatically to fit its panel. Artwork stays fixed.")
        f._sliders = {}
        local fields = {
            { field = "routeTextScale",  title = "Flight locations",        label = "Route" },
            { field = "timeTextScale",   title = "Countdown and ETA",      label = "Time" },
            { field = "fareTextScale",   title = "Gold paid",              label = "Fare" },
        }
        for index, info in ipairs(fields) do
            local y = -82 - (index - 1) * 51
            local text = f:CreateFontString(nil, "OVERLAY", "GameFontHighlight")
            text:SetPoint("TOPLEFT", 19, y)
            text:SetText(info.title)
            local slider = CreateFrame("Slider", "ShadyFlightTimer" .. info.label .. "TextScale", f, "OptionsSliderTemplate")
            slider:SetSize(133, 16)
            slider:SetPoint("TOPLEFT", 189, y - 4)
            slider:SetMinMaxValues(0.75, 1.5)
            slider:SetValueStep(0.05)
            if slider.SetObeyStepOnDrag then slider:SetObeyStepOnDrag(true) end
            local prefix = slider:GetName()
            if _G[prefix .. "Low"] then _G[prefix .. "Low"]:SetText("75%") end
            if _G[prefix .. "High"] then _G[prefix .. "High"]:SetText("150%") end
            if _G[prefix .. "Text"] then _G[prefix .. "Text"]:SetText("") end
            local value = f:CreateFontString(nil, "OVERLAY", "GameFontNormal")
            value:SetPoint("LEFT", slider, "RIGHT", 18, 0)
            slider:SetScript("OnValueChanged", function(_, input)
                if f._loading then return end
                local setting = math.max(0.75, math.min(1.5, math.floor((input or 1) * 20 + 0.5) / 20))
                SFT.db.settings[info.field] = setting
                value:SetText(math.floor(setting * 100 + 0.5) .. "%")
                SFT:RefreshTimer()
            end)
            f._sliders[info.field] = {slider = slider, value = value}
        end
        local reset = button(f, "Reset text to 100%", 154, 25, function()
            SFT.db.settings.routeTextScale = 1
            SFT.db.settings.timeTextScale = 1
            SFT.db.settings.fareTextScale = 1
            SFT:RefreshTimer()
            SFT:RefreshTextSizes()
        end)
        reset:SetPoint("BOTTOMLEFT", 18, 18)
        local footer = f:CreateFontString(nil, "OVERLAY", "GameFontDisableSmall")
        footer:SetPoint("BOTTOMRIGHT", -14, 13)
        footer:SetText("RIP Shady")
        if UISpecialFrames then table.insert(UISpecialFrames, "ShadyFlightTimerTextSizes") end
        f:Hide()
        self.textSizesFrame = f
    end
    if f:IsShown() then
        f:Hide()
    else
        self:RefreshTextSizes()
        f:Show()
    end
end

function SFT:RefreshTextSizes()
    local f = self.textSizesFrame
    if not f or not self.db then return end
    f._loading = true
    for field, record in pairs(f._sliders) do
        local scale = self.db.settings[field] or 1
        record.slider:SetValue(scale)
        record.value:SetText(math.floor(scale * 100 + 0.5) .. "%")
    end
    f._loading = false
end

-- Full history is intentionally a separate window: fixed-size recycled rows mean
-- thousands of saved flights do not create thousands of frames. Every record
-- remains accessible with mouse wheel or Previous/Next navigation.
local HISTORY_ROWS = 13
local function historyShort(name)
    local value = shortStop(name or "?")
    return value
end
function SFT:ShowFullHistory()
    local f = self.historyFrame
    if not f then
        f = CreateFrame("Frame", "ShadyFlightTimerFullHistory", UIParent)
        f:SetSize(770, 610)
        f:SetFrameStrata("FULLSCREEN_DIALOG")
        f:SetFrameLevel(260)
        f:SetPoint("CENTER", UIParent, "CENTER", 0, 0)
        f:SetClampedToScreen(true)
        f:EnableMouse(true)
        f:EnableMouseWheel(true)
        makeSolid(f, 1)
        local heading = f:CreateFontString(nil, "OVERLAY", "GameFontNormalLarge")
        heading:SetPoint("TOPLEFT", 18, -16)
        heading:SetText("Shady Airlines - Full Flight History")
        button(f, "X", 26, 24, function() f:Hide() end):SetPoint("TOPRIGHT", -12, -10)
        local hint = f:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
        hint:SetPoint("TOPLEFT", 18, -46)
        hint:SetText("Every saved flight  |  Click a flight to review  |  Scroll for older entries")
        local header = f:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
        header:SetPoint("TOPLEFT", 20, -72)
        header:SetText("DATE / TIME               FROM  >  DESTINATION                                      TIME        FARE        STATUS")
        f.rows = {}
        f.offset = 0
        for i = 1, HISTORY_ROWS do
            local row = CreateFrame("Button", nil, f)
            row:SetSize(736, 31)
            row:SetPoint("TOPLEFT", 17, -91 - (i-1)*31)
            local backdrop = row:CreateTexture(nil, "BACKGROUND")
            backdrop:SetAllPoints()
            backdrop:SetColorTexture(0.25, 0.20, 0.09, i % 2 == 0 and 0.12 or 0.22)
            row.bg = backdrop
            local label = row:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
            label:SetPoint("LEFT", 5, 0)
            label:SetPoint("RIGHT", -5, 0)
            label:SetJustifyH("LEFT")
            label:SetWordWrap(false)
            row.label = label
            row:SetScript("OnClick", function(self)
                f.selected = self.trip
                SFT:RefreshHistory()
            end)
            row:SetScript("OnEnter", function(self)
                local trip = self.trip
                if not trip or not GameTooltip then return end
                GameTooltip:SetOwner(self, "ANCHOR_RIGHT")
                GameTooltip:AddLine((trip.from or "Unknown") .. " > " .. (trip.to or "Unknown"), 1, 0.85, 0.4)
                GameTooltip:AddLine("Flight: " .. SFT:ClockText(trip.duration), 1, 1, 1)
                GameTooltip:AddLine("Fare: " .. (type(trip.cost) == "number" and SFT:MoneyText(trip.cost) or "unconfirmed"), 1, 1, 1)
                if trip.landedZone then GameTooltip:AddLine("Landing zone: " .. trip.landedZone, 0.9, 0.85, 0.7) end
                if type(trip.reportedVia) == "table" and #trip.reportedVia > 0 then
                    GameTooltip:AddLine("Taxi map reported via: " .. table.concat(trip.reportedVia, " > "), 0.85, 0.75, 0.65, true)
                    GameTooltip:AddLine("Unverified fly-by sequence; the map may be wrong.", 0.8, 0.55, 0.4, true)
                end
                if trip.reviewReason then GameTooltip:AddLine(trip.reviewReason, 1, 0.35, 0.35, true) end
                if trip.excludeTiming then GameTooltip:AddLine("Excluded from flight-time learning", 1, 0.5, 0.3) end
                GameTooltip:AddLine("Fare history is kept even when timing is excluded.", 0.7, 0.75, 0.8, true)
                GameTooltip:Show()
            end)
            row:SetScript("OnLeave", function() if GameTooltip then GameTooltip:Hide() end end)
            f.rows[i] = row
        end
        local counter = f:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
        counter:SetPoint("BOTTOMLEFT", 20, 69)
        f.counter = counter
        local newer = button(f, "Newer", 77, 24, function()
            f.offset = max(0, (f.offset or 0) - HISTORY_ROWS)
            SFT:RefreshHistory()
        end)
        newer:SetPoint("BOTTOMRIGHT", -220, 62)
        local older = button(f, "Older", 77, 24, function()
            f.offset = min(max(0, #SFT.db.history - HISTORY_ROWS), (f.offset or 0) + HISTORY_ROWS)
            SFT:RefreshHistory()
        end)
        older:SetPoint("BOTTOMRIGHT", -138, 62)
        f:SetScript("OnMouseWheel", function(_, delta)
            f.offset = min(max(0, #SFT.db.history - HISTORY_ROWS),
                           max(0, (f.offset or 0) - delta * 3))
            SFT:RefreshHistory()
        end)
        local selectedLabel = f:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
        selectedLabel:SetPoint("BOTTOMLEFT", 19, 36)
        selectedLabel:SetPoint("BOTTOMRIGHT", -357, 36)
        selectedLabel:SetJustifyH("LEFT")
        f.selectedLabel = selectedLabel
        local review = button(f, "Exclude timing", 158, 25, function()
            if not f.selected then return end
            SFT:SetHistoryTimingExcluded(f.selected, not f.selected.excludeTiming)
        end)
        review:SetPoint("BOTTOMRIGHT", -20, 30)
        f.reviewButton = review
        local clearCorrection = button(f, "Clear correction", 148, 25, function()
            if not f.selected then return end
            if SFT:ClearHistoryRouteCorrection(f.selected) then
                SFT:Print("Manual correction cleared for selected route; original flight record preserved.")
            else
                SFT:Print("No manual correction saved for this route and speed profile.")
            end
        end)
        clearCorrection:SetPoint("BOTTOMRIGHT", -182, 30)
        f.clearCorrection = clearCorrection
        local footer = f:CreateFontString(nil, "OVERLAY", "GameFontDisableSmall")
        footer:SetPoint("BOTTOM", 0, 8)
        footer:SetText("RIP Shady")
        if UISpecialFrames then table.insert(UISpecialFrames, "ShadyFlightTimerFullHistory") end
        f:Hide()
        self.historyFrame = f
    end
    self:RefreshHistory()
    f:Show()
end
function SFT:RefreshHistory()
    local f = self.historyFrame
    if not f or not self.db then return end
    local flights = self.db.history
    local total = #flights
    f.offset = min(max(0, f.offset or 0), max(0, total - HISTORY_ROWS))
    for i, row in ipairs(f.rows) do
        local trip = flights[f.offset + i]
        row.trip = trip
        if trip then
            local when = type(trip.when) == "number" and date("%m/%d %I:%M%p", trip.when) or "date unknown"
            local where = historyShort(trip.from) .. " > " .. historyShort(trip.to)
            if #where > 44 then where = where:sub(1, 41) .. "..." end
            local fare = type(trip.cost) == "number" and shortMoney(trip.cost) or "unconfirmed"
            local status = trip.excludeTiming and "IGNORED" or
                (trip.trainingValid == false and "REVIEW" or
                (trip.early and "EARLY" or "DONE"))
            local line = string.format("%-19s %-44s %7s  %-13s %s",
                when, where, SFT:ClockText(trip.duration), fare, status)
            row.label:SetText(line)
            if trip == f.selected then
                row.bg:SetColorTexture(0.38, 0.26, 0.08, 0.78)
            else
                row.bg:SetColorTexture(0.25, 0.20, 0.09, i%2 == 0 and 0.12 or 0.22)
            end
            row:Show()
        else
            row:Hide()
        end
    end
    f.counter:SetText("Flights " .. (total > 0 and tostring(f.offset + 1) or "0") ..
        "-" .. tostring(min(total, f.offset + HISTORY_ROWS)) .. " of " .. total)
    if f.selected then
        local label = historyShort(f.selected.from) .. " > " .. historyShort(f.selected.to)
        f.selectedLabel:SetText("Selected: " .. label)
        f.reviewButton:SetText(f.selected.excludeTiming and "Restore timing" or "Exclude timing")
        f.reviewButton:Enable()
        f.clearCorrection:Enable()
    else
        f.selectedLabel:SetText("Select a flight to inspect or flag an incorrect route.")
        f.reviewButton:SetText("Exclude timing")
        f.reviewButton:Disable()
        f.clearCorrection:Disable()
    end
end

function SFT:CreateSettings()
    if self.settingsFrame then return end
    local f = CreateFrame("Frame", "ShadyFlightTimerSettings", UIParent)
    f:SetSize(474, 758)
    f:SetFrameStrata("FULLSCREEN_DIALOG")
    f:SetFrameLevel(200) -- Settings must remain clickable above the timer.
    f:SetClampedToScreen(true)
    f:SetPoint("CENTER")
    f:EnableMouse(true)
    makeSolid(f, 0.985)
    local title = f:CreateFontString(nil, "OVERLAY", "GameFontNormalLarge")
    title:SetPoint("TOPLEFT", 20, -16)
    title:SetText("Shady Airlines - Flight Timer")
    local version = f:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
    version:SetPoint("TOPRIGHT", -46, -19)
    version:SetText("v" .. self.VERSION)
    local close = button(f, "X", 25, 24, function() f:Hide() end)
    close:SetPoint("TOPRIGHT", -10, -11)
    createToggle(f, "Show countdown while flying", "visible", 20, -54)
    createToggle(f, "Show flight-master hover information", "tooltips", 20, -85)
    createToggle(f, "Show fall-back land button (when Action Hero is hidden)", "showFallbackLanding", 20, -116)
    createToggle(f, "15-second arrival notification", "notify", 20, -147)
    createToggle(f, "Lock timer position", "lock", 20, -178)
    createToggle(f, "Show minimap icon", "showMinimap", 20, -209)
    createToggle(f, "Preview timer outside flights", "preview", 20, -240)
    createToggle(f, "Show Shady Airlines header (standard view)", "showAirlinesHeader", 20, -271)
    local experimental = createToggle(f, "Experimental: Illustrated Shady Airlines UI", "experimentalMascot", 20, -302)
    experimental:SetScript("OnEnter", function(self)
        GameTooltip:SetOwner(self, "ANCHOR_RIGHT")
        GameTooltip:AddLine("Experimental mascot UI", 0.8, 0.55, 1)
        GameTooltip:AddLine("Shows the full illustrated Shady Airlines artwork, crest/title, and thumbs-up Shadow Priest. Destination, countdown and actual payment remain live.", 1, 1, 1, true)
        GameTooltip:AddLine("The engraved header is always shown in this view. Mini Mode and standard view retain their own layouts.", 0.7, 0.7, 0.7, true)
        GameTooltip:Show()
    end)
    experimental:SetScript("OnLeave", function() GameTooltip:Hide() end)
    local mini = createToggle(f, "Mini Mode (countdown only)", "miniMode", 20, -333)
    mini:SetScript("OnEnter", function(self)
        GameTooltip:SetOwner(self, "ANCHOR_RIGHT")
        GameTooltip:AddLine("Mini Mode", 0.8, 0.55, 1)
        GameTooltip:AddLine("Shows only the countdown in a small movable panel. Hide title, mascot, destination, paid fare, progress bar and built-in landing button.", 1, 1, 1, true)
        GameTooltip:AddLine("Hover for destination and fare; right-click to open settings. Other UI preferences stay saved.", 0.7, 0.7, 0.7, true)
        GameTooltip:Show()
    end)
    mini:SetScript("OnLeave", function() GameTooltip:Hide() end)
    -- Small, opaque, in-addon list rather than an external dropdown dependency.
    local skinLabel = f:CreateFontString(nil, "OVERLAY", "GameFontHighlight")
    skinLabel:SetPoint("TOPLEFT", 22, -371)
    skinLabel:SetText("Illustrated skin")
    local skinChoice = button(f, "Classic Shadow Priest  v", 205, 23, function()
        if f.skinMenu:IsShown() then f.skinMenu:Hide() else f.skinMenu:Show() end
    end)
    skinChoice:SetPoint("TOPLEFT", 133, -365)
    f.skinChoice = skinChoice
    local popup = CreateFrame("Frame", nil, f)
    popup:SetSize(205, 128)
    popup:SetPoint("TOPLEFT", skinChoice, "BOTTOMLEFT", 0, -1)
    popup:SetFrameStrata("FULLSCREEN_DIALOG")
    popup:SetFrameLevel(f:GetFrameLevel() + 15)
    makeSolid(popup, 1)
    popup:Hide()
    f.skinMenu = popup
    f:HookScript("OnHide", function() popup:Hide() end)
    local options = {
        { name = "Classic Shadow Priest", id = "classic" },
        { name = "Shadow Wyvern", id = "wyvern" },
        { name = "Stealthed Tauren Druid", id = "druid" },
        { name = "Orc Forgemaster", id = "orc" },
        { name = "Shadow Rogue Heist", id = "rogue" },
    }
    for i, entry in ipairs(options) do
        local item = button(popup, entry.name, 203, 24, function()
            SFT.db.settings.skin = entry.id
            popup:Hide()
            SFT:RefreshTimer()
            SFT:RefreshSettings()
        end)
        item:SetPoint("TOPLEFT", 1, -(i - 1) * 25 - 1)
    end
    local textSizeButton = button(f, "Text sizes...", 110, 23, function()
        SFT:ShowTextSizes()
    end)
    textSizeButton:SetPoint("TOPRIGHT", -19, -392)
    local scaleText = f:CreateFontString(nil, "OVERLAY", "GameFontHighlight")
    scaleText:SetPoint("TOPLEFT", 22, -420)
    scaleText:SetText("Timer size")
    local slider = CreateFrame("Slider", "ShadyFlightTimerScale", f, "OptionsSliderTemplate")
    slider:SetSize(160, 16)
    slider:SetPoint("TOPLEFT", 130, -432)
    slider:SetMinMaxValues(0.7, 1.5)
    slider:SetValueStep(0.05)
    if slider.SetObeyStepOnDrag then slider:SetObeyStepOnDrag(true) end
    _G[slider:GetName() .. "Low"]:SetText("70%")
    _G[slider:GetName() .. "High"]:SetText("150%")
    _G[slider:GetName() .. "Text"]:SetText("")
    slider:SetScript("OnValueChanged", function(_, value)
        SFT.db.settings.scale = math.floor(value * 20 + 0.5) / 20
        SFT:RefreshTimer()
        if f.scaleValue then f.scaleValue:SetText(floor(SFT.db.settings.scale * 100 + 0.5) .. "%") end
    end)
    local value = f:CreateFontString(nil, "OVERLAY", "GameFontNormal")
    value:SetPoint("LEFT", slider, "RIGHT", 24, 0)
    f.scaleValue = value
    f.scaleSlider = slider
    local reset = button(f, "Reset position", 112, 23, function()
        if SFT.db.settings.miniMode then
            SFT.db.settings.miniX, SFT.db.settings.miniY = 0, 245
        else
            SFT.db.settings.x, SFT.db.settings.y = 0, 160
        end
        SFT.timerFrame:ClearAllPoints()
        local settings = SFT.db.settings
        SFT.timerFrame:SetPoint("CENTER", UIParent, "CENTER",
            settings.miniMode and settings.miniX or settings.x,
            settings.miniMode and settings.miniY or settings.y)
    end)
    reset:SetPoint("TOPRIGHT", -19, -420)
    local frequent = createToggle(f, "Frequent Flier talent (+20% flight speed)", "frequentFlier", 20, -458)
    frequent:SetScript("OnEnter", function(self)
        GameTooltip:SetOwner(self, "ANCHOR_RIGHT")
        GameTooltip:AddLine("Frequent Flier - flight speed profile", 1, 0.82, 0.35)
        GameTooltip:AddLine("Enable only if you have the Forever Legacy talent. Routes are measured separately for normal and faster flights.", 1, 1, 1, true)
        GameTooltip:AddLine("This is a manual setting, not automatic talent detection.", 0.7, 0.7, 0.7, true)
        GameTooltip:Show()
    end)
    frequent:SetScript("OnLeave", function() GameTooltip:Hide() end)
    local div = f:CreateTexture(nil, "OVERLAY")
    div:SetColorTexture(0.32, 0.32, 0.32, 0.9)
    div:SetPoint("TOPLEFT", 20, -525)
    div:SetSize(434, 1)
    local statsTitle = f:CreateFontString(nil, "OVERLAY", "GameFontNormal")
    statsTitle:SetPoint("TOPLEFT", 20, -536)
    statsTitle:SetText("FLIGHT EXPENSES AND HISTORY")
    local correct = button(f, "Correct flight time", 146, 23, function() SFT:ShowCalibration() end)
    correct:SetPoint("TOPRIGHT", -19, -518)
    local stats = f:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
    stats:SetPoint("TOPLEFT", 21, -556)
    stats:SetPoint("TOPRIGHT", -20, -556)
    stats:SetJustifyH("LEFT")
    f.statsText = stats
    local history = f:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
    history:SetPoint("TOPLEFT", 21, -615)
    history:SetPoint("TOPRIGHT", -20, -615)
    history:SetJustifyH("LEFT")
    f.historyText = history
    local allHistory = button(f, "Full History...", 150, 25, function() SFT:ShowFullHistory() end)
    allHistory:SetPoint("BOTTOMLEFT", 20, 18)
    local footer = f:CreateFontString(nil, "OVERLAY", "GameFontDisableSmall")
    footer:SetPoint("BOTTOM", 0, 10)
    footer:SetText("RIP Shady")
    f:Hide()
    if UISpecialFrames then table.insert(UISpecialFrames, "ShadyFlightTimerSettings") end
    self.settingsFrame = f
end

function SFT:RefreshSettings()
    local f = self.settingsFrame
    if not f or not self.db then return end
    for field, cb in pairs(f._toggles or {}) do
        cb:SetChecked(self.db.settings[field] and true or false)
    end
    if f.scaleSlider then f.scaleSlider:SetValue(self.db.settings.scale or 1) end
    if f.skinChoice then
        f.skinChoice:SetText((SKIN_NAMES[self.db.settings.skin] or "Classic Shadow Priest") .. "  v")
    end
    local db = self.db
    local today, week = 0, 0
    local day = date("%Y-%m-%d")
    local weekLabel = date("%Y-%W")
    for _, trip in ipairs(db.history) do
        if trip.cost and trip.when then
            if date("%Y-%m-%d", trip.when) == day then today = today + trip.cost end
            if date("%Y-%W", trip.when) == weekLabel then week = week + trip.cost end
        end
    end
    f.statsText:SetText("Session: " .. self:MoneyText(self.sessionSpent) ..
        "  |  Today: " .. self:MoneyText(today) ..
        "\nWeek: " .. self:MoneyText(week) .. "  |  All-time: " .. self:MoneyText(db.totals.copper) ..
        " (" .. db.totals.flights .. " flights)")
    local lines = { "Last 5 flights (actual fares only when confirmed):" }
    if f.historyText.SetWordWrap then f.historyText:SetWordWrap(false) end
    for i = 1, min(5, #db.history) do
        local trip = db.history[i]
        local dest = trip.early and ((trip.earlyStop or "Early stop") .. " [requested]") or (trip.to or "?")
        local fare = trip.cost and self:MoneyText(trip.cost) or "fare unconfirmed"
        local status = trip.excludeTiming and " [timing ignored]" or
            (trip.trainingValid == false and " [review route]" or "")
        local recentRoute = shortStop(trip.from) .. " > " .. shortStop(dest)
        if #recentRoute > 34 then recentRoute = recentRoute:sub(1, 31) .. "..." end
        lines[#lines + 1] = "- " .. recentRoute .. "  " .. self:ClockText(trip.duration) .. "  " .. fare .. status
    end
    if #db.history == 0 then lines[#lines + 1] = "No completed flights recorded yet." end
    f.historyText:SetText(table.concat(lines, "\n"))
end
function SFT:ShowCalibration()
    if not self.db then return end
    local f = self.calibrationFrame
    if not f then
        f = CreateFrame("Frame", "ShadyFlightTimerCalibration", UIParent)
        f:SetSize(420, 216)
        f:SetFrameStrata("FULLSCREEN_DIALOG")
        f:SetFrameLevel(250) -- Calibration dialog stays in front of the timer.
        f:SetPoint("CENTER")
        f:EnableMouse(true)
        makeSolid(f, 1)
        local title = f:CreateFontString(nil, "OVERLAY", "GameFontNormalLarge")
        title:SetPoint("TOPLEFT", 18, -15)
        title:SetText("Correct recorded flight time")
        local close = button(f, "X", 25, 23, function() f:Hide() end)
        close:SetPoint("TOPRIGHT", -10, -10)
        local route = f:CreateFontString(nil, "OVERLAY", "GameFontHighlight")
        route:SetPoint("TOPLEFT", 20, -48)
        route:SetPoint("TOPRIGHT", -20, -48)
        route:SetJustifyH("LEFT")
        f.routeLabel = route
        local hint = f:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
        hint:SetPoint("TOPLEFT", 20, -81)
        hint:SetText("Enter actual duration: M:SS or total seconds")
        local input = CreateFrame("EditBox", "ShadyFlightTimeInput", f, "InputBoxTemplate")
        input:SetSize(110, 24)
        input:SetPoint("TOPLEFT", 26, -106)
        input:SetAutoFocus(false)
        input:SetMaxLetters(7)
        input:SetScript("OnEscapePressed", function(self) self:ClearFocus(); f:Hide() end)
        f.input = input
        local result = f:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
        result:SetPoint("TOPLEFT", 20, -180)
        result:SetPoint("TOPRIGHT", -20, -180)
        result:SetJustifyH("LEFT")
        f.result = result
        local save = button(f, "Save corrected time", 157, 26, function()
            local ok, message = SFT:CalibrateLatest(f.input:GetText() or "")
            f.result:SetText(message)
            if ok then SFT:Print(message) end
        end)
        save:SetPoint("LEFT", input, "RIGHT", 14, 0)
        input:SetScript("OnEnterPressed", function(self)
            self:ClearFocus()
            local ok, message = SFT:CalibrateLatest(self:GetText() or "")
            f.result:SetText(message)
            if ok then SFT:Print(message) end
        end)
        local clear = button(f, "Remove manual correction", 207, 24, function()
            local ok, message = SFT:ClearLatestCalibration()
            f.result:SetText(message)
            if ok then SFT:Print(message) end
        end)
        clear:SetPoint("TOPLEFT", 20, -147)
        local footer = f:CreateFontString(nil, "OVERLAY", "GameFontDisableSmall")
        footer:SetPoint("BOTTOMRIGHT", -10, 9)
        footer:SetText("RIP Shady")
        if UISpecialFrames then table.insert(UISpecialFrames, "ShadyFlightTimerCalibration") end
        self.calibrationFrame = f
    end
    local trip = self:LatestFullFlight()
    if trip then
        local fast = trip.frequentFlier
        if fast == nil then fast = self.db.settings.frequentFlier == true end
        f.routeLabel:SetText((trip.from or "Unknown") .. " > " .. (trip.to or "Unknown") .. " (" ..
            (fast and "Frequent Flier" or "Normal") .. ")")
        local entry = self.db.calibrations[trip.routeKey]
        local profile = fast and "fast" or "normal"
        local existing = type(entry)=="table" and entry[profile]
        f.input:SetText(self:ClockText(existing or trip.duration))
        f.result:SetText("Manual corrections override learned/estimated times until cleared.")
    else
        f.routeLabel:SetText("Take a full flight first (not an early landing).")
        f.input:SetText("")
        f.result:SetText("No complete flight recorded yet.")
    end
    f:Show()
end

function SFT:ToggleSettings()
    if not self.settingsFrame then return end
    if self.settingsFrame:IsShown() then
        self.settingsFrame:Hide()
    else
        self:RefreshSettings()
        self.settingsFrame:Show()
    end
end
function SFT:InitUI()
    if self.timerFrame then return end
    self:CreateTimer()
    self:CreateSettings()
    self:CreateMinimapButton()
    self:RefreshTimer()
end

SLASH_SHADYFLIGHTTIMER1 = "/sft"
SLASH_SHADYFLIGHTTIMER2 = "/flighttimer"
SlashCmdList.SHADYFLIGHTTIMER = function(msg)
    if not SFT.db then return end
    msg = (msg or ""):lower():match("^%s*(.-)%s*$")
    if msg == "history" then
        SFT:ShowFullHistory()
    elseif msg == "status" then
        SFT:Status()
    elseif msg == "show" or msg == "hide" then
        SFT.db.settings.visible = msg == "show"
        SFT:RefreshTimer()
        SFT:Print(msg == "show" and "Timer enabled." or "Timer hidden.")
    elseif msg == "preview" then
        SFT.db.settings.preview = not SFT.db.settings.preview
        SFT:RefreshTimer()
        SFT:RefreshSettings()
    elseif msg == "lock" or msg == "unlock" then
        SFT.db.settings.lock = msg == "lock"
        SFT:RefreshSettings()
    elseif msg == "calibrate" or msg == "correct" then
        SFT:ShowCalibration()
    elseif msg:match("^calibrate%s+") then
        local value = msg:match("^calibrate%s+(.+)$")
        local ok, message = SFT:CalibrateLatest(value)
        SFT:Print(message)
    elseif msg == "uncalibrate" then
        local ok, message = SFT:ClearLatestCalibration()
        SFT:Print(message)
    elseif msg == "stats" then
        SFT:Print("Session " .. SFT:MoneyText(SFT.sessionSpent) .. ", all-time " .. SFT:MoneyText(SFT.db.totals.copper) .. ", " .. SFT.db.totals.flights .. " flights.")
    elseif msg == "help" then
        SFT:Print("/sft (settings), /sft preview, /sft show|hide, /sft lock|unlock, /sft stats, /sft status, /sft calibrate 1:42, /sft uncalibrate")
    else
        SFT:ToggleSettings()
    end
end
