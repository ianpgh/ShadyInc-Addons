local _, AP = ...
local R={}
AP.Reliability=R

-- A historical bag-delta recovery is an accounting estimate, not an invoice.
-- Only recover an entire missing reagent from a unique recorded purchase and
-- an isolated zero-to-full-to-zero bag movement, with no other use of its cost.
local function refs(ch,index)
  local list={}
  for _,x in ipairs(ch.craftLedger.lots) do
    for _,p in ipairs(x.parts or {}) do if p.source==index then list[#list+1]={owner=x,part=p} end end
  end
  for _,x in pairs(ch.craftLedger.posts) do
    for _,p in ipairs(x.parts or {}) do if p.source==index then list[#list+1]={owner=x,part=p} end end
  end
  for _,pool in ipairs({ch.sold or {},ch.deleted or {}}) do
    for _,x in ipairs(pool) do if x.mailFlip and x.mailFlip.source==index then list[#list+1]={owner=x,part=x.mailFlip} end end
  end
  return list
end
local function positive(n) return type(n)=="number" and n>0 and n%1==0 end
function R.RecoverCraftDelivery(ch)
  local l=ch.craftLedger
  local observations=ch.inventoryReconciliation and ch.inventoryReconciliation.observations
  if not l or not observations then return 0 end
  local count=0
  for _,d in ipairs(l.craftDiagnostics or {}) do
    local x=l.lots[d.lot]
    if x and x.quantity==1 and x.unknown and x.parts then
      local links=refs(ch,d.lot)
      -- No downstream crafts or split allocations: either one available unit
      -- or one intact posting. This makes cost propagation unambiguous.
      local link=#links==1 and links[1] or nil
      local held=#links==0 and x.left==1 and x.balance==x.cost
      local posted=link and x.left==0 and x.balance==0 and link.part.n==1
        and link.part.cost==x.cost and link.owner.itemID==x.itemID and link.owner.parts
        and #link.owner.parts==1 and link.owner.quantity==1 and not link.owner.returnedUnits
        and not link.owner.remainderTo and not link.owner.costRecovery
      if held or posted then
        for _,i in ipairs(d.inputs or {}) do
          if positive(i.required) and i.bag==i.required and i.tracked==0 and i.missing==i.required then
            local missing,holes
            holes=0
            for _,p in ipairs(x.parts) do
              if p.itemID==i.itemID and p.unknown and not p.source and p.cost==0
                and p.reason=="INSUFFICIENT_TRACKED" and p.n==i.required then missing=p;holes=holes+1 end
            end
            local buy,nb=nil,0
            for _,b in ipairs(ch.buys or {}) do
              if b.itemID==i.itemID and b.boughtAt and b.boughtAt<=x.at and x.at-b.boughtAt<=600 then
                nb=nb+1;buy=b
              end
            end
            if holes==1 and nb==1 and buy.delivery and buy.delivery.stage~="verified"
              and buy.notifiedAH and buy.quantity==i.required and positive(buy.price)
              and positive(buy.purchaseID) and not buy.priceEstimated
              and not l.purchases["p:"..buy.purchaseID]
              and not (buy.auctionID and l.purchases["a:"..buy.auctionID]) then
              local existing=false
              for _,v in ipairs(l.lots) do if v.purchase==buy.purchaseID or (buy.auctionID and v.auctionID==buy.auctionID) then existing=true end end
              local arrival,consumed,changes=nil,nil,0
              for _,o in ipairs(observations) do
                if o.itemID==i.itemID and o.at>=buy.boughtAt and o.at<=x.at then
                  changes=changes+1
                  if not o.bankOpen and o.before==0 and o.after==i.required and o.evidence
                    and o.evidence.GENERIC_ITEM_RECEIPT==i.required and o.at-buy.boughtAt<=120 then
                    local other=false;for k in pairs(o.evidence) do if k~="GENERIC_ITEM_RECEIPT" then other=true end end
                    if not other then arrival=o end
                  elseif not o.bankOpen and o.before==i.required and o.after==0 and o.at==x.at
                    and o.evidence and o.evidence.CRAFT_INPUT==-i.required then consumed=o end
                end
              end
              if not existing and changes==2 and arrival and consumed and arrival.at<consumed.at then
                local index=#l.lots+1
                local previous=buy.delivery
                buy.delivery={version=2,stage="verified",collectedAt=arrival.at,
                  evidence={method="HISTORICAL_BAG_DELTA_ESTIMATE",before=0,after=i.required,craftLot=d.lot},prior=previous}
                buy.deliveryInferred=true
                l.lots[index]={index=index,itemID=i.itemID,quantity=i.required,left=0,cost=buy.price,balance=0,
                  at=buy.boughtAt,purchase=buy.purchaseID,auctionID=buy.auctionID,estimate=true}
                l.purchases["p:"..buy.purchaseID]=index
                if buy.auctionID then l.purchases["a:"..buy.auctionID]=index end
                missing.source,missing.cost,missing.unknown,missing.estimate=index,buy.price,nil,true
                missing.reason="HISTORICAL_BAG_DELTA_ESTIMATE"
                x.cost=x.cost+buy.price;x.estimate=true
                x.unknown=nil
                for _,p in ipairs(x.parts) do if p.unknown then x.unknown=true end end
                if held then x.balance=x.cost else
                  link.part.cost,link.part.unknown,link.part.estimate=x.cost,x.unknown,true
                end
                count=count+1
              end
            end
          end
        end
      end
    end
  end
  return count
end

-- User reported that this specific purchased stack was collected and reposted.
-- Do not infer other expired returns from similar names or elapsed timers.
function R.ConfirmReportedDye(ch)
  local l=ch.craftLedger
  if not l or l.reportedDyeRepostV211 then return end
  local a,b=l.posts["215808403"],l.posts["224917431"]
  local x=l.lots[1241]
  if not a or not b or not x or a.itemID~=4340 or b.itemID~=4340 or a.quantity~=20 or b.quantity~=20
    or a.at~=1795632867 or b.at~=1795676581 or a.totalPrice~=500 or b.totalPrice~=340
    or a.ended or not a.unresolved or a.returnedUnits or a.remainderTo or a.filled or a.soldAt
    or b.returnedUnits or b.remainderTo or b.filled or b.gross or not b.awaitingReturn
    or x.itemID~=4340 or x.quantity~=20 or x.cost~=5670 or x.left~=0 or x.balance~=0 or x.purchase~=375
    or #(a.parts or {})~=1 or #(b.parts or {})~=1 then return end
  local src,dst=a.parts[1],b.parts[1]
  local links=refs(ch,1241)
  if #links~=1 or links[1].part~=src or src.source~=1241 or src.n~=20 or src.cost~=5670 or src.unknown
    or dst.source or not dst.unknown or dst.n~=20 or dst.cost~=0 or dst.reason~="UNKNOWN_ACQUISITION" then return end
  local old,new,receipt
  for _,e in ipairs(ch.returnEvidence and ch.returnEvidence.pending or {}) do
    if e.id==4340 and e.at>=a.at then return end
  end
  for _,r in ipairs(ch.ended or {}) do
    if r.auctionID==215808403 and r.repostedAs==224917431 and r.endedReason=="unconfirmed" and not r.returnCollectedAt and r.endTime and r.endTime<b.at then old=r end
    if r.auctionID==224917431 and r.repostOf==215808403 and not r.returnCollectedAt and not r.cancelRequestedAt then new=r end
  end
  for _,r in ipairs(ch.sold or {}) do
    if r.receiptID=="mail:283" and r.mailOnly and r.name=="Gray Dye" and r.receiptQty==20 and r.verifiedGross==6800 then receipt=r end
  end
  if not old or not new or not receipt then return end
  for _,pool in ipairs({ch.active or {},ch.sold or {},ch.deleted or {},ch.ended or {}}) do
    for _,r in ipairs(pool) do
      if (r.auctionID==215808403 and r~=old) or (r.auctionID==224917431 and r~=new)
        or (r.receiptID=="mail:283" and r~=receipt) then return end
    end
  end
  l.reportedDyeRepostV211={at=time(),old="215808403",new="224917431",prior=dst,method="PLAYER_REPORTED_REPOST"}
  src.returnedFrom,src.method,src.allocatedAt=215808403,"PLAYER_REPORTED_REPOST",time()
  b.parts,a.parts={src},{}
  a.ended,a.returnedUnits,a.fillLimit,a.remainderTo,a.unresolved="expired",20,0,"224917431",nil
  old.endedReason,old.confirmedReturned="expired",true
  return true
end
