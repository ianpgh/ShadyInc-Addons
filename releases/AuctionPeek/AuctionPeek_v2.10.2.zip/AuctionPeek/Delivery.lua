local _, AP = ...
local D = {}
AP.Delivery = D
local session

function D.Record(row)
  if row.notifiedAH and row.itemID and row.quantity then
    row.delivery={version=1,stage="awaiting"}
  end
end

local function read(index)
  local _,_,sender,subject,money,cod,_,count=GetInboxHeaderInfo(index)
  for _,v in pairs({sender,subject,money,cod,count}) do
    if not AP.MailValueReadable(v) then return nil,false end
  end
  if not count or count==0 then return end
  if count==true then count=1 end
  if type(count)~="number" or count<1 or count>16 then return nil,false end
  if count~=1 then
    local others={}
    for slot=1,count do
      local _,id=GetInboxItem(index,slot)
      if not AP.MailValueReadable(id) or type(id)~="number" then return nil,false end
      others[id]=true
    end
    return nil,true,nil,others
  end
  local name,id,_,n=GetInboxItem(index,1)
  for _,v in pairs({name,id,n}) do if not AP.MailValueReadable(v) then return nil,false end end
  if type(id)~="number" or type(n)~="number" or n<=0 then return nil,false end
  local kind,item,seller,bid,buyout=GetInboxInvoiceInfo(index)
  for _,v in pairs({kind,item,seller,bid,buyout}) do if not AP.MailValueReadable(v) then return nil,false end end
  if kind=="buyer" and cod==0 and money==0 and name==item and type(seller)=="string" and seller~=""
      and type(subject)=="string" and type(sender)=="string" then
    local paid=(type(bid)=="number" and bid>0 and bid) or (type(buyout)=="number" and buyout>0 and buyout)
    if paid then
      return {id=id,n=n,paid=paid,key=table.concat({sender,subject,seller,id,n,paid},"\031")},true,id
    end
  end
  return nil,true,id
end

local function candidate(ch,a)
  local result
  for _,r in ipairs(ch.buys) do
    if r.delivery and r.delivery.stage~="verified" and r.itemID==a.id and r.quantity==a.n
        and (not r.price or r.price==a.paid) then
      if result then return end
      result=r
    end
  end
  if result and result.price==a.paid and not result.priceEstimated then return result end
end

function D.Scan(ch,confirm)
  local active=session
  if not active or active.ch~=ch then return end
  local ok,n=pcall(GetInboxNumItems)
  if not ok or not AP.MailValueReadable(n) or type(n)~="number" or n>200 then return end
  local rows,keys,items={},{},{}
  for j=1,n do
    local success,a,valid,id,others=pcall(read,j)
    if not success or valid==false then return end
    if id then items[id]=(items[id] or 0)+1 end
    for other in pairs(others or {}) do items[other]=(items[other] or 0)+1 end
    if a then rows[j]=a; keys[a.key]=(keys[a.key] or 0)+1 end
  end
  local now=time()
  for id,q in pairs(active.requests) do
    local r=q.row
    local after=AP.Reconciliation.Count(id)
    if now-q.at>10 then
      r.delivery.stage="awaiting"
      r.delivery.issue="Collection could not be verified"
      active.requests[id]=nil
    elseif confirm and not keys[q.item.key] and not items[id] and after and after-q.before==q.item.n
        and candidate(ch,q.item)==r then
      r.delivery.stage="verified"
      r.delivery.collectedAt=now
      r.delivery.issue=nil
      r.delivery.evidence={invoice=q.item.key, before=q.before, after=after}
      active.requests[id]=nil
      AP.Inventory.Signal(ch,id,q.item.n,"AH_DELIVERY")
    end
  end
  -- Retain an observed buyer invoice and its pre-collection bag count. This
  -- also handles clients that remove the attachment before the secure post-hook.
  active.observed=active.observed or {}
  for key,o in pairs(active.observed) do
    if keys[key] then
      if items[o.item.id]~=1 then active.observed[key]=nil end
    elseif not active.requests[o.item.id] then
      local r=candidate(ch,o.item)
      local after=AP.Reconciliation.Count(o.item.id)
      if confirm and not items[o.item.id] and r==o.row and after and after-o.before==o.item.n
          and now-o.at<=120 and not o.competing then
        r.delivery.stage="verified"
        r.delivery.collectedAt=now
        r.delivery.issue=nil
        r.delivery.evidence={invoice=key,before=o.before,after=after,method="INVOICE_AND_BAG_DELTA"}
        AP.Inventory.Signal(ch,o.item.id,o.item.n,"AH_DELIVERY")
        active.observed[key]=nil
      elseif items[o.item.id] or now-o.at>120 or o.competing or not r then active.observed[key]=nil end
    end
  end
  active.rows,active.keys,active.items=rows,keys,items
  for _,a in pairs(rows) do
    local r=keys[a.key]==1 and items[a.id]==1 and candidate(ch,a)
    if r and not active.requests[a.id] then
      r.delivery.stage="available"
      local before=AP.Reconciliation.Count(a.id)
      if before~=nil then
        local o=active.observed[a.key]
        if not o or o.row~=r then active.observed[a.key]={item=a,row=r,before=before,at=now}
        elseif before~=o.before then o.competing=true
        else o.at=now end
      end
    end
  end
end

function D.Fail(reason)
  if not session then return end
  for _,q in pairs(session.requests) do
    q.row.delivery.stage="awaiting"
    q.row.delivery.issue=reason
  end
  session.requests={}
  session.observed={}
end

function D.Open(ch)
  session={ch=ch,rows={},keys={},items={},requests={}}
  D.Scan(ch)
end

function D.Close()
  D.Fail("Mailbox closed before collection was verified")
  session=nil
end

function D.Reset(ch)
  for _,r in ipairs(ch.buys) do
    if r.delivery and r.delivery.stage~="verified" then
      if r.delivery.stage=="requested" then r.delivery.issue="Session ended before collection was verified" end
      r.delivery.stage="awaiting"
    end
  end
end

function D.Queue(ch)
  local active=session
  if not active or active.queued or not (C_Timer and C_Timer.After) then return end
  active.queued=true
  C_Timer.After(0.25,function()
    if session~=active then return end
    active.queued=false
    D.Scan(ch,true)
  end)
end

function D.BeforePacedPickup(index)
  if D.Request then D.Request(index) end
end

function D.Install()
  if not (hooksecurefunc and GetInboxNumItems and GetInboxHeaderInfo and GetInboxInvoiceInfo and GetInboxItem) then return end
  local function requested(index,attachment)
    local active=session
    if not active or not AP.MailValueReadable(index) or not AP.MailValueReadable(attachment)
        or type(index)~="number" or (attachment and attachment~=1) then return end
    local a=active.rows[index]
    if not a or active.keys[a.key]~=1 or active.items[a.id]~=1 or active.requests[a.id] then return end
    -- Post-hook attribution requires the same readable attachment at the index.
    -- If the inbox shifted synchronously, leave the delivery unresolved.
    local ok,current=pcall(read,index)
    if not ok or not current or current.key~=a.key then return end
    local r=candidate(active.ch,a)
    local o=(active.observed or {})[a.key]
    local before=o and not o.competing and o.before or AP.Reconciliation.Count(a.id)
    if not r or before==nil then return end
    r.delivery.stage="requested"
    local request={row=r,item=a,before=before,at=time()}
    active.requests[a.id]=request
    D.Queue(active.ch)
    if C_Timer and C_Timer.After then C_Timer.After(11,function()
      if session==active and active.requests[a.id]==request then
        request.row.delivery.stage="awaiting"
        request.row.delivery.issue="Collection could not be verified"
        active.requests[a.id]=nil
      end
    end) end
  end
  D.Request=requested
  if TakeInboxItem then hooksecurefunc("TakeInboxItem",requested) end
  if AutoLootMailItem then hooksecurefunc("AutoLootMailItem",function(index) requested(index) end) end
end

-- Simultaneous positive evidence prevents a bag increase from proving a pickup.
function D.CompetingIncrease(ch,id)
  if not session or session.ch~=ch then return end
  for _,o in pairs(session.observed or {}) do if o.item.id==id then o.competing=true end end
  local q=session.requests[id]
  if q then
    q.row.delivery.stage="awaiting"
    q.row.delivery.issue="Another source added this item during collection"
    session.requests[id]=nil
  end
end

function AP.ReconcileWalletDrop(ch,previous,before,after,claims,walletDelta,record)
  local receipts,total={},0
  local remaining={}
  for key,n in pairs(before) do remaining[key]=math.max(0,n-(after[key] or 0)-(claims[key] or 0)) end
  for _,r in pairs(previous) do
    if (remaining[r.signature] or 0)>0 then
      receipts[#receipts+1]=r
      total=total+r.net
      remaining[r.signature]=remaining[r.signature]-1
    end
  end
  if total==0 then return end
  if total~=walletDelta then
    AP.Inventory.Append(ch,{at=time(),reason="SELLER_INVOICE_DROPPED_WITHOUT_PAYMENT_PROOF",
      invoiceCount=#receipts,invoiceAmount=total,walletDelta=walletDelta})
    return
  end
  -- A later post-hook sees these claims and cannot credit the same drop.
  for _,r in ipairs(receipts) do
    claims[r.signature]=(claims[r.signature] or 0)+1
    local verified={}
    for k,v in pairs(r) do verified[k]=v end
    verified.paymentEvidence="INBOX_AND_WALLET"
    record(verified)
  end
  return true
end
