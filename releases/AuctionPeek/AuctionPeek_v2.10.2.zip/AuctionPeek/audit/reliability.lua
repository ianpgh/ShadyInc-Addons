local AP={}
for _,m in ipairs({'Reconciliation','Crafts','Transactions','Accounting','CostIntegrity','Reliability','Delivery'}) do assert(loadfile(m..'.lua'))('AuctionPeek',AP) end
time=function() return 1795709800 end
AP.MailValueReadable=function() return true end
local path=assert(arg[1],'saved variables path required')
dofile(path)
local ch=assert(AuctionPeekDB.characters['Crillz - '])
local l=ch.craftLedger
local before=AP.CostIntegrity.Audit(ch).discrepancies
assert(AP.Reliability.RecoverCraftDelivery(ch)==1)
assert(l.lots[1294].cost==25180 and not l.lots[1294].unknown and l.lots[1294].estimate)
assert(l.posts['225173046'].parts[1].cost==25180)
assert(AP.Reliability.RecoverCraftDelivery(ch)==0)
assert(AP.Reliability.ConfirmReportedDye(ch))
assert(not AP.Reliability.ConfirmReportedDye(ch))
assert(l.posts['224917431'].parts[1].cost==5670)
local n=AP.Transactions.Reconcile(ch,function(s) return (s or ''):lower() end)
print('receipts reconciled',n)
local p=l.posts['224917431'];assert(p.filled==20 and p.gross==6800 and p.cut==340 and p.ownedSold and not p.ended)
assert(p.fills['mail:283'])
assert(AP.CostIntegrity.Audit(ch).discrepancies<=before)
AP.Transactions.Reconcile(ch,function(s) return (s or ''):lower() end)
assert(p.filled==20 and p.gross==6800)
print('PASS supplied saved data: craft cost recovery, dye repost, full receipt, conservation, repeat safety')
-- Buyer invoice observed before a synchronously disappearing attachment.
local bag,mail=0,true
GetInboxNumItems=function() return mail and 1 or 0 end
GetInboxHeaderInfo=function() return nil,nil,'Horde Auction House','Auction won: Test',0,0,29,1 end
GetInboxItem=function() return 'Test',123,nil,6 end
GetInboxInvoiceInfo=function() return 'buyer','Test','Seller',120,120 end
AP.Reconciliation.Count=function() return bag end
AP.Inventory={Signal=function() end}
local function buyer() return {buys={{itemID=123,quantity=6,price=120,notifiedAH=true,delivery={stage='awaiting'}}}} end
local c=buyer();AP.Delivery.Open(c);mail=false;bag=6;AP.Delivery.Scan(c,true);assert(c.buys[1].delivery.stage=='verified')
AP.Delivery.Close();mail=true;bag=0;c=buyer();AP.Delivery.Open(c);AP.Delivery.CompetingIncrease(c,123);mail=false;bag=6;AP.Delivery.Scan(c,true);assert(c.buys[1].delivery.stage~='verified')
AP.Delivery.Close();print('PASS missing post-hook delivery and competing increase rejection')
-- A full invoice cannot override an explicit player cancellation or an
-- ambiguous receipt: use fresh copies of the actual conflicting stack.
for _,kind in ipairs({'cancel','duplicate','no-notice'}) do
  dofile(path);local c=AuctionPeekDB.characters['Crillz - ']
  local p=c.craftLedger.posts['224917431']
  if kind=='cancel' then for _,r in ipairs(c.ended) do if r.auctionID==224917431 then r.cancelRequestedAt=p.endedAt end end
  elseif kind=='duplicate' then
    for _,r in ipairs(c.sold) do if r.receiptID=='mail:283' then local copy={};for k,v in pairs(r) do copy[k]=v end;c.sold[#c.sold+1]=copy;break end end
  else p.saleNoticeAt=nil end
  AP.Transactions.Reconcile(c,function(s) return (s or ''):lower() end)
  assert(not p.filled,kind)
end
print('PASS actual cancellation, duplicate receipt and absent sale notice rejected')
