time=os.time
date=os.date
GetTime=os.clock
SlashCmdList={}
tinsert=table.insert
UnitName=function() return "Crillz" end
GetRealmName=function() return "" end
UnitGUID=function() return "Player-6934-0084E67D" end
GetItemInfo=function(id) return id==6887 and "Spotted Yellowtail" or id==8999 and "Simulated Commodity" or "Item #"..tostring(id) end
local queue={}
C_Timer={After=function(_,f) queue[#queue+1]=f end}
local frames={}
local methods={}
local mt={__index=function(_,k) return methods[k] or function() end end}
function methods:SetScript(event,f) rawset(self,event,f) end
function methods:RegisterEvent(event) if event=="PLAYER_LOGIN" then rawset(self,"loadsAddon",true) end end
function methods:CreateTexture() return setmetatable({},mt) end
function methods:CreateFontString() return setmetatable({},mt) end
function methods:SetSize(w,h) self.width,self.height=w,h end
function methods:GetWidth() return rawget(self,"width") or 1000 end
function methods:GetHeight() return rawget(self,"height") or 600 end
function methods:GetFrameLevel() return 1 end
function methods:GetFont() return "",12,"" end
function methods:IsShown() return false end
function methods:SetNormalTexture() end
function methods:GetNormalTexture() return setmetatable({},mt) end
function methods:GetName() return rawget(self,"name") end
function methods:SetText(text) self.Text=text end
function methods:GetText() return self.Text end
function CreateFrame(_,name)
  local f=setmetatable({name=name},mt)
  frames[#frames+1]=f
  if name then _G[name]=f end
  return f
end
UIParent=CreateFrame()
WorldFrame=CreateFrame()
Minimap=CreateFrame()
UISpecialFrames={}
GameTooltip=CreateFrame()
local inbox,owned={},{}
C_AuctionHouse={GetOwnedAuctions=function() return owned end,
  HasFullOwnedAuctionResults=function() return true end,
  CancelAuction=function() end}
GetInboxNumItems=function() return #inbox end
GetInboxHeaderInfo=function(index)
  local r=inbox[index]
  if r then return nil,nil,"Auction House",r.subject or "Auction successful",r.money or 0,0,29,r.item and 1 or nil end
end
GetInboxInvoiceInfo=function(index)
  local r=inbox[index]
  if r and not r.item then return "seller",r.name,r.buyer,r.gross,r.gross,r.deposit,r.cut,nil,nil,nil,r.qty end
end
GetInboxItem=function(index)
  local r=inbox[index]
  if r and r.item then return r.name,r.item,nil,r.qty end
end
TakeInboxMoney=function() end
TakeInboxItem=function() end
hooksecurefunc=function(target,method,handler)
  if type(target)=="string" then handler,method,target=method,target,_G end
  local old=target[method]
  target[method]=function(...) if old then old(...) end; handler(...) end
end
local AP={}
local dir="./"
for line in io.lines(dir.."AuctionPeek.toc") do
  if line:match("%.lua$") then assert(loadfile(dir..line))("AuctionPeek",AP) end
end
local main
for _,frame in ipairs(frames) do
  if rawget(frame,"loadsAddon") and rawget(frame,"OnEvent") then main=frame end
end
assert(main)
dofile(arg[1])
local originalDE
for _,profile in pairs(AuctionPeekDB.characters) do
  if profile.craftLedger and profile.craftLedger.posts["210413075"] then originalDE=#(profile.deTests or {}) end
end
main:OnEvent("PLAYER_LOGIN","AuctionPeek")
local ch=assert(AP.Character())
assert(#(ch.deTests or {})==originalDE)
assert(type(AP.DETest.Tracked(ch))=="table")
local function flush()
  for _=1,20 do
    local old=queue; queue={}
    for _,callback in ipairs(old) do callback() end
    if #queue==0 then break end
  end
end
flush()
local l=ch.craftLedger
assert(l.lots[1294].cost==25180 and l.posts['225173046'].parts[1].cost==25180)
assert(l.posts['224917431'].filled==20 and l.posts['224917431'].parts[1].cost==5670)
local sales,flips=AP.BuildHistory(ch,function(s) return (s or ''):lower() end)
AP.Crafts.Rows(ch,flips,sales)
AP.Crafts.AddTransactionRows(ch,flips,sales)
for _,r in ipairs(flips) do if tostring(r.auctionID)=="225173046" or tostring(r.auctionID)=="224917431" then print('flip',r.auctionID,r.profitText,r.net,r.soldCost and r.soldCost.cost) end end
print('PASS full TOC load, PLAYER_LOGIN, deferred reconciliation, history rendering')
