local _, AP = ...
local button, run
local pause = 1
local function stop(reason)
  run = nil
  if button then button:SetText("Open All (paced)") end
  if reason then print("|cffffcf40Auction Peek:|r "..reason) end
end

-- Count identical funded/attached letters together so shifting inbox positions
-- and duplicate auction subjects do not masquerade as a completed pickup.
local function inbox(wanted)
  local n = GetInboxNumItems()
  if not AP.MailValueReadable(n) or type(n) ~= "number" or n > 200 then return end
  local matches, choice = 0, nil
  for i = n, 1, -1 do
    local _, _, sender, subject, money, cod, _, items, _, _, _, _, gm = GetInboxHeaderInfo(i)
    for _, value in pairs({sender, subject, money, cod, items, gm}) do
      if not AP.MailValueReadable(value) then return end
    end
    if type(subject) ~= "string" or type(money) ~= "number" or type(cod) ~= "number" then return end
    if cod == 0 and not gm and (money > 0 or (items and items ~= 0)) then
      if type(sender) ~= "string" then return end
      local key = table.concat({sender, subject, tostring(money), tostring(items or 0)}, "\031")
      if key == wanted then matches = matches + 1 end
      if not choice then choice = {index=i, key=key, money=money, sender=sender} end
    end
  end
  return matches, choice
end

local function step(session)
  if run ~= session then return end
  if not MailFrame or not MailFrame:IsShown() or (InboxFrame and not InboxFrame:IsShown()) then
    stop()
    return
  end
  local now = GetTime()
  local count, choice = inbox(session.key)
  if session.key then
    if count and count < session.count and (not session.signature or session.recorded) then
      session.key, session.signature, session.recorded = nil, nil, nil
      session.deadline = now + pause + 10
      C_Timer.After(pause, function() step(session) end)
      return
    end
  elseif count then
    if not choice then
      stop("Finished collecting available mail.")
      if MailFrame_RefreshInbox then
        MailFrame_RefreshInbox(MailFrame)
      elseif CheckInbox and (not C_Mail or not C_Mail.CanCheckInbox or C_Mail.CanCheckInbox()) then
        CheckInbox()
      end
      return
    end
    local ready, signature = AP.PrepareMailPickup(choice)
    if ready then
      session.key, session.signature = choice.key, signature
      session.count = inbox(choice.key)
      if not session.count or session.count < 1 then stop("Inbox changed. Click again to resume."); return end
      session.deadline = now + 10
      if GetInboxText then GetInboxText(choice.index) end
      if AP.Delivery then AP.Delivery.BeforePacedPickup(choice.index) end
      if AP.BeforeReturnPickup then AP.BeforeReturnPickup(choice.index,1) end
      local ok = pcall(AutoLootMailItem, choice.index)
      if not ok then
        if AP.Delivery then AP.Delivery.Fail("Pickup unavailable") end
        stop("Pickup unavailable. Check the mailbox before resuming."); return end
    end
  end
  if now >= session.deadline then
    stop("Paused. The invoice or pickup could not be confirmed. Check the mailbox before resuming.")
  else
    C_Timer.After(0.35, function() step(session) end)
  end
end

function AP.PacedReceiptSaved(signature)
  if run and run.signature == signature then run.recorded = true end
end

function AP.ShowPacedMail()
  if not (MailFrame and InboxFrame and AutoLootMailItem and C_Timer and C_Timer.After) then return end
  if not button then
    button = CreateFrame("Button", nil, InboxFrame, "UIPanelButtonTemplate")
    button:SetSize(136, 24)
    button:SetPoint("TOP", MailFrame, "TOP", 0, -30)
    button:SetText("Open All (paced)")
    button:SetScript("OnHide", function() stop() end)
    button:SetScript("OnClick", function()
      if run then stop("Stopped. Check the inbox before resuming."); return end
      run = {deadline=GetTime()+10}
      button:SetText("Stop collection")
      step(run)
    end)
    button:SetScript("OnEvent", function(_, event, _, message)
      if run and (event == "MAIL_FAILED" or
          (AP.MailValueReadable(message) and message and
           (message == ERR_ITEM_NOT_FOUND or message == ERR_INV_FULL))) then
        stop("Mailbox reported a pickup error. Check the inbox before resuming.")
      end
    end)
    button:RegisterEvent("MAIL_FAILED")
    button:RegisterEvent("UI_ERROR_MESSAGE")
  end
  button:Show()
end

function AP.ClosePacedMail()
  stop()
end
