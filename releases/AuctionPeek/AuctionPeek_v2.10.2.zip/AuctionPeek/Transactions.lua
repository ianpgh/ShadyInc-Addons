local _, AP = ...
local T = {}
AP.Transactions = T

local function units(n)
  return type(n)=="number" and n>0 and n%1==0
end

local function shallow(row)
  local copy={}
  for k,v in pairs(row) do copy[k]=v end
  return copy
end

local function journal(ch)
  ch.transactionIntegrity=ch.transactionIntegrity or {version=1, superseded={}}
  return ch.transactionIntegrity
end

function T.Post(ch,id)
  return ch.craftLedger and ch.craftLedger.posts[tostring(id)]
end

function T.Stack(ch,row)
  local p=T.Post(ch,row.auctionID)
  local e=(ch.postingEvidence or {})[tostring(row.auctionID)]
  return (p and (p.quantity or 0)>1) or (e and (e.maxSeenQuantity or 0)>1)
    or (row.quantity or 0)>1
end

function T.Observe(ch,row)
  if not row.auctionID or not row.itemID or not units(row.quantity) or not T.Stack(ch,row) then return end
  ch.craftLedger=ch.craftLedger or {lots={},posts={},casts={},purchases={}}
  local posts=ch.craftLedger.posts
  local key=tostring(row.auctionID)
  local p=posts[key]
  if not p then
    if row.sold then return end
    p={at=row.firstSeenAt or row.seenAt,quantity=row.quantity,itemID=row.itemID,
      totalPrice=row.buyout,unitPrice=row.unitPrice,observedWithoutAllocation=true}
    posts[key]=p
  end
  if p.itemID and p.itemID~=row.itemID or not units(p.quantity) then return end
  p.name=p.name or row.name
  p.unitPrice=p.unitPrice or row.unitPrice
  if row.sold then
    -- An owned sold line can describe just one fill. Repeated snapshots
    -- may show that same line, so never sum its quantity across updates.
    if not p.ended and row.quantity<=p.quantity then
      p.soldSnapshotUnits=math.max(row.quantity,p.soldSnapshotUnits or 0)
      p.soldSnapshotAt=row.seenAt
    end
  elseif row.quantity<=p.quantity and not p.returnedUnits then
    if row.quantity<p.quantity then
      p.remainingSeen=math.min(p.remainingSeen or p.quantity,row.quantity)
    end
    p.lastRemainingAt=row.seenAt
    p.activeObserved=true
    p.unresolved=nil
  end
end

local function observed(ch,id,p)
  local e=(ch.postingEvidence or {})[id]
  local remaining=p.remainingSeen
  if e and e.maxSeenQuantity==p.quantity and units(e.minSeenQuantity)
      and e.minSeenQuantity<p.quantity then
    remaining=math.min(remaining or p.quantity,e.minSeenQuantity)
  end
  return remaining and p.quantity-remaining or 0
end

function T.SaleLimit(ch,id,p)
  if p.returnedUnits then return p.quantity-p.returnedUnits end
  if p.ended then return math.max(p.filled or 0,p.fillLimit or 0,observed(ch,id,p)) end
  if p.activeObserved then return math.max(p.filled or 0,observed(ch,id,p)) end
  if p.fullStackObserved or p.ownedSold then return p.quantity end
  return math.max(observed(ch,id,p),p.soldSnapshotUnits or 0)
end

local function fillTotals(p)
  local n,g,fee,deposit,net,latest=0,0,0,0,0,0
  for _,f in pairs(p.fills or {}) do
    if not units(f.quantity) or not units(f.gross) or type(f.fee)~="number"
        or type(f.deposit)~="number" or type(f.net)~="number" then return end
    n,g,fee=n+f.quantity,g+f.gross,fee+f.fee
    deposit,net=deposit+f.deposit,net+f.net
    latest=math.max(latest,tonumber(f.observedAt or f.reconciledAt) or 0)
  end
  return n,g,fee,deposit,net,latest
end

local function fitsPrice(p,row,receipt)
  local n,g=receipt.receiptQty,receipt.verifiedGross
  local unit=p.unitPrice or p.verifiedUnitPrice or row.unitPrice
  if units(unit) then return unit*n==g end
  local raw=p.totalPrice or row.buyout
  if units(raw) and raw*n==g*p.quantity then return true end
  -- Older snapshots can hold an untyped price. The match still requires
  -- independent quantity evidence, and both interpretations can compete.
  return units(raw) and raw*n==g
end

function T.Reconcile(ch,normalize)
  local posts=ch.craftLedger and ch.craftLedger.posts or {}
  local rows,claims,settled,targets,ambiguous={},{},{},{},{}
  for _,pool in ipairs({ch.sold,ch.deleted,ch.ended,ch.active}) do
    for _,r in ipairs(pool) do
      if r.receiptID then claims[r.receiptID]=(claims[r.receiptID] or 0)+1 end
      if r.auctionID and r.deletedKind~="buys" then
        local id=tostring(r.auctionID)
        rows[id]=rows[id] or r
        if r.receiptID and (r.sold or r.deletedKind=="sold") then settled[id]=r end
        if r.sold or r.deletedKind=="sold" then
          if targets[id] and targets[id]~=r then ambiguous[id]=true end
          targets[id]=targets[id] or r
        end
      end
    end
  end
  local used=AP.DETest and AP.DETest.ConfirmedReceiptClaims(ch) or {}
  for _,p in pairs(posts) do for id in pairs(p.fills or {}) do used[id]=true end end
  for id,p in pairs(posts) do
    if not rows[id] and p.name and p.itemID and units(p.quantity) and p.endedAt then
      rows[id]={auctionID=tonumber(id),name=p.name,itemID=p.itemID,endedAt=p.endedAt}
    end
  end
  local archived={}
  for _,r in ipairs(ch.deleted) do
    if r.mailOnly and not r.auctionID and r.receiptID and r.observedAt then
      archived[#archived+1]=r
    end
  end
  local proposals={}
  for i,r in ipairs(ch.sold) do
    local q,g,fee,deposit,at=r.receiptQty,r.verifiedGross,r.verifiedCut,r.verifiedDeposit,r.observedAt
    if r.mailOnly and not r.mailFlip and not r.auctionID and r.receiptID and claims[r.receiptID]==1 and not used[r.receiptID]
        and r.receiptQuantityKnown and units(q) and units(g) and type(fee)=="number"
        and fee>=0 and fee<=g and type(deposit)=="number" and deposit>=0
        and g-fee+deposit==r.verifiedNet and type(at)=="number" then
      local candidates,blocked={},false
      for id,row in pairs(rows) do
        local p=posts[id]
        local posted=p and p.at or row.firstSeenAt
        local same=(not r.itemID or not row.itemID or r.itemID==row.itemID)
          and normalize(r.name)==normalize(row.name or row.link)
        if same and posted and posted<=at and (not r.invoiceAuctionID or tostring(r.invoiceAuctionID)==id) then
          local ended=row.endedAt or (p and p.endedAt)
          if not ended or ended>=at-86400 then
            if p and units(p.quantity) and p.quantity>1 and q<=p.quantity
                and fitsPrice(p,row,r) then
              local limit=T.SaleLimit(ch,id,p)
              local evidence=(ch.postingEvidence or {})[id]
              local disappearance=row.endedReason=="unconfirmed" and ended
                and math.abs(ended-at)<86400 and not (p.ended or p.returnedUnits or row.repostedAs)
              local knownOriginal=p.parts or (evidence and evidence.originalPostedQuantity==p.quantity)
              -- Commodity sale notices can follow a false cancel status. A
              -- complete paid invoice and exact sale-ID notice can settle the
              -- whole original stack, but never override a collected return,
              -- actual player cancellation, or an earlier settled fill.
              local fullAfterNotice=p.ended=="canceled" and p.awaitingReturn
                and p.fullStackObserved and p.saleNoticeAt and p.endedAt
                and p.saleNoticeAt>=p.endedAt and p.saleNoticeAt<=at
                and at-p.saleNoticeAt<86400 and q==p.quantity
                and not (p.returnedUnits or p.remainderTo or p.filled or p.fills
                  or row.cancelRequestedAt or row.returnCollectedAt or row.repostedAs)
              if fullAfterNotice or (r.invoiceAuctionID and not p.ended and not p.returnedUnits)
                  or (disappearance and knownOriginal and q==p.quantity and limit==0)
                  or (disappearance and p.saleNoticeAt and p.saleNoticeAt<=at and at-p.saleNoticeAt<86400) then
                limit=p.quantity
              end
              if q<=limit-(p.filled or 0) and not ambiguous[id] and not p.remainderTo
                  and (not settled[id] or (p.fills and p.fills[settled[id].receiptID]))
                  and not (p.gross and not p.fills)
                  and (not p.fills or fillTotals(p)==(p.filled or 0)) then
                candidates[#candidates+1]={id=id,row=row,limit=limit}
              else
                local e=(ch.postingEvidence or {})[id]
                local intactAfterMail=e and e.lastSeenAt and e.lastSeenAt>=at
                  and e.minSeenQuantity==p.quantity and e.maxSeenQuantity==p.quantity
                  and limit==0
                if (p.filled or 0)<p.quantity and (not p.ended or limit>(p.filled or 0))
                    and not intactAfterMail and not (p.returnedUnits and limit==(p.filled or 0)) then
                  blocked=true
                end
              end
            elseif not r.invoiceAuctionID and not (p and (p.quantity or 0)>1)
                and (row.quantity or 1)==q and (row.buyout==g or row.bid==g) then
              blocked=true
            end
          end
        end
      end
      if #candidates==1 and not blocked then
        for _,old in ipairs(archived) do
          if old.receiptQty==q and old.verifiedGross==g and normalize(old.name)==normalize(r.name)
              and math.abs(old.observedAt-at)<86400 then blocked=true; break end
        end
      end
      if #candidates==1 and not blocked then
        local c=candidates[1]
        local group=proposals[c.id] or {quantity=0,items={},limit=c.limit,row=c.row}
        group.quantity=group.quantity+q
        group.limit=math.min(group.limit,c.limit)
        group.items[#group.items+1]={index=i,receipt=r}
        proposals[c.id]=group
      end
    end
  end
  local consumed,count={},0
  for id,group in pairs(proposals) do
    local p=posts[id]
    if group.quantity<=group.limit-(p.filled or 0) then
      local sale=targets[id]
      if not sale then
        sale=shallow(group.row)
        sale.endedAt,sale.endedReason,sale.deletedAt,sale.deletedKind=nil,nil,nil,nil
        ch.sold[#ch.sold+1]=sale
      end
      p.fills=p.fills or {}
      for _,entry in ipairs(group.items) do
        local r=entry.receipt
        p.fills[r.receiptID]={quantity=r.receiptQty,gross=r.verifiedGross,fee=r.verifiedCut,
          deposit=r.verifiedDeposit,net=r.verifiedNet,buyer=r.receiptBuyer,
          observedAt=r.observedAt,reconciledAt=r.reconciledAt,original=r}
        sale.receiptID=sale.receiptID or r.receiptID
        consumed[entry.index]=true
        count=count+1
      end
      local n,g,fee,deposit,net,latest=fillTotals(p)
      p.filled,p.gross,p.cut,p.integrityFills=n,g,fee,true
      if g%n==0 then
        local unit=g/n
        local consistent=true
        for _,f in pairs(p.fills) do if f.gross~=unit*f.quantity then consistent=false; break end end
        if consistent then p.verifiedUnitPrice=unit end
      end
      p.soldAt=p.soldAt or (latest>0 and latest) or time()
      if n==p.quantity and p.awaitingReturn and not p.returnedUnits and not group.row.cancelRequestedAt then
        p.ended,p.awaitingReturn,p.fillLimit,p.unresolved=nil,nil,nil,nil
        p.ownedSold=true
      elseif p.ended then p.fillLimit=group.limit end
      sale.sold,sale.mailOnly=true,nil
      sale.quantity,sale.receiptQty,sale.receiptQuantityKnown=n,n,true
      sale.verifiedGross,sale.verifiedCut,sale.verifiedDeposit,sale.verifiedNet=g,fee,deposit,net
      sale.soldAt=(latest>0 and latest) or p.soldAt
      sale.saleTimeSource="invoice"
      sale.reconciledAt=time()
      sale.buyout=g
    end
  end
  for i=#ch.sold,1,-1 do if consumed[i] then table.remove(ch.sold,i) end end
  return count
end

function T.Migrate(ch)
  local state=journal(ch)
  if state.migrated then return end
  for _,r in ipairs(ch.active) do T.Observe(ch,r) end
  for _,pool in ipairs({ch.ended,ch.sold,ch.deleted}) do
    for _,r in ipairs(pool) do
      local p=T.Post(ch,r.auctionID)
      if p then
        p.endedAt=p.endedAt or r.endedAt
        p.name=p.name or r.name
      end
    end
  end
  for i=#ch.sold,1,-1 do
    local r=ch.sold[i]
    local p=T.Post(ch,r.auctionID)
    if p and units(p.quantity) and p.quantity>1 and not r.receiptID and not p.filled
        and not p.gross and not p.fullStackObserved and not p.reportedAllSold then
      local id=tostring(r.auctionID)
      local delta=observed(ch,id,p)
      if delta>0 and r.quantity>delta then
        state.superseded[#state.superseded+1]=shallow(r)
        p.remainingSeen=p.quantity-delta
        p.legacySaleNoticeAt=p.soldAt
        p.ownedSold,p.soldAt=nil,nil
        if p.ended then p.fillLimit=delta end
        local hasListing=false
        for _,pool in ipairs({ch.active,ch.ended,ch.deleted}) do
          for _,old in ipairs(pool) do if old.auctionID==r.auctionID then hasListing=true end end
        end
        if not hasListing then
          local listing=shallow(r)
          listing.sold,listing.soldAt=nil,nil
          listing.quantity=p.quantity-delta
          listing.endedReason=p.ended or "unconfirmed"
          listing.endedAt=p.endedAt or ((ch.postingEvidence or {})[id] or {}).lastSeenAt
          ch.ended[#ch.ended+1]=listing
        end
        table.remove(ch.sold,i)
      end
    end
  end
  state.migrated=true
end

function T.Recent(ch,row,now)
  local p=T.Post(ch,row.auctionID)
  if not (p and p.integrityFills and row.receiptID) then
    return row.soldAt and row.soldAt<=now and now-row.soldAt<86400 and row or nil
  end
  local recent=shallow(row)
  recent.quantity,recent.verifiedGross,recent.verifiedCut,recent.verifiedDeposit,recent.verifiedNet=0,0,0,0,0
  for _,f in pairs(p.fills) do
    local at=f.observedAt or f.reconciledAt or p.soldAt
    if at and at<=now and now-at<86400 then
      recent.quantity=recent.quantity+f.quantity
      recent.verifiedGross=recent.verifiedGross+f.gross
      recent.verifiedCut=recent.verifiedCut+f.fee
      recent.verifiedDeposit=recent.verifiedDeposit+f.deposit
      recent.verifiedNet=recent.verifiedNet+f.net
    end
  end
  if recent.quantity==0 then return end
  recent.receiptQty=recent.quantity
  recent.historySource=row
  return recent
end
