local _, AP = ...
local Accounting = {}
AP.Accounting = Accounting

function Accounting.SaleUnits(row)
  if row.mailOnly and not row.auctionID and not row.receiptQuantityKnown then return end
  local quantity = row.receiptQuantityKnown and row.receiptQty or row.quantity
  if type(quantity) == "number" and quantity > 0 and quantity % 1 == 0 then
    return quantity
  end
end

function Accounting.Audit(ch, now)
  local count = {verified=0, pending=0, receipts=0, withoutAuction=0, deferred=0, recent=0}
  local findings, auctions, receipts, purchases, live = {}, {}, {}, {}, {}
  local ledger = ch.craftLedger or {}
  local lots, posts, imports = ledger.lots or {}, ledger.posts or {}, ledger.purchases or {}
  local function flag(kind, id)
    local group = findings[kind]
    if not group then group={count=0, examples={}}; findings[kind]=group end
    group.count=group.count+1
    if #group.examples<6 then group.examples[#group.examples+1]=tostring(id) end
  end
  local function claim(map, kind, id, owner)
    if not id then return end
    id=tostring(id)
    if map[id] then flag(kind,id) else map[id]=owner end
  end
  local function receipt(row, owner)
    local id=row.receiptID
    claim(receipts,"Repeated sale receipt",id,owner)
    if not row.auctionID then count.withoutAuction=count.withoutAuction+1 end
    local gross, cut, deposit, payout=row.verifiedGross,row.verifiedCut,row.verifiedDeposit,row.verifiedNet
    if type(gross)~="number" or type(cut)~="number" or type(deposit)~="number" or type(payout)~="number" then
      flag("Incomplete receipt fields",id)
    elseif gross<=0 or cut<0 or cut>gross or deposit<0 or math.abs(gross-cut+deposit-payout)>2 then
      flag("Receipt arithmetic mismatch",id)
    end
    if row.receiptQuantityKnown and row.receiptQty~=row.quantity then flag("Receipt quantity discrepancy",id) end
  end
  for _,bucket in ipairs({"active","ended","sold","deleted","buys"}) do
    local rows=ch[bucket] or {}
    local seen={}
    count[bucket]=#rows
    for i,row in ipairs(rows) do
      local owner=bucket..":"..i
      local id=row.auctionID and tostring(row.auctionID)
      claim(seen,"Repeated auction in "..bucket,id,owner)
      if bucket=="active" or bucket=="sold" then claim(live,"Shared active/sold auction",id,owner) end
      if id and bucket~="buys" and row.deletedKind~="buys" then auctions[id]=row end
      if row.quantity~=nil and (type(row.quantity)~="number" or row.quantity<=0 or row.quantity%1~=0) then
        flag("Invalid quantity",id or owner)
      end
      local stamp=row.soldAt or row.boughtAt or row.endedAt or row.seenAt
      if stamp and (type(stamp)~="number" or stamp<=0 or (now and stamp>now+300)) then flag("Timestamp outside snapshot",id or owner) end
      if row.receiptID then receipt(row,id or owner) end
      if bucket=="sold" then
        if row.receiptID then count.verified=count.verified+1 else count.pending=count.pending+1 end
        if now and type(row.soldAt)=="number" and row.soldAt<=now and now-row.soldAt<86400 then
          count.recent=count.recent+1
        end
      end
      if bucket=="buys" or row.deletedKind=="buys" then
        claim(purchases,"Repeated purchase ID",row.purchaseID,owner)
        local key=row.purchaseID and "p:"..row.purchaseID
        if bucket=="buys" and key and not imports[key] then count.deferred=count.deferred+1 end
      end
    end
  end
  for key,index in pairs(imports) do
    if not lots[index] then flag("Broken purchase alias",key) end
  end
  local function parts(list, id)
    local units=0
    for _,part in ipairs(list or {}) do
      units=units+(part.n or 0)
      if part.source and not lots[part.source] then flag("Broken allocation reference",id) end
      if type(part.n)~="number" or part.n<=0 or part.n%1~=0 then flag("Invalid allocation quantity",id) end
    end
    return units
  end
  for i,lot in ipairs(lots) do
    if type(lot.left)~="number" or type(lot.quantity)~="number" or lot.left<0 or lot.left>lot.quantity then
      flag("Lot quantity outside bounds",i)
    end
    if type(lot.balance)~="number" or type(lot.cost)~="number" or lot.balance<0 or lot.balance>lot.cost then
      flag("Lot balance outside bounds",i)
    end
    parts(lot.parts,i)
  end
  local fills, postCount={},0
  for id,post in pairs(posts) do
    postCount=postCount+1
    if not auctions[id] then count.postsOutsideHistory=(count.postsOutsideHistory or 0)+1 end
    local units=parts(post.parts,id)
    if post.quantity and (units>post.quantity or (post.filled and post.filled>post.quantity)) then
      flag("Post quantity outside bounds",id)
    end
    for key in pairs(post.fills or {}) do
      claim(fills,"Receipt shared by stack fills",key,id)
      if receipts[key] and receipts[key]~=id then flag("Stack receipt also used by another sale",key) end
    end
  end
  for key in pairs(fills) do receipts[key]=true end
  for _ in pairs(receipts) do count.receipts=count.receipts+1 end
  count.posts,count.lots=postCount,#lots
  return count,findings
end
