local _, addon = ...

-- Normalize each side separately. One row can link two IDs that previously
-- appeared on separate legacy records. Equal prices and times are never IDs.
local function unique(rows, secondID)
  local parent, byID, best, result = {}, {}, {}, {}
  local function root(i)
    while parent[i] ~= i do
      parent[i] = parent[parent[i]]
      i = parent[i]
    end
    return i
  end
  local function bind(i, prefix, id)
    if id == nil or id == "" then return end
    local key = prefix .. tostring(id)
    if byID[key] then parent[root(i)] = root(byID[key]) else byID[key] = i end
  end
  local function quality(r)
    return (r.receiptID and 16 or 0) + (r.auctionID and 8 or 0)
      + ((r.verifiedGross or (r.price and not r.priceEstimated)) and 4 or 0)
      + (r.itemID and 2 or 0) + (r.quantity and 1 or 0)
  end
  for i, row in ipairs(rows) do
    parent[i] = i
    bind(i, "a:", row.auctionID)
    bind(i, "t:", row[secondID])
  end
  for i, row in ipairs(rows) do
    local k = root(i)
    if not best[k] or quality(row) > quality(best[k]) then best[k] = row end
  end
  for i, row in ipairs(rows) do
    if best[root(i)] == row then
      result[#result+1] = row
      best[root(i)] = nil
    end
  end
  return result
end

function addon.BuildHistory(character, nameKey)
  local sales = unique(character.sold, "receiptID")
  local buys = unique(character.buys, "purchaseID")
  local names, keys, counts, flips = {}, {}, {}, {}
  local function index(rows)
    for _, row in ipairs(rows) do
      local id = tonumber(row.itemID) or tonumber((row.link or ""):match("item:(%d+)"))
      local name = nameKey(row.name or row.link)
      if id and id > 0 then
        -- Item level may be absent from purchase callbacks. Suffix identifies
        -- random-enchantment variants when the client supplies it.
        local key = id .. ":" .. (tonumber(row.itemSuffix) or 0)
        keys[row] = key
        if names[name] == nil then names[name] = key
        elseif names[name] ~= key then names[name] = false end
      end
    end
  end
  index(character.active)
  index(buys)
  index(sales)
  local function identity(row)
    if keys[row] then return keys[row] end
    local name = nameKey(row.name or row.link)
    if name == "" or name:match("^unknown") or name:match("^item #") or name:match("^auction #") then return end
    if names[name] == false then return end
    return names[name] or "name:" .. name
  end
  local posts=character.craftLedger and character.craftLedger.posts or {}
  for _, row in ipairs(sales) do
    local key = identity(row)
    if key then
      local c = counts[key] or {linked=0, receipts=0, postings=0}
      counts[key] = c
      local post=posts[tostring(row.auctionID)]
      local units=tonumber(row.receiptQty) or tonumber(row.quantity) or 1
      if post and not row.receiptID then
        units=post.filled or (post.remainingSeen and post.quantity and post.quantity-post.remainingSeen) or units
      end
      if row.receiptID and row.auctionID then c.linked = c.linked + units
      elseif row.receiptID then c.receipts = c.receipts + units
      elseif row.auctionID then c.postings = c.postings + units end
    end
  end
  local function soldCount(row)
    local c = counts[identity(row)]
    if not c then return end
    -- Unlinked receipts and notifications can describe the same sales.
    local n = c.linked + math.max(c.receipts, c.postings)
    if n > 0 then return n, c.receipts > 0 and c.postings > 0 end
  end
  return sales, flips, soldCount
end

-- Read only. Match identifiers within their own namespace, independent of price.
function addon.AuditFlip(ch,nameKey,printLine)
  local sales,flips=addon.BuildHistory(ch,nameKey)
  addon.Crafts.Rows(ch,flips,sales)
  if addon.DETest and addon.DETest.ProjectFlip then
    addon.DETest.ProjectFlip(ch,flips,sales,addon.DETest.Tracked(ch,true))
  end
  local counts,examples={},{}
  local function flag(kind,label)
    counts[kind]=(counts[kind] or 0)+1
    if counts[kind]<=4 then
      examples[kind]=examples[kind] and (examples[kind]..", "..label) or label
    end
  end
  for _,field in ipairs({"auctionID","receiptID"}) do
    local seen={}
    for _,row in ipairs(ch.sold) do
      if row[field] then
        local id=tostring(row[field])
        if seen[id] then flag("Repeated "..field,id) end
        seen[id]=true
      end
    end
  end
  local covered,shared={},{}
  for _,row in ipairs(flips) do
    local id=tostring(row.auctionID)
    covered[id]=(covered[id] or 0)+row.quantity
    for _,receipt in ipairs(row.recoveredReceipts or {}) do shared[receipt]=true end
  end
  for _,group in ipairs(addon.Crafts.ItemGroups(ch,flips,sales)) do
    if group.sharedReceipt then shared[group.sharedReceipt.receiptID]=true end
  end
  local posts=ch.craftLedger and ch.craftLedger.posts or {}
  for _,row in ipairs(sales) do
    local id=tostring(row.auctionID)
    local post=posts[id]
    if row.receiptID and not row.auctionID and not shared[row.receiptID] then
      flag("Receipts without an auction ID",(row.name or "?").." "..row.receiptID)
    end
    if post and post.soldAt then
      local units=post.filled or (post.remainingSeen and not post.gross and post.quantity-post.remainingSeen) or row.quantity or 1
      if units>(covered[id] or 0) then
        flag("Tracked sales with units outside Flip",(row.name or "?").." #"..id)
      end
    end
  end
  printLine("Flip audit of visible sale history (up to four examples per line)")
  for _,kind in ipairs({"Repeated auctionID","Repeated receiptID","Receipts without an auction ID","Tracked sales with units outside Flip"}) do
    printLine(kind.." = "..(counts[kind] or 0)..(examples[kind] and (" | "..examples[kind]) or ""))
  end
end

-- Settle identical single-item invoices as a group. A mail key reserves one
-- payment per post for accounting; it does not identify that auction's buyer.
function addon.SettleReceiptGroups(ch, ids, auctions, normalize)
  local posts=ch.craftLedger and ch.craftLedger.posts
  if not posts then return 0 end
  local groups={}
  for _,r in ipairs(ch.sold) do
    if r.mailOnly and not r.auctionID and r.name then
      local key=normalize(r.name).."|"..tostring(r.verifiedGross)
      groups[key]=groups[key] or {}
      table.insert(groups[key],r)
    end
  end

  -- A later, differently priced listing can look like a repost when the AH
  -- refresh happens after payment. Its distinct craft lot corroborates the invoice.
  local function independentListing(old, earliest)
    if not old.repostedAs then return true end
    for _,row in ipairs(ch.active) do
      if row.auctionID==old.repostedAs and row.repostOf==old.auctionID and row.itemID==old.itemID
          and row.firstSeenAt and row.firstSeenAt>earliest and row.buyout~=old.buyout then
        local a,b=posts[tostring(old.auctionID)],posts[tostring(row.auctionID)]
        if not a or not b or not b.at or b.at<=earliest or #(a.parts or {})~=1 or #(b.parts or {})~=1 then return end
        local x,y=ch.craftLedger.lots[a.parts[1].source],ch.craftLedger.lots[b.parts[1].source]
        if x and y and x~=y and x.parts and y.parts and x.quantity==1 and y.quantity==1
            and x.itemID==old.itemID and y.itemID==old.itemID then return row end
      end
    end
  end

  local function candidates(name, receipts)
    name=normalize(receipts[1].name)
    local first=receipts[1]
    local earliest,latest=math.huge,0
    local targets,byID={},{}
    for _,r in ipairs(receipts) do
      if not (r.receiptID and ids[r.receiptID]==1 and r.receiptQuantityKnown and r.receiptQty==1
          and r.observedAt and r.verifiedGross and r.verifiedCut and r.verifiedDeposit and r.verifiedNet
          and r.verifiedGross==first.verifiedGross and r.verifiedCut==first.verifiedCut
          and r.verifiedDeposit==first.verifiedDeposit and r.verifiedNet==first.verifiedNet
          and r.verifiedGross-r.verifiedCut+r.verifiedDeposit==r.verifiedNet) then return end
      earliest=math.min(earliest,r.observedAt)
      latest=math.max(latest,r.observedAt)
    end
    local item,suffix
    local closed={}
    for _,pool in ipairs({ch.sold,ch.deleted,ch.active,ch.ended}) do
      for _,r in ipairs(pool) do
        if normalize(r.name or r.link)==name then
          local id=tostring(r.auctionID)
          local price=r.buyout
          if pool==ch.ended and (r.endedReason=="canceled" or r.endedReason=="expired") then
            closed[id]=true
          elseif pool==ch.deleted and r.mailOnly and not r.auctionID
              and (not r.verifiedGross or r.verifiedGross==first.verifiedGross) then return
          elseif not r.receiptID and (not price or price==0 or price==first.verifiedGross or r.bid==first.verifiedGross) then
            local p=posts[id]
            if not p or not r.auctionID or not r.itemID or byID[id] or price~=first.verifiedGross
                or r.quantity~=1 or p.quantity~=1 or p.itemID~=r.itemID or p.ended or p.filled or p.gross
                or not independentListing(r,latest) or r.cancelRequestedAt or r.returnCollectedAt
                or (item and (item~=r.itemID or suffix~=(r.itemSuffix or 0))) then return end
            if pool==ch.sold then
              if not r.sold or not p.ownedSold or not p.soldAt or auctions[id]~=1
                  or not r.endTime or not r.soldAt or r.soldAt>r.endTime or r.endTime>earliest
                  or latest-r.endTime>86400 then return end
            elseif pool==ch.ended then
              -- This listing vanished at the first AH refresh around collection.
              if r.endedReason~="unconfirmed" or not p.unresolved or p.soldAt or auctions[id]
                  or not r.seenAt or r.seenAt>earliest or latest-r.seenAt>86400
                  or not r.endedAt or r.endedAt<r.seenAt or r.endedAt>latest+3600
                  or p.totalPrice~=price or p.remainderTo or p.remainingSeen then return end
            else return end
            item,suffix=r.itemID,r.itemSuffix or 0
            byID[id]=true
            targets[#targets+1]=r
          end
        end
      end
    end
    if #targets~=#receipts then return end
    for id in pairs(byID) do if closed[id] then return end end
    for id,p in pairs(posts) do
      if p.itemID==item and not p.ended and not p.gross and not byID[tostring(id)]
          and (not p.totalPrice or p.totalPrice==first.verifiedGross or p.quantity~=1) then return end
    end
    return targets
  end

  local consumed,count={},0
  for name,receipts in pairs(groups) do
    local targets=candidates(name,receipts)
    if targets then
      table.sort(targets,function(a,b) return a.auctionID<b.auctionID end)
      table.sort(receipts,function(a,b) return a.receiptID<b.receiptID end)
      local members={}
      for i,r in ipairs(receipts) do members[i]=r.receiptID end
      local group=table.concat(members,", ")
      for i,target in ipairs(targets) do
        local r=receipts[i]
        if target.endedReason=="unconfirmed" then
          for j=#ch.ended,1,-1 do
            if ch.ended[j]==target then table.remove(ch.ended,j);break end
          end
          if target.repostedAs then
            local later=independentListing(target,r.observedAt)
            if type(later)=="table" then later.repostOf,later.repostCount=nil,nil end
            target.repostedAs=nil
          end
          target.endedReason,target.endedAt=nil,nil
          target.sold,target.soldAt,target.mailOnly=true,r.soldAt,true
          table.insert(ch.sold,target)
        end
        if #targets>1 then
          target.receiptGroup=group
          target.groupInvoiceBuyer=r.receiptBuyer
        else target.receiptBuyer=r.receiptBuyer end
        for _,field in ipairs({"receiptID","verifiedGross","verifiedNet","verifiedCut","verifiedDeposit",
            "receiptQty","receiptQuantityKnown","observedAt","reconciledAt"}) do target[field]=r[field] end
        addon.Crafts.Sale(ch,target)
        consumed[r]=true
        count=count+1
      end
    end
  end
  if count>0 then
    for i=#ch.sold,1,-1 do if consumed[ch.sold[i]] then table.remove(ch.sold,i) end end
  end
  return count
end

-- Recover a whole commodity stack when the sold snapshot describes only one
-- fill and a later end event conflicts with the complete set of invoices.
-- Work from one full AH snapshot. Count each sale line once within that
-- snapshot and remember only a corroborated full stack across later scans.
function addon.ObserveSoldStacks(ch,rows)
  local posts=ch.craftLedger and ch.craftLedger.posts or {}
  local groups={}
  for _,r in ipairs(rows) do
    local key=tostring(r.auctionID)
    local p=posts[key]
    if p and p.quantity and p.quantity>1 then
      local g=groups[key] or {units=0,lines=0}
      groups[key]=g
      if not r.sold or r.itemID~=p.itemID or not r.quantity or r.quantity<1
          or not p.totalPrice or p.totalPrice<=0 or r.buyout~=p.totalPrice*r.quantity then
        g.conflict=true
      else
        g.units=g.units+r.quantity
        g.lines=g.lines+1
      end
    end
  end
  for key,g in pairs(groups) do
    local p=posts[key]
    if not g.conflict and g.lines>1 and g.units==p.quantity and
        not (p.returnedUnits or p.remainderTo or p.fillLimit) then p.fullStackObserved=true end
  end
end

local function differentStackPrice(other,unit)
  return other and other.quantity and other.quantity>1 and other.totalPrice and other.totalPrice>0
    and other.totalPrice~=unit and other.totalPrice~=unit*other.quantity
    and (not other.unitPrice or other.unitPrice~=unit)
end

function addon.SettleSplitStacks(ch,ids)
  local ledger=ch.craftLedger
  if not ledger then return 0 end
  local consumed,count={},0
  for _,sale in ipairs(ch.sold) do
    local key=tostring(sale.auctionID)
    local p=ledger.posts[key]
    if p and sale.sold and not sale.receiptID and not sale.repostedAs and not sale.cancelRequestedAt
        and not sale.returnCollectedAt and ((p.awaitingReturn and p.ended=="canceled") or p.fullStackObserved) and not (p.returnedUnits or p.fills or p.filled
          or (p.remainingSeen and not p.fullStackObserved) or p.remainderTo or p.fillLimit or p.gross)
        and p.quantity and sale.quantity and sale.quantity>0 and p.quantity>1 and p.quantity>=sale.quantity
        and p.itemID==sale.itemID and p.soldAt and p.soldAt==sale.soldAt and sale.endTime
        and p.totalPrice and p.totalPrice>0 and p.totalPrice*sale.quantity==sale.buyout then
      local invoices={}
      local units,gross,net,fee,deposit=0,0,0,0,0
      local unique=true
      local endedBefore={}
      for _,pool in ipairs({ch.sold,ch.active,ch.ended,ch.deleted}) do
        for _,r in ipairs(pool) do
          if r~=sale and (r.itemID==sale.itemID or r.name==sale.name or tostring(r.auctionID)==key) then
            local other=ledger.posts[tostring(r.auctionID)]
            if r.auctionID and tostring(r.auctionID)~=key and differentStackPrice(other,p.totalPrice) then
              -- This listing cannot account for any of the candidate invoices.
            elseif r.mailOnly and r.receiptQuantityKnown and r.receiptQty and r.receiptQty>0
                and r.verifiedGross and r.verifiedGross~=r.receiptQty*p.totalPrice then
              -- Different verified unit price.
            elseif pool==ch.sold and r.mailOnly and not r.auctionID and r.observedAt
                and r.observedAt>=((p.reportedAllSold or p.fullStackObserved) and p.soldAt or sale.endTime-60) and r.observedAt<=sale.endTime+86400 then
              local q=r.receiptQty
              if not (r.receiptQuantityKnown and q and q>0 and q<=p.quantity and ids[r.receiptID]==1
                  and r.verifiedGross==p.totalPrice*q and r.verifiedCut and r.verifiedDeposit
                  and r.verifiedGross-r.verifiedCut+r.verifiedDeposit==r.verifiedNet) then unique=false
              else
                invoices[#invoices+1]=r
                units,gross=units+q,gross+r.verifiedGross
                net,fee,deposit=net+r.verifiedNet,fee+r.verifiedCut,deposit+r.verifiedDeposit
              end
            elseif pool==ch.ended and r.auctionID and tostring(r.auctionID)~=key and r.endedAt and r.endedAt<p.at then
              endedBefore[tostring(r.auctionID)]=true
            elseif tostring(r.auctionID)==key or (r.observedAt or r.endedAt or r.endTime or r.soldAt or math.huge)>=p.at then unique=false end
          end
        end
      end
      for id,other in pairs(ledger.posts) do
        if id~=key and other.itemID==p.itemID and not differentStackPrice(other,p.totalPrice) and not (endedBefore[id] and other.totalPrice and other.totalPrice~=p.totalPrice)
            and (not other.at or other.at>=p.at-86400) then unique=false end
      end
      if unique and units==p.quantity and (#invoices>=2 or sale.quantity==p.quantity) then
        table.sort(invoices,function(a,b)return a.observedAt<b.observedAt or
          (a.observedAt==b.observedAt and a.receiptID<b.receiptID) end)
        if #invoices==1 then sale.receiptBuyer=invoices[1].receiptBuyer end
        p.fills={}
        for _,r in ipairs(invoices) do
          p.fills[r.receiptID]={quantity=r.receiptQty,gross=r.verifiedGross,net=r.verifiedNet,
            fee=r.verifiedCut,deposit=r.verifiedDeposit,buyer=r.receiptBuyer,observedAt=r.observedAt,
            reconciledAt=r.reconciledAt}
          consumed[r]=true
        end
        p.filled,p.gross,p.cut=units,gross,fee
        p.ended,p.awaitingReturn,p.unresolved=nil,nil,nil
        p.ownedSold=true
        sale.quantity,sale.receiptQty,sale.receiptQuantityKnown=units,units,true
        sale.receiptID,sale.observedAt=invoices[1].receiptID,invoices[1].observedAt
        sale.reconciledAt=invoices[#invoices].reconciledAt
        sale.verifiedGross,sale.verifiedNet,sale.verifiedCut,sale.verifiedDeposit=gross,net,fee,deposit
        count=count+#invoices
      end
    end
  end
  if count>0 then
    for i=#ch.sold,1,-1 do if consumed[ch.sold[i]] then table.remove(ch.sold,i) end end
  end
  return count
end

-- Build the picker again on confirmation. Hidden, duplicate and previously
-- settled IDs must not become available through an already open inspector.
function addon.ManualTargets(ch,id,nameKey)
  local receipt,index
  local blocked,seen={},{}
  local posts=ch.craftLedger and ch.craftLedger.posts or {}
  for _,pool in ipairs({ch.sold,ch.deleted,ch.active,ch.ended}) do
    for i,row in ipairs(pool or {}) do
      if row.receiptID==id then
        if receipt or pool~=ch.sold or row.auctionID or not row.mailOnly then return {} end
        receipt,index=row,i
      end
      if row.receiptGroup then
        for member in tostring(row.receiptGroup):gmatch("mail:%d+") do
          if member==id then return {} end
        end
      end
      if row.auctionID then
        local key=tostring(row.auctionID)
        if seen[key] or pool~=ch.sold then blocked[key]=true end
        seen[key]=true
      end
    end
  end
  for _,p in pairs(posts) do if p.fills and p.fills[id] then return {} end end
  if not receipt or not receipt.receiptQuantityKnown
      or type(receipt.receiptQty)~="number" or receipt.receiptQty<1
      or receipt.receiptQty~=math.floor(receipt.receiptQty)
      or not receipt.observedAt or not receipt.name or not receipt.verifiedGross
      or receipt.verifiedGross<=0 or type(receipt.verifiedNet)~="number"
      or type(receipt.verifiedCut)~="number" or type(receipt.verifiedDeposit)~="number"
      or receipt.verifiedCut<0 or receipt.verifiedCut>receipt.verifiedGross
      or receipt.verifiedGross-receipt.verifiedCut+receipt.verifiedDeposit~=receipt.verifiedNet then return {} end
  local out={}
  for _,r in ipairs(ch.sold) do
    local k=tostring(r.auctionID)
    local p=posts[k] or {}
    local price=r.buyout or 0
    if r.auctionID and not blocked[k] and r.sold and r.soldAt and r.soldAt<=receipt.observedAt
        and not (r.receiptID or r.repostedAs or r.returnCollectedAt or r.endedReason
          or r.cancelRequestedAt or p.gross or p.fills or p.filled or p.returnedUnits or p.remainderTo)
        and (not p.ended or (p.awaitingReturn and not p.itemID and not r.itemID))
        and ((receipt.receiptQty==1 and (not r.quantity or r.quantity==1)
              and (not p.quantity or p.quantity==1))
          or (receipt.receiptQty>1 and r.quantity==receipt.receiptQty
              and p.quantity==receipt.receiptQty and p.itemID==r.itemID
              and p.parts and #p.parts>0 and not p.remainingSeen))
        and (not receipt.itemID or not r.itemID or receipt.itemID==r.itemID)
        and (not receipt.itemSuffix or not r.itemSuffix or receipt.itemSuffix==r.itemSuffix)
        and nameKey(r.name or r.link)==nameKey(receipt.name)
        and ((receipt.receiptQty==1 and (not r.endTime or r.endTime<=receipt.observedAt+5))
          or (receipt.receiptQty>1 and receipt.observedAt-r.soldAt<=86400))
        and ((receipt.receiptQty==1 and price==0 and (r.bid or 0)==0 and (p.totalPrice or 0)==0)
          or price==receipt.verifiedGross or (receipt.receiptQty==1 and r.bid==receipt.verifiedGross)
          or p.totalPrice==receipt.verifiedGross) then
      out[#out+1]=r
    end
  end
  table.sort(out,function(a,b) return a.soldAt>b.soldAt end)
  return out,receipt,index
end

function addon.MatchPayment(ch,id,auction,nameKey)
  local rows,receipt,index=addon.ManualTargets(ch,id,nameKey)
  for _,r in ipairs(rows) do
    if tostring(r.auctionID)==tostring(auction) then
      r.manualReceiptSource=addon.Crafts.ManualReceiptSource(ch,r,receipt)
      r.manualPayment=true
      for _,k in ipairs({"receiptID","verifiedGross","verifiedNet","verifiedCut","verifiedDeposit",
          "receiptBuyer","receiptQty","receiptQuantityKnown","reconciledAt","observedAt"}) do
        r[k]=receipt[k]
      end
      r.quantity=r.quantity or receipt.receiptQty
      addon.Crafts.Sale(ch,r)
      table.remove(ch.sold,index)
      return r
    end
  end
end
