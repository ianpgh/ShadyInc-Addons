-- Observe item returns independently from seller invoices.
local _, AP = ...
local rows, counts, requests = {}, {}, {}
local watching = false

local function readable(v)
  return not issecretvalue or not issecretvalue(v)
end

local function returnedItem(index)
  local _,_,sender,subject,money,cod,_,hasItem = GetInboxHeaderInfo(index)
  if not readable(sender) or not readable(subject) or not readable(money) or not readable(cod)
      or not money or not cod then return nil,false end
  if money~=0 or cod~=0 or type(subject)~="string" then return end
  if sender~="Auction House" and (not AUCTION_HOUSE or sender~=AUCTION_HOUSE) then return end
  local name,id,_,n=GetInboxItem(index,1)
  if not readable(name) or not readable(id) or not readable(n) then return nil,false end
  if not name then
    if not readable(hasItem) or (hasItem and hasItem~=0) then return nil,false end
    return
  end
  if type(id)~="number" or type(n)~="number" or n<1 then return nil,false end
  -- Stacked attachments may include their quantity in the auction subject.
  local suffix=" ("..n..")"
  if subject:sub(-#suffix)==suffix then subject=subject:sub(1,-#suffix-1) end
  local function subjectMatches(template)
    return type(template)=="string" and subject==template:gsub("%%s",function() return name end)
  end
  local reason
  if subjectMatches(AUCTION_REMOVED_MAIL_SUBJECT) or subjectMatches(AUCTION_CANCELED_MAIL_SUBJECT) or subject=="Auction cancelled: "..name
      or subject=="Auction canceled: "..name then reason="canceled"
  elseif subjectMatches(AUCTION_EXPIRED_MAIL_SUBJECT) or subject=="Auction expired: "..name then reason="expired"
  else return end
  return {id=id,n=n,reason=reason,key=reason.."/"..id.."/"..n}
end

local function confirm(ch,item)
  local posts=ch.craftLedger and ch.craftLedger.posts or {}
  local target,post
  for _,pool in ipairs({ch.ended,ch.active,ch.deleted,ch.sold}) do
    for _,row in ipairs(pool) do
      if row.itemID==item.id and row.auctionID and not row.returnCollectedAt then
        local p=posts[tostring(row.auctionID)]
        local n=p and AP.Crafts.ReturnQuantity(p) or nil
        local partial=p and (p.filled or p.remainingSeen)
        if (n==item.n or (not p and row.quantity==item.n)) and (not row.sold or partial)
            and (not row.endedReason or row.endedReason=="unconfirmed" or row.endedReason==item.reason)
            and (not p or not p.ended or p.ended==item.reason) then
          if target and target.auctionID~=row.auctionID then return end
          target,post=row,p
        end
      end
    end
  end
  if not target or target.repostedAs then return end
  if target.endedReason~=item.reason and not (post and post.ended==item.reason) then
    local now=time()
    local seen=target.seenAt or target.firstSeenAt
    if not seen or now<seen or now-seen>86400 then return end
    if item.reason=="expired" and (not target.endTime or target.endTime>now+5) then return end
  end
  if post and not AP.Crafts.CollectReturn(ch,post,item.n,item.reason,target.auctionID) then return end
  target.returnCollectedAt=time()
  target.endedReason=item.reason
  if AP.QueueReceiptReview then AP.QueueReceiptReview() end
end

function AP.ScanReturns()
  if not watching or not GetInboxItem or not GetInboxNumItems then return end
  local n=GetInboxNumItems()
  if not readable(n) or type(n)~="number" or n>200 then return end
  local fresh,totals={},{}
  for i=1,n do
    local item,valid=returnedItem(i)
    if valid==false then return end
    if item then fresh[i]=item; totals[item.key]=(totals[item.key] or 0)+1 end
  end
  for key,request in pairs(requests) do
    if GetTime()-request.at>10 then requests[key]=nil
    elseif (counts[key] or 0)==1 and not totals[key] then
      requests[key]=nil
      confirm(AP.Character(),request.item)
    end
  end
  rows,counts=fresh,totals
end

function AP.ReturnMailbox(open)
  rows,counts,requests={},{},{}
  watching=open
  if open then AP.ScanReturns() end
end

function AP.InstallReturnHooks()
  if not hooksecurefunc then return end
  if C_AuctionHouse and C_AuctionHouse.CancelAuction then
    hooksecurefunc(C_AuctionHouse,"CancelAuction",function(id)
      if not readable(id) then return end
      local ch=AP.Character()
      if not ch then return end
      for _,row in ipairs(ch.active) do
        if row.auctionID==id then row.cancelRequestedAt=time();break end
      end
    end)
  end
  local function take(index,attachment)
    if not watching or not readable(index) or not readable(attachment) or (attachment and attachment~=1) then return end
    local item=rows[index]
    if item and counts[item.key]==1 then
      requests[item.key]={item=item,at=GetTime()}
      AP.ScanReturns()
    end
  end
  if TakeInboxItem then hooksecurefunc("TakeInboxItem",take) end
  if AutoLootMailItem then hooksecurefunc("AutoLootMailItem",function(index) take(index) end) end
end
function AP.ReturnTakeFailed() requests={} end
