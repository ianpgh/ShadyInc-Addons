local _, AP = ...
local C = {}
AP.Crafts = C

local function positive(n)
  return type(n) == "number" and n > 0 and n == math.floor(n)
end
local function itemName(id)
  local get = C_Item and C_Item.GetItemNameByID
  return (get and get(id)) or (GetItemInfo and GetItemInfo(id)) or ("Item #" .. id)
end
local function ledger(ch)
  if not ch.craftLedger then
    ch.craftLedger = {lots={}, purchases={}, casts={}, posts={}}
  end
  return ch.craftLedger
end
local function lot(l, id, qty, cost, at, extra)
  local x = extra or {}
  x.itemID, x.quantity, x.left, x.at = id, qty, qty, at
  x.cost, x.balance = cost or 0, cost or 0
  l.lots[#l.lots+1] = x
  x.index = #l.lots
  return x
end
-- Only the client's personal loot formats qualify. Created items, vendor
-- purchases, group loot announcements and generic item receipts use other text.
local lootPatterns = {}
local function lootPattern(template)
  if not template then return end
  if not lootPatterns[template] then
    local pattern = template:gsub("%%1%$s", "%%s"):gsub("%%2%$d", "%%d")
    pattern = pattern:gsub("([%(%)%.%+%-%*%?%[%]%^%$])", "%%%1")
    lootPatterns[template] = "^"..pattern:gsub("%%s", "(.-)"):gsub("%%d", "(%%d+)").."$"
  end
  return lootPatterns[template]
end

function C.PersonalLoot(ch, message)
  if not AP.MailValueReadable(message) or type(message) ~= "string" then return end
  local template = lootPattern(LOOT_ITEM_SELF_MULTIPLE)
  local link, count
  if template then link, count = message:match(template) end
  if not link then
    template = lootPattern(LOOT_ITEM_SELF)
    link = template and message:match(template)
    count = 1
  end
  local id = link and tonumber(link:match("|Hitem:(%d+)"))
  count = tonumber(count)
  if positive(id) and positive(count) then
    lot(ledger(ch), id, count, 0, time(), {looted=true})
    return id,count
  end
end

local function import(l, rows)
  -- Buy History is newest first. Process oldest first even after a restore.
  for i=#rows,1,-1 do
    local r=rows[i]
    local a=r.auctionID and "a:"..r.auctionID
    local p=r.purchaseID and "p:"..r.purchaseID
    local id=tonumber(r.itemID) or tonumber((r.link or ""):match("item:(%d+)"))
    if (a or p) and positive(id) and positive(r.quantity) then
      local existing=(a and l.purchases[a]) or (p and l.purchases[p])
      local x=existing and l.lots[existing] or lot(l,id,r.quantity,r.price,r.boughtAt or 0,
        {unknown=not positive(r.price), estimate=r.priceEstimated, vendor=r.vendor, purchase=r.purchaseID})
      if a then l.purchases[a]=x.index end
      if p then l.purchases[p]=x.index end
    end
  end
end
-- Restore the reported purchase only against its original unpriced allocation.
function C.RecoverGrayDye(ch,unit)
  local l=ch.craftLedger
  local p=l and l.posts["181419023"]
  if not p or p.itemID~=4340 or p.quantity~=20 or p.at~=1795404006 or p.totalPrice~=467
      or p.returnedUnits or p.remainderTo or #(p.parts or {})~=1 then return end
  local a=p.parts[1]
  if a.itemID~=4340 or a.n~=20 then return end
  local sale
  for _,r in ipairs(ch.sold) do
    if r.auctionID==181419023 and r.itemID==4340 and r.sold then sale=r end
  end
  if not sale then return end
  local row,thread
  for _,pool in ipairs({ch.buys,ch.deleted}) do
    for _,r in ipairs(pool) do
      if r.recoveredGrayDye then
        if pool~=ch.buys or row then return end
        row=r
      elseif r.purchaseID==184 and r.itemID==8343 and r.vendor and r.boughtAt==1795403949
          and r.quantity==12 and r.price==19440 then thread=r
      elseif r.itemID==4340 and r.purchase and r.boughtAt and r.boughtAt>=1795403910 and r.boughtAt<=p.at then return end
    end
  end
  if not thread then return end
  if not row then
    if a.source or not a.unknown or a.cost~=0 then return end
    ch.nextPurchaseID=ch.nextPurchaseID+1
    row={purchase=true,purchaseID=ch.nextPurchaseID,itemID=4340,name="Gray Dye",vendor=true,
      quantity=20,boughtAt=thread.boughtAt,recoveredGrayDye=true,
      source="Player-reported purchase. Time approximate (thread purchase during the same visit)."}
    local idx=1
    while ch.buys[idx] and (ch.buys[idx].boughtAt or 0)>row.boughtAt do idx=idx+1 end
    table.insert(ch.buys,idx,row)
    import(l,{row})
    a.source=l.purchases["p:"..row.purchaseID]
    local x=l.lots[a.source]
    x.left,x.balance=0,0
    p.reportedAllSold=true
  end
  if unit and positive(unit) and unit<=1000000 then
    local x=l.lots[a.source]
    if not x or x.purchase~=row.purchaseID or x.left~=0 then return end
    row.price=unit*20
    a.cost,x.cost=row.price,row.price
    a.unknown,x.unknown=false,false
  end
  return row
end

-- Original AH screenshot records 10+7+2+1 at 467c, then 19+1 at 349c.
function C.RecoverDyeSplit(ch)
  local l=ch.craftLedger
  if not l then return end
  for _,r in ipairs(ch.sold) do
    local p=l.posts[tostring(r.auctionID)]
    local unit=r.auctionID==181419023 and 467 or r.auctionID==182089752 and 349
    if unit and r.sold and r.itemID==4340 and r.quantity and r.quantity>0 and r.quantity<=20
        and r.buyout==unit*r.quantity and not (r.receiptID or r.returnCollectedAt or r.repostedAs)
        and p and p.itemID==4340 and p.quantity==20 and p.totalPrice==unit
        and not (p.returnedUnits or p.remainderTo or p.fillLimit or p.filled or p.gross) then
      p.fullStackObserved=true
      p.soldAt=p.soldAt or r.soldAt
      r.quantity,r.buyout=20,20*unit
      if unit==349 and p.parts and #p.parts==1 and p.parts[1].unknown
          and not p.parts[1].source and p.parts[1].n==20 then
        local candidate
        for _,b in ipairs(ch.buys) do
          if b.manualVendor and b.source and b.source:find("Second player-reported stack",1,true)
              and b.itemID==4340 and b.quantity==20 then
            if candidate then candidate=nil;break end
            candidate=b
          end
        end
        if candidate then
          import(l,{candidate})
          local x=l.lots[l.purchases["p:"..candidate.purchaseID]]
          if x and x.left==20 and x.balance==x.cost then
            p.parts={{source=x.index,itemID=4340,n=20,cost=x.cost,estimate=x.estimate,unknown=x.unknown}}
            x.left,x.balance=0,0
          end
        end
      end
    end
  end
end

local function take(l,id,qty,at,onHand,posting)
  local parts,candidates={},{}
  local total=0
  for _,x in ipairs(l.lots) do
    if x.itemID==id and x.left>0 and x.at<=at then
      candidates[#candidates+1]=x
      total=total+x.left
    end
  end
  table.sort(candidates,function(a,b)
    if a.at~=b.at then return a.at<b.at end
    return a.index<b.index
  end)
  -- Older records may describe stock already used before tracking began.
  -- Limit this cast to the newest lots that fit in the observed inventory.
  -- Keep skipped balances intact: those units could also be stored elsewhere.
  local skip=onHand and math.max(0,total-onHand) or 0
  -- A commodity listing carries no bag-slot identity. If both purchased and
  -- looted copies fit a partial withdrawal, FIFO is only a cost estimate.
  local mixed=false
  if posting and qty<total then
    local bought,looted=false,false
    for _,x in ipairs(candidates) do
      if x.looted then looted=true elseif not x.parts then bought=true end
    end
    mixed=bought and looted
    if mixed then
      for _,x in ipairs(candidates) do
        if not x.parts then x.sourceUncertain=true end
      end
    end
  end
  for _,x in ipairs(candidates) do
    local unavailable=math.min(skip,x.left)
    skip=skip-unavailable
    local n=math.min(qty,x.left-unavailable)
    if n>0 then
      local i=x.index
      local cost=math.floor(x.balance*n/x.left)
      parts[#parts+1]={source=i,itemID=id,n=n,cost=cost,unknown=x.unknown,estimate=x.estimate or x.sourceUncertain,sourceUncertain=x.sourceUncertain,returnedFrom=x.returnedFrom}
      x.returnedFrom=nil
      x.left,x.balance=x.left-n,x.balance-cost
      qty=qty-n
      if qty==0 then break end
    end
  end
  if qty>0 then parts[#parts+1]={itemID=id,n=qty,cost=0,unknown=true} end
  return parts
end
local function schematic(spell)
  local api=C_TradeSkillUI
  if not api or not api.GetRecipeSchematic then return end
  local ok,s=pcall(api.GetRecipeSchematic,spell,false)
  if not ok or type(s)~="table" or s.isRecraft or not positive(s.outputItemID)
    or not positive(s.quantityMin) or s.quantityMax~=s.quantityMin
    or type(s.reagentSlotSchematics)~="table" then return end
  local mats={}
  for _,slot in ipairs(s.reagentSlotSchematics) do
    local items=slot.reagents
    if slot.required==false or not items or #items~=1 or not positive(items[1].itemID)
      or not positive(slot.quantityRequired) or (slot.variableQuantities and next(slot.variableQuantities)) then return end
    mats[#mats+1]={id=items[1].itemID,n=slot.quantityRequired}
  end
  if #mats>0 then return {id=s.outputItemID,n=s.quantityMin,mats=mats} end
end
-- Material costs store known copper even when part of a craft was unpriced.
-- Apply the zero-cost convention only inside crafts and their posted copies.
function C.UpdateMaterialCosts(ch)
  local l=ch.craftLedger
  if not l or l.zeroCostMaterials then return end
  for _,batch in ipairs(l.lots) do
    if batch.parts then
      for _,part in ipairs(batch.parts) do part.unknown=nil end
      batch.unknown=nil
    end
  end
  for _,post in pairs(l.posts) do
    for _,part in ipairs(post.parts or {}) do
      local batch=l.lots[part.source]
      if batch and batch.parts then part.unknown=nil end
    end
  end
  l.zeroCostMaterials=true
end
function C.Record(ch,guid,recipe,at)
  local l=ledger(ch)
  if l.casts[guid] then return end
  import(l,ch.buys)
  local parts,total,estimate={},0,false
  for _,m in ipairs(recipe.mats) do
    for _,p in ipairs(take(l,m.id,m.n,at,recipe.onHand and recipe.onHand[m.id])) do
      p.unknown=nil
      parts[#parts+1]=p
      total=total+p.cost
      estimate=estimate or p.estimate
    end
  end
  local x=lot(l,recipe.id,recipe.n,total,at,{parts=parts,estimate=estimate})
  l.casts[guid]=x.index
  return x
end
local pending={}
function C.Cast(ch,event,unit,guid,spell)
  if (issecretvalue and (issecretvalue(unit) or issecretvalue(guid) or issecretvalue(spell)))
    or unit~="player" or type(guid)~="string" or guid=="" or not positive(spell) then return end
  if event=="UNIT_SPELLCAST_START" then
    pending={} -- Only one normal profession cast can be in progress.
    local recipe=schematic(spell)
    if recipe then
      local count=(C_Item and C_Item.GetItemCount) or GetItemCount
      if count then
        recipe.onHand={}
        for _,m in ipairs(recipe.mats) do
          local ok,n=pcall(count,m.id,false,false)
          if ok and not (issecretvalue and issecretvalue(n)) and positive(n) and n>=m.n then
            recipe.onHand[m.id]=n
          end
        end
      end
      pending[guid]=recipe
    end
  elseif event=="UNIT_SPELLCAST_SUCCEEDED" then
    local recipe=pending[guid] or schematic(spell)
    pending[guid]=nil
    if recipe then return C.Record(ch,guid,recipe,time()) end
  else pending[guid]=nil end
end
function C.Created(ch,id)
  if not positive(id) then return end
  local l=ledger(ch)
  local k=tostring(id)
  if l.posts[k] then return end
  l.posts[k]={at=time()}
  -- An owned snapshot may have arrived before the creation notification.
  for _,bucket in ipairs({ch.active or {},ch.sold or {}}) do
    for _,r in ipairs(bucket) do
      if tostring(r.auctionID)==k then
        if r.sold then C.Sale(ch,r) else C.Observe(ch,r) end
        return
      end
    end
  end
end
function C.Observe(ch,row)
  local l=ch.craftLedger
  local post=l and l.posts[tostring(row.auctionID)]
  if not post or post.ended then return end
  post.unresolved=nil
  if post.parts and not row.sold and positive(row.quantity) and row.quantity < post.quantity then
    post.remainingSeen=math.min(post.remainingSeen or post.quantity,row.quantity)
  end
  if post.parts or not positive(row.itemID) or not positive(row.quantity) then return end
  import(l,ch.buys)
  post.parts=take(l,row.itemID,row.quantity,post.at,nil,true)
  post.quantity=row.quantity
  post.itemID,post.totalPrice,post.unitPrice=row.itemID,row.buyout,row.unitPrice
end
-- Called only for an authoritative sold ID or a specifically audited repair.
function C.ConfirmSoldID(ch,row,ownedSnapshot)
  local l=ch.craftLedger
  local p=l and l.posts[tostring(row.auctionID)]
  if not p or p.returnedUnits then return end
  if row.quantity~=1 or (p.quantity or row.quantity)~=1 then
    if ownedSnapshot and row.sold and row.quantity and row.quantity>1
        and p.quantity==row.quantity and p.itemID==row.itemID and p.parts
        and not (p.ended or p.remainingSeen or p.filled or p.fillLimit or p.remainderTo) then
      p.ownedSold=true
    end
    return
  end
  if p.ended=="canceled" or p.ended=="expired" then
    -- End released these parts only if there was no evidence of a sale.
    if not (p.awaitingReturn or p.soldAt or p.filled or p.remainingSeen) then p.parts=nil end
    p.awaitingReturn=nil
    p.ended=nil
  end
  p.ownedSold=true
end

function C.End(ch,id,reason)
  local l=ch.craftLedger
  local p=l and l.posts[tostring(id)]
  if not p or p.ended or p.ownedSold then return end
  if p.filled or p.remainingSeen or p.soldAt then
    if reason=="expired" or reason=="canceled" then
      p.ended=reason
      p.awaitingReturn=true
      if p.filled or p.remainingSeen then
        p.fillLimit=math.max(p.filled or 0,p.remainingSeen and p.quantity-p.remainingSeen or 0)
      end
    end
    return
  end
  if reason=="unconfirmed" then p.unresolved=true; return end
  if reason~="expired" and reason~="canceled" then return end
  p.ended=reason
  p.awaitingReturn=true
end
-- Split each original lot in integer copper. Adjacent slices conserve its cost.
local function slice(parts,start,count)
  local result,offset={},0
  for _,part in ipairs(parts) do
    local a=math.max(0,start-offset)
    local b=math.min(part.n,start+count-offset)
    if b>a then
      result[#result+1]={itemID=part.itemID,source=part.source,n=b-a,
        cost=math.floor(part.cost*b/part.n)-math.floor(part.cost*a/part.n),
        unknown=part.unknown,estimate=part.estimate,sourceUncertain=part.sourceUncertain}
    end
    offset=offset+part.n
  end
  return result
end

-- A confirmed withdrawal releases exactly the tail of the original allocation.
function C.ReturnQuantity(p)
  if not p or not positive(p.quantity) or p.returnedUnits or p.ownedSold or p.remainderTo
      or (p.gross and not p.filled) or (p.soldAt and not (p.filled or p.remainingSeen)) then return end
  local sold=math.max(p.filled or 0,p.remainingSeen and p.quantity-p.remainingSeen or 0)
  if p.fillLimit and p.fillLimit~=sold then return end
  return p.quantity-sold
end

function C.CollectReturn(ch,p,n,reason,auctionID)
  if C.ReturnQuantity(p)~=n or not positive(n) then return end
  local sold=p.quantity-n
  -- Legacy full cancellations already released their balances at the end event.
  local released=p.ended and not p.awaitingReturn and sold==0
  if p.ended and p.ended~=reason then return end
  if not released then
    local lots=ch.craftLedger.lots
    local restores=slice(p.parts,sold,n)
    local units, credits=0, {}
    for _,part in ipairs(restores) do
      units=units+part.n
      if part.source then
        local x=lots[part.source]
        if not x then return end
        local credit=credits[part.source] or {n=0,cost=0}
        credit.n,credit.cost=credit.n+part.n,credit.cost+part.cost
        if x.left+credit.n>x.quantity or x.balance+credit.cost>x.cost then return end
        credits[part.source]=credit
      end
    end
    if units~=n then return end
    for _,part in ipairs(restores) do
      local x=lots[part.source]
      if x then
        if auctionID and x.quantity==1 and part.n==1 and x.left==0 then
          x.returnedFrom=auctionID
        end
        x.left,x.balance=x.left+part.n,x.balance+part.cost
      end
    end
  end
  p.ended,p.returnedUnits,p.fillLimit=reason,n,sold
  p.awaitingReturn,p.unresolved=nil,nil
  return true
end

function C.LinkRemainder(ch,oldID,newID)
  local posts=ch.craftLedger and ch.craftLedger.posts
  local old,new=posts and posts[oldID],posts and posts[newID]
  if not old or not new or old==new or not old.filled or not old.ended or old.remainderTo or old.returnedUnits
      or not new.parts or new.ended or new.at<old.at or new.filled
      or new.quantity~=old.quantity-old.filled or old.itemID~=new.itemID then return end
  -- Never displace another tracked purchase or craft.
  for _,part in ipairs(new.parts) do if part.source then return end end
  new.parts=slice(old.parts,old.filled,new.quantity)
  old.remainderTo=newID
  return true
end

-- Carry a reserved single craft across a linked cancel/repost. A confirmed
-- withdrawal already restored the lot and therefore uses the normal take path.
function C.LinkReservedCraft(ch,row)
  if not row.repostOf or row.quantity~=1 then return end
  local l=ch.craftLedger
  local old=l and l.posts[tostring(row.repostOf)]
  local new=l and l.posts[tostring(row.auctionID)]
  if not old or not new or old.itemID~=row.itemID or new.itemID~=row.itemID
      or old.quantity~=1 or new.quantity~=1 or not old.awaitingReturn or (old.ended~="canceled" and old.ended~="expired")
      or old.returnedUnits or old.remainderTo or old.filled or old.soldAt or old.gross
      or new.returnedUnits or new.remainderTo or #(old.parts or {})~=1 or #(new.parts or {})~=1 then return end
  local src,dst=old.parts[1],new.parts[1]
  local lot=l.lots[src.source]
  if not lot or not (lot.parts or (lot.purchase and not lot.looted and not lot.unknown and not lot.estimate))
      or lot.quantity~=1 or lot.left~=0 or lot.itemID~=row.itemID
      or src.sourceUncertain or src.n~=1 or src.cost~=lot.cost or dst.source or dst.n~=1 or dst.cost~=0 or not dst.unknown then return end
  local linked
  for _,r in ipairs(ch.ended or {}) do
    if r.auctionID==row.repostOf and r.repostedAs==row.auctionID and r.endedAt
        and new.at>=r.endedAt and new.at-r.endedAt<=120 and not r.returnCollectedAt then linked=true
    elseif r.itemID==row.itemID and r.quantity==1 and r.endedAt and math.abs(new.at-r.endedAt)<=120 then return end
  end
  if not linked then return end
  for key,p in pairs(l.posts) do
    if key~=tostring(row.repostOf) and key~=tostring(row.auctionID) and not p.returnedUnits then
      for _,part in ipairs(p.parts or {}) do if part.source==src.source then return end end
    end
  end
  new.parts,old.parts=old.parts,{}
  old.remainderTo=tostring(row.auctionID)
end

function C.Sale(ch,row)
  if not row.auctionID then return end
  C.Observe(ch,row)
  local l=ch.craftLedger
  local p=l and l.posts[tostring(row.auctionID)]
  if p and not p.ended then
    p.soldAt=p.soldAt or row.soldAt or time()
    if not p.filled and row.receiptID and positive(row.verifiedGross) then
      p.gross=row.verifiedGross
      if type(row.verifiedCut)=="number" then p.cut=row.verifiedCut end
    end
  end
end
-- The saved full-stack sale and invoice were audited in both character saves.
function C.RepairDustReceipt(ch)
  local posts=ch.craftLedger and ch.craftLedger.posts
  local p=posts and posts["169517856"]
  if not p or p.itemID~=11176 or p.quantity~=2 or p.at~=1795334430 or p.soldAt~=1795334677
      or p.ended~="canceled" or p.gross or p.filled or p.fillLimit or p.remainingSeen or p.remainderTo then return end
  local sale,receipt,index
  for _,pool in ipairs({ch.sold,ch.active,ch.deleted,ch.ended}) do
    for i,r in ipairs(pool) do
      if r.auctionID==169517856 then
        if sale or pool~=ch.sold or not r.sold or r.receiptID or r.itemID~=11176 or r.quantity~=2
            or r.buyout~=4652 or r.soldAt~=p.soldAt or r.endTime~=1795338276 then return end
        sale=r
      elseif r.receiptID=="mail:73" then
        if receipt or pool~=ch.sold or not r.mailOnly or r.auctionID or not r.receiptQuantityKnown
            or r.receiptQty~=2 or r.observedAt~=1795338305 or r.verifiedGross~=4652
            or r.verifiedCut~=232 or r.verifiedDeposit~=1 or r.verifiedNet~=4421 then return end
        receipt,index=r,i
      end
    end
  end
  if not sale or not receipt or receipt.name~=sale.name then return end
  for _,other in pairs(posts) do
    if other.fills and other.fills["mail:73"] then return end
  end
  for _,k in ipairs({"receiptID","receiptQty","receiptQuantityKnown","observedAt","reconciledAt",
      "verifiedGross","verifiedCut","verifiedDeposit","verifiedNet","receiptBuyer"}) do sale[k]=receipt[k] end
  p.ended,p.ownedSold=nil,true
  C.Sale(ch,sale)
  table.remove(ch.sold,index)
  return true
end

-- Recover only the five bolts confirmed as consumed by this saved bag.
-- Keep the remaining three reserved against the original unresolved listing.
function C.RepairBagBolts(ch)
  local l=ch.craftLedger
  if not l or not l.posts then return end
  local old,post=l.posts["163770912"],l.posts["169450760"]
  if not old or not old.unresolved or old.ended or old.soldAt or old.filled or old.remainingSeen
      or old.fillLimit or old.gross or old.quantity~=8 or old.itemID~=14048 or #(old.parts or {})~=8
      or not post or post.itemID~=14046 or post.quantity~=1 or #(post.parts or {})~=1 then return end
  local bag=l.lots[post.parts[1].source]
  local cloth=l.lots[l.purchases["p:90"]]
  if not bag or bag.at~=1795333875 or bag.cost~=33634 or bag.left~=0 or bag.itemID~=14046
      or post.parts[1].cost~=bag.cost or not cloth or cloth.itemID~=14047 or cloth.quantity~=40
      or cloth.cost~=20644 or cloth.left~=0 or cloth.balance~=0 then return end
  local missing=bag.parts and bag.parts[1]
  if not missing or missing.itemID~=14048 or missing.n~=5 or missing.source or missing.cost~=0 then return end
  local seen,sum={},0
  for _,part in ipairs(old.parts) do
    local bolt=l.lots[part.source]
    local mat=bolt and bolt.parts and bolt.parts[1]
    if not mat or seen[part.source] or bolt.itemID~=14048 or bolt.quantity~=1 or bolt.left~=0
        or bolt.balance~=0 or part.n~=1 or part.cost~=bolt.cost or mat.source~=cloth.index
        or mat.n~=5 or mat.cost~=part.cost then return end
    seen[part.source]=true
    sum=sum+part.cost
  end
  if sum~=cloth.cost then return end
  table.remove(bag.parts,1)
  for i=1,5 do
    local part=table.remove(old.parts,1)
    table.insert(bag.parts,i,part)
    bag.cost=bag.cost+part.cost
  end
  post.parts[1].cost=bag.cost
  old.fillLimit=3
end

-- The owner confirmed the other three bolts from purchase 90 were sold together.
function C.RepairSoldBolts(ch)
  local l=ch.craftLedger
  if not l then return end
  local old,new,bagPost=l.posts["163770912"],l.posts["173765261"],l.posts["169450760"]
  if not old or not new or not bagPost or old.fillLimit~=3 or not old.unresolved
      or old.filled or old.gross or old.returnedUnits or old.remainderTo or old.ended
      or old.itemID~=14048 or #(old.parts or {})~=3 or new.itemID~=14048
      or new.quantity~=3 or new.totalPrice~=3100 or new.soldAt~=1795369753
      or new.returnedUnits or new.remainderTo or #(new.parts or {})~=1 then return end
  local missing=new.parts[1]
  if missing.source or not missing.unknown or missing.n~=3 or missing.cost~=0 then return end
  local cloth=l.lots[l.purchases["p:90"]]
  local bag=bagPost.parts and bagPost.parts[1] and l.lots[bagPost.parts[1].source]
  if not cloth or cloth.itemID~=14047 or cloth.quantity~=40 or cloth.cost~=20644
      or not bag or bag.itemID~=14046 or bag.cost~=46535 then return end
  local seen,units,total={},0,0
  for _,parts in ipairs({bag.parts or {},old.parts}) do
    for _,part in ipairs(parts) do
      local bolt=l.lots[part.source]
      if bolt and bolt.itemID==14048 then
        local mat=bolt.parts and bolt.parts[1]
        if seen[part.source] or not mat or mat.source~=cloth.index or mat.n~=5
            or part.n~=1 or bolt.quantity~=1 or bolt.left~=0 or part.cost~=mat.cost then return end
        seen[part.source]=true
        units,total=units+1,total+part.cost
      elseif parts==old.parts then return end
    end
  end
  if units~=8 or total~=cloth.cost then return end
  new.parts,old.parts=old.parts,{}
  old.remainderTo="173765261"
end

-- Owner-confirmed raw loot sales. The paid units previously reserved by
-- these posts were cooked; releasing them would recreate spent stock.
function C.RepairCookedInputs(ch)
  local l=ch.craftLedger
  if not l then return end
  local function repair(key,id,source,purchase,units,cost,loot)
    local p=l.posts[key]
    local x=l.lots[source]
    if not p or p.itemID~=id or p.returnedUnits or p.remainderTo or not p.soldAt
        or not x or x.purchase~=purchase or x.itemID~=id or not p.parts then return end
    local part=p.parts[1]
    if not part or part.source~=source or part.n~=units or part.cost~=cost then return end
    local replacements={}
    for _,index in ipairs(loot) do
      local v=l.lots[index]
      if not v or not v.looted or v.itemID~=id or v.at>p.at or v.left<1 or v.balance~=0 then return end
      replacements[#replacements+1]={source=index,itemID=id,n=1,cost=0}
    end
    table.remove(p.parts,1)
    for i,v in ipairs(replacements) do
      l.lots[v.source].left=l.lots[v.source].left-1
      table.insert(p.parts,i,v)
    end
  end
  repair("176630460",4603,331,81,1,76,{522})
  repair("176624579",7974,98,18,3,324,{524,532,533})
end

-- Owner-confirmed seven-bolt return. Validate the full purchase and both uses
-- before releasing the old reservation or changing a posted craft's cost.
function C.RepairMageweaveReturn(ch)
  local l=ch.craftLedger
  if not l then return end
  local old,bagPost=l.posts["176764486"],l.posts["176789179"]
  if not old or not old.unresolved or old.ended or old.soldAt or old.returnedUnits
      or old.filled or old.gross or old.quantity~=7 or old.itemID~=4339 or #(old.parts or {})~=7
      or not bagPost or #(bagPost.parts or {})~=1 then return end
  local bag=l.lots[bagPost.parts[1].source]
  local cloth=l.lots[612]
  if not bag or bag.itemID~=254035 or bag.at~=1795384371 or bag.cost~=15423 or bag.left~=0
      or bagPost.parts[1].cost~=bag.cost or not cloth or cloth.itemID~=4338 or cloth.cost~=13965
      or cloth.quantity~=35 or cloth.left~=5 or cloth.balance~=1995 then return end
  local missing=bag.parts and bag.parts[1]
  if not missing or missing.source or missing.itemID~=4339 or missing.n~=4 or missing.cost~=0 then return end
  local target
  for _,p in pairs(l.posts) do
    if p.itemID==4339 and p.at>old.at then
      local v=p.parts and p.parts[1]
      if target or p.quantity~=3 or #(p.parts or {})~=1 or not v or v.source or v.cost~=0
          or v.n~=3 or p.returnedUnits or p.remainderTo then return end
      target=p
    end
  end
  for i,v in ipairs(old.parts) do
    local x=l.lots[v.source]
    if v.source~=612+i or v.n~=1 or not x or x.itemID~=4339 or x.left~=0 or x.balance~=0
        or x.quantity~=1 or x.cost~=v.cost then return end
    if i~=2 and (x.cost~=1995 or #x.parts~=1 or x.parts[1].source~=612 or x.parts[1].n~=5) then return end
  end
  local bolt=l.lots[614]
  if bolt.cost~=0 or #bolt.parts~=2 then return end
  for i,v in ipairs(bolt.parts) do
    local x=l.lots[v.source]
    if not x or not x.looted or x.itemID~=4338 or v.cost~=0 or v.source~=(i==1 and 587 or 604)
        or v.n~=(i==1 and 2 or 3) or x.left+v.n>x.quantity then return end
  end
  local ended
  for _,r in ipairs(ch.ended or {}) do if r.auctionID==176764486 then ended=r end end
  if not ended or ended.endedReason~="unconfirmed" or ended.returnCollectedAt then return end
  for _,v in ipairs(bolt.parts) do local x=l.lots[v.source];x.left=x.left+v.n end
  cloth.left,cloth.balance=0,0
  bolt.parts={{source=612,itemID=4338,n=5,cost=1995}}
  bolt.cost,old.parts[2].cost=1995,1995
  table.remove(bag.parts,1)
  for i,v in ipairs(old.parts) do
    if i<=4 then table.insert(bag.parts,i,v)
    elseif not target then
      local x=l.lots[v.source]
      x.left,x.balance,x.returnedFrom=1,v.cost,176764486
    end
  end
  if target then target.parts=slice(old.parts,4,3) end
  bag.cost=bag.cost+7980
  bagPost.parts[1].cost=bag.cost
  old.ended,old.returnedUnits,old.fillLimit,old.unresolved="canceled",7,0,nil
  ended.endedReason="canceled"
  ended.returnCollectedAt=bag.at -- Latest known time the confirmed return was in hand.
end

-- Historical migration for a confirmed return and repost of vendor purchase 50.
function C.RepairFormulaRepost(ch)
  local l=ch.craftLedger
  if not l then return end
  local old=l.posts["159338015"]
  local new=l.posts["165294009"]
  if not (old and old.unresolved and not old.ended and not old.soldAt and not old.filled
      and new and new.ownedSold and new.soldAt==1795314937 and not new.ended and not new.filled
      and old.parts and #old.parts==1 and new.parts and #new.parts==1) then return end
  local src,dst=old.parts[1],new.parts[1]
  local lot=l.lots[src.source]
  if not (src.n==1 and src.cost==9500 and lot and lot.purchase==50 and lot.vendor
      and lot.itemID==20754 and lot.quantity==1 and lot.left==0 and lot.balance==0
      and dst.itemID==20754 and dst.n==1 and dst.cost==0 and not dst.source) then return end
  local ended,sale,receipt,index
  for _,pool in ipairs({ch.ended,ch.sold,ch.deleted,ch.active}) do
    for i,r in ipairs(pool) do
      if r.auctionID==159338015 then
        if ended or pool~=ch.ended or r.endedReason~="unconfirmed" or r.repostedAs then return end
        ended=r
      elseif r.auctionID==165294009 then
        if sale or pool~=ch.sold or not r.sold or r.itemID~=20754 or r.buyout~=19900
            or r.quantity~=1 or r.repostOf then return end
        sale=r
      end
      if r.receiptID=="mail:66" then
        if receipt or pool~=ch.sold or (r.auctionID and r.auctionID~=165294009) then return end
        receipt,index=r,i
      end
    end
  end
  if not (ended and sale and receipt and (not sale.receiptID or sale==receipt)
      and receipt.name==sale.name and receipt.receiptQty==1 and receipt.observedAt==1795320501
      and receipt.verifiedGross==19900 and receipt.verifiedCut==995
      and receipt.verifiedNet==19405 and receipt.verifiedDeposit==500) then return end
  for _,p in pairs(l.posts) do
    if p.fills and p.fills["mail:66"] then return end
    if p~=old and not p.ended then
      for _,part in ipairs(p.parts or {}) do if part.source==src.source then return end end
    end
  end
  if receipt~=sale then
    for _,k in ipairs({"receiptID","receiptQty","receiptQuantityKnown","observedAt","reconciledAt",
        "verifiedGross","verifiedCut","verifiedDeposit","verifiedNet","receiptBuyer"}) do sale[k]=receipt[k] end
    table.remove(ch.sold,index)
  end
  new.parts,old.parts=old.parts,{}
  old.ended,old.unresolved="reposted",nil
  ended.repostedAs,sale.repostOf=sale.auctionID,ended.auctionID
  C.Sale(ch,sale)
  return true
end

local function stamp(t) return date("%b %d %I:%M %p",t) end
local function amount(n) return n==0 and "0c" or AP.Money(n) end
local function label(x)
  if x.unknown and x.cost==0 then return "Unknown" end
  return (x.estimate and "~" or "")..amount(x.cost)..(x.unknown and " + unknown" or "")
end
local function profitText(net,cost)
  if type(net)~="number" then return "Pending" end
  if not cost or cost.unknown then return "Cost unknown" end
  local profit=net-cost.cost
  return (cost.estimate and "~" or "")..(profit<0 and "-" or profit>0 and "+" or "")..amount(math.abs(profit))
end
local function allocated(total,start,count,quantity)
  return math.floor(total*(start+count)/quantity)-math.floor(total*start/quantity)
end
-- Read-only recovery for the player's confirmed 21-unit repost. The original
-- invoices remain in History. All cost comes from the unsold end of the old lot.
local function recoveredRedgill(ch)
  local l=ch.craftLedger
  local old=l.posts["154167863"]
  local new=l.posts["157997617"]
  if not (old and old.quantity==40 and old.remainingSeen==21 and not old.gross and not old.filled
      and not old.remainderTo and new and new.itemID==13930 and new.quantity==21 and new.totalPrice==22
      and new.at==1795276660 and new.soldAt and not new.gross and not new.filled and new.parts and
      #new.parts==1 and not new.parts[1].source and new.parts[1].n==21) then return end
  local wanted={["mail:44"]={11,242,12},["mail:45"]={10,220,11}}
  local receipts,seen={},{}
  for _,bucket in ipairs({ch.sold,ch.deleted or {}}) do
    for _,r in ipairs(bucket) do
      local w=wanted[r.receiptID]
      if w then
        if seen[r.receiptID] or bucket~=ch.sold or r.auctionID or not r.mailOnly or not r.receiptQuantityKnown
            or r.name~="Filet of Redgill" or r.reconciledAt~=1795280640 or r.receiptQty~=w[1]
            or r.verifiedGross~=w[2] or r.verifiedCut~=w[3] then return end
        seen[r.receiptID]=true
        receipts[#receipts+1]=r.receiptID
      end
    end
  end
  if #receipts~=2 then return end
  local parts=slice(old.parts,19,21)
  local sources={}
  if #parts~=21 then return end
  for _,p in ipairs(parts) do
    local lot=l.lots[p.source]
    if not lot or not lot.parts or lot.left~=0 or lot.quantity~=1 or lot.itemID~=13930
        or p.n~=1 or p.cost~=9 or sources[p.source] then return end
    sources[p.source]=true
  end
  for _,post in pairs(l.posts) do
    if post.fills and (post.fills["mail:44"] or post.fills["mail:45"]) then return end
    if post~=old then
      for _,part in ipairs(post.parts or {}) do if sources[part.source] then return end end
    end
  end
  return parts,receipts
end

-- The AH retained a 40-unit sale under this ID, but the seller invoice
-- covers the whole 60-unit craft allocation. Keep the original AH evidence.
local function redgillBatchInvoice(ch,p,sale)
  if not (sale and sale.sold and sale.itemID==13930 and sale.quantity==40 and sale.buyout==600
      and not sale.receiptID and p.at==1795284879 and p.quantity==60 and p.totalPrice==15
      and p.itemID==13930 and p.ended=="canceled" and not p.remainderTo and not p.remainingSeen
      and not p.gross and not p.filled and p.parts and #p.parts==60) then return end
  local lots=ch.craftLedger.lots
  local used={}
  for _,part in ipairs(p.parts) do
    local lot=lots[part.source]
    local mat=lot and lot.parts and lot.parts[1]
    local raw=mat and lots[mat.source]
    if not (raw and raw.purchase==54 and raw.itemID==13758 and mat.n==1 and mat.cost==5
        and lot.itemID==13930 and lot.left==0 and part.n==1 and part.cost==5
        and not used[part.source]) then return end
    used[part.source]=true
  end
  local receipt
  for _,pool in ipairs({ch.sold,ch.deleted or {}}) do
    for _,r in ipairs(pool) do
      if r.receiptID=="mail:54" then
        if receipt or pool~=ch.sold or not r.mailOnly or r.auctionID or r.name~=sale.name
            or r.observedAt~=1795290198 or not r.receiptQuantityKnown or r.receiptQty~=60
            or r.verifiedGross~=900 or r.verifiedCut~=45 or r.verifiedDeposit~=60
            or r.verifiedNet~=915 then return end
        receipt=r
      end
    end
  end
  if not receipt then return end
  for _,other in pairs(ch.craftLedger.posts) do
    if other.fills and other.fills[receipt.receiptID] then return end
    if other~=p then
      for _,part in ipairs(other.parts or {}) do if used[part.source] then return end end
    end
  end
  return receipt
end

local function reconcileRedgillRows(ch,flips)
  local targets={}
  for _,row in ipairs(flips) do
    if row.itemID==13930 then targets[tostring(row.auctionID)]=row end
  end
  local original=targets["154167863"]
  local other=targets["154303612"]
  local repost=targets["157997617"]
  if original and repost and repost.recoveredReceipts then
    original.repostNote="Remaining 21 reposted as auction #157997617 (21 sold)."
    repost.repostNote="These 21 came from the original 40 on auction #154167863."
  end
  if not (original and other and original.quantity==19 and other.quantity==25
      and not original.net and not other.net) then return end
  local invoice
  for _,pool in ipairs({ch.sold,ch.deleted or {}}) do
    for _,r in ipairs(pool) do
      if r.receiptID=="mail:27" or (r.mailOnly and r.name=="Filet of Redgill" and r.receiptQty==44) then
        if invoice or pool~=ch.sold or r.receiptID~="mail:27" or r.name~="Filet of Redgill"
            or not r.mailOnly or r.auctionID or r.receiptQty~=44 or r.reconciledAt~=1795247287
            or r.verifiedGross~=1056 or r.verifiedCut~=52 then return end
        invoice=r
      end
    end
  end
  if not invoice then return end
  for _,post in pairs(ch.craftLedger.posts) do
    if post.fills and post.fills[invoice.receiptID] then return end
  end
  local net=invoice.verifiedGross-invoice.verifiedCut
  other.net=allocated(net,0,other.quantity,invoice.receiptQty)
  original.net=net-other.net
  for _,row in ipairs({original,other}) do
    row.pooledReceipt=invoice
    row.events[1].gross=row.quantity*24
    row.profitText=profitText(row.net,row.soldCost)
  end
end

-- Read-only attribution for the reported overnight repost. Withdraw the
-- estimate if the old post, its invoice, or its purchase allocation changes.
local function overnightFormulaCost(ch,sale)
  if sale.auctionID~=173156714 or sale.receiptID~="mail:87" or sale.verifiedGross~=19800
      or sale.itemID~=20754 then return end
  local l=ch.craftLedger
  local old=l.posts["168468911"]
  local part=old and old.parts and old.parts[1]
  local lot=part and l.lots[part.source]
  if not lot or #old.parts~=1 or not old.unresolved or old.soldAt or old.ended or old.gross
      or old.filled or old.returnedUnits or old.remainderTo or part.n~=1 or lot.left~=0
      or not lot.vendor or lot.purchase~=44 or lot.itemID~=20754 or lot.cost~=9500
      or part.cost~=lot.cost or lot.quantity~=1 then return end
  for _,other in pairs(l.posts) do
    if other~=old and (not other.ended or other.gross or other.soldAt) then
      for _,allocation in ipairs(other.parts or {}) do
        if allocation.source==part.source then return end
      end
    end
  end
  for _,r in ipairs(ch.ended or {}) do
    if r.auctionID==168468911 and r.endedReason=="unconfirmed" and not r.repostedAs
        and r.endTime and r.endedAt and r.endTime<=r.endedAt and sale.firstSeenAt and r.endedAt<=sale.firstSeenAt then
      return part.cost
    end
  end
end

-- Follow reciprocal repost links only. References are display-only because
-- the client can infer a repost even when it missed the physical return.
local function repostSource(ch,sale,endedByID)
  local l=ch.craftLedger
  local row=sale
  local visited={}
  while row.repostOf do
    local id=tostring(row.repostOf)
    if visited[id] then return end
    visited[id]=true
    local prior=endedByID[id]
    if not prior or prior.repostedAs~=row.auctionID or prior.itemID~=sale.itemID
        or prior.quantity~=1 or prior.itemSuffix~=sale.itemSuffix or prior.itemLevel~=sale.itemLevel
        or not prior.endedAt or not row.firstSeenAt or prior.endedAt>row.firstSeenAt
        or row.firstSeenAt-prior.endedAt>7*86400 then return end
    local post=l.posts[id]
    if not post or post.quantity~=1 or post.soldAt or post.gross or post.filled or post.remainderTo
        or not post.parts or #post.parts~=1 then return end
    local part=post.parts[1]
    if part.source then
      local lot=l.lots[part.source]
      if not lot or not lot.purchase or lot.quantity~=1 or lot.left~=0 or lot.balance~=0
          or lot.itemID~=sale.itemID or lot.estimate or lot.unknown or part.cost~=lot.cost
          or part.n~=1 or not positive(part.cost) then return end
      for key,other in pairs(l.posts) do
        if key~=id and (not other.ended or other.soldAt or other.gross) then
          for _,a in ipairs(other.parts or {}) do if a.source==part.source then return end end
        end
      end
      for _,batch in ipairs(l.lots) do
        for _,a in ipairs(batch.parts or {}) do if a.source==part.source then return end end
      end
      return part.cost,"Estimated from purchase #"..lot.purchase.." on original auction #"..id.."."
    end
    row=prior
  end
end

-- Identical vendor copies can have a provable common price without an exact
-- predecessor ID. Require one reserved purchase per outstanding unknown copy.
local function commonVendorCost(ch,sale)
  local ledger=ch.craftLedger
  local price,lastBuy,unknown,reserved=nil,0,0,0
  local sources,owners,history={},{},{}
  for i,lot in ipairs(ledger.lots) do
    if lot.itemID==sale.itemID then
      if not lot.vendor or not lot.purchase or lot.quantity~=1 or lot.left~=0 or lot.balance~=0
          or lot.parts or lot.looted or lot.estimate or lot.unknown or lot.sourceUncertain
          or not positive(lot.cost) or (price and lot.cost~=price) then return end
      price=lot.cost
      sources[i]=true
      lastBuy=math.max(lastBuy,lot.at)
    end
  end
  if not price then return end
  for _,lot in ipairs(ledger.lots) do
    for _,v in ipairs(lot.parts or {}) do if sources[v.source] then return end end
  end
  for _,r in ipairs(ch.deTests or {}) do if r.input==sale.itemID then return end end
  for _,bucket in ipairs({"sold","active","ended","deleted"}) do
    for _,r in ipairs(ch[bucket] or {}) do
      if r.itemID==sale.itemID or r.name==sale.name then
        local id=tostring(r.auctionID)
        local p=ledger.posts[id]
        if not p or history[id] or bucket=="deleted" or r.itemID~=sale.itemID
            or r.quantity~=1 or r.itemLevel~=sale.itemLevel or r.itemSuffix~=sale.itemSuffix
            or not p.parts or #p.parts~=1 or p.quantity~=1 or p.itemID~=sale.itemID then return end
        history[id]=true
        local part=p.parts[1]
        if part.source then
          if not sources[part.source] or part.cost~=price or part.n~=1 or part.sourceUncertain then return end
          if bucket=="sold" or bucket=="active" or (p.unresolved and not p.ended) then
            if owners[part.source] then return end
            owners[part.source]=true
            if bucket=="ended" then
              if p.gross or p.filled or p.soldAt or p.returnedUnits or p.remainderTo then return end
              reserved=reserved+1
            end
          elseif not p.returnedUnits then
            -- Legacy returns may lack a withdrawal marker. Accept only if
            -- their source was subsequently allocated to a different post.
            if not p.ended or p.awaitingReturn then return end
          end
        elseif bucket~="ended" then
          if not part.unknown or part.n~=1 or p.at<lastBuy then return end
          unknown=unknown+1
        elseif not p.ended or p.soldAt or p.gross then return end
      end
    end
  end
  for id,p in pairs(ledger.posts) do if p.itemID==sale.itemID and not history[id] then return end end
  for source in pairs(sources) do if not owners[source] then return end end
  if reserved==unknown and unknown>0 then
    return price,"Estimated from equal-price vendor copies. Exact repost source unresolved."
  end
end

-- Display a possible craft source for a sale whose listing was never observed.
-- Never assign its reserved lot or settle an invoice using just the item name.
local function sparseRepost(ch,l,sale,p)
  if not sale or not sale.sold or not sale.name or sale.itemID or sale.receiptID
      or not sale.soldAt or not p.at or p.itemID or p.parts or p.returnedUnits
      or p.remainderTo or not p.awaitingReturn then return end
  local candidate
  for _,old in ipairs(ch.ended or {}) do
    if old.name==sale.name and old.auctionID and old.endedAt and not old.repostedAs
        and old.endedAt<=p.at and p.at-old.endedAt<=120 then
      if candidate then return end
      candidate=old
    end
  end
  if not candidate or candidate.quantity~=1 or candidate.returnCollectedAt then return end
  local prior=l.posts[tostring(candidate.auctionID)]
  if not prior or not prior.awaitingReturn or prior.returnedUnits or prior.remainderTo
      or prior.filled or prior.soldAt or prior.gross or #(prior.parts or {})~=1 then return end
  local part=prior.parts[1]
  local lot=l.lots[part.source]
  if not lot or not lot.parts or lot.itemID~=candidate.itemID or lot.quantity~=1
      or lot.left~=0 or part.n~=1 or part.cost~=lot.cost then return end
  for _,other in ipairs(ch.sold or {}) do
    local q=l.posts[tostring(other.auctionID)]
    if q and q~=p and not q.itemID and other.name==sale.name and q.at
        and q.at>=candidate.endedAt and q.at-candidate.endedAt<=120 then return end
  end
  return {sold=true,soldAt=sale.soldAt,auctionID=sale.auctionID,name=sale.name,
    possibleSource=candidate.auctionID,quantity=1,profitText="Possible repost",soldCost={unknown=true,cost=0,
      note="Possible crafted repost of #"..candidate.auctionID..". Cost and receipt unconfirmed."}}
end

-- A player can identify an earlier craft even when the server assigned a new ID.
-- Return only whole, reserved craft lots with no sale, return or other claimant.
function C.CostSources(ch,id)
  local l=ch.craftLedger
  local p=l and l.posts[tostring(id)]
  local result={}
  if not p or not p.at or p.returnedUnits or p.remainderTo or p.filled or p.remainingSeen
      or (p.quantity and p.quantity~=1) then return result end
  if p.parts and not (#p.parts==1 and p.parts[1].unknown and not p.parts[1].source
      and p.parts[1].cost==0 and p.parts[1].n==1) then return result end
  local sale
  for _,r in ipairs(ch.sold or {}) do
    if id and tostring(r.auctionID)==tostring(id) then
      if sale or not r.sold or r.repostedAs or r.returnCollectedAt or r.cancelRequestedAt
          or (r.quantity and r.quantity~=1) then return result end
      sale=r
    end
  end
  if not sale then return result end
  for _,old in ipairs(ch.ended or {}) do
    local src=l.posts[tostring(old.auctionID)]
    local part=src and src.parts and src.parts[1]
    local lot=part and l.lots[part.source]
    local pinned=sale.manualReceiptSource or sale.repostOf
    if old.auctionID and tostring(old.auctionID)~=tostring(id)
        and (not pinned or tostring(old.auctionID)==tostring(pinned))
        and old.name==sale.name and (sale.itemID or pinned)
        and (not sale.itemID or (sale.itemID==old.itemID and
          (sale.itemSuffix or 0)==(old.itemSuffix or 0)))
        and (not p.itemID or p.itemID==old.itemID)
        and old.quantity==1 and old.endedAt and old.endedAt<=p.at and not old.returnCollectedAt
        and (not old.repostedAs or tostring(old.repostedAs)==tostring(id))
        and src and src.quantity==1 and src.itemID==old.itemID and src.awaitingReturn
        and (src.ended=="expired" or src.ended=="canceled") and not
          (src.returnedUnits or src.remainderTo or src.filled or src.remainingSeen or src.soldAt or src.gross)
        and #src.parts==1 and lot and lot.parts and lot.quantity==1 and lot.left==0
        and lot.itemID==src.itemID and part.n==1 and part.cost==lot.cost then
      local claimed=false
      for _,pool in ipairs({ch.sold,ch.active,ch.deleted}) do
        for _,r in ipairs(pool or {}) do
          if tostring(r.auctionID)==tostring(old.auctionID)
              or (r.repostOf==old.auctionID and tostring(r.auctionID)~=tostring(id)) then claimed=true end
        end
      end
      if not claimed then result[#result+1]={old=old,cost=lot.cost,lot=lot} end
    end
  end
  return result,sale
end

function C.ConfirmCostSource(ch,id,oldID)
  local choices,sale=C.CostSources(ch,id)
  for _,choice in ipairs(choices) do
    local old=choice.old
    if tostring(old.auctionID)==tostring(oldID) then
      local posts=ch.craftLedger.posts
      local src,p=posts[tostring(oldID)],posts[tostring(id)]
      p.parts,src.parts=src.parts,{}
      p.itemID,p.quantity,p.ended,p.awaitingReturn=old.itemID,1,nil,nil
      p.soldAt,p.ownedSold=sale.soldAt,true
      src.remainderTo=tostring(id)
      sale.itemID,sale.quantity,sale.repostOf=old.itemID,1,old.auctionID
      sale.itemSuffix,sale.itemLevel=old.itemSuffix,old.itemLevel
      sale.repostCount=(old.repostCount or 0)+1
      old.repostedAs=sale.auctionID
      C.Sale(ch,sale)
      return sale
    end
  end
end

-- Match a single sold copy to one recorded purchase. A reserved purchase
-- can move only when all its prior listings ended before this copy was posted.
function C.PurchaseSources(ch,id)
  local l=ch.craftLedger
  local p=l and l.posts[tostring(id)]
  local result={}
  if not p or not p.at or not p.soldAt or p.quantity~=1 or p.ended or p.filled
      or p.returnedUnits or p.remainderTo or not p.itemID then return result end
  local missing=p.parts and p.parts[1]
  if not missing or #p.parts~=1 or missing.source or not missing.unknown
      or missing.cost~=0 or missing.n~=1 then return result end
  local sale
  for _,r in ipairs(ch.sold or {}) do
    if tostring(r.auctionID)==tostring(id) then
      if sale or not r.sold or r.quantity~=1 or r.itemID~=p.itemID then return result end
      sale=r
    end
  end
  if not sale then return result end
  local ended,blocked={},{}
  for _,r in ipairs(ch.ended or {}) do ended[tostring(r.auctionID)]=r end
  for _,pool in ipairs({ch.active,ch.sold,ch.deleted}) do
    for _,r in ipairs(pool or {}) do blocked[tostring(r.auctionID)]=true end
  end
  local function chainAvailable(old)
    local visited={}
    while old.repostedAs and tostring(old.repostedAs)~=tostring(id) do
      local key=tostring(old.repostedAs)
      if visited[key] or blocked[key] then return false end
      visited[key]=true
      local nextRow,nextPost=ended[key],l.posts[key]
      if not nextRow or not nextPost or nextRow.itemID~=p.itemID or nextRow.quantity~=1
          or (nextRow.itemSuffix or 0)~=(sale.itemSuffix or 0)
          or tostring(nextRow.repostOf)~=tostring(old.auctionID)
          or not nextRow.endedAt or nextRow.endedAt>p.at or nextRow.returnCollectedAt
          or nextPost.soldAt or nextPost.gross or nextPost.filled or nextPost.returnedUnits
          or nextPost.remainderTo then return false end
      for _,part in ipairs(nextPost.parts or {}) do if part.source then return false end end
      old=nextRow
    end
    return true
  end
  local owners,used={},{}
  for k,post in pairs(l.posts) do
    for _,a in ipairs(post.parts or {}) do
      if a.source and a.itemID==p.itemID then
        local old=ended[k]
        if #post.parts~=1 or blocked[k] or post.soldAt or post.filled or post.gross or not old
            or old.itemID~=p.itemID or (old.itemSuffix or 0)~=(sale.itemSuffix or 0)
            or not old.endedAt or old.endedAt>p.at or a.n~=1 then used[a.source]=true
        elseif not (post.returnedUnits or post.remainderTo or old.returnCollectedAt)
            and (post.awaitingReturn or post.unresolved) then
          if owners[a.source] or not chainAvailable(old)
              then used[a.source]=true else owners[a.source]=k end
        end
      end
    end
  end
  for _,batch in ipairs(l.lots) do
    for _,a in ipairs(batch.parts or {}) do if a.source then used[a.source]=true end end
  end
  for _,buy in ipairs(ch.buys or {}) do
    local index=buy.purchaseID and l.purchases["p:"..buy.purchaseID]
    local x=index and l.lots[index]
    if x and x.purchase==buy.purchaseID and x.itemID==p.itemID and buy.itemID==p.itemID
        and (buy.itemSuffix or 0)==(sale.itemSuffix or 0)
        and x.quantity==1 and buy.quantity==1 and not used[index]
        and not (x.parts or x.looted or x.estimate or x.unknown or buy.priceEstimated)
        and positive(buy.price) and x.cost==buy.price and buy.boughtAt and buy.boughtAt<=p.at
        and ((x.left==1 and x.balance==x.cost and not owners[index])
          or (x.left==0 and x.balance==0 and owners[index])) then
      result[#result+1]={buy=buy,lot=x,owner=owners[index],cost=x.cost}
      used[index]=true
    end
  end
  return result,sale
end

function C.ConfirmPurchase(ch,id,purchase)
  local choices,sale=C.PurchaseSources(ch,id)
  for _,choice in ipairs(choices) do
    if choice.buy.purchaseID==purchase then
      local posts=ch.craftLedger.posts
      local p,x=posts[tostring(id)],choice.lot
      if choice.owner then
        local old=posts[choice.owner]
        old.parts,old.remainderTo={},tostring(id)
      else
        x.left,x.balance=0,0
      end
      p.parts={{source=x.index,itemID=x.itemID,n=1,cost=x.cost}}
      p.confirmedPurchase=purchase
      return sale
    end
  end
end

-- Only the explicit match command may pair a sparse sale with a paid invoice.
function C.ManualReceiptSource(ch,target,receipt)
  local l=ch.craftLedger
  local p=l and l.posts[tostring(target.auctionID)]
  if not p or p.gross or p.filled or p.fills or target.cancelRequestedAt
      or target.returnCollectedAt or target.repostedAs or target.buyout or target.bid
      or (target.quantity and target.quantity~=1) or receipt.name~=target.name
      or not receipt.receiptQuantityKnown or receipt.receiptQty~=1
      or not positive(receipt.verifiedGross) or type(receipt.verifiedCut)~="number"
      or receipt.verifiedCut<0 or receipt.verifiedCut>receipt.verifiedGross
      or type(receipt.verifiedNet)~="number" or not receipt.observedAt
      or not target.soldAt or receipt.observedAt<target.soldAt then return end
  local possible=sparseRepost(ch,l,target,p)
  return possible and possible.possibleSource
end

function C.Rows(ch,flips,sales)
  local l=ch.craftLedger
  local cuts={}
  for _,bucket in ipairs({ch.sold or {},ch.deleted or {}}) do
    for _,sale in ipairs(bucket) do
      if sale.auctionID and sale.receiptID and positive(sale.verifiedGross) and type(sale.verifiedCut)=="number" then
        cuts[tostring(sale.auctionID)]=sale
      end
    end
  end
  if not l then return end
  local visible={}
  for _,sale in ipairs(sales or ch.sold or {}) do
    if sale.auctionID then visible[tostring(sale.auctionID)]=sale end
  end
  local earliestVendorBuy, endedByID={}, nil
  for _,buy in ipairs(ch.buys or {}) do
    if buy.vendor and buy.itemID and buy.boughtAt and positive(buy.price) then
      earliestVendorBuy[buy.itemID]=math.min(earliestVendorBuy[buy.itemID] or buy.boughtAt,buy.boughtAt)
    end
  end
  for id,p in pairs(l.posts) do
    local receipt=cuts[id]
    local grossTotal=p.gross or (receipt and receipt.verifiedGross)
    local cut=p.cut or (receipt and receipt.verifiedGross==grossTotal and receipt.verifiedCut)
    local net=grossTotal and cut and cut>=0 and cut<=grossTotal and grossTotal-cut
    local purchaseCost={cost=0}
    local boughtUnits,boughtNet=0,0
    local crafted={}
    local craftCost={cost=0}
    local craftUnits,craftNet,craftGross=0,0,0
    local used=0
    local quantity=p.filled or (not p.fullStackObserved and not p.gross and p.remainingSeen and p.quantity-p.remainingSeen) or p.quantity
    local parts=(p.filled or p.remainingSeen) and slice(p.parts,0,quantity) or p.parts
    local recovered
    if id=="159333551" then
      local batch=redgillBatchInvoice(ch,p,visible[id])
      if batch then
        recovered={batch.receiptID}
        grossTotal=batch.verifiedGross
        net=grossTotal-batch.verifiedCut
      end
    end
    if id=="157997617" and visible[id] and visible[id].sold and not visible[id].receiptID then
      local verifiedParts,receipts=recoveredRedgill(ch)
      if verifiedParts then
        parts,recovered,quantity,grossTotal,net=verifiedParts,receipts,21,462,439
      end
    end
    for _,part in ipairs(parts or {}) do
      local x=l.lots[part.source]
      if x and x.parts then
        crafted[#crafted+1]={lot=x,n=part.n,cost=part.cost}
        craftUnits=craftUnits+part.n
        craftCost.cost=craftCost.cost+part.cost
        craftCost.unknown=craftCost.unknown or x.unknown
        craftCost.estimate=craftCost.estimate or x.estimate
        if net then craftNet=craftNet+allocated(net,used,part.n,quantity) end
        if grossTotal then craftGross=craftGross+allocated(grossTotal,used,part.n,quantity) end
      elseif x and not x.parts and not x.looted and not part.sourceUncertain then
        boughtUnits=boughtUnits+part.n
        purchaseCost.cost=purchaseCost.cost+part.cost
        purchaseCost.unknown=purchaseCost.unknown or part.unknown
        purchaseCost.estimate=purchaseCost.estimate or part.estimate
        if net then boughtNet=boughtNet+allocated(net,used,part.n,quantity) end
      end
      used=used+part.n
    end
    local sale=visible[id]
    local possible=sparseRepost(ch,l,sale,p)
    if sale and sale.manualReceiptSource and sale.receiptID and net and not parts then
      possible={sold=true,auctionID=sale.auctionID,soldAt=sale.soldAt,name=sale.name,
        quantity=sale.receiptQty,receiptID=sale.receiptID,net=net,profitText="Cost unknown",
        soldCost={cost=0,unknown=true,note="Receipt linked by you. Possible craft source #"
          ..sale.manualReceiptSource..". Material cost unconfirmed."}}
    end
    if possible then flips[#flips+1]=possible end
    if p.ended=="canceled" and not (receipt or p.filled or p.remainingSeen or recovered) then
      -- A full-stack owned sale can precede both a conflicting end event and its mail.
      -- Show its recorded cost provisionally without modifying receipt or return state.
      local fullSale=sale and sale.sold and not sale.mailOnly and not sale.cancelRequestedAt
        and not sale.returnCollectedAt and not sale.repostedAs and p.awaitingReturn
        and not (p.returnedUnits or p.remainderTo or p.fillLimit or p.gross)
        and p.itemID==sale.itemID and p.soldAt and p.soldAt==sale.soldAt
        and positive(p.quantity) and p.quantity>1 and p.quantity==sale.quantity
        and type(p.totalPrice)=="number" and p.totalPrice>0
        and p.totalPrice*p.quantity==sale.buyout and used==p.quantity
      if not fullSale and not ((p.reportedAllSold or p.fullStackObserved) and sale and sale.sold and not p.returnedUnits and not p.remainderTo) then sale=nil end
    end
    -- A paid, single-item listing can lose its source on an unobserved return.
    -- Keep the sale visible without spending a second copy from Buy History.
    if sale and ((sale.receiptID and net) or (sale.repostOf and p.ownedSold)) and quantity==1 and p.quantity==1 and p.soldAt
        and not p.ended and not p.filled and parts and #parts==1 and parts[1].unknown
        and parts[1].n==1 and not parts[1].source then
      if not endedByID then
        endedByID={}
        for _,row in ipairs(ch.ended or {}) do
          local key=tostring(row.auctionID)
          -- A duplicate ID cannot establish a unique predecessor.
          if endedByID[key]~=nil then endedByID[key]=false else endedByID[key]=row end
        end
      end
      local inferred,note=repostSource(ch,sale,endedByID)
      inferred=inferred or overnightFormulaCost(ch,sale)
      if not inferred and earliestVendorBuy[p.itemID] then inferred,note=commonVendorCost(ch,sale) end
      if not inferred then
        local choices=C.PurchaseSources(ch,id)
        local common=#choices>0 and choices[1].cost or nil
        for _,choice in ipairs(choices) do if choice.cost~=common then common=nil; break end end
        if common then
          inferred,note=common,"Estimated from eligible recorded purchases with equal cost; confirm source in inspector."
        end
      end
      if inferred or (earliestVendorBuy[p.itemID] and p.at and earliestVendorBuy[p.itemID]<=p.at) then
        boughtUnits,boughtNet=1,net
      end
      if inferred then
        purchaseCost.cost,purchaseCost.estimate=inferred,true
        purchaseCost.note=note or "Likely repost of #168468911. Vendor purchase #44 cost 95s. Return unconfirmed."
      else purchaseCost.unknown=true end
    end
    if sale and p.soldAt and boughtUnits>0 and used==quantity then
      local proceeds=net and boughtNet or nil
      local row={}
      for k,v in pairs(sale) do row[k]=v end
      row.quantity,row.soldCost,row.net=boughtUnits,purchaseCost,proceeds
      row.profitText=profitText(proceeds,purchaseCost)
      flips[#flips+1]=row
    end
    if sale and p.soldAt and craftUnits>0 then
      local first=crafted[1].lot
      local proceeds=net and craftNet
      flips[#flips+1]={craft=first,craftKey=id,auctionID=id,batches=crafted,itemID=first.itemID,
        name=itemName(first.itemID),quantity=craftUnits,stage=craftUnits.." sold of "..p.quantity.." posted",
        soldAt=p.soldAt,price=craftCost.cost,soldCost=craftCost,net=proceeds,
        profitText=profitText(proceeds,craftCost),
        recoveredReceipts=recovered,events={{id=id,p=p,n=craftUnits,gross=grossTotal and craftGross}}}
    end
  end
  reconcileRedgillRows(ch,flips)
  -- DE-output sales remain under DE Test until output inventory cost
  -- attribution is proven. Do not inject a candidate sale into Flip.
end
local function appendIngredients(out,source,p)
  local cumulative,paid=0,0
  for _,child in ipairs(source.parts) do
    cumulative=cumulative+child.cost
    local target=source.cost>0 and math.floor(cumulative*p.cost/source.cost+0.5) or 0
    out[#out+1]={itemID=child.itemID,source=child.source,
      n=child.n*p.n/source.quantity,cost=target-paid,
      unknown=child.unknown,estimate=child.estimate}
    paid=target
  end
end
local function materials(l,lines,expanded,parts,indent,path)
  local function line(t) lines[#lines+1]={detail=t} end
  local groups,order={},{}
  for _,p in ipairs(parts) do
    local id=p.itemID
    local group=groups[id]
    if not group then
      group={itemID=id,n=0,cost=0,entries={}}
      groups[id]=group
      order[#order+1]=group
    end
    group.n=group.n+p.n
    group.cost=group.cost+p.cost
    group.unknown=group.unknown or p.unknown
    group.estimate=group.estimate or p.estimate
    group.entries[#group.entries+1]=p
    local source=l.lots[p.source]
    if not source or (source.unknown and not source.parts) then
      group.unpriced=(group.unpriced or 0)+p.n
    end
    if source and source.parts then group.crafted=true
    elseif source and source.looted then group.looted=(group.looted or 0)+p.n
    elseif source then
      if source.vendor then group.vendor=true else group.ah=true end
      group.first=math.min(group.first or source.at,source.at)
      group.last=math.max(group.last or source.at,source.at)
    end
  end
  for _,g in ipairs(order) do
    local key=path.."/"..g.itemID
    local open=expanded and expanded[key]
    local qty=string.format("%.3f",g.n):gsub("0+$",""):gsub("%.$","")
    local text=qty.."x "..itemName(g.itemID).."   "..label(g)
    if g.unpriced then text=text..string.format("   %g unpriced (0c)",g.unpriced) end
    if g.looted then text=text..string.format("   %g looted (0c)",g.looted) end
    if g.crafted then
      line(indent..(open and "[-] " or "[+] ")..text)
      lines[#lines].materialKey=key
      if open then
        local children={}
        for _,p in ipairs(g.entries) do
          local source=l.lots[p.source]
          if source and source.parts then
            -- Allocate only this portion of a multi-output batch. Round
            -- cumulative copper shares so the displayed lines sum exactly.
            appendIngredients(children,source,p)
          else
            children[#children+1]=p
          end
        end
        materials(l,lines,expanded,children,indent.."    ",key)
      end
    else
      local origin=g.first and (g.first==g.last and "   bought "..stamp(g.first) or "   multiple purchases")
      local seller=g.vendor and (g.ah and " (vendor + AH)" or " (vendor)") or g.ah and " (AH)" or ""
      line(indent..text..(origin or "")..seller)
    end
  end
end
function C.ListedParts(ch,row)
  local l=ch.craftLedger
  local post=l and l.posts[tostring(row.auctionID)]
  if not post or not post.parts or not positive(row.quantity) or not positive(post.quantity) then return end
  local parts=slice(post.parts,math.max(0,post.quantity-row.quantity),row.quantity)
  for _,part in ipairs(parts) do
    local source=l.lots[part.source]
    if source and source.parts then return parts end
  end
end

function C.ListedDetails(ch,parts,expanded)
  local ingredients,lines={},{}
  local total={cost=0}
  local l=ch.craftLedger
  for _,part in ipairs(parts) do
    local source=l.lots[part.source]
    if source and source.parts then
      appendIngredients(ingredients,source,part)
      total.cost=total.cost+part.cost
      total.unknown=total.unknown or source.unknown
      total.estimate=total.estimate or source.estimate
    end
  end
  lines[1]={detail="Crafted material cost: "..label(total)}
  materials(l,lines,expanded,ingredients,"  ","listed")
  return lines
end

function C.Details(ch,row,expanded)
  local l=ch.craftLedger
  local lines={}
  local function line(t) lines[#lines+1]={detail=t} end
  line(row.stage.."   After AH cut: "..(row.net and amount(row.net) or "Pending receipt")..
    "   Sold material cost: "..label(row.soldCost).."   Profit: "..row.profitText)
  if row.repostNote then line(row.repostNote) end
  if row.pooledReceipt then line("After AH cut allocated by unit from shared 44-unit receipt "..row.pooledReceipt.receiptID..".") end
  for _,batch in ipairs(row.batches) do
    local x=batch.lot
    local key="batch/"..x.index
    local multiple=#row.batches>1
    local open=not multiple or (expanded and expanded[key])
    line((multiple and (open and "[-] " or "[+] ") or "").."Made "..x.quantity.."   "..stamp(x.at)..
      "   Batch material cost: "..label(x).."   Used in post: "..batch.n.." ("..
      label({cost=batch.cost,unknown=x.unknown,estimate=x.estimate})..")")
    if multiple then lines[#lines].materialKey=key end
    if open then materials(l,lines,expanded,x.parts,"  ",key) end
  end
  for _,e in ipairs(row.events) do
    line("Posted "..e.p.quantity.."   "..stamp(e.p.at).."   Auction #"..e.id)
    lines[#lines].inspectID=e.id
    lines[#lines].inspectSource=row
    if e.p.soldAt then line("Sold "..e.n.."   "..stamp(e.p.soldAt)..(e.gross and "   Gross "..amount(e.gross) or "   Awaiting verified price"))
    elseif e.p.ended then line("Listing "..e.p.ended)
    elseif e.p.unresolved then line("Outcome unknown; awaiting an identifiable sale or return.") end
  end
  return lines
end
C.CostLabel=label

-- This projection is rebuilt on demand; the receipt stays in sale history.
function C.ItemGroups(ch,flips,sales)
  local rows,groups,byAuction={},{},{}
  local posts=ch.craftLedger and ch.craftLedger.posts or {}
  local function key(row)
    return tostring(row.itemID or row.name)..":"..tostring(row.itemSuffix or 0)
  end
  local function addPost(g,id,n)
    if not g.posts[id] then
      g.posts[id]=true
      g.posted=g.posted+n
    end
  end
  for _,sale in ipairs(sales) do
    if sale.auctionID then byAuction[tostring(sale.auctionID)]=sale end
  end
  for _,row in ipairs(flips) do
    local id=tostring(row.auctionID)
    local sale=byAuction[id] or row
    local k=key(sale)
    local g=groups[k]
    if not g then
      g={members={},posts={},posted=0,listed=0,quantity=0,paidNet=0,paidCost={cost=0},pending=0,
        soldCost={cost=0},sold=true,itemID=row.itemID,name=sale.name or row.name,
        craftKey="group:"..k,soldAt=0}
      groups[k]=g
      rows[#rows+1]=g
    end
    if row.pooledReceipt then g.sharedReceipt=row.pooledReceipt end
    g.members[#g.members+1]=row
    addPost(g,id,(id=="157997617" and row.recoveredReceipts) and 0 or (posts[id] or {}).quantity or row.quantity)
    g.quantity=g.quantity+row.quantity
    g.soldAt=math.max(g.soldAt,row.soldAt or 0)
    g.soldCost.cost=g.soldCost.cost+row.soldCost.cost
    g.soldCost.unknown=g.soldCost.unknown or row.soldCost.unknown
    g.soldCost.estimate=g.soldCost.estimate or row.soldCost.estimate
    if row.net then
      g.paidNet=g.paidNet+row.net
      g.paidCost.cost=g.paidCost.cost+row.soldCost.cost
      g.paidCost.unknown=g.paidCost.unknown or row.soldCost.unknown
      g.paidCost.estimate=g.paidCost.estimate or row.soldCost.estimate
    else
      g.pending=g.pending+row.quantity
    end
  end
  for _,row in ipairs(ch.active or {}) do
    local g=groups[key(row)]
    if g then
      local id=tostring(row.auctionID)
      addPost(g,id,(posts[id] or {}).quantity or row.quantity)
      g.listed=g.listed+row.quantity
    end
  end
  for _,g in pairs(groups) do
    table.sort(g.members,function(a,b) return (a.soldAt or 0)>(b.soldAt or 0) end)
    g.net=g.pending==0 and g.paidNet or nil
    g.price=g.soldCost.cost
    g.profitText=profitText(g.net,g.soldCost)
    if g.pending>0 then
      g.partialProceeds="|cffffff00("..amount(g.paidNet)..")|r"
      g.partialProfit="|cffffff00("..profitText(g.paidNet,g.paidCost)..")|r"
    end
    g.unitsText=g.quantity.."/"..g.posted.." sold   "..g.listed.." listed"
  end
  return rows
end

function C.GroupDetails(ch,g)
  local lines={{detail=g.unitsText.."    Sold material cost: "..label(g.soldCost)}}
  for _,r in ipairs(g.members) do
    local post=ch.craftLedger.posts[tostring(r.auctionID)]
    if r.deAutoFlip then
      lines[#lines+1]={deAction="auto",deGuid=r.deGuid,deAuctionID=r.deAuctionID,deAutoDetail=r.deAutoDetail,
        detail="Auto DE | "..r.quantity.." sold | #"..r.auctionID.." | Cost: "..label(r.soldCost).." | P/L: "..r.profitText.." | Click to review"}
    else
    lines[#lines+1]={inspectID=r.auctionID,inspectSource=r,detail=r.quantity.." of "..post.quantity.." sold    Auction #"..r.auctionID..
      "    Cost: "..label(r.soldCost)..(r.net and "    After AH cut: "..amount(r.net) or "    Payment pending").."    "..stamp(r.soldAt)}
    end
  end
  if g.sharedReceipt then
    lines[#lines+1]={detail="Payment collected for 44    After AH cut: "..amount(1004).."    "..stamp(g.sharedReceipt.reconciledAt)}
  end
  if g.pending>0 then
    lines[#lines+1]={detail=g.pending.." sold units awaiting matched payment"}
  end
  return lines
end
