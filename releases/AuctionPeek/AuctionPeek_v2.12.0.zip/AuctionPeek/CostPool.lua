local _, AP = ...
local P={}
AP.CostPool=P

local function key(id,suffix)
  return tostring(id).."/"..tostring(suffix or 0)
end

-- Index references to the permanent, append-only ledger. Availability changes
-- in place as each owner reserves, consumes or returns a slice.
local pools=setmetatable({}, {__mode="k"})
function P.Lots(ledger,id,suffix)
  local pool=pools[ledger]
  if not pool or pool.size>#ledger.lots then
    pool={size=0,groups={}}
    pools[ledger]=pool
  end
  for i=pool.size+1,#ledger.lots do
    local x=ledger.lots[i]
    local k=key(x.itemID,x.itemSuffix)
    pool.groups[k]=pool.groups[k] or {}
    table.insert(pool.groups[k],x)
  end
  pool.size=#ledger.lots
  return pool.groups[key(id,suffix)] or {}
end

local function readable(v) return not issecretvalue or not issecretvalue(v) end
function P.BaseLevel(id)
  local get=C_Item and C_Item.GetItemInfo or GetItemInfo
  if not get then return end
  local ok,_,_,_,level=pcall(get,id)
  if ok and readable(level) and type(level)=="number" and level>0 then return level end
end

function P.Compatible(lot,level,base)
  local a=lot.itemLevel or 0
  local b=level or 0
  if a==b then return true end
  -- Legacy and fixed recipe lots may only know their base item ID.
  local implicit=base or P.BaseLevel(lot.itemID)
  return implicit and (a==0 and b==implicit or b==0 and a==implicit)
end

function P.Take(x,n,method,estimate)
  local cost=math.floor((x.balance-(x.bankedCopper or 0))*n/P.BagUnits(x))
  local part={source=x.index,itemID=x.itemID,n=n,cost=cost,unknown=x.unknown,
    estimate=x.estimate or x.sourceUncertain or x.inferredReturn or estimate,
    sourceUncertain=x.sourceUncertain,returnedFrom=x.returnedFrom,method=method}
  x.left,x.balance=x.left-n,x.balance-cost
  return part
end

function P.Eligible(l,x,at,level,base)
  return x.index and x.at and x.at<=at and P.BagUnits(x)>0 and x.left<=x.quantity
    and x.balance>=(x.bankedCopper or 0) and x.balance<=x.cost and not (l.quarantined and l.quarantined[x.index])
    and (not x.availableAt or x.availableAt<=at) and (not x.lastReturnedAt or x.lastReturnedAt<=at)
    and P.Compatible(x,level,base)
end

local function fifo(a,b)
  if a.at~=b.at then return a.at<b.at end
  return a.index<b.index
end

local function hole(a)
  return a and a.unknown and not a.source and a.cost==0
    and (a.reason=="UNKNOWN_ACQUISITION" or a.reason=="POSTING_EVENT_MISSING")
end

local function saleEvidence(p)
  return p.ownedSold or p.fullStackObserved or p.reportedAllSold or p.soldSnapshotUnits
    or p.soldAt or p.gross or p.filled or p.saleNoticeAt
end

-- A persisted pickup can predate the cost release. An old end event alone
-- can be stale, so there must be pickup evidence and no sale or live owner.
local function releaseStranded(ch,ended,blocked,unmatched,entries,observations,linkedOnly)
  local posts=ch.craftLedger.posts
  local count=0
  for id,r in pairs(ended) do
    local p=posts[id]
    local witness=observations[id]
    local at=r.returnCollectedAt or (witness and witness.at)
    local reason=r.endedReason
    if (not linkedOnly or r.returnCollectedAt and linkedOnly[id]) and p and at and p.at and p.at<=at and (reason=="expired" or reason=="canceled")
        and not blocked[id] and p.parts and (p.awaitingReturn or p.unresolved and not p.ended) and not saleEvidence(p)
        and not p.returnedUnits and not p.remainderTo and p.itemID==r.itemID
        and (not r.endTime or reason=="canceled" or r.endTime<=at)
        and AP.Lifecycle.BalancedPost(ch,p,entries) then
      local competing=false
      for _,receipt in ipairs(unmatched) do
        if (receipt.itemID and receipt.itemID==r.itemID or not receipt.itemID and receipt.name==r.name)
            and (receipt.observedAt or math.huge)>=p.at then competing=true;break end
      end
      if not competing and AP.Crafts.CollectReturn(ch,p,p.quantity,reason,r.auctionID,false,at,true) then
        p.poolReturnEvidence={method=witness and "RECORDED_RETURN_DELTA" or "RECORDED_PICKUP",at=at,quantity=p.quantity}
        if witness then r.returnCollectedAt=at end
        count=count+1
      end
    end
  end
  return count
end

-- A retained, isolated return movement can close an obsolete reservation
-- without a physical-copy link. Require a unique compatible ended group and
-- exclude observations already explained by a recorded return.
local function returnMovements(ch,ended,blocked)
  local observed,competing,attributed={},{},{}
  local posts=ch.craftLedger.posts
  for _,p in pairs(posts) do
    if p.itemID and (p.returnedAt or p.returnedUnits) then
      attributed[p.itemID]=attributed[p.itemID] or {}
      table.insert(attributed[p.itemID],p.returnedAt or math.huge)
    end
  end
  for id,r in pairs(ended) do
    if r.returnCollectedAt and r.itemID then
      attributed[r.itemID]=attributed[r.itemID] or {}
      table.insert(attributed[r.itemID],r.returnCollectedAt)
    end
    if r.itemID and not r.returnCollectedAt and not blocked[id] then
      local group=competing[r.itemID] or {}
      competing[r.itemID]=group
      group[#group+1]={id=id,row=r,post=posts[id]}
    end
  end
  for _,r in ipairs(ch.active or {}) do
    if r.itemID and competing[r.itemID] then
      competing[r.itemID]=nil
    end
  end
  for _,e in ipairs(ch.inventoryReconciliation and ch.inventoryReconciliation.observations or {}) do
    if competing[e.itemID] and e.evidence and e.evidence.AUCTION_RETURN and not e.bankOpen
        and e.reason=="EVENTS_AGREE" and type(e.delta)=="number" and e.delta>0 and e.delta==e.after-e.before
        and e.evidence.AUCTION_RETURN==e.delta and next(e.evidence)=="AUCTION_RETURN"
        and next(e.evidence,"AUCTION_RETURN")==nil then
      local duplicate=false
      for _,at in ipairs(attributed[e.itemID] or {}) do
        if at==math.huge or math.abs(at-e.at)<=5 then duplicate=true;break end
      end
      if not duplicate then
        local candidates,n={},0
        for _,c in ipairs(competing[e.itemID]) do
          local p,r=c.post,c.row
          local availableFrom=r.endedReason=="expired" and r.endTime or r.endedAt
          if availableFrom and availableFrom<=e.at and e.at-availableFrom<=120
              and (not p or not p.returnedUnits and not p.remainderTo and not saleEvidence(p)) then
            if not p or not p.awaitingReturn or not p.parts or (r.itemSuffix or 0)~=0 then
              candidates={};break
            end
            candidates[#candidates+1]=c
            n=n+p.quantity
          end
        end
        if n==e.delta and #candidates==1 then
          local id=candidates[1].id
          if observed[id]==nil then observed[id]=e else observed[id]=false end
        end
      end
    end
  end
  return observed
end

local function fill(l,target,entries)
  local p,r,limit=target.post,target.row,target.paid
  local candidates={}
  local base=P.BaseLevel(p.itemID)
  for _,x in ipairs(P.Lots(l,p.itemID,r.itemSuffix or p.itemSuffix)) do
    if P.Eligible(l,x,p.at,r.itemLevel or p.itemLevel,base) and not x.unknown
        and entries[x.index] and not entries[x.index].discrepancy then candidates[#candidates+1]=x end
  end
  if #candidates==0 then return 0,0 end
  table.sort(candidates,function(a,b)
    local aa=a.returnedFrom and tostring(a.returnedFrom)==tostring(r.repostOf)
    local bb=b.returnedFrom and tostring(b.returnedFrom)==tostring(r.repostOf)
    if not not aa~=not not bb then return aa end
    return fifo(a,b)
  end)
  local added,copper,parts,offset,i=0,0,{},0,1
  for _,a in ipairs(p.parts) do
    local missing=hole(a) and math.max(0,math.min(a.n,limit-offset)) or 0
    local assigned=0
    while missing>0 and candidates[i] do
      local x=candidates[i]
      local units=math.min(missing,P.BagUnits(x))
      local method=x.returnedFrom and tostring(x.returnedFrom)==tostring(r.repostOf) and "RETURN_FIFO" or "HISTORICAL_FIFO"
      local part=P.Take(x,units,method)
      parts[#parts+1]=part
      added,copper=added+units,copper+part.cost
      assigned,missing=assigned+units,missing-units
      if P.BagUnits(x)==0 then i=i+1 end
    end
    if assigned==0 then parts[#parts+1]=a
    elseif assigned<a.n then
      parts[#parts+1]={itemID=p.itemID,n=a.n-assigned,cost=0,unknown=true,reason=a.reason}
    end
    offset=offset+a.n
  end
  if added>0 then
    p.parts=parts
    p.poolReconciledAt=time()
  end
  return added,copper
end

function P.Reconcile(ch)
  local l=ch.craftLedger
  if not l then return 0,0,0 end
  local blocked,ended,receipts,unmatched,paid,targets={},{},{},{},{},{}
  for _,r in ipairs(ch.active or {}) do if r.auctionID then blocked[tostring(r.auctionID)]=true end end
  for _,r in ipairs(ch.ended or {}) do
    local id=tostring(r.auctionID)
    if ended[id] then blocked[id]=true end
    ended[id]=r
  end
  local owners={}
  for id,p in pairs(l.posts) do
    for receipt in pairs(p.fills or {}) do
      if owners[receipt] and owners[receipt]~=id then owners[receipt]=false
      elseif owners[receipt]==nil then owners[receipt]=id end
    end
  end
  for _,pool in ipairs({ch.sold or {},ch.deleted or {}}) do
    for _,r in ipairs(pool) do
      local id=r.auctionID and tostring(r.auctionID)
      if r.receiptID then receipts[r.receiptID]=(receipts[r.receiptID] or 0)+1 end
      if r.mailOnly and r.receiptID and not id and not r.mailFlip then unmatched[#unmatched+1]=r end
      if id and (r.sold or r.deletedKind=="sold") then
        blocked[id]=true
        if paid[id]~=nil then paid[id]=false else paid[id]=r end
      elseif id and r.deletedKind=="listed" and not r.endedReason then blocked[id]=true end
    end
  end
  local pending={}
  local journal=ch.returnEvidence or {}
  for _,e in ipairs(journal.pending or {}) do
    for id in pairs(e.waiting or {}) do pending[id]=true end
  end
  for _,e in pairs(journal.attempts or {}) do
    if e.requestedAt and time()-e.requestedAt<=120 then
      for id in pairs(e.waiting or {}) do pending[id]=true end
    end
  end
  local deClaims=AP.DETest and AP.DETest.ConfirmedReceiptClaims(ch) or {}
  for id,r in pairs(paid) do
    local p=l.posts[id]
    if not pending[id] and r and p and p.parts and p.at and p.at>0 and not p.observedWithoutAllocation
        and not (p.remainderTo or p.costRecovery or p.costRecoveryAutoBlocked or p.manualPurchaseUndo)
        and (p.itemSuffix==nil or r.itemSuffix==nil or p.itemSuffix==r.itemSuffix)
        and (p.itemLevel==nil or r.itemLevel==nil or p.itemLevel==r.itemLevel)
        and not (AP.VendorCosts and AP.VendorCosts.ManualActive(ch,id)) and r.itemID==p.itemID
        and r.receiptID and receipts[r.receiptID]==1 and not deClaims[r.receiptID]
        and (owners[r.receiptID]==nil or owners[r.receiptID]==id)
        and AP.Reconciliation.VerifiedProceeds(r) then
      local n=AP.Accounting.SaleUnits(r)
      local sold=p.filled or (p.ownedSold or p.soldAt and not p.remainingSeen) and p.quantity
      local cap=p.returnedUnits and p.quantity-p.returnedUnits or p.quantity
      local valid=n and cap and n==sold and n<=cap
      for receipt in pairs(p.fills or {}) do
        if owners[receipt]~=id or deClaims[receipt] or (receipts[receipt] or 0)>(receipt==r.receiptID and 1 or 0) then valid=false end
      end
      if valid then
        local offset=0
        for _,a in ipairs(p.parts) do
          if offset<n and hole(a) then targets[#targets+1]={id=id,post=p,row=r,paid=n};break end
          offset=offset+a.n
        end
      end
    end
  end
  local observations=returnMovements(ch,ended,blocked)
  if #targets==0 then
    local pending=next(observations)~=nil
    for id,r in pairs(ended) do
      local p=l.posts[id]
      if r.returnCollectedAt and p and (p.awaitingReturn or p.unresolved and not p.ended) and not p.returnedUnits and not blocked[id] then pending=true;break end
    end
    if not pending then return 0,0,0 end
  end
  local _,entries=AP.CostIntegrity.Audit(ch)
  local affected,copper={},0
  table.sort(targets,function(a,b)
    if a.post.at~=b.post.at then return a.post.at<b.post.at end
    return (tonumber(a.id) or math.huge)<(tonumber(b.id) or math.huge)
  end)
  local function allocate(list)
    local incomplete={}
    for _,t in ipairs(list) do
      if AP.Lifecycle.BalancedPost(ch,t.post,entries) then
        local n,c=fill(l,t,entries)
        if n>0 then affected[t.id]=true;copper=copper+c end
        if AP.Crafts.AllocationCost(t.post,0,t.paid).unknown then incomplete[#incomplete+1]=t end
      end
    end
    return incomplete
  end
  local linked={}
  for _,t in ipairs(targets) do
    if t.row.repostOf then linked[tostring(t.row.repostOf)]=true end
  end
  local recovered=0
  if next(linked) then recovered=releaseStranded(ch,ended,blocked,unmatched,entries,observations,linked) end
  local incomplete=allocate(targets)
  local released=releaseStranded(ch,ended,blocked,unmatched,entries,observations)
  if released>0 then
    allocate(incomplete)
  end
  local assigned=0
  for _ in pairs(affected) do assigned=assigned+1 end
  return assigned,copper,recovered+released
end

function P.BagUnits(lot)
  return lot.left-(lot.banked or 0)
end

function P.MoveBank(ch,id,delta)
  local l=ch.craftLedger
  if not l or delta==0 then return 0 end
  local candidates,variants={},{}
  for _,x in ipairs(l.lots) do
    if x.itemID==id and x.left>0 and not (l.quarantined and l.quarantined[x.index]) then
      candidates[#candidates+1]=x
      variants[key(x.itemSuffix or 0,x.itemLevel or 0)]=true
    end
  end
  -- The bank count lacks variant details. Leave mixed variants for review.
  local first=next(variants)
  if first and next(variants,first) then return 0 end
  table.sort(candidates,fifo)
  local remaining=math.abs(delta)
  for _,x in ipairs(candidates) do
    local banked,copper=x.banked or 0,x.bankedCopper or 0
    local units=delta>0 and P.BagUnits(x) or banked
    local n=math.min(units,remaining)
    if n>0 then
      local amount=delta>0 and (x.balance-copper) or copper
      local cost=math.floor(amount*n/units)
      local direction=delta>0 and 1 or -1
      x.banked=banked+direction*n
      x.bankedCopper=copper+direction*cost
      if x.banked==0 then x.banked,x.bankedCopper=nil,nil end
      remaining=remaining-n
      if remaining==0 then break end
    end
  end
  return math.abs(delta)-remaining
end
