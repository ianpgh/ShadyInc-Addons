local _, AP = ...
local R = {version=1, addonVersion="2.12.0"}
AP.AccountingReview = R

local category = {
  "Unmatched payment", "Missing sale cost", "Stranded reservation", "Purchase delivery",
  "Unconfirmed auction", "Possible duplicate", "Integrity violation", "Unmatched pickup",
  "Incomplete craft", "Missing active reservation basis"
}

local function stamp(row)
  return row and (row.observedAt or row.boughtAt or row.at or row.endedAt or row.soldAt)
end

local function key(index, entry)
  local r=entry.row
  if index==7 and r and r.index then
    return index.."/lot/"..r.index..(entry.text:match("^Invalid bank") and "/bank" or "/conservation")
  end
  if r and index~=6 and index~=7 then
    local ref=r.receiptID or r.auctionID or r.purchaseID or r.index
    if ref then return index.."/"..tostring(ref) end
  end
  return index.."/"..entry.text
end

local function copyFields(issue,row)
  if not row then return end
  issue.itemID,issue.itemSuffix,issue.itemLevel=row.itemID,row.itemSuffix,row.itemLevel
  issue.auctionID,issue.purchaseID,issue.receiptID=row.auctionID,row.purchaseID,row.receiptID
  issue.lotID=row.index
  issue.originalAt=issue.originalAt or stamp(row)
  issue.quantity,issue.copper=row.quantity,row.cost or row.price
end

local function classify(index,entry,historical,now)
  local r=entry.row
  if index==6 then return "Possible duplicate","Multiple records claim the same accounting identity." end
  if index==7 then return "Accounting integrity violation","Recorded quantity, copper or allocation references disagree." end
  if historical then
    if entry.insufficientEvidence then return "Unresolved historical issue",entry.insufficientEvidence end
    if index==2 or index==9 or index==10 then
      return "Inherited unknown acquisition cost","An input or sale allocation was already incomplete at installation."
    end
    return "Recoverable historical issue","Additional delivery, lifecycle or receipt evidence could establish the outcome."
  end
  local at=stamp(r)
  local returned=entry.pending==true
  local explicitDelivery=r and r.delivery and (r.delivery.stage=="available" or r.delivery.stage=="requested")
  if ((index==4 or index==5 or index==8) and at and now-at<=86400)
      or explicitDelivery or returned then
    return "Legitimately pending transaction","The transaction has recent or still-present lifecycle evidence."
  end
  if (index==2 or index==9 or index==10) and entry.inherited then
    return "Inherited unknown acquisition cost","A correctly linked pre-installation lot already had an incomplete basis."
  end
  return "New accounting failure","The issue first appeared after the installation audit."
end

function R.Refresh(ch,groups,initial,reconciled)
  local j=ch.accountingReview
  local now=time()
  local seen={}
  for i,entries in ipairs(groups) do
    for _,entry in ipairs(entries) do
      local id=key(i,entry)
      if not seen[id] then
        local issue=j.issues[id]
        if not issue then
          issue={id=id,detectedAt=now,detectedVersion=R.addonVersion,
            historical=initial==true,baseline=j.baseline and j.baseline.id,preBaseline=j.baseline==nil,
            history={},attempts=0,category=category[i],categoryIndex=i}
          if initial then issue.originatingVersion="2.11.0 or earlier" end
          j.issues[id]=issue
        end
        issue.categoryIndex=i
        copyFields(issue,entry.row)
        issue.expectedQuantity,issue.actualQuantity=entry.expectedQuantity,entry.actualQuantity
        issue.expectedCopper,issue.actualCopper=entry.expectedCopper,entry.actualCopper
        local state,reason=classify(i,entry,issue.historical,now)
        if issue.state~=state then
          issue.history[#issue.history+1]={at=now,previous=issue.state,state=state,reason=reason}
        end
        issue.state,issue.reason,issue.evidence=state,reason,entry.text
        issue.current=true
        if reconciled then issue.attempts=issue.attempts+1;issue.lastAttempt=now end
        seen[id]=true
      end
    end
  end
  local details={}
  local function link(index,id,method)
    if id then details[index.."/"..tostring(id)]=method end
  end
  for _,record in ipairs(j.corrections) do
    if record.method then
      for _,id in ipairs(record.purchases or {}) do link(4,id,record.method) end
      for _,id in ipairs(record.postings or {}) do link(2,id,record.method) end
      for _,id in ipairs(record.craftLots or {}) do link(9,id,record.method) end
      link(3,record.previousAuctionID,record.method)
      link(2,record.receiptID,record.method)
    end
  end
  for _,record in ipairs(ch.lifecycle and ch.lifecycle.supersededEnds or {}) do
    link(3,record.auctionID,record.action)
    link(5,record.auctionID,record.action)
    link(1,record.receipt,record.action)
  end
  for id,issue in pairs(j.issues) do
    if issue.current and not seen[id] then
      local method=details[id] or (issue.auctionID and details[issue.categoryIndex.."/"..tostring(issue.auctionID)])
      local state=issue.historical and "Historical issue cleared from diagnostics" or "Issue cleared from diagnostics"
      local reason="The finding did not recur. Consult the correction log for evidence of a repair."
      if method and issue.historical then
        state,reason="Recovered historical accounting issue","Evidence-linked correction · "..method
      end
      issue.history[#issue.history+1]={at=now,previous=issue.state,state=state,reason=reason}
      issue.state,issue.reason,issue.current=state,reason,false
      if reconciled then issue.attempts=issue.attempts+1;issue.lastAttempt=now end
    end
  end
end

function R.Prepare(ch)
  if ch.accountingReview then return ch.accountingReview.version==R.version end
  ch.accountingReview={version=R.version,installedAt=time(),issues={},corrections={},baselines={}}
  R.Refresh(ch,AP.Health.Rows(ch),true)
  return true
end

function R.Check(ch)
  if not R.Prepare(ch) then return end
  R.Refresh(ch,AP.Health.Rows(ch))
end

function R.Reconcile(ch,receiptPass)
  if not R.Prepare(ch) then return end
  local j=ch.accountingReview
  local before=AP.Health.Rows(ch)
  local paid=receiptPass and receiptPass() or 0
  local closed=AP.Lifecycle.ResolvePaid(ch)
  local receipts=AP.HistoricalAccounting.RecoverDeliveries(ch)
  local gifts=AP.HistoricalAccounting.RecoverReportedMageweave(ch)
  local reposts=AP.HistoricalAccounting.RecoverObservedReposts(ch)
  local crafts=AP.Reliability.RecoverCraftDelivery(ch)
  local returned,returnedCost,sales,saleCost=AP.CostIntegrity.Reconcile(ch)
  AP.Lifecycle.Validate(ch)
  local after=AP.Health.Rows(ch)
  R.Refresh(ch,after,false,true)
  local result={at=time(),payments=paid,supersededEnds=closed,deliveries=receipts,gifts=gifts,
    crafts=crafts,returns=returned+reposts,returnCopper=returnedCost,sales=sales,saleCopper=saleCost,
    before={},after={}}
  for i=1,#after do result.before[i]=#before[i];result.after[i]=#after[i] end
  j.lastReconciled=result
  if paid+closed+receipts+gifts+crafts+returned+reposts+sales>0 then
    j.corrections[#j.corrections+1]=result
  end
  return result
end

function R.Baseline(ch,commit)
  if not R.Prepare(ch) then return nil,"Accounting review schema unavailable." end
  local j=ch.accountingReview
  if j.baseline then return nil,"A baseline already exists." end
  if not j.lastReconciled then return nil,"Run Reconcile and inspect the results first." end
  if #(ch.active or {})>0 then return nil,"Settle active listings before setting the baseline." end
  for _,r in ipairs(ch.deleted or {}) do
    if r.deletedKind=="listed" and not r.endedAt then return nil,"Settle hidden active listings first." end
  end
  if next(ch.deliveryObservation or {}) then return nil,"Finish reviewing outstanding mailbox attachments first." end
  R.Check(ch)
  local groups=R.Summary(ch)
  if groups.pending>0 or groups.failures>0 or groups.violations>0 or groups.duplicates>0 then
    return nil,"Resolve current pending transactions, failures and integrity findings first."
  end
  if not commit then return true end
  local counts,audit=AP.Accounting.Audit(ch,time())
  local b={id=#j.baselines+1,at=time(),version=R.addonVersion,counts=counts,audit=audit,
    issues=groups,nextPurchaseID=ch.nextPurchaseID,nextReceiptID=ch.nextReceiptID}
  j.baselines[#j.baselines+1]=b
  j.baseline=b
  return b
end

function R.Summary(ch)
  local j=ch.accountingReview
  local s={historical=0,cleared=0,recovered=0,unresolved=0,inherited=0,pending=0,failures=0,violations=0,duplicates=0,
    historicalViolations=0,historicalDuplicates=0,verified=0}
  local since=j and (j.baseline and j.baseline.at or j.installedAt)
  for _,r in ipairs(ch.sold or {}) do
    if since and stamp(r) and stamp(r)>=since and r.receiptID and AP.Reconciliation.VerifiedProceeds(r) then
      local p=AP.Transactions.Post(ch,r.auctionID)
      local n=AP.Accounting.SaleUnits(r)
      if p and n and not AP.Crafts.AllocationCost(p,0,n).unknown then s.verified=s.verified+1 end
    end
  end
  for _,issue in pairs(j and j.issues or {}) do
    local state=issue.state
    if not issue.current then
      if state=="Recovered historical accounting issue" then s.recovered=s.recovered+1
      elseif issue.historical then s.cleared=s.cleared+1 end
    elseif state=="Accounting integrity violation" then
      local k=issue.historical and "historicalViolations" or "violations";s[k]=s[k]+1
    elseif state=="Possible duplicate" then
      local k=issue.historical and "historicalDuplicates" or "duplicates";s[k]=s[k]+1
    elseif state=="Unresolved historical issue" then s.unresolved=s.unresolved+1
    elseif state=="Inherited unknown acquisition cost" then s.inherited=s.inherited+1
    elseif state=="Legitimately pending transaction" then s.pending=s.pending+1
    elseif state=="New accounting failure" then s.failures=s.failures+1
    elseif issue.historical then s.historical=s.historical+1 end
  end
  return s
end

function R.Finding(ch,index,entry)
  local j=ch.accountingReview
  return j and j.issues[key(index,entry)]
end
