local _,AP=...
local H={}
AP.Health=H
local categories={"Unmatched payments","Sales missing cost","Stranded reservations","Awaiting delivery",
  "Unconfirmed auctions","Possible duplicates","Integrity violations","Unmatched pickups","Incomplete crafts",
  "Active listings missing cost"}

function H.Rows(ch)
  local _,lots,sales=AP.CostIntegrity.Audit(ch)
  local groups={}
  for i=1,#categories do groups[i]={} end
  local function add(k,s,r)
    groups[k][#groups[k]+1]={text=s,row=r}
  end
  local receipts,fillOwners={},{}
  local posts=ch.craftLedger and ch.craftLedger.posts or {}
  local deClaims=AP.DETest and AP.DETest.ConfirmedReceiptClaims(ch) or {}
  for id,p in pairs(posts) do
    for receipt in pairs(p.fills or {}) do
      if fillOwners[receipt] and fillOwners[receipt]~=id then add(6,"Two listing fills claim "..receipt) end
      fillOwners[receipt]=id
    end
  end
  for _,pool in ipairs({ch.sold or {},ch.deleted or {}}) do
    for _,r in ipairs(pool) do
      if r.receiptID then
        if receipts[r.receiptID] then add(6,"Repeated receipt "..r.receiptID,r) end
        receipts[r.receiptID]=true
        if fillOwners[r.receiptID] and tostring(r.auctionID)~=fillOwners[r.receiptID] then add(6,"Conflicting fill claim "..r.receiptID,r) end
        if r.mailOnly and not r.auctionID and not r.mailFlip and not deClaims[r.receiptID] and not fillOwners[r.receiptID] then add(1,r.receiptID.."  "..(r.name or ""),r) end
      end
    end
  end
  local function activeCosts(r)
    local p=posts[tostring(r.auctionID)]
    if p and p.parts and r.quantity and r.quantity>0 and AP.Crafts.AllocationCost(p,p.filled or 0,r.quantity).unknown then
      add(10,(r.name or "Listing").."  #"..tostring(r.auctionID),r)
    end
  end
  for _,r in ipairs(ch.active or {}) do activeCosts(r) end
  for _,r in ipairs(ch.deleted or {}) do
    if r.deletedKind=="listed" and not r.endedAt then activeCosts(r) end
  end
  for _,r in ipairs(sales) do
    add(2,(r.name or "Sale").."  "..tostring(r.auctionID or r.receiptID or "?"),r)
    if not posts[tostring(r.auctionID)] and not r.invoiceAuctionID then
      groups[2][#groups[2]].insufficientEvidence="The saved sale has no linked posting or cost reservation."
    end
  end
  for _,r in ipairs(ch.ended or {}) do
    local p=posts[tostring(r.auctionID)]
    if p and not (p.returnedUnits or p.remainderTo or p.ownedSold or p.soldAt) then
      local name=(r.name or "Item").."  #"..tostring(r.auctionID)
      if p.unresolved or p.awaitingReturn then
        for _,a in ipairs(p.parts or {}) do if a.source then add(3,name,r);break end end
      end
      if r.endedReason=="unconfirmed" then add(5,name,r) end
    elseif not p and r.endedReason=="unconfirmed" then add(5,(r.name or "Item").."  #"..tostring(r.auctionID),r) end
  end
  for _,b in ipairs(ch.buys or {}) do
    if b.delivery and b.delivery.stage~="verified" then
      add(4,(b.name or tostring(b.itemID)).."  purchase #"..tostring(b.purchaseID).."  "..tostring(b.delivery.stage),b)
    end
  end
  for _,e in ipairs(lots) do
    local x=e.lot
    local s="Lot #"..e.index.."  item "..x.itemID.."  units "..e.n.."/"..x.quantity.."  copper "..e.cost.."/"..x.cost
    if e.discrepancy or x.left<0 or x.balance<0 or x.left>x.quantity or x.balance>x.cost then
      add(7,s,x)
      local finding=groups[7][#groups[7]]
      finding.expectedQuantity,finding.actualQuantity=x.quantity,e.n
      finding.expectedCopper,finding.actualCopper=x.cost,e.cost
    end
    if (x.banked or 0)<0 or (x.banked or 0)>x.left or (x.bankedCopper or 0)<0
        or (x.bankedCopper or 0)>x.balance then add(7,"Invalid bank allocation · "..s,x) end
    if e.n>x.quantity or e.cost>x.cost then add(6,s,x) end
    if x.parts and x.unknown then add(9,"Lot #"..e.index.."  item "..x.itemID.."  known portion "..x.cost.."c",x) end
  end
  local function inspect(owner,label)
    for _,a in ipairs(owner.parts or {}) do
      local e=a.source and lots[a.source]
      if a.source and (not e or (a.itemID and e.lot.itemID~=a.itemID)) then
        add(7,label.." · missing or incompatible source lot #"..tostring(a.source))
      elseif e and ((e.lot.at or 0)>(owner.at or 0) or (e.lot.availableAt or 0)>(owner.at or 0)) then
        add(7,label.." · acquisition or delivery occurred after allocation")
      end
    end
  end
  for _,e in ipairs(lots) do inspect(e.lot,"Lot #"..e.index) end
  for id,p in pairs(posts) do
    inspect(p,"Auction #"..id)
    if p.quantity and (p.filled or 0)+(p.returnedUnits or 0)>p.quantity then add(7,"Auction #"..id.." · filled and returned units exceed original quantity") end
  end
  for _,r in ipairs(ch.returnEvidence and ch.returnEvidence.pending or {}) do
    add(8,"Item "..r.id.." x"..r.n.."  "..r.reason.."  "..date("%b %d %I:%M %p",r.at),r)
  end
  for _,r in pairs(ch.returnEvidence and ch.returnEvidence.attempts or {}) do
    add(8,"Pickup requested · unverified · item "..r.id.." x"..r.n.."  "..date("%b %d %I:%M %p",r.requestedAt),r)
  end
  local installed=ch.accountingReview and ch.accountingReview.installedAt
  if installed then
    for _,i in ipairs({2,9,10}) do
      for _,entry in ipairs(groups[i]) do
        local r=entry.row
        local owner=i==9 and r or posts[tostring(r.auctionID)]
        local inherited=false
        for _,a in ipairs(owner and owner.parts or {}) do
          if a.unknown then
            local x=a.source and lots[a.source] and lots[a.source].lot
            if not x or not x.at or x.at>=installed or not x.unknown then inherited=false;break end
            inherited=true
          end
        end
        entry.inherited=inherited
      end
    end
  end
  for _,g in ipairs(groups) do table.sort(g,function(a,b) return a.text<b.text end) end
  return groups
end

local function normalize(s) return (s or ""):lower() end

local frame
function H.Open(ch,money,refresh)
  if not frame then
    local f=CreateFrame("Frame","AuctionPeekHealth",UIParent)
    frame=f
    f:SetSize(690,555);f:SetPoint("CENTER");f:SetFrameStrata("DIALOG");f:EnableMouse(true)
    f:SetClampedToScreen(true)
    local bg=f:CreateTexture(nil,"BACKGROUND");bg:SetAllPoints();bg:SetColorTexture(.035,.035,.04,1)
    if UISpecialFrames then table.insert(UISpecialFrames,"AuctionPeekHealth") end
    local function label(t,x,y,w)
      local s=f:CreateFontString(nil,"OVERLAY","GameFontHighlight");s:SetPoint("TOPLEFT",x,-y)
      s:SetWidth(w);s:SetJustifyH("LEFT");s:SetText(t);return s
    end
    local function button(t,x,y,w,fn)
      local b=CreateFrame("Button",nil,f,"UIPanelButtonTemplate");b:SetSize(w,23)
      b:SetPoint("TOPLEFT",x,-y);b:SetText(t);b:SetScript("OnClick",fn);return b
    end
    local function edit(x,w)
      local b=CreateFrame("EditBox",nil,f,"InputBoxTemplate");b:SetPoint("TOPLEFT",x,-375)
      b:SetSize(w,23);b:SetAutoFocus(false);b:SetText("");return b
    end
    label("Accounting Health",15,12,260)
    local close=CreateFrame("Button",nil,f,"UIPanelCloseButton");close:SetPoint("TOPRIGHT")
    f.categories={};f.lines={}
    f.detail=label("",18,447,650)
    f.summary=label("",18,495,650)
    f.summary:SetFontObject(GameFontNormal)
    f.baseline=label("",18,525,250)
    local scopes={"All issues","Historical issues","Current issues","Cleared issues"}
    local function paint()
      local review=AP.AccountingReview
      local counts=review.Summary(f.ch)
      local function status(n,failed)
        return (n==0 and "|cff72ff85✓ " or failed and "|cffff6868X " or "|cffffcf40• ")..n.."|r"
      end
      local visible={}
      for i,b in ipairs(f.categories) do
        visible[i]={}
        for _,entry in ipairs(f.groups[i]) do
          local issue=review.Finding(f.ch,i,entry)
          if f.scope==1 or (f.scope==2 and issue and issue.historical)
              or (f.scope==3 and issue and not issue.historical) then
            visible[i][#visible[i]+1]=entry
          end
        end
        if f.scope==4 then
          for _,issue in pairs(f.ch.accountingReview.issues) do
            if not issue.current and issue.categoryIndex==i then
              visible[i][#visible[i]+1]={text=issue.evidence,issue=issue}
            end
          end
          table.sort(visible[i],function(a,b) return a.text<b.text end)
        end
        b:SetText(status(#visible[i],i==6 or i==7).."  "..categories[i])
      end
      f.scopeButton:SetText(scopes[f.scope])
      f.summary:SetText("History  "..counts.recovered.." recovered  •  "..counts.cleared.." cleared  •  "
        ..counts.historical.." review  •  "..counts.unresolved.." unresolved  •  "
        ..counts.inherited.." inherited  •  "..counts.historicalViolations.." integrity\n"
        .."Current  "..counts.pending.." pending  •  "..status(counts.failures,true).." failures  •  "
        ..status(counts.violations,true).." integrity  •  "..status(counts.duplicates,true).." duplicate  •  "..counts.verified.." verified")
      local j=f.ch.accountingReview
      f.baseline:SetText(j and j.baseline and date("Baseline · %b %d %I:%M %p",j.baseline.at) or "Baseline pending")
      local g=visible[f.category]
      f.page=math.max(1,math.min(f.page,math.ceil(#g/9)))
      for i,b in ipairs(f.lines) do
        local r=g[(f.page-1)*9+i]
        b.record=r;b:SetShown(r~=nil)
        if r then b:SetText(r.text) end
      end
      f.caption:SetText(categories[f.category].."   "..f.page.." / "..math.max(1,math.ceil(#g/9)))
    end
    function f:Reload()
      AP.AccountingReview.Check(self.ch)
      self.groups=H.Rows(self.ch)
      paint()
    end
    f.scopeButton=button(scopes[1],470,8,160,function()
      f.scope=(f.scope%#scopes)+1;f.page=1;paint()
    end)
    for i=1,#categories do
      f.categories[i]=button("",14,45+(i-1)*27,195,function() f.category=i;f.page=1;paint() end)
    end
    f.caption=label("",223,45,445)
    for i=1,9 do
      f.lines[i]=button("",216,65+(i-1)*24,458,function(b)
        local r=b.record
        if r.row and r.row.auctionID then f.old:SetText(tostring(r.row.auctionID)) end
        local issue=r.issue or AP.AccountingReview.Finding(f.ch,f.category,r)
        f.detail:SetText(issue and (issue.state.." · "..issue.reason) or r.text)
        if r.row and r.row.auctionID and AP.InspectorText then
          AP.OpenInspector(f,f.ch,r.row,f.money,function() return false end,normalize,f.refresh)
        end
      end)
    end
    button("Previous",216,287,83,function() f.page=f.page-1;paint() end)
    button("Next",302,287,75,function() f.page=f.page+1;paint() end)
    button("Reconcile",390,287,112,function()
      local result=AP.ReviewAccounting()
      f:Reload();f.refresh()
      if result then
        f.detail:SetText(("%d payments linked, %d stale ends cleared, %d deliveries, %d craft corrections, %d returns, %d sale costs.")
          :format(result.payments,result.supersededEnds,result.deliveries,result.crafts+result.gifts,result.returns,result.sales))
      end
    end)
    button("Payments",508,287,142,function()
      f:Hide();AP.OpenReceiptReview(UIParent,f.ch,normalize,f.money,f.refresh)
    end)
    label("Confirm a return you personally collected. Leave the destination blank to release it to inventory.",16,326,662)
    label("Source auction ID",18,354,170);label("Replacement auction ID",211,354,190)
    label("Known lost deposit (copper, optional)",409,354,262)
    f.old=edit(19,165);f.new=edit(212,168);f.fee=edit(411,125)
    local function values() return f.old:GetText(),f.new:GetText(),f.fee:GetText() end
    button("Preview return / transfer",16,408,195,function()
      local a,b,c=values()
      local v,err
      if c=="" or c:match("^%d+$") then v,err=AP.Lifecycle.Preview(f.ch,a,b,c~="" and tonumber(c) or nil) end
      f.preview=v
      f.detail:SetText(v and ("Confirm pickup of "..v.n.." × item "..v.item.." from #"..v.old.." to "
        ..(v.new and "#"..v.new or "available inventory").." · basis "..f.money(v.cost).." · lost deposit "
        ..(v.deposit and f.money(v.deposit) or "unknown")) or ("X "..(err or "Invalid deposit.")))
    end)
    button("Confirm pickup",219,408,137,function()
      if not f.preview then return end
      local v=f.preview;f.preview=nil
      local ok,err=AP.Lifecycle.Apply(f.ch,v)
      f.detail:SetText(ok and "✓ Applied and recorded." or ("X "..tostring(err)));f:Reload();f.refresh()
    end)
    button("Undo correction",365,408,132,function()
      local id=f.old:GetText()
      if f.undo~=id then f.undo=id;f.detail:SetText("Click Undo correction again to reverse the latest eligible correction on #"..id);return end
      f.undo=nil
      local ok=AP.Lifecycle.Undo(f.ch,id)
      f.detail:SetText(ok and "✓ Correction reversed." or "X No unchanged correction is eligible.");f:Reload();f.refresh()
    end)
    button("Record lost deposit",506,408,160,function()
      local id,amount=f.old:GetText(),tonumber(f.fee:GetText())
      if not AP.Lifecycle.Fee(f.ch,id,amount,false) then
        f.detail:SetText("X Enter a fully returned source auction and its previously unrecorded deposit in copper.");return
      end
      local key=id.."/"..amount
      if f.feeConfirm~=key then
        f.feeConfirm=key
        f.detail:SetText("Confirm the actual deposit forfeited on #"..id.." · "..f.money(amount)..". Click again to record.");return
      end
      f.feeConfirm=nil
      if AP.Lifecycle.Fee(f.ch,id,amount,true) then f.detail:SetText("✓ Forfeited deposit recorded.");f.refresh() end
    end)
    button("Establish baseline",485,520,175,function()
      local ok,err=AP.AccountingReview.Baseline(f.ch,f.confirmBaseline)
      if not ok then f.confirmBaseline=nil;f.detail:SetText("X "..err);return end
      if not f.confirmBaseline then
        f.confirmBaseline=true
        f.detail:SetText("Click Establish baseline again after saving your clean-state snapshot.")
        return
      end
      f.confirmBaseline=nil
      f.detail:SetText("✓ Baseline recorded in SavedVariables.")
      f:Reload()
    end)
    for _,b in ipairs({f.old,f.new,f.fee}) do b:SetScript("OnTextChanged",function() f.preview=nil;f.undo=nil;f.feeConfirm=nil end) end
  end
  frame.ch,frame.money,frame.refresh=ch,money,refresh
  frame.page,frame.category,frame.preview,frame.undo=1,1,nil,nil
  frame.confirmBaseline=nil
  frame.scope=1
  frame.old:SetText("");frame.new:SetText("");frame.fee:SetText("");frame.detail:SetText("")
  frame:Reload();frame:Show()
end
