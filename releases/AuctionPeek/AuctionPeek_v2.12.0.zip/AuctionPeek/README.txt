Auction Peek 2.12.0 accounting candidate for WoW Forever.

Extract AuctionPeek into Interface/AddOns with the game closed. Back up the
existing addon and AuctionPeek.lua SavedVariables before upgrading. Open
Accounting Health with /ap health and run Reconcile. The private development
kit contains the migration, rollback and controlled gameplay instructions.
