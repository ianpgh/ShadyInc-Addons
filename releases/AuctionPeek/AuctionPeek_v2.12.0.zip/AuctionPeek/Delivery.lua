local _, AP = ...
local D = {}
AP.Delivery = D
local session

function D.Record(row)
  if row.notifiedAH and row.itemID and row.quantity then
    row.delivery={version=1,stage="awaiting"}
  end
end

local function readable(v)
  return AP.MailValueReadable(v)
end

local function inbox()
  local n,total=GetInboxNumItems()
  if not readable(n) or not readable(total) or type(n)~="number" or n>200 or (total and total~=n) then return end
  local items={}
  for index=1,n do
    local _,_,sender,subject,money,cod,_,count,_,returned,_,canReply,isGM=GetInboxHeaderInfo(index)
    for _,v in pairs({sender,subject,money,cod,count,returned,canReply,isGM}) do
      if not readable(v) then return end
    end
    if count==true then count=1 end
    if count and count~=0 then
      if type(count)~="number" or count<1 or count>16 then return end
      local kind,name,seller,bid,buyout,_,_,_,_,_,invoiceQty=GetInboxInvoiceInfo(index)
      for _,v in pairs({kind,name,seller,bid,buyout,invoiceQty}) do if not readable(v) then return end end
      local paid=type(bid)=="number" and bid>0 and bid or buyout
      local gift=kind==nil and (canReply==true or canReply==1) and not returned and not isGM
      local found=0
      for slot=1,(ATTACHMENTS_MAX_RECEIVE or 16) do
        local label,id,_,qty=GetInboxItem(index,slot)
        local link=GetInboxItemLink and GetInboxItemLink(index,slot)
        if not readable(label) or not readable(id) or not readable(qty) or not readable(link) then return end
        if not label and not id and not qty then
          -- Remaining attachments can occupy nonconsecutive slots.
        elseif type(id)~="number" or type(qty)~="number" or qty<1 or qty%1~=0 then return
        else
          local list=items[id] or {};items[id]=list
          local purchase=kind=="buyer" and (count==1 or type(invoiceQty)=="number") and name==label
            and type(seller)=="string" and seller~="" and type(paid)=="number" and paid>0
          local source=cod==0 and money==0 and (purchase and "purchase" or gift and "gift") or nil
          local key=table.concat({tostring(sender),tostring(subject),tostring(kind),tostring(seller),
            id,qty,purchase and paid or 0,link or ""},"\031")
          local signature=table.concat({tostring(sender),tostring(subject),tostring(seller),
            id,purchase and paid or 0,link or ""},"\031")
          local row=list[key] or {qty=qty,count=0,source=source,paid=purchase and paid or nil,link=link}
          row.count=row.count+1;list[key]=row
          row.signature,row.originalQty=signature,type(invoiceQty)=="number" and invoiceQty or qty
          found=found+1
          if found==count then break end
        end
      end
      if found~=count then return end
    end
  end
  return items
end

local function verify(ch,id,previous,remaining,after,now)
  local total,allocated=0,{}
  for key,row in pairs(previous.items) do
    local vanished=row.count-(remaining[key] and remaining[key].count or 0)
    if vanished>0 then
      if not row.source then return end
      total=total+row.qty*vanished
      for _=1,vanished do allocated[#allocated+1]={key=key,row=row} end
    end
  end
  if total==0 then return false end
  if after-previous.before~=total then return end
  -- Match identical invoices FIFO only within the same quantity and price.
  -- A missing Buy History row cannot lend its price to a different purchase.
  local candidates={}
  for _,b in ipairs(ch.buys) do
    if b.itemID==id and b.delivery and b.delivery.stage~="verified" and not b.priceEstimated
        and b.boughtAt and b.boughtAt<=previous.at then candidates[#candidates+1]=b end
  end
  table.sort(candidates,function(a,b)
    if a.boughtAt~=b.boughtAt then return a.boughtAt<b.boughtAt end
    return a.purchaseID<b.purchaseID
  end)
  table.sort(allocated,function(a,b) return a.key<b.key end)
  for _,a in ipairs(allocated) do
    local row=a.row
    if row.source=="purchase" then
      for _,b in ipairs(candidates) do
        local d=b.delivery
        local prior=d.confirmedUnits or 0
        if d.stage~="verified" and b.quantity==row.originalQty and b.price==row.paid
            and row.qty<=b.quantity-prior and AP.Crafts.VariantMatches(b,row.link)
            and (not d.signature or d.signature==row.signature) then
          local evidence={method="BUYER_INVOICE_AND_BAG_DELTA",invoice=a.key,before=previous.before,after=after}
          if prior==0 and row.qty==b.quantity then
            b.delivery={version=3,stage="verified",collectedAt=now,prior=d,evidence=evidence}
          else
            if not d.segments then
              d={version=3,stage="partial",prior=d,confirmedUnits=0,segments={},signature=row.signature}
              b.delivery=d
            end
            local units=prior+row.qty
            local copper=math.floor(b.price*units/b.quantity)-math.floor(b.price*prior/b.quantity)
            d.segments[#d.segments+1]={quantity=row.qty,copper=copper,at=now,evidence=evidence}
            d.confirmedUnits=units
            if units==b.quantity then d.stage,d.collectedAt="verified",now end
          end
          AP.Crafts.ImportPurchases(ch,{b})
          AP.Inventory.Signal(ch,id,row.qty,"AH_DELIVERY")
          break
        end
      end
    elseif row.source=="gift" then
      AP.Crafts.ExternalLot(ch,id,row.qty,0,now,"giftMail",row.link,{invoice=a.key})
      AP.Inventory.Signal(ch,id,row.qty,"GIFT_MAIL")
    end
  end
  return true
end

function D.Scan(ch)
  if not session or session.ch~=ch then return end
  local ok,items=pcall(inbox)
  if not ok or not items then return end
  local now=time()
  local saved=ch.deliveryObservation or {}
  local nextState={}
  for id,previous in pairs(saved) do
    local remaining=items[id] or {}
    local after=AP.Reconciliation.Count(id)
    if after and not previous.competing and now>=previous.at and now-previous.at<=120 then
      local result=verify(ch,id,previous,remaining,after,now)
      if result==nil then
        previous.droppedAt=previous.droppedAt or now
        if now-previous.droppedAt<=10 then nextState[id]=previous end
      elseif result==false and after>previous.before then
        previous.increasedAt=previous.increasedAt or now
        if now-previous.increasedAt<=3 then nextState[id]=previous end
      end
    end
  end
  for id,list in pairs(items) do
    if not nextState[id] then
      local before=AP.Reconciliation.Count(id)
      if before then nextState[id]={items=list,before=before,at=now} end
    end
  end
  ch.deliveryObservation=nextState
end

function D.Fail()
  if session then session.ch.deliveryObservation=nil end
end

function D.Open(ch)
  session={ch=ch}
  D.Scan(ch,true)
end

function D.Close()
  if session then D.Scan(session.ch,true);session.ch.deliveryObservation=nil end
  session=nil
end

function D.Reset(ch)
  for _,r in ipairs(ch.buys) do
    if r.delivery and r.delivery.stage~="verified" and r.delivery.stage~="partial" then r.delivery.stage="awaiting" end
  end
end

function D.Queue(ch)
  local active=session
  if not active or active.queued or not (C_Timer and C_Timer.After) then return end
  active.queued=true
  C_Timer.After(0.25,function()
    if session~=active then return end
    active.queued=false
    D.Scan(ch,true)
  end)
end

function D.BeforePacedPickup()
  if session then D.Scan(session.ch,true) end
end

function D.Install()
  if not (hooksecurefunc and GetInboxNumItems and GetInboxHeaderInfo and GetInboxInvoiceInfo and GetInboxItem) then return end
  local function requested()
    if session then D.Queue(session.ch) end
  end
  if TakeInboxItem then hooksecurefunc("TakeInboxItem",requested) end
  if AutoLootMailItem then hooksecurefunc("AutoLootMailItem",requested) end
end

function D.CompetingIncrease(ch,id)
  local row=ch.deliveryObservation and ch.deliveryObservation[id]
  if row then row.competing=true end
end

function AP.ReconcileWalletDrop(ch,previous,before,after,claims,walletDelta,record)
  local receipts,total={},0
  local remaining={}
  for key,n in pairs(before) do remaining[key]=math.max(0,n-(after[key] or 0)-(claims[key] or 0)) end
  for _,r in pairs(previous) do
    if (remaining[r.signature] or 0)>0 then
      receipts[#receipts+1]=r
      total=total+r.net
      remaining[r.signature]=remaining[r.signature]-1
    end
  end
  if total==0 then return end
  if total~=walletDelta then
    AP.Inventory.Append(ch,{at=time(),reason="SELLER_INVOICE_DROPPED_WITHOUT_PAYMENT_PROOF",
      invoiceCount=#receipts,invoiceAmount=total,walletDelta=walletDelta})
    return
  end
  -- A later post-hook sees these claims and cannot credit the same drop.
  for _,r in ipairs(receipts) do
    claims[r.signature]=(claims[r.signature] or 0)+1
    local verified={}
    for k,v in pairs(r) do verified[k]=v end
    verified.paymentEvidence="INBOX_AND_WALLET"
    record(verified)
  end
  return true
end
