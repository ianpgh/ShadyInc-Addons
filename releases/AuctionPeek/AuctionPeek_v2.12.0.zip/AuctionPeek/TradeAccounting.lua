local _, AP = ...
local T={}
AP.TradeAccounting=T
local session

local function read(v)
  return AP.MailValueReadable(v)
end

local function offer()
  if not (GetTradeTargetItemInfo and GetTradeTargetItemLink and GetTradePlayerItemInfo
      and GetPlayerTradeMoney and GetTargetTradeMoney) then return end
  local paid,received=GetPlayerTradeMoney(),GetTargetTradeMoney()
  if not read(paid) or not read(received) or type(paid)~="number" or type(received)~="number"
      or paid<0 or received~=0 then return end
  local items,counts,slots={}, {}, 0
  for i=1,6 do
    local outgoing=GetTradePlayerItemInfo(i)
    local name,_,n=GetTradeTargetItemInfo(i)
    local link=GetTradeTargetItemLink(i)
    if not read(outgoing) or not read(name) or not read(n) or not read(link) or outgoing then return end
    if name then
      local id=type(link)=="string" and tonumber(link:match("|Hitem:(%d+)"))
      if not id or type(n)~="number" or n<=0 or n%1~=0 then return end
      local bag=AP.Reconciliation.Count(id)
      if bag==nil then return end
      slots=slots+1
      items[slots]={id=id,n=n,link=link}
      local count=counts[id] or {before=bag,quantity=0}
      count.quantity=count.quantity+n
      counts[id]=count
    end
  end
  if slots==0 or (paid>0 and slots~=1) then return end
  return {items=items,counts=counts,paid=paid,at=time()}
end

function T.Confirm(ch)
  local s=session
  if not s or not s.success or s.ch~=ch or not s.offer then return end
  if time()-s.success>5 then session=nil;return end
  for id,count in pairs(s.offer.counts) do
    if AP.Reconciliation.Count(id)~=count.before+count.quantity then return end
  end
  session=nil
  local state=ch.tradeAccounting or {version=1,sequence=0}
  ch.tradeAccounting=state
  state.sequence=state.sequence+1
  local source=s.offer.paid>0 and "paidTrade" or "giftTrade"
  for _,row in ipairs(s.offer.items) do
    AP.Crafts.ExternalLot(ch,row.id,row.n,s.offer.paid,s.success,source,row.link,
      {method="TRADE_COMPLETE_AND_BAG_DELTA",tradeID=state.sequence})
    AP.Delivery.CompetingIncrease(ch,row.id)
    AP.Inventory.Signal(ch,row.id,row.n,s.offer.paid>0 and "PAID_TRADE" or "GIFT_TRADE")
  end
  return true
end

function T.Event(ch,event,...)
  if event=="TRADE_SHOW" then session={ch=ch}
  elseif not session or session.ch~=ch then return
  elseif event=="TRADE_ACCEPT_UPDATE" then
    local player,target=...
    if not read(player) or not read(target) then session.offer=nil;return end
    if player==1 or player==true then
      if target==1 or target==true then
        local ok,result=pcall(offer)
        if ok and result then session.offer=result end
      end
    else session.offer=nil end
  elseif event=="TRADE_REQUEST_CANCEL" then session=nil
  elseif event=="TRADE_CLOSED" then
    local closing=session
    if C_Timer and C_Timer.After then
      C_Timer.After(5,function() if session==closing then session=nil end end)
    end
  elseif event=="UI_INFO_MESSAGE" or event=="CHAT_MSG_SYSTEM" then
    local code,message=...
    if event=="CHAT_MSG_SYSTEM" then message=code end
    if read(message) and ERR_TRADE_COMPLETE and message==ERR_TRADE_COMPLETE and session.offer
        and time()-session.offer.at<=10 then
      session.success=time()
      T.Confirm(ch)
    end
  end
end
