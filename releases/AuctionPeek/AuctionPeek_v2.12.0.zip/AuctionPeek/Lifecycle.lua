local _, AP = ...
local L={}
AP.Lifecycle=L

-- Lot indexes in v2.10 are append-only primary keys. Preserve these foreign
-- keys, including exhausted lots. The new journal contains manual actions only.
function L.Migrate(ch)
  if not ch.lifecycle then ch.lifecycle={version=1,actions={}} end
  return ch.lifecycle.version==1
end

local function whole(n) return type(n)=="number" and n>=0 and n==math.floor(n) end
local function copy(t)
  if type(t)~="table" then return t end
  local out={}
  for k,v in pairs(t) do out[k]=copy(v) end
  return out
end
local function same(a,b)
  if type(a)~="table" then return a==b end
  if type(b)~="table" then return false end
  for k,v in pairs(a) do if not same(v,b[k]) then return false end end
  for k in pairs(b) do if a[k]==nil then return false end end
  return true
end

function L.BalancedPost(ch,p,entries)
  local l=ch.craftLedger
  local n=0
  for _,a in ipairs(p.parts or {}) do
    if not whole(a.n) or a.n==0 or not whole(a.cost) then return false end
    n=n+a.n
    if a.source then
      local x=l.lots[a.source]
      if not x or x.itemID~=p.itemID or not whole(x.left) or not whole(x.balance)
          or x.left>x.quantity or x.balance>x.cost or (x.at or 0)>(p.at or 0)
          or (x.availableAt or 0)>(p.at or 0) then return false end
      if not entries then local totals; totals,entries=AP.CostIntegrity.Audit(ch) end
      if not entries[a.source] or entries[a.source].discrepancy then return false end
    end
  end
  return not p.parts or n==p.quantity
end

local function history(ch,id)
  local row,bucket
  for _,key in ipairs({"ended","active","sold","deleted"}) do
    for _,r in ipairs(ch[key] or {}) do
      if r.auctionID and tostring(r.auctionID)==id then
        if row then return end
        row,bucket=r,key
      end
    end
  end
  return row,bucket
end

function L.Preview(ch,old,new,deposit)
  local l=ch.craftLedger
  if not l or not L.Migrate(ch) then return nil,"Ledger unavailable." end
  old=tostring(old)
  new=new and new~="" and tostring(new) or nil
  if deposit~=nil and not whole(deposit) then return nil,"Enter the exact lost deposit in whole copper." end
  local p=l.posts[old]
  local row,bucket=history(ch,old)
  if not p or bucket~="ended" or row.purchase or row.sold or row.receiptID or row.returnCollectedAt
      or p.ownedSold or p.soldSnapshotUnits or p.soldAt or p.saleNoticeAt or p.gross or p.filled or p.remainingSeen
      or p.returnedUnits or p.remainderTo or not p.parts or not p.quantity or not p.at
      or not (p.unresolved or p.awaitingReturn) or not L.BalancedPost(ch,p) then
    return nil,"Source must be an intact, balanced reservation on one ended, unpaid listing."
  end
  if row.repostedAs and tostring(row.repostedAs)~=new then return nil,"History links to another listing." end
  local dest,where,q
  if new then
    dest,where=history(ch,new)
    q=l.posts[new]
    if not dest or (where~="active" and where~="sold") or not q or not q.at or q.at<p.at
        or q.at<(row.endedAt or p.at) or old==new or q.itemID~=p.itemID or q.quantity~=p.quantity
        or row.itemID~=dest.itemID or (row.itemSuffix or 0)~=(dest.itemSuffix or 0)
        or row.itemLevel~=dest.itemLevel or (dest.repostOf and tostring(dest.repostOf)~=old)
        or q.ended or q.returnedUnits or q.remainderTo or q.costRecovery or q.manualPurchaseUndo
        or q.filled or q.remainingSeen or not q.parts or not L.BalancedPost(ch,q)
        or (AP.VendorCosts and AP.VendorCosts.ManualActive(ch,new)) then
      return nil,"Destination needs the same item, variant and intact quantity on a later listing."
    end
    for _,a in ipairs(q.parts) do
      if a.source or not a.unknown or a.cost~=0 or a.reason~="UNKNOWN_ACQUISITION" then
        return nil,"Destination already has cost evidence."
      end
    end
  end
  local pickup
  for i,r in ipairs(ch.returnEvidence and ch.returnEvidence.pending or {}) do
    if r.id==p.itemID and r.at>=p.at and r.n==p.quantity and (r.suffix or 0)==(row.itemSuffix or 0) then
      if pickup or (p.ended and p.ended~=r.reason) or (q and r.at>q.at) then
        return nil,"Conflicting or repeated return attachments require reconciliation."
      end
      pickup={index=i,record=copy(r)}
    end
  end
  for _,pool in ipairs({ch.sold or {},ch.deleted or {}}) do
    for _,r in ipairs(pool) do
      if r.receiptID and not r.auctionID and not r.mailFlip and (r.itemID==p.itemID or r.name==row.name)
          and (r.observedAt or math.huge)>=p.at then return nil,"A payment could belong to the source." end
    end
  end
  local attempt
  for id,e in pairs(ch.returnEvidence and ch.returnEvidence.attempts or {}) do
    if e.id==p.itemID and e.n==p.quantity and (e.suffix or 0)==(row.itemSuffix or 0)
        and e.requestedAt>=p.at and (not q or e.requestedAt<=q.at) then
      if attempt or pickup then return nil,"More than one pickup record matches." end
      attempt={id=id,at=e.requestedAt,reason=e.reason}
    end
  end
  local cost=0
  for _,a in ipairs(p.parts) do
    if not a.source or a.unknown then return nil,"Source contains an unresolved allocation." end
    cost=cost+a.cost
  end
  return {old=old,new=new,cost=cost,n=p.quantity,item=p.itemID,deposit=deposit,parts=copy(p.parts),
    pickup=pickup,attempt=attempt,before=row.endedReason,reposted=row.repostedAs,receipt=dest and dest.receiptID}
end

local balanceFields={"left","balance","returnedFrom","lastReturnedAt","inferredReturn","mixedReturnHistory"}
local postFields={"ended","awaitingReturn","unresolved","returnedUnits","fillLimit","returnedAt","returnAllocation","manualReturnAt"}
local function capture(t,fields)
  local r={}
  for _,k in ipairs(fields) do r[k]=t[k] end
  return r
end
local function restore(t,r,fields)
  for _,k in ipairs(fields) do t[k]=r[k] end
end
local function balances(ch,parts)
  local result={}
  for _,a in ipairs(parts) do
    result[a.source]=capture(ch.craftLedger.lots[a.source],balanceFields)
  end
  return result
end

function L.Apply(ch,preview)
  local v,err=L.Preview(ch,preview.old,preview.new,preview.deposit)
  if not v or not same(v,preview) then return nil,err or "Evidence changed. Preview again." end
  local posts=ch.craftLedger.posts
  local p=posts[v.old]
  local row=history(ch,v.old)
  local at=time()
  if v.new then
    local q=posts[v.new]
    v.original=copy(q.parts)
    v.destinationState={soldAt=q.soldAt,ownedSold=q.ownedSold,saleNoticeAt=q.saleNoticeAt}
    v.destinationState.where=select(2,history(ch,v.new))
    v.flags={ended=p.ended,awaitingReturn=p.awaitingReturn,unresolved=p.unresolved,fillLimit=p.fillLimit}
    local parts=copy(p.parts)
    for _,a in ipairs(parts) do
      a.returnedFrom=tonumber(v.old); a.method="PLAYER_CONFIRMED_TRANSFER"
    end
    q.parts=parts
    p.remainderTo,p.returnedUnits,p.fillLimit=v.new,v.n,0
    p.ended=p.ended or (v.pickup and v.pickup.record.reason) or "returned"
    p.unresolved,p.awaitingReturn=nil,nil
    row.repostedAs=tonumber(v.new)
    v.assigned=copy(parts)
  else
    v.balances=balances(ch,p.parts)
    v.flags=capture(p,postFields)
    local reason=(v.pickup and v.pickup.record.reason) or p.ended or (row.endedReason~="unconfirmed" and row.endedReason) or "returned"
    if not AP.Crafts.CollectReturn(ch,p,v.n,reason,tonumber(v.old),false,at,true) then return nil,"Reservation changed." end
  end
  if v.attempt then ch.returnEvidence.attempts[v.attempt.id]=nil end
  if v.pickup then
    local j=ch.returnEvidence
    table.remove(j.pending,v.pickup.index)
    j.resolved=(j.resolved or 0)+1
    j.recoveredCost=(j.recoveredCost or 0)+v.cost
  end
  row.returnCollectedAt=at
  row.endedReason=p.ended or "returned"
  p.manualReturnAt=at
  if not v.new then v.after=balances(ch,p.parts);v.afterPost=capture(p,postFields) end
  v.at=at
  ch.lifecycle.actions[#ch.lifecycle.actions+1]=v
  return true
end

function L.Undo(ch,old)
  if not ch.lifecycle or ch.lifecycle.version~=1 then return end
  for i=#ch.lifecycle.actions,1,-1 do
    local v=ch.lifecycle.actions[i]
    if v.old==old and not v.undoneAt then
      if v.pickup or v.attempt then return end
      if not v.new then
        local row,bucket=history(ch,old)
        local p=ch.craftLedger.posts[old]
        if bucket~="ended" or not p or p.saleNoticeAt or p.gross or p.ownedSold or p.soldSnapshotUnits or p.soldAt or p.filled then return end
        if v.kind=="PLAYER_CONFIRMED_DEPOSIT" then
          if p.forfeitedDeposit~=v.deposit then return end
          p.forfeitedDeposit=nil;v.undoneAt=time();return true
        end
        if not v.after or row.returnCollectedAt~=v.at or row.repostedAs~=v.reposted
            or not same(capture(p,postFields),v.afterPost) or not same(p.parts,v.parts)
            or not same(balances(ch,p.parts),v.after) or not L.BalancedPost(ch,p) then return end
        for index,r in pairs(v.balances) do restore(ch.craftLedger.lots[index],r,balanceFields) end
        restore(p,v.flags,postFields)
        row.returnCollectedAt,row.endedReason=nil,v.before
        v.undoneAt=time()
        return true
      end
      local posts=ch.craftLedger.posts
      local p,q=posts[old],posts[v.new]
      local row,bucket=history(ch,old)
      local dest,where=history(ch,v.new)
      if not row or bucket~="ended" or not dest or (where~="sold" and where~="active")
          or dest.receiptID~=v.receipt or not p or not q or p.manualReturnAt~=v.at
          or p.remainderTo~=v.new or row.returnCollectedAt~=v.at or p.saleNoticeAt or p.gross or p.ownedSold
          or q.ended or q.returnedUnits or q.filled or q.remainingSeen or q.remainderTo
          or not same(v.destinationState,{soldAt=q.soldAt,ownedSold=q.ownedSold,saleNoticeAt=q.saleNoticeAt,where=where})
          or not same(q.parts,v.assigned) or not same(p.parts,v.parts) or not L.BalancedPost(ch,q) then return end
      p.remainderTo,p.returnedUnits,p.manualReturnAt=nil,nil,nil
      p.ended,p.awaitingReturn,p.unresolved,p.fillLimit=v.flags.ended,v.flags.awaitingReturn,v.flags.unresolved,v.flags.fillLimit
      row.returnCollectedAt,row.endedReason,row.repostedAs=nil,v.before,v.reposted
      q.parts=copy(v.original)
      v.undoneAt=time()
      return true
    end
  end
end

-- Only whole-listing chains can carry a whole deposit into a later sale.
-- Never apportion an unverified historical fee across mixed or split stacks.
function L.Deposits(ch,id)
  local posts=ch.craftLedger and ch.craftLedger.posts or {}
  local seen,total,count={},0,0
  while id do
    id=tostring(id)
    if seen[id] then return total,false,count end
    seen[id]=true
    local p=posts[id]
    if not p or not p.parts or #p.parts==0 then return total,false,count end
    local prior=p.parts[1].returnedFrom
    for _,a in ipairs(p.parts) do
      if a.returnedFrom~=prior or not a.source then return total,false,count end
    end
    local row=history(ch,id)
    if not prior then
      for _,a in ipairs(p.parts) do
        local x=ch.craftLedger.lots[a.source]
        if not x or x.mixedReturnHistory or (x.lastReturnedAt and x.lastReturnedAt<=p.at) then return total,false,count end
      end
      return total,row~=nil and not row.repostOf and p.lifecycleObserved==true,count
    end
    local old=posts[tostring(prior)]
    if not old or old.quantity~=p.quantity or old.returnedUnits~=p.quantity then return total,false,count end
    local fee=old.forfeitedDeposit
    if fee==nil then
      for _,v in ipairs(ch.lifecycle and ch.lifecycle.actions or {}) do
        if not v.undoneAt and v.old==tostring(prior) then fee=v.deposit end
      end
    end
    if fee==nil then return total,false,count end
    total,count=total+fee,count+1
    id=prior
  end
end

-- Establish all downstream destinations before changing the first copper.
-- Decline converging/reused paths, corrected allocations, and returned slices
-- whose historical segment boundaries are no longer recoverable.
function L.RepricePlan(ch,root)
  local l=ch.craftLedger
  local links,visited={},{}
  local function ref(source,r)
    if source then
      links[source]=links[source] or {}
      table.insert(links[source],r)
    end
  end
  for i,x in ipairs(l.lots) do
    for j,a in ipairs(x.parts or {}) do ref(a.source,{x=x,a=a,child=i,key="c"..i.."/"..j}) end
  end
  for id,p in pairs(l.posts) do
    for j,a in ipairs(p.parts or {}) do ref(a.source,{x=p,a=a,key="p"..id.."/"..j}) end
  end
  for _,pool in ipairs({ch.sold or {},ch.deleted or {}}) do
    for _,r in ipairs(pool) do if r.mailFlip then ref(r.mailFlip.source,{blocked=true}) end end
  end
  local function plan(i,depth)
    if visited[i] or depth>32 then return end
    visited[i]=true
    local x=l.lots[i]
    if not x or not x.parts or not whole(x.quantity) or x.quantity==0 or not whole(x.left)
        or not whole(x.balance) or not whole(x.cost) or x.lastReturnedAt or x.banked then return end
    local inputCost=0
    for _,a in ipairs(x.parts) do
      if not whole(a.cost) then return end
      inputCost=inputCost+a.cost
    end
    if inputCost~=x.cost then return end
    local n,c=x.left,x.balance
    local children=links[i] or {}
    for _,edge in ipairs(children) do
      local owner,a=edge.x,edge.a
      if edge.blocked or not a or a.itemID~=x.itemID or not whole(a.n) or a.n==0 or not whole(a.cost)
          or not owner.at or owner.at<x.at or owner.returnedUnits or owner.remainderTo
          or owner.costRecovery or owner.manualPurchaseUndo or a.recovered or a.manual then return end
      n,c=n+a.n,c+a.cost
      if edge.child then
        edge.plan=plan(edge.child,depth+1)
        if not edge.plan then return end
      end
    end
    if n~=x.quantity or c~=x.cost then return end
    table.sort(children,function(a,b)
      if a.x.at~=b.x.at then return a.x.at<b.x.at end
      return a.key<b.key
    end)
    return {lot=x,children=children}
  end
  return plan(root,0)
end

function L.Reprice(plan,delta)
  local x=plan.lot
  x.cost=x.cost+delta;x.estimate=true;x.unknown=nil
  for _,a in ipairs(x.parts) do if a.unknown then x.unknown=true;break end end
  local offset,assigned=0,0
  for _,e in ipairs(plan.children) do
    offset=offset+e.a.n
    local total=math.floor(delta*offset/x.quantity)
    local share=total-assigned
    e.a.cost=e.a.cost+share;e.a.estimate=true;e.a.unknown=x.unknown
    if e.plan then L.Reprice(e.plan,share) end
    assigned=total
  end
  x.balance=x.balance+delta-assigned
end

function L.Fee(ch,id,copper,apply)
  if not id or not whole(copper) or not L.Migrate(ch) then return end
  local row,bucket=history(ch,tostring(id))
  local l=ch.craftLedger
  local p=l and l.posts[tostring(id)]
  if bucket~="ended" or not p or not p.quantity or p.quantity~=p.returnedUnits
      or p.saleNoticeAt or p.ownedSold or p.soldAt or p.gross or p.filled or p.remainingSeen
      or p.forfeitedDeposit~=nil or not (row.returnCollectedAt or row.confirmedReturned) then return end
  for _,v in ipairs(ch.lifecycle.actions) do
    if v.old==tostring(id) and v.deposit~=nil and not v.undoneAt then return end
  end
  if apply then
    p.forfeitedDeposit=copper
    table.insert(ch.lifecycle.actions,{old=tostring(id),deposit=copper,at=time(),kind="PLAYER_CONFIRMED_DEPOSIT"})
  end
  return true
end

-- An offline split may have no observed intermediate stack size. Accept the
-- complement only when collected mail and unique paid invoices exhaust one
-- original listing. Older ambiguous stock or a matching archived receipt vetoes it.
function L.OfflineRemainder(ch,e)
  local l=ch.craftLedger
  if not l then return end
  local target,row
  for _,r in ipairs(ch.ended or {}) do
    local p=l.posts[tostring(r.auctionID)]
    if r.itemID==e.id and (r.itemSuffix or 0)==(e.suffix or 0)
        and (not e.level or not r.itemLevel or e.level==r.itemLevel) and p and p.at and p.at<=e.at
        and p.parts and p.quantity and p.quantity>e.n and not (p.returnedUnits or p.remainderTo or p.filled
        or p.gross or p.ownedSold or p.fullStackObserved or p.reportedAllSold or p.soldSnapshotUnits or p.soldAt or p.remainingSeen or r.returnCollectedAt)
        and (p.ended==e.reason or r.endedReason==e.reason or
          (e.reason=="expired" and r.endedReason=="unconfirmed" and r.endTime and r.endTime<=e.at)) then
      if target then return end
      target,row=p,r
    end
  end
  if not target or not row.name then return end
  local unit=target.unitPrice or target.totalPrice
  if not whole(unit) or unit<1 then return end
  local wanted=target.quantity-e.n
  local receipts,claimed={},{}
  local n,latest=0,0
  for _,pool in ipairs({ch.sold or {},ch.deleted or {}}) do
    for _,r in ipairs(pool) do
      if r.name==row.name and (not r.itemID or r.itemID==e.id) and r.receiptID then
        if claimed[r.receiptID] then return end
        claimed[r.receiptID]=true
        if not r.auctionID and r.mailOnly and not r.mailFlip and (r.observedAt or 0)>=target.at then
          if pool~=ch.sold or not r.receiptQuantityKnown or not whole(r.receiptQty) or r.receiptQty<1
              or not whole(r.verifiedGross) or r.verifiedGross~=unit*r.receiptQty
              or not whole(r.verifiedCut) or r.verifiedCut>r.verifiedGross or not whole(r.verifiedDeposit)
              or r.verifiedGross-r.verifiedCut+r.verifiedDeposit~=r.verifiedNet
              or (r.invoiceAuctionID and r.invoiceAuctionID~=row.auctionID)
              or math.abs(r.observedAt-e.at)>86400 then return end
          receipts[r.receiptID]=true;n=n+r.receiptQty;latest=math.max(latest,r.observedAt)
        end
      end
    end
  end
  if n~=wanted then return end
  local claims=AP.DETest and AP.DETest.ConfirmedReceiptClaims(ch) or {}
  for id in pairs(receipts) do if claims[id] then return end end
  for _,p in pairs(l.posts) do
    for id in pairs(p.fills or {}) do if receipts[id] then return end end
    if p~=target and p.itemID==e.id and (p.at or 0)<=math.max(latest,e.at)
        and not (p.returnedUnits==p.quantity and p.quantity) and not p.remainderTo
        and not (p.filled==p.quantity and p.quantity) and not (p.ownedSold and p.gross) then return end
  end
  for _,pool in ipairs({ch.active or {},ch.deleted or {},ch.ended or {},ch.sold or {}}) do
    for _,r in ipairs(pool) do
      if r.auctionID and r.auctionID~=row.auctionID and (r.itemID==e.id or r.name==row.name)
          and not l.posts[tostring(r.auctionID)] and (r.firstSeenAt or 0)<=latest then return end
    end
  end
  return target,receipts,wanted
end

-- Existing saves can contain costs removed before allocation journaling.
-- Keep the historical amounts but exclude affected lots from new spending.
function L.Validate(ch)
  local l=ch.craftLedger
  if not l then return end
  local _,items=AP.CostIntegrity.Audit(ch)
  local blocked={}
  for _,e in ipairs(items) do
    local x=e.lot
    if e.discrepancy or x.left<0 or x.balance<0 or x.left>x.quantity or x.balance>x.cost
        or (x.banked or 0)<0 or (x.banked or 0)>x.left or (x.bankedCopper or 0)<0
        or (x.bankedCopper or 0)>x.balance then
      blocked[e.index]=true
    end
  end
  l.quarantined=next(blocked) and blocked or nil
end

local function paidFull(row,post)
  if not row.receiptID or not AP.Reconciliation.VerifiedProceeds(row)
      or AP.Accounting.SaleUnits(row)~=post.quantity
      or row.itemID~=post.itemID or (post.filled and post.filled~=post.quantity)
      or post.returnedUnits or post.remainderTo or row.returnCollectedAt then return end
  return true
end

-- Preserve superseded observations while removing them from the live end state.
function L.ResolvePaid(ch)
  local posts=ch.craftLedger and ch.craftLedger.posts or {}
  local paid,active,receiptCounts={}, {}, {}
  for _,row in ipairs(ch.active or {}) do active[tostring(row.auctionID)]=true end
  for _,pool in ipairs({ch.sold or {},ch.deleted or {}}) do
    for _,row in ipairs(pool) do
      if row.receiptID then receiptCounts[row.receiptID]=(receiptCounts[row.receiptID] or 0)+1 end
      if row.auctionID and (row.sold or row.deletedKind=="sold") then
        local id=tostring(row.auctionID)
        if paid[id]~=nil then paid[id]=false else paid[id]=row end
      end
    end
  end
  local fillOwners={}
  for id,p in pairs(posts) do
    for receipt in pairs(p.fills or {}) do
      if fillOwners[receipt]~=nil then fillOwners[receipt]=false else fillOwners[receipt]=id end
    end
  end
  local changed=0
  for i=#(ch.ended or {}),1,-1 do
    local old=ch.ended[i]
    local id=tostring(old.auctionID)
    local row,p=paid[id],posts[id]
    local receipt=row and row.receiptID
    if p and row and paidFull(row,p) and not old.returnCollectedAt and not active[id]
        and receiptCounts[receipt]==1 and (fillOwners[receipt]==nil or fillOwners[receipt]==id)
        and (not p.ended or p.awaitingReturn) then
      L.Migrate(ch)
      ch.lifecycle.supersededEnds=ch.lifecycle.supersededEnds or {}
      local history=ch.lifecycle.supersededEnds
      history[#history+1]={auctionID=id,at=time(),receipt=receipt,reason=p.ended,
        previous=old,action="FULL_VERIFIED_PAYMENT",awaitingReturn=p.awaitingReturn}
      p.ended,p.awaitingReturn,p.unresolved,p.activeObserved,p.fillLimit=nil,nil,nil,nil,nil
      p.ownedSold,p.soldAt=true,p.soldAt or row.soldAt
      table.remove(ch.ended,i)
      changed=changed+1
    end
  end
  return changed
end
