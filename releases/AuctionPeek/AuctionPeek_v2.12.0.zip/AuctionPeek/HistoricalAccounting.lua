local _, AP = ...
local H = {}
AP.HistoricalAccounting = H

local function integer(v)
  return type(v)=="number" and v>=0 and v%1==0
end

local function report(ch,entry)
  local j=ch.accountingReview
  j.corrections[#j.corrections+1]=entry
end

local function unknownPost(p)
  local n=0
  for _,a in ipairs(p.parts or {}) do
    if a.source or not a.unknown or a.cost~=0 or a.reason~="UNKNOWN_ACQUISITION" then return end
    n=n+a.n
  end
  return n>0 and n==p.quantity
end

local function planGroup(ch,id,buys,observations,posts,active,paid,origins)
  table.sort(buys,function(a,b)
    if a.boughtAt~=b.boughtAt then return a.boughtAt<b.boughtAt end
    return a.purchaseID<b.purchaseID
  end)
  local first,last=buys[1].boughtAt,buys[#buys].boughtAt
  if last-first>180 or origins[id] then return end
  local n=0
  local suffix,level=buys[1].itemSuffix or 0,buys[1].itemLevel
  for _,b in ipairs(buys) do
    if (b.itemSuffix or 0)~=suffix or b.itemLevel~=level then return end
    n=n+b.quantity
  end

  -- Corroborate a complete zero-to-full inventory wave. Generic receipt
  -- chat can be coalesced across adjacent observations, but other sources,
  -- gaps, or a premature withdrawal make attribution ambiguous.
  local before,generic,arrived=0,0,nil
  for _,o in ipairs(observations or {}) do
    if o.at>=last and o.at<=last+120 then
      if o.bankOpen or o.before~=before or o.after<=before or o.after>n then return end
      for k,v in pairs(o.evidence or {}) do
        if k~="GENERIC_ITEM_RECEIPT" or not integer(v) then return end
        generic=generic+v
      end
      before=o.after
      if before==n then arrived=o.at;break end
    elseif o.at>=first and o.at<last then return end
  end
  if not arrived or generic~=n then return end

  local targets,total={},0
  local lastPost=arrived
  for _,entry in ipairs(posts or {}) do
    local key,p=entry.key,entry.post
    if p.at>=first then
      if p.at<arrived or p.at>arrived+7200 or active[key] or not unknownPost(p)
          or (p.itemSuffix or 0)~=suffix or (level and p.itemLevel and p.itemLevel~=level)
          or not (p.returnedUnits==p.quantity and p.returnedAt
            or paid[key] and AP.Accounting.SaleUnits(paid[key])==p.quantity
              and AP.Reconciliation.VerifiedProceeds(paid[key])) then return end
      targets[#targets+1]=entry
      total=total+p.quantity
      lastPost=math.max(lastPost,p.at)
    end
  end
  if total==0 or total>n then return end
  for _,entry in ipairs(targets) do
    if entry.post.returnedAt and entry.post.returnedAt<=lastPost then return end
  end
  -- The journal must cover listing withdrawals within the retained time range.
  -- A complete net withdrawal isn’t necessary because paid/returned post rows
  -- account for the rest, but a contradictory movement defeats the inference.
  for _,o in ipairs(observations) do
    if o.at>arrived and o.at<=lastPost then
      if o.bankOpen or o.after>=o.before then return end
      for k in pairs(o.evidence or {}) do if k~="AUCTION_POST" then return end end
    end
  end
  table.sort(targets,function(a,b)
    if a.post.at~=b.post.at then return a.post.at<b.post.at end
    return tonumber(a.key)<tonumber(b.key)
  end)
  return arrived,targets
end

function H.RecoverDeliveries(ch)
  local l=ch.craftLedger
  local observations=ch.inventoryReconciliation and ch.inventoryReconciliation.observations
  if not l or not observations then return 0 end
  local buys,events,posts,origins,active,paid,receiptCounts={},{},{},{},{},{},{}
  for _,x in ipairs(l.lots) do origins[x.itemID]=true end
  for _,b in ipairs(ch.buys) do
    if b.itemID and b.delivery and b.delivery.stage~="verified" and not b.priceEstimated and b.notifiedAH
        and integer(b.price) and integer(b.quantity) and b.quantity>0 and integer(b.purchaseID)
        and integer(b.boughtAt) and not l.purchases["p:"..b.purchaseID]
        and not (b.auctionID and l.purchases["a:"..b.auctionID]) then
      buys[b.itemID]=buys[b.itemID] or {}
      table.insert(buys[b.itemID],b)
    elseif b.itemID then origins[b.itemID]=true end
  end
  for _,o in ipairs(observations) do
    if buys[o.itemID] then
      events[o.itemID]=events[o.itemID] or {}
      table.insert(events[o.itemID],o)
    end
  end
  for _,r in ipairs(ch.active or {}) do active[tostring(r.auctionID)]=true end
  for _,pool in ipairs({ch.sold, ch.deleted}) do
    for _,r in ipairs(pool) do
      if r.receiptID then receiptCounts[r.receiptID]=(receiptCounts[r.receiptID] or 0)+1 end
      if r.receiptID and r.auctionID and (r.sold or r.deletedKind=="sold") then
        local id=tostring(r.auctionID)
        if paid[id]~=nil then paid[id]=false else paid[id]=r end
      end
    end
  end
  for id,r in pairs(paid) do if r and receiptCounts[r.receiptID]~=1 then paid[id]=false end end
  for k,p in pairs(l.posts) do
    if buys[p.itemID] and p.at then
      posts[p.itemID]=posts[p.itemID] or {}
      table.insert(posts[p.itemID],{key=k,post=p})
    end
  end
  local ids,count={},0
  for id in pairs(buys) do ids[#ids+1]=id end
  table.sort(ids)
  for _,id in ipairs(ids) do
    local group=buys[id]
    local at,targets=planGroup(ch,id,group,events[id],posts[id],active,paid,origins)
    if at then
      local evidence={method="ISOLATED_PURCHASE_AND_INVENTORY_WAVE",itemID=id,at=at,purchases={},postings={},
        units=0,copper=0}
      for _,b in ipairs(group) do
        b.delivery={version=3,stage="verified",collectedAt=at,prior=b.delivery,
          evidence={method=evidence.method,at=at}}
        b.deliveryInferred=true
        evidence.purchases[#evidence.purchases+1]=b.purchaseID
        evidence.units,evidence.copper=evidence.units+b.quantity,evidence.copper+b.price
        count=count+1
      end
      AP.Crafts.ImportPurchases(ch,group)
      local index=1
      local returns={}
      for _,t in ipairs(targets) do
        local p=t.post
        local needed,parts=p.quantity,{}
        while needed>0 do
          local x=l.lots[l.purchases["p:"..group[index].purchaseID]]
          local qty=math.min(x.left,needed)
          local part=AP.CostPool.Take(x,qty,"HISTORICAL_PURCHASE_FIFO",true)
          parts[#parts+1]=part
          if p.returnedUnits then returns[#returns+1]={lot=x,part=part} end
          needed=needed-qty
          if x.left==0 then index=index+1 end
        end
        p.priorUnknownAllocation=p.parts
        p.parts=parts
        p.poolReconciledAt=time()
        evidence.postings[#evidence.postings+1]=t.key
      end
      for _,r in ipairs(returns) do
        local x,a=r.lot,r.part
        x.left,x.balance=x.left+a.n,x.balance+a.cost
        x.inferredReturn=true
      end
      report(ch,evidence)
    end
  end
  return count
end

function H.RecoverReportedMageweave(ch)
  local l=ch.craftLedger
  local post=l and l.posts["230429778"]
  if not post or post.at~=1795720175 or post.itemID~=4339 or post.quantity~=12
      or post.returnedUnits or post.remainderTo or #(post.parts or {})~=12 then return 0 end
  local missing,plans,known,units={}, {},0,0
  local expected={1359,1360,1389,1390,1391,1392,1393,1394,1395,1396,1397,1398}
  local first
  for i,p in ipairs(post.parts) do
    local x=l.lots[p.source]
    if p.source~=expected[i] or p.cost~=0 or p.n~=1 or not x or x.itemID~=4339
        or x.quantity~=1 or not x.parts or x.cost~=0 then return 0 end
    local n=0
    for _,a in ipairs(x.parts) do
      if a.itemID~=4338 or a.cost~=0 or not integer(a.n) then return 0 end
      local input=l.lots[a.source]
      if input and input.looted and not a.unknown then known=known+a.n
      elseif a.unknown and not a.source and a.reason=="INSUFFICIENT_TRACKED" then
        missing[#missing+1]=a
        units=units+a.n
        first=math.min(first or x.at,x.at)
      else return 0 end
      n=n+a.n
    end
    if n~=5 then return 0 end
    if x.unknown then
      plans[i]=AP.Lifecycle.RepricePlan(ch,p.source)
      if not plans[i] then return 0 end
    end
  end
  if known~=23 or units~=37 then return 0 end
  local evidence={method="PLAYER_CONFIRMED_TRADE_AND_CRAFT_INPUTS",itemID=4338,units=37,copper=0,
    auctionID="230429778",at=first,latestPossibleAcquisition=first,craftLots={}}
  local x=AP.Crafts.ExternalLot(ch,4338,37,0,first,"giftTrade",nil,evidence)
  x.left=0
  for _,p in ipairs(missing) do p.source=x.index;p.unknown=nil;p.method=evidence.method end
  for i,plan in pairs(plans) do
    AP.Lifecycle.Reprice(plan,0)
    evidence.craftLots[#evidence.craftLots+1]=expected[i]
  end
  table.sort(evidence.craftLots)
  report(ch,evidence)
  return 1
end

function H.RecoverObservedReposts(ch)
  local l=ch.craftLedger
  local observations=ch.inventoryReconciliation and ch.inventoryReconciliation.observations
  if not l or not observations then return 0 end
  local rows,blocked,paid,receiptCounts={}, {}, {}, {}
  for _,r in ipairs(ch.active) do blocked[tostring(r.auctionID)]=true end
  for _,r in ipairs(ch.ended) do
    local id=tostring(r.auctionID)
    if rows[id]~=nil then rows[id]=false else rows[id]=r end
  end
  for _,pool in ipairs({ch.sold,ch.deleted}) do
    for _,r in ipairs(pool) do
      local id=tostring(r.auctionID)
      if r.receiptID then receiptCounts[r.receiptID]=(receiptCounts[r.receiptID] or 0)+1 end
      if r.auctionID and (r.sold or r.deletedKind=="sold") then
        if paid[id]~=nil then paid[id]=false else paid[id]=r end
      elseif r.deletedKind=="listed" then blocked[id]=true end
    end
  end
  local count=0
  local _,entries=AP.CostIntegrity.Audit(ch)
  for id,sale in pairs(paid) do
    local prior=sale and sale.repostOf and tostring(sale.repostOf)
    local row=prior and rows[prior]
    local old,new=prior and l.posts[prior],l.posts[id]
    if row and old and new and sale.receiptID and receiptCounts[sale.receiptID]==1
        and tostring(row.repostedAs)==id and row.endedReason=="canceled" and not paid[prior]
        and not (blocked[prior] or blocked[id] or row.returnCollectedAt)
        and new.itemID==old.itemID and old.quantity==new.quantity
        and (old.itemSuffix or 0)==(new.itemSuffix or 0) and old.itemLevel==new.itemLevel
        and old.ended=="canceled" and old.endedAt and old.awaitingReturn and not (old.soldAt or old.filled
          or old.saleNoticeAt or old.gross or old.returnedUnits or old.remainderTo)
        and new.at>old.endedAt and AP.Accounting.SaleUnits(sale)==new.quantity
        and AP.Reconciliation.VerifiedProceeds(sale) and not (new.remainderTo or new.returnedUnits)
        and unknownPost(new) and #(old.parts or {})==1 and AP.Lifecycle.BalancedPost(ch,old,entries) then
      local x=l.lots[old.parts[1].source]
      if x and x.quantity==old.quantity and x.left==0 and x.balance==0 and x.cost==old.parts[1].cost
          and x.purchase and not (x.unknown or x.estimate or old.parts[1].unknown) then
        local arrival,withdrawal,uncertain
        for _,o in ipairs(observations) do
          if o.itemID==new.itemID and o.at>=old.endedAt and o.at<=new.at+2 then
            if not arrival and not o.bankOpen and o.before==0 and o.after==new.quantity
                and o.at<=new.at and o.evidence and o.evidence.GENERIC_ITEM_RECEIPT==new.quantity
                and next(o.evidence)=="GENERIC_ITEM_RECEIPT" and next(o.evidence,"GENERIC_ITEM_RECEIPT")==nil then
              arrival=o
            elseif arrival and not withdrawal and not o.bankOpen and o.before==new.quantity and o.after==0
                and math.abs(o.at-new.at)<=2 then withdrawal=o
            else uncertain=true end
          end
        end
        for key,p in pairs(l.posts) do
          if key~=id and key~=prior and p.itemID==new.itemID and p.at and p.at>=old.endedAt and p.at<=new.at+2 then
            uncertain=true;break
          end
        end
        if arrival and withdrawal and not uncertain then
          local basis=old.parts[1]
          local part={}
          for k,v in pairs(basis) do part[k]=v end
          part.estimate,part.method,part.returnedFrom=true,"INFERRED_CORROBORATED_REPOST",row.auctionID
          old.returnedUnits,old.returnedAt,old.awaitingReturn=old.quantity,arrival.at,nil
          old.returnAllocation=part.method
          row.returnCollectedAt=arrival.at
          row.returnInferred=true
          new.priorUnknownAllocation=new.parts
          new.parts={part}
          new.poolReconciledAt=time()
          report(ch,{method=part.method,at=time(),auctionID=id,previousAuctionID=prior,
            lotID=x.index,purchaseID=x.purchase,receiptID=sale.receiptID,units=part.n,copper=part.cost,
            arrival=arrival.at,withdrawal=withdrawal.at})
          count=count+1
        end
      end
    end
  end
  return count
end
