Auction Peek 2.6.1 - Auto DE in Flip
- Revalidated automatic DE results appear in Flip and leave DE Test; manual, batch, stale and unresolved observations remain in DE Test.
- Display-only projection; no new receipts or ledger allocations. Conflicting evidence remains in review.
- Flip profit excludes returned deposits. Click Auto DE row or grouped member to disable attribution; it returns to DE Test.

Auction Peek 2.5.55: Offline and Cross-ledger Safety Update (2026-11-24)

- Hide currently verified player-confirmed DE receipt batches from Unmatched Flip Receipts and its count.
- Refuse manually linking a DE-claimed receipt via Flip until its DE confirmation is revoked.
- Guard automatic single-receipt reconciliation against stealing an already-confirmed DE receipt.
- Display mail-only rows as Paid [time] instead of implying that mail collection is the sale time.
- Show exact sale time as unknown when mail is the only source. Snapshot-only sales show Seen.
- On the first full owned-auctions snapshot after login, missing saved listings remain unconfirmed;
  annotate the gap instead of treating it as proof of sale, expiration, or cancellation.
- Retain passive posting quantity evidence (max observed vs known created quantity) without
  extrapolating any missed original stack count or changing financial allocations.
- Leaves Bought / Flip / DE confirmed batch figures, existing receipts, prices and SavedVariables intact.

OFFLINE SALES
The game cannot replay every offline transition after login. The addon must NOT invent an
exact sale time, auction ID, original stack size, or a cost allocation. Mail payment is hard
evidence of a sale; first post-login owned snapshot is only evidence of the current state.
When ambiguous, retained receipts and ended rows remain available for audit.

Auction Peek 2.5.54 - evidence-first DE confirmation

When confirming a historical DE batch, the modal now shows original AH purchase IDs, unit prices and purchase times; each bag/loot-verified DE output; every matched mail receipt with quantities, AH fees, deposit returns and collected net; and ONE combined cost/profit calculation. It clearly labels that the historical original auction ID and canonical inventory allocation remain unproven. Confirm and revoke still revalidate existing source evidence and never rewrite Buy History, mail, Flip or inventory lots.

v2.5.53 – User-confirmed shared DE receipt settlement
- Existing 2.5.52 diagnostics identify one candidate batch per output type and complete AH input pool.
- Click Confirm Shared Batch for an explicitly reviewed historical case. The saved record is revalidated on every read, is reversible, and prevents a mail receipt being claimed by two DE groups.
- Supports multiple purchased items -> multiple DEs -> one material batch -> multiple aggregated sale receipts; source costs counted once per DE and group proceeds counted once per batch.
- Does NOT fabricate an original posted auction ID, edit a receipt, rewrite purchased lots, or create Flip income. The global Unmatched counter is independent and may remain nonzero.
- An unconfirmed candidate remains unverified; confirmation is proof of player attribution only, not proof of a canonical auction posting.
- New selling/posting capture behavior is NOT altered: older posts cannot safely recover an unobserved original quantity from partial snapshots.
- User must back up SavedVariables and /reload; confirm only the exact groups they personally posted.

v2.5.52 – Read-only DE receipt batch diagnostics
- Displays possible combined payment batches when a complete, equal-cost AH purchase pool produced the same material in multiple disenchants.
- Supports multi-fill payment evidence (e.g. 7 + 2 units) without inventing a 9-unit auction ID.
- Keeps a separately priced/found-material sale outside the proposed batch.
- Also displays two-unit material receipts as candidates even if the AH only retained a one-unit posting record.
- Does NOT link receipts, rewrite auction IDs, modify inventory lots, recognize profits, or change Flip accounting.
- Candidate grouping deliberately requires the full AH input pool, bag/loot verification, zero pre-existing material, exactly matching paid unit counts, and a unique per-unit price group. Ambiguous data remains unverified.

Auction Peek v2.5.51 — Verified equal-price AH purchase pools (WoW Forever)

Changes from v2.5.50:
- DE Test can show a verified unit acquisition cost when multiple identical AH items
  were bought within 15 minutes at the same unit price, the pre-cast bag held
  exactly that many items, and clean subsequent disenchants follow the observed
  held-count sequence (e.g. 3 -> 2 -> 1).
- Example: AH purchases #273/#274/#275 at 35s99c each -> three clean
  Heavy Mithril Gauntlet disenchants. Each DE preview displays 35s99c.
- Purchase IDs are presented as a POOL, never falsely attributed to individual
  physical gauntlets. No purchase source is written to the saved DE rows.
- Mixed prices, estimated/unconfirmed purchases, changed bag counts and other
  ambiguous histories remain unverified. No new realized-profit assertions.
- This is read-only DE Test preview logic. SavedVariables, Buy History, Flip,
  receipts, and the canonical craft/inventory lot ledger are not mutated.

Auction Peek v2.5.50 — AH-purchased DE-only view (WoW Forever)

Change from v2.5.49:
- DE Test displays only cast observations backed by a confirmed AH purchase of the disenchanted input item within the existing 15-minute preview window.
- Keeps unverified DEs visible when multiple identical AH purchases or held copies prevent unique cost identification. The UI displays the number of matching recent AH purchases without attributing cost.
- Limits visible candidate disenchants to the recorded AH-purchased unit count, and reserves previously linked purchases before weaker candidates.
- Disenchants from looted or crafted items remain in SavedVariables but are hidden from the AH-only DE view. No history is erased.
- Existing profit, sale receipt, input cost, Flip and inventory-lot handling is unchanged.
- Limitation: AH gear held more than 15 minutes before disenchanting can remain hidden unless independently linked; this filter does not establish ownership from item GUIDs.
- Install by replacing the AuctionPeek addon folder, keeping your SavedVariables untouched.

v2.5.48 — Vendors archive / Auction Companion integration
- Vendors archive now prefers AuctionCompanionAPI market prices and opens AC for row AH Search; Auctionator is only a fallback when AC is not installed.
- Scan Vendor List uses AC 0.1.13+ StartItemListScan, restricted to eligible unique item IDs in this archive. It does not request a market-wide Full Scan.
- The scan honors vendor faction, BoP, and known vendor price filters; it deliberately includes items with missing AH quotes. The displayed scan count is calculated at runtime, not hardcoded to 574.
- Live scans show confirmed progress and unresolved counts. Cached prices from older scans never silently stand in for pending/failed targeted results.
- AC's newer complete Full Scan can supersede a previous targeted scan, including when an item is no longer priced.
- No transaction, saved-ledger, DE test, or flip accounting data is changed.
- When AC is not installed, prior Auctionator price/search integration remains available for compatibility.

=== 2.5.46: STRICT READ-ONLY AUTOMATIC DE ATTRIBUTION ===
Based on 2.5.45 receipt repair. DE Test can automatically *attribute* an
unambiguous purchased single-input disenchant to exactly one post and one
full-stack verified mail receipt, ONLY when input acquisition is unique,
bag/loot verification agrees, output stock was zero, and no competing
auction/acquisition or DE claim exists. This is a read-only diagnostic profit;
no inventory lot is reassigned and nothing is moved into Flip.
Manual confirmations have priority and are never silently overwritten.
Only new casts following installation are considered for auto matches.
Mixed inventory, multiple candidates, incomplete/split receipts, missing
history or canceled postings remain ? Review. Auto matches store the evidence,
are rechecked before display, and can be disabled/retried via the Auto evidence
row. The DE Test profit column has more room and avoids wrapping; version
labels read the TOC metadata rather than separate hardcoded strings.

2.5.44 — Unmatched Flip Receipts review: reviewed and grouped existing saved writ payments (mail:166/167 were already paid and assigned); adds a priority counter, a read-only candidate review, explicit double-click manual linking, dismiss and guarded undo. Original receipts preserved for undo; no implicit auto-match, posting sort request, cost-lot rewriting, or DE cost changes. The review button is visible on sufficiently wide windows; /ap unmatched always works.
2.5.43 — Two-unit writ/stack tracking: capture owned posting metadata on creation, retain exact-ID quantity for sold events, recheck uniquely-matched full-stack payments after AH updates, and enable carefully guarded manual matching of complete multi-unit invoices. No inferred prices or automatic ambiguous merges.

NEW IN 2.5.42
- Compatibility fix: Auction Peek no longer sends automatic owned-auction queries while Blizzard's auction window is open. This prevents forced native sort resets and unnecessary flickering of both windows.
- Existing Blizzard owned-auction updates are observed without a new query. Repeated unchanged updates and native sort-only events no longer rebuild Auction Peek's list.
- Expiration, cancellation, posting and sales events remain tracked; no transaction histories or accounting allocations are migrated or modified.
- Use Auction Peek's Refresh button (or /ap refresh) only when an explicit owned-auctions query is needed. Since the Forever API uses a default sort for this query, the native sort can reset once when Refresh is clicked.

NEW IN 2.5.41
- DE Test: click an actionable ? on Input cost candidate or a Possible output
  auction, review the exact evidence, and manually Confirm Link or Cancel.
- Click a manually confirmed green marker to review and Undo Link. Manual
  confirmations are saved to each DE cast, survive reload, are revalidated
  against purchases and postings, and cannot claim one purchase or auction
  for two different DE sessions.
- Fully paid and quantity-matched manually linked DE output + purchase shows
  a MANUAL profit/loss estimate. Canonical auction cost lots, sales, mail and
  Flip are deliberately untouched. Unknown bag timing remains uncertain.
- The DE header no longer displays Flip's Show time checkbox; fixes an
  overlapping header/first-row problem and resets scroll-frame anchors.

NEW IN 2.5.40
- DE-output sales are confined to DE Test, not included in Flip accounting
  until output-to-cost matching is trustworthy.
- DE Test displays Flip-style summary columns: output item, diagnostic input
  cost, verified possible-auction net, profit (unverified), possible auction ID.
- Clicking the summary row or possible auction ID expands the same diagnostic
  sections; no cost lots or receipts are modified.
- Known source costs and matching auction receipts remain separate claims;
  an apparent sale does not produce DE profit until source allocation is proven.
- Replaced the unicode verified-check glyph with a Blizzard texture so the
  green status no longer appears as a missing-font square.

NEW IN 2.5.39
- Verified DE output sales that are not ordinary purchased/crafted resale lots
  appear in Flip as DE: cost-review rows, with real collected mail proceeds.
- Display is strictly read-only: mixed old/new dust and input gauntlet cost are
  still unverified, therefore DE profit is NOT computed or counted.
- Only unique candidate listings inside the matching disenchant time window,
  no larger than the recorded DE output, qualify; existing Flip rows never
  duplicate. Grouped Flip rows continue showing unknown cost.
- Auction-ID search finds these review rows. SavedVariables are unchanged.

NEW IN 2.5.38
- DE Test candidate auction matches are limited to listings posted before the
  next recorded disenchant yielding the same output item. This prevents later
  Vision Dust auctions from appearing as candidates for older DE sessions.
- Ambiguous delayed or mixed-inventory DE listings remain unresolved rather
  than being automatically linked, and no SavedVariables costs are modified.
- Search bars now match auction IDs in Listed, 24h, All Time, Buy History,
  and Flip. Paste #123456789 to search auction IDs exclusively; plain digits
  continue matching item IDs and auction IDs.
- Auction ID lookup also works in grouped Flip rows through their member IDs.

NEW IN 2.5.37
DE Test expandable rows now show high-contrast confidence symbols: green ✓ is
recorded/verified evidence, yellow ? is a candidate or pending verification,
and red ! indicates a demonstrable inconsistency in saved auction data.
Hover any marked line for the specific reason. The row summary indicates the
strongest issue and each expanded entry counts confirmed/review/error findings.
No cost allocations, receipt links, or SavedVariables are altered by this UI.
Corrected version text on main panel, Settings, and Supply windows.

NEW IN 2.5.36
DE Test now displays each tracked disenchant as a clickable expand/collapse row.
Expanded entries are divided by dashed SOURCE & COST, DISENCHANT RESULTS,
and AUCTION / PAYMENT headings. Hover input/output rows for native item
information. Source cost remains diagnostic, receipt matches are previews,
and no cost lots, auction links, payment matches, or SavedVariables are altered.

NEW IN 2.5.35
DE Test no longer hides a uniquely purchased disenchant merely because an immediate auction posting changed bag counts before the eight-second verification. Such rows remain Unresolved, show a read-only Buy History cost candidate, and never assign the DE cost to mixed old/new dust sales automatically. No SavedVariables migration or accounting rewrite.

Auction Peek 2.5.34 — WoW Forever (Interface 16001)
================================================

INSTALL
1. Back up WTF/Account/<account>/SavedVariables/AuctionPeek.lua.
2. Extract AuctionPeek/ into World of Warcraft/_forever_/Interface/AddOns/,
   replacing the previous addon. Keep SavedVariables unchanged.
3. /reload; /ap opens Auction Peek; /ap search focuses the history search.

NEW IN 2.5.34
Prevent the Flip window from crashing after an auction cancellation event is received
before its listing quantity has been observed. Unobserved postings remain
unresolved; no historical purchases, sale receipts, or costs are rewritten.

NEW IN 2.5.33
Combine same-ID sold lines in a complete owned-auction scan when quantities and prices account for the posted stack. Show pending proceeds until payment. Recover the two reported Gray Dye listings at their separate unit prices.

NEW IN 2.5.32
Hover a main table row for the item tooltip. Hold Shift to add Auction Peek history and click instructions. Release Shift to return to the item tooltip.

NEW IN 2.5.31
Restore buy in Buy History records a missed vendor purchase with an optional unit cost. Restore the second reported Gray Dye stack separately. Match compatible split invoices for the reported sale when their quantities total the original 20.

NEW IN 2.5.30
Check all vendor items gained together. Allow small per-stack rounding differences on a single observed buy and store the actual copper spent. Restore the reported Gray Dye purchase for #181419023. /ap graydye <unit price in copper> sets its missing cost.

NEW IN 2.5.29
Track bulk vendor buys using observed bag gains and the matching copper charge even when the buy call is missed. Keep bag and money baselines together through merchant close.

NEW IN 2.5.28
Click a sold auction ID to assign a qualifying single-copy vendor or AH purchase when its recorded cost is missing. Each confirmed purchase can fund one sale.

NEW IN 2.5.27
Click a sold auction ID to confirm the craft cost from an eligible earlier listing. The full craft record follows the confirmed repost. Automatic reserved-craft transfer also recognizes expired listings.

NEW IN 2.5.26
Click an unmatched receipt ID, select its sold auction ID, and click Confirm. You can also use /ap match mail:<number> <auctionID> to confirm a paid single-item receipt for a possible crafted repost with missing listing details. The receipt establishes proceeds. Craft cost requires separate evidence.

NEW IN 2.5.25
Capture exact single-item owned listing details at creation when available. Flip flags a possible crafted repost when a sparse sale has one recent reserved craft candidate. Its cost and receipt stay unconfirmed.

NEW IN 2.5.24
Paced collection reads each selected letter and refreshes the inbox on completion.

NEW IN 2.5.23
Estimate the cost of a paid single-item sale when identical vendor purchases balance the unassigned listed and sold copies.

NEW IN 2.5.22
Distinguish raw loot sales from resales when partial listings draw on mixed stock. Preserve ambiguous source flags across returns.

NEW IN 2.5.21
Show the cost of a corroborated full-stack sale in Flip while payment is pending, even after a conflicting cancellation status.

NEW IN 2.5.20
Restore the confirmed Mageweave batch and recognize quantity suffixes on return mail. Carry a reserved single craft into its uniquely linked, promptly reposted auction.

NEW IN 2.5.19
DE Test shows disenchants with a positive purchase or crafting cost candidate.

NEW IN 2.5.18
Reconcile full commodity stacks with a matching payment despite a conflicting cancellation. Restore the remaining three confirmed Runecloth bolts to their sold listing.

NEW IN 2.5.17
A repost link alone no longer qualifies an unknown-source sale for Flip.

NEW IN 2.5.16
Recover fully paid split commodity sales from compatible invoices when no competing listing or collected return exists.

NEW IN 2.5.15
DE Test previews partial commodity receipts by corroborated unit price and shows invoice quantities.

NEW IN 2.5.14
Inspector shows the allocated purchase and cost. Single-unit purchase lots retain the collected return auction ID on their next allocation.

NEW IN 2.5.13
Show confirmed single-item repost sales while awaiting mail and trace purchase cost across recorded repost links.

NEW IN 2.5.12
Show the inferred cost of the reported overnight Lesser Mana Oil formula repost in Flip.

NEW IN 2.5.11
Show verified single-item sales with an unresolved cost source and earlier vendor purchase history in Flip.

NEW IN 2.5.10
DE Test checks recent verified purchases for the cost of disenchanted gear.

NEW IN 2.5.9
Match equal seller payouts across mailbox visits within the auction evidence window. Release original material costs on confirmed canceled or expired mail withdrawals, including tracked partial stacks.

NEW IN 2.5.8
Recover five tracked bolts used in the audited Runecloth Bag. Resolve separate crafted listings and equal payouts across nearby mailbox scans.

NEW IN 2.5.7
Retry single-unit seller invoices after an offline AH refresh. Group equal payouts by price and preserve ambiguous returns.

NEW IN 2.5.6
DE Test records zero when an output was absent from a successful pre-cast bag scan.

NEW IN 2.5.5
Protect full-stack owned sale confirmations and reconcile the audited Dream Dust receipt.

NEW IN 2.5.4
DE Test shows conflicting sale and listing records, with possible unlinked receipts when price, quantity and timing fit.

NEW IN 2.5.3
DE Test compares player disenchant casts, personal loot and bag changes. Costs are diagnostic candidates only.

NEW IN 2.5.2
Repaint the visible list after moving or resizing the window, including when scrolled near the bottom.

NEW IN 2.5.1
The resize grip follows cursor movement from the current window size and keeps the upper-left corner fixed.

NEW IN 2.5.0
Click the far-right auction ID in Flip, 24h or All Time to inspect the sale. Click a mail ID to inspect an unlinked receipt. Expanded craft and grouped auction lines open the same inspector.

NEW IN 2.4.24
Identical single-item payouts can settle together when every recent owned sale and invoice is accounted for. The sale tooltip identifies the group.

NEW IN 2.4.23
* Shift-hover in the vendor archive and history shows the native item tooltip without equipped-item comparison panels.

NEW IN 2.4.22
* Vendor faction tags and saved Hide Alliance / Hide Horde filters use observed Forever reactions. [?] after a faction letter means the other side is unverified. Both-faction vendors remain visible.

NEW IN 2.4.21
* Draw auction IDs on a dedicated line. Show time switches the Sold column between elapsed and exact time in 24h and All Time.

NEW IN 2.4.20
* Show auction IDs in Flip, 24h and All Time using a shared header checkbox. Unlinked receipts show the mail reference. Expand grouped flips for individual auction IDs.

NEW IN 2.4.19
* Restore the confirmed Formula repost cost and payment for auction #165294009 on login.

NEW IN 2.4.18
* Unpriced crafting materials count as 0c in existing and future crafts. Flip uses the recorded material spend for profit.

NEW IN 2.4.17
* Craft costs count recorded personal loot at 0c and show the looted quantity in the material breakdown.

NEW IN 2.4.16
* Moved Open All (paced) to the center of the inbox header, below the title.

NEW IN 2.4.15
* Optional Open All (paced) under the inbox. One pickup at a time, with one second after confirmation. Click again to stop. COD and GM mail are skipped. Unreadable auction payments and unconfirmed pickups pause the run.

NEW IN 2.4.14
* Build vendor offers and map locations on first archive open. Refresh history on display and combine bursts of item-info updates.

NEW IN 2.4.13
* Cross-check canceled single-stack auction returns on item withdrawal when the ended listing is identifiable.

NEW IN 2.4.12
* Recover the verified 60-filet batch in Flip from its combined seller invoice and recorded raw-fish costs.

NEW IN 2.4.11
* Vendor Archive excludes bind-on-pickup items by default. Unresolved binding waits for Forever client item data.

NEW IN 2.4.10
* Single-item auto-matches require a dated candidate within 24 hours of the first invoice observation, measured from expected payout or the recorded sale/end. Older payments are retained for review.

NEW IN 2.4.9
* Capture late-loading seller invoices before comparing the inbox after a withdrawal.

NEW IN 2.4.8
* Vendor Archive uses public in-game Forever merchant scans. Prices are observed per bundle and may vary by reputation. Coverage depends on public visits.

NEW IN 2.4.7
* Automatic single-item invoice review on login, withdrawal and owned auction snapshots.
* An AH-confirmed single paid within three minutes of its expected payout can outrank earlier unconfirmed listings.
* Hold Shift over vendor or history items for the native item tooltip.

NEW IN 2.4.6
* Hide duplicate items keeps the cheapest matching unit offer, breaking ties by available same-continent distance and then catalog order.
* AH Search starts an exact Auctionator shopping search for the row at an open auction house.

NEW IN 2.4.5
* Separate saved checkboxes for missing Auctionator and vendor prices.

NEW IN 2.4.4
* Vendor archive remembers the missing-base-price filter and AH-minus-vendor sort direction.
* Refresh reloads Auctionator prices. Unknown differences sort last.

NEW IN 2.4.3
* Map uses the OpenMap tracked waypoint or Blizzard user waypoint for the vendor.
* Wait for the map to open before placing the destination.

NEW IN 2.4.2
* Map buttons open the world map at a known vendor spawn with a labeled yellow star.

NEW IN 2.4.1
* Vendors searches a bundled public Forever catalog with base prices and local Auctionator prices.
* Rapid confirmed non-stackable vendor buys receive individual purchase IDs.

NEW IN 2.4.0
* Vendors or /ap vendors opens a searchable character-specific archive of coin-priced merchant offers.
* Compare vendor and cached Auctionator unit prices. Positive difference means AH costs more, before fees.

NEW IN 2.3.29
* Preserve competing single-item invoices and report unmatched withdrawals in chat.
* Reserve stack invoice IDs when restoring counters or reconciling individual sales.

NEW IN 2.3.28
* Show the verified 44-unit Redgill payout across its two sales, allocated by unit.
* Expanded original and repost rows identify where the last 21 units went.

NEW IN 2.3.27
* /ap reconcile rechecks saved single-item receipts for unique unpaid auctions.
* Flip can display the audited last 21 Redgill from the matching invoices and unused material lots.

NEW IN 2.3.26
* /ap audit checks visible history for repeated IDs, unlinked receipts and sold units missing from Flip.
* Mail matching checks closed and paid auction IDs across saved views before assigning a receipt.

NEW IN 2.3.25
* Optional audited bag cost transfer: /ap repost 150798168 158013099.
  Use only if the second auction was the returned bag from the first.

NEW IN 2.3.24
* Confirm exact-ID notifications through the normal sale path when chat arrived
  first. A prompt chat echo after an exact ID cannot claim another active copy.

NEW IN 2.3.23
* Single-item sale notifications with an auction ID confirm the tracked sale
  before payment. Correct two audited pending formula sales on login.

NEW IN 2.3.22
* Correct the confirmed one-copy Redgill recipe purchase and its stock count.
  Single-auction purchases use one unit when item data confirms a stack limit of one.

NEW IN 2.3.21
* Buy History shows Vendor or AH next to Avg/Unit. Hide vendor purchases
  filters the list and its spend summary.

NEW IN 2.3.20
* Sold history shows all-time units sold alongside individual stack sizes.
  Amount headings align with their values.

NEW IN 2.3.19
* Grouped Flip rows show collected proceeds and the profit on paid sales in
  yellow parentheses while any payments are pending.

NEW IN 2.3.18
* Click a tracked crafted listing to inspect its materials and recorded costs.
  Crafted ingredients expand to show their own ingredients.

NEW IN 2.3.17
* A sold single-item auction in the owned AH snapshot restores its pending
  Flip row even when an earlier cancellation flag exists for that ID.

NEW IN 2.3.16
* Flip excludes canceled posts without evidence of sold units. Canceled posts
  are excluded from automatic whole-auction payment matching.

NEW IN 2.3.15
* Check the sold auction payout timer for single-item receipts. Correct the
  two audited formula payment links on login.

NEW IN 2.3.14
* Group by item summarizes single-item auctions as well as stacks. Expand
  the item to see each auction ID and its individual payment status.

NEW IN 2.3.13
* /ap match mail:NUMBER AUCTION_ID assigns a collected single-item receipt
  to one compatible unpaid auction chosen by the player.

NEW IN 2.3.12
* Only multi-unit posts are grouped. Single-unit auctions require an individual
  receipt match and keep separate rows with Group by item on or off.

NEW IN 2.3.11
* Identical single-item sales share unmatched verified payments in totals.
  Equal payouts settle each auction when all matching payments are collected.

NEW IN 2.3.10
* An active, unsold copy at the same price no longer blocks a unique sold
  auction from receiving its payout. Flip labels unmatched resale receipts.

NEW IN 2.3.9
* Optional Group by item view summarizes Flip auctions and lists their details.
  The audited combined Redgill receipt appears once in its group.

NEW IN 2.3.8
* Verified partial receipts allocate costs to sold units. Returned units stay
  outside AH profit. For a confirmed return reposted as one matching stack,
  use /ap repost OLD_AUCTION_ID NEW_AUCTION_ID to carry its remaining cost.

NEW IN 2.3.7
* Open All checks invoice counts and avoids ambiguous sale assignments.
  Verified mail with no unique sale stays in sale history.

NEW IN 2.3.6
* Flip has compact money columns and an optional 12-hour Sold at column.

NEW IN 2.3.5
* Flip rows show the quantity in each sale. The yellow all-time counter
  is hidden on this tab.

NEW IN 2.3.4
* Crafted stacks appear as one Flip row per sold auction. Expand the row
  to inspect the contributing craft batches and their materials.

NEW IN 2.3.3
* Flip shows direct resales only when a sold auction has recorded purchase
  units assigned to it. Buying or posting additional copies cannot add rows.
  Older unmatched sales remain in sale history. Buy History retains purchases.

NEW IN 2.3.2
* Flip shows After AH Cut between Paid / Mat Cost and Profit. Sales awaiting
  verified proceeds show Pending. Expand a craft for its gross sale price.

NEW IN 2.3.1
* Flip shows profit after the verified AH cut and the cost of units sold.
  Expand a craft to see proceeds and material cost. Pending receipts and
  unknown costs are labeled. Estimates carry ~. Returned deposits are excluded.
  Lost deposits on previous listings are outside this calculation.

NEW IN 2.3.0
* New gold-only vendor purchases appear in Buy History when the bag increase
  and copper spent match the quoted bundle price. Craft history identifies
  vendor and AH ingredients, including mixed sources. Vendor sales, buybacks
  and currency/barter purchases are outside this feature.

NEW IN 2.2.3
* Flip groups matching ingredients into one row. Click [+] beside a crafted
  ingredient to see the combined quantities and costs of its inputs.

NEW IN 2.2.2
* New crafts check carried reagent counts at cast start. If recorded stock
  exceeds the observed count, older excess stock is skipped for that craft.
  Identical items still use chronological cost allocation within eligible lots.
  If a usable pre-craft count is unavailable, recorded stock is used.
* Existing saved craft costs are preserved.

NEW IN 2.2.1
* Supported crafts stay in background history until a linked auction sale.
* For partially sold batches, Flip shows the quantity sold and its allocated
  cost. Expand a sale to see the full batch inputs and posting history.

NEW IN 2.2.0
* Flip shows observed, fixed-reagent, fixed-yield crafts. Click [+] for
  material quantities, allocated cost, source purchases and intermediate crafts.
* Costs follow the oldest recorded item lots first. Identical units can mix
  with gathered or previously owned stock. Allocation is a bookkeeping convention.
  Unknown inputs and estimated purchase prices are labeled. Source-batch details
  explain intermediate costs already included in the parent.
* New auction IDs observed at creation connect crafted quantities to listings
  and identified sales. Unmatched mail does not guess which bag sold.
  Older crafts cannot be recovered from purchase and sale records alone.

NEW IN 2.1.0
* Flip shows both transaction histories for items bought and sold on this character.
  Search or sort the history. ~ prices are estimates. The tab count is history rows.
* Sold badges count all-time sale transactions. xN+ indicates a minimum when
  unlinked receipts may overlap auction notifications. Listed retains its posting count.
* Duplicate auction, receipt and purchase IDs are reconciled for the Flip view.
  Separate same-price receipts remain separate. The view never writes history.

NEW IN 2.0.8
* Name-only seller receipts now show the item icon, tooltip and posting count
  when recorded auctions identify one exact-name variant on this character.
  Applies to existing receipts on reload and newly collected mail.

NEW IN 2.0.7
* Shift-left-click deletion uses a private Auction Peek confirmation window.
  Removed the assignment to the shared Blizzard popup registry at load.

NEW IN 2.0.6
* The gold xN counts distinct postings across all copies of the same variant,
  as in 2.0.4. Selling multiple identical copies can produce identical badges.
* Options > Show all-time item earnings on hover (default on) totals visible
  history's verified receipts for the character and item, regardless of tab
  or search. Uses gross less AH fees, excluding returned deposits and estimates.
  Receipt-only records match by exact item name when their item ID is missing.

NEW IN 2.0.4
* Clear beside the Buy History selection total clears every highlight,
  including purchases hidden by search, and restores the usual footer.

NEW IN 2.0.3
* Shift-right-click Buy History rows to highlight them and total their stack
  prices in the footer. Repeat to deselect, or switch tabs to clear all.
* Sorting, scrolling and searching retain selections. The footer counts
  selections hidden by search, estimated prices and missing prices.

NEW IN 2.0.2
* Remember the active profile by player GUID across realm label changes.
* A recovery companion can access the same profile as the All Time tab.

NEW IN 2.0.1
* Supply (or /ap supply) restores paired scans and existing 1.9 history.
* An optional per-item target accepts 2s, 2s 40c, or plain copper. Scan Both
  saves the targets and counts units with buyouts at or below each price.
  Hover the result to compare consecutive scans at the same target.
* Lowest unit buyout appears for new scans. Market supply changes alone
  cannot distinguish sales, expirations and cancellations.
* Auction Peek item rows show the latest matching verified gross sale per
  unit, quantity, total and recorded date when receipt quantity is known.
  Old single-unit receipts with uncertain quantity are omitted.

NEW IN 2.0.0 — LIVE HISTORY SEARCH AND SORT
* Type to filter the CURRENT tab: Listed, 24h, All Time or Buy History.
* Matches item names (partial, case-insensitive) or exact/partial item IDs.
* Clearing search restores the complete list. No auction house queries are
  performed by the search feature. Tab counts always reflect the full list.
* Sort by Item A-Z, Item Z-A, Newest, Oldest, Highest price, Lowest price,
  or Most listed (for non-purchase tabs). Each tab retains its own sort.
* Newest/oldest in Listed use first-observed posting dates, not guaranteed
  original posting times; price sort uses the recorded listing/receipt prices.
* Filtering 24h, All Time or Buy History recalculates totals for ONLY the
  matching rows. Verified gold and listing estimates remain separate.
* Optional setting shows overall totals on a second line while filtering.
* The visual search/sort row and the Shady shortcut can be hidden in settings.
* /ap search focuses the search field. Search text is session-only and is
  cleared if the search bar is disabled.

SHADY PRICE 1.1 — OPTIONAL FUTURE CONNECTION
* The small Shady button (or /ap shady) calls ShadyPriceAPI.OpenSearch()
  when that function exists. It does not require Shady to load Auction Peek.
* Shady v1.0.1 does not yet implement this API. Until Shady v1.1 provides
  it, the button explains what is missing and doesn't open a fake search.
* Hovering an item row shows WoW's native item tooltip when item details are
  available. Shady's existing item-tooltip hook appends its own market price,
  if Shady is installed, enabled and has data for the item.
* Shift+LEFT-CLICK on Auction Peek rows continues to request deletion with
  confirmation; Shift-clicking bag/chat items into Shady Search belongs to
  the separate Shady 1.1 addon and does NOT override Auction Peek deletion.
* The history-search field is NOT a live market-price search. Prices are
  controlled exclusively by Shady in its own search window.

NEW IN 1.8.0 — TIMES LISTED
* An amber "xN" indicator appears at the right end of each item name on
  Listed, 24h and All Time. Hover the row for "Times listed (recorded)".
* One distinct owned auction ID counts as one posting. AH auto-refresh,
  reopening the auction house, and moving a listing to Sold/Ended/Deleted do
  NOT add another posting.
* An expired or canceled item reposted under a new auction ID adds one to the
  count, even when its previous listing is too ambiguous to link as a repost.
* Identical item variants share the same posting count, across ALL their
  separate stacks/copies on this character. This is NOT a guaranteed count
  of how many times one specific physical stack was relisted.
* Different item IDs, item levels and random suffixes are counted separately.
* The count survives relogs and locally deleted listings. Historic auction IDs
  still in the v1.7 SavedVariables are backfilled once; purged historical IDs
  cannot be recovered, so these are recorded counts, not lifetime guarantees.
* Settings > Show times listed next to items controls the compact indicator.
  The count remains available on item hover regardless of this setting.
* Existing repost linkage and its explicit cycle display are retained.

NEW IN 1.7.0 — RECOVERABLE DELETE
* SHIFT+LEFT-CLICK any visible row in Listed, 24h, All Time, or Buy History.
* A confirmation dialog appears. No entry is changed unless you confirm.
* The entry is moved to a persistent Deleted Entries list in SavedVariables.
* Options > Deleted Entries / Restore (or /ap deleted) displays deleted entries
  with a Restore button for each. Use Previous/Next to browse large histories.
* Deleting a listed auction ONLY hides its specific auction ID inside Auction
  Peek. It does NOT cancel, withdraw, or change the auction in WoW.
* Hidden live auctions do not reappear on a subsequent 90s automatic refresh.
* If a hidden auction legitimately sells, it is shown as a new sale record.
* Deleting a confirmed sale removes it from 24h AND All Time totals. A later
  owned-auction refresh will not resurrect that deleted sale. Mail receipt
  reconciliation will still update the archived sale without re-showing it.
* A deleted entry can be restored at any time (provided it still exists in
  SavedVariables). An old listing that has already ended cannot be restored as
  an ACTIVE auction; if it is reposted it will appear under its new auction ID.

NEW IN 1.7.0 — EXPIRED, CANCELED AND REPOSTED AUCTIONS
* Auction IDs are the primary identity, NOT name/quantity alone.
* Explicit AUCTION_HOUSE_AUCTIONS_EXPIRED and AUCTION_CANCELED events are
  recorded where the client provides them.
* A listing that disappears from a complete owned-auctions snapshot is marked
  ENDED (unconfirmed), never automatically sold or definitively expired.
* A repost with a new auction ID is a NEW active listing, not a new sale.
* A prior ended auction can be linked to a repost if it is the UNIQUE plausible
  match by item ID, item level, random suffix, and quantity within 7 days.
  Repost count appears on the listing's hover tooltip.
* Multiple identical candidates remain unlinked instead of guessing.
* An auction-sold notification with a specific ID cannot mark a different
  same-name active repost as sold.
* Only confirmed sold statuses/notifications and invoice reconciliation feed
  the Sold tabs; listing disappearances are NOT sale confirmations.
* Repost/ended metadata is kept up to 60 days (up to 1,200 ended records).
  Sales, purchases and recoverably deleted entries are not age-pruned.

EXISTING FEATURES PRESERVED
* Listed, rolling 24h, All Time, Buy History tabs with net/gross totals.
* Sale receipt matching at mailbox collection and Open All safeguards.
* Auto AH refresh every 90s while at auctioneer; Auctionator-compatible.
* Resizable opaque-black window and freely moving minimap button.
* Secret chat-string guard and RIP Shady footer.
* Visible v2.0.0 version on main and Settings windows.

LIMITATIONS
* Auction Peek can only refresh full owned listings at an auction house.
* A missing listing is not proof it expired; it might have sold or been canceled.
  Auction Peek leaves it "unconfirmed" unless a conclusive event/receipt arrives.
* When a mailbox invoice has no unique match to a particular listing, a
  separate receipt record can be kept instead of assuming which repost sold.
* The actual selling timestamp of offline sales is unavailable until WoW
  reports it; reconciliation time is used for mail-only sales.
* Live WoW Forever testing is still required. Please save your
  WTF/Account/<account>/SavedVariables/AuctionPeek.lua before replacing.


=== 2.5.45: GUARD-ONLY RECEIPT REPAIR (2026-11-23) ===
Back up WTF/Account/<account>/SavedVariables/AuctionPeek.lua first.
Install the addon ZIP while WoW is CLOSED, then launch WoW.
/ap repairreceipts          -- preview only, no changes
/ap repairreceipts confirm  -- one-time targeted repair if ALL source records match
/ap audit                    -- review other unmatched/history evidence
If the saved data has changed or any required record is missing, nothing is changed.
The 9/20 Gray Dye partial snapshot (#183438400) is reconciled with mail:154
and mail:169 into a single 20x sale (not deleted as a phantom). Three
formula receipts mail:37/38/39 are paired to existing costed auctions. The
two identically priced formula receipts are a group, not buyer-identified IDs.
Existing general matching rules remain unchanged; the targeted repair is
manual, source-checked, and opt-in rather than a broad automatic migration.
The repair does not run automatically, and will refuse altered/ambiguous data.


Auction Peek 2.5.47 — Proof-gated DE receipt recovery
- Reconciles a conflicting canceled/sold full-stack DE auction only after a unique clean DE cast, complete saved sold ID, exact verified mail invoice, and no competing claims or return evidence.
- Preserves original mail evidence in posting.recoveredFullDESale, fixes only the affected sale/receipt posting status, and never reallocates lot parts or edits original purchase costs.
- Read-only DE input-cost candidate can use a unique purchase within 120 seconds of a verified one-item pre-DE bag snapshot even if older virtual ledger lots remain unconsumed.
- DE Test now marks confirmed receipt fills green while retaining explanatory cost provenance.
- No automatic full-stack matching for mixed output inventory, unverified DE, split sales, canceled-and-returned auctions, or ambiguous receipts.


2.5.56 - Unit-price full-stack receipt recovery with duplicate/return guards; eligible purchase sources across ended repost chains; equal-cost estimates remain provisional; Refresh retries saved receipts. Existing manual costs preserved.

2.6.0 release candidate
- 24h and All Time show quantity per transaction. Item tooltips retain all-time units.
- Paid transaction quantity survives owned-auction refreshes.
- Incomplete, restricted or duplicate-ID owned snapshots leave the last accepted state intact.
- A late sold notification cannot relabel a terminal listing with recorded return evidence or a transferred remainder.
- /ap accounting prints read-only profile counts and structural checks.
