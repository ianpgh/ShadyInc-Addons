-- Auction Peek 2.6.3 — WoW: Forever (Interface 16001)
-- Standalone, read-only, and compatible with Auctionator.
-- Owned auctions are observed passively; explicit Refresh is the only owned-auction query.
local ADDON, Supply = ...
-- TOC metadata is the canonical UI version; the fallback is only for clients
-- without the modern C_AddOns metadata function.
local VERSION=(C_AddOns and C_AddOns.GetAddOnMetadata and C_AddOns.GetAddOnMetadata(ADDON,"Version")) or "2.6.3"
local AP = CreateFrame("Frame")
local db, char, panel, settingsPanel, minimapButton, deletedPanel
local deletedPage = 1
local ahOpen, refreshQueued, retryWhenReady = false, false, false
local refreshEpoch, lastQueryAt, autoRetryCount = 0, -1000, 0
-- Refreshing owned auctions with an empty sort array overwrites the Blizzard
-- owned-auction sort and redraws its list. Do not query automatically; use
-- the Blizzard OWNED_AUCTIONS_UPDATED event as the live data source.
local lastOwnedSignature
-- First authoritative owned snapshot after login may contain auctions that
-- finished while offline. Missing is NOT proof of sold, expired or canceled.
local firstOwnedSnapshotAfterLogin = true
local DAY_SECONDS = 24 * 60 * 60
local MIN_QUERY_GAP = 6 -- Avoid repeated requests when Auctionator or UI triggers many events.
local rowHeight, rowButtons = 23, {}
-- UI-only search and per-tab sort. History stays untouched and no scan/API calls
-- are made while typing. Auction Peek never provides its own market prices.
local searchText = ""
local expandedCraft
local expandedDE={} -- display-only DE Test section state
local listedKeys={}
local expandedMaterials={}
local SORT_OPTIONS = {
  { key = "name_asc", label = "Item A-Z" },
  { key = "name_desc", label = "Item Z-A" },
  { key = "newest", label = "Newest" },
  { key = "oldest", label = "Oldest" },
  { key = "price_desc", label = "Highest price" },
  { key = "price_asc", label = "Lowest price" },
  { key = "listed_desc", label = "Most listed" },
}
local SORT_LABELS = {}
for _, option in ipairs(SORT_OPTIONS) do SORT_LABELS[option.key] = option.label end
local MIN_WIDTH, MIN_HEIGHT = 530, 220
local HISTORY_RETENTION = 60 * DAY_SECONDS -- ended/repost linkage, not sales or deleted records
local lastMessage, lastMessageTime = nil, 0
-- Mailbox is OBSERVED only. Auction Peek never clicks, opens, deletes,
-- withdraws, or alters mail. It only reconciles after successful cash removal.
local mailOpen = false
local mailRows, mailCounts, pendingMail = {}, {}, {}
local previousMailRows, previousMailCounts, previousDropClaims = {}, {}, {}
local mailScanQueued, mailRequestSeq = false, 0
-- Buy history observes completed game auction purchases. No buying, bidding,
-- mailbox opening, or input simulation is performed by Auction Peek.
local pendingItemBids = {}
local pendingCommodity, lastUnpairedCommodity = nil, nil
local tonumber, tostring, type, pairs, ipairs = tonumber, tostring, type, pairs, ipairs
local floor, max, min = math.floor, math.max, math.min
local tinsert, sort = table.insert, table.sort
local GetTime = GetTime
local clock = time

-- WoW Forever can deliver CHAT_MSG_SYSTEM and auction-notification payloads
-- as protected "secret" values, especially in restricted instances / combat.
-- Lua's type() still reports "string" for a secret string, but calling
-- :match(), comparing it or coercing it will throw from addon code.
-- Test the value before *any* inspection; never attempt to unwrap secrets.
local function CanRead(value)
  if issecretvalue and issecretvalue(value) then return false end
  if canaccessvalue and not canaccessvalue(value) then return false end
  return true
end

local function Print(message)
  if DEFAULT_CHAT_FRAME then
    DEFAULT_CHAT_FRAME:AddMessage("|cffdfb469Auction Peek:|r " .. tostring(message))
  end
end

local function CurrentCharacterKey()
  local name = UnitName("player") or "Unknown"
  local realm = GetRealmName and GetRealmName()
  -- Keep the exact pre-2.0.7 key, including an empty string, on first
  -- access. Bind subsequent logins to that profile by player GUID.
  local legacy = name .. " - " .. (realm or "Forever")
  local guid = UnitGUID and UnitGUID("player")
  if not CanRead(guid) or type(guid) ~= "string" or guid == "" then return legacy end
  db.characterProfiles = db.characterProfiles or {}
  local key = db.characterProfiles[guid]
  if key and type(db.characters[key]) == "table" then return key end
  key = legacy
  for other, bound in pairs(db.characterProfiles) do
    if other ~= guid and bound == key then key = "guid:" .. guid; break end
  end
  db.characterProfiles[guid] = key
  return key
end

local function MoneyString(value)
  if not value or value <= 0 then return "-" end
  value = floor(value + 0.5)
  local g = floor(value / 10000)
  local s = floor(value / 100) % 100
  local c = value % 100
  if g > 0 then return string.format("%dg %ds %dc", g, s, c) end
  if s > 0 then return string.format("%ds %dc", s, c) end
  return string.format("%dc", c)
end

local function PlainName(text)
  text = tostring(text or "")
  local linkName = text:match("|h%[([^%]]+)%]|h")
  if linkName then text = linkName end
  text = text:gsub("|c%x%x%x%x%x%x%x%x", ""):gsub("|r", "")
  text = text:gsub("^%s+", ""):gsub("%s+$", "")
  return text
end

local function NameKey(text)
  return PlainName(text):lower()
end

-- Track one posting for every distinct auction ID.  Refreshing an owned-
-- auctions snapshot (or moving the auction to Sold/Ended/Deleted) must not
-- increment the count.  This is an item-level posting count, NOT proof that
-- two identical stacks are the same physical items.
local function ListingIdentity(row)
  if type(row) ~= "table" or row.purchase then return nil end
  local itemID = tonumber(row.itemID)
  if (not itemID or itemID <= 0) and CanRead(row.link) and type(row.link) == "string" then
    itemID = tonumber(row.link:match("item:(%d+)"))
  end
  if itemID and itemID > 0 then
    return "item:" .. tostring(itemID) .. ":" ..
      tostring(tonumber(row.itemLevel) or 0) .. ":" ..
      tostring(tonumber(row.itemSuffix) or 0)
  end
  local name = row.name or row.link
  if CanRead(name) and type(name) == "string" then
    local clean = NameKey(name)
    if clean ~= "" and clean ~= "unknown item" and not clean:match("^item #%d+$") then
      return "name:" .. clean
    end
  end
  return nil
end

-- Display metadata only. Keep every receipt and its transaction fields independent.
local postedItemsByName = {}
local function ReceiptItem(row)
  if row.receiptID and not row.itemID and not row.link then
    return postedItemsByName[NameKey(row.name)] or row
  end
  return row
end

local function RememberPosting(row)
  if not char or type(row) ~= "table" or not row.auctionID
      or not CanRead(row.auctionID) then return end
  local key = ListingIdentity(row)
  if not key then return end
  if tonumber(row.itemID) and tonumber(row.itemID) > 0 then
    local name = NameKey(row.name or row.link)
    if name ~= "" and name ~= "unknown item" and not name:match("^item #%d+$") then
      local known = postedItemsByName[name]
      if known == nil then
        postedItemsByName[name] = {itemID = row.itemID, itemLevel = row.itemLevel,
          itemSuffix = row.itemSuffix, name = PlainName(row.name or row.link)}
      elseif known and ListingIdentity(known) ~= key then
        postedItemsByName[name] = false -- Multiple observed variants share this name.
      end
    end
  end
  local id = tostring(row.auctionID)
  local old = char.listingSeen[id]
  if old == key then return end
  if old and (type(old) ~= "string" or not old:match("^name:")) then
    -- Never replace a known item identity using a less complete later event.
    return
  end
  if old then
    -- An initial text-only notification may later be resolved to itemID.
    -- Move, rather than duplicate, that one recorded posting.
    if key:match("^name:") then return end
    char.listingCounts[old] = math.max(0, (char.listingCounts[old] or 0) - 1)
  end
  char.listingSeen[id] = key
  char.listingCounts[key] = (char.listingCounts[key] or 0) + 1
end

-- Snapshot-only quantity evidence; never assume the first observed partial
-- stack is the original listed quantity. Observations do not allocate costs.
local function RememberQuantityEvidence(row,created)
  if not char or not row or not CanRead(row.auctionID)
      or not row.auctionID or type(row.quantity)~="number"
      or row.quantity<1 or row.quantity%1~=0 then return end
  local key=tostring(row.auctionID)
  local observations=char.postingEvidence
  if not observations then observations={};char.postingEvidence=observations end
  local old=observations[key]
  if not old and row.quantity==1 and not created then return end
  if not old then
    old={firstSeenQuantity=row.quantity,maxSeenQuantity=row.quantity,
      minSeenQuantity=row.quantity,firstSeenAt=clock(),creationObserved=false}
    observations[key]=old
  end
  old.maxSeenQuantity=math.max(old.maxSeenQuantity or 0,row.quantity)
  old.minSeenQuantity=math.min(old.minSeenQuantity or row.quantity,row.quantity)
  old.lastSeenAt=clock()
  if created then
    -- Creation event plus a matching fresh owned row is strong initial
    -- evidence; never overwrite an earlier proven original posted amount.
    if not old.creationObserved then old.originalPostedQuantity=row.quantity end
    old.creationObserved=true
  end
end

local function TimesListed(row)
  if not char then return nil end
  local key = ListingIdentity(ReceiptItem(row))
  if not key then return nil end
  local count = tonumber(char.listingCounts[key]) or 0
  return count > 0 and count or nil
end

local function InitializeListingHistory()
  postedItemsByName = {}
  if type(char.listingSeen) ~= "table" then char.listingSeen = {} end
  -- Reconstruct the counter from the ID journal to avoid drift from an
  -- interrupted SavedVariables write or updates from a previous version.
  char.listingCounts = {}
  for _, key in pairs(char.listingSeen) do
    if type(key) == "string" then
      char.listingCounts[key] = (char.listingCounts[key] or 0) + 1
    end
  end
  -- Backfill only auction IDs still present in v1.7 saved records.  Older
  -- purged ended entries cannot be reconstructed, and are never invented.
  for _, bucket in ipairs({char.active, char.sold, char.ended, char.deleted}) do
    for _, row in ipairs(bucket) do
      if type(row) == "table" and not row.purchase then RememberPosting(row) end
    end
  end
end

local function ItemDetails(row)
  row = ReceiptItem(row)
  local link = row.link
  local itemID = row.itemID
  local name, _, quality, _, _, _, _, _, _, icon
  if link and GetItemInfo then
    name, _, quality, _, _, _, _, _, _, icon = GetItemInfo(link)
  end
  if itemID and GetItemInfo then
    local n, _, q, _, _, _, _, _, _, i = GetItemInfo(itemID)
    name, quality, icon = name or n, quality or q, icon or i
  end
  if not icon and itemID and C_Item and C_Item.GetItemIconByID then
    icon = C_Item.GetItemIconByID(itemID)
  end
  if not name and itemID and C_AuctionHouse and C_AuctionHouse.GetItemKeyInfo then
    local ok, data = pcall(C_AuctionHouse.GetItemKeyInfo,
      { itemID = itemID, itemLevel = row.itemLevel or 0, itemSuffix = row.itemSuffix or 0,
        battlePetSpeciesID = 0 })
    if ok and type(data) == "table" then
      name, quality, icon = data.itemName, data.quality, icon or data.iconFileID
    end
  end
  name = row.name or name or (itemID and ("Item #" .. itemID) or "Unknown item")
  local r, g, b = 0.90, 0.90, 0.90
  if quality and ITEM_QUALITY_COLORS and ITEM_QUALITY_COLORS[quality] then
    local color = ITEM_QUALITY_COLORS[quality]
    r, g, b = color.r, color.g, color.b
  elseif link then
    local hex = link:match("|cff(%x%x%x%x%x%x)")
    if hex then
      r = (tonumber(hex:sub(1,2),16) or 230) / 255
      g = (tonumber(hex:sub(3,4),16) or 230) / 255
      b = (tonumber(hex:sub(5,6),16) or 230) / 255
    end
  end
  return name, icon or "Interface\\Icons\\INV_Misc_QuestionMark", r, g, b
end

local function Remaining(row)
  if row.purchase then
    return row.boughtAt and date("%b %d", row.boughtAt) or "Bought"
  end
  if row.sold then
    -- An unmatched mail receipt does NOT establish the sale's exact time.
    -- Earlier builds used soldAt=mail collection time; leave that historical
    -- value intact for compatibility, but label the display truthfully.
    local t=(row.mailOnly and (row.receiptRecordedAt or row.reconciledAt or row.observedAt))
      or row.soldAt
    local prefix=row.mailOnly and "Paid "
      or row.saleTimeSource=="owned_snapshot" and "Seen " or ""
    if type(t)=="number" and t>0 then
      local seconds = max(0, clock() - t)
      if seconds >= 7 * DAY_SECONDS then return prefix..date("%b %d", t) end
      if seconds >= DAY_SECONDS then return prefix..floor(seconds / DAY_SECONDS) .. "d ago" end
      if seconds >= 3600 then return prefix..floor(seconds / 3600) .. "h ago" end
      return prefix..floor(seconds / 60) .. "m ago"
    end
    return row.mailOnly and "Payment recorded" or "Sold"
  end
  if row.endTime then
    local seconds = row.endTime - clock()
    if seconds <= 0 then return "Ended?" end
    if seconds >= 3600 then return math.ceil(seconds / 3600) .. "h" end
    return math.ceil(seconds / 60) .. "m"
  end
  local bands = { [0] = "<30m", [1] = "<2h", [2] = "<12h", [3] = "<48h" }
  return bands[row.timeBand] or "-"
end

local function SaleKey(row)
  if row.auctionID then return "id:" .. tostring(row.auctionID) end
  return nil
end

-- All-time confirmed sales are intentionally never pruned or capped. Older
-- builds retained at most 3 days / 80 records; previously deleted records
-- cannot be restored here, but all existing SavedVariables are preserved.
local function SortSold()
  if not char then return end
  sort(char.sold, function(a,b) return (a.soldAt or 0) > (b.soldAt or 0) end)
end

local function IsRecentSale(sale, now)
  local soldAt = sale and tonumber(sale.soldAt)
  return soldAt and soldAt <= now and now - soldAt < DAY_SECONDS
end

-- A sale notification does not contain the actual transaction payout. Only
-- count stored listing buyouts as ESTIMATES, never as verified revenue.
-- Unknown prices are shown separately instead of counted as zero-value sales.
local soldCount
local function SaleTotals(now, sales)
  local recentCount, recentEstimated, recentEstimateCount, recentUnknown = 0, 0, 0, 0
  local allEstimated, allEstimateCount, allUnknown = 0, 0, 0
  local recentGross, recentNet, recentVerified = 0, 0, 0
  local allGross, allNet, allVerified = 0, 0, 0
  for _, sale in ipairs(sales) do
    local isRecent = IsRecentSale(sale, now)
    if isRecent then recentCount = recentCount + 1 end
    if sale.receiptID and tonumber(sale.verifiedNet) and tonumber(sale.verifiedGross) then
      local gross, net = tonumber(sale.verifiedGross), tonumber(sale.verifiedNet)
      allGross, allNet, allVerified = allGross + gross, allNet + net, allVerified + 1
      if isRecent then
        recentGross, recentNet, recentVerified = recentGross + gross, recentNet + net,
          recentVerified + 1
      end
    else
      local buyout = tonumber(sale.buyout)
      if buyout and buyout > 0 then
        allEstimated, allEstimateCount = allEstimated + buyout, allEstimateCount + 1
        if isRecent then
          recentEstimated, recentEstimateCount = recentEstimated + buyout,
            recentEstimateCount + 1
        end
      else
        allUnknown = allUnknown + 1
        if isRecent then recentUnknown = recentUnknown + 1 end
      end
    end
  end
  return recentCount,
    recentGross, recentNet, recentVerified, recentEstimated, recentEstimateCount, recentUnknown,
    allGross, allNet, allVerified, allEstimated, allEstimateCount, allUnknown
end

local function AddSold(row)
  if not char then return end
  local stack=char.craftLedger and char.craftLedger.posts[tostring(row.auctionID)]
  if stack and (stack.fullStackObserved or stack.reportedAllSold) and not stack.filled
      and row.itemID==stack.itemID and stack.totalPrice and stack.quantity then
    row.quantity,row.buyout=stack.quantity,stack.quantity*stack.totalPrice
  end
  RememberPosting(row)
  row.sold = true
  row.soldAt = row.soldAt or clock()
  local key = SaleKey(row)
  for i, old in ipairs(char.sold) do
    if key and SaleKey(old) == key then
      row.soldAt = old.soldAt or row.soldAt
      -- Preserve known listing prices on subsequent, sometimes partial AH
      -- updates, so cumulative estimates do not mysteriously fall.
      if not row.buyout or row.buyout <= 0 then row.buyout = old.buyout end
      if not row.bid or row.bid <= 0 then row.bid = old.bid end
      -- An AH status refresh must never overwrite a mail-verified payout.
      if old.receiptID then
        row.receiptID, row.verifiedGross, row.verifiedNet = old.receiptID,
          old.verifiedGross, old.verifiedNet
        row.verifiedCut, row.verifiedDeposit = old.verifiedCut, old.verifiedDeposit
        local post=char.craftLedger and char.craftLedger.posts[tostring(row.auctionID)]
        if old.receiptQuantityKnown and old.receiptQty then
          row.quantity = old.receiptQty
        elseif post and post.filled then
          row.quantity = post.filled
        end
        if post and post.unitPriceRecovery then row.buyout=old.verifiedGross end
        row.manualReceiptSource,row.manualPayment = old.manualReceiptSource,old.manualPayment
        row.receiptQuantityKnown = old.receiptQuantityKnown
        row.reconciledAt, row.receiptQty = old.reconciledAt, old.receiptQty
        row.receiptGroup, row.groupInvoiceBuyer = old.receiptGroup, old.groupInvoiceBuyer
        row.observedAt = old.observedAt
        row.receiptBuyer, row.mailOnly = old.receiptBuyer, old.mailOnly
      end
      for _,field in ipairs({"itemID","itemLevel","itemSuffix","name","link","quantity","unitPrice","repostOf","repostCount","firstSeenAt"}) do
        if row[field]==nil then row[field]=old[field] end
      end
      Supply.Crafts.Sale(char,row)
      char.sold[i] = row
      SortSold()
      return
    end
  end
  -- Where chat reported an unidentifiable auction, replace the unmatched
  -- placeholder when a real auction ID arrives instead of adding a duplicate.
  if key then
    local placeholderIndex, matches = nil, 0
    for i, old in ipairs(char.sold) do
      if not old.auctionID and not old.receiptID
          and NameKey(old.name or old.link) == NameKey(row.name or row.link)
          and math.abs((old.soldAt or 0) - row.soldAt) <= 2 then
        matches, placeholderIndex = matches + 1, i
      end
    end
    -- Never merge same-name auctions on a one-hour proximity guess.
    if matches == 1 then
      local old = char.sold[placeholderIndex]
      row.soldAt = old.soldAt
      if not row.buyout or row.buyout <= 0 then row.buyout = old.buyout end
      if not row.bid or row.bid <= 0 then row.bid = old.bid end
      Supply.Crafts.Sale(char,row)
      char.sold[placeholderIndex] = row
      SortSold()
      return
    end
  end
  Supply.Crafts.Sale(char,row)
  tinsert(char.sold, row)
  SortSold()
end

local function NewAuctionRow(info)
  if not info or type(info) ~= "table" or not info.auctionID then return nil end
  local itemKey = info.itemKey or {}
  local row = {
    auctionID = info.auctionID,
    itemID = itemKey.itemID,
    itemLevel = itemKey.itemLevel,
    itemSuffix = itemKey.itemSuffix,
    link = info.itemLink,
    quantity = info.quantity or 1,
    bid = tonumber(info.bidAmount) or 0,
    buyout = tonumber(info.buyoutAmount) or 0,
    unitPrice = tonumber(info.unitPrice),
    timeBand = info.timeLeft,
    seenAt = clock(),
    sold = (info.status == 1 or (Enum and Enum.AuctionStatus
      and info.status == Enum.AuctionStatus.Sold)) and true or false,
  }
  if info.timeLeftSeconds and tonumber(info.timeLeftSeconds) then
    row.endTime = clock() + max(0, tonumber(info.timeLeftSeconds))
  end
  local name = ItemDetails(row)
  if name and not name:match("^Item #%d+$") then row.name = name end
  return row
end

local Render, ShowDeleteConfirmation, ShowDEConfirmation
local selectedBuys = {}
local RefreshDeletedPanel

-- Recoverable soft-delete. Rows are moved to a SavedVariables trash list
-- rather than destroyed, and selecting the same row in 24h or All Time
-- removes exactly one underlying sale. Deleting a live auction only hides
-- that exact auction ID; it NEVER calls Blizzard's cancellation API.
local function MoveToDeleted(row, kind)
  if not char or type(row) ~= "table" then return false end
  local source = kind == "listed" and char.active or
    kind == "buys" and char.buys or char.sold
  local index
  for i, entry in ipairs(source) do
    if entry == row then index = i; break end
  end
  if not index then return false end
  selectedBuys[row] = nil
  table.remove(source, index)
  if kind == "listed" and row.auctionID then
    char.hiddenAuctions[tostring(row.auctionID)] = true
  end
  row.deletedAt = clock()
  row.deletedKind = kind == "listed" and "listed" or
    kind == "buys" and "buys" or "sold"
  tinsert(char.deleted, row)
  if RefreshDeletedPanel then RefreshDeletedPanel() end
  if Render then Render() end
  return true
end

local function RestoreDeleted(index)
  if not char or not char.deleted[index] then return end
  local row = table.remove(char.deleted, index)
  local kind = row.deletedKind
  row.deletedKind, row.deletedAt = nil, nil
  if kind == "listed" then
    if row.auctionID then char.hiddenAuctions[tostring(row.auctionID)] = nil end
    if row.endedAt then
      -- An ended auction is never resurrected as a live listing.
      Print("Restored the hidden listing; its auction has since ended. A new repost will appear on its own.")
    else
      local duplicate = false
      for _, active in ipairs(char.active) do
        if active.auctionID and tostring(active.auctionID) == tostring(row.auctionID) then
          duplicate = true; break
        end
      end
      if not duplicate then tinsert(char.active, row) end
    end
  elseif kind == "buys" then
    local duplicate = false
    for _, purchase in ipairs(char.buys) do
      if row.purchaseID and purchase.purchaseID == row.purchaseID then duplicate = true; break end
    end
    if not duplicate then tinsert(char.buys, row) end
  else
    AddSold(row)
  end
  if RefreshDeletedPanel then RefreshDeletedPanel() end
  if Render then Render() end
end

-- PURCHASE HISTORY
-- Auction item buyouts and commodities have DIFFERENT success events. Prices
-- are captured from the attempted bid/accepted commodity price quote and
-- persisted ONLY after a success event. No chat parsing or gold-delta guesses.
local function SafeNumber(value)
  if not CanRead(value) then return nil end
  local number = tonumber(value)
  if not number or number < 0 then return nil end
  return number
end

local function GetItemAuctionDetails(auctionID)
  if not C_AuctionHouse or not C_AuctionHouse.GetAuctionInfoByID then return nil end
  local ok, info = pcall(C_AuctionHouse.GetAuctionInfoByID, auctionID)
  if not ok or not CanRead(info) or type(info) ~= "table" then return nil end
  local row = {}
  if CanRead(info.itemLink) and type(info.itemLink) == "string" then
    row.link = info.itemLink
  end
  local key = info.itemKey
  if CanRead(key) and type(key) == "table" then
    row.itemID = SafeNumber(key.itemID)
    row.itemLevel = SafeNumber(key.itemLevel)
    row.itemSuffix = SafeNumber(key.itemSuffix)
    -- Search results provide the stack quantity, which GetAuctionInfoByID
    -- does not. If unavailable, leave it UNKNOWN rather than inventing 1.
    if C_AuctionHouse.GetNumItemSearchResults
        and C_AuctionHouse.GetItemSearchResultInfo and row.itemID then
      local okCount, count = pcall(C_AuctionHouse.GetNumItemSearchResults, key)
      if okCount and SafeNumber(count) then
        for index = 1, min(tonumber(count), 300) do
          local okResult, result = pcall(C_AuctionHouse.GetItemSearchResultInfo, key, index)
          if okResult and CanRead(result) and type(result) == "table"
              and SafeNumber(result.auctionID) == auctionID then
            row.quantity = SafeNumber(result.quantity)
            if not row.link and CanRead(result.itemLink) and type(result.itemLink) == "string" then
              row.link = result.itemLink
            end
            break
          end
        end
      end
    end
  end
  row.buyout = SafeNumber(info.buyoutAmount)
  return row
end

-- Item search rows can report several copies of a non-stackable item.
local function PurchasedStackSize(row)
  local qty=SafeNumber(row.quantity)
  if not qty or qty<=1 or not row.auctionID or not row.itemID then return qty end
  local info=(C_Item and C_Item.GetItemInfo) or GetItemInfo
  if info then
    local ok,_,_,_,_,_,_,_,stack=pcall(info,row.itemID)
    if ok and SafeNumber(stack)==1 then return 1 end
  end
  return qty
end

local function RepairRedgillRecipe()
  local l=char.craftLedger
  for _,pool in ipairs({char.buys,char.deleted}) do
    for _,r in ipairs(pool) do
      if tostring(r.auctionID)=="153987841" and r.itemID==13941 and r.price==17889
          and r.boughtAt==1795241981 and r.quantity==16 then
        r.quantity=1
        local index=l and l.purchases and l.purchases["a:153987841"]
        local lot=index and l.lots[index]
        if lot and lot.itemID==13941 and lot.quantity==16 and lot.cost==r.price then
          local unused=lot.left==16
          lot.quantity=1
          lot.left=unused and 1 or 0
          lot.balance=unused and lot.cost or 0
        end
      end
    end
  end
end

local function RememberItemBid(auctionID, amount)
  if not ahOpen then return end
  auctionID, amount = SafeNumber(auctionID), SafeNumber(amount)
  if not auctionID or auctionID <= 0 or not amount or amount <= 0 then return end
  -- Discard abandoned bids after two minutes so failed purchase attempts
  -- cannot slowly accumulate in memory during long auction sessions.
  local now = GetTime()
  for id, old in pairs(pendingItemBids) do
    if now - (old.at or 0) > 120 then pendingItemBids[id] = nil end
  end
  local entry = GetItemAuctionDetails(auctionID) or {}
  entry.auctionID, entry.price, entry.at = auctionID, amount, GetTime()
  pendingItemBids[auctionID] = entry
end

local function StoreBuy(record)
  if not char or type(record) ~= "table" then return end
  if record.auctionID then
    -- A repeated success event for the same auction is not a new purchase.
    local auctionID = tostring(record.auctionID)
    for _, existing in ipairs(char.buys) do
      if tostring(existing.auctionID) == auctionID then return end
    end
    for _, existing in ipairs(char.deleted) do
      if existing.deletedKind == "buys" and tostring(existing.auctionID) == auctionID then return end
    end
  end
  char.nextPurchaseID = (tonumber(char.nextPurchaseID) or 0) + 1
  record.purchaseID = char.nextPurchaseID
  record.purchase, record.boughtAt = true, clock()
  local total = SafeNumber(record.price)
  record.price = total and total > 0 and floor(total + 0.5) or nil
  local qty = PurchasedStackSize(record)
  record.quantity = qty and qty >= 1 and floor(qty) or nil
  if record.itemID then
    local name = ItemDetails(record)
    if name and not name:match("^Item #%d+$") then record.name = name end
  end
  if not record.name then
    record.name = record.auctionID and ("Auction #" .. record.auctionID)
      or (record.itemID and ("Item #" .. record.itemID)) or "Unknown purchase"
  end
  tinsert(char.buys, record)
  sort(char.buys, function(a,b)
    if a.boughtAt ~= b.boughtAt then return (a.boughtAt or 0) > (b.boughtAt or 0) end
    return (a.purchaseID or 0) > (b.purchaseID or 0)
  end)
  if Render and panel then Render() end
end

local function RecordItemPurchase(auctionID)
  auctionID = SafeNumber(auctionID)
  if not auctionID or auctionID <= 0 then return end
  local pending = pendingItemBids[auctionID]
  local details = GetItemAuctionDetails(auctionID) or {}
  if pending then
    for _, key in ipairs({"itemID","itemLevel","itemSuffix","link","quantity"}) do
      if not details[key] then details[key] = pending[key] end
    end
    if GetTime() - (pending.at or 0) <= 120 then
      details.price = pending.price
      details.source = "Confirmed purchase; recorded buyout payment"
    end
  end
  details.auctionID = auctionID
  if not details.price and details.buyout and details.buyout > 0 then
    -- The completed auction's buyout is generally the charged amount, but
    -- it isn't a captured confirmation; mark it as a reported listing price.
    details.price = details.buyout
    details.priceEstimated = true
    details.source = "Confirmed purchase; amount is last listed buyout, NOT verified paid"
  end
  StoreBuy(details)
  pendingItemBids[auctionID] = nil
end

local function RememberCommodityStart(itemID, quantity)
  itemID, quantity = SafeNumber(itemID), SafeNumber(quantity)
  if not itemID or itemID <= 0 or not quantity or quantity < 1 then return end
  pendingCommodity = {itemID = itemID, quantity = floor(quantity),
    startedAt = GetTime(), quotedTotal = nil, confirmed = false, committed = false}
end

local function RememberCommodityConfirm(itemID, quantity)
  if not pendingCommodity or pendingCommodity.committed then return end
  itemID, quantity = SafeNumber(itemID), SafeNumber(quantity)
  if itemID == pendingCommodity.itemID and quantity == pendingCommodity.quantity then
    pendingCommodity.confirmed = true
  end
end

local function RememberCommodityQuote(unitPrice, totalPrice)
  local pending = pendingCommodity
  if not pending or pending.committed or GetTime() - pending.startedAt > 120 then return end
  local total, unit = SafeNumber(totalPrice), SafeNumber(unitPrice)
  if total and total > 0 and unit and unit > 0 then
    pending.quotedTotal = total
    pending.quotedAt = GetTime()
  end
end

local function CommitCommodity(pending, itemID, quantity)
  if pending and pending.committed then return end
  local qty = SafeNumber(quantity) or (pending and pending.quantity)
  local id = SafeNumber(itemID) or (pending and pending.itemID)
  if not id or id < 1 or not qty or qty < 1 then return end
  qty = floor(qty)
  local record = {itemID = id, quantity = qty, commodity = true,
    source = "Confirmed commodity purchase; price unavailable"}
  if pending and not pending.committed and pending.itemID == id
      and pending.quantity == qty and pending.quotedTotal
      and GetTime() - (pending.quotedAt or 0) <= 120 then
    record.price = pending.quotedTotal
    record.source = "Confirmed commodity purchase; accepted AH price quote"
  end
  if pending then pending.committed = true end
  StoreBuy(record)
end

local function OnCommodityPurchased(itemID, quantity)
  itemID, quantity = SafeNumber(itemID), SafeNumber(quantity)
  if not itemID or not quantity or itemID < 1 or quantity < 1 then return end
  local pending = pendingCommodity
  if pending and pending.itemID == itemID and not pending.committed
      and GetTime() - pending.startedAt <= 120 then
    CommitCommodity(pending, itemID, quantity)
    return
  end
  -- Some client paths report only COMMODITY_PURCHASED. Retain such purchases
  -- with unknown price, while dropping an immediate duplicate notification.
  local now = GetTime()
  if lastUnpairedCommodity and lastUnpairedCommodity.itemID == itemID
      and lastUnpairedCommodity.quantity == quantity
      and now - lastUnpairedCommodity.at < 0.25 then return end
  if pending and pending.committed and pending.itemID == itemID
      and now - (pending.startedAt or 0) < 120 then return end
  lastUnpairedCommodity = {itemID = itemID, quantity = quantity, at = now}
  CommitCommodity(nil, itemID, quantity)
end

local function OnCommoditySucceeded()
  local pending = pendingCommodity
  if not pending or pending.committed or GetTime() - pending.startedAt > 120 then return end
  -- COMMODITY_PURCHASED carries the definitive item ID/quantity. Give the
  -- game a moment to send it; success-only builds still get a single record.
  if C_Timer and C_Timer.After then
    C_Timer.After(0.35, function()
      if pending and not pending.committed and pendingCommodity == pending then
        CommitCommodity(pending, pending.itemID, pending.quantity)
      end
    end)
  else
    CommitCommodity(pending, pending.itemID, pending.quantity)
  end
end

local function InstallPurchaseHooks()
  if type(hooksecurefunc) ~= "function" or not C_AuctionHouse then return end
  -- Post-hooks observe Blizzard/Auctionator buying; they never intercept or
  -- replace restricted buy APIs, and no purchase is written on a mere click.
  if type(C_AuctionHouse.PlaceBid) == "function" then
    pcall(hooksecurefunc, C_AuctionHouse, "PlaceBid", RememberItemBid)
  end
  if type(C_AuctionHouse.StartCommoditiesPurchase) == "function" then
    pcall(hooksecurefunc, C_AuctionHouse, "StartCommoditiesPurchase", RememberCommodityStart)
  end
  if type(C_AuctionHouse.ConfirmCommoditiesPurchase) == "function" then
    pcall(hooksecurefunc, C_AuctionHouse, "ConfirmCommoditiesPurchase", RememberCommodityConfirm)
  end
end

-- MAIL RECONCILIATION (WoW Forever native legacy mailbox globals).
-- A seller invoice can contain bid (gross sale), consignment fee, returned
-- deposit, and the net gold attached to the mail. Only a verified decrease
-- in attached money after a TakeInboxMoney / AutoLootMailItem call finalizes
-- a receipt. We never assume MAIL_SUCCESS or a click itself proves payment.
local function ReadSaleInvoice(index)
  if not mailOpen or not GetInboxHeaderInfo or not GetInboxInvoiceInfo then return nil end
  if not CanRead(index) or type(index) ~= "number" or index < 1 then return nil end
  local ok, _, _, sender, subject, money, COD, daysLeft = pcall(GetInboxHeaderInfo, index)
  if not ok or not CanRead(money) or not CanRead(COD) or not CanRead(daysLeft) then return nil, false end
  money, COD = tonumber(money), tonumber(COD) or 0
  if not money then return nil, false end
  if money <= 0 or COD > 0 then return nil end
  local valid, kind, itemName, buyer, bid, buyout, deposit, cut, _, _, _, qty =
    pcall(GetInboxInvoiceInfo, index)
  if not valid or not CanRead(kind) or kind ~= "seller" then return nil, money end
  if not CanRead(itemName) or type(itemName) ~= "string" or itemName == "" then return nil, money end
  if not CanRead(bid) or not CanRead(deposit) or not CanRead(cut)
      or not CanRead(qty) or not CanRead(buyer) then return nil, money end
  local gross, fee, refund = tonumber(bid), tonumber(cut), tonumber(deposit)
  local quantity = tonumber(qty) or 1
  if not gross or gross <= 0 or not fee or fee < 0 or not refund or refund < 0
      or quantity < 1 then return nil, money end
  quantity = floor(quantity)
  if quantity < 1 then quantity = 1 end
  -- In Blizzard's seller invoice, amount received = bid + deposit - consignment.
  -- A mismatch can mean a partial/loading invoice; don't count it as exact.
  if math.abs(gross + refund - fee - money) > 2 then return nil, money end
  local clean = PlainName(itemName)
  local buyerName = type(buyer) == "string" and buyer or ""
  local signature = table.concat({ NameKey(clean), buyerName, tostring(quantity),
    tostring(gross), tostring(refund), tostring(fee), tostring(money) }, "|")
  return {
    name = clean, buyer = buyerName, quantity = quantity, quantityKnown = tonumber(qty) == quantity,
    gross = gross, net = money, fee = fee, deposit = refund,
    signature = signature, mailIndex = index, observedAt = clock(),
  }
end

local function ReceiptMatchesSale(sale, receipt)
  if sale.receiptID or not sale.auctionID or not receipt.quantityKnown
      or tonumber(sale.quantity) ~= receipt.quantity
      or NameKey(sale.name or sale.link) ~= NameKey(receipt.name) then return false end
  if (sale.firstSeenAt or 0) > receipt.observedAt or (sale.soldAt or 0) > receipt.observedAt then
    return false
  end
  -- Sold AH snapshots report time until payment. Allow clock rounding.
  if receipt.quantity==1 and sale.sold and sale.endTime and sale.endTime>receipt.observedAt+5 then return false end
  return tonumber(sale.buyout) == receipt.gross or tonumber(sale.bid) == receipt.gross
end

-- Correct the audited pair only when both original invoices and posts agree.
local function RepairFormulaPair()
  local early,late,orphan,index
  for i,r in ipairs(char.sold) do
    if r.auctionID==154331851 then early=r end
    if r.auctionID==154571188 then late=r end
    if r.receiptID=="mail:31" and r.mailOnly and not r.auctionID then orphan,index=r,i end
  end
  if not (early and late and orphan and not early.receiptID and late.receiptID=="mail:28"
      and early.itemID==20754 and late.itemID==20754 and orphan.name==late.name
      and early.buyout==20000 and late.buyout==20000 and early.quantity==1 and late.quantity==1
      and early.endTime and late.endTime and late.reconciledAt and orphan.observedAt
      and early.endTime<=late.reconciledAt and late.reconciledAt<late.endTime
      and late.endTime<=orphan.observedAt) then return end
  for _,invoice in ipairs({late,orphan}) do
    if invoice.receiptQty~=1 or invoice.verifiedGross~=20000 or invoice.verifiedCut~=1000
        or invoice.verifiedNet~=19500 or invoice.verifiedDeposit~=500 then return end
  end
  for _,pool in ipairs({char.sold,char.deleted}) do
    for _,r in ipairs(pool) do
      if (r.receiptID=="mail:28" and r~=late) or (r.receiptID=="mail:31" and r~=orphan)
          or (r.auctionID==early.auctionID and r~=early) or (r.auctionID==late.auctionID and r~=late) then return end
    end
  end
  for _,field in ipairs({"receiptID","verifiedGross","verifiedNet","verifiedCut","verifiedDeposit",
      "receiptBuyer","receiptQty","receiptQuantityKnown","reconciledAt","observedAt"}) do
    early[field],late[field]=late[field],orphan[field]
  end
  Supply.Crafts.Sale(char,early)
  Supply.Crafts.Sale(char,late)
  table.remove(char.sold,index)
end

-- Both IDs were active in the backup and subsequently recorded as sold.
-- Their cost allocations were retained when the conflicting end event arrived.
local function RepairPendingFormulaPosts()
  local ledger=char.craftLedger
  if not ledger or not ledger.posts then return end
  local prices={["158025517"]=23900,["158026275"]=20000}
  for _,r in ipairs(char.sold) do
    local id=tostring(r.auctionID)
    local p=prices[id] and ledger.posts[id]
    if p and p.ended=="canceled" and r.sold and r.itemID==20754 and r.quantity==1
        and r.buyout==prices[id] and p.soldAt and p.soldAt==r.soldAt and p.quantity==1
        and p.parts and #p.parts==1 then
      local part=p.parts[1]
      local lot=ledger.lots[part.source]
      if lot and lot.itemID==20754 and lot.vendor and part.n==1 and part.cost==9500 then
        Supply.Crafts.ConfirmSoldID(char,r)
      end
    end
  end
end

local function UniqueReceiptSale(receipt,confirmedAt)
  local match,partial
  local posts=char.craftLedger and char.craftLedger.posts or {}
  local closed,paid={},{}
  for _,row in ipairs(char.ended) do
    if row.endedReason=="canceled" or row.endedReason=="expired" then
      closed[tostring(row.auctionID)]=true
    end
  end
  for _,pool in ipairs({char.sold,char.deleted}) do
    for _,row in ipairs(pool) do
      if row.auctionID and row.receiptID then paid[tostring(row.auctionID)]=true end
    end
  end
  for _,pool in ipairs({char.sold, char.deleted, char.ended, char.active}) do
    for _,sale in ipairs(pool) do
      local post=posts[tostring(sale.auctionID)]
      local qty=receipt.quantity
      local eligible = pool == char.sold or (pool == char.deleted and sale.deletedKind == "sold")
        or (pool == char.ended and sale.endedReason == "unconfirmed" and
          not (confirmedAt and sale.endedAt and sale.endedAt<confirmedAt))
      local key=tostring(sale.auctionID)
      local terminal=closed[key] or (post and (post.ended=="expired" or post.ended=="canceled"))
      local exact=eligible and not (post and post.fillLimit and qty>post.fillLimit) and not terminal and not paid[key] and not (post and post.filled) and ReceiptMatchesSale(sale,receipt)
      local original=post and post.quantity or sale.quantity
      local price=post and post.totalPrice or sale.buyout
      local limit=post and post.fillLimit or original
      if post and pool==char.active and post.remainingSeen and not post.soldAt then
        limit=original-post.remainingSeen
      end
      local room=limit and limit-(post and post.filled or 0) or 0
      local open=(not paid[key] or (post and post.filled)) and (not terminal or (post and post.fillLimit))
      local possible=sale.auctionID and open and qty<=room and not (post and (post.remainderTo or
        (post.ended and not post.soldAt and not post.remainingSeen))) and receipt.quantityKnown and original and qty<original
        and NameKey(sale.name or sale.link)==NameKey(receipt.name)
        and (sale.firstSeenAt or 0)<=receipt.observedAt and (sale.soldAt or 0)<=receipt.observedAt
        and ((post and post.unitPrice or sale.unitPrice)==receipt.gross/qty
          or (price and price*qty==receipt.gross*original))
      local split=possible and post and post.parts and not post.remainderTo
        and not (post.ended and not post.soldAt and not post.remainingSeen)
        and (post.filled or not post.gross) and (post.filled or 0)+qty<=original
        and (post.soldAt or post.remainingSeen or eligible)
      if exact or (possible and (pool~=char.active or (post and post.remainingSeen))) then
        if match and match.auctionID~=sale.auctionID then return nil end
        if not match or pool==char.sold then
          match=sale
          if split then partial=post elseif exact then partial=nil else partial=false end
        end
      end
    end
  end
  if partial==false then return nil end
  -- Apply the cutoff after looking for competing IDs. Removing old candidates
  -- before that check would silently give their invoices to newer auctions.
  if match and receipt.quantity==1 and not partial then
    local anchor = match.sold and (match.endTime or match.soldAt) or match.endedAt
    if not anchor or receipt.observedAt-anchor > 24*60*60 then return nil end
  end
  if match and match.endedReason=="unconfirmed" then
    -- An unconfirmed predecessor and a still-listed copy can both fit late mail.
    if match.repostedAs then return nil end
    for _,row in ipairs(char.active) do
      if tostring(row.auctionID)~=tostring(match.auctionID) and ReceiptMatchesSale(row,receipt) then return nil end
    end
  end
  return match,partial
end

-- Reevaluate saved single-item invoices after additional owned-AH evidence arrives.
function Supply.ReconcilePaidSingles()
  local proposals,claims,ids,auctions={},{},{},{}
  local ledger=char.craftLedger
  local visible={}
  for _,r in ipairs(char.sold) do visible[r]=true end
  for _,pool in ipairs({char.sold,char.deleted}) do
    for _,r in ipairs(pool) do
      if r.receiptID then ids[r.receiptID]=(ids[r.receiptID] or 0)+1 end
      if r.auctionID then
        local key=tostring(r.auctionID)
        auctions[key]=(auctions[key] or 0)+1
      end
    end
  end
  for _,post in pairs(ledger and ledger.posts or {}) do
    for id in pairs(post.fills or {}) do ids[id]=(ids[id] or 0)+1 end
  end
  local deClaims=Supply.DETest and Supply.DETest.ConfirmedReceiptClaims
    and Supply.DETest.ConfirmedReceiptClaims(char) or {}
  for i,r in ipairs(char.sold) do
    if r.mailOnly and r.receiptID and not deClaims[r.receiptID]
        and ids[r.receiptID]==1 and not r.auctionID and r.observedAt
        and r.receiptQuantityKnown and type(r.receiptQty)=="number" and r.receiptQty>=1
        and r.receiptQty==math.floor(r.receiptQty) and type(r.verifiedGross)=="number"
        and r.verifiedGross>0 and type(r.verifiedCut)=="number"
        and type(r.verifiedDeposit)=="number" and type(r.verifiedNet)=="number"
        and r.verifiedGross-r.verifiedCut+r.verifiedDeposit==r.verifiedNet then
      local invoice={name=r.name,quantity=r.receiptQty,quantityKnown=true,gross=r.verifiedGross,observedAt=r.observedAt}
      local target,partial=UniqueReceiptSale(invoice)
      if not target then
        for _,sale in ipairs(char.sold) do
          local post=ledger and ledger.posts[tostring(sale.auctionID)]
          if sale.sold and sale.endTime and sale.soldAt and post and post.ownedSold and post.quantity==1
              and invoice.quantity==1 and not post.ended and not post.gross and ReceiptMatchesSale(sale,invoice)
              and invoice.observedAt>=sale.endTime and invoice.observedAt-sale.endTime<=180 then
            local timed,split=UniqueReceiptSale(invoice,sale.soldAt)
            if timed==sale and not split then target=sale end
            break
          end
        end
      end
      -- Count competing invoices even when one of them also fits another sale.
      for _,sale in ipairs(char.sold) do
        if ReceiptMatchesSale(sale,invoice) then claims[sale]=(claims[sale] or 0)+1 end
      end
      local key=target and tostring(target.auctionID)
      local post=ledger and ledger.posts[key]
      -- Multi-unit receipts are eligible only for one complete originally
      -- recorded stack, never a partial fill or inferred per-unit purchase.
      -- One receipt must not be offered to two auctions, and vice versa.
      local fullStack=invoice.quantity==1 or (target and post
          and target.quantity==invoice.quantity and post.quantity==invoice.quantity
          and post.itemID==target.itemID and post.parts and #post.parts>0
          and target.buyout==invoice.gross and not post.remainingSeen
          and not post.returnedUnits and not post.fillLimit and not post.remainderTo
          and not post.fills and not post.filled)
      if target and visible[target] and target.sold and not partial and auctions[key]==1 and post
          and fullStack and post.quantity==invoice.quantity and post.soldAt
          and not post.gross and not post.ended then
        proposals[i]=target
      end
    end
  end
  -- An archived invoice can still compete with a visible one.
  for _,r in ipairs(char.deleted) do
    if r.mailOnly and r.receiptID and not r.auctionID and r.observedAt and r.receiptQuantityKnown
        and type(r.receiptQty)=="number" and r.receiptQty>=1 and r.verifiedGross then
      local invoice={name=r.name,quantity=r.receiptQty,quantityKnown=true,gross=r.verifiedGross,observedAt=r.observedAt}
      for _,target in pairs(proposals) do
        if ReceiptMatchesSale(target,invoice) then claims[target]=2 end
      end
    end
  end
  local n=0
  for i=#char.sold,1,-1 do
    local target=proposals[i]
    if target and claims[target]==1 then
      local receipt=char.sold[i]
      for _,field in ipairs({"receiptID","verifiedGross","verifiedNet","verifiedCut","verifiedDeposit",
          "receiptBuyer","receiptQty","receiptQuantityKnown","reconciledAt","observedAt"}) do
        target[field]=receipt[field]
      end
      Supply.Crafts.Sale(char,target)
      table.remove(char.sold,i)
      n=n+1
      Print("Linked "..receipt.receiptID.." to "..target.name.." #"..target.auctionID..".")
    end
  end
  -- v2.5.48: a full-stack DE sale can retain a false canceled flag.
  -- This additional pass requires a unique new clean DE, sold ID, exact invoice,
  -- and no competing listing/return before repairing the contradictory status.
  n=n+Supply.ReconcileConflictedFullDE(char)
  n=n+Supply.ReconcileUnitPriceStack(char)
  n=n+Supply.SettleReceiptGroups(char,ids,auctions,NameKey)
  n=n+Supply.SettleSplitStacks(char,ids)
  if n>0 then SortSold() end
  return n
end

-- Batch a mailbox withdrawal or a burst of owned-auction updates before retrying.
local retrySinglesQueued=false
function Supply.QueueReceiptReview()
  if retrySinglesQueued or not C_Timer or not C_Timer.After then return end
  retrySinglesQueued=true
  C_Timer.After(1,function()
    retrySinglesQueued=false
    if char and Supply.ReconcilePaidSingles()>0 and panel then Render() end
  end)
end

-- A newly collected invoice may fit an auction already claimed by an earlier
-- unassigned invoice. Preserve both receipts until their identities are clear.
local function EarlierReceiptFits(target)
  for _,pool in ipairs({char.sold,char.deleted}) do
    for _,r in ipairs(pool) do
      if r.mailOnly and not r.auctionID and r.receiptID and r.receiptQty==1
          and r.receiptQuantityKnown and r.observedAt and r.verifiedGross
          and ReceiptMatchesSale(target,{name=r.name,quantity=1,quantityKnown=true,
            gross=r.verifiedGross,observedAt=r.observedAt}) then return true end
    end
  end
end

local function RecordVerifiedReceipt(receipt)
  if not char or type(receipt) ~= "table" then return end
  local existing,post = UniqueReceiptSale(receipt)
  if existing and not post and receipt.quantity==1 and EarlierReceiptFits(existing) then existing=nil end
  if post then
    -- Keep a single history row per auction and each constituent invoice once.
    local sale
    for _,pool in ipairs({char.sold,char.deleted}) do
      for _,r in ipairs(pool) do
        if r.auctionID==existing.auctionID and (r.sold or r.deletedKind=="sold") then sale=r;break end
      end
      if sale then break end
    end
    if not sale then
      sale={}
      for k,v in pairs(existing) do sale[k]=v end
      sale.endedReason,sale.endedAt,sale.deletedKind=nil,nil,nil
      sale.sold=true
      tinsert(char.sold,sale)
    end
    char.nextReceiptID=char.nextReceiptID+1
    local id="mail:"..char.nextReceiptID
    post.fills=post.fills or {}
    post.fills[id]={quantity=receipt.quantity,gross=receipt.gross,fee=receipt.fee,
      net=receipt.net,deposit=receipt.deposit,buyer=receipt.buyer}
    post.filled=(post.filled or 0)+receipt.quantity
    post.gross=(post.gross or 0)+receipt.gross
    post.cut=(post.cut or 0)+receipt.fee
    post.soldAt=post.soldAt or sale.soldAt or receipt.observedAt
    post.itemID=post.itemID or sale.itemID
    post.totalPrice=post.totalPrice or existing.buyout
    sale.soldAt=post.soldAt
    sale.quantity,sale.receiptQty,sale.receiptQuantityKnown=post.filled,post.filled,true
    sale.receiptID=sale.receiptID or id
    sale.verifiedGross,sale.verifiedCut=post.gross,post.cut
    sale.verifiedDeposit=(sale.verifiedDeposit or 0)+receipt.deposit
    sale.verifiedNet=(sale.verifiedNet or 0)+receipt.net
    sale.reconciledAt=clock()
    SortSold()
    Supply.PacedReceiptSaved(receipt.signature)
    return
  end
  if existing and existing.endedReason == "unconfirmed" then
    local ended = existing
    for i = #char.ended, 1, -1 do
      if char.ended[i] == ended then table.remove(char.ended, i); break end
    end
    ended.sold, ended.soldAt, ended.mailOnly = true, clock(), true
    ended.endedAt, ended.endedReason = nil, nil
    -- An ended hidden listing is no longer an active auction. Its verified
    -- sale belongs in Sold, not in both the trash and Sold history.
    for i = #char.deleted, 1, -1 do
      if char.deleted[i] == ended then
        table.remove(char.deleted, i)
        if ended.auctionID then char.hiddenAuctions[tostring(ended.auctionID)] = nil end
        ended.deletedAt, ended.deletedKind = nil, nil
        break
      end
    end
    if RefreshDeletedPanel then RefreshDeletedPanel() end
    tinsert(char.sold, ended)
  end
  char.nextReceiptID = (tonumber(char.nextReceiptID) or 0) + 1
  local receiptID = "mail:" .. tostring(char.nextReceiptID)
  local sale = existing or {
    name = receipt.name, quantity = receipt.quantity,
    sold = true, soldAt = clock(), mailOnly = true,
  }
  if not existing then sale.receiptRecordedAt=clock() end
  sale.receiptID = receiptID
  sale.verifiedGross, sale.verifiedNet = receipt.gross, receipt.net
  sale.verifiedCut, sale.verifiedDeposit = receipt.fee, receipt.deposit
  sale.receiptBuyer, sale.receiptQty = receipt.buyer, receipt.quantity
  sale.receiptQuantityKnown = receipt.quantityKnown
  sale.reconciledAt = clock()
  sale.observedAt = receipt.observedAt
  Supply.Crafts.Sale(char,sale)
  -- A confirmed sale with no unique matching listing is added on its own.
  -- The original ambiguous notification remains UNVERIFIED; we never alter
  -- another sale's payout based solely on a shared item name.
  if not existing then
    tinsert(char.sold, sale)
    if receipt.quantity==1 then
      Print("Payment saved: "..receiptID.." ("..receipt.name.."). No unique auction match. Flip will recheck automatically.")
    end
  end
  SortSold()
  Supply.PacedReceiptSaved(receipt.signature)
end

-- Keep the previous full inbox snapshot. On Open All, several same-item
-- invoices may vanish between two events. Compare counts per COMPLETE
-- signature, not positions: indices shift when the server removes mail.
local function ScanMailbox()
  if not mailOpen or not GetInboxNumItems then return end
  local ok, count = pcall(GetInboxNumItems)
  if not ok or not CanRead(count) or type(count) ~= "number" then return end
  if count > 200 then return end
  local newCounts, newRows, unresolvedMoney, firstObserved = {}, {}, {}, {}
  for _,old in pairs(mailRows) do firstObserved[old.signature] = old.observedAt end
  for index = 1, min(count, 200) do
    local receipt, unreadable = ReadSaleInvoice(index)
    if unreadable == false then return end
    if unreadable then unresolvedMoney[unreadable] = true end
    if receipt then
      receipt.observedAt = firstObserved[receipt.signature] or receipt.observedAt
      newRows[index] = receipt
      newCounts[receipt.signature] = (newCounts[receipt.signature] or 0) + 1
    end
  end
  -- A still-funded, temporarily unreadable invoice can look like a withdrawal.
  for _,old in pairs(mailRows) do
    if unresolvedMoney[old.net] and (newCounts[old.signature] or 0) < mailCounts[old.signature] then return end
  end
  -- Repeated scans of an unchanged slot retain its pending take identity.
  for index,receipt in pairs(newRows) do
    local old = mailRows[index]
    if old and old.signature == receipt.signature
        and mailCounts[receipt.signature] == newCounts[receipt.signature] then
      newRows[index] = old
    end
  end
  local dropClaims, changed = {}, false
  for signature, oldCount in pairs(mailCounts) do
    local gone = max(0, oldCount - (newCounts[signature] or 0))
    local originalGone = gone
    local queue = pendingMail[signature]
    if queue then
      -- Failed or stalled requests are never allowed to turn a later unrelated
      -- mailbox change into a false payout.
      while #queue > 0 and GetTime() - (queue[1].requestedAt or 0) > 20 do
        table.remove(queue, 1)
      end
      for i = #queue, 1, -1 do
        if gone == 0 then break end
        if not queue[i].disappeared then
          RecordVerifiedReceipt(table.remove(queue, i).receipt)
          gone, changed = gone - 1, true
        end
      end
      if #queue == 0 then pendingMail[signature] = nil end
    end
    dropClaims[signature] = originalGone - gone
  end
  previousDropClaims = dropClaims
  previousMailRows, previousMailCounts = mailRows, mailCounts
  mailRows, mailCounts = newRows, newCounts
  for signature, queue in pairs(pendingMail) do
    for i = #queue, 1, -1 do
      local transaction = queue[i]
      if GetTime() - transaction.requestedAt > 20 then
        table.remove(queue, i)
      elseif transaction.ack and transaction.disappeared then
        table.remove(queue, i)
        RecordVerifiedReceipt(transaction.receipt)
        changed = true
      end
    end
    if #queue == 0 then pendingMail[signature] = nil end
  end
  if changed then
    Supply.QueueReceiptReview()
    if panel then Render() end
  end
  return true
end

Supply.MailValueReadable = CanRead
function Supply.PrepareMailPickup(choice)
  if not mailOpen or not ScanMailbox() or next(pendingMail) then return false end
  Supply.ScanReturns()
  local receipt = mailRows[choice.index]
  if receipt then return true, receipt.signature end
  if choice.money > 0 then
    local kind = GetInboxInvoiceInfo(choice.index)
    if not CanRead(kind) or kind == "seller" or choice.sender == "Auction House"
        or choice.sender == AUCTION_HOUSE then return false end
  end
  return true
end

local function QueueMailScan()
  if not mailOpen or mailScanQueued then return end
  mailScanQueued = true
  if C_Timer and C_Timer.After then
    C_Timer.After(0.15, function()
      mailScanQueued = false
      if mailOpen then ScanMailbox() end
    end)
  else
    mailScanQueued = false
    ScanMailbox()
  end
end

local function OnTakeMailMoney(index)
  if not mailOpen or not CanRead(index) or type(index) ~= "number" then return end
  local receipt = mailRows[index]
  local alreadyGone = false
  -- Some Open All handlers may update the inbox synchronously before
  -- our post-hook runs. Use the immediately prior snapshot if an invoice
  -- vanished from this index; don't misattribute the new shifted mail.
  local previous = previousMailRows[index]
  if previous then
    local dropped = (previousMailCounts[previous.signature] or 0)
      - (mailCounts[previous.signature] or 0)
    if dropped > (previousDropClaims[previous.signature] or 0) then
      receipt = previous
      alreadyGone = true
      previousDropClaims[previous.signature] = (previousDropClaims[previous.signature] or 0) + 1
    end
  end
  if not receipt then
    -- The first mailbox scan may have run before this seller invoice loaded.
    -- Establish its full multiplicity while it is still funded. A standalone
    -- read here would enqueue a take without a baseline to observe its removal.
    ScanMailbox()
    receipt = mailRows[index]
  end
  if not receipt then return end
  local signature = receipt.signature
  local queue = pendingMail[signature]
  if not queue then queue = {}; pendingMail[signature] = queue end
  local existingCount = max(mailCounts[signature] or 0,
    previousMailCounts[signature] or 0, 1)
  -- Nested duplicate calls cannot enqueue more invoices than exist.
  if #queue >= existingCount then return end
  for _,transaction in ipairs(queue) do
    if transaction.receipt == receipt then return end
  end
  mailRequestSeq = mailRequestSeq + 1
  tinsert(queue, {receipt = receipt, requestedAt = GetTime(), seq = mailRequestSeq,
    disappeared = alreadyGone})
  -- Bulk looters may repeatedly take index 1 before the next inbox event.
  -- Refresh the index map while the call's resulting state is available.
  ScanMailbox()
  QueueMailScan()
end

local function AcknowledgeMailSuccess()
  -- MAIL_SUCCESS is not tagged with an invoice ID. Attribute it only to the
  -- oldest observed take request; a later inbox decrease must ALSO occur.
  local earliest
  for _, queue in pairs(pendingMail) do
    for _, transaction in ipairs(queue) do
      if not transaction.ack and (not earliest or transaction.seq < earliest.seq) then
        earliest = transaction
      end
    end
  end
  if earliest then earliest.ack = true end
  QueueMailScan()
end

local function RejectMailTake()
  -- A failed request may not be identifiable by index; remove the oldest
  -- unconfirmed request rather than risk turning it into a future "sale".
  local earliest, foundQueue, foundIndex
  for _, queue in pairs(pendingMail) do
    for index, transaction in ipairs(queue) do
      if not earliest or transaction.seq < earliest.seq then
        earliest, foundQueue, foundIndex = transaction, queue, index
      end
    end
  end
  if foundQueue then table.remove(foundQueue, foundIndex) end
  QueueMailScan()
end

local function StopMailWatch()
  mailOpen = false
  mailRows, mailCounts, pendingMail = {}, {}, {}
  previousMailRows, previousMailCounts, previousDropClaims = {}, {}, {}
  mailScanQueued = false
end

local function InstallMailHooks()
  if type(hooksecurefunc) ~= "function" then return end
  -- Hooks are post-call observers only. We do not intercept or replace the
  -- mail APIs, so they keep working with Blizzard's and addons' Open All.
  if type(TakeInboxMoney) == "function" then
    hooksecurefunc("TakeInboxMoney", OnTakeMailMoney)
  end
  if type(AutoLootMailItem) == "function" then
    hooksecurefunc("AutoLootMailItem", OnTakeMailMoney)
  end
end

-- Search applies only to the currently selected tab. These helpers do not
-- change SavedVariables, other than the explicit per-tab sort preferences.
local function SortForTab(tab)
  local configured = db and db.sortModes and db.sortModes[tab]
  if configured and SORT_LABELS[configured] and not ((tab == "buys" or tab == "flip") and configured == "listed_desc") then
    return configured
  end
  return tab == "listed" and "name_asc" or "newest"
end

local function EventTime(row, tab)
  if row.purchase then return tonumber(row.boughtAt) or 0 end
  if tab == "listed" then
    return tonumber(row.firstSeenAt) or tonumber(row.seenAt) or 0
  end
  return tonumber(row.soldAt) or 0
end

local function RowPrice(row, tab)
  if row.craftKey then return row.price end
  if row.purchase then return tonumber(row.price) or 0 end
  if tab == "listed" then
    local buyout = tonumber(row.buyout) or 0
    return buyout > 0 and buyout or (tonumber(row.bid) or 0)
  end
  return (row.receiptID and tonumber(row.verifiedGross)) or tonumber(row.buyout) or 0
end

local function RowSearchName(row)
  local name = row.name or row.link
  if name and CanRead(name) then return NameKey(name) end
  return ""
end

local function RowAuctionMatchesSearch(row, query)
  if row.auctionID and CanRead(row.auctionID) and tostring(row.auctionID):find(query, 1, true) then return true end
  -- Grouped Flip rows have no single auction ID; search their members too.
  if type(row.members)=="table" then
    for _,member in ipairs(row.members) do
      if member.auctionID and CanRead(member.auctionID)
          and tostring(member.auctionID):find(query, 1, true) then return true end
    end
  end
  return false
end
local function RowMatchesSearch(row, query)
  if not query or query == "" then return true end
  -- #123456789 means auction-ID only; plain digits still match item IDs.
  local explicitAuctionID=query:match("^#(%d+)$")
  if explicitAuctionID then return RowAuctionMatchesSearch(row, explicitAuctionID) end
  if RowSearchName(row):find(query, 1, true) then return true end
  local itemID = row.itemID
  if itemID and CanRead(itemID) and tostring(itemID):find(query, 1, true) then return true end
  if RowAuctionMatchesSearch(row, query) then return true end
  return false
end

local function SortDisplayRows(rows, tab)
  local mode = SortForTab(tab)
  local function compare(a, b)
    local aa, bb
    if mode == "name_asc" or mode == "name_desc" then
      aa, bb = RowSearchName(a), RowSearchName(b)
    elseif mode == "newest" or mode == "oldest" then
      aa, bb = EventTime(a, tab), EventTime(b, tab)
    elseif mode == "price_asc" or mode == "price_desc" then
      aa, bb = RowPrice(a, tab), RowPrice(b, tab)
    elseif mode == "listed_desc" then
      aa, bb = TimesListed(a) or 0, TimesListed(b) or 0
    end
    if aa ~= bb then
      if mode == "name_asc" or mode == "oldest" or mode == "price_asc" then
        return aa < bb
      end
      return aa > bb
    end
    -- Stable deterministic fallback, even for identical names/prices.
    local at, bt = EventTime(a, tab), EventTime(b, tab)
    if at ~= bt then return at > bt end
    local an, bn = RowSearchName(a), RowSearchName(b)
    if an ~= bn then return an < bn end
    return tostring(a.auctionID or a.purchaseID or a.receiptID or "") <
      tostring(b.auctionID or b.purchaseID or b.receiptID or "")
  end
  sort(rows, compare)
end

-- Search totals must be computed from the visible matching rows, never from
-- all saved sales. Listing estimates and verified mail totals remain separate.
local function FilteredSummary(rows, tab)
  local count = #rows
  if tab == "flip" then
    if db.groupFlipItems then return count.." rows" end
    local buys, receipts, pending, crafts, deReviews = 0, 0, 0, 0, 0
    for _, row in ipairs(rows) do
      if row.deReview then deReviews = deReviews + 1
      elseif row.craft then crafts = crafts + 1
      elseif row.purchase then buys = buys + 1
      elseif row.receiptID then receipts = receipts + 1
      else pending = pending + 1 end
    end
    return (crafts>0 and crafts.." crafted auctions  |  " or "") ..
      (deReviews>0 and deReviews.." DE sales for cost review  |  " or "") ..
      buys .. " purchases  |  " .. receipts .. " sale receipts  |  " .. pending .. " resales without a matched receipt"
  end
  if tab == "listed" then return tostring(count) .. " matching active listings" end
  local verified, gross, net, estimate, estimated, missing = 0, 0, 0, 0, 0, 0
  for _, row in ipairs(rows) do
    if tab == "buys" then
      local price = tonumber(row.price)
      if price and price > 0 then
        if row.priceEstimated then estimate, estimated = estimate + price, estimated + 1
        else net, verified = net + price, verified + 1 end
      else missing = missing + 1 end
    else
      if row.receiptID and tonumber(row.verifiedGross) and tonumber(row.verifiedNet) then
        gross = gross + tonumber(row.verifiedGross)
        net = net + tonumber(row.verifiedNet)
        verified = verified + 1
      elseif tonumber(row.buyout) and tonumber(row.buyout) > 0 then
        estimate, estimated = estimate + tonumber(row.buyout), estimated + 1
      else missing = missing + 1 end
    end
  end
  local result = tab == "buys" and ("Spent: " .. (verified > 0 and MoneyString(net) or "none confirmed")) or
    ("Verified: " .. (verified > 0 and (MoneyString(gross) .. " gross / " .. MoneyString(net) .. " net") or "none"))
  if estimated > 0 then result = result .. " | ~" .. MoneyString(estimate) .. " estimates" end
  if missing > 0 then result = result .. " | " .. missing .. " unknown" end
  return result
end

local function OpenShadySearch()
  -- Shady v1.1 implements this optional method. It MUST open its own search,
  -- not be expected to provide prices or a search database to Auction Peek.
  local api = _G and _G.ShadyPriceAPI or ShadyPriceAPI
  if api and type(api.OpenSearch) == "function" then
    local ok = pcall(api.OpenSearch)
    if ok then return end
  end
  Print("Shady Search isn't available yet. Install Shady Price Engine 1.1 with ShadyPriceAPI.OpenSearch().")
end

local function saleIDTab(tab)
  return tab=="flip" or tab=="recent" or tab=="all"
end

local function LayoutTable()
  if not panel or not panel.content then return end
  local minimum=(saleIDTab(db.selectedTab) or db.selectedTab=="de") and 760 or 640
  if panel.tableMinimum~=minimum then
    panel.tableMinimum=minimum
    if panel.SetResizeBounds then panel:SetResizeBounds(minimum,MIN_HEIGHT)
    elseif panel.SetMinResize then panel:SetMinResize(minimum,MIN_HEIGHT) end
    if panel:GetWidth()<minimum then panel:SetWidth(minimum) end
  end
  local width = max(1, floor(panel:GetWidth() - 38))
  -- Keep each auction column visible even at the smallest permitted width.
  local saleHistory = db.selectedTab=="recent" or db.selectedTab=="all"
  local timeWidth = max(saleHistory and db.showFlipTime and 125 or 64, floor(width * 0.105))
  local buyoutWidth = max(99, floor(width * 0.195))
  local bidWidth = max(101, floor(width * 0.19))
  local idWidth = (saleIDTab(db.selectedTab) or db.selectedTab=="de") and 104 or 0
  local itemWidth = max(1, width - idWidth - timeWidth - buyoutWidth - bidWidth)
  local flip = db.selectedTab == "flip" or db.selectedTab == "de"
  local showTime = db.selectedTab == "flip" and db.showFlipTime == true
  local soldWidth = showTime and 112 or 0
  if flip then
    bidWidth = min(121, max(88, floor(width * 0.16)))
    buyoutWidth = min(121, max(88, floor(width * 0.16)))
    timeWidth = db.selectedTab=="de" and min(152,max(130,floor(width * 0.18))) or min(110, max(75, floor(width * 0.13)))
    itemWidth = width - idWidth - bidWidth - buyoutWidth - timeWidth - soldWidth
  end
  local tableEnd = itemWidth + bidWidth + buyoutWidth + timeWidth
  panel.groupCheck:SetShown(db.selectedTab=="flip")
  panel.groupCheck:SetChecked(db.groupFlipItems == true)
  panel.vendorCheck:SetShown(db.selectedTab=="buys")
  panel.restoreVendor:SetShown(db.selectedTab=="buys")
  panel.vendorCheck:SetChecked(db.hideVendorBuys==true)
  panel.timeCheck:SetShown((db.selectedTab == "flip") or saleHistory)
  panel.timeCheck:SetChecked(db.showFlipTime==true)
  panel.header:SetHeight(23)
  panel.headers.auction:SetShown(idWidth>0)
  panel.columnItemWidth = itemWidth
  panel.columnBidWidth = bidWidth
  panel.columnBuyoutWidth = buyoutWidth
  panel.columnTimeWidth = timeWidth
  panel.content:SetWidth(width)
  panel.header:SetWidth(width)
  local showSearch = db and db.showHistorySearch ~= false and db.selectedTab~="de"
  if panel.searchRow then panel.searchRow:SetShown(showSearch) end
  panel.header:ClearAllPoints()
  panel.header:SetPoint("TOPLEFT", panel, "TOPLEFT", 7, showSearch and -94 or -60)
  if panel.scroll then
    panel.scroll:ClearAllPoints()
    panel.scroll:SetPoint("TOPLEFT", panel, "TOPLEFT", 8, (db.selectedTab=="de" and -84 or showSearch and -118 or -84))
    local searchHasText = searchText and searchText:find("%S")
    local twoLines = showSearch and searchHasText and db.showOverallSearchTotals == true
    panel.scroll:SetPoint("BOTTOMRIGHT", panel, "BOTTOMRIGHT", -30, twoLines and 45 or 29)
  end
  if panel.empty then
    panel.empty:ClearAllPoints()
    panel.empty:SetPoint("TOPLEFT", panel, "TOPLEFT", 22, (showSearch and -160 or -126))
  end

  local heads = panel.headers
  heads.auction:ClearAllPoints()
  heads.auction:SetPoint("TOPRIGHT",panel.header,"TOPRIGHT",-6,-5)
  heads.item:ClearAllPoints()
  heads.item:SetPoint("TOPLEFT", panel.header, "TOPLEFT", 9, -5)
  heads.item:SetWidth(itemWidth - 15)
  heads.bid:SetJustifyH("RIGHT")
  heads.buyout:SetJustifyH("RIGHT")
  heads.soldTime:ClearAllPoints()
  heads.soldTime:SetPoint("TOPRIGHT", panel.header, "TOPLEFT", tableEnd + soldWidth - 6, -5)
  heads.soldTime:SetShown(showTime)
  heads.units:ClearAllPoints()
  heads.units:SetPoint("TOPRIGHT",panel.header,"TOPLEFT",itemWidth-11,-5)
  heads.units:SetText(db.selectedTab=="buys" and "Source" or "Qty")
  heads.units:SetShown(db.selectedTab=="buys" or db.showListingCount and (db.selectedTab=="all" or db.selectedTab=="recent"))
  heads.bid:ClearAllPoints()
  heads.bid:SetPoint("TOPLEFT", panel.header, "TOPLEFT", itemWidth + 4, -5)
  heads.bid:SetWidth(bidWidth - 10)
  heads.buyout:ClearAllPoints()
  heads.buyout:SetPoint("TOPLEFT", panel.header, "TOPLEFT", itemWidth + bidWidth + 4, -5)
  heads.buyout:SetWidth(buyoutWidth - 10)
  heads.time:ClearAllPoints()
  heads.time:SetPoint("TOPRIGHT", panel.header, "TOPLEFT", tableEnd - 6, -5)
  heads.time:SetWidth(timeWidth - 10)

  for _, btn in ipairs(rowButtons) do
    btn:SetWidth(width)
    local showCount = btn.listCount and btn.listCount:IsShown()
    btn.name:SetWidth(btn.data and btn.data.deHeader and max(45,itemWidth-66) or
      btn.data and btn.data.detail and max(60,panel:GetWidth()-82) or
      max(45, itemWidth - (btn.data and (btn.data.sold or db.selectedTab == "flip") and 68 or 28) -
      8 - (showCount and 43 or 0)))
    if btn.listCount then
      btn.listCount:ClearAllPoints()
      btn.listCount:SetPoint("RIGHT", btn, "LEFT", itemWidth - 12, 0)
    end
    btn.bid:ClearAllPoints()
    btn.bid:SetPoint("RIGHT", btn, "LEFT", itemWidth + bidWidth - 7, 0)
    btn.bid:SetWidth(bidWidth - 13)
    btn.buyout:ClearAllPoints()
    btn.buyout:SetPoint("RIGHT", btn, "LEFT", itemWidth + bidWidth + buyoutWidth - 7, 0)
    btn.buyout:SetWidth(buyoutWidth - 13)
    btn.remaining:ClearAllPoints()
    btn.remaining:SetPoint("RIGHT", btn, "LEFT", tableEnd - 7, 0)
    btn.soldTime:ClearAllPoints()
    btn.soldTime:SetPoint("RIGHT", btn, "LEFT", tableEnd + soldWidth - 7, 0)
    btn.soldTime:SetShown(showTime)
    btn.remaining:SetWidth(timeWidth - 11)
    btn.remaining:SetWordWrap(db.selectedTab~="de")
  end
  panel.empty:SetWidth(max(100, width - 30))
  if panel.overallStatus then panel.overallStatus:SetWidth(max(100, panel:GetWidth() - 55)) end
end

-- Keep one list visible. The 24h tab is a rolling filter, while All Time
-- retains every confirmed sale including those in the last 24 hours.
local function UpdateTabAppearance(recentCount, sales, flips, tracked)
  if not panel or not panel.tabs then return end
  local selected = db and db.selectedTab or "listed"
  local counts = { listed = #char.active, recent = recentCount,
    all = #sales, flip = #flips, buys = #char.buys, de = #(tracked or Supply.DETest.Tracked(char)) }
  local titles = { listed = "Listed", recent = "24h", all = "All Time",
    flip = "Flip", buys = "Buy History", de = "DE Test" }
  for key, tab in pairs(panel.tabs) do
    local active = key == selected
    tab.background:SetColorTexture(active and 0.12 or 0, active and 0.10 or 0,
      active and 0.05 or 0, 1)
    tab.underline:SetColorTexture(active and 0.95 or 0.24,
      active and 0.76 or 0.24, active and 0.36 or 0.24, active and 1 or 0.6)
    tab.label:SetText(titles[key] .. " (" .. counts[key] .. ")")
    tab.label:SetTextColor(active and 1 or 0.72, active and 0.85 or 0.72,
      active and 0.47 or 0.72)
  end
  if panel.headers and panel.headers.time then
    if selected == "flip" or selected == "de" then
      panel.headers.time:SetText("Profit")
      panel.headers.bid:SetText("Paid / Mat Cost")
      panel.headers.buyout:SetText("After AH Cut")
    elseif selected == "buys" then
      panel.headers.time:SetText("Bought")
      panel.headers.bid:SetText("Avg/Unit")
      panel.headers.buyout:SetText("Total Paid")
    else
      panel.headers.time:SetText(selected ~= "listed" and (db.showFlipTime and "Sold at" or "Sold") or "Time")
      panel.headers.bid:SetText(selected ~= "listed" and "Net Payout" or "Bid Price")
      panel.headers.buyout:SetText(selected ~= "listed" and "Sold Gross" or "Buyout Price")
    end
  end
end

local displayRows = {}

-- Pool only rows visible in the scroll viewport. All Time can grow without
-- creating one WoW frame for every sale in the character's history.
-- Seller mail can identify an item only by name. Prefer item IDs whenever
-- both records have one, and compare exact normalized names otherwise.
local function AddItemEarnings(data)
  if db.showItemEarnings == false then return end
  local id, name = tonumber(ReceiptItem(data).itemID), NameKey(data.name or data.link)
  local seenReceipts, seenAuctions = {}, {}
  local earned, count = 0, 0
  for _, sale in ipairs(char.sold) do
    local saleID = tonumber(ReceiptItem(sale).itemID)
    local matches
    if id and saleID then
      matches = id == saleID
    else
      matches = name ~= "" and name == NameKey(sale.name or sale.link)
    end
    local receipt, auction = sale.receiptID, sale.auctionID and tostring(sale.auctionID)
    local gross, fee = tonumber(sale.verifiedGross), tonumber(sale.verifiedCut)
    if matches and receipt and gross and fee and gross >= fee and fee >= 0
        and not seenReceipts[receipt] and not (auction and seenAuctions[auction]) then
      seenReceipts[receipt] = true
      if auction then seenAuctions[auction] = true end
      count, earned = count + 1, earned + gross - fee
    end
  end
  local value = count == 0 and "No verified receipts" or
    ((earned == 0 and "0c" or MoneyString(earned)) .. " (" .. count .. (count == 1 and " receipt)" or " receipts)"))
  GameTooltip:AddDoubleLine("All-time after AH fees", value, 0.80, 0.80, 0.80, 1, 0.84, 0.42)
end

local function AddLastSaleLine(data)
  data = ReceiptItem(data)
  local id = tonumber(data.itemID)
  if not id then return end
  for _, sale in ipairs(char.sold) do
    local qty, gross = tonumber(sale.receiptQty), tonumber(sale.verifiedGross)
    -- Older receipts defaulted missing quantities to one. Only larger
    -- historical quantities prove the invoice actually supplied a count.
    local item = ReceiptItem(sale)
    if tonumber(item.itemID) == id and sale.receiptID and gross and gross > 0
        and qty and qty > 0 and (sale.receiptQuantityKnown or qty > 1)
        and (item.itemLevel or 0) == (data.itemLevel or 0)
        and (item.itemSuffix or 0) == (data.itemSuffix or 0) and sale.soldAt then
      local when = (sale.mailOnly and "receipt " or "") .. date("%b %d", sale.soldAt)
      GameTooltip:AddLine("Your last verified sale: " .. MoneyString(gross / qty) ..
        " each (" .. qty .. " for " .. MoneyString(gross) .. ", " .. when .. ")", 1, 0.84, 0.42, true)
      return
    end
  end
end

local function SelectionSummary(query)
  local count, total, estimates, missing, hidden = 0, 0, 0, 0, 0
  for row in pairs(selectedBuys) do
    count = count + 1
    if not RowMatchesSearch(row, query) then hidden = hidden + 1 end
    local price = tonumber(row.price)
    if price and price > 0 then
      total = total + price
      if row.priceEstimated then estimates = estimates + 1 end
    else
      missing = missing + 1
    end
  end
  local label = missing > 0 and "Subtotal" or "Total"
  local amount = total > 0 and MoneyString(total) or "unknown"
  local parts = { count .. " selected", label .. " " .. (estimates > 0 and "~" or "") .. amount }
  if estimates > 0 then parts[#parts+1] = estimates .. " estimated" end
  if missing > 0 then parts[#parts+1] = missing .. " unpriced" end
  if hidden > 0 then parts[#parts+1] = hidden .. " hidden by search" end
  return table.concat(parts, "  |  ")
end

local function PaintRows()
  if not panel or not panel.content or not panel.scroll then return end
  local height=panel.scroll:GetHeight()
  if not height or height<=0 then return end
  local rows = displayRows
  local count = #rows
  local offset = max(0, panel.scroll:GetVerticalScroll() or 0)
  local firstIndex = min(count + 1, floor(offset / rowHeight) + 1)
  local visible = max(1, math.ceil(height / rowHeight) + 3)
  local lastIndex = min(count, firstIndex + visible - 1)
  local used = 0
  for index = firstIndex, lastIndex do
    used = used + 1
    local row = rows[index]
    local btn = rowButtons[used]
    if not btn then
      btn = CreateFrame("Button", nil, panel.content)
      btn:SetSize(max(1, floor(panel:GetWidth() - 38)), rowHeight)
      local fill = btn:CreateTexture(nil, "BACKGROUND")
      btn.selectionFill = fill
      fill:SetAllPoints()
      fill:SetColorTexture(0, 0, 0, 1)
      local separator = btn:CreateTexture(nil, "BORDER")
      separator:SetPoint("BOTTOMLEFT", btn, "BOTTOMLEFT", 2, 0)
      separator:SetPoint("BOTTOMRIGHT", btn, "BOTTOMRIGHT", -2, 0)
      separator:SetHeight(1)
      separator:SetColorTexture(0.16, 0.16, 0.16, 0.48)
      local highlight = btn:CreateTexture(nil, "HIGHLIGHT")
      highlight:SetAllPoints()
      highlight:SetColorTexture(0.85, 0.76, 0.45, 0.13)
      btn.icon = btn:CreateTexture(nil, "ARTWORK")
      btn.icon:SetSize(17,17)
      btn.icon:SetPoint("LEFT", 7, 0)
      btn.saleTag = btn:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
      btn.saleTag:SetPoint("LEFT", 27, 0)
      btn.saleTag:SetJustifyH("LEFT")
      btn.saleTag:SetTextColor(0.30, 0.95, 0.34)
      btn.name = btn:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
      btn.name:SetJustifyH("LEFT")
      btn.name:SetWordWrap(false)
      btn.name:SetSize(331, 20)
      btn.subline=btn:CreateFontString(nil,"OVERLAY","GameFontHighlightSmall")
      btn.subline:SetPoint("TOPLEFT",btn.name,"BOTTOMLEFT",0,1)
      btn.subline:SetPoint("TOPRIGHT",btn.name,"BOTTOMRIGHT",0,1)
      btn.subline:SetHeight(15)
      btn.subline:SetJustifyH("LEFT")
      btn.subline:SetWordWrap(false)
      -- Big bold glyphs keep the confidence state readable without relying on color.
      btn.deMarker=btn:CreateFontString(nil,"OVERLAY","GameFontNormalLarge")
      btn.deMarker:SetPoint("LEFT",btn,"LEFT",10,0)
      btn.deMarker:SetWidth(20)
      btn.deMarker:SetJustifyH("CENTER")
      btn.deMarker:Hide()
      -- WoW's client font does not consistently include the unicode check
      -- glyph; use Blizzard's built-in check texture for verified evidence.
      btn.deCheck=btn:CreateTexture(nil,"OVERLAY")
      btn.deCheck:SetSize(18,18)
      btn.deCheck:SetPoint("CENTER",btn.deMarker,"CENTER",0,0)
      btn.deCheck:SetTexture("Interface\\Buttons\\UI-CheckBox-Check")
      btn.deCheck:SetVertexColor(.17,1,.23)
      btn.deCheck:Hide()
      btn.listCount = btn:CreateFontString(nil, "OVERLAY", "GameFontDisableSmall")
      btn.listCount:SetWidth(39)
      btn.listCount:SetJustifyH("RIGHT")
      btn.listCount:SetTextColor(0.90, 0.75, 0.40)
      btn.auctionButton=CreateFrame("Button",nil,btn)
      btn.auctionButton:SetSize(100,20)
      btn.auctionButton:SetPoint("RIGHT",-6,0)
      local idLabel=btn.auctionButton:CreateFontString(nil,"OVERLAY","GameFontNormalSmall")
      idLabel:SetAllPoints()
      idLabel:SetJustifyH("RIGHT")
      btn.auctionButton.idLabel=idLabel
      btn.auctionButton:SetScript("OnClick",function(self)
        local data=self:GetParent().data
        if db.selectedTab=="de" then
          -- The ID is a time-window candidate; clicking it opens diagnostics,
          -- not a sale inspector that might imply verified attribution.
          if data and data.deHeader then
            expandedDE[data.deKey]=not expandedDE[data.deKey] or nil
            Render()
          end
          return
        end
        Supply.OpenInspector(panel,char,data,MoneyString,ReceiptMatchesSale,NameKey,Render)
      end)
      btn.soldTime = btn:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
      btn.soldTime:SetJustifyH("RIGHT")
      btn.soldTime:SetWidth(108)
      btn.bid = btn:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
      btn.bid:SetJustifyH("RIGHT")
      btn.buyout = btn:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
      btn.buyout:SetJustifyH("RIGHT")
      btn.remaining = btn:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
      btn.remaining:SetJustifyH("RIGHT")
      btn:SetScript("OnEnter", function(self)
        local data = self.data
        if db.selectedTab=="de" then
          if not data or not (data.deHeader or data.deOutput or data.deConfidence) then return end
          GameTooltip:SetOwner(self,"ANCHOR_RIGHT")
          GameTooltip:ClearLines()
          local shown=false
          if data.itemID and CanRead(data.itemID) and GameTooltip.SetItemByID then
            shown=pcall(GameTooltip.SetItemByID,GameTooltip,data.itemID)
          end
          if not shown then GameTooltip:AddLine(data.deHeader and "Disenchant record" or "DE Test confidence") end
          if data.deConfidence=="ok" then
            GameTooltip:AddLine("|cff33ff33[OK] Verified|r",1,1,1)
          elseif data.deConfidence=="question" then
            GameTooltip:AddLine("|cffffff00[?] Needs review / pending|r",1,1,1)
          elseif data.deConfidence=="error" then
            GameTooltip:AddLine("|cffff4545[!] Conflicting saved data|r",1,1,1)
          end
          if data.deReason then GameTooltip:AddLine(data.deReason,1,.86,.58,true) end
          if data.deAction then
            GameTooltip:AddLine(data.deManualConfirmed and "Click: review or undo MANUAL confirmation" or
              "Click: review evidence and confirm or reject",1,.95,.3,true)
          end
          if data.deHeader then
            GameTooltip:AddLine("Left-click: expand or collapse details",1,.83,.35)
            GameTooltip:AddLine("Read-only diagnostics; no costs or receipts are changed",.8,.8,.8,true)
          end
          GameTooltip:Show()
          return
        end
        if not data or data.detail then return end
        GameTooltip:SetOwner(self, "ANCHOR_RIGHT")
        GameTooltip:ClearLines()
        local shown = false
        if data.link and CanRead(data.link) then
          shown = pcall(GameTooltip.SetHyperlink, GameTooltip, data.link)
        end
        -- WoW's native item tooltip (stats, enchants, requirements) comes
        -- first. Shady's own tooltip hook adds its valuation if installed.
        local item = ReceiptItem(data)
        if not shown and item.itemID and GameTooltip.SetItemByID then
          shown = pcall(GameTooltip.SetItemByID, GameTooltip, item.itemID)
        end
        if not shown then GameTooltip:AddLine(data.name or "Auction") end
        if data.deAutoFlip then
          GameTooltip:AddLine("Auto DE: verified input purchase and paid output",.45,1,.52,true)
          GameTooltip:AddLine(data.deAutoDetail,.9,.8,.5,true)
          GameTooltip:AddLine("Left-click to review or disable Auto attribution.",1,.83,.35,true)
        end
        if not IsShiftKeyDown() then GameTooltip:Show(); return end
        if data.soldCost and data.soldCost.note then GameTooltip:AddLine(data.soldCost.note,1,.8,.3,true) end
        if data.deReview then GameTooltip:AddLine("DE sale: proceeds verified; input cost attribution NOT confirmed.",1,.95,.2,true) end
        if data.receiptGroup then GameTooltip:AddLine("Matched identical payouts as a group: "..data.receiptGroup..". Individual buyer assignment unknown.",1,.8,.3,true) end
        if data.auctionID then GameTooltip:AddDoubleLine("Auction ID",tostring(data.auctionID)) end
        if data.members then
          GameTooltip:AddLine(data.unitsText)
          GameTooltip:AddLine("Click for auctions and payments")
          GameTooltip:Show()
          return
        end
        if data.craft then
          GameTooltip:AddLine("Click to expand materials and posting history",1,0.82,0.4)
          GameTooltip:AddLine("Craft costs use recorded stock and available pre-craft bag counts.",0.8,0.8,0.8)
          GameTooltip:Show()
          return
        end
        GameTooltip:AddLine(data.purchase and (data.vendor and "Vendor purchase (confirmed)" or "Auction House purchase (confirmed)")
          or (data.sold and (data.mailOnly and "Mail payment recorded (auction not identified)" or "Sold observed") or "Last seen listed"), 1, 0.82, 0.30)
        GameTooltip:AddDoubleLine("Quantity", data.quantity and tostring(data.quantity)
          or "Unknown", 0.8,0.8,0.8, 1,1,1)
        if data.purchase then
          if data.boughtAt then
            GameTooltip:AddLine("Bought: " .. date("%b %d, %Y %I:%M %p", data.boughtAt),
              0.8, 0.8, 0.8)
          end
          GameTooltip:AddDoubleLine(data.priceEstimated and (data.manualVendor and "Estimated purchase cost" or "Listed buyout (estimate)")
            or "Total paid", data.price and ((data.priceEstimated and "~" or "") ..
            MoneyString(data.price)) or "Unknown", 0.45, 0.95, 0.50, 1, 1, 1)
          if data.price and data.quantity and data.quantity > 0 then
            GameTooltip:AddDoubleLine("Average unit price",
              MoneyString(data.price / data.quantity), 0.8,0.8,0.8, 1,1,1)
          end
          if data.source then GameTooltip:AddLine(data.source, 0.72,0.72,0.72, true) end
        elseif data.sold then
          if data.mailOnly then
            local paidAt=data.receiptRecordedAt or data.reconciledAt or data.observedAt or data.soldAt
            if paidAt then GameTooltip:AddLine("Payment recorded: " .. date("%b %d, %Y %I:%M %p",paidAt),.8,.8,.8) end
            GameTooltip:AddLine("Exact sale time unknown (could have sold offline).",1,.82,.35,true)
          elseif data.soldAt then
            GameTooltip:AddLine((data.saleTimeSource=="owned_snapshot" and "Seen sold: " or "Recorded: ") ..
              date("%b %d, %Y %I:%M %p", data.soldAt), 0.8,0.8,0.8)
            if data.saleTimeSource=="owned_snapshot" then
              GameTooltip:AddLine("Owned-auction snapshot, not verified sale time.",1,.82,.35,true)
            end
          end
          if data.auctionID and char and char.postingEvidence then
            local evidence=char.postingEvidence[tostring(data.auctionID)]
            if evidence and evidence.creationObserved then
              GameTooltip:AddDoubleLine("Original posting (observed)",tostring(evidence.originalPostedQuantity or "?"))
            elseif evidence then
              GameTooltip:AddDoubleLine("Max quantity seen (not original)",tostring(evidence.maxSeenQuantity or "?"))
            end
          end
          if data.receiptID then
            GameTooltip:AddDoubleLine("Verified sale (gross)", MoneyString(data.verifiedGross),
              0.45, 0.95, 0.50, 1, 1, 1)
            GameTooltip:AddDoubleLine("AH fee", MoneyString(data.verifiedCut),
              0.8, 0.8, 0.8, 1, 1, 1)
            GameTooltip:AddDoubleLine("Deposit returned", MoneyString(data.verifiedDeposit),
              0.8, 0.8, 0.8, 1, 1, 1)
            GameTooltip:AddDoubleLine("Gold collected", MoneyString(data.verifiedNet),
              0.45, 0.95, 0.50, 1, 1, 1)
            if data.mailOnly then
              GameTooltip:AddLine("Receipt preserved without an auction-ID link; not a second sale.",
                0.8, 0.7, 0.5)
            end
          elseif data.buyout and data.buyout > 0 then
            GameTooltip:AddLine("Estimated from LISTED buyout; awaiting auction mail", 0.75,0.75,0.75)
          else
            GameTooltip:AddLine("Final sale price unknown; awaiting auction mail", 0.75,0.75,0.75)
          end
        end
        AddLastSaleLine(data)
        AddItemEarnings(data)
        if data.sold and soldCount then
          local n, uncertain = soldCount(data)
          if n then GameTooltip:AddDoubleLine("All-time units sold", (uncertain and "At least " or "") .. n) end
          if uncertain then GameTooltip:AddLine("Some receipts may match sales still awaiting mail.", 0.8,0.75,0.6,true) end
        end
        if not data.purchase then
          local count = TimesListed(data)
          GameTooltip:AddDoubleLine("Times listed (recorded)",
            count and tostring(count) or "Unknown", 0.8, 0.8, 0.8, 1, 0.84, 0.42)
          GameTooltip:AddLine("Counts distinct auction IDs for this item variant, including other copies/stacks.",
            0.68, 0.68, 0.68, true)
        end
        if data.repostCount and data.repostCount > 0 and not data.sold then
          GameTooltip:AddLine("Identified repost cycle: " .. tostring(data.repostCount + 1) ..
            " (unique predecessor match)", 0.75, 0.75, 0.75)
        end
        if data.endedReason then
          local ended = data.endedReason == "expired" and "Expired" or
            data.endedReason == "canceled" and "Canceled" or "Ended (unconfirmed)"
          GameTooltip:AddLine("Prior auction: " .. ended, 0.75, 0.75, 0.75)
        end
        if db.selectedTab == "buys" then
          GameTooltip:AddLine("Shift+Right-click: select or deselect for combined price", 1, 0.82, 0.32)
        end
        if db.selectedTab ~= "flip" then GameTooltip:AddLine("Shift+Left-click: delete from Auction Peek (restorable)",
          0.78, 0.70, 0.47) end
        GameTooltip:Show()
      end)
      btn:SetScript("OnLeave", function() GameTooltip:Hide() end)
      Supply.BindShiftTooltip(btn)
      btn:RegisterForClicks("LeftButtonUp", "RightButtonUp")
      btn:SetScript("OnClick", function(self, button)
        if db.selectedTab=="flip" and button=="LeftButton" and self.data and self.data.deAction=="auto" then
          local evidence={deAction="auto",deGuid=self.data.deGuid,deAuctionID=self.data.deAuctionID,
            detail=self.data.deAutoDetail or self.data.detail}
          ShowDEConfirmation(evidence)
          return
        end
        if self.data and button=="LeftButton" and not IsShiftKeyDown() and
            (self.data.inspectID or ((db.selectedTab=="all" or db.selectedTab=="recent") and self.data.sold)) then
          Supply.OpenInspector(panel,char,self.data,MoneyString,ReceiptMatchesSale,NameKey,Render)
          return
        end
        if db.selectedTab=="de" then
          if button=="LeftButton" and self.data then
            if self.data.deAction then
              ShowDEConfirmation(self.data)
            elseif self.data.deHeader then
              local key=self.data.deKey
              expandedDE[key]=not expandedDE[key] or nil
              Render()
            end
          end
          return
        end
        if db.selectedTab=="listed" and self.data and self.data.detail and not self.data.materialKey then return end
        if self.data and self.data.materialKey and button=="LeftButton" then
          local key=self.data.materialKey
          expandedMaterials[key]=not expandedMaterials[key]
          Render()
          return
        end
        local key=self.data and (self.data.craftKey or listedKeys[self.data])
        if key and button=="LeftButton" and (not listedKeys[self.data] or not IsShiftKeyDown or not IsShiftKeyDown()) then
          expandedMaterials={}
          if expandedCraft == key then expandedCraft=nil else expandedCraft=key end
          Render()
          return
        end
        if not IsShiftKeyDown or not IsShiftKeyDown() then return end
        local data = self.data
        if not data or not char then return end
        local selected = db and db.selectedTab or "listed"
        if selected == "flip" then return end
        if button == "RightButton" and selected == "buys" then
          selectedBuys[data] = not selectedBuys[data] or nil
          Render()
          return
        end
        if button ~= "LeftButton" then return end
        local kind = selected == "listed" and "listed" or
          selected == "buys" and "buys" or "sold"
        local name = PlainName(data.name or data.link)
        if name == "" then name = "this entry" end
        ShowDeleteConfirmation(data, kind, name)
      end)
      rowButtons[used] = btn
      LayoutTable()
    end
    btn:ClearAllPoints()
    btn:SetPoint("TOPLEFT", panel.content, "TOPLEFT", 0, -(index - 1) * rowHeight)
    btn:SetHeight(rowHeight)
    btn.data = row
    local idText
    if db.selectedTab=="de" and row.deHeader and row.deAuctionID then
      idText="#"..row.deAuctionID
    elseif saleIDTab(db.selectedTab) and not row.purchase and not row.members and not row.detail then
      idText=row.auctionID and ("#"..row.auctionID) or row.receiptID or (row.sold and "ID unknown")
    end
    btn.auctionButton.idLabel:SetText(idText or "")
    btn.auctionButton:SetShown(idText and true or false)
    local flipTime=row.mailOnly and
      (row.receiptRecordedAt or row.reconciledAt or row.observedAt or row.soldAt) or row.soldAt
    btn.soldTime:SetText(db.selectedTab == "flip" and db.showFlipTime and flipTime
      and date("%b %d %I:%M %p",flipTime) or "")
    if db.selectedTab=="de" and row.deHeader then
      btn.selectionFill:SetColorTexture(0.13,0.12,0.07,1)
    elseif db.selectedTab == "buys" and selectedBuys[row] then
      btn.selectionFill:SetColorTexture(0.27, 0.21, 0.07, 1)
    else
      btn.selectionFill:SetColorTexture(0, 0, 0, 1)
    end
    btn.subline:Hide()
    btn.deMarker:Hide() -- recycled button may come from a different tab
    btn.deMarker:ClearAllPoints()
    btn.deMarker:SetPoint("LEFT",btn,"LEFT",row.deHeader and 31 or 10,0)
    btn.deCheck:Hide()
    if row.detail then
      btn.name:SetHeight(20)
      btn.name:ClearAllPoints()
      btn.name:SetPoint("LEFT",btn,"LEFT",32,0)
      btn.name:SetWidth(math.max(60,panel:GetWidth()-82))
      btn.name:SetText(row.detail)
      if db.selectedTab=="de" and row.deConfidence then
        local state=row.deConfidence
        if state=="ok" then
          btn.deCheck:Show()
        else
          btn.deMarker:SetText(state=="error" and "!" or "?")
          if state=="error" then btn.deMarker:SetTextColor(1,.22,.25)
          else btn.deMarker:SetTextColor(1,.96,.05) end
          btn.deMarker:Show()
        end
      end
      if row.deHeader then
        btn.name:SetTextColor(1,0.86,0.35)
        btn.name:ClearAllPoints()
        btn.name:SetPoint("LEFT",btn,"LEFT",57,0)
        btn.name:SetWidth(max(45,(panel.columnItemWidth or 340)-66))
        local iconID=row.deOutputID or row.deInputID
        btn.icon:Hide()
        if iconID then
          local texture=(C_Item and C_Item.GetItemIconByID and C_Item.GetItemIconByID(iconID))
            or (GetItemIcon and GetItemIcon(iconID))
          if texture then btn.icon:SetTexture(texture);btn.icon:Show() end
        end
      elseif row.deSection then
        btn.name:SetTextColor(0.52,0.94,0.90)
      elseif row.deNotice then
        btn.name:SetTextColor(1,0.74,0.36)
      elseif row.deOutput then
        btn.name:SetTextColor(0.88,0.91,0.83)
      elseif row.deSummary then
        btn.name:SetTextColor(0.84,0.84,0.84)
      elseif row.inspectID then btn.name:SetTextColor(1,.82,.2)
      else btn.name:SetTextColor(0.88,0.81,0.65) end
      if not row.deHeader then btn.icon:Hide() end
      btn.listCount:Hide()
      btn.saleTag:SetText("")
      if row.deHeader and db.selectedTab=="de" then
        btn.bid:SetText(row.deCostText or "Unknown")
        btn.buyout:SetText(row.deNetText or "-")
        btn.remaining:SetText(row.deProfitText or "Unverified")
        if row.deProfitNegative then btn.remaining:SetTextColor(1,.38,.40)
        elseif row.deProfitManual then btn.remaining:SetTextColor(.45,1,.52)
        else btn.remaining:SetTextColor(1,.96,.05) end
      else
        btn.bid:SetText("")
        btn.buyout:SetText("")
        btn.remaining:SetText("")
      end
    else
    btn.icon:Show()
    local name, icon, r,g,b = ItemDetails(row)
    btn.icon:SetTexture(icon)
    local flipBuy = db.selectedTab == "flip" and row.purchase
    local key=row.craftKey or listedKeys[row]
    btn.saleTag:SetText(key and (expandedCraft==key and "[-]" or "[+]") or flipBuy and "Buy:" or row.deAutoFlip and "Auto DE:" or row.deReview and "DE:" or row.sold and "Sold:" or "")
    btn.name:ClearAllPoints()
    local secondary=row.members and row.unitsText
    btn.name:SetPoint("LEFT", btn, "LEFT", (row.sold or flipBuy or row.craft) and 68 or listedKeys[row] and 50 or 28, secondary and 8 or 0)
    local count
    if db.selectedTab ~= "flip" and db.showListingCount and not row.purchase and not row.craft then
      if row.sold then count = Supply.Accounting.SaleUnits(row) else count = TimesListed(row) end
    end
    if db.selectedTab=="buys" then
      btn.listCount:SetText(row.vendor and "Vendor" or "AH")
      btn.listCount:Show()
    elseif count then
      btn.listCount:SetText("x" .. tostring(count))
      btn.listCount:Show()
    else
      btn.listCount:SetText("")
      btn.listCount:Hide()
    end
    btn.listCount:ClearAllPoints()
    btn.listCount:SetPoint("RIGHT", btn, "LEFT", (panel.columnItemWidth or 340) - 12, 0)
    btn.name:SetWidth(max(45, (panel.columnItemWidth or 340) -
      ((row.sold or flipBuy or row.craft) and 68 or listedKeys[row] and 50 or 28) - 8 - ((count or db.selectedTab=="buys") and 43 or 0)))
    btn.name:SetHeight(18)
    if secondary then
      btn.subline:SetText(secondary)
      btn.subline:SetTextColor(1,0.84,0.4)
      btn.subline:Show()
    end
    local quantity = row.quantity
    if row.sold then quantity = Supply.Accounting.SaleUnits(row) end
    local quantityInColumn = row.sold and count ~= nil
    btn.name:SetText((not quantityInColumn and not row.members and quantity and quantity > 1
      and (quantity .. "x ") or "") .. name)
    btn.name:SetTextColor(r,g,b)
    -- On sale tabs the columns become verified NET and GROSS; for older
    -- unmatched sales, the buyout is shown only as a ~ listing estimate.
    if db.selectedTab == "flip" then
      btn.bid:SetText(row.soldCost and Supply.Crafts.CostLabel(row.soldCost) or row.purchase and row.price and ((row.priceEstimated and "~" or "") .. MoneyString(row.price)) or "-")
      local proceeds=row.net
      if row.sold and not row.soldCost and row.receiptID then
        local gross,cut=tonumber(row.verifiedGross),tonumber(row.verifiedCut)
        if gross and cut and cut>=0 and cut<=gross then proceeds=gross-cut end
      end
      btn.buyout:SetText(row.partialProceeds or proceeds==0 and "0c" or proceeds and MoneyString(proceeds)
        or (row.sold or row.craft) and "Pending" or "-")
    elseif row.purchase then
      btn.bid:SetText(row.price and row.quantity and row.quantity > 0
        and ((row.priceEstimated and "~" or "") .. MoneyString(row.price / row.quantity)) or "-")
      btn.buyout:SetText(row.price and ((row.priceEstimated and "~" or "") ..
        MoneyString(row.price)) or "-")
    elseif row.sold then
      btn.bid:SetText(row.receiptID and MoneyString(row.verifiedNet) or "-")
      btn.buyout:SetText(row.receiptID and MoneyString(row.verifiedGross)
        or ((tonumber(row.buyout) or 0) > 0 and ("~" .. MoneyString(row.buyout)) or "-"))
    else
      btn.bid:SetText(MoneyString(row.bid))
      btn.buyout:SetText(MoneyString(row.buyout))
    end
    if db.selectedTab=="flip" then
      local value=row.partialProfit or row.profitText
      if not value and row.sold then value=row.receiptID and "Cost unknown" or "Pending" end
      btn.remaining:SetText(value or "-")
    else
      if db.showFlipTime and (db.selectedTab=="recent" or db.selectedTab=="all") then
        local seenTime=row.mailOnly and (row.receiptRecordedAt or row.reconciledAt or row.observedAt)
          or row.soldAt
        btn.remaining:SetText(seenTime and
          ((row.mailOnly and "Paid " or row.saleTimeSource=="owned_snapshot" and "Seen " or "")..
          date("%b %d %I:%M %p",seenTime)) or "-")
      else
        btn.remaining:SetText(Remaining(row))
      end
    end
    btn.remaining:SetTextColor(row.sold and 0.77 or 0.74, row.sold and 0.77 or 0.74,
      row.sold and 0.77 or 0.74)
    end
    btn:Show()
  end
  for i = used + 1, #rowButtons do rowButtons[i]:Hide() end
end

-- Scroll-frame dimensions can settle after the parent's drag/size callback.
-- Repaint the existing rows once observers have received the final dimensions.
local function QueueViewportPaint()
  if panel.viewportPaintQueued then return end
  panel.viewportPaintQueued=true
  C_Timer.After(0,function()
    panel.viewportPaintQueued=nil
    if not panel:IsShown() then return end
    local height=panel.scroll:GetHeight()
    if not height or height<=0 then return end
    local limit=max(0,#displayRows*rowHeight-height)
    if panel.scroll:GetVerticalScroll()>limit then panel.scroll:SetVerticalScroll(limit) end
    PaintRows()
  end)
end

Render = function()
  if not panel or not panel:IsShown() or not char then return end
  listedKeys={}
  if panel.unmatchedButton then
    panel.unmatchedButton:SetText("Unmatched: "..Supply.ReviewReceiptCount(char,NameKey))
    panel.unmatchedButton:SetShown(panel:GetWidth()>=760)
  end
  local allRows = {}
  local tab = db and db.selectedTab or "listed"
  local now = clock()
  local sales, flips, counter = Supply.BuildHistory(char, NameKey)
  Supply.Crafts.Rows(char,flips,sales)
  local tracked=Supply.DETest.Tracked(char)
  local moved=Supply.DETest.ProjectFlip(char,flips,sales,tracked)
  local remainingDE={}
  for _,entry in ipairs(tracked) do
    if not moved[entry.original or entry] then remainingDE[#remainingDE+1]=entry end
  end
  soldCount = counter
  local recentCount,
    recentGross, recentNet, recentVerified, recentEstimated, recentEstimateCount, recentUnknown,
    allGross, allNet, allVerified, allEstimated, allEstimateCount, allUnknown = SaleTotals(now, sales)
  if tab=="de" then
    UpdateTabAppearance(recentCount,sales,flips,remainingDE)
    panel.searchRow:Hide()
    panel.header:Show()
    panel.clearSelection:Hide()
    panel.overallStatus:Hide()
    panel.scroll:ClearAllPoints()
    panel.scroll:SetPoint("TOPLEFT",panel,"TOPLEFT",8,-84)
    panel.scroll:SetPoint("BOTTOMRIGHT",panel,"BOTTOMRIGHT",-30,29)
    panel.empty:SetPoint("TOPLEFT",panel,"TOPLEFT",22,-126)
    displayRows=Supply.DETest.Lines(char,MoneyString,ReceiptMatchesSale,remainingDE,expandedDE)
    rowHeight=23
    panel.content:SetHeight(max(1,#displayRows*rowHeight))
    PaintRows()
    panel.empty:SetText("No remaining DE Test observations. Verified Auto results appear in Flip.")
    panel.empty:SetShown(#displayRows==0)
    panel.status:SetText("AH-purchased DE review  |  Auto results in Flip  |  Click to expand")
    return
  end
  panel.header:Show()
  if tab == "listed" then
    for _, row in ipairs(char.active) do
      if Supply.Crafts.ListedParts(char,row) then listedKeys[row]="listed:"..row.auctionID end
      tinsert(allRows,row)
    end
  elseif tab == "buys" then
    for _, row in ipairs(char.buys) do
      if not (db.hideVendorBuys and row.vendor) then tinsert(allRows,row) end
    end
  elseif tab == "flip" then
    allRows = flips
  else
    for _, row in ipairs(sales) do
      if tab == "all" or IsRecentSale(row, now) then tinsert(allRows, row) end
    end
  end
  if tab=="flip" and db.groupFlipItems then allRows=Supply.Crafts.ItemGroups(char,flips,sales) end
  rowHeight=(tab=="flip" and db.groupFlipItems) and 36 or 23
  UpdateTabAppearance(recentCount, sales, tab=="flip" and allRows or flips,remainingDE)
  if panel.sortButton then
    panel.sortButton:SetText("Sort: " .. (SORT_LABELS[SortForTab(tab)] or "Newest"))
  end
  local allCount = #allRows
  local query = (db.showHistorySearch ~= false) and searchText:lower():match("^%s*(.-)%s*$") or ""
  local filtered = {}
  for _, row in ipairs(allRows) do
    if RowMatchesSearch(row, query) then tinsert(filtered, row) end
  end
  SortDisplayRows(filtered, tab)
  local hasSelection = tab == "buys" and next(selectedBuys) ~= nil
  local showOverallLine = not hasSelection and query ~= "" and db.showOverallSearchTotals == true
  if panel.scroll then
    panel.scroll:SetPoint("TOPLEFT", panel, "TOPLEFT", 8, (db.showHistorySearch ~= false and -118 or -84)-(panel.header:GetHeight()-23))
    panel.scroll:SetPoint("BOTTOMRIGHT", panel, "BOTTOMRIGHT", -30, showOverallLine and 45 or 29)
  end
  local count = #filtered
  displayRows = filtered
  if (tab == "flip" or tab=="listed") and expandedCraft then
    displayRows = {}
    for _, row in ipairs(filtered) do
      displayRows[#displayRows+1] = row
      if (row.craftKey or listedKeys[row]) == expandedCraft then
        local details=listedKeys[row] and Supply.Crafts.ListedDetails(char,Supply.Crafts.ListedParts(char,row),expandedMaterials) or row.members and Supply.Crafts.GroupDetails(char,row) or Supply.Crafts.Details(char,row,expandedMaterials)
        for _, detail in ipairs(details) do displayRows[#displayRows+1] = detail end
      end
    end
  end
  if panel.scroll and panel.scroll:GetVerticalScroll() > max(0, #displayRows * rowHeight - panel.scroll:GetHeight()) then
    panel.scroll:SetVerticalScroll(max(0, #displayRows * rowHeight - panel.scroll:GetHeight()))
  end
  panel.content:SetHeight(max(1, #displayRows * rowHeight))
  PaintRows()
  panel.empty:SetShown(count == 0)
  if count == 0 then
    if query ~= "" then
      panel.empty:SetText("No matching items in this tab. Clear the search to see everything.")
    elseif tab == "flip" then
      panel.empty:SetText("Crafted items appear after a linked auction sale. Bought and resold items also appear here.")
    elseif tab == "buys" then
      panel.empty:SetText(db.hideVendorBuys and #char.buys>0 and "Vendor purchases are hidden." or "No purchases tracked yet.")
    elseif tab == "recent" then
      panel.empty:SetText("No confirmed sales recorded in the last 24 hours.")
    elseif tab == "all" then
      panel.empty:SetText("No confirmed sales recorded yet.")
    elseif char.lastSync > 0 then
      panel.empty:SetText("No active auctions in your last auction-house snapshot.")
    else
      panel.empty:SetText("Visit an auctioneer once to load your listings.")
    end
  end
  panel.clearSelection:SetShown(hasSelection)
  panel.status:SetPoint("BOTTOMRIGHT", panel, "BOTTOMRIGHT", hasSelection and -86 or -44, 10)
  if hasSelection then
    panel.overallStatus:Hide()
    panel.status:SetText(SelectionSummary(query))
  elseif query ~= "" then
    panel.status:SetText("Matches " .. count .. "/" .. allCount .. " | " .. FilteredSummary(filtered, tab))
    if db.showOverallSearchTotals then
      local overall = FilteredSummary(allRows, tab)
      panel.overallStatus:SetText("All " .. allCount .. " | " .. overall)
      panel.overallStatus:Show()
    elseif panel.overallStatus then
      panel.overallStatus:Hide()
    end
  elseif tab == "flip" then
    panel.overallStatus:Hide()
    panel.status:SetText(FilteredSummary(allRows, tab))
  elseif tab == "buys" then
    if panel.overallStatus then panel.overallStatus:Hide() end
    local paid, known, estimated, estimatedCount, unknown = 0, 0, 0, 0, 0
    for _, row in ipairs(allRows) do
      if row.price and row.price > 0 and row.priceEstimated then
        estimated, estimatedCount = estimated + row.price, estimatedCount + 1
      elseif row.price and row.price > 0 then
        paid, known = paid + row.price, known + 1
      else unknown = unknown + 1 end
    end
    local status = #allRows .. " purchases  |  Confirmed spend: " ..
      (known > 0 and MoneyString(paid) or "none yet")
    if estimatedCount > 0 then
      status = status .. "  |  ~" .. MoneyString(estimated) .. " listing estimates"
    end
    if unknown > 0 then status = status .. "  |  " .. unknown .. " missing prices" end
    panel.status:SetText(status)
  elseif tab == "recent" or tab == "all" then
    if panel.overallStatus then panel.overallStatus:Hide() end
    local gross = tab == "recent" and recentGross or allGross
    local net = tab == "recent" and recentNet or allNet
    local verified = tab == "recent" and recentVerified or allVerified
    local estimated = tab == "recent" and recentEstimated or allEstimated
    local estCount = tab == "recent" and recentEstimateCount or allEstimateCount
    local unknown = tab == "recent" and recentUnknown or allUnknown
    local status
    if verified > 0 then
      status = "Verified sold: " .. MoneyString(gross) .. " gross / " ..
        MoneyString(net) .. " collected"
    else
      status = "Verified sold: none yet"
    end
    if estCount > 0 then
      status = status .. "  |  ~" .. MoneyString(estimated) .. " listed estimates (" .. estCount .. ")"
    end
    if unknown > 0 then status = status .. "  |  " .. unknown .. " awaiting mail" end
    panel.status:SetText(status)
  elseif char.lastSync and char.lastSync > 0 then
    if panel.overallStatus then panel.overallStatus:Hide() end
    local checked = date("%b %d, %I:%M %p", char.lastSync)
    panel.status:SetText(string.format("%d listed  |  AH checked %s%s",
      #char.active, checked, ahOpen and "" or " (saved snapshot)"))
  else
    if panel.overallStatus then panel.overallStatus:Hide() end
    panel.status:SetText(string.format("%d listed  |  Auction house not checked yet", #char.active))
  end
end

-- Ended listings are not sales. Persist the old auction ID so a repost with
-- a new ID can be recognized without accidentally crediting a sold total.
-- Event-proven expired/canceled outranks any inferred end state.
local function EndListing(row, reason)
  if not char or not row or not row.auctionID then return end
  if row.returnCollectedAt then reason=row.endedReason or reason end
  Supply.Crafts.End(char,row.auctionID,reason)
  RememberPosting(row)
  local id = tostring(row.auctionID)
  if not CanRead(row.auctionID) then return end
  for _, existing in ipairs(char.ended) do
    if tostring(existing.auctionID) == id then
      if reason ~= "unconfirmed" or not existing.endedReason then
        existing.endedReason = reason
      end
      existing.endedAt = existing.endedAt or clock()
      return
    end
  end
  row.endedReason = reason or "unconfirmed"
  row.endedAt = clock()
  row.sold = nil
  tinsert(char.ended, row)
end

local function RemoveEnded(id)
  if not id or not char then return nil end
  for i = #char.ended, 1, -1 do
    if char.ended[i].auctionID and tostring(char.ended[i].auctionID) == tostring(id) then
      return table.remove(char.ended, i)
    end
  end
end

-- Matching by item name alone is unsafe for stacks/duplicates. Only link a
-- repost if there is ONE plausible ended predecessor, with the same complete
-- item key and stack quantity, recently ended. Price may have changed.
local function LinkRepost(row)
  if not row or not row.itemID or not char then return end
  local candidate, matches, now = nil, 0, clock()
  for _, old in ipairs(char.ended) do
    if old.auctionID and tostring(old.auctionID) ~= tostring(row.auctionID)
        and not old.repostedAs and old.itemID == row.itemID
        and (old.itemLevel or 0) == (row.itemLevel or 0)
        and (old.itemSuffix or 0) == (row.itemSuffix or 0)
        and (old.quantity or 1) == (row.quantity or 1)
        and old.endedAt and now - old.endedAt >= 0
        and now - old.endedAt < 7 * DAY_SECONDS then
      matches, candidate = matches + 1, old
    end
  end
  if matches == 1 then
    row.repostOf = candidate.auctionID
    row.repostCount = (candidate.repostCount or 0) + 1
    candidate.repostedAs = row.auctionID
    Supply.Crafts.LinkReservedCraft(char,row)
  end
end

local function ChangeAuctionStatus(auctionID, status)
  if not char or not CanRead(auctionID) or type(auctionID) ~= "number" then return end
  local id = tostring(auctionID)
  Supply.Crafts.End(char,auctionID,status)
  for i = #char.active, 1, -1 do
    local row = char.active[i]
    if row.auctionID and tostring(row.auctionID) == id then
      table.remove(char.active, i)
      EndListing(row, status)
      break
    end
  end
  for _, row in ipairs(char.deleted) do
    if row.deletedKind == "listed" and row.auctionID
        and tostring(row.auctionID) == id then
      EndListing(row, status)
      break
    end
  end
  for _, row in ipairs(char.ended) do
    if row.auctionID and tostring(row.auctionID) == id then
      if status ~= "unconfirmed" or not row.endedReason then row.endedReason = status end
      row.endedAt = row.endedAt or clock()
    end
  end
  if Render then Render() end
end

-- A sorted, display-independent snapshot key. Blizzard can emit multiple
-- OWNED_AUCTIONS_UPDATED events for the *same* auctions (including when its
-- list is sorted). Skip processing/repainting these unchanged updates.
-- Do not include countdown seconds, which vary without any accounting change.
local function OwnedSignature(owned)
  local keys, ids = {}, {}
  for _, info in ipairs(owned) do
    if not CanRead(info) or type(info) ~= "table" then return nil end
    local id = info.auctionID
    if not CanRead(id) or type(id) ~= "number" or id <= 0 or ids[id] then return nil end
    ids[id] = true
    if not CanRead(info.itemKey) or not CanRead(info.itemLink)
        or not CanRead(info.timeLeftSeconds) then return nil end
    local key = info.itemKey or {}
    if type(key) ~= "table" then return nil end
    local values = {
      info.auctionID, key.itemID, key.itemLevel, key.itemSuffix,
      info.quantity, info.bidAmount, info.buyoutAmount, info.unitPrice,
      info.status, info.timeLeft,
    }
    local components = {}
    for i=1, 10 do
      if not CanRead(values[i]) then return nil end
      components[i] = tostring(values[i] or "")
    end
    keys[#keys+1] = table.concat(components, ":")
  end
  table.sort(keys)
  return table.concat(keys, "|")
end

local function ReadOwnedAuctions()
  if not ahOpen or not char or not C_AuctionHouse or not C_AuctionHouse.GetOwnedAuctions then return end
  if C_AuctionHouse.HasFullOwnedAuctionResults then
    local ok, full = pcall(C_AuctionHouse.HasFullOwnedAuctionResults)
    if not ok or not CanRead(full) or not full then return end
  end
  local ok, owned = pcall(C_AuctionHouse.GetOwnedAuctions)
  if not ok or not CanRead(owned) or type(owned) ~= "table" then return end
  local signature = OwnedSignature(owned)
  if not signature or signature == lastOwnedSignature then return end
  local now = clock()
  local prior, deletedByID, deletedSoldByID, soldByID, seen, active = {}, {}, {}, {}, {}, {}
  for _, row in ipairs(char.active) do
    if row.auctionID then prior[tostring(row.auctionID)] = row end
  end
  for _, row in ipairs(char.deleted) do
    if row.auctionID then
      if row.deletedKind == "listed" then
        deletedByID[tostring(row.auctionID)] = row
      elseif row.deletedKind == "sold" then
        deletedSoldByID[tostring(row.auctionID)] = row
      end
    end
  end
  for _, row in ipairs(char.sold) do
    if row.auctionID then soldByID[tostring(row.auctionID)] = row end
  end
  -- Complete the snapshot's ID set before associating any new auctions.
  -- A cancel/expiration and repost can both happen between two scans; the
  -- previous auction must be marked ended BEFORE linking the new ID.
  for _, info in ipairs(owned) do
    if CanRead(info) and type(info) == "table" and CanRead(info.auctionID)
        and info.auctionID then seen[tostring(info.auctionID)] = true end
  end
  for id, old in pairs(prior) do
    if not seen[id] and not soldByID[id] then
      if firstOwnedSnapshotAfterLogin then
        old.missingAfterLogin=true
        old.lastKnownAuctionSync=char.lastSync
      end
      EndListing(old, "unconfirmed")
    end
  end
  for id, old in pairs(deletedByID) do
    if not seen[id] and not soldByID[id] then
      if firstOwnedSnapshotAfterLogin then
        old.missingAfterLogin=true
        old.lastKnownAuctionSync=char.lastSync
      end
      EndListing(old, "unconfirmed")
    end
  end
  local rows={}
  for _,info in ipairs(owned) do
    if CanRead(info) and type(info)=="table" and CanRead(info.auctionID) then
      local row=NewAuctionRow(info)
      if row then rows[#rows+1]=row end
    end
  end
  Supply.ObserveSoldStacks(char,rows)
  for _,row in ipairs(rows) do
    if row.auctionID then
      RememberPosting(row)
      RememberQuantityEvidence(row,false)
      if row.sold then Supply.Crafts.ConfirmSoldID(char,row,true) end
      Supply.Crafts.Observe(char,row)
      local id = tostring(row.auctionID)
      seen[id] = true
      if row.sold then
        local previous = soldByID[id] or deletedSoldByID[id] or prior[id] or deletedByID[id]
        if previous then
          row.soldAt = previous.soldAt
          row.saleTimeSource=previous.saleTimeSource
          row.repostOf, row.repostCount = previous.repostOf, previous.repostCount
          row.firstSeenAt = previous.firstSeenAt
        end
        if not row.soldAt then row.saleTimeSource="owned_snapshot" end
        RemoveEnded(id)
        if deletedSoldByID[id] then
          -- Don't resurrect a deliberately deleted sale on the next AH scan.
          -- Keep any mailbox-confirmed figures attached to the archived row.
          local hiddenSale = deletedSoldByID[id]
          hiddenSale.seenAt = now
          if (not hiddenSale.buyout or hiddenSale.buyout <= 0) and row.buyout then
            hiddenSale.buyout = row.buyout
          end
        else
          -- A hidden ACTIVE listing can legitimately sell: move it to Sold.
          if deletedByID[id] then
            for i = #char.deleted, 1, -1 do
              if char.deleted[i] == deletedByID[id] then
                table.remove(char.deleted, i); break
              end
            end
            char.hiddenAuctions[id] = nil
            if RefreshDeletedPanel then RefreshDeletedPanel() end
          end
          AddSold(row)
        end
      else
        local previous = prior[id] or deletedByID[id]
        if previous then
          row.firstSeenAt = previous.firstSeenAt or previous.seenAt
          row.repostOf, row.repostCount = previous.repostOf, previous.repostCount
          if deletedByID[id] then
            -- Update the hidden copy too, including any changed price/time.
            local hidden = deletedByID[id]
            hidden.bid, hidden.buyout = row.bid, row.buyout
            hidden.endTime, hidden.seenAt = row.endTime, row.seenAt
            hidden.endedAt, hidden.endedReason = nil, nil
          end
        else
          local old = RemoveEnded(id)
          if old then
            row.firstSeenAt, row.repostOf, row.repostCount = old.firstSeenAt,
              old.repostOf, old.repostCount
          else
            row.firstSeenAt = now
            LinkRepost(row)
          end
        end
        if not char.hiddenAuctions[id] then tinsert(active, row) end
      end
    end
  end
  -- Bound only the technical ended/repost journal. Sales and the user's
  -- deleted history are not pruned; retain up to 60d / 1200 ended cycles.
  local ended = char.ended
  for i = #ended, 1, -1 do
    if now - (ended[i].endedAt or now) > HISTORY_RETENTION then
      table.remove(ended, i)
    end
  end
  if #ended > 1200 then
    sort(ended, function(a,b) return (a.endedAt or 0) > (b.endedAt or 0) end)
    for i = #ended, 1201, -1 do ended[i] = nil end
  end
  char.active = active
  char.lastSync = now
  firstOwnedSnapshotAfterLogin=false
  lastOwnedSignature = signature
  Supply.QueueReceiptReview()
  Render()
end

-- Explicit user refresh ONLY. QueryOwnedAuctions({}, ...) resets the default
-- native sort on this client, so never call this from timers, AH open, posting,
-- cancellation, or sale events. Ordinary tracking uses Blizzard updates.
local function RequestRefresh()
  if not ahOpen or not C_AuctionHouse or not C_AuctionHouse.QueryOwnedAuctions then return end
  if refreshQueued then return end
  refreshQueued = true
  local epoch = refreshEpoch
  local delay = max(1.1, MIN_QUERY_GAP - (GetTime() - lastQueryAt))
  local function doQuery()
    if epoch ~= refreshEpoch then return end -- Closed/reopened since scheduling.
    refreshQueued = false
    if not ahOpen then return end
    if C_AuctionHouse.IsThrottledMessageSystemReady then
      local ok, ready = pcall(C_AuctionHouse.IsThrottledMessageSystemReady)
      if not ok or not ready then
        retryWhenReady = true
        -- The ready event is preferred; two delayed checks cover missed events.
        if autoRetryCount < 2 and C_Timer and C_Timer.After then
          autoRetryCount = autoRetryCount + 1
          C_Timer.After(5, function()
            if epoch == refreshEpoch and ahOpen and retryWhenReady then RequestRefresh() end
          end)
        end
        return
      end
    end
    lastQueryAt = GetTime()
    -- The required argument is an array of sort descriptors; empty uses default.
    local ok = pcall(C_AuctionHouse.QueryOwnedAuctions, {})
    if ok then
      retryWhenReady = false
      autoRetryCount = 0
    else
      -- Avoid breaking the AH UI if another addon is using the query channel.
      retryWhenReady = true
    end
  end
  if C_Timer and C_Timer.After then C_Timer.After(delay, doQuery) else doQuery() end
end

local function SoldTextFromSystem(message)
  if not CanRead(message) or type(message) ~= "string" then return nil end
  if CanRead(ERR_AUCTION_SOLD_S) and type(ERR_AUCTION_SOLD_S) == "string" then
    local pattern = ERR_AUCTION_SOLD_S:gsub("([%^%$%(%)%.%[%]%*%+%-%?])", "%%%1")
    pattern = pattern:gsub("%%s", "(.+)")
    local found = message:match("^" .. pattern .. "$")
    if found and found ~= "" then return found end
  end
  return message:match("^A buyer has been found for your auction of (.+)%.$")
      or message:match("^Your auction of (.+) has sold%.$")
end

local recentExactSales={}
local function RecordSale(found, auctionID)
  if not char or not CanRead(found) or type(found) ~= "string" then return end
  if not CanRead(auctionID) or type(auctionID) ~= "number" then auctionID = nil end
  local now, itemName = clock(), PlainName(found)
  if itemName == "" then return end
  local normalized = NameKey(itemName)
  local id = auctionID and tostring(auctionID) or nil
  -- A chat echo immediately after an exact notification must not claim the
  -- next identical active auction. A second exact ID is always processed.
  if id then
    for name,at in pairs(recentExactSales) do
      if now-at>2 then recentExactSales[name]=nil end
    end
    recentExactSales[normalized]=now
  elseif recentExactSales[normalized] and now-recentExactSales[normalized]<=2 then
    recentExactSales[normalized]=nil
    return
  end
  local matchedAt, matchedEnded, matchedHidden
  if id then
    for i, entry in ipairs(char.active) do
      if entry.auctionID and tostring(entry.auctionID) == id then
        matchedAt = i; break
      end
    end
    if not matchedAt then
      for _, old in ipairs(char.sold) do
        if old.auctionID and tostring(old.auctionID)==id then
          if NameKey(old.name or old.link)==normalized then
            Supply.Crafts.ConfirmSoldID(char,old)
            Supply.Crafts.Sale(char,old)
            Render()
          end
          return
        end
      end
      for _, old in ipairs(char.deleted) do
        if old.deletedKind == "sold" and old.auctionID
            and tostring(old.auctionID) == id then return end
      end
      for i, entry in ipairs(char.deleted) do
        if entry.deletedKind == "listed" and entry.auctionID
            and tostring(entry.auctionID) == id then
          matchedHidden = i; break
        end
      end
      if not matchedHidden then
        for i, entry in ipairs(char.ended) do
          if entry.auctionID and tostring(entry.auctionID) == id then
            matchedEnded = i; break
          end
        end
      end
    end
    -- CRITICAL: when an exact auction ID was supplied, NEVER fall back to
    -- a current same-name listing. That could be an expired auction's repost.
  else
    local count = 0
    for i, entry in ipairs(char.active) do
      if NameKey(entry.name or entry.link) == normalized then
        count, matchedAt = count + 1, i
      end
    end
    -- An id-less chat echo might describe the PREVIOUS auction cycle after
    -- its same-name replacement was posted. Favor an unassigned placeholder
    -- until auction mail provides independent confirmation.
    for _, ended in ipairs(char.ended) do
      if NameKey(ended.name or ended.link) == normalized
          and ended.endedAt and now - ended.endedAt < DAY_SECONDS then
        count = count + 1
      end
    end
    if count ~= 1 then matchedAt = nil end
  end
  if not id and not matchedAt and not matchedEnded and not matchedHidden then
    for _, old in ipairs(char.sold) do
      if not old.receiptID and NameKey(old.name or old.link) == normalized
          and now - (old.soldAt or 0) >= 0 and now - (old.soldAt or 0) <= 2
          and not old.auctionID then
        return
      end
    end
  end
  local row
  if matchedAt then row = table.remove(char.active, matchedAt)
  elseif matchedHidden then
    row = table.remove(char.deleted, matchedHidden)
    char.hiddenAuctions[id] = nil
    row.deletedAt, row.deletedKind = nil, nil
    if RefreshDeletedPanel then RefreshDeletedPanel() end
  elseif matchedEnded then
    local ended = char.ended[matchedEnded]
    local post = char.craftLedger and char.craftLedger.posts[id]
    if (ended.endedReason=="expired" or ended.endedReason=="canceled") and
        (ended.quantity~=1 or NameKey(ended.name or ended.link)~=normalized
          or ended.returnCollectedAt
          or (post and (post.returnedUnits or post.remainderTo))) then
      -- The old listing is explicitly confirmed to have ended unsold. Do
      -- not upgrade that old ID or its new repost to a sale via a late notice.
      return
    end
    row = table.remove(char.ended, matchedEnded)
  else row = {name = itemName, link = found:find("|Hitem:", 1, true) and found or nil}
  end
  row.sold, row.soldAt = true, now
  row.endedAt, row.endedReason = nil, nil
  if id then row.auctionID = auctionID end
  row.endTime = nil
  if not (matchedAt or matchedHidden or matchedEnded) then
    row.buyout, row.bid = nil, nil
  end
  if id and NameKey(row.name or row.link)==normalized then
    local post=char.craftLedger and char.craftLedger.posts[id]
    if post and type(post.quantity)=="number" and post.quantity>0 and post.itemID then
      row.quantity=row.quantity or post.quantity
      row.itemID=row.itemID or post.itemID
      row.buyout=row.buyout or post.totalPrice
      if post.createdKey and not (matchedAt or matchedHidden or matchedEnded) then
        for k,v in pairs(post.createdKey) do row[k]=row[k] or v end
        if post.quantity==1 then LinkRepost(row) end
      end
    end
    Supply.Crafts.ConfirmSoldID(char,row)
  end
  AddSold(row)
  Render()
end

local function ChatSale(message)
  if not char or not CanRead(message) then return end
  local found = SoldTextFromSystem(message)
  if not found then return end
  -- Suppress one chat line delivered more than once in the same instant.
  if message == lastMessage and GetTime() - lastMessageTime < 0.1 then return end
  lastMessage, lastMessageTime = message, GetTime()
  RecordSale(found, nil)
  -- Never force Blizzard's owned-auction sort to reset on a sale message.
  -- Its next OWNED_AUCTIONS_UPDATED event supplies the normal snapshot.
end

local function AuctionNotification(notification, itemText, auctionID)
  if not CanRead(notification) or not CanRead(itemText) then return end
  local soldEnum = Enum and Enum.AuctionHouseNotification
      and Enum.AuctionHouseNotification.AuctionSold or 4
  if notification ~= soldEnum or type(itemText) ~= "string" then return end
  if not CanRead(auctionID) then auctionID = nil end
  -- Unlike CHAT_MSG_SYSTEM, this event supplies the item/format argument,
  -- and may also include the exact auction ID.
  RecordSale(SoldTextFromSystem(itemText) or itemText, auctionID)
end

local function ApplyBackgrounds()
  if not panel or not db then return end
  local opacity = db.solid and 1 or 0.78
  panel.background:SetColorTexture(0, 0, 0, opacity)
  if settingsPanel then settingsPanel.background:SetColorTexture(0, 0, 0, opacity) end
  if deletedPanel then deletedPanel.background:SetColorTexture(0, 0, 0, opacity) end
end

local function DrawBorder(frame)
  local border = frame:CreateTexture(nil, "BORDER")
  border:SetPoint("TOPLEFT", frame, "TOPLEFT", -1, 1)
  border:SetPoint("BOTTOMRIGHT", frame, "BOTTOMRIGHT", 1, -1)
  border:SetColorTexture(0.47,0.43,0.35,0.7)
  local bg = frame:CreateTexture(nil, "BACKGROUND")
  bg:SetAllPoints()
  bg:SetColorTexture(0,0,0,1)
  frame.background = bg
end

local function Label(parent, text, x, y, width, align)
  local fs = parent:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
  fs:SetPoint("TOPLEFT", parent, "TOPLEFT", x, y)
  fs:SetWidth(width)
  fs:SetJustifyH(align or "LEFT")
  fs:SetText(text)
  return fs
end

-- Keep the local history prompt entirely inside Auction Peek.
ShowDeleteConfirmation = function(entry, kind, name)
  local dialog = panel.deleteConfirmation
  if not dialog then
    dialog = CreateFrame("Frame", "AuctionPeekDeleteConfirmation", panel)
    panel.deleteConfirmation = dialog
    dialog:SetSize(330, 118)
    dialog:SetPoint("CENTER")
    dialog:SetFrameStrata("DIALOG")
    dialog:EnableMouse(true)
    DrawBorder(dialog)
    dialog.message = Label(dialog, "", 14, -15, 302, "CENTER")
    local accept = CreateFrame("Button", nil, dialog, "UIPanelButtonTemplate")
    accept:SetSize(100, 22)
    accept:SetPoint("BOTTOMRIGHT", dialog, "BOTTOM", -4, 10)
    accept:SetText("Delete")
    accept:SetScript("OnClick", function()
      local target, targetKind = dialog.entry, dialog.kind
      dialog:Hide()
      if target then MoveToDeleted(target, targetKind) end
    end)
    local cancel = CreateFrame("Button", nil, dialog, "UIPanelButtonTemplate")
    cancel:SetSize(100, 22)
    cancel:SetPoint("BOTTOMLEFT", dialog, "BOTTOM", 4, 10)
    cancel:SetText(CANCEL or "Cancel")
    cancel:SetScript("OnClick", function() dialog:Hide() end)
    dialog:SetScript("OnHide", function()
      dialog.entry, dialog.kind = nil, nil
    end)
    panel:HookScript("OnHide", function() dialog:Hide() end)
    if UISpecialFrames then tinsert(UISpecialFrames, "AuctionPeekDeleteConfirmation") end
  end
  dialog.entry, dialog.kind = entry, kind
  dialog.message:SetText("Remove " .. name .. " from Auction Peek history?\n\nRestore it anytime under Options > Deleted Entries.")
  dialog:Show()
end

-- Small evidence-review dialog; never touches the canonical cost or sales ledgers.
-- Evidence-first confirmation: the user must see the actual purchase, cast,
-- and receipt records. No saved purchase, sale or lot is changed by opening it.
local function DEReviewText(r)
  local out={}
  local function add(value) out[#out+1]=value end
  local function funds(copper)
    if type(copper)~="number" then return "unknown" end
    if copper==0 then return "0c" end
    return MoneyString(copper)
  end
  local function when(ts)
    return type(ts)=="number" and date("%b %d %I:%M %p",ts) or "time unavailable"
  end
  add("|cffffd46bAH PURCHASE EVIDENCE|r")
  add(tostring(r.inputName).."   verified unit price "..funds(r.inputUnitCost))
  for _,b in ipairs(r.purchases) do
    add("  Purchase #"..b.id.."  1x "..funds(b.price).."   "..when(b.at))
  end
  add("|cffffd46bDISENCHANT EVIDENCE|r")
  for _,cast in ipairs(r.casts) do
    add("  "..when(cast.at)..": "..tostring(cast.qty).."x "..r.outputName.."  [bag/loot verified]")
  end
  add("  Total output: "..r.outputQty.."x "..r.outputName)
  add("|cffffd46bCOLLECTED MAIL RECEIPTS|r")
  local qty,gross,cut,deposit,net=0,0,0,0,0
  for _,receipt in ipairs(r.receipts) do
    add("  "..receipt.id.."   "..receipt.qty.."x  gross "..funds(receipt.gross)..
      "   collected "..funds(receipt.net))
    add("     AH fee "..funds(receipt.fee).."   deposit returned "..funds(receipt.deposit))
    qty=qty+receipt.qty;gross=gross+receipt.gross
    cut=cut+receipt.fee;deposit=deposit+receipt.deposit;net=net+receipt.net
  end
  add("  Receipt total "..qty.."x   gross "..funds(gross)..
    "   AH fees "..funds(cut).."   returned "..funds(deposit))
  add("|cffffd46bGROUP CALCULATION (ONCE)|r")
  add("  Net collected: "..funds(r.net).."   DE input cost: "..funds(r.inputCost))
  add("  Candidate P/L: "..(r.profit<0 and "-" or "+")..funds(math.abs(r.profit)))
  add("|cffff7b7bNOT PROVEN: original full-stack auction ID or inventory-lot allocation.|r")
  add("Player confirmation records this historical batch only. No auction IDs, mail,")
  add("Buy History, Flip, or inventory costs are rewritten. Posting costs may remain.")
  return table.concat(out,"\n")
end
ShowDEConfirmation = function(data)
  if not data or not data.deAction or not data.deGuid then return end
  local dialog=panel.deConfirmation
  if not dialog then
    dialog=CreateFrame("Frame","AuctionPeekDEConfirmation",UIParent)
    panel.deConfirmation=dialog
    dialog:SetSize(570,460)
    dialog:SetPoint("CENTER",UIParent,"CENTER")
    dialog:SetFrameStrata("DIALOG")
    dialog:EnableMouse(true)
    dialog:SetClampedToScreen(true)
    DrawBorder(dialog)
    dialog.heading=Label(dialog,"DE Test - Evidence Review",14,-14,542,"CENTER")
    dialog.heading:SetTextColor(1,0.83,0.35)
    dialog.intro=Label(dialog,"",18,-43,530,"LEFT")
    dialog.intro:SetHeight(35)
    dialog.intro:SetJustifyV("TOP")
    local scroll=CreateFrame("ScrollFrame",nil,dialog,"UIPanelScrollFrameTemplate")
    scroll:SetPoint("TOPLEFT",dialog,"TOPLEFT",18,-87)
    scroll:SetSize(518,289)
    dialog.scroll=scroll
    local content=CreateFrame("Frame",nil,scroll)
    content:SetSize(490,320)
    dialog.scrollContent=content
    scroll:SetScrollChild(content)
    dialog.body=Label(content,"",2,-2,483,"LEFT")
    dialog.body:SetJustifyV("TOP")
    dialog.body:SetWordWrap(true)
    dialog.body:SetHeight(310)
    dialog.warning=Label(dialog,"",18,-385,525,"LEFT")
    dialog.warning:SetHeight(34)
    dialog.warning:SetJustifyV("TOP")
    local approve=CreateFrame("Button",nil,dialog,"UIPanelButtonTemplate")
    approve:SetSize(130,24)
    approve:SetPoint("BOTTOMLEFT",dialog,"BOTTOM",-142,16)
    dialog.approve=approve
    approve:SetScript("OnClick",function()
      local d=dialog.data
      if not d then return end
      local ok,message
      if d.deAction=="auto" then ok,message=Supply.DETest.AutoUndo(char,d.deGuid)
      elseif d.deAction=="batch" then ok,message=Supply.DETest.BatchConfirm(char,d.deGuid,d.deOutputID,d.deManualConfirmed)
      else ok,message=Supply.DETest.ManualSet(char,d.deGuid,d.deAction,d.deAuctionID,d.deManualConfirmed) end
      dialog:Hide()
      if not ok and DEFAULT_CHAT_FRAME then
        DEFAULT_CHAT_FRAME:AddMessage("|cffffcc00Auction Peek DE:|r "..tostring(message))
      end
      Render()
    end)
    local cancel=CreateFrame("Button",nil,dialog,"UIPanelButtonTemplate")
    cancel:SetSize(130,24)
    cancel:SetPoint("BOTTOMRIGHT",dialog,"BOTTOM",142,16)
    cancel:SetText(CANCEL or "Cancel")
    cancel:SetScript("OnClick",function()dialog:Hide()end)
    dialog:SetScript("OnHide",function(self)self.data=nil end)
    panel:HookScript("OnHide",function()dialog:Hide()end)
    if UISpecialFrames then tinsert(UISpecialFrames,"AuctionPeekDEConfirmation") end
  end
  dialog.data={deGuid=data.deGuid,deAction=data.deAction,
    deAuctionID=data.deAuctionID,deOutputID=data.deOutputID,
    deManualConfirmed=data.deManualConfirmed}
  local linked=data.deManualConfirmed
  local content
  if data.deAction=="batch" then
    local review,reason=Supply.DETest.BatchReview(char,data.deGuid,data.deOutputID)
    if review then
      dialog.approve:Enable()
      dialog.intro:SetText(linked and "Review the saved group before REVOCATION:" or
        "Review the actual records before confirming this historical DE batch:")
      content=DEReviewText(review)
      dialog.warning:SetText("|cffffbb66This is your attribution, not verified auction-ID linkage.|r")
    else
      dialog.approve:Disable()
      dialog.intro:SetText("Confirmation unavailable. Evidence could not be revalidated.")
      content="|cffff7777"..tostring(reason or "Unknown evidence error").."|r\n\nNo changes have been made."
      dialog.warning:SetText("Cancel and inspect the DE Test history.")
    end
  else
    dialog.approve:Enable()
    dialog.intro:SetText("Review the source details before changing this attribution:")
    if data.deAction=="auto" then
      content="Disable or retry automatic DE attribution?\n\n"..tostring(data.detail)..
        "\n\nThis does not delete purchase, auction or mail records."
    elseif data.deAction=="cost" then
      content=(linked and "Undo this manual purchase link?" or "Confirm the purchase was the disenchanted item?").."\n\n"..
        tostring(data.detail).."\n\nNo purchase or inventory cost records change."
    else
      content=(linked and "Undo this output-to-auction link?" or
        "Confirm all auction units came from this exact DE?").."\n\n"..
        tostring(data.detail).."\n\nMixed bag inventory can make allocation wrong; inventory lots stay unchanged."
    end
    dialog.warning:SetText("This is read-only to the purchase and inventory ledgers.")
  end
  dialog.body:SetText(content)
  local height=math.max(295,(dialog.body:GetStringHeight() or 0)+12)
  dialog.body:SetHeight(height)
  dialog.scrollContent:SetHeight(height+4)
  dialog.scroll:SetVerticalScroll(0)
  dialog.approve:SetText(data.deAction=="auto" and "Toggle Auto"
    or linked and "Undo Link" or data.deAction=="batch" and "Confirm Batch" or "Confirm Link")
  dialog:Show()
end

local function MakeDeletedPanel()
  deletedPanel = CreateFrame("Frame", "AuctionPeekDeletedWindow", UIParent)
  deletedPanel:SetSize(540, 375)
  deletedPanel:SetPoint("CENTER", UIParent, "CENTER", 10, 0)
  deletedPanel:SetFrameStrata("DIALOG")
  deletedPanel:SetClampedToScreen(true)
  deletedPanel:SetMovable(true)
  deletedPanel:EnableMouse(true)
  deletedPanel:RegisterForDrag("LeftButton")
  deletedPanel:SetScript("OnDragStart", function(self) self:StartMoving() end)
  deletedPanel:SetScript("OnDragStop", function(self) self:StopMovingOrSizing() end)
  DrawBorder(deletedPanel)
  deletedPanel:Hide()
  if UISpecialFrames then tinsert(UISpecialFrames, "AuctionPeekDeletedWindow") end
  local caption = Label(deletedPanel, "Deleted Entries  |  Click Restore to undo deletion", 15, -14, 455)
  caption:SetTextColor(1, 0.79, 0.48)
  local close = CreateFrame("Button", nil, deletedPanel, "UIPanelCloseButton")
  close:SetPoint("TOPRIGHT", 0, 0)
  close:SetScript("OnClick", function() deletedPanel:Hide() end)
  local hint = Label(deletedPanel,
    "Listed deletions are only hidden locally. Restoring an expired listing does not reopen it.",
    15, -43, 505)
  hint:SetTextColor(0.7, 0.7, 0.7)
  local buttons = {}
  for i = 1, 10 do
    local row = CreateFrame("Frame", nil, deletedPanel)
    row:SetSize(514, 24)
    row:SetPoint("TOPLEFT", 13, -(64 + (i - 1) * 25))
    local stripe = row:CreateTexture(nil, "BACKGROUND")
    stripe:SetAllPoints()
    stripe:SetColorTexture(0.07, 0.07, 0.07, i % 2 == 0 and 0.9 or 0.45)
    local txt = row:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
    txt:SetPoint("LEFT", 8, 0)
    txt:SetWidth(405)
    txt:SetJustifyH("LEFT")
    txt:SetWordWrap(false)
    local restore = CreateFrame("Button", nil, row, "UIPanelButtonTemplate")
    restore:SetSize(77, 21)
    restore:SetPoint("RIGHT", row, "RIGHT", -3, 0)
    restore:SetText("Restore")
    restore:SetScript("OnClick", function(self)
      if self.trashIndex then RestoreDeleted(self.trashIndex) end
    end)
    row.text, row.restore = txt, restore
    buttons[i] = row
  end
  local previous = CreateFrame("Button", nil, deletedPanel, "UIPanelButtonTemplate")
  previous:SetSize(74, 22)
  previous:SetPoint("BOTTOMLEFT", 15, 12)
  previous:SetText("Previous")
  previous:SetScript("OnClick", function()
    deletedPage = max(1, deletedPage - 1)
    RefreshDeletedPanel()
  end)
  local next = CreateFrame("Button", nil, deletedPanel, "UIPanelButtonTemplate")
  next:SetSize(74, 22)
  next:SetPoint("BOTTOMRIGHT", -15, 12)
  next:SetText("Next")
  next:SetScript("OnClick", function()
    deletedPage = deletedPage + 1
    RefreshDeletedPanel()
  end)
  local paging = Label(deletedPanel, "", 195, -346, 150, "CENTER")
  paging:ClearAllPoints()
  paging:SetPoint("BOTTOM", 0, 16)
  RefreshDeletedPanel = function()
    if not deletedPanel or not char then return end
    local entries = {}
    for i, entry in ipairs(char.deleted) do
      tinsert(entries, {index = i, entry = entry})
    end
    sort(entries, function(a,b)
      if a.entry.deletedAt ~= b.entry.deletedAt then
        return (a.entry.deletedAt or 0) > (b.entry.deletedAt or 0)
      end
      return a.index > b.index
    end)
    local pages = max(1, math.ceil(#entries / #buttons))
    deletedPage = min(max(1, deletedPage), pages)
    for i, frame in ipairs(buttons) do
      local selected = entries[(deletedPage - 1) * #buttons + i]
      if selected then
        local entry = selected.entry
        local name = PlainName(entry.name or entry.link)
        local kind = entry.deletedKind == "buys" and "Bought" or
          entry.deletedKind == "sold" and "Sold" or "Listed"
        local ended = entry.endedAt and " [ended]" or ""
        frame.text:SetText(kind .. ": " .. name .. ended)
        frame.restore.trashIndex = selected.index
        frame:Show()
      else
        frame.restore.trashIndex = nil
        frame:Hide()
      end
    end
    paging:SetText(deletedPage .. " / " .. pages .. "  (" .. #entries .. " entries)")
    previous:SetEnabled(deletedPage > 1)
    next:SetEnabled(deletedPage < pages)
  end
  deletedPanel:SetScript("OnShow", function() RefreshDeletedPanel() end)
end

local function MakeSettings()
  settingsPanel = CreateFrame("Frame", "AuctionPeekSettings", UIParent)
  settingsPanel:SetSize(332, 470)
  settingsPanel:SetPoint("CENTER", UIParent, "CENTER", 0, 0)
  settingsPanel:SetFrameStrata("DIALOG")
  settingsPanel:SetClampedToScreen(true)
  DrawBorder(settingsPanel)
  settingsPanel:Hide()
  if UISpecialFrames then tinsert(UISpecialFrames, "AuctionPeekSettings") end
  Label(settingsPanel, "Auction Peek - Settings  v"..VERSION, 15, -14, 290)
  local close = CreateFrame("Button", nil, settingsPanel, "UIPanelCloseButton")
  close:SetPoint("TOPRIGHT", 0, 0)
  close:SetScript("OnClick", function() settingsPanel:Hide() end)

  local solid = CreateFrame("CheckButton", nil, settingsPanel, "UICheckButtonTemplate")
  solid:SetPoint("TOPLEFT", 12, -42)
  solid:SetChecked(db.solid)
  Label(settingsPanel, "Solid black / opaque background", 43, -52, 260)
  solid:SetScript("OnClick", function(self)
    db.solid = self:GetChecked() and true or false
    ApplyBackgrounds()
  end)

  local mini = CreateFrame("CheckButton", nil, settingsPanel, "UICheckButtonTemplate")
  mini:SetPoint("TOPLEFT", 12, -79)
  mini:SetChecked(db.showMinimap)
  Label(settingsPanel, "Show minimap button", 43, -89, 260)
  mini:SetScript("OnClick", function(self)
    db.showMinimap = self:GetChecked() and true or false
    if minimapButton then minimapButton:SetShown(db.showMinimap) end
  end)

  local listingCount = CreateFrame("CheckButton", nil, settingsPanel, "UICheckButtonTemplate")
  listingCount:SetPoint("TOPLEFT", 12, -116)
  listingCount:SetChecked(db.showListingCount)
  Label(settingsPanel, "Show listing counts and sale quantities", 43, -126, 260)
  listingCount:SetScript("OnClick", function(self)
    db.showListingCount = self:GetChecked() and true or false
    Render()
  end)

  local resetMini = CreateFrame("Button", nil, settingsPanel, "UIPanelButtonTemplate")
  resetMini:SetSize(198, 23)
  resetMini:SetPoint("TOPLEFT", settingsPanel, "TOPLEFT", 23, -155)
  resetMini:SetText("Reset minimap button position")
  resetMini:SetScript("OnClick", function()
    if not db then return end
    db.minimapX, db.minimapY = nil, nil
    if minimapButton then
      -- PositionMinimapButton() is assigned during construction below.
      minimapButton:ClearAllPoints()
      local mx, my = Minimap and Minimap:GetCenter()
      local px, py = UIParent:GetCenter()
      if mx and my and px and py then
        local radius = math.min(Minimap:GetWidth(), Minimap:GetHeight()) / 2 + 2
        local angle = math.rad(db.minimapAngle or 210)
        db.minimapX = mx - px + math.cos(angle) * radius
        db.minimapY = my - py + math.sin(angle) * radius
      else
        db.minimapX, db.minimapY = 0, 0
      end
      minimapButton:SetPoint("CENTER", UIParent, "CENTER", db.minimapX, db.minimapY)
    end
  end)

  local deletedButton = CreateFrame("Button", nil, settingsPanel, "UIPanelButtonTemplate")
  deletedButton:SetSize(198, 23)
  deletedButton:SetPoint("TOPLEFT", settingsPanel, "TOPLEFT", 23, -191)
  deletedButton:SetText("Deleted Entries / Restore")
  deletedButton:SetScript("OnClick", function()
    if deletedPanel then deletedPanel:SetShown(not deletedPanel:IsShown()) end
  end)
  local showSearch = CreateFrame("CheckButton", nil, settingsPanel, "UICheckButtonTemplate")
  showSearch:SetPoint("TOPLEFT", 12, -228)
  showSearch:SetChecked(db.showHistorySearch ~= false)
  Label(settingsPanel, "Show history search and sorting", 43, -238, 265)
  showSearch:SetScript("OnClick", function(self)
    db.showHistorySearch = self:GetChecked() and true or false
    if not db.showHistorySearch then
      searchText = ""
      if panel and panel.searchEdit then panel.searchEdit:SetText("") end
    end
    LayoutTable()
    Render()
  end)

  local showShortcut = CreateFrame("CheckButton", nil, settingsPanel, "UICheckButtonTemplate")
  showShortcut:SetPoint("TOPLEFT", 12, -265)
  showShortcut:SetChecked(db.showShadyShortcut ~= false)
  Label(settingsPanel, "Show optional Shady Search shortcut", 43, -275, 268)
  showShortcut:SetScript("OnClick", function(self)
    db.showShadyShortcut = self:GetChecked() and true or false
    if panel and panel.shadyButton then panel.shadyButton:SetShown(db.showShadyShortcut) end
  end)

  local showTotals = CreateFrame("CheckButton", nil, settingsPanel, "UICheckButtonTemplate")
  showTotals:SetPoint("TOPLEFT", 12, -302)
  showTotals:SetChecked(db.showOverallSearchTotals == true)
  Label(settingsPanel, "Show overall totals below filtered totals", 43, -312, 274)
  showTotals:SetScript("OnClick", function(self)
    db.showOverallSearchTotals = self:GetChecked() and true or false
    Render()
  end)
  local earnings = CreateFrame("CheckButton", nil, settingsPanel, "UICheckButtonTemplate")
  earnings:SetPoint("TOPLEFT", 12, -339)
  earnings:SetChecked(db.showItemEarnings ~= false)
  Label(settingsPanel, "Show all-time item earnings on hover", 43, -349, 274)
  earnings:SetScript("OnClick", function(self)
    db.showItemEarnings = self:GetChecked() and true or false
  end)
  local desc = Label(settingsPanel,
    "Shift+click a row to delete (restorable). Search items, item IDs, or auction IDs in the current tab.",
    17, -392, 297)
  desc:SetTextColor(0.72, 0.72, 0.72)
  desc:SetJustifyH("CENTER")

  local tribute = settingsPanel:CreateFontString(nil, "OVERLAY")
  tribute:SetPoint("BOTTOM", settingsPanel, "BOTTOM", 0, 9)
  local loaded = tribute:SetFont("Fonts\\MORPHEUS.TTF", 12, "OUTLINE")
  if not loaded then tribute:SetFontObject("GameFontNormalSmall") end
  tribute:SetTextColor(0.83, 0.68, 0.33)
  tribute:SetText("RIP Shady")
  ApplyBackgrounds()
end

local function SavePanelGeometry()
  if not panel or not db then return end
  local x, y = panel:GetCenter()
  local px, py = UIParent:GetCenter()
  if x and px then db.x, db.y = x - px, y - py end
  db.width = floor(panel:GetWidth() + 0.5)
  db.height = floor(panel:GetHeight() + 0.5)
end

local function MakePanel()
  panel = CreateFrame("Frame", "AuctionPeekFrame", UIParent)
  panel:SetSize(max(MIN_WIDTH, tonumber(db.width) or 747),
    max(MIN_HEIGHT, tonumber(db.height) or 301))
  panel:SetResizable(true)
  if panel.SetResizeBounds then
    panel:SetResizeBounds(MIN_WIDTH, MIN_HEIGHT)
  elseif panel.SetMinResize then
    panel:SetMinResize(MIN_WIDTH, MIN_HEIGHT)
  end
  panel:SetPoint("CENTER", UIParent, "CENTER", db.x or 0, db.y or 90)
  panel:SetFrameStrata("MEDIUM")
  panel:SetClampedToScreen(true)
  panel:SetMovable(true)
  panel:EnableMouse(true)
  panel:RegisterForDrag("LeftButton")
  panel:SetScript("OnDragStart", function(self) self:StartMoving() end)
  panel:SetScript("OnDragStop", function(self)
    self:StopMovingOrSizing()
    SavePanelGeometry()
    QueueViewportPaint()
  end)
  DrawBorder(panel)
  panel:Hide()
  panel:SetScript("OnShow",function() Render() end)
  if UISpecialFrames then tinsert(UISpecialFrames, "AuctionPeekFrame") end

  local title = Label(panel, "Auction Peek  v"..VERSION, 11, -10, 280)
  title:SetTextColor(0.96, 0.80, 0.50)
  local unmatchedButton = CreateFrame("Button", nil, panel, "UIPanelButtonTemplate")
  unmatchedButton:SetSize(126,21)
  unmatchedButton:SetPoint("TOPLEFT",panel,"TOPLEFT",173,-4)
  unmatchedButton:SetText("Unmatched: 0")
  unmatchedButton:SetScript("OnClick",function()
    Supply.OpenReceiptReview(panel,char,NameKey,MoneyString,Render)
  end)
  unmatchedButton:SetScript("OnEnter",function(self)
    GameTooltip:SetOwner(self,"ANCHOR_BOTTOM")
    GameTooltip:AddLine("Unmatched Flip Receipts")
    GameTooltip:AddLine("Review possible flip payments; manual matching only",.9,.8,.5,true)
    GameTooltip:Show()
  end)
  unmatchedButton:SetScript("OnLeave",function() GameTooltip:Hide() end)
  panel.unmatchedButton=unmatchedButton
  local opts = CreateFrame("Button", nil, panel, "UIPanelButtonTemplate")
  opts:SetSize(57, 21)
  opts:SetPoint("TOPRIGHT", -67, -4)
  opts:SetText("Options")
  opts:SetScript("OnClick", function()
    if settingsPanel:IsShown() then settingsPanel:Hide() else settingsPanel:Show() end
  end)
  local reload = CreateFrame("Button", nil, panel, "UIPanelButtonTemplate")
  reload:SetSize(59, 21)
  reload:SetPoint("RIGHT", opts, "LEFT", -5, 0)
  reload:SetText("Refresh")
  reload:SetScript("OnClick", function()
    if char then Supply.ReconcilePaidSingles(); Render() end
    if not ahOpen then Print("Saved payments checked. Visit an auctioneer to refresh live auctions."); return end
    RequestRefresh()
  end)
  local supplyButton = CreateFrame("Button", nil, panel, "UIPanelButtonTemplate")
  supplyButton:SetSize(55, 21)
  supplyButton:SetPoint("RIGHT", reload, "LEFT", -5, 0)
  supplyButton:SetText("Supply")
  supplyButton:SetScript("OnClick", Supply.Toggle)
  local shadyButton = CreateFrame("Button", nil, panel, "UIPanelButtonTemplate")
  shadyButton:SetSize(54, 21)
  shadyButton:SetPoint("RIGHT", supplyButton, "LEFT", -5, 0)
  shadyButton:SetText("Shady")
  shadyButton:SetShown(db.showShadyShortcut ~= false)
  shadyButton:SetScript("OnClick", OpenShadySearch)
  shadyButton:SetScript("OnEnter", function(self)
    GameTooltip:SetOwner(self, "ANCHOR_BOTTOM")
    GameTooltip:AddLine("Open Shady Price Search")
    GameTooltip:AddLine("Requires Shady Price Engine 1.1+ with OpenSearch API", 0.8, 0.8, 0.8, true)
    GameTooltip:Show()
  end)
  shadyButton:SetScript("OnLeave", function() GameTooltip:Hide() end)
  local vendors=CreateFrame("Button",nil,panel,"UIPanelButtonTemplate")
  vendors:SetSize(61,21)
  vendors:SetPoint("RIGHT",shadyButton,"LEFT",-4,0)
  vendors:SetText("Vendors")
  vendors:SetScript("OnClick",Supply.ToggleVendors)
  panel.shadyButton = shadyButton
  local close = CreateFrame("Button", nil, panel, "UIPanelCloseButton")
  close:SetPoint("TOPRIGHT", 3, 0)
  close:SetScript("OnClick", function() panel:Hide() end)

  -- Compact history tabs, independent of the auction-house UI.
  panel.tabs = {}
  local function MakeTab(key, x)
    local tab = CreateFrame("Button", nil, panel)
    tab:SetSize(99, 23)
    tab:SetPoint("TOPLEFT", panel, "TOPLEFT", x, -33)
    local bg = tab:CreateTexture(nil, "BACKGROUND")
    bg:SetAllPoints()
    tab.background = bg
    local line = tab:CreateTexture(nil, "BORDER")
    line:SetPoint("BOTTOMLEFT", tab, "BOTTOMLEFT", 0, 0)
    line:SetPoint("BOTTOMRIGHT", tab, "BOTTOMRIGHT", 0, 0)
    line:SetHeight(2)
    tab.underline = line
    local label = tab:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
    label:SetPoint("CENTER", tab, "CENTER", 0, 1)
    tab.label = label
    local hover = tab:CreateTexture(nil, "HIGHLIGHT")
    hover:SetAllPoints()
    hover:SetColorTexture(0.78, 0.67, 0.40, 0.12)
    tab:SetScript("OnClick", function()
      if db.selectedTab == key then return end
      if db.selectedTab == "buys" then selectedBuys = {} end
      db.selectedTab = key
      LayoutTable()
      if panel.sortMenu then panel.sortMenu:Hide() end
      if panel.scroll then panel.scroll:SetVerticalScroll(0) end
      Render()
    end)
    panel.tabs[key] = tab
  end
  MakeTab("listed", 8)
  MakeTab("recent", 112)
  MakeTab("all", 216)
  MakeTab("buys", 320)
  MakeTab("flip", 424)
  MakeTab("de", 528)

  local searchRow = CreateFrame("Frame", nil, panel)
  searchRow:SetPoint("TOPLEFT", panel, "TOPLEFT", 8, -63)
  searchRow:SetPoint("TOPRIGHT", panel, "TOPRIGHT", -8, -63)
  searchRow:SetHeight(24)
  panel.searchRow = searchRow

  local sortButton = CreateFrame("Button", nil, searchRow, "UIPanelButtonTemplate")
  sortButton:SetSize(135, 23)
  sortButton:SetPoint("TOPRIGHT", searchRow, "TOPRIGHT", 0, 0)
  panel.sortButton = sortButton
  local clear = CreateFrame("Button", nil, searchRow, "UIPanelButtonTemplate")
  clear:SetSize(23, 23)
  clear:SetPoint("RIGHT", sortButton, "LEFT", -5, 0)
  clear:SetText("X")
  clear:SetScript("OnClick", function()
    if panel.searchEdit then panel.searchEdit:SetText(""); panel.searchEdit:SetFocus() end
  end)
  local searchEdit = CreateFrame("EditBox", nil, searchRow, "InputBoxTemplate")
  searchEdit:SetHeight(23)
  searchEdit:SetPoint("TOPLEFT", searchRow, "TOPLEFT", 6, -1)
  searchEdit:SetPoint("RIGHT", clear, "LEFT", -11, 0)
  searchEdit:SetAutoFocus(false)
  searchEdit:SetFontObject("ChatFontNormal")
  searchEdit:SetTextInsets(4, 4, 0, 0)
  searchEdit:SetMaxLetters(100)
  searchEdit:SetScript("OnTextChanged", function(self)
    local value = self:GetText() or ""
    if not CanRead(value) then return end
    if value == searchText then return end
    searchText = value
    if panel.scroll then panel.scroll:SetVerticalScroll(0) end
    Render()
  end)
  searchEdit:SetScript("OnEscapePressed", function(self) self:ClearFocus() end)
  searchEdit:SetScript("OnEnterPressed", function(self) self:ClearFocus() end)
  panel.searchEdit = searchEdit
  local hint = searchRow:CreateFontString(nil, "OVERLAY", "GameFontDisableSmall")
  hint:SetPoint("LEFT", searchEdit, "LEFT", 7, 0)
  hint:SetText("Search items or auction ID...")
  hint:EnableMouse(false)
  local function UpdateSearchHint()
    hint:SetShown(searchEdit:GetText() == "" and not searchEdit:HasFocus())
  end
  searchEdit:HookScript("OnTextChanged", UpdateSearchHint)
  searchEdit:HookScript("OnEditFocusGained", UpdateSearchHint)
  searchEdit:HookScript("OnEditFocusLost", UpdateSearchHint)
  UpdateSearchHint()

  local sortMenu = CreateFrame("Frame", nil, panel)
  sortMenu:SetSize(158, 8 + (#SORT_OPTIONS * 23))
  sortMenu:SetFrameStrata("DIALOG")
  sortMenu:SetFrameLevel(panel:GetFrameLevel() + 20)
  sortMenu:SetPoint("TOPRIGHT", sortButton, "BOTTOMRIGHT", 0, -2)
  DrawBorder(sortMenu)
  sortMenu:Hide()
  panel.sortMenu = sortMenu
  for i, option in ipairs(SORT_OPTIONS) do
    local choice = CreateFrame("Button", nil, sortMenu)
    choice:SetSize(150, 22)
    choice:SetPoint("TOPLEFT", sortMenu, "TOPLEFT", 4, -(4 + (i - 1) * 23))
    local label = choice:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
    label:SetPoint("LEFT", choice, "LEFT", 7, 0)
    label:SetText(option.label)
    choice.label = label
    local hover = choice:CreateTexture(nil, "HIGHLIGHT")
    hover:SetAllPoints()
    hover:SetColorTexture(0.9, 0.74, 0.35, 0.19)
    choice:SetScript("OnClick", function()
      db.sortModes[db.selectedTab] = option.key
      sortMenu:Hide()
      if panel.scroll then panel.scroll:SetVerticalScroll(0) end
      Render()
    end)
    choice.sortKey = option.key
    sortMenu[i] = choice
  end
  sortButton:SetScript("OnClick", function()
    for i, option in ipairs(SORT_OPTIONS) do
      sortMenu[i]:SetShown(not ((db.selectedTab == "buys" or db.selectedTab == "flip") and option.key == "listed_desc"))
      sortMenu[i].label:SetTextColor(SortForTab(db.selectedTab) == option.key and 1 or 0.72,
        SortForTab(db.selectedTab) == option.key and 0.83 or 0.72, 0.4)
    end
    sortMenu:SetShown(not sortMenu:IsShown())
  end)
  searchEdit:HookScript("OnEditFocusGained", function() sortMenu:Hide() end)

  local header = CreateFrame("Frame", nil, panel)
  header:SetPoint("TOPLEFT", 7, -60)
  header:SetSize(708, 23)
  panel.header = header
  local head = header:CreateTexture(nil, "BACKGROUND")
  head:SetAllPoints()
  head:SetColorTexture(0, 0, 0, 1)
  local headerRule = header:CreateTexture(nil, "BORDER")
  headerRule:SetPoint("BOTTOMLEFT", header, "BOTTOMLEFT", 0, 0)
  headerRule:SetPoint("BOTTOMRIGHT", header, "BOTTOMRIGHT", 0, 0)
  headerRule:SetHeight(1)
  headerRule:SetColorTexture(0.28, 0.28, 0.28, 0.75)
  panel.headers = {
    item = Label(header, "Item  |cffffd36a\226\134\145|r", 9, -5, 355),
    units = Label(header,"Units sold",0,-5,70,"RIGHT"),
    bid = Label(header, "Bid Price", 374, -5, 117),
    buyout = Label(header, "Buyout Price", 510, -5, 120),
    auction = Label(header,"Auction ID",0,-5,100,"RIGHT"),
    soldTime = Label(header, "Sold at", 0, -5, 108, "RIGHT"),
    time = Label(header, "Time", 649, -5, 54, "RIGHT"),
  }

  local timeCheck = CreateFrame("CheckButton", nil, header, "UICheckButtonTemplate")
  timeCheck:SetSize(20, 20)
  timeCheck:SetPoint("TOPLEFT", header, "TOPLEFT", 55, -1)
  Label(timeCheck, "Show time", 21, -4, 67)
  timeCheck:SetHitRectInsets(0, -58, 0, 0)
  timeCheck:SetScript("OnClick", function(self)
    db.showFlipTime = self:GetChecked() and true or false
    LayoutTable()
    Render()
  end)
  panel.timeCheck = timeCheck
  local vendorCheck=CreateFrame("CheckButton",nil,header,"UICheckButtonTemplate")
  vendorCheck:SetSize(20,20)
  vendorCheck:SetPoint("LEFT",header,"LEFT",55,0)
  Label(vendorCheck,"Hide vendor purchases",21,-4,140)
  vendorCheck:SetHitRectInsets(0,-131,0,0)
  vendorCheck:SetScript("OnClick",function(self)
    db.hideVendorBuys=self:GetChecked() and true or false
    if db.hideVendorBuys then
      for row in pairs(selectedBuys) do
        if row.vendor then selectedBuys[row]=nil end
      end
    end
    Render()
  end)
  panel.vendorCheck=vendorCheck
  panel.restoreVendor=CreateFrame("Button",nil,header,"UIPanelButtonTemplate")
  panel.restoreVendor:SetSize(108,22)
  panel.restoreVendor:SetPoint("LEFT",header,"LEFT",209,0)
  panel.restoreVendor:SetText("Restore buy")
  panel.restoreVendor:SetScript("OnClick",function() Supply.OpenVendorRestore(panel,StoreBuy) end)
  local groupCheck=CreateFrame("CheckButton",nil,panel,"UICheckButtonTemplate")
  groupCheck:SetSize(20,20)
  groupCheck:SetPoint("BOTTOMRIGHT",panel,"BOTTOMRIGHT",-102,4)
  Label(groupCheck,"Group by item",21,-4,85)
  groupCheck:SetHitRectInsets(0,-81,0,0)
  groupCheck:SetScript("OnClick",function(self)
    db.groupFlipItems=self:GetChecked() and true or false
    expandedCraft=nil
    expandedMaterials={}
    panel.scroll:SetVerticalScroll(0)
    Render()
  end)
  panel.groupCheck=groupCheck

  local scroll = CreateFrame("ScrollFrame", "AuctionPeekScrollFrame", panel,
    "UIPanelScrollFrameTemplate")
  scroll:SetPoint("TOPLEFT", panel, "TOPLEFT", 8, -84)
  scroll:SetPoint("BOTTOMRIGHT", panel, "BOTTOMRIGHT", -30, 29)
  panel.scroll = scroll
  scroll:HookScript("OnSizeChanged", QueueViewportPaint)
  scroll:HookScript("OnVerticalScroll", function() PaintRows() end)
  local content = CreateFrame("Frame", nil, scroll)
  content:SetSize(708, 1)
  scroll:SetScrollChild(content)
  panel.content = content
  panel.empty = Label(panel, "", 22, -126, 660, "CENTER")
  panel.empty:SetTextColor(0.70, 0.70, 0.70)
  panel.empty:Hide()
  panel.status = Label(panel, "", 11, -281, 719)
  panel.status:ClearAllPoints()
  panel.status:SetPoint("BOTTOMLEFT", panel, "BOTTOMLEFT", 11, 10)
  panel.status:SetTextColor(0.72, 0.72, 0.72)
  local clearSelection = CreateFrame("Button", nil, panel, "UIPanelButtonTemplate")
  clearSelection:SetSize(52, 20)
  clearSelection:SetPoint("BOTTOMRIGHT", panel, "BOTTOMRIGHT", -28, 5)
  clearSelection:SetText("Clear")
  clearSelection:SetScript("OnClick", function()
    selectedBuys = {}
    Render()
  end)
  clearSelection:Hide()
  panel.clearSelection = clearSelection
  local overallStatus = panel:CreateFontString(nil, "OVERLAY", "GameFontDisableSmall")
  overallStatus:SetPoint("BOTTOMLEFT", panel, "BOTTOMLEFT", 11, 27)
  overallStatus:SetWidth(max(100, panel:GetWidth() - 55))
  overallStatus:SetJustifyH("LEFT")
  overallStatus:Hide()
  panel.overallStatus = overallStatus

  -- Drag the lower-right corner to resize. The whole layout and the saved
  -- dimensions adapt together so the auction columns never drift apart.
  local grip = CreateFrame("Button", nil, panel)
  grip:SetSize(20, 20)
  grip:SetPoint("BOTTOMRIGHT", panel, "BOTTOMRIGHT", -2, 2)
  grip:SetNormalTexture("Interface\\ChatFrame\\UI-ChatIM-SizeGrabber-Up")
  grip:SetHighlightTexture("Interface\\ChatFrame\\UI-ChatIM-SizeGrabber-Highlight")
  grip:SetPushedTexture("Interface\\ChatFrame\\UI-ChatIM-SizeGrabber-Down")
  local startX,startY,startWidth,startHeight,left,top
  local function resize()
    local x,y=GetCursorPosition()
    local scale=panel:GetEffectiveScale()
    local minimum=panel.tableMinimum or MIN_WIDTH
    local w=max(minimum,min(UIParent:GetRight()-left,startWidth+(x-startX)/scale))
    local h=max(MIN_HEIGHT,min(top-UIParent:GetBottom(),startHeight+(startY-y)/scale))
    w,h=floor(w+0.5),floor(h+0.5)
    if w~=panel:GetWidth() or h~=panel:GetHeight() then panel:SetSize(w,h) end
  end
  local function finishResize()
    if not startX then return end
    grip:SetScript("OnUpdate",nil)
    startX=nil
    SavePanelGeometry()
    QueueViewportPaint()
  end
  grip:RegisterForDrag("LeftButton")
  grip:SetScript("OnDragStart",function()
    left,top=panel:GetLeft(),panel:GetTop()
    if not left or not top then return end
    startX,startY=GetCursorPosition()
    startWidth,startHeight=panel:GetSize()
    panel:ClearAllPoints()
    panel:SetPoint("TOPLEFT",UIParent,"BOTTOMLEFT",left-UIParent:GetLeft(),top-UIParent:GetBottom())
    grip:SetScript("OnUpdate",resize)
  end)
  grip:SetScript("OnDragStop",function()
    if startX then resize(); finishResize() end
  end)
  grip:SetScript("OnHide",finishResize)
  panel.resizeGrip = grip
  panel:SetScript("OnSizeChanged", function(self)
    if self.unmatchedButton then self.unmatchedButton:SetShown(self:GetWidth()>=760) end
    if not self.content then return end
    LayoutTable()
    QueueViewportPaint()
    db.width, db.height = floor(self:GetWidth() + 0.5), floor(self:GetHeight() + 0.5)
  end)
  LayoutTable()
  ApplyBackgrounds()
end

-- The minimap button is a normal, freely movable UIParent widget.  It is NOT
-- constrained to a radius or parented to the Minimap: drag it to any spot.
local function SaveMinimapPosition()
  if not minimapButton or not db then return end
  local x, y = minimapButton:GetCenter()
  local px, py = UIParent:GetCenter()
  if x and y and px and py then
    db.minimapX = x - px
    db.minimapY = y - py
  end
end

local function PositionMinimapButton()
  if not minimapButton or not db then return end
  if type(db.minimapX) ~= "number" or type(db.minimapY) ~= "number" then
    local mx, my = Minimap and Minimap:GetCenter()
    local px, py = UIParent:GetCenter()
    if mx and my and px and py then
      local radius = math.min(Minimap:GetWidth(), Minimap:GetHeight()) / 2 + 2
      local angle = math.rad(db.minimapAngle or 210)
      db.minimapX = mx - px + math.cos(angle) * radius
      db.minimapY = my - py + math.sin(angle) * radius
    else
      db.minimapX, db.minimapY = 0, 0
    end
  end
  minimapButton:ClearAllPoints()
  minimapButton:SetPoint("CENTER", UIParent, "CENTER", db.minimapX, db.minimapY)
end

local function MakeMinimap()
  if not Minimap then return end
  minimapButton = CreateFrame("Button", "AuctionPeekMinimapButton", UIParent)
  minimapButton:SetSize(31, 31)
  minimapButton:SetFrameStrata("HIGH")
  minimapButton:SetFrameLevel(10)
  minimapButton:SetMovable(true)
  minimapButton:SetClampedToScreen(true)
  minimapButton:RegisterForClicks("LeftButtonUp", "RightButtonUp")
  minimapButton:RegisterForDrag("LeftButton")

  -- Standard LibDBIcon-style round minimap button.  In 1.1 the border was
  -- incorrectly centered, while the icon was centered on the frame; the
  -- tracking border atlas expects a TOPLEFT anchor and icon offset (7,-5).
  local bg = minimapButton:CreateTexture(nil, "BACKGROUND")
  bg:SetTexture("Interface\\Minimap\\UI-Minimap-Background")
  bg:SetSize(20, 20)
  bg:SetPoint("TOPLEFT", minimapButton, "TOPLEFT", 7, -5)

  local icon = minimapButton:CreateTexture(nil, "ARTWORK")
  icon:SetTexture("Interface\\Icons\\INV_Misc_Coin_01")
  icon:SetSize(20, 20)
  icon:SetTexCoord(0.05, 0.95, 0.05, 0.95)
  icon:SetPoint("TOPLEFT", minimapButton, "TOPLEFT", 7, -5)

  local border = minimapButton:CreateTexture(nil, "OVERLAY")
  border:SetTexture("Interface\\Minimap\\MiniMap-TrackingBorder")
  border:SetSize(53, 53)
  border:SetPoint("TOPLEFT", minimapButton, "TOPLEFT", 0, 0)
  minimapButton:SetHighlightTexture("Interface\\Minimap\\UI-Minimap-ZoomButton-Highlight")

  minimapButton:SetScript("OnClick", function(self, button)
    -- Do not open windows as a side effect of releasing a drag.
    if self.dragEndedAt and GetTime() - self.dragEndedAt < 0.15 then return end
    if button == "RightButton" then
      settingsPanel:SetShown(not settingsPanel:IsShown())
    else
      panel:SetShown(not panel:IsShown())
    end
  end)
  minimapButton:SetScript("OnEnter", function(self)
    if self.dragging then return end
    GameTooltip:SetOwner(self, "ANCHOR_CURSOR")
    GameTooltip:AddLine("Auction Peek")
    GameTooltip:AddLine("Left-click: auctions", 0.85, 0.85, 0.85)
    GameTooltip:AddLine("Shift-click a row: delete (restore in settings)", 0.85, 0.85, 0.85)
    GameTooltip:AddLine("Right-click: settings", 0.85, 0.85, 0.85)
    GameTooltip:AddLine("Drag: move anywhere (position saved)", 0.75, 0.75, 0.75)
    GameTooltip:Show()
  end)
  minimapButton:SetScript("OnLeave", function() GameTooltip:Hide() end)
  minimapButton:SetScript("OnDragStart", function(self)
    self.dragging = true
    GameTooltip:Hide()
    self:StartMoving()
  end)
  minimapButton:SetScript("OnDragStop", function(self)
    self:StopMovingOrSizing()
    self.dragging = nil
    self.dragEndedAt = GetTime()
    SaveMinimapPosition()
  end)
  PositionMinimapButton()
  minimapButton:SetShown(db.showMinimap)
end

SLASH_AUCTIONPEEK1 = "/ap"
SLASH_AUCTIONPEEK2 = "/auctionpeek"
SlashCmdList.AUCTIONPEEK = function(input)
  input = (input or ""):lower():gsub("^%s+", ""):gsub("%s+$", "")
  if input == "accounting" then
    if not char then Print("Character profile is not loaded."); return end
    local counts, findings = Supply.Accounting.Audit(char, clock())
    Print(("%d active, %d paid sales, %d without payment, %d distinct receipt IDs, %d buys")
      :format(counts.active, counts.verified, counts.pending, counts.receipts, counts.buys))
    Print(("%d ended, %d archived, %d ledger lots, %d posts, %d receipts without an auction ID")
      :format(counts.ended, counts.deleted, counts.lots, counts.posts, counts.withoutAuction))
    local kinds = {}
    for kind in pairs(findings) do kinds[#kinds+1] = kind end
    sort(kinds)
    if #kinds == 0 then Print("No structural discrepancies detected by these checks.") end
    for _,kind in ipairs(kinds) do
      local entry = findings[kind]
      Print(kind .. " (" .. entry.count .. "): " .. table.concat(entry.examples, ", "))
    end
    return
  end
  local dyePrice=input:match("^graydye%s+(%d+)$")
  if dyePrice and char then
    local n=tonumber(dyePrice)
    if n and n>0 and n<=1000000 and Supply.Crafts.RecoverGrayDye(char,n) then
      Render(); Print("Updated the recovered Gray Dye purchase to "..MoneyString(n).." each.")
    else Print("No matching recovered purchase or invalid unit price.") end
    return
  end
  if input=="repairreceipts" or input=="repairreceipts confirm" then
    if not char then Print("Character profile is not loaded."); return end
    local yes=input=="repairreceipts confirm"
    local ok,msg=Supply.RepairReceipts20261123(char,yes)
    Print((ok and "OK: " or "Not applied: ")..msg)
    if ok and yes then Render() end
    return
  end
  if input=="vendorcheck" and char then Print(char.vendorCheck or "No vendor price mismatch recorded."); return end
  if input=="vendors" then Supply.ToggleVendors(); return end
  if input=="reconcile" and char then
    local n=Supply.ReconcilePaidSingles()
    if n>0 then Render() end
    Print("Reconciled "..n.." saved payments.")
    return
  end
  if input=="unmatched" or input=="review" then
    if char then Supply.OpenReceiptReview(panel,char,NameKey,MoneyString,Render) end
    return
  end
  if input=="audit" then
    if char then Supply.AuditFlip(char,NameKey,Print) end
    return
  end
  local serial,auction=input:match("^match%s+mail:(%d+)%s+(%d+)$")
  if serial and char then
    local id="mail:"..serial
    if not Supply.MatchPayment(char,id,auction,NameKey) then
      Print("Receipt or sold auction is no longer eligible."); return
    end
    Render()
    Print("Linked "..id.." to auction #"..auction..".")
    return
  end
  local oldID,newID=input:match("^repost%s+(%d+)%s+(%d+)$")
  if oldID then
    -- Optional transfer of the one unresolved craft allocation in the audited bag batch.
    if oldID=="150798168" and newID=="158013099" then
      local l=char.craftLedger
      local old=l and l.posts[oldID]
      local new=l and l.posts[newID]
      local src=old and old.parts and old.parts[1]
      local dst=new and new.parts and new.parts[1]
      local lot=src and l.lots[src.source]
      local ended,sale
      for _,r in ipairs(char.ended) do if tostring(r.auctionID)==oldID then ended=r end end
      for _,r in ipairs(char.sold) do
        if tostring(r.auctionID)==oldID then Print("Original auction has a sale."); return end
        if tostring(r.auctionID)==newID then sale=r end
      end
      if ended and ended.endedReason=="unconfirmed" and ended.itemID==254035 and not ended.repostedAs
          and sale and sale.itemID==254035 and sale.receiptID and sale.verifiedGross==27000
          and old and old.unresolved and not old.ended and not old.soldAt and old.quantity==1
          and new and new.soldAt and new.quantity==1 and new.at>old.at
          and lot and lot.parts and lot.itemID==254035 and lot.quantity==1 and lot.left==0
          and #old.parts==1 and src.n==1 and src.cost==22404
          and dst and #new.parts==1 and not dst.source and dst.n==1 then
        for _,post in pairs(l.posts) do
          if post~=old and not post.ended then
            for _,part in ipairs(post.parts or {}) do
              if part.source==src.source then Print("Craft already allocated."); return end
            end
          end
        end
        new.parts,old.parts=old.parts,{}
        old.ended,old.unresolved="reposted",nil
        ended.repostedAs,sale.repostOf=sale.auctionID,ended.auctionID
        Render()
        Print("Linked the bag's recorded craft cost to its paid repost.")
      else Print("Bag cost already linked or records do not match.") end
      return
    end
    if Supply.Crafts.LinkRemainder(char,oldID,newID) then Render(); Print("Returned stack cost linked to repost.")
    else Print("No matching, unassigned repost for this returned stack.") end
    return
  end
  if input == "settings" or input == "options" then
    settingsPanel:SetShown(not settingsPanel:IsShown())
  elseif input == "deleted" or input == "trash" then
    if deletedPanel then deletedPanel:SetShown(not deletedPanel:IsShown()) end
  elseif input == "refresh" or input == "sync" then
    if not ahOpen then Print("Open the auction house before refreshing.")
    else RequestRefresh(); Print("Requesting your auctions...") end
  elseif input == "search" then
    if not panel:IsShown() then panel:Show() end
    if db.showHistorySearch == false then
      db.showHistorySearch = true
      LayoutTable()
    end
    if panel.searchEdit then panel.searchEdit:SetFocus() end
  elseif input == "supply" then
    Supply.Toggle()
  elseif input == "shady" then
    OpenShadySearch()
  elseif input == "help" then
    Print("/ap: window; /ap search; /ap supply; /ap shady; /ap settings; /ap deleted; /ap refresh (at AH).")
  else
    panel:SetShown(not panel:IsShown())
  end
end

for _, event in ipairs({"UNIT_SPELLCAST_START","UNIT_SPELLCAST_SUCCEEDED","UNIT_SPELLCAST_INTERRUPTED","UNIT_SPELLCAST_FAILED"}) do
  if AP.RegisterUnitEvent then AP:RegisterUnitEvent(event,"player") else AP:RegisterEvent(event) end
end
AP:RegisterEvent("PLAYER_LOGIN")
AP:RegisterEvent("AUCTION_HOUSE_SHOW")
AP:RegisterEvent("AUCTION_HOUSE_CLOSED")
AP:RegisterEvent("OWNED_AUCTIONS_UPDATED")
AP:RegisterEvent("AUCTION_HOUSE_AUCTION_CREATED")
AP:RegisterEvent("AUCTION_CANCELED")
-- Some private-client variants omit this event: optional registration.
pcall(AP.RegisterEvent, AP, "AUCTION_HOUSE_AUCTIONS_EXPIRED")
AP:RegisterEvent("AUCTION_HOUSE_THROTTLED_SYSTEM_READY")
AP:RegisterEvent("CHAT_MSG_SYSTEM")
AP:RegisterEvent("CHAT_MSG_LOOT")
AP:RegisterEvent("AUCTION_HOUSE_SHOW_FORMATTED_NOTIFICATION")
AP:RegisterEvent("GET_ITEM_INFO_RECEIVED")
AP:RegisterEvent("MAIL_SHOW")
AP:RegisterEvent("MAIL_CLOSED")
AP:RegisterEvent("MAIL_INBOX_UPDATE")
AP:RegisterEvent("MAIL_SUCCESS")
AP:RegisterEvent("MAIL_FAILED")
AP:RegisterEvent("AUCTION_HOUSE_PURCHASE_COMPLETED")
AP:RegisterEvent("COMMODITY_PURCHASED")
AP:RegisterEvent("COMMODITY_PURCHASE_SUCCEEDED")
AP:RegisterEvent("COMMODITY_PURCHASE_FAILED")
AP:RegisterEvent("COMMODITY_PRICE_UPDATED")
AP:RegisterEvent("COMMODITY_PRICE_UNAVAILABLE")
AP:SetScript("OnEvent", function(_, event, ...)
  if event == "PLAYER_LOGIN" then
    if type(AuctionPeekDB) ~= "table" then AuctionPeekDB = {} end
    db = AuctionPeekDB
    if type(db.characters) ~= "table" then db.characters = {} end
    -- Upgrade v1.3's Sold tab to the new rolling 24h view.
    if db.selectedTab == "sold" then db.selectedTab = "recent" end
    if db.selectedTab ~= "listed" and db.selectedTab ~= "recent"
        and db.selectedTab ~= "all" and db.selectedTab ~= "buys" and db.selectedTab ~= "flip" and db.selectedTab ~= "de" then
      db.selectedTab = "listed"
    end
    if db.blackBackgroundMigration ~= 1 then
      db.solid = true
      db.blackBackgroundMigration = 1
    elseif db.solid == nil then
      db.solid = true
    end
    if db.showMinimap == nil then db.showMinimap = true end
    if db.showListingCount == nil then db.showListingCount = true end
    if db.showHistorySearch == nil then db.showHistorySearch = true end
    if db.showShadyShortcut == nil then db.showShadyShortcut = true end
    if type(db.sortModes) ~= "table" then db.sortModes = {} end
    firstOwnedSnapshotAfterLogin=true
    local key = CurrentCharacterKey()
    if type(db.characters[key]) ~= "table" then db.characters[key] = {} end
    char = db.characters[key]
    if type(char.active) ~= "table" then char.active = {} end
    if type(char.sold) ~= "table" then char.sold = {} end
    if type(char.buys) ~= "table" then char.buys = {} end
    if type(char.deleted) ~= "table" then char.deleted = {} end
    if type(char.hiddenAuctions) ~= "table" then char.hiddenAuctions = {} end
    if type(char.ended) ~= "table" then char.ended = {} end
    Supply.Crafts.UpdateMaterialCosts(char)
    RepairRedgillRecipe()
    RepairFormulaPair()
    RepairPendingFormulaPosts()
    Supply.Crafts.RepairBagBolts(char)
    Supply.Crafts.RepairSoldBolts(char)
    Supply.Crafts.RepairMageweaveReturn(char)
    Supply.Crafts.RepairCookedInputs(char)
    for _,pool in ipairs({char.active,char.sold}) do
      for _,row in ipairs(pool) do Supply.Crafts.LinkReservedCraft(char,row) end
    end
    Supply.Crafts.RepairDustReceipt(char)
    Supply.Crafts.RepairFormulaRepost(char)
    InitializeListingHistory()
    char.nextPurchaseID = tonumber(char.nextPurchaseID) or 0
    InstallPurchaseHooks()
    for _,profile in pairs(db.characters) do profile.vendorArchive=nil end
    Supply.InstallVendorTracking(StoreBuy,char)
    char.nextReceiptID = tonumber(char.nextReceiptID) or 0
    -- Restored and imported history can outlive its old sequence counters.
    for _, bucket in ipairs({char.buys, char.sold, char.deleted}) do
      for _, row in ipairs(bucket) do
        char.nextPurchaseID = max(char.nextPurchaseID, tonumber(row.purchaseID) or 0)
        local serial = tostring(row.receiptID or ""):match("^mail:(%d+)$")
        char.nextReceiptID = max(char.nextReceiptID, tonumber(serial) or 0)
      end
    end
    -- Stack sales keep all invoice IDs in fills, including IDs beyond the
    -- first invoice displayed on the sale row.
    for _,post in pairs(char.craftLedger and char.craftLedger.posts or {}) do
      for id in pairs(post.fills or {}) do
        local serial=tostring(id):match("^mail:(%d+)$")
        char.nextReceiptID=max(char.nextReceiptID,tonumber(serial) or 0)
      end
    end
    Supply.Crafts.RecoverGrayDye(char)
    Supply.RestoreSecondDye(char,StoreBuy)
    Supply.Crafts.RecoverDyeSplit(char)
    Supply.SplitVendorHistory(char)
    char.lastSync = tonumber(char.lastSync) or 0
    Supply.QueueReceiptReview()
    InstallMailHooks()
    Supply.InstallReturnHooks()
    MakeDeletedPanel()
    MakeSettings()
    MakePanel()
    MakeMinimap()
    Render()
    if C_Timer and C_Timer.NewTicker then
      -- Keep relative time labels fresh without querying or reordering the
      -- Blizzard auction list. Auction data itself is event-driven.
      C_Timer.NewTicker(45, function()
        if panel and panel:IsShown() then PaintRows() end
      end)
    end
  elseif event == "CHAT_MSG_LOOT" then
    if char then Supply.DETest.Loot(Supply.Crafts.PersonalLoot(char, ...)) end
  elseif event:match("^UNIT_SPELLCAST_") then
    if char then
      local unit,guid,spell=...
      Supply.DETest.Cast(char,event,unit,guid,spell,function()
        if db.selectedTab=="de" then Render() end
      end)
      if Supply.Crafts.Cast(char,event,...) then Render() end
    end
  elseif event == "AUCTION_HOUSE_SHOW" then
    ahOpen = true
    Supply.RefreshVendorArchive()
    refreshEpoch = refreshEpoch + 1
    refreshQueued, retryWhenReady = false, false
    autoRetryCount, lastQueryAt = 0, -1000
    -- The native Owned tab emits OWNED_AUCTIONS_UPDATED once it has fresh
    -- data. Do not treat a potentially stale cache from the previous AH
    -- visit as a new snapshot, or request Blizzard's default sort.
    lastOwnedSignature = nil
    if char then Render() end
  elseif event == "AUCTION_HOUSE_CLOSED" then
    -- Keep recent buy attempts briefly: completion events may arrive just
    -- after the player closes the auction house.
    ahOpen = false
    Supply.RefreshVendorArchive()
    refreshEpoch = refreshEpoch + 1
    refreshQueued, retryWhenReady = false, false
    autoRetryCount = 0
    lastOwnedSignature = nil
    if char then Render() end
  elseif event == "OWNED_AUCTIONS_UPDATED" then
    ReadOwnedAuctions()
  elseif event == "AUCTION_HOUSE_THROTTLED_SYSTEM_READY" then
    if retryWhenReady and ahOpen then RequestRefresh() end
  elseif event == "AUCTION_HOUSE_AUCTIONS_EXPIRED" then
    ChangeAuctionStatus(..., "expired")
  elseif event == "AUCTION_CANCELED" then
    ChangeAuctionStatus(..., "canceled")
  elseif event == "AUCTION_HOUSE_AUCTION_CREATED" then
    -- New post = new auction ID; don't revive an ended/hidden old listing.
    local id = ...
    if char and CanRead(id) and type(id)=="number" then
      Supply.Crafts.Created(char,id)
      -- A quick sale can disappear before the next complete owned scan.
      local get=C_AuctionHouse and C_AuctionHouse.GetOwnedAuctions
      if get then
        local ok,owned=pcall(get)
        for _,info in ipairs(ok and type(owned)=="table" and owned or {}) do
          if CanRead(info) and CanRead(info.auctionID) and info.auctionID==id
              and CanRead(info.itemKey) and type(info.itemKey)=="table"
              and CanRead(info.itemKey.itemID) and CanRead(info.quantity)
              and type(info.quantity)=="number" and info.quantity>0 then
            local row=NewAuctionRow(info)
            if row and row.itemID and row.quantity and row.quantity>0 then
              Supply.Crafts.Observe(char,row)
              RememberPosting(row)
              RememberQuantityEvidence(row,true)
              local post=char.craftLedger.posts[tostring(id)]
              if post and post.itemID==row.itemID then
                post.createdKey={itemLevel=row.itemLevel,itemSuffix=row.itemSuffix,link=row.link}
              end
              -- Cache this exact freshly-created ID. It may sell before the
              -- next Blizzard-owned refresh, especially a two-writ stack.
              -- Never fabricate a row if Blizzard's cache lacked this ID.
              local already=false
              for _,bucket in ipairs({char.active,char.sold,char.ended,char.deleted}) do
                for _,existing in ipairs(bucket) do
                  if tostring(existing.auctionID)==tostring(id) then already=true;break end
                end
                if already then break end
              end
              if not already and not row.sold then
                row.firstSeenAt=row.firstSeenAt or clock()
                tinsert(char.active,row)
              end
            end
            break
          end
        end
      end
    end
    -- Created is already tracked above; wait for Blizzard's normal owned
    -- snapshot instead of resetting the user's native auction sort.
  elseif event == "AUCTION_HOUSE_PURCHASE_COMPLETED" then
    RecordItemPurchase(...)
  elseif event == "COMMODITY_PRICE_UPDATED" then
    RememberCommodityQuote(...)
  elseif event == "COMMODITY_PURCHASED" then
    OnCommodityPurchased(...)
  elseif event == "COMMODITY_PURCHASE_SUCCEEDED" then
    OnCommoditySucceeded()
  elseif event == "COMMODITY_PURCHASE_FAILED" or event == "COMMODITY_PRICE_UNAVAILABLE" then
    if pendingCommodity and not pendingCommodity.committed then pendingCommodity = nil end
  elseif event == "CHAT_MSG_SYSTEM" then
    ChatSale(...)
  elseif event == "AUCTION_HOUSE_SHOW_FORMATTED_NOTIFICATION" then
    AuctionNotification(...)
  elseif event == "MAIL_SHOW" then
    mailOpen = true
    Supply.ShowPacedMail()
    Supply.ReturnMailbox(true)
    mailRows, mailCounts, pendingMail = {}, {}, {}
    previousMailRows, previousMailCounts, previousDropClaims = {}, {}, {}
    ScanMailbox()
    QueueMailScan()
    -- Invoice details sometimes arrive after the initial inbox notification.
    -- Timers from an earlier mailbox session must not read a reopened inbox.
    if C_Timer and C_Timer.After then
      local session = {}
      Supply.mailScanSession = session
      for _,delay in ipairs({0.5, 1, 2}) do
        C_Timer.After(delay,function()
          if mailOpen and Supply.mailScanSession == session then ScanMailbox() end
        end)
      end
    end
  elseif event == "MAIL_CLOSED" then
    Supply.ClosePacedMail()
    Supply.ReturnMailbox(false)
    StopMailWatch()
  elseif event == "MAIL_INBOX_UPDATE" then
    if mailOpen then ScanMailbox(); Supply.ScanReturns() end
  elseif event == "MAIL_SUCCESS" then
    -- A successful mail operation is a prompt to RECHECK, not confirmation
    -- of which invoice was paid. Only an observed cash decrease credits it.
    AcknowledgeMailSuccess()
  elseif event == "MAIL_FAILED" then
    Supply.ReturnTakeFailed()
    RejectMailTake()
  elseif event == "GET_ITEM_INFO_RECEIVED" then
    if panel and panel:IsShown() and not panel.itemRefreshPending then
      if C_Timer and C_Timer.After then
        panel.itemRefreshPending=true
        C_Timer.After(0,function()
          panel.itemRefreshPending=nil
          Render()
        end)
      else Render() end
    end
  end
end)

Supply.Character = function() return char end
Supply.AtAuctioneer = function() return ahOpen end
Supply.Money = MoneyString

-- Optional recovery companion reads the profile currently bound to the UI.
AuctionPeek_GetActiveProfileForRecovery = function() return char end
