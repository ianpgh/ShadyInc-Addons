local AP={Money=tostring,MailValueReadable=function() return true end}
time=os.time; date=os.date
for _,name in ipairs({'Transactions','Reconciliation','Crafts','VendorCosts','History','Inspector'}) do assert(loadfile(name..'.lua'))('AuctionPeek',AP) end
local C,V=AP.Crafts,AP.VendorCosts
local function encode(t)
  if type(t)~='table' then return type(t)..':'..tostring(t) end
  local a={}; for k,v in pairs(t) do a[#a+1]=encode(k)..'='..encode(v) end; table.sort(a); return '{'..table.concat(a,',')..'}'
end
local function projected(ch)
  local sales,flips=AP.BuildHistory(ch,function(n) return (n or ''):lower() end)
  C.Rows(ch,flips,sales); C.AddTransactionRows(ch,flips,sales)
  local map={}; for _,r in ipairs(flips) do if r.auctionID then map[tostring(r.auctionID)]=r end end; return map
end
if arg[1] then
  dofile(arg[1]); local ch=AuctionPeekDB.characters['Crillz - ']; local l=ch.craftLedger
  local before=projected(ch); local raw={}; for _,k in ipairs({'buys','sold','active','ended','deleted'}) do raw[k]=encode(ch[k]) end
  local lots=encode(l.lots); local other={}; for k,p in pairs(l.posts) do if k~='214922938' and k~='210320879' then other[k]=encode(p) end end
  assert(V.Reconcile(ch)==1 and V.Reconcile(ch)==0)
  local p=l.posts['214922938']; assert(p.parts[1].source==1098 and p.parts[1].cost==18000 and l.posts['213107600'].parts[1].source==1099)
  assert(C.ReturnQuantity(l.posts['210320879'])==nil)
  local after=projected(ch); assert(after['214922938'].net==32490 and after['214922938'].profitText=='+14490')
  for k,v in pairs(other) do assert(encode(l.posts[k])==v,k) end
  for k,v in pairs(raw) do assert(encode(ch[k])==v,k) end
  assert(encode(l.lots)==lots)
  for id,r in pairs(before) do if id~='214922938' then assert(encode(after[id].soldCost)==encode(r.soldCost),id) end end
  assert(C.UndoPurchase(ch,'214922938')); assert(V.Reconcile(ch)==0 and p.parts[1].unknown and l.posts['210320879'].parts[1].source==1098)
  print('PASS actual profile: unique stranded purchase, 18000c cost, 14490c profit, unchanged purchase/sale/active history and other lot allocations; reversible, no double credit')
end
local item=42; local ch={buys={{vendor=true,purchaseID=1,quantity=1,price=18000,boughtAt=100,itemID=item,name='Vendor recipe'}},sold={{auctionID=11,itemID=item,quantity=1,sold=true,soldAt=210,receiptID='mail:1',receiptQty=1,verifiedGross=34200,verifiedCut=1710,verifiedDeposit=1000,verifiedNet=33490,name='Vendor recipe'}},active={},ended={},deleted={},craftLedger={lots={},purchases={},posts={['11']={itemID=item,quantity=1,at=200,soldAt=210,ownedSold=true,restoredFromSale=true,parts={{itemID=item,n=1,cost=0,unknown=true}}}}}}
local p=ch.craftLedger.posts['11']; local unknown={cost=0,unknown=true}
assert(not V.Cost(ch,11,unknown)); assert(not V.Save(ch,1,19000,300)); assert(V.Save(ch,1,18000,300))
local raw=encode(ch.craftLedger)
local fallback=assert(V.Cost(ch,11,unknown)); assert(fallback.vendorFallback and fallback.estimate and fallback.cost==18000)
assert(encode(ch.craftLedger)==raw); assert(V.Save(ch,1,17000,300)); assert(V.Cost(ch,11,unknown).cost==18000)
assert(not V.Cost(ch,11,{cost=20000})); assert(V.SetEnabled(ch,item,false)); assert(not V.Cost(ch,11,unknown)); assert(V.SetEnabled(ch,item,true))
local rows=projected(ch); assert(rows['11'].soldCost.vendorFallback and rows['11'].profitText=='~+14490')
assert(V.Manual(ch,11,19000,301)); assert(projected(ch)['11'].profitText=='+13490'); assert(V.UndoManual(ch,11,302)); assert(projected(ch)['11'].soldCost.vendorFallback)
assert(encode(ch.craftLedger)==raw)
ch.craftLedger.lots[1]={itemID=item,looted=true}; assert(not V.Cost(ch,11,unknown)); ch.craftLedger.lots[1]=nil
ch.buys[2]={itemID=item,vendor=false}; assert(not V.Cost(ch,11,unknown)); ch.buys[2]=nil
ch.sold[2]={auctionID=12,receiptID='mail:1'}; assert(not V.Cost(ch,11,unknown)); ch.sold[2]=nil
ch.sold[1].receiptID=nil; assert(not V.Cost(ch,11,unknown)); assert(not V.Manual(ch,11,100,303)); ch.sold[1].receiptID='mail:1'
p.parts[1].source=1; assert(not V.Cost(ch,11,unknown)); p.parts[1].source=nil
print('PASS opt-in vendor fallback, historical price versions, actual-cost precedence, disable, manual override/undo, loot/AH/duplicate receipt/no payment rejection, no ledger mutation')
