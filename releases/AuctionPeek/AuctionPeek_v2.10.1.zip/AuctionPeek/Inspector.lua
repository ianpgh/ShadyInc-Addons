local _, AP = ...
local window
local function when(t)
  return t and date("%b %d %I:%M %p",t) or "Time unknown"
end

function AP.InspectorText(ch, selection, money, matches)
  local id=selection.inspectID or selection.auctionID
  local row=selection
  local records={}
  for _,bucket in ipairs({ch.sold,ch.ended,ch.active,ch.deleted}) do
    for _,r in ipairs(bucket or {}) do
      if id and tostring(r.auctionID)==tostring(id) then
        records[#records+1]=r
        if #records==1 or r.receiptID then row=r end
      end
    end
  end
  local posts=ch.craftLedger and ch.craftLedger.posts or {}
  local p=posts[tostring(id)] or {}
  local lines={row.name or selection.name or "Auction",id and "Auction #"..id or "Auction ID unavailable"}
  local function add(s) lines[#lines+1]=s end
  local function cash(label,value)
    if type(value)=="number" then add(label.."   "..(value==0 and "0c" or money(value))) end
  end
  for _,part in ipairs(p.parts or {}) do
    if part.method=="PLAYER_CONFIRMED_RETURN_FIFO" or part.method=="RETURN_FIFO" then
      add("FIFO return allocation · lot #"..tostring(part.source)..
        (part.returnedFrom and " · previous auction #"..part.returnedFrom or ""))
    end
  end
  local origin=selection.inspectSource or selection
  local pooled=origin.pooledReceipt
  if row.receiptGroup then
    add("Paid · matched as a group")
    add("Group receipts   "..row.receiptGroup)
    add("The individual buyer assignment is unknown.")
  elseif pooled or origin.recoveredReceipts then
    add("Paid · allocated from recorded receipts")
    add("Receipts   "..(pooled and pooled.receiptID or table.concat(origin.recoveredReceipts,", ")))
  elseif row.receiptID then
    add(id and "|TInterface\\Buttons\\UI-CheckBox-Check:14:14:0:0|t Payment recorded" or row.mailFlip and "Payment recorded; purchase cost recovered" or "|cffff5555X|r Receipt has no unique auction match")
    add("Receipt   "..row.receiptID)
    if row.mailFlip then add("Purchase cost recovered #"..row.mailFlip.purchase.."; auction ID unavailable") end
    if row.manualPayment then add("Receipt link confirmed by you") end
  elseif row.sold or p.soldAt or p.saleNoticeAt then add("Sale evidence · payment pending")
  end
  local allocation
  if type(p.quantity)=="number" and p.quantity>1 then
    local key=tostring(id)
    local limit=AP.Transactions.SaleLimit(ch,key,p)
    local sold=p.filled or (row.receiptQuantityKnown and row.receiptQty) or 0
    local active
    for _,r in ipairs(ch.active or {}) do
      if tostring(r.auctionID)==key then active=r; break end
    end
    add((p.observedWithoutAllocation and "First observed quantity   " or "Original recorded quantity   ")..p.quantity)
    add("Confirmed paid units   "..sold)
    if limit>sold then add("Additional units awaiting payment   "..(limit-sold)) end
    if active then add("Active remainder   "..active.quantity)
    elseif p.awaitingReturn then add("Awaiting return   "..math.max(0,p.quantity-math.max(limit,sold)))
    elseif p.unresolved and not p.returnedUnits and sold<p.quantity then
      add("Remainder unresolved · listing disappeared without a confirmed return")
    end
    if p.returnedUnits then add("Returned   "..p.returnedUnits.." ("..p.ended..")") end
    if p.remainderTo then add("Remainder reposted as   #"..p.remainderTo) end
    if p.ended=="canceled" or p.ended=="expired" then add("Remainder "..p.ended) end
    if row.verifiedGross and sold>0 and row.verifiedGross%sold==0 then
      cash("Verified gross per unit",row.verifiedGross/sold)
    elseif p.unitPrice then cash("Listed price per unit",p.unitPrice)
    elseif p.totalPrice then cash("Original price quote (unit or total unverified)",p.totalPrice) end
    if sold>0 then
      allocation=AP.Crafts.AllocationCost(p,0,sold)
      add("Sold cost   "..AP.Crafts.CostLabel(allocation))
    end
    local basisUnits=p.quantity-math.max(sold,limit)
    if basisUnits>0 then
      local basis=AP.Crafts.AllocationCost(p,p.quantity-basisUnits,basisUnits)
      local label=p.returnedUnits and "Returned cost basis" or "Remaining cost basis"
      add(label.."   "..AP.Crafts.CostLabel(basis))
    end
  end
  if p.returnAllocation=="FIFO_IDENTICAL_RETURN" then add("Return allocated by FIFO among identical ended listings") end
  if p.manualPurchaseUndo then add("Undo cost attachment with /ap undocost "..tostring(id)) end
  if p.vendorReconciliation then add("Recovered stranded vendor purchase #"..p.vendorReconciliation.purchase)
  elseif p.confirmedPurchase then add("Buy History match confirmed by you   #"..p.confirmedPurchase) end
  if p.at then add("Posted   "..when(p.at))
  elseif row.firstSeenAt then add("First seen   "..when(row.firstSeenAt)) end
  if id and (row.soldAt or p.soldAt) then
    add((row.saleTimeSource=="invoice" and "Last payment observed   " or "Sale recorded   ")
      ..when(row.soldAt or p.soldAt))
  end
  for _,r in ipairs(records) do
    if r.repostOf then add("Reposted from   #"..r.repostOf) end
    if r.endedReason then add("Listing "..r.endedReason.."   "..when(r.endedAt)) end
    if r.returnCollectedAt then add("Return collected   "..when(r.returnCollectedAt)) end
    if r.repostedAs then add("Reposted as   #"..r.repostedAs) end
  end
  for _,part in ipairs(p.parts or {}) do
    local lot=ch.craftLedger.lots[part.source]
    if lot and lot.purchase then
      add("Allocated purchase #"..lot.purchase.."   "..part.n.." unit(s)")
      cash("Allocated purchase cost",part.cost)
      if part.returnedFrom then add("Source lot returned from #"..part.returnedFrom) end
    end
  end
  if not allocation and row.receiptID and p.parts and row.quantity==1 and p.quantity==1 then
    allocation=AP.Crafts.AllocationCost(p,0,1)
    if AP.VendorCosts then
      local base=origin.soldCost
      if base and not base.unknown and not base.manual and not base.vendorFallback and allocation.unknown then allocation=base end
      local adjusted=AP.VendorCosts.Cost(ch,id,allocation)
      if adjusted then allocation=adjusted; add(adjusted.note) end
    end
    add("Sold cost   "..AP.Crafts.CostLabel(allocation))
    for _,part in ipairs(p.parts) do
      local lot=ch.craftLedger.lots[part.source]
      for _,input in ipairs(lot and lot.parts or {}) do
        local evidence=input.costEstimateEvidence
        if evidence then
          add("Estimated Wildvine from purchases #"..evidence.first.." and #"..evidence.second)
          cash("Estimated ingredient cost",input.cost)
        end
      end
    end
    if allocation.unknown then
      local unknown=AP.Crafts.UnknownIngredients(ch,p.parts)
      if unknown~="" then add("Unknown cost   "..unknown) end
    end
  end
  if row.repostOf and p.parts and #p.parts==1 then
    local previous=posts[tostring(row.repostOf)]
    local prior=previous and previous.parts and #previous.parts==1 and previous.parts[1]
    if prior and prior.source and p.parts[1].source and prior.source~=p.parts[1].source
        and not (previous.returnedUnits or previous.remainderTo) then
      add("Possible repost · the two listings have different recorded cost sources.")
    end
  end
  if origin.soldCost and origin.soldCost.note then add(origin.soldCost.note) end
  if row.reconciledAt then add("Payment recorded   "..when(row.reconciledAt)) end
  cash("Verified gross",row.verifiedGross)
  cash("AH fee",row.verifiedCut)
  if row.verifiedGross and row.verifiedCut then cash("After AH cut",row.verifiedGross-row.verifiedCut)
  elseif pooled or origin.recoveredReceipts then cash("Allocated after AH cut",origin.net) end
  cash("Deposit returned",row.verifiedDeposit)
  cash("Collected",row.verifiedNet)
  if allocation and row.verifiedGross and row.verifiedCut then
    if allocation.unknown then add("|cffff5555X|r Profit unresolved · material cost unknown")
    else cash(allocation.estimate and "Estimated profit" or "Realized profit (before deposit losses)",
      row.verifiedGross-row.verifiedCut-allocation.cost) end
  end
  if p.fills then
    local keys={}
    for key in pairs(p.fills) do keys[#keys+1]=key end
    table.sort(keys)
    for _,key in ipairs(keys) do
      local fill=p.fills[key]
      add(key.."   "..tostring(fill.quantity or "?").." units"
        ..(fill.buyer and fill.buyer~="" and "   "..fill.buyer or ""))
      cash("  Collected",fill.net)
    end
  end
  return table.concat(lines,"\n")
end

function AP.OpenInspector(parent,ch,selection,money,matches,nameKey,refresh)
  if not window then
    window=CreateFrame("Frame",nil,parent)
    window:SetSize(420,310)
    window:SetPoint("CENTER")
    window:SetFrameStrata("DIALOG")
    window:SetFrameLevel(parent:GetFrameLevel()+25)
    window:EnableMouse(true)
    local bg=window:CreateTexture(nil,"BACKGROUND")
    bg:SetAllPoints()
    bg:SetColorTexture(.07,.06,.05,1)
    local title=window:CreateFontString(nil,"OVERLAY","GameFontNormalLarge")
    title:SetPoint("TOPLEFT",16,-12)
    title:SetText("Auction ID Inspector")
    local close=CreateFrame("Button",nil,window,"UIPanelCloseButton")
    close:SetPoint("TOPRIGHT")
    close:SetScript("OnClick",function() window:Hide() end)
    window:EnableKeyboard(true)
    window:SetPropagateKeyboardInput(true)
    window:SetScript("OnKeyDown",function(self,key)
      if InCombatLockdown and InCombatLockdown() then return end
      self:SetPropagateKeyboardInput(key~="ESCAPE")
      if key=="ESCAPE" then self:Hide() end
    end)
    local scroll=CreateFrame("ScrollFrame",nil,window,"UIPanelScrollFrameTemplate")
    scroll:SetPoint("TOPLEFT",16,-42)
    scroll:SetPoint("BOTTOMRIGHT",-32,14)
    local body=CreateFrame("Frame",nil,scroll)
    body:SetWidth(368)
    scroll:SetScrollChild(body)
    local text=body:CreateFontString(nil,"OVERLAY","GameFontHighlight")
    text:SetPoint("TOPLEFT")
    text:SetWidth(366)
    text:SetJustifyH("LEFT")
    text:SetSpacing(4)
    window.text,window.body,window.scroll=text,body,scroll
    parent:HookScript("OnHide",function() window:Hide() end)
  end
  window.text:SetText(AP.InspectorText(ch,selection,money,matches))
  window.choices=window.choices or {}
  for _,button in ipairs(window.choices) do button:Hide() end
  local height=window.text:GetStringHeight()+8
  if selection.mailOnly and not selection.mailFlip and selection.receiptID and not selection.auctionID then
    local receiptID=selection.receiptID
    local choices=AP.ManualTargets(ch,receiptID,nameKey)
    window.text:SetText(window.text:GetText()..(#choices>0 and "\nSelect a sold auction to link this receipt:" or "\nNo eligible unpaid single-item sales."))
    height=window.text:GetStringHeight()+8
    for i,sale in ipairs(choices) do
      local button=window.choices[i] or CreateFrame("Button",nil,window.body,"UIPanelButtonTemplate")
      window.choices[i]=button
      local id=sale.auctionID
      local summary="#"..id.."   "..when(sale.soldAt).."   "..((sale.buyout or 0)>0 and money(sale.buyout) or "Price unknown")
      button:SetSize(364,24)
      button:ClearAllPoints()
      button:SetPoint("TOPLEFT",0,-height)
      button:SetText(summary)
      button:SetScript("OnClick",function()
        if window.pending~=button then
          if window.pending then window.pending:SetText(window.pending.summary) end
          window.pending=button
          button:SetText("Confirm "..receiptID.."  to  #"..id)
          return
        end
        local linked=AP.MatchPayment(ch,receiptID,id,nameKey)
        refresh()
        AP.OpenInspector(parent,ch,linked or selection,money,matches,nameKey,refresh)
      end)
      button.summary=summary
      button:Show()
      height=height+26
    end
  end
  local targetID=selection.inspectID or selection.auctionID
  if targetID then
    local choices=AP.Crafts.CostSources(ch,targetID)
    for _,buy in ipairs(AP.Crafts.PurchaseSources(ch,targetID)) do choices[#choices+1]=buy end
    for i,choice in ipairs(choices) do
      local old,buy=choice.old,choice.buy
      local button=window.choices[i] or CreateFrame("Button",nil,window.body,"UIPanelButtonTemplate")
      window.choices[i]=button
      button:SetSize(364,24)
      button:ClearAllPoints()
      button:SetPoint("TOPLEFT",0,-height)
      if buy then
        button.summary=(buy.vendor and "Vendor" or "AH").." buy #"..buy.purchaseID.."   "..money(choice.cost).."   "..when(buy.boughtAt)
      else button.summary="Use craft cost "..money(choice.cost).." from #"..old.auctionID end
      button:SetText(button.summary)
      button:SetScript("OnClick",function()
        if window.pending~=button then
          if window.pending then window.pending:SetText(window.pending.summary) end
          window.pending=button
          button:SetText(buy and "Confirm purchase #"..buy.purchaseID or "Confirm craft source #"..old.auctionID)
          return
        end
        local linked
        if buy then linked=AP.Crafts.ConfirmPurchase(ch,targetID,buy.purchaseID)
        else linked=AP.Crafts.ConfirmCostSource(ch,targetID,old.auctionID) end
        refresh()
        AP.OpenInspector(parent,ch,linked or selection,money,matches,nameKey,refresh)
      end)
      button:Show()
      height=height+26
    end
  end
  if targetID and AP.VendorCosts and AP.VendorCosts.CanManual(ch,targetID) then
    local i=#AP.Crafts.CostSources(ch,targetID)+#AP.Crafts.PurchaseSources(ch,targetID)+1
    local function redraw() refresh(); AP.OpenInspector(parent,ch,selection,money,matches,nameKey,refresh) end
    local function action(text,fn)
      local button=window.choices[i] or CreateFrame("Button",nil,window.body,"UIPanelButtonTemplate")
      window.choices[i]=button; i=i+1
      button:SetSize(364,24); button:ClearAllPoints(); button:SetPoint("TOPLEFT",0,-height)
      button:SetText(text); button:SetScript("OnClick",fn); button:Show(); height=height+26
    end
    action("Set Manual Cost (g / s / c)",function() AP.VendorCosts.OpenManual(ch,targetID,redraw,selection.soldCost) end)
    if AP.VendorCosts.ManualActive(ch,targetID) then
      action("Undo Manual Cost",function() AP.VendorCosts.UndoManual(ch,targetID,time()); redraw() end)
    end
  end
  window.pending=nil
  window.body:SetHeight(math.max(1,height))
  window.scroll:SetVerticalScroll(0)
  window:Show()
end
