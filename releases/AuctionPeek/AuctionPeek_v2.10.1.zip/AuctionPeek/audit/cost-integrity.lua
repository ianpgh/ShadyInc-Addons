local AP={Money=tostring,MailValueReadable=function() return true end}
for _,name in ipairs({"Reconciliation","Crafts","Returns","Accounting","CostIntegrity","History","MailFlip"}) do
  assert(loadfile(name..".lua"))("AuctionPeek",AP)
end
local C,I=AP.Crafts,AP.CostIntegrity
local now=2000
time=function() return now end
date=os.date
local function eq(a,b,context)
  assert(a==b,(context or "").." expected "..tostring(b)..", got "..tostring(a))
end
local function copy(t)
  if type(t)~="table" then return t end
  local out={}
  for k,v in pairs(t) do out[k]=copy(v) end
  return out
end
local function profile(crafted)
  local lot={index=1,itemID=10026,quantity=1,left=0,cost=11556,balance=0,at=1000}
  if crafted then lot.parts={{itemID=4339,n=3,cost=11556}} else lot.purchase=1 end
  local old={auctionID=123,itemID=10026,quantity=1,firstSeenAt=1100,endTime=1900,name="Black Mageweave Boots"}
  return {active={old},sold={},ended={},deleted={},buys={{purchaseID=1,itemID=10026}},
    craftLedger={lots={lot},purchases={},posts={["123"]={at=1100,itemID=10026,quantity=1,
      parts={{source=1,itemID=10026,n=1,cost=11556}}}}}},old
end
local function sold(ch,id)
  local row={auctionID=id,itemID=10026,quantity=1,soldAt=2020,sold=true,receiptID="mail:1",
    receiptQty=1,receiptQuantityKnown=true,verifiedGross=17541,verifiedCut=877,
    verifiedDeposit=1091,verifiedNet=17755,name="Black Mageweave Boots"}
  ch.sold[1]=row
  local post={at=2010,itemID=10026,quantity=1,soldAt=2020,ownedSold=true,gross=17541,cut=877,
    parts={{itemID=10026,n=1,cost=0,unknown=true}}}
  ch.craftLedger.posts[tostring(id)]=post
  return row,post
end

local ch,old=profile(true)
AP.Character=function() return ch end
local inbox={true}
GetInboxNumItems=function() return #inbox end
GetInboxHeaderInfo=function(i)
  if inbox[i] then return nil,nil,"Auction House","Auction expired: Black Mageweave Boots",0,0,1,1 end
end
GetInboxItem=function(i) if inbox[i] then return "Black Mageweave Boots",10026,nil,1 end end
GetTime=function() return now end
TakeInboxItem=function() end
local take
hooksecurefunc=function(name,fn) if name=="TakeInboxItem" then take=fn end end
AP.InstallReturnHooks()
AP.ReturnMailbox(true)
take(1,1);take(1,1)
inbox={}
AP.ScanReturns()
AP.ScanReturns()
eq(#ch.returnEvidence.pending,1)
eq(ch.craftLedger.lots[1].balance,0)
AP.ReturnMailbox(false)
ch=copy(ch)
assert(loadfile("Returns.lua"))("AuctionPeek",AP)
old=ch.active[1]
old.endedReason="unconfirmed"
ch.ended[1]=old
eq(AP.ReconcileReturns(ch,{["123"]=true}),0,"owned snapshot still contains ID")
eq(AP.ReconcileReturns(ch),0,"saved active info cannot alone release")
ch.active={}
local competing={mailOnly=true,receiptID="mail:77",itemID=10026,quantity=1,observedAt=1950}
ch.sold[1]=competing
eq(AP.ReconcileReturns(ch),0,"unmatched payment blocks premature release")
ch.sold={}
local count,cost=AP.ReconcileReturns(ch)
eq(count,1);eq(cost,11556)
eq(AP.ReconcileReturns(ch),0)
eq(ch.craftLedger.lots[1].balance,11556)
eq(ch.craftLedger.posts["123"].returnedAt,2000)
eq(#ch.returnEvidence.pending,0)
print("PASS persisted offline expiration, reload, conflicting snapshots and seller receipt, duplicate pickup, exact return conservation")

local row,post=sold(ch,456)
row.repostOf=123
old.repostedAs=456
local n,amount=I.RecoverReposts(ch)
eq(n,1);eq(amount,11556)
eq(I.RecoverReposts(ch),0)
local summary=I.Audit(ch)
eq(summary.sold.cost,11556);eq(summary.available.cost,0);eq(summary.discrepancies,0)
local sales,flips=AP.BuildHistory(ch,function(name) return (name or ""):lower() end)
C.Rows(ch,flips,sales)
eq(flips[1].net,16664)
eq(flips[1].profitText,"+5108","deposit excluded")
ch=copy(ch)
eq(I.Undo(ch,456),true)
eq(I.Undo(ch,456),nil)
eq(I.RecoverReposts(ch),0,"undo blocks automatic redo")
eq(ch.craftLedger.lots[1].balance,11556)
eq(I.Assign(ch,456,1),true)
eq(I.Assign(ch,456,1),nil)
eq(I.Audit(ch).discrepancies,0)
print("PASS verified linked repost, after-cut profit, reload-safe undo, manual reassign, no double spend")

ch,old=profile(false)
ch.active={}
ch.ended={old}
old.endedReason="unconfirmed"
assert(C.CollectReturn(ch,ch.craftLedger.posts["123"],1,"expired",123))
sold(ch,456)
ch.sold[1].itemSuffix=9
eq(#I.Choices(ch,456),0,"variant mismatch")
ch.sold[1].itemSuffix=0
eq(I.Assign(ch,456,1),true,"purchase lot")
eq(I.Undo(ch,456),true)
print("PASS purchase recovery, variant isolation and undo")

ch,old=profile(true)
local second=copy(old)
second.auctionID,second.endTime=124,1910
old.endedReason,second.endedReason="unconfirmed","unconfirmed"
ch.active={}
ch.ended={old,second}
local ledger=ch.craftLedger
local secondLot=copy(ledger.lots[1])
secondLot.index,secondLot.cost=2,12146
ledger.lots[2]=secondLot
local secondPost=copy(ledger.posts["123"])
secondPost.parts[1].source,secondPost.parts[1].cost=2,12146
ledger.posts["124"]=secondPost
local e={id=10026,n=1,reason="expired",at=2000}
ch.returnEvidence={version=1,pending={copy(e)},resolved=0}
eq(AP.ReconcileReturns(ch),0,"two possible expirations, one pickup")
table.insert(ch.returnEvidence.pending,copy(e))
eq(AP.ReconcileReturns(ch),2,"both matching returns observed")
eq(ledger.lots[1].balance+ledger.lots[2].balance,23702)
eq(AP.ReconcileReturns(ch),0)
print("PASS grouped offline expirations require enough compatible confirmed pickups")

ch=profile(false)
ch.active={}
local l=ch.craftLedger
l.lots={}
l.posts={}
for i=1,30000 do
  l.lots[i]={index=i,itemID=i,quantity=1,left=1,at=1000,cost=71,balance=71}
end
local start=os.clock()
local t=I.Audit(ch)
eq(t.available.cost,2130000)
eq(t.discrepancies,0)
print(("PASS read-only 30,000-lot integrity scan %.3fs CPU"):format(os.clock()-start))

for _,path in ipairs(arg) do
  dofile(path)
  local fixture=AuctionPeekDB.characters["Crillz - "]
  local stats=I.Audit(fixture)
  local old1=fixture.craftLedger.posts["216017663"]
  local old2=fixture.craftLedger.posts["216090883"]
  eq(old1.parts[1].cost,11556);eq(old2.parts[1].cost,12146)
  eq(I.RecoverReposts(fixture),0)
  eq(#I.Choices(fixture,223572224),0)
  eq(old1.returnedUnits,nil);eq(old2.returnedUnits,nil)
  local ref,trigger,boots
  for _,r in ipairs(fixture.sold) do
    if r.auctionID==215398138 then ref=r end
    if r.auctionID==223572224 then boots=r end
    if r.receiptID=="mail:272" then trigger=r end
  end
  eq(C.AllocationCost(fixture.craftLedger.posts["215398138"],0,1).cost,9119)
  eq(AP.Reconciliation.VerifiedProceeds(ref)-9119,4086)
  eq(trigger.mailFlip.purchase,333);eq(trigger.itemID,10560)
  eq(trigger.mailFlip.cost,2300);eq(trigger.verifiedGross-trigger.verifiedCut-trigger.mailFlip.cost,-126)
  eq(fixture.craftLedger.lots[trigger.mailFlip.source].left,0)
  eq(AP.MailFlip.Reconcile(fixture,function(name) return (name or ""):lower() end),0)
  if boots.receiptID then eq(boots.receiptID,"mail:275");eq(AP.Reconciliation.VerifiedProceeds(boots),16664) end
  local c=fixture.craftLedger
  local function sameItem(name) return name and name:find("Unstable Trigger",1,true) end
  for _,b in ipairs(fixture.buys) do if sameItem(b.name) and b.purchaseID==333 then eq(b.itemID,10560) end end
  print(("PASS fixture boots and Unstable Trigger: spend %d, available %d/%d, reserved %d/%d, pending %d/%d, unresolved %d/%d, crafted %d/%d, sold %d/%d, missing %d, partial %d, lot variances %d")
    :format(stats.original,stats.available.n,stats.available.cost,stats.reserved.n,stats.reserved.cost,
      stats.pending.n,stats.pending.cost,stats.unresolved.n,stats.unresolved.cost,stats.crafting.n,stats.crafting.cost,
      stats.sold.n,stats.sold.cost,stats.missing,stats.partial,stats.discrepancies))
end
