local AP={}
for _,m in ipairs({"Reconciliation","Crafts","Transactions","VendorCosts","Accounting","CostIntegrity","RepostCosts","Returns"}) do
  assert(loadfile(m..".lua"))("AuctionPeek",AP)
end
time=function() return 2000 end
local ch={active={},ended={},sold={},deleted={},buys={},craftLedger={lots={},posts={},purchases={}}}
local l=ch.craftLedger
ch.returnEvidence={version=1,pending={},resolved=0}
for i,cost in ipairs({1001,2002}) do
  l.lots[i]={index=i,itemID=99,at=i,cost=cost,balance=0,quantity=2,left=0,parts={}}
  local old={auctionID=i,firstSeenAt=10,endedReason="expired",itemID=99,quantity=2,endTime=100}
  l.posts[tostring(i)]={itemID=99,quantity=2,at=i+10,ended="expired",awaitingReturn=true,
    parts={{itemID=99,source=i,cost=cost,n=2}}}
  ch.returnEvidence.pending[i]={id=99,n=2,at=200,reason="expired"}
  ch.active[i]=old
end
for _,id in ipairs({4,3}) do
  l.posts[tostring(id)]={at=300+id}
  AP.Crafts.Observe(ch,{auctionID=id,itemID=99,quantity=id==3 and 3 or 1})
  assert(l.posts[tostring(id)].parts[1].unknown)
end
ch.ended,ch.active=ch.active,{}
assert(AP.ReconcileReturns(ch)==2)
local a,b=l.posts["3"],l.posts["4"]
assert(#a.parts==2 and a.parts[1].source==1 and a.parts[1].cost==1001 and a.parts[2].cost==1001)
assert(#b.parts==1 and b.parts[1].source==2 and b.parts[1].cost==1001)
assert(l.lots[1].left==0 and l.lots[2].balance==0)
assert(AP.ReconcileReturns(ch)==0)
assert(AP.CostIntegrity.Audit(ch).discrepancies==0)
print("PASS confirmed returns arriving after repost allocation, merged and split stacks, exact copper, FIFO, repeated reconciliation")
for _,path in ipairs(arg) do
  dofile(path)
  local c=AuctionPeekDB.characters["Crillz - "]
  local ledger=c.craftLedger
  local before=AP.CostIntegrity.Audit(c)
  assert(AP.RepostCosts.ConfirmBoots(c))
  assert(not AP.RepostCosts.ConfirmBoots(c))
  assert(ledger.posts["223570302"].parts[1].cost==11556)
  assert(ledger.posts["223572224"].parts[1].cost==12146)
  local after=AP.CostIntegrity.Audit(c)
  assert(after.discrepancies==before.discrepancies and after.available.cost==before.available.cost)
  assert(after.unresolved.cost==before.unresolved.cost-23702)
  assert(after.reserved.cost==before.reserved.cost+11556)
  assert(after.sold.cost==before.sold.cost+12146)
  assert(AP.RepostCosts.UndoBoots(c))
  assert(not AP.RepostCosts.ConfirmBoots(c))
  assert(AP.CostIntegrity.Audit(c).unresolved.cost==before.unresolved.cost)
  print("PASS fixture migration, exact cost transfer, unchanged available inventory, safe undo, idempotence")
end
