local AP={Money=tostring}
local function load(name) assert(loadfile("./"..name..".lua"))("AuctionPeek",AP) end
local now=1000000
time=function() return now end
date=os.date
GetItemInfo=function(id) return id==20 and "Cooked" or id==21 and "Unpriced" or "Raw" end
for _,name in ipairs({"Transactions","Crafts","History","Accounting","Returns","Inspector"}) do load(name) end
local C,T=AP.Crafts,AP.Transactions
local function norm(n) return (n or ""):lower() end
local function eq(actual,expected,label)
  assert(actual==expected,(label or "assertion")..": expected "..tostring(expected)..", got "..tostring(actual))
end
local function new()
  local ch={active={},ended={},sold={},deleted={},buys={},postingEvidence={}}
  T.Migrate(ch)
  return ch
end
local function purchase(ch,id,n,cost,pid)
  table.insert(ch.buys,1,{purchaseID=pid,itemID=id,quantity=n,price=cost,boughtAt=now})
end
local function post(ch,id,n,price,item)
  local row={itemID=item or 20,name=GetItemInfo(item or 20),auctionID=id,quantity=n,
    buyout=price,unitPrice=price,firstSeenAt=now,seenAt=now}
  C.Created(ch,id)
  C.Observe(ch,row)
  T.Observe(ch,row)
  table.insert(ch.active,row)
  return row,T.Post(ch,id)
end
local function receipt(ch,key,n,unit,buyer,auction)
  local gross=n*unit
  local fee=math.floor(gross/20)
  local r={name="Cooked",receiptID=key,mailOnly=true,sold=true,quantity=n,receiptQty=n,
    receiptQuantityKnown=true,verifiedGross=gross,verifiedCut=fee,verifiedDeposit=n,
    verifiedNet=gross-fee+n,receiptBuyer=buyer,observedAt=now,soldAt=now,
    invoiceAuctionID=auction}
  table.insert(ch.sold,r)
  return r
end
local function refresh(ch,row,n)
  row.quantity=n
  row.seenAt=now
  C.Observe(ch,row)
  T.Observe(ch,row)
end
local function close(ch,row,reason)
  for i,r in ipairs(ch.active) do if r==row then table.remove(ch.active,i); break end end
  row.endedAt,row.endedReason=now,reason
  table.insert(ch.ended,row)
  C.End(ch,row.auctionID,reason)
  T.Post(ch,row.auctionID).activeObserved=nil
end
local function flip(ch)
  local sales,flips=AP.BuildHistory(ch,norm)
  C.Rows(ch,flips,sales)
  C.AddTransactionRows(ch,flips,sales)
  return flips,sales
end
local function inventory(ch,item)
  local n,cost=0,0
  for _,x in ipairs(ch.craftLedger.lots) do
    if x.itemID==item then n,cost=n+x.left,cost+x.balance end
  end
  return n,cost
end
local function reload(ch)
  local function copy(value)
    if type(value)~="table" then return value end
    local result={}
    for k,v in pairs(value) do result[k]=copy(v) end
    return result
  end
  load("Transactions");load("Crafts")
  C,T=AP.Crafts,AP.Transactions
  return copy(ch)
end

local ch=new()
purchase(ch,10,100,5001,1)
local batch=C.Record(ch,"craft100",{id=20,n=100,mats={{id=10,n=100}}},now)
eq(batch.cost,5001)
eq(inventory(ch,10),0)
local row,p=post(ch,100,100,798)
eq(inventory(ch,20),0)
receipt(ch,"mail:1",2,798,"Buyer 1")
eq(T.Reconcile(ch,norm),0,"mail before owned refresh")
ch=reload(ch)
row,p=ch.active[1],T.Post(ch,100)
refresh(ch,row,98)
eq(T.Reconcile(ch,norm),1)
eq(T.Reconcile(ch,norm),0,"retry idempotence")
eq(p.filled,2)
local f=flip(ch)
eq(#f,1);eq(f[1].soldCost.cost,100);eq(f[1].net,1517);eq(f[1].profitText,"+1417")
local first=now
now=now+90000
refresh(ch,row,95)
receipt(ch,"mail:2",3,798,"Buyer 2")
eq(T.Reconcile(ch,norm),1,"second buyer after refresh")
eq(p.filled,5);eq(ch.sold[1].verifiedGross,3990)
eq(T.Recent(ch,ch.sold[1],now).quantity,3)
eq(T.Recent(ch,ch.sold[1],first).quantity,2)
close(ch,row,"canceled")
eq(C.ReturnQuantity(p),95)
assert(C.CollectReturn(ch,p,95,"canceled",100))
eq(C.CollectReturn(ch,p,95,"canceled",100),nil,"no duplicate return")
local n,balance=inventory(ch,20);eq(n,95);eq(balance,4751)
local repost,rp=post(ch,101,95,800)
eq(rp.parts[1].cost,4751)
close(ch,repost,"unconfirmed")
eq(rp.filled,nil,"disappearance does not create a sale")
receipt(ch,"mail:3",95,800,"Buyer 3")
eq(T.Reconcile(ch,norm),1,"combined full stack after disappearance")
eq(rp.filled,95)
f=flip(ch)
eq(#f,2)
local groups=C.ItemGroups(ch,f,ch.sold)
eq(#groups,1);eq(groups[1].quantity,100);eq(groups[1].soldCost.cost,5001)
eq(groups[1].net,75992)
print("PASS 100 cooked, two partial payments, reload, 24h, return, repost, full payout, grouping, copper conservation")

ch=new()
local a,pa=post(ch,201,20,400)
local b,pb=post(ch,202,20,400)
refresh(ch,a,18);refresh(ch,b,18)
receipt(ch,"mail:4",2,400,"Same Price")
eq(T.Reconcile(ch,norm),0,"identical listings collide")
eq(ch.sold[1].auctionID,nil)
eq(ch.sold[1].verifiedGross,800,"unmatched revenue stays verified")
ch.sold[1].invoiceAuctionID=201
eq(T.Reconcile(ch,norm),1)
eq(pa.filled,2);eq(pb.filled,nil)
print("PASS identical-price ambiguity, explicit ID, unmatched revenue")

ch=new()
purchase(ch,20,20,1001,2)
a,pa=post(ch,301,20,100)
refresh(ch,a,18)
close(ch,a,"expired")
eq(C.ReturnQuantity(pa),18)
assert(C.CollectReturn(ch,pa,18,"expired",301))
receipt(ch,"mail:5",2,100,"Late buyer")
eq(T.Reconcile(ch,norm),1)
eq(pa.filled+pa.returnedUnits,20)
n,balance=inventory(ch,20);eq(n,18);eq(balance,901)
b,pb=post(ch,302,18,500)
close(ch,b,"canceled")
eq(C.ReturnQuantity(pb),18)
assert(C.CollectReturn(ch,pb,18,"canceled",302))
eq(pb.filled,nil)
n,balance=inventory(ch,20);eq(n,18);eq(balance,901)
print("PASS expired partial, return before mail, canceled without sales")

ch=new()
purchase(ch,10,2,101,11)
purchase(ch,10,3,152,12)
purchase(ch,11,2,17,13)
local recipe={id=20,n=8,mats={{id=10,n=5},{id=11,n=2}}}
batch=C.Record(ch,"multi",recipe,now)
eq(batch.cost,270);eq(batch.unknown,false)
eq(C.Record(ch,"multi",recipe,now),nil)
AP.MailValueReadable=function() return true end
LOOT_ITEM_SELF_MULTIPLE="Loot %s x%d"
C.PersonalLoot(ch,"Loot |Hitem:20|h[Cooked]|h x2")
purchase(ch,20,2,190,14)
a,pa=post(ch,401,12,1000)
eq(C.AllocationCost(pa,0,12).cost,460)
eq(C.AllocationCost(pa,0,12).unknown,false)
batch=C.Record(ch,"unknown",{id=21,n=2,mats={{id=10,n=1}}},now)
eq(batch.unknown,true)
eq(batch.cost,0)
print("PASS mixed crafting inputs, multiple output, purchased/crafted/looted supply, unknown costs")

ch=new()
C_TradeSkillUI={GetRecipeSchematic=function()
  return {outputItemID=20,quantityMin=2,quantityMax=2,reagentSlotSchematics={{reagents={{itemID=10}},quantityRequired=1}}}
end}
GetItemCount=function() return 1 end
purchase(ch,10,1,203,15)
C.Cast(ch,"UNIT_SPELLCAST_START","player","cast-1",5)
ch=reload(ch)
batch=C.Cast(ch,"UNIT_SPELLCAST_SUCCEEDED","player","cast-1",5)
eq(batch.quantity,2);eq(batch.cost,203)
eq(C.Cast(ch,"UNIT_SPELLCAST_SUCCEEDED","player","cast-1",5),nil)
print("PASS confirmed cast across module and SavedVariables reload")

ch=new()
purchase(ch,20,1,200,16)
ch.buys[1].vendor=true
a,pa=post(ch,501,1,700)
C.ConfirmSoldID(ch,a,true)
a.sold,a.soldAt,a.receiptID=true,now,"mail:6"
a.verifiedGross,a.verifiedCut,a.verifiedNet=700,35,690
a.receiptQty,a.receiptQuantityKnown=1,true
ch.active={};ch.sold={a}
C.Sale(ch,a)
f=flip(ch)
eq(#f,1);eq(f[1].soldCost.cost,200);eq(f[1].net,665)
print("PASS legacy vendor recipe and ordinary single-item sale projection")

ch=new()
a,pa=post(ch,601,10,400)
local snap={auctionID=601,itemID=20,name="Cooked",quantity=10,sold=true,seenAt=now}
T.Observe(ch,snap)
receipt(ch,"mail:7",10,400,"Buyer")
eq(T.Reconcile(ch,norm),0,"sold snapshot cannot override intact active remainder")
refresh(ch,a,9)
receipt(ch,"mail:8",1,400,"Buyer")
eq(T.Reconcile(ch,norm),1,"one-unit receipt from a stack")
eq(pa.filled,1)
eq(#ch.sold,2,"unrelated full receipt kept")
local duplicate={name="Cooked",receiptID="mail:8",receiptQty=1,receiptQuantityKnown=true,
  verifiedGross=400,verifiedCut=20,verifiedDeposit=1,verifiedNet=381,mailOnly=true}
table.insert(ch.sold,duplicate)
local _,sales=flip(ch)
eq(#sales,2,"strong duplicate remains in storage and counts once")
eq(#ch.sold,3)
print("PASS single-unit commodity sale, intact active remainder protects capacity, duplicate payout projection")

ch=new()
purchase(ch,10,10,1003,71)
local crafted=C.Record(ch,"duplicate-reagent-slots",{id=20,n=2,mats={{id=10,n=2},{id=10,n=2}},onHand={[10]=4}},now)
eq(crafted.cost,401,"apply the bag cap once per distinct reagent")
eq(crafted.unknown,false)
eq(ch.craftLedger.craftDiagnostics[1].inputs[1].excluded,6)
local intermediate=C.Record(ch,"consume-intermediate",{id=21,n=1,mats={{id=20,n=2}}},now)
eq(intermediate.cost,401)
eq(inventory(ch,20),0)
local taken=C.Record(ch,"unpriced",{id=21,n=1,mats={{id=10,n=2}},onHand={[10]=0}},now)
eq(taken.unknown,true)
eq(ch.craftLedger.craftDiagnostics[2].inputs[1].missing,2)
print("PASS grouped reagent slots, intermediate cost, bag mismatch diagnostics")

ch=new()
purchase(ch,20,1,351,72)
C.Record(ch,"import",{id=21,n=1,mats={{id=11,n=1}}},now)
local manual={auctionID=901,itemID=20,quantity=1,sold=true,soldAt=now}
ch.sold={manual}
local manualPost={at=now,itemID=20,quantity=1,soldAt=now,
  parts={{itemID=20,n=1,cost=0,unknown=true}}}
ch.craftLedger.posts["901"]=manualPost
assert(C.ConfirmPurchase(ch,"901",72))
eq(C.ConfirmPurchase(ch,"901",72),nil)
eq(inventory(ch,20),0)
ch=reload(ch)
assert(C.UndoPurchase(ch,"901"))
eq(C.UndoPurchase(ch,"901"),nil)
n,balance=inventory(ch,20);eq(n,1);eq(balance,351)
C.Record(ch,"already-consumed",{id=21,n=1,mats={{id=20,n=1}}},now)
eq(C.ConfirmPurchase(ch,"901",72),nil)
print("PASS manual attach, duplicate rejection, undo after reload, cannot attach consumed input")

ch=new()
purchase(ch,10,1,111,73)
C.Record(ch,"priced-glove",{id=20,n=1,mats={{id=10,n=1}}},now)
LOOT_ITEM_SELF="Loot %s"
C.PersonalLoot(ch,"Loot |Hitem:10|h[Raw]|h")
C.Record(ch,"looted-glove",{id=20,n=1,mats={{id=10,n=1}}},now)
a,pa=post(ch,610,1,400)
b,pb=post(ch,611,1,400)
eq(pa.parts[1].cost,111);eq(pb.parts[1].cost,0)
close(ch,b,"canceled"); now=now+1; close(ch,a,"canceled")
AP.Character=function() return ch end
local inbox={1,1}
GetInboxNumItems=function() return #inbox end
GetInboxHeaderInfo=function(i)
  if inbox[i] then return nil,nil,"Auction House","Auction cancelled: Cooked",0,0,28,1 end
end
GetInboxItem=function(i) if inbox[i] then return "Cooked",20,nil,1 end end
GetTime=function() return now end
local hook
TakeInboxItem=function() end
hooksecurefunc=function(name,cb) if name=="TakeInboxItem" then hook=cb end end
AP.InstallReturnHooks()
AP.ReturnMailbox(true)
hook(1,1);hook(1,1)
table.remove(inbox,1);AP.ScanReturns()
eq(pb.returnedUnits,1);eq(pb.returnAllocation,"FIFO_IDENTICAL_RETURN")
eq(pa.returnedUnits,nil)
hook(1,1)
table.remove(inbox,1);AP.ScanReturns()
eq(pa.returnedUnits,1)
n,balance=inventory(ch,20);eq(n,2);eq(balance,111)
for i=1,3 do
  local listed,allocation=post(ch,620+i,2,800)
  eq(C.AllocationCost(allocation,0,2).cost,111)
  close(ch,listed,"canceled")
  assert(C.CollectReturn(ch,allocation,2,"canceled",621))
  n,balance=inventory(ch,20);eq(n,2);eq(balance,111)
end
print("PASS identical return mail, FIFO cancellation order, repeated reposting and conserved basis")

ch=new()
local messages={}
local function capture(s) messages[#messages+1]=s end
local missing=C.Record(ch,"warning",{id=20,n=1,mats={{id=10,n=4}}},now)
C.WarnUnpricedCraft(ch,missing,capture)
C.WarnUnpricedCraft(ch,missing,capture)
eq(#messages,1)
assert(messages[1]:find("4× Raw",1,true))
now=now+60
C.WarnUnpricedCraft(ch,missing,capture)
eq(#messages,2)
print("PASS informative material warning and cooldown")
