Open a terminal in the AuctionPeek folder. Run with Lua 5.3 or texlua:

  texlua audit/regression.lua
  texlua audit/saved-replay.lua /path/to/current-SavedVariables.lua current
  texlua audit/saved-replay.lua /path/to/backup-SavedVariables.bak backup

The saved-replay assertions target the two November 25 fixtures used in the
audit. Those user files are intentionally omitted from the installer.
