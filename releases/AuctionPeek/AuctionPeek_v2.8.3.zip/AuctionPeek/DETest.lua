-- Isolated observations. Never reserve inventory or assign a receipt to a sale.
local _,AP=...
local D={}
AP.DETest=D
local active
local function snapshot()
  local bag=C_Container
  if not bag then return end
  local counts={}
  for b=0,(NUM_TOTAL_EQUIPPED_BAG_SLOTS or NUM_BAG_SLOTS or 4) do
    local slots=bag.GetContainerNumSlots(b)
    if type(slots)~="number" then return end
    for slot=1,slots do
      local info=bag.GetContainerItemInfo(b,slot)
      if info then
        local id,n=info.itemID,info.stackCount
        if not AP.MailValueReadable(id) or not AP.MailValueReadable(n) or type(id)~="number" or type(n)~="number" then return end
        counts[id]=(counts[id] or 0)+n
      end
    end
  end
  return counts
end
local function sourceCost(ch,id,held)
  local total,price=0,nil
  for _,lot in ipairs(ch.craftLedger and ch.craftLedger.lots or {}) do
    if lot.itemID==id and lot.left>0 then
      if lot.unknown or lot.estimate or not lot.parts or not lot.balance or lot.balance%lot.left~=0 then return end
      local unit=lot.balance/lot.left
      if price and price~=unit then return end
      total,price=total+lot.left,unit
    end
  end
  if total==held then return price end
end
-- Buy History can already contain the purchase before the craft ledger imports it.
-- A recent single-unit purchase is only a candidate for this diagnostic preview.
local function purchaseCost(ch,r,priorSources,previewUnresolved)
  if not r.input or (r.held and r.held~=1) then return end
  if r.status~="Bag and loot agree" then
    -- A fast auction posting can remove the just-disenchanted output before
    -- the eight-second bag verification runs. The recorded input loss and
    -- personal loot are still useful to *preview* a uniquely priced purchase,
    -- but must not be upgraded into a confirmed allocation or written to DB.
    if not previewUnresolved or r.status~="Unresolved" or r.held~=1
        or type(r.outputs)~="table" or not next(r.outputs) then return end
    for id,n in pairs(r.outputs) do
      if type(id)~="number" or type(n)~="number" or id<=0 or n<=0 then return end
    end
  end
  local buy
  for _,b in ipairs(ch.buys or {}) do
    if b.itemID==r.input and b.boughtAt and b.boughtAt<=r.at and r.at-b.boughtAt<=900 then
      if buy or b.quantity~=1 or b.priceEstimated or not b.price or b.price<=0 or not b.purchaseID then return end
      buy=b
    end
  end
  if not buy then return end
  -- v2.5.47: the read-only DE ledger does not consume an old gauntlet lot.
  -- Those old virtual lots can remain "left=1" after a verified DE, even
  -- when the actual pre-cast bag snapshot contains exactly ONE input item.
  -- A brand-new clean-inventory DE with a unique, verified purchase <=120s
  -- beforehand may use that fresh purchase as a candidate, without touching
  -- old lots or treating stale virtual leftovers as physical bag contents.
  local freshSingle = r.status=="Bag and loot agree" and r.held==1
    and type(ch.deAutoSinceV2546)=="number" and r.at>=ch.deAutoSinceV2546
    and r.at-buy.boughtAt>=0 and r.at-buy.boughtAt<=120
  for _,other in ipairs(ch.deTests or {}) do
    if other~=r and other.input==r.input and other.at>=buy.boughtAt and other.at<=r.at then return end
  end
  local ledger=ch.craftLedger
  for _,lot in ipairs(ledger and ledger.lots or {}) do
    if lot.itemID==r.input and lot.at<=r.at then
      if lot.purchase==buy.purchaseID then
        if lot.left~=1 or lot.balance~=buy.price then return end
      elseif lot.left>0 then
        -- Earlier DE observations can explain spent purchase lots that the
        -- read-only preview deliberately leaves in the inventory ledger.
        local spent=priorSources and lot.purchase and priorSources[lot.purchase]
        for _,other in ipairs(ch.deTests or {}) do
          if lot.purchase and other.purchaseSource==lot.purchase and other.at<r.at then spent=true;break end
        end
        if not spent and not freshSingle then return end
      end
    end
  end
  return buy.price,buy.purchaseID
end
local function finish()
  local a=active
  active=nil
  if not a or not a.row then return end
  local r=a.row
  local after=snapshot()
  r.status="Unresolved"
  if a.before and after then
    local input,losses=nil,0
    for id,n in pairs(a.before) do
      local lost=n-(after[id] or 0)
      if lost>0 then losses=losses+lost;input=id end
    end
    if losses==1 then
      r.input=input
      r.held=a.before[input]
      r.cost=sourceCost(a.ch,input,a.before[input])
    end
    local matched=next(a.loot)~=nil
    for id,n in pairs(a.loot) do
      if (after[id] or 0)-(a.before[id] or 0)~=n then matched=false end
    end
    for id,n in pairs(after) do
      if n>(a.before[id] or 0) and not a.loot[id] then matched=false end
    end
    if r.input and matched then r.status="Bag and loot agree" end
  end
  r.preexisting={}
  if a.before then
    for id in pairs(a.loot) do r.preexisting[id]=a.before[id] or 0 end
  end
  if not r.cost then r.cost,r.purchaseSource=purchaseCost(a.ch,r) end
  r.outputs=a.loot
  if a.refresh then a.refresh() end
end
function D.Cast(ch,event,unit,guid,spell,refresh)
  if not AP.MailValueReadable(unit) or not AP.MailValueReadable(guid) or not AP.MailValueReadable(spell)
      or unit~="player" or spell~=13262 or type(guid)~="string" then return end
  if event=="UNIT_SPELLCAST_START" then
    if active and active.guid==guid then return end
    finish()
    active={ch=ch,guid=guid,before=snapshot(),loot={},refresh=refresh}
  elseif event=="UNIT_SPELLCAST_SUCCEEDED" then
    for _,r in ipairs(ch.deTests or {}) do if r.guid==guid then return end end
    if not active or active.guid~=guid then finish();active={ch=ch,guid=guid,loot={},refresh=refresh} end
    local a=active
    a.row={guid=guid,at=time(),status="Awaiting loot"}
    ch.deTests=ch.deTests or {}
    table.insert(ch.deTests,1,a.row)
    while #ch.deTests>100 do table.remove(ch.deTests) end
    C_Timer.After(8,function() if active==a then finish() end end)
    refresh()
  elseif active and active.guid==guid and not active.row then active=nil end
end
function D.Loot(id,n)
  if active and id then active.loot[id]=(active.loot[id] or 0)+n end
end
function D.EndSession()
  finish()
end
local function name(id)
  return id and ((C_Item and C_Item.GetItemNameByID and C_Item.GetItemNameByID(id)) or ("Item #"..id)) or "Unknown input"
end
-- Cumulative rounding conserves every copper even if sales split unevenly.
function D.Share(cost,quantity,soldBefore,soldNow)
  if soldNow<=0 or soldBefore<0 or soldBefore+soldNow>quantity then return end
  return math.floor(cost*(soldBefore+soldNow)/quantity)-math.floor(cost*soldBefore/quantity)
end
-- Preview only. Even matching auction IDs identify a listing, not its bag lot.
-- Diagnostic only. A plausible listing is NOT proof that the newly
-- disenchanted units were allocated to it, particularly with mixed inventory.
-- Stop suggestions when the next disenchant produces the same output. A
-- subsequent auction cannot safely be attributed to this older session by
-- item and timestamp alone. This intentionally leaves delayed/mixed postings
-- unresolved instead of inventing a source or moving costs between sessions.
local function nextOutputSession(ch,r,id)
  local source=r.original or r
  local after
  for _,other in ipairs(ch.deTests or {}) do
    local produced=other.outputs and other.outputs[id]
    if other~=source and type(other.at)=="number" and other.at>r.at
        and type(produced)=="number" and produced>0 then
      if not after or other.at<after then after=other.at end
    end
  end
  return after
end
-- Same candidate discovery for both the expandable evidence and the compact
-- Flip-style DE Test summary. A candidate is NOT a confirmed cost transfer.
local function candidatePosts(ch,r,id)
  local posts=ch.craftLedger and ch.craftLedger.posts or {}
  local candidates={}
  local nextAt=nextOutputSession(ch,r,id)
  for key,p in pairs(posts) do
    if p.itemID==id and type(p.at)=="number" and p.at>=r.at
        and (not nextAt or p.at<nextAt) then
      candidates[#candidates+1]={key=key,p=p}
    end
  end
  table.sort(candidates,function(a,b)
    if a.p.at==b.p.at then return tostring(a.key)<tostring(b.key) end
    return a.p.at<b.p.at
  end)
  return candidates
end
-- Manual DE attestations are separate from the canonical inventory cost ledger.
-- These records identify which purchase and which complete output auction the
-- PLAYER says belong to a DE cast. They are reversible, scoped by cast GUID,
-- validated on every read, and never rewrite lot.parts, receipts, or Flip.
local function rawRecord(r) return r.original or r end
local function otherClaims(ch,r,kind,value)
  local src=rawRecord(r)
  for _,other in ipairs(ch.deTests or {}) do
    if other~=src and ((other.manualDE and other.manualDE[kind]==value)
        or (other.autoDE and not other.autoDE.disabled and other.autoDE[kind]==value)) then return true end
  end
  return false
end
local function validatedCost(ch,r)
  local src=rawRecord(r)
  local m=src.manualDE
  if type(m)~="table" or type(m.purchaseID)~="number"
      or type(m.cost)~="number" or type(src.at)~="number"
      or type(src.input)~="number" then return end
  if otherClaims(ch,r,"purchaseID",m.purchaseID) then return end
  for _,buy in ipairs(ch.buys or {}) do
    if buy.purchaseID==m.purchaseID and buy.itemID==src.input
        and buy.quantity==1 and type(buy.price)=="number"
        and buy.price==m.cost and buy.price>=0 and not buy.priceEstimated
        and type(buy.boughtAt)=="number" and buy.boughtAt<=src.at
        and src.at-buy.boughtAt<=900 then
      return buy
    end
  end
end
local function validatedAuction(ch,r)
  local src=rawRecord(r)
  local m=src.manualDE
  if type(m)~="table" or type(m.auctionID)~="string"
      or type(m.outputID)~="number" or type(m.quantity)~="number" then return end
  local n=src.outputs and src.outputs[m.outputID]
  if type(n)~="number" or n~=m.quantity or n<=0 then return end
  if otherClaims(ch,r,"auctionID",m.auctionID) then return end
  local posts=ch.craftLedger and ch.craftLedger.posts or {}
  local post=posts[m.auctionID]
  if not post or post.itemID~=m.outputID or post.quantity~=n then return end
  for _,candidate in ipairs(candidatePosts(ch,src,m.outputID)) do
    if tostring(candidate.key)==m.auctionID then return post end
  end
end
-- v2.5.46: AUTO evidence is independent of manual attestations and canonical
-- inventory lots. This intentionally declines mixed bags, ambiguous posts,
-- partial receipts, canceled postings, and preexisting identical output.
local AUTO_RULE=1
local function strictAutoCandidate(ch,r)
  if type(r)~="table" or type(r.at)~="number" or type(r.input)~="number"
      or type(r.guid)~="string" or r.status~="Bag and loot agree" or r.held~=1
      or type(r.preexisting)~="table" or type(r.outputs)~="table" then return end
  local outputID,quantity
  for id,n in pairs(r.outputs) do
    if type(id)~="number" or type(n)~="number" or n<=0 or n%1~=0 or outputID then return end
    outputID,quantity=id,n
  end
  if not outputID or r.preexisting[outputID]~=0 then return end
  -- An existing/manual decision takes precedence over the auto evaluator.
  if r.manualDE and (r.manualDE.purchaseID or r.manualDE.auctionID) then return end
  local cost,purchaseID=purchaseCost(ch,r,nil,false)
  if not cost or not purchaseID or cost<=0 then return end
  -- Require the purchase and cost candidate to agree with saved evidence.
  if r.purchaseSource and r.purchaseSource~=purchaseID then return end
  if r.cost and r.cost~=cost then return end
  if otherClaims(ch,r,"purchaseID",purchaseID) then return end
  local purchase
  for _,b in ipairs(ch.buys or {}) do
    if b.purchaseID==purchaseID and b.itemID==r.input
        and b.quantity==1 and b.price==cost and not b.priceEstimated then
      purchase=b;break
    end
  end
  if not purchase then return end
  -- No other DE output of the same item in the candidate time window.
  local candidates=candidatePosts(ch,r,outputID)
  if #candidates~=1 then return end
  local k,p=candidates[1].key,candidates[1].p
  local auctionID=tostring(k)
  if type(p.at)~="number" or p.at>r.at+600 or p.itemID~=outputID
      or type(p.quantity)~="number" or p.quantity~=quantity
      or p.ended or p.awaitingReturn or p.returnedUnits or p.remainderTo
      or p.filled and p.filled~=quantity
      or otherClaims(ch,r,"auctionID",auctionID) then return end
  -- Reject an intervening *recorded* same-output acquisition. History can't
  -- establish every possible bag movement; this remains read-only attribution.
  for _,b in ipairs(ch.buys or {}) do
    if b.itemID==outputID and type(b.boughtAt)=="number"
        and b.boughtAt>r.at and b.boughtAt<=p.at then return end
  end
  for _,other in ipairs(ch.deTests or {}) do
    if other~=r and type(other.at)=="number" and other.at>r.at and other.at<=p.at
        and other.outputs and other.outputs[outputID] then return end
  end
  local sale
  for _,row in ipairs(ch.sold or {}) do
    if row.auctionID and tostring(row.auctionID)==auctionID then
      if sale then return end
      sale=row
    end
  end
  if not sale or not sale.sold or sale.itemID~=outputID
      or not sale.receiptID or type(sale.verifiedNet)~="number"
      or sale.verifiedNet<0 or type(sale.receiptQty)~="number"
      or sale.receiptQty~=quantity or sale.receiptQuantityKnown==false
      or type(sale.quantity)=="number" and sale.quantity~=quantity then return end
  -- A single verified, full-stack receipt only. No partial split or second fill.
  if type(p.fills)=="table" then
    local count,filled=0,0
    for _,f in pairs(p.fills) do
      if type(f)=="table" and type(f.quantity)=="number" and f.quantity>0 then
        count,filled=count+1,filled+f.quantity
      end
    end
    if count>1 or (count==1 and filled~=quantity) then return end
  end
  for _,other in ipairs(ch.sold or {}) do
    if other~=sale and other.receiptID and other.receiptID==sale.receiptID then return end
  end
  return {purchaseID=purchaseID,cost=cost,auctionID=auctionID,
    outputID=outputID,quantity=quantity,receiptID=sale.receiptID,
    verifiedNet=sale.verifiedNet,profit=sale.verifiedNet-cost,rule=AUTO_RULE},purchase,p,sale
end
local function validatedAuto(ch,r)
  local src=rawRecord(r)
  local a=src.autoDE
  if type(a)~="table" or a.disabled or a.rule~=AUTO_RULE then return end
  local proof,purchase,post,sale=strictAutoCandidate(ch,src)
  if proof and proof.purchaseID==a.purchaseID and proof.cost==a.cost
      and proof.auctionID==a.auctionID and proof.outputID==a.outputID
      and proof.quantity==a.quantity and proof.receiptID==a.receiptID
      and proof.verifiedNet==a.verifiedNet then return proof,purchase,post,sale end
end
-- Runs on normal UI/event-driven refreshes, not via any AH polling or query.
-- Store only a reversible relationship, never a new receipt or cost lot.
function D.AutoEvaluate(ch)
  if not ch or not ch.deTests then return end
  -- Never silently backfill historical records on first install. New casts
  -- after this version is activated may acquire read-only auto links.
  if type(ch.deAutoSinceV2546)~="number" then ch.deAutoSinceV2546=time() end
  for i=#ch.deTests,1,-1 do
    local r=ch.deTests[i]
    if type(r)=="table" and type(r.at)=="number" and r.at>=ch.deAutoSinceV2546
        and type(r.guid)=="string" and not r.autoDE
        and not (r.manualDE and (r.manualDE.purchaseID or r.manualDE.auctionID)) then
      local proof=strictAutoCandidate(ch,r)
      if proof then
        proof.at=time()
        r.autoDE=proof
      end
    end
  end
end
function D.AutoUndo(ch,guid)
  for _,r in ipairs(ch.deTests or {}) do
    if r.guid==guid then
      if type(r.autoDE)=="table" and not r.autoDE.disabled then
        r.autoDE.disabled=true
        return true,"Auto DE link disabled; canonical costs untouched."
      end
      if type(r.autoDE)=="table" and r.autoDE.disabled then
        r.autoDE=nil
        return true,"Auto DE verification eligible again."
      end
      return false,"No automatic link exists."
    end
  end
  return false,"DE record not found."
end
local function findCast(ch,guid)
  if type(guid)~="string" then return end
  for _,r in ipairs(ch.deTests or {}) do if r.guid==guid then return r end end
end
-- Called ONLY from an explicit user-confirmation UI. Each assignment is
-- conservative and distinct; the user can revoke either one independently.
function D.ManualSet(ch,guid,kind,auctionID,revoke)
  local r=findCast(ch,guid)
  if not r then return false,"Disenchant cast no longer exists." end
  if kind~="cost" and kind~="auction" then return false,"Unknown confirmation type." end
  if revoke then
    if type(r.manualDE)=="table" then
      if kind=="cost" then
        r.manualDE.purchaseID=nil; r.manualDE.cost=nil; r.manualDE.costAt=nil
      else
        r.manualDE.auctionID=nil; r.manualDE.outputID=nil
        r.manualDE.quantity=nil; r.manualDE.auctionAt=nil
      end
    end
    return true,"Manual confirmation revoked; original accounting unchanged."
  end
  if kind=="cost" then
    if validatedCost(ch,r) then return false,"Purchase is already manually confirmed." end
    local possible
    for _,tracked in ipairs(D.Tracked(ch)) do
      if rawRecord(tracked)==r and tracked.purchaseSource
          and tracked.cost and tracked.input==r.input then possible=tracked;break end
    end
    if not possible or otherClaims(ch,r,"purchaseID",possible.purchaseSource) then
      return false,"Purchase source is missing, ambiguous, or already assigned to another DE." end
    local chosen
    for _,buy in ipairs(ch.buys or {}) do
      if buy.purchaseID==possible.purchaseSource and buy.itemID==r.input
          and buy.price==possible.cost and buy.quantity==1
          and not buy.priceEstimated then chosen=buy;break end
    end
    if not chosen then return false,"Purchase cost changed; refresh the evidence." end
    r.manualDE=r.manualDE or {}
    r.manualDE.purchaseID=chosen.purchaseID
    r.manualDE.cost=chosen.price
    r.manualDE.costAt=time()
    return true,"Purchase-to-DE relationship manually confirmed."
  end
  if type(auctionID)~="string" then return false,"Auction ID missing." end
  if otherClaims(ch,r,"auctionID",auctionID) then
    return false,"This auction is already linked to a different disenchant." end
  local posts=ch.craftLedger and ch.craftLedger.posts or {}
  local p=posts[auctionID]
  if not p or type(p.quantity)~="number" or p.quantity<=0 then
    return false,"Auction posting or quantity is missing." end
  local n=r.outputs and r.outputs[p.itemID]
  if type(n)~="number" or n<=0 or n~=p.quantity then
    return false,"Auction must contain exactly the DE output quantity. Partial/mixed stacks need a different workflow." end
  local found=false
  for _,entry in ipairs(candidatePosts(ch,r,p.itemID)) do
    if tostring(entry.key)==auctionID then found=true;break end
  end
  if not found then return false,"Auction is outside this disenchant's time window." end
  r.manualDE=r.manualDE or {}
  r.manualDE.auctionID=auctionID
  r.manualDE.outputID=p.itemID
  r.manualDE.quantity=n
  r.manualDE.auctionAt=time()
  return true,"Output-to-auction relationship manually confirmed; inventory lot ledger unchanged."
end
function D.ManualStatus(ch,guid,kind,auctionID)
  local r=findCast(ch,guid)
  if not r then return false end
  if kind=="cost" then return validatedCost(ch,r)~=nil end
  if kind=="auction" then
    local p=validatedAuction(ch,r)
    return p~=nil and r.manualDE.auctionID==tostring(auctionID)
  end
  return false
end
local function salePreview(ch,r,id,quantity,money,lines,sales,receipts,matches)
  local candidates=candidatePosts(ch,r,id)
  local confirmed=validatedAuction(ch,r)
  local autoProof=validatedAuto(ch,r)
  local mixed=not r.preexisting or r.preexisting[id]~=0
  for _,other in ipairs(ch.deTests or {}) do
    if other~=(r.original or r) and other.outputs and other.outputs[id] then mixed=true end
  end
  local used=0
  for _,entry in ipairs(candidates) do
    local p=entry.p
    local sale=sales[tostring(entry.key)]
    local n=p.filled or (p.gross and p.quantity)
    if type(n)~="number" then n=nil end
    local label,confidence,why
    -- A sold auction that the same saved listing marks canceled is a genuine
    -- lifecycle contradiction. Flag the RECORD, not the entire DE accounting.
    local contradiction=(sale and sale.sold and p.ended=="canceled"
      and not (n and p.quantity and n<p.quantity and (p.fillLimit or p.returnedUnits))) or
      (n and type(p.quantity)=="number" and (n<0 or n>p.quantity))
    if n and n>0 then
      local share
      if not mixed and r.cost and r.status=="Bag and loot agree" then
        share=D.Share(r.cost,quantity,used,n)
      end
      label=n.." sold   "..(share and ("Test cost "..(share==0 and "0c" or money(share))) or "Allocation unresolved")
      used=used+n
    elseif sale and sale.receiptID then label="Payment linked   "..sale.receiptID
    elseif sale and p.ended then label="Sale recorded / listing "..p.ended.." / receipt unlinked"
    elseif sale then label="Sale recorded / receipt unlinked"
    elseif p.ended then label="Listing "..p.ended
    elseif p.soldAt then label="Awaiting payment"
    else label="Posted" end
    if contradiction then
      confidence="error"
      why="Conflicting stored auction events: this auction ID is marked both sold and canceled, or has impossible filled quantity. Review the auction lifecycle. This does not prove duplicate gold."
    else
      confidence="question"
      why=mixed and "Possible listing matches the item and time, but old and newly disenchanted inventory were mixed. Output lot attribution is not confirmed." or
        "Possible auction based on item and time. This diagnostic has not established a confirmed output-to-auction cost assignment."
    end
    local matched=confirmed==p and r.manualDE and r.manualDE.auctionID==tostring(entry.key)
    local autoMatched=autoProof and autoProof.auctionID==tostring(entry.key)
    local display=(autoMatched and "Auto-linked auction #" or matched and "Manually linked auction #" or "Possible output auction #")..entry.key.."   "..label
    lines[#lines+1]={detail=display,
      deConfidence=(autoMatched or matched) and not contradiction and "ok" or confidence,
      deReason=autoMatched and "Auto-linked by strict single-output, clean-inventory, unique-auction and verified full-receipt checks. Read-only; click the Auto evidence line to disable."
        or matched and "Player manually confirmed that this auction used this DE output. Canonical inventory lots were NOT rewritten. Click again to undo." or why,
      deAction=autoMatched and nil or "auction",deGuid=rawRecord(r).guid,deAuctionID=tostring(entry.key),
      deManualConfirmed=matched}
    if sale and sale.receiptID and type(sale.verifiedNet)=="number" then
      lines[#lines+1]={detail="Payment recorded for auction #"..entry.key.."   "..money(sale.verifiedNet).." net",
        deConfidence="ok",deReason="The auction has a reconciled mail receipt. Its connection to this particular disenchant remains only a candidate."}
    end
    if p.fills and n then
      local keys,total={},0
      for key,fill in pairs(p.fills) do
        if type(fill.quantity)=="number" and fill.quantity>0 then
          keys[#keys+1]=key
          total=total+fill.quantity
        end
      end
      table.sort(keys,function(a,b)
        return (tonumber(tostring(a):match("(%d+)$")) or 0)<(tonumber(tostring(b):match("(%d+)$")) or 0)
      end)
      local offset=used-n
      for _,key in ipairs(keys) do
        local fill=p.fills[key]
        local cost
        if total==n and not mixed and r.status=="Bag and loot agree" and r.cost then
          cost=D.Share(r.cost,quantity,offset,fill.quantity)
        end
        -- A receipt is verified once it belongs to the confirmed auction;
        -- its inventory cost still remains separate from the accounting ledger.
        local paidFill=(autoMatched or matched) and sale and sale.receiptID==key
          and type(sale.verifiedNet)=="number" and total==n
        lines[#lines+1]={detail=tostring(key).."   "..fill.quantity.." sold"..
          (cost and ("   Test cost "..money(cost)) or ""),
          deConfidence=paidFill and "ok" or "question",
          deReason=paidFill and "Payment is verified for the linked auction. The cost calculation is a separate, read-only DE attribution."
            or "Observed auction fill. Attribution to this DE source is not confirmed; the test cost is diagnostic only."}
        offset=offset+fill.quantity
      end
    end
    if sale and not sale.receiptID and not n and matches then
      local anchor=sale.endTime or sale.soldAt
      for _,receipt in ipairs(receipts) do
        local qty=receipt.receiptQty
        local partial=p.quantity and sale.quantity and sale.quantity>0 and sale.quantity<p.quantity
          and sale.buyout and p.totalPrice and sale.buyout==p.totalPrice*sale.quantity
          and receipt.receiptQuantityKnown and qty and qty>0 and qty<=p.quantity
          and receipt.verifiedGross==qty*p.totalPrice and receipt.name==sale.name
        if anchor and receipt.observedAt>=anchor-5 and receipt.observedAt-anchor<=86400
            and (not receipt.itemID or receipt.itemID==sale.itemID)
            and (partial or matches(sale,{name=receipt.name,quantity=receipt.receiptQty,quantityKnown=receipt.receiptQuantityKnown,
              gross=receipt.verifiedGross,observedAt=receipt.observedAt})) then
          lines[#lines+1]={detail="Possible receipt "..receipt.receiptID.."   "..money(receipt.verifiedNet).." collected ("..tostring(qty or "?").." units, unlinked)",
            deConfidence="question",deReason="Candidate receipt matches some auction evidence, but has not been linked to the auction ID. Do not treat it as verified DE profit."}
        end
      end
    end
  end
end
-- v2.5.50: DE Test is an AH-purchase workflow, not a lifetime disenchant log.
-- Only display DE observations backed by recorded, confirmed AH purchases of
-- the *input* item. This is a read-only VIEW filter: never remove observations,
-- consume craft ledger lots, invent purchase IDs, or assign costs to casts.
local AH_PREVIEW_WINDOW=900 -- mirrors purchaseCost's 15-minute evidence window
local function confirmedAHInputBuy(b)
  if type(b)~="table" or b.vendor or not b.purchase or b.priceEstimated
      or type(b.itemID)~="number" or type(b.purchaseID)~="number"
      or type(b.boughtAt)~="number" or type(b.quantity)~="number"
      or b.quantity<1 then return false end
  -- Vendor buys have a separate vendor flag/source; historical player-reported
  -- estimates are not proof of an actual AH transaction.
  return b.auctionID~=nil or b.commodity==true or
    (type(b.source)=="string" and b.source:match("^Confirmed.*purchase")~=nil)
end
local function ahPurchaseWindow(b,r)
  return type(r.input)=="number" and type(r.at)=="number"
    and b.itemID==r.input and b.boughtAt<=r.at
    and r.at-b.boughtAt<=AH_PREVIEW_WINDOW
end
local function purchasedDEVisibility(ch,tests)
  local eligible,byID,byPurchase,remaining,reserved={},{},{},{},{}
  for _,b in ipairs(ch.buys or {}) do
    if confirmedAHInputBuy(b) then
      local group=byID[b.itemID]
      if not group then group={};byID[b.itemID]=group end
      group[#group+1]=b
      byPurchase[b.purchaseID]=b
      remaining[b]=b.quantity
    end
  end
  for _,group in pairs(byID) do
    table.sort(group,function(a,b)
      if a.boughtAt==b.boughtAt then return a.purchaseID<b.purchaseID end
      return a.boughtAt<b.boughtAt
    end)
  end
  -- Reserve explicitly linked real AH purchases first. Otherwise an earlier
  -- ambiguous cast could claim the only preview slot for a later proven cast.
  for _,r in ipairs(tests) do
    local ids={r.manualDE and r.manualDE.purchaseID,
      r.autoDE and not r.autoDE.disabled and r.autoDE.purchaseID,r.purchaseSource}
    for _,id in pairs(ids) do
      local b=byPurchase[id]
      if b and ahPurchaseWindow(b,r) then
        if not reserved[id] then reserved[id]=r end
        break
      end
    end
  end
  -- Oldest-first, at most one displayed DE per confirmed AH input unit.
  -- A possible match is visibility evidence only; it is NOT cost attribution.
  for i=#tests,1,-1 do
    local r=tests[i]
    local linked
    local ids={r.manualDE and r.manualDE.purchaseID,
      r.autoDE and not r.autoDE.disabled and r.autoDE.purchaseID,r.purchaseSource}
    for _,id in pairs(ids) do
      local b=byPurchase[id]
      if b and reserved[id]==r and ahPurchaseWindow(b,r) and remaining[b]>0 then
        linked=b;break
      end
    end
    if not linked and type(r.input)=="number" and type(r.at)=="number" then
      for _,b in ipairs(byID[r.input] or {}) do
        if remaining[b]>0 and not reserved[b.purchaseID]
            and ahPurchaseWindow(b,r) then linked=b;break end
      end
    end
    if linked then
      remaining[linked]=remaining[linked]-1
      eligible[r]=true
    end
  end
  return eligible
end


-- v2.5.51: confirm a UNIT COST from a complete, same-price AH purchase pool.
-- This does NOT identify which physical piece came from which purchase ID:
-- do not persist a purchaseSource, move craft lots, create Flip entries, or
-- calculate a verified DE sale profit from a pool price alone.
-- Require bag-confirmed consecutive DEs with an exact 3->2->1 (etc.) input
-- sequence and exactly that many recent, confirmed AH input units.
local function verifiedAHPurchasePools(ch,tests,eligible)
  local proof,usedPurchaseIDs={},{}
  local chronological={}
  for _,r in ipairs(tests) do
    if type(r)=="table" and type(r.at)=="number" and type(r.input)=="number" then
      chronological[#chronological+1]=r
    end
  end
  table.sort(chronological,function(a,b)
    if a.at==b.at then return tostring(a.guid or "")<tostring(b.guid or "") end
    return a.at<b.at
  end)
  local buysByItem={}
  for _,b in ipairs(ch.buys or {}) do
    if confirmedAHInputBuy(b) then
      local group=buysByItem[b.itemID] or {}
      group[#group+1]=b
      buysByItem[b.itemID]=group
    end
  end
  local function cleanCast(r)
    return eligible[r] and r.status=="Bag and loot agree"
      and type(r.held)=="number" and r.held>=1 and r.held%1==0
      and type(r.outputs)=="table" and next(r.outputs)~=nil
      and not r.purchaseSource and not (r.manualDE and r.manualDE.purchaseID)
      and not (r.autoDE and not r.autoDE.disabled)
  end
  local function validUnitPrice(b)
    return type(b.price)=="number" and b.price>0 and b.price%1==0
      and not b.priceEstimated and b.quantity==1
      and not usedPurchaseIDs[b.purchaseID]
  end
  for i,first in ipairs(chronological) do
    -- Single-item matches already use existing strict proof logic. Only a
    -- multi-item, same-price input pool needs this separate cost-only path.
    if not proof[first] and cleanCast(first) and first.held>=2 and first.held<=40 then
      local pool,unitPrice,earliest={},nil,nil
      local total=0
      local invalid=false
      for _,b in ipairs(buysByItem[first.input] or {}) do
        if ahPurchaseWindow(b,first) then
          -- An in-window uncertain buy can contaminate this pool. Do not
          -- silently ignore a different-priced, estimated or bulk purchase.
          if not validUnitPrice(b) or (unitPrice and b.price~=unitPrice) then
            invalid=true;break
          end
          unitPrice=unitPrice or b.price
          earliest=math.min(earliest or b.boughtAt,b.boughtAt)
          pool[#pool+1]=b
          total=total+1
        end
      end
      if not invalid and unitPrice and total==first.held then
        -- A previous recorded DE after these purchases means the candidate
        -- pool may have been partially consumed before our first snapshot.
        for k=1,i-1 do
          local older=chronological[k]
          if older.input==first.input and older.at>=earliest then invalid=true;break end
        end
      else
        invalid=true
      end
      if not invalid then
        -- Never let an unseen intervening purchase or an inconsistent bag
        -- snapshot be covered by the same proof. Future casts are verified
        -- only while the actual held count drops by exactly one each time.
        local matched={first}
        local previous=first
        for j=i+1,#chronological do
          local later=chronological[j]
          if later.input==first.input then
            if #matched>=total or later.at-first.at>AH_PREVIEW_WINDOW then break end
            local extra=false
            for _,b in ipairs(buysByItem[first.input] or {}) do
              if b.boughtAt>previous.at and b.boughtAt<=later.at then extra=true;break end
            end
            if extra or not cleanCast(later) or later.held~=previous.held-1 then break end
            matched[#matched+1]=later
            previous=later
          end
        end
        -- An earlier same-item cast between the buys and this first cast
        -- is rejected above. All pool slots are reserved as a set; no later
        -- group can reuse these purchase IDs even if only some DEs occurred.
        local ids={}
        table.sort(pool,function(a,b)
          if a.boughtAt==b.boughtAt then return a.purchaseID<b.purchaseID end
          return a.boughtAt<b.boughtAt
        end)
        for _,b in ipairs(pool) do ids[#ids+1]=b.purchaseID end
        local details={cost=unitPrice,quantity=total,purchaseIDs=ids,
          validatedCasts=#matched,firstAt=first.at}
        local safe=true
        for _,r in ipairs(matched) do
          if r.cost and r.cost~=unitPrice then safe=false;break end
        end
        if safe then
          for _,b in ipairs(pool) do usedPurchaseIDs[b.purchaseID]=true end
          for _,r in ipairs(matched) do proof[r]=details end
        end
      end
    end
  end
  return proof
end


-- v2.5.52: a READ-ONLY group preview for split commodity payments.
-- Modern AH snapshots can identify individual fills, while an aggregate mail
-- receipt can contain several fills and carry no auction ID. Neither a matching
-- item name nor matching proceeds proves which material inventory was sold.
-- Therefore this NEVER edits post IDs, inventory lots, sale receipts or profit.
-- A strict, fully observed equal-cost AH purchase pool and a zero-preexisting
-- first output are required before showing the possible combined payment.
function D.SharedBatchPreview(ch,entry,pool,outputID)
  local source=entry and (entry.original or entry)
  if not source or not pool or pool.validatedCasts~=pool.quantity
      or type(pool.cost)~="number" or pool.cost<=0
      or type(pool.firstAt)~="number" or type(outputID)~="number" then return end
  local casts={}
  local n,firstOutput,latest=0,nil,0
  for _,r in ipairs(ch.deTests or {}) do
    if r.input==source.input and type(r.at)=="number"
        and r.at>=pool.firstAt and r.at-pool.firstAt<=900 then
      if r.status~="Bag and loot agree" or type(r.held)~="number"
          or r.held<=0 or type(r.outputs)~="table" then return end
      casts[#casts+1]=r
      if type(r.outputs[outputID])=="number" and r.outputs[outputID]>0 then
        n=n+r.outputs[outputID]
        if not firstOutput or r.at<firstOutput.at then firstOutput=r end
      end
      latest=math.max(latest,r.at)
    end
  end
  if #casts~=pool.quantity or not firstOutput or n<1
      or not firstOutput.preexisting or firstOutput.preexisting[outputID]~=0 then return end
  table.sort(casts,function(a,b) return a.at<b.at end)
  for i,r in ipairs(casts) do
    if r.held~=pool.quantity-i+1 then return end
  end
  -- Do not include a receipt collected after another DE generated the same
  -- material; that would make origin attribution even less defensible.
  local nextOutput=nil
  for _,r in ipairs(ch.deTests or {}) do
    if type(r.at)=="number" and r.at>latest
        and r.outputs and type(r.outputs[outputID])=="number"
        and r.outputs[outputID]>0 then
      nextOutput=math.min(nextOutput or r.at,r.at)
    end
  end
  local groups={}
  local seen={}
  local outputName=name(outputID):lower()
  for _,sale in ipairs(ch.sold or {}) do
    local id=sale.receiptID
    local q=sale.receiptQty
    local observed=sale.observedAt
    local gross=sale.verifiedGross
    local fee=sale.verifiedCut
    local deposit=sale.verifiedDeposit
    local net=sale.verifiedNet
    if type(id)=="string" and not seen[id] and sale.receiptQuantityKnown
        and type(q)=="number" and q>=1 and q%1==0
        and type(observed)=="number" and observed>=latest and observed-latest<=14400
        and (not nextOutput or observed<nextOutput)
        and type(gross)=="number" and gross>0 and gross%q==0
        and type(fee)=="number" and type(deposit)=="number" and type(net)=="number"
        and gross-fee+deposit==net
        and (sale.itemID==nil or sale.itemID==outputID)
        and type(sale.name)=="string" and sale.name:lower()==outputName then
      -- Preserve receipt identity even if the AH generated several per-fill IDs.
      seen[id]=true
      local unit=gross/q
      local g=groups[unit] or {unit=unit,qty=0,net=0,gross=0,receipts={}}
      g.qty,g.net,g.gross=g.qty+q,g.net+net,g.gross+gross
      g.receipts[#g.receipts+1]=id
      groups[unit]=g
    end
  end
  local answer,count=nil,0
  for _,g in pairs(groups) do
    if g.qty==n then
      answer=g
      count=count+1
    end
  end
  if count~=1 then return end
  table.sort(answer.receipts)
  answer.outputQty=n
  answer.inputCasts=0
  for _,r in ipairs(casts) do
    if type(r.outputs[outputID])=="number" and r.outputs[outputID]>0 then
      answer.inputCasts=answer.inputCasts+1
    end
  end
  answer.inputCost=pool.cost*answer.inputCasts
  answer.previewProfit=answer.net-answer.inputCost
  answer.firstCastGuid=firstOutput.guid
  answer.castGUIDs={}
  for _,cast in ipairs(casts) do
    if type(cast.outputs[outputID])=="number" and cast.outputs[outputID]>0 then
      if type(cast.guid)~="string" or cast.guid=="" then return end
      answer.castGUIDs[#answer.castGUIDs+1]=cast.guid
    end
  end
  table.sort(answer.castGUIDs)
  return answer
end

-- v2.5.53: source-checked, player-confirmed GROUP settlement evidence.
-- A mail receipt proves a payment, not a particular bag lot or auction ID.
-- This store is independent of craftLedger.posts/lots, ch.sold and Flip. It
-- may be revoked; no receipt or purchase is ever rewritten by this workflow.
local function batchKey(r,pool,outputID)
  return tostring(pool.firstAt)..":"..tostring(r.input)..":"..tostring(outputID)
end
local function sameArray(a,b)
  if type(a)~="table" or type(b)~="table" or #a~=#b then return false end
  for i,v in ipairs(a) do if v~=b[i] then return false end end
  return true
end
local function proofMatchesSaved(record,r,pool,outputID,batch)
  return type(record)=="table" and record.rule==1 and not record.disabled
    and record.firstAt==pool.firstAt and record.input==r.input
    and record.outputID==outputID and record.outputQty==batch.outputQty
    and record.inputCost==batch.inputCost and record.net==batch.net
    and record.gross==batch.gross and record.unit==batch.unit
    and sameArray(record.receipts,batch.receipts)
    and sameArray(record.casts,batch.castGUIDs)
    and sameArray(record.purchases,pool.purchaseIDs)
end
local function receiptConflict(ch,key,batch)
  local selected={}
  for _,receiptID in ipairs(batch.receipts) do selected[receiptID]=true end
  for otherKey,record in pairs(ch.deBatchLinks or {}) do
    if otherKey~=key and type(record)=="table" and not record.disabled
        and type(record.receipts)=="table" then
      for _,id in ipairs(record.receipts) do if selected[id] then return true end end
    end
  end
  return false
end
-- Rechecks every condition every time a confirmation is displayed. Stale
-- confirmations cease to count if receipt quantities/prices/casts change.
function D.BatchEvidence(ch,r,pool,outputID,batch)
  if not pool or not batch then return end
  local key=batchKey(r,pool,outputID)
  local record=ch.deBatchLinks and ch.deBatchLinks[key]
  if receiptConflict(ch,key,batch) then return nil,key,"Receipt claimed by another DE batch" end
  if proofMatchesSaved(record,r,pool,outputID,batch) then return record,key end
  if record and not record.disabled then return nil,key,"Historical confirmation no longer matches current evidence" end
  return nil,key
end
-- v2.5.55: cross-ledger receipt claims. Only CURRENTLY VALID verified
-- player-confirmed batches are excluded from Flip review. Inactive/stale
-- confirmations do not silently suppress receipts; the user can review them.
-- Recompute the same source + output + mail evidence as the DE display.
function D.ConfirmedReceiptClaims(ch,tracked)
  local claims={}
  if type(ch)~="table" or type(ch.deBatchLinks)~="table" then return claims end
  for _,entry in ipairs(tracked or D.Tracked(ch)) do
    if entry.poolAHCost and type(entry.outputs)=="table" then
      for outputID,qty in pairs(entry.outputs) do
        if type(outputID)=="number" and type(qty)=="number" and qty>0 then
          local batch=D.SharedBatchPreview(ch,entry,entry.poolAHCost,outputID)
          if batch then
            local saved,key=D.BatchEvidence(ch,entry,entry.poolAHCost,outputID,batch)
            if saved then
              for _,receiptID in ipairs(batch.receipts) do
                claims[receiptID]=key
              end
            end
          end
        end
      end
    end
  end
  return claims
end

-- v2.5.54: build an explicit, fresh evidence review for the confirmation
-- dialog. Never substitute a generic explanation for real source records.
-- This is presentation-only: it does not link historical auction IDs.
function D.BatchReview(ch,guid,outputID)
  if type(guid)~="string" or type(outputID)~="number" then
    return nil,"Missing cast or output identity" end
  local source=findCast(ch,guid)
  if not source then return nil,"Disenchant observation is missing" end
  for _,entry in ipairs(D.Tracked(ch)) do
    if rawRecord(entry)==source and entry.poolAHCost then
      local pool=entry.poolAHCost
      local batch=D.SharedBatchPreview(ch,entry,pool,outputID)
      if not batch then return nil,"Current purchases, outputs and receipts no longer support one unique batch" end
      local included=false
      for _,id in ipairs(batch.castGUIDs) do
        if id==guid then included=true;break end
      end
      if not included then return nil,"This disenchant is not a member of that output batch" end
      local linked,_,reason=D.BatchEvidence(ch,entry,pool,outputID,batch)
      if reason then return nil,reason end
      local result={inputName=name(entry.input),outputName=name(outputID),
        outputQty=batch.outputQty,unitPrice=batch.unit,inputUnitCost=pool.cost,
        inputCost=batch.inputCost,net=batch.net,gross=batch.gross,
        profit=batch.previewProfit,linked=linked~=nil,
        purchases={},casts={},receipts={}}
      for _,purchaseID in ipairs(pool.purchaseIDs) do
        local found
        for _,b in ipairs(ch.buys or {}) do
          if b.purchaseID==purchaseID and b.itemID==entry.input
              and b.quantity==1 and b.price==pool.cost and not b.priceEstimated then
            found={id=purchaseID,quantity=1,price=b.price,at=b.boughtAt}
            break
          end
        end
        if not found then return nil,"An original AH purchase could no longer be verified" end
        result.purchases[#result.purchases+1]=found
      end
      local selected={}
      for _,castID in ipairs(batch.castGUIDs) do selected[castID]=true end
      for _,r in ipairs(ch.deTests or {}) do
        if selected[r.guid] then
          result.casts[#result.casts+1]={at=r.at,qty=r.outputs and r.outputs[outputID],
            held=r.held,status=r.status}
          selected[r.guid]=nil
        end
      end
      for id in pairs(selected) do return nil,"A contributing disenchant is missing" end
      table.sort(result.casts,function(a,b) return a.at<b.at end)
      for _,receiptID in ipairs(batch.receipts) do
        local found
        for _,sale in ipairs(ch.sold or {}) do
          local qty=sale.receiptQty
          local gross=sale.verifiedGross
          local fee=sale.verifiedCut
          local deposit=sale.verifiedDeposit
          local net=sale.verifiedNet
          if sale.receiptID==receiptID and sale.receiptQuantityKnown
              and (sale.itemID==nil or sale.itemID==outputID)
              and type(sale.name)=="string" and sale.name:lower()==name(outputID):lower()
              and type(qty)=="number" and qty>0
              and type(gross)=="number" and gross/qty==batch.unit
              and type(fee)=="number" and type(deposit)=="number"
              and type(net)=="number" and gross-fee+deposit==net then
            found={id=receiptID,qty=qty,gross=gross,fee=fee,
              deposit=deposit,net=net,at=sale.observedAt}
            break
          end
        end
        if not found then return nil,"A receipt could no longer be verified: "..receiptID end
        result.receipts[#result.receipts+1]=found
      end
      return result
    end
  end
  return nil,"No complete verified AH-purchase pool for this disenchant"
end

function D.BatchConfirm(ch,guid,outputID,revoke)
  if type(guid)~="string" or type(outputID)~="number" then
    return false,"Missing DE cast or material identity" end
  local source=findCast(ch,guid)
  if not source then return false,"The original DE observation was not found" end
  local tracked=D.Tracked(ch)
  for _,entry in ipairs(tracked) do
    local raw=rawRecord(entry)
    if raw==source and entry.poolAHCost then
      local pool=entry.poolAHCost
      local batch=D.SharedBatchPreview(ch,entry,pool,outputID)
      if not batch then return false,"Shared batch is no longer uniquely supported by purchase and receipt evidence" end
      local included=false
      for _,id in ipairs(batch.castGUIDs) do if id==guid then included=true;break end end
      if not included then return false,"This DE did not produce that material" end
      local record,key,reason=D.BatchEvidence(ch,entry,pool,outputID,batch)
      if revoke then
        if not record then return false,reason or "No verified batch confirmation to revoke" end
        ch.deBatchLinks[key].disabled=true
        return true,"Shared DE batch confirmation revoked; all original receipts preserved"
      end
      if record then return false,"This DE batch is already confirmed" end
      if reason then return false,reason end
      ch.deBatchLinks=ch.deBatchLinks or {}
      ch.deBatchLinks[key]={rule=1,firstAt=pool.firstAt,input=entry.input,
        outputID=outputID,outputQty=batch.outputQty,
        inputCost=batch.inputCost,net=batch.net,gross=batch.gross,unit=batch.unit,
        receipts={unpack(batch.receipts)},casts={unpack(batch.castGUIDs)},
        purchases={unpack(pool.purchaseIDs)},confirmedAt=time()}
      return true,"Shared DE batch confirmed (read-only to auction and cost ledgers)"
    end
  end
  return false,"This record has no complete verified AH purchase pool"
end

function D.Tracked(ch,skipAuto)
  if not skipAuto then D.AutoEvaluate(ch) end
  local tracked,priorSources={},{}
  local tests=ch.deTests or {}
  local purchased=purchasedDEVisibility(ch,tests)
  local poolProofs=verifiedAHPurchasePools(ch,tests,purchased)
  for i=#tests,1,-1 do
    local r=tests[i]
    local entry=r
    if r.purchaseSource then priorSources[r.purchaseSource]=true end
    local autoProof=validatedAuto(ch,r)
    if autoProof and (r.cost~=autoProof.cost or r.purchaseSource~=autoProof.purchaseID) then
      local preview={}
      for k,v in pairs(r) do preview[k]=v end
      preview.cost,preview.purchaseSource,preview.original=autoProof.cost,autoProof.purchaseID,r
      entry=preview
      priorSources[autoProof.purchaseID]=true
    end
    local confirmedPurchase=validatedCost(ch,r)
    if not autoProof and confirmedPurchase and (r.cost~=confirmedPurchase.price or r.purchaseSource~=confirmedPurchase.purchaseID) then
      local preview={}
      for k,v in pairs(r) do preview[k]=v end
      preview.cost,preview.purchaseSource,preview.original=confirmedPurchase.price,confirmedPurchase.purchaseID,r
      entry=preview
      priorSources[confirmedPurchase.purchaseID]=true
    elseif not autoProof and not r.cost then
      -- Display-only: never persist an unresolved candidate into the ledger.
      local cost,source=purchaseCost(ch,r,priorSources,true)
      if cost then
        local preview={}
        for k,v in pairs(r) do preview[k]=v end
        preview.cost,preview.purchaseSource,preview.original=cost,source,r
        entry=preview
        priorSources[source]=true
      end
    end
    local pool=poolProofs[r]
    if pool and not entry.purchaseSource and (not entry.cost or entry.cost==pool.cost) then
      -- Read-only preview with a verified shared unit cost. Deliberately no
      -- purchaseSource: individual purchase ID attribution remains unknown.
      if entry==r then
        local preview={}
        for k,v in pairs(r) do preview[k]=v end
        preview.original=r
        entry=preview
      end
      entry.cost=pool.cost
      entry.poolAHCost=pool
    end
    -- Show every AH-purchase-supported DE even when the precise purchase ID
    -- and acquisition cost remain unresolved (e.g. three identical gauntlets).
    -- Unrelated looted/crafted DE observations stay saved but out of this view.
    if purchased[r] then tracked[#tracked+1]=entry end
  end
  return tracked
end
-- Project strictly revalidated Auto DE results into Flip, never into saved
-- inventory, sale or purchase records. Return the exact casts represented.
function D.ProjectFlip(ch,flips,sales,tracked)
  local moved,visible={},{}
  for _,sale in ipairs(sales or {}) do visible[tostring(sale.auctionID)]=sale end
  local batchClaims=D.ConfirmedReceiptClaims(ch,tracked)
  for _,r in ipairs(tracked or {}) do
    local proof,purchase,post,sale=validatedAuto(ch,r)
    if proof and visible[proof.auctionID]==sale and not batchClaims[proof.receiptID] then
      local gross,cut,deposit=sale.verifiedGross,sale.verifiedCut,sale.verifiedDeposit
      -- Use Flip's existing after-cut convention, excluding returned deposits.
      if type(gross)=="number" and type(cut)=="number" and type(deposit)=="number"
          and gross>=0 and cut>=0 and cut<=gross and deposit>=0
          and gross-cut+deposit==proof.verifiedNet then
        local existing,conflict
        for i,row in ipairs(flips) do
          if tostring(row.auctionID)==proof.auctionID then
            if existing or row.craft or row.quantity~=proof.quantity or not row.soldCost
                or (not row.soldCost.unknown and not row.soldCost.estimate and row.soldCost.cost~=proof.cost)
                or row.net~=nil and row.net~=gross-cut then conflict=true end
            existing=i
          elseif row.receiptID==proof.receiptID then conflict=true
          else
            for _,id in ipairs(row.recoveredReceipts or {}) do
              if id==proof.receiptID then conflict=true end
            end
          end
        end
        if not conflict then
          local row={}
          for k,v in pairs(sale) do row[k]=v end
          row.quantity,row.net=proof.quantity,gross-cut
          row.soldCost={cost=proof.cost,note="Auto DE: verified input purchase #"..proof.purchaseID.."; output auction and full receipt revalidated. Display only; inventory ledger unchanged."}
          local profit=row.net-proof.cost
          row.profitText=(profit<0 and "-" or profit>0 and "+" or "")..(profit==0 and "0c" or AP.Money(math.abs(profit)))
          row.deAutoFlip=true
          row.deAction="auto"
          row.deGuid=rawRecord(r).guid
          row.deInputID=r.input
          row.deAutoPurchaseID=proof.purchaseID
          row.deAuctionID=proof.auctionID
          row.deAutoDetail="Auto DE: "..name(r.input).." -> "..proof.quantity.."x "..name(proof.outputID).."; purchase #"..proof.purchaseID..", auction #"..proof.auctionID..", receipt "..proof.receiptID
          if existing then flips[existing]=row else flips[#flips+1]=row end
          moved[rawRecord(r)]=true
        end
      end
    end
  end
  return moved
end

-- UI-only fold state is supplied by AuctionPeek.lua; it is never stored in SavedVariables.
-- Each badge is a claim about the specific displayed fact, not an automatic
-- assertion that the complete DE-to-auction transaction is verified.
function D.Lines(ch,money,matches,tracked,expanded)
  local lines,sales,receipts={},{},{}
  for _,sale in ipairs(ch.sold or {}) do
    if sale.sold and sale.auctionID then sales[tostring(sale.auctionID)]=sale
    elseif sale.mailOnly and sale.receiptID and sale.verifiedNet and sale.observedAt then receipts[#receipts+1]=sale end
  end
  tracked=tracked or D.Tracked(ch)
  for i=#tracked,1,-1 do
    local r=tracked[i]
    local key=r.guid or (tostring(r.at)..":"..tostring(r.input)..":"..tostring(i))
    local ids,outputLabels={},{}
    for id in pairs(r.outputs or {}) do if type(id)=="number" then ids[#ids+1]=id end end
    table.sort(ids)
    for _,id in ipairs(ids) do
      local n=tonumber(r.outputs[id])
      if n and n>0 then outputLabels[#outputLabels+1]=n.."x "..name(id) end
    end
    local outputs=#outputLabels>0 and table.concat(outputLabels,", ") or "Output not confirmed"
    local open=expanded==nil or expanded[key]==true
    local outputID=(#ids==1 and ids[1]) or nil
    local candidateID,verifiedNet,candidateCount=nil,nil,0
    local allAuctionIDs={}
    for _,id in ipairs(ids) do
      if tonumber(r.outputs[id]) and tonumber(r.outputs[id])>0 then
        for _,candidate in ipairs(candidatePosts(ch,r,id)) do
          candidateCount=candidateCount+1
          allAuctionIDs[#allAuctionIDs+1]=tostring(candidate.key)
          if candidateCount==1 then
            candidateID=tostring(candidate.key)
            local sale=sales[candidateID]
            if sale and sale.receiptID and type(sale.verifiedNet)=="number"
                and sale.verifiedNet>=0 then
              verifiedNet=sale.verifiedNet
            end
          else
            candidateID,verifiedNet=nil,nil
          end
        end
      end
    end
    local confirmedSource=validatedCost(ch,r)
    local poolProof=r.poolAHCost
    local confirmedBatch,batchLead=nil,false
    if poolProof then
      for _,batchOutput in ipairs(ids) do
        local group=D.SharedBatchPreview(ch,r,poolProof,batchOutput)
        if group then
          local linked=D.BatchEvidence(ch,r,poolProof,batchOutput,group)
          if linked then
            confirmedBatch=group
            batchLead=(group.firstCastGuid==rawRecord(r).guid)
            break
          end
        end
      end
    end
    local confirmedOutput=validatedAuction(ch,r)
    local autoProof=validatedAuto(ch,r)
    local autoDisabled=rawRecord(r).autoDE and rawRecord(r).autoDE.disabled
    local autoStale=rawRecord(r).autoDE and not autoDisabled and not autoProof
    local manualNet,manualProfit=nil,nil
    if confirmedSource and confirmedOutput then
      local manualID=r.manualDE and r.manualDE.auctionID
      local sale=manualID and sales[manualID]
      if sale and sale.receiptID and type(sale.verifiedNet)=="number"
          and sale.verifiedNet>=0 and type(sale.receiptQty)=="number"
          and sale.receiptQty==r.manualDE.quantity then
        manualNet=sale.verifiedNet
        manualProfit=sale.verifiedNet-confirmedSource.price
      end
    end
    local parts={}
    local function detail(label,kind,itemID,confidence,reason)
      parts[#parts+1]={detail=label,deSection=kind=="section",deNotice=kind=="notice",
        deOutput=kind=="output",itemID=itemID,deConfidence=confidence,deReason=reason,
        deSummary=kind=="summary"}
    end
    local function section(title)
      detail("------------  "..title.."  ------------","section")
    end
    section("SOURCE & COST")
    detail("Input: "..name(r.input)..(r.input and ("   Item #"..r.input) or ""),nil,r.input,
      r.input and "ok" or "question",
      r.input and "Disenchant input item ID was captured from the bag-difference observation." or "Input item ID was not established.")
    detail("Disenchanted: "..date("%b %d, %Y %I:%M %p",r.at),nil,nil,"ok",
      "Disenchant spellcast time was recorded by Auction Peek.")
    if r.cost then
      local label=(r.cost==0 and "0c" or money(r.cost))
      if r.purchaseSource then
        detail("Buy History #"..r.purchaseSource.."   Purchase recorded",nil,nil,"ok",
          "A matching real purchase entry exists in Buy History. This verifies a purchase, not the cost assignment to this disenchant.")
        local confirmedCost=confirmedSource~=nil
        local autoCost=autoProof~=nil
        detail((autoCost and "Auto-verified input cost: " or confirmedCost and "Manually confirmed input cost: " or "Input cost candidate: ")..label,
          (confirmedCost or autoCost) and nil or "notice",nil,(confirmedCost or autoCost) and "ok" or "question",
          autoCost and "Automatically matched one verified input purchase to the clean DE event and unique paid output auction. Read-only; see Auto evidence to disable."
          or confirmedCost and "Player confirmed this Buy History purchase for this DE cast. No inventory lots changed; click to undo." or
          "Cost is inferred from a nearby single-unit purchase, not proven allocated to this DE. No ledger values changed.")
        local line=parts[#parts]
        if not autoCost then
          line.deAction="cost"; line.deGuid=rawRecord(r).guid
          line.deManualConfirmed=confirmedCost
        end
        detail("Read-only DE attribution: canonical inventory lots unchanged")
      elseif poolProof then
        detail("Verified AH purchase pool unit cost: "..label,nil,nil,"ok",
          "All input units in this fresh bag snapshot match an equal-sized set of confirmed AH purchases at an identical price. This verifies a shared unit cost, NOT the individual purchase ID or output-auction allocation.")
        local purchaseLabels={}
        for _,id in ipairs(poolProof.purchaseIDs or {}) do
          purchaseLabels[#purchaseLabels+1]="#"..tostring(id)
        end
        detail("AH purchase pool: "..table.concat(purchaseLabels,", ")..
          "   ("..poolProof.validatedCasts.."/"..poolProof.quantity.." observed DEs)",nil,nil,"ok",
          "The input count decreased one at a time across clean DE casts. Purchase IDs are pooled, not individually claimed, and none are consumed in the canonical cost ledger.")
        detail("Read-only pooled cost: inventory lots and Flip unchanged")
      else
        detail("Observed source cost: "..label.." (diagnostic)",nil,nil,"question",
          "Acquisition cost is shown for diagnosis only. It is not a confirmed sale allocation or realized DE profit.")
      end
    else
      detail("Input acquisition cost: Unresolved","notice",nil,"question",
        "Confirmed AH purchase evidence exists for this input item, but no unique cost allocation has been proven. No realized DE profit is asserted.")
      local matchingAH=0
      for _,b in ipairs(ch.buys or {}) do
        if confirmedAHInputBuy(b) and ahPurchaseWindow(b,r) then
          matchingAH=matchingAH+b.quantity
        end
      end
      if matchingAH>0 then
        detail("Matching recent AH purchases: "..matchingAH.." unit(s)","notice",nil,"question",
          "These are possible sources, not a proof of which individual bought item was disenchanted. Costs and inventory lots remain unchanged.")
      end
      if type(r.held)=="number" and r.held>1 then
        detail("Purchase matching withheld: "..r.held.." identical input items held","notice",nil,"question",
          "The bag snapshot contained multiple copies before the cast. The addon cannot prove which physical item/purchase was disenchanted.")
      else
        local matching=0
        for _,b in ipairs(ch.buys or {}) do
          if b.itemID==r.input and type(b.boughtAt)=="number" and type(r.at)=="number"
              and b.boughtAt<=r.at and r.at-b.boughtAt<=900 then
            matching=matching+1
          end
        end
        if matching>1 then
          detail("Purchase matching withheld: "..matching.." recent identical purchases","notice",nil,"question",
            "Multiple purchases of this item fall within the 15-minute candidate window. No purchase ID has been assigned automatically.")
        end
      end
    end
    section("DISENCHANT RESULTS")
    local agreed=r.status=="Bag and loot agree"
    detail("Bag verification: "..(r.status or "Unknown"),agreed and nil or "notice",nil,
      agreed and "ok" or "question",agreed and
        "The post-disenchant bag comparison matched the recorded input loss and output loot." or
        "The output was not verified by the delayed bag comparison. Fast posting, bag changes, or other activity can cause this; it is not proof of an erroneous disenchant.")
    if r.status=="Unresolved" and r.purchaseSource then
      detail("Bag changed before verification; cost allocation unverified","notice",nil,"question",
        "Auction Peek had an input and loot observation, but could not reconcile the delayed inventory snapshot. The cost remains a candidate.")
    end
    if #ids==0 then detail("No recorded output loot yet","notice",nil,"question",
      "No loot event was recorded for this disenchant; no output quantity can be asserted.") end
    for _,id in ipairs(ids) do
      local n=tonumber(r.outputs[id])
      if n and n>0 then
        detail("Loot event: "..n.."x "..name(id),"output",id,"ok",
          "Personal loot event recorded this item and quantity. This does not prove the later auction used precisely these units.")
        if r.preexisting and type(r.preexisting[id])=="number" then
          detail("Already held: "..r.preexisting[id].."x "..name(id),nil,id,"ok",
            "Quantity of this item observed in bags before the disenchant. Mixed inventory makes output-to-auction assignment uncertain.")
        end
        if #ids==1 and r.cost and agreed then
          local first=D.Share(r.cost,n,0,1)
          if first then detail("First unit test cost: "..(first==0 and "0c" or money(first)),"notice",nil,nil,
            "Illustrative split of input cost across output units; not a verified inventory or auction allocation.") end
        end
      end
    end
    section("AUCTION / PAYMENT")
    detail("Matches below are candidates, not proof of DE inventory use")
    if poolProof then
      for _,id in ipairs(ids) do
        local batch=D.SharedBatchPreview(ch,r,poolProof,id)
        if batch then
          local linked,batchID,stale=D.BatchEvidence(ch,r,poolProof,id,batch)
          local shared=#batch.castGUIDs>1
          detail((linked and "Player-confirmed shared payment batch: " or "Payment batch candidate: ")..
            batch.outputQty.."x "..name(id).." from "..batch.inputCasts.." DE(s)   "..
            table.concat(batch.receipts,", "),linked and nil or "notice",id,
            linked and "ok" or "question",
            linked and "Player explicitly confirmed these AH purchases, DE output observations, and collected receipts. This is a GROUP claim, not a canonical lot or auction-ID reconciliation; shared receipt totals may appear on several rows but count only once."
              or "Receipt totals and item price suggest a group, but the original full auction posting ID is not proven. Review the evidence and confirm only if these were the exact units sold.")
          detail((linked and "Confirmed group net: " or "Candidate group net: ")..
            money(batch.net).."   Input cost: "..money(batch.inputCost)..
            "   Group P/L: "..(batch.previewProfit<0 and "-" or "+")..
            money(math.abs(batch.previewProfit)),linked and nil or "notice",nil,
            linked and "ok" or "question",
            "ONE shared group result: do not add this profit once per DE row. The original sale receipt, Flip and cost lots remain untouched. Posting costs not represented in receipts could affect actual realized profit.")
          local status=stale or (linked and "Confirmed - click to revoke shared batch" or
            "Review purchase, DE and receipt evidence before confirming")
          detail(status,"notice",nil,stale and "question" or linked and "ok" or "question",
            "Player confirmation is reversible and revalidated against exact source casts, AH purchase pool, receipt quantities, unit price, and aggregate net. No historical auction ID or lot cost will be fabricated.")
          if not stale then
            local action=parts[#parts]
            action.deAction="batch";action.deGuid=rawRecord(r).guid
            action.deOutputID=id;action.deManualConfirmed=linked~=nil
          end
        end
      end
    end
    local before=#parts
    for _,id in ipairs(ids) do
      local n=tonumber(r.outputs[id])
      if n and n>0 then salePreview(ch,r,id,n,money,parts,sales,receipts,matches) end
    end
    if #parts==before then
      local laterSession=false
      for _,id in ipairs(ids) do
        if nextOutputSession(ch,r,id) then laterSession=true;break end
      end
      if laterSession then
        detail("No output auction before the next same-item DE; later auctions not assumed to match","notice",nil,"question",
          "A newer disenchant produced this same output before any candidate auction was observed. Later listings may contain mixed inventory and cannot be assigned to this older DE without stronger evidence.")
      else
        detail("No possible output auctions yet; check after AH refresh","notice",nil,"question",
          "No later auction listing was found that could be the DE output. This may be normal before posting.")
      end
    end
    if autoProof then
      detail("Auto DE result: "..(autoProof.profit<0 and "-" or "+")..money(math.abs(autoProof.profit)),nil,nil,"ok",
        "Auto-linked purchase, single clean output, unique auction and complete verified sale receipt. This remains separate from permanent inventory lots.")
      detail("Auto evidence: rule "..AUTO_RULE.."   Click to disable automatic attribution",nil,nil,"ok",
        "Automated verification is rechecked against the original saved records. Click to disable; no saved costs or receipts are changed.")
      parts[#parts].deAction="auto";parts[#parts].deGuid=rawRecord(r).guid
      detail("Auto evidence only: canonical inventory lots unchanged")
    elseif manualProfit then
      local amount=money(math.abs(manualProfit))
      detail("Manual DE result: "..(manualProfit<0 and "-" or "+")..amount,nil,nil,"ok",
        "Computed from the player-confirmed input purchase and output auction, plus a verified payment. This is a MANUAL attribution, not an automatic inventory-lot correction.")
      detail("Manual evidence only: inventory cost lots remain unchanged")
    else
      if autoStale then
        detail("Auto DE link needs review: underlying evidence changed","notice",nil,"question",
          "Stored auto attribution no longer matches current records. Its profit is withheld until investigated.")
      end
      if autoDisabled then
        detail("Auto verification disabled; click to retry","notice",nil,"question",
          "You disabled this automatically verified relationship. Click to make the transaction eligible for auto verification again.")
        parts[#parts].deAction="auto";parts[#parts].deGuid=rawRecord(r).guid
      end
      detail("DE profit: awaiting verified output-to-sale cost linkage","notice",nil,"question",
        "Both manual confirmations and the correct verified sale payment are needed for a manual DE result. Awaiting mail alone is not a broken transaction.")
    end

    -- Assign the parent indicator using the strongest child evidence. Counts
    -- reflect only the evidence rows, not divider or explanatory lines.
    local ok,uncertain,errors=0,0,0
    for _,part in ipairs(parts) do
      if part.deConfidence=="ok" then ok=ok+1
      elseif part.deConfidence=="error" then errors=errors+1
      elseif part.deConfidence=="question" then uncertain=uncertain+1 end
    end
    local overall=(manualProfit or autoProof) and errors==0 and "ok"
      or errors>0 and "error" or uncertain>0 and "question" or "ok"
    local overallReason=errors>0 and "At least one stored-record contradiction is flagged below. Expand to identify it." or
      uncertain>0 and "Some costs, allocations, or auction links still require evidence. Expand to see which fields are confirmed." or
      "All checks shown for this record are verified."
    -- Compact line uses Flip's columns, but only evidence is displayed:
    -- - input cost is a diagnostic candidate, NOT allocated dust cost
    -- - verified net belongs to a possible auction, NOT proven DE profit
    -- - profit must remain unverified until output-to-sale linkage is proven.
    local costText=r.cost and (((confirmedSource or autoProof or poolProof) and "" or "? ")..(r.cost==0 and "0c" or money(r.cost))) or "Unknown"
    local proceedsText=autoProof and money(autoProof.verifiedNet) or manualNet and money(manualNet)
      or confirmedBatch and (batchLead and money(confirmedBatch.net) or "Shared batch")
      or candidateID and verifiedNet and ("? "..money(verifiedNet)) or
      candidateCount>1 and "Multiple" or candidateCount==1 and "Pending" or "-"
    local resultText=autoProof and ("Auto "..(autoProof.profit<0 and "-" or "+")..money(math.abs(autoProof.profit))) or
      manualProfit and ("Manual "..(manualProfit<0 and "-" or "+")..money(math.abs(manualProfit))) or
      confirmedBatch and (batchLead and ("Batch "..(confirmedBatch.previewProfit<0 and "-" or "+")..
        money(math.abs(confirmedBatch.previewProfit))) or "Shared batch") or "Unverified"
    lines[#lines+1]={detail=(open and "[-] " or "[+] ")..outputs,
      name=outputs.." / "..name(r.input),
      deHeader=true,deKey=key,itemID=outputID or r.input,deInputID=r.input,
      deOutputID=outputID,deCostText=costText,deNetText=proceedsText,
      deProfitText=resultText,deProfitManual=manualProfit~=nil or autoProof~=nil or confirmedBatch~=nil,
      deProfitAuto=autoProof~=nil,
      deProfitNegative=(autoProof and autoProof.profit<0) or (manualProfit~=nil and manualProfit<0) or
        (confirmedBatch and batchLead and confirmedBatch.previewProfit<0),
      deAuctionID=autoProof and autoProof.auctionID or candidateID,
      deAuctionIDs=allAuctionIDs,deAt=r.at,deStatus=r.status,
      deConfidence=overall,deReason=overallReason}
    if open then
      for _,part in ipairs(parts) do lines[#lines+1]=part end
      lines[#lines+1]={detail="Status: "..ok.." verified  /  "..uncertain.." review  /  "..errors.." errors",
        deSummary=true}
    end
  end
  return lines
end
