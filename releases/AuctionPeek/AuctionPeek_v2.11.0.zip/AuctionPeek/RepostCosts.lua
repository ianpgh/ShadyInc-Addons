local _, AP = ...
local R={}
AP.RepostCosts=R

-- Only postings observed while an actual collected attachment is waiting for
-- its old auction can claim a delayed credit. Never search by display name.
function R.Watch(ch,p,auctionID,suffix)
  local journal=ch.returnEvidence
  local hole=false
  for _,part in ipairs(p.parts or {}) do
    if part.unknown and not part.source and part.reason=="UNKNOWN_ACQUISITION" then hole=true end
  end
  if not hole then return end
  if AP.WatchReturnRequests then AP.WatchReturnRequests(p,auctionID,suffix) end
  if not journal or not next(journal.pending) then return end
  for _,pickup in ipairs(journal.pending) do
    if pickup.id==p.itemID and (pickup.suffix or 0)==(suffix or 0) and (not pickup.level or not p.itemLevel or pickup.level==p.itemLevel) and pickup.at<=p.at then
      pickup.waiting=pickup.waiting or {}
      pickup.waiting[tostring(auctionID)]=true
    end
  end
end

function R.WatchCraft(ch,x)
  if not ch.returnEvidence then return end
  local id="craft:"..x.index
  for _,a in ipairs(x.parts) do
    if a.unknown and not a.source and a.reason=="INSUFFICIENT_TRACKED" then
      local item={at=x.at,itemID=a.itemID}
      if AP.WatchReturnRequests then AP.WatchReturnRequests(item,id,0) end
      for _,e in ipairs(ch.returnEvidence.pending or {}) do
        if e.id==a.itemID and (e.suffix or 0)==0 and e.at<=x.at then
          e.waiting=e.waiting or {};e.waiting[id]=true
        end
      end
    end
  end
end

function R.Apply(ch,credits)
  local l=ch.craftLedger
  local targets={}
  local seen={}
  for _,credit in ipairs(credits) do
    for id in pairs(credit.waiting) do
      local index=tonumber(tostring(id):match("^craft:(%d+)$"))
      local owner=index and l.lots[index] or l.posts[id]
      if not seen[id] and owner then
        targets[#targets+1]={id=id,p=owner,index=index}
        seen[id]=true
      end
    end
  end
  table.sort(targets,function(a,b)
    if a.p.at~=b.p.at then return a.p.at<b.p.at end
    if (not a.index)~=(not b.index) then return a.index~=nil end
    return (a.index or tonumber(a.id))<(b.index or tonumber(b.id))
  end)
  table.sort(credits,function(a,b)
    local x,y=l.lots[a.source],l.lots[b.source]
    if x.at~=y.at then return x.at<y.at end
    if a.source~=b.source then return a.source<b.source end
    return a.old<b.old
  end)
  for _,target in ipairs(targets) do
    local p=target.p
    local graph=target.index and AP.Lifecycle.RepricePlan(ch,target.index)
    local added,units=0,0
    if (not target.index or graph) and not (p.returnedUnits or p.remainderTo or p.manualPurchaseUndo or p.costRecovery)
        and (not p.ended or p.awaitingReturn) then
      local parts={}
      for _,part in ipairs(p.parts or {}) do
        local need=part.n
        if part.unknown and not part.source and part.cost==0 and part.reason==(target.index and "INSUFFICIENT_TRACKED" or "UNKNOWN_ACQUISITION") then
          for _,c in ipairs(credits) do
            local x=l.lots[c.source]
            if c.waiting[target.id] and part.itemID==x.itemID and (not c.level or not p.itemLevel or c.level==p.itemLevel)
                and (not target.index or c.source<target.index) and c.n>0 and need>0 then
              local n=math.min(c.n,need)
              local cost=math.floor(c.cost*n/c.n)
              if x.left>=n and x.balance>=cost then
                parts[#parts+1]={itemID=x.itemID,source=c.source,n=n,cost=cost,unknown=c.unknown,
                  estimate=c.estimate,sourceUncertain=c.sourceUncertain,returnedFrom=c.old,
                  method="RETURN_FIFO",allocatedAt=time()}
                added,units=added+cost,units+n
                x.left,x.balance=x.left-n,x.balance-cost
                c.n,c.cost,need=c.n-n,c.cost-cost,need-n
              end
            end
          end
        end
        if need==part.n then parts[#parts+1]=part
        elseif need>0 then
          parts[#parts+1]={itemID=part.itemID,n=need,cost=0,unknown=true,reason=part.reason}
        end
      end
      p.parts=parts
      if graph and units>0 then AP.Lifecycle.Reprice(graph,added) end
    end
  end
end

-- The player confirmed this specific two-item return and repost as a group.
-- Check both legs, the actual lots and their entire allocation graph before
-- moving either reservation. Receipts and sale states belong to the client.
local boots={
  {old="216017663",new="223570302",lot=1253,cost=11556,posted=1795670107},
  {old="216090883",new="223572224",lot=1257,cost=12146,posted=1795670115}
}

local function historyRow(ch,id)
  local found,bucket
  for _,name in ipairs({"active","ended","sold","deleted"}) do
    for _,r in ipairs(ch[name] or {}) do
      if tostring(r.auctionID)==id then
        if found then return end
        found,bucket=r,name
      end
    end
  end
  return found,bucket
end

function R.ConfirmBoots(ch)
  local l=ch.craftLedger
  if not l or l.confirmedBootsRepostsV1 then return end
  for _,leg in ipairs(boots) do
    local a,b=l.posts[leg.old],l.posts[leg.new]
    local x=l.lots[leg.lot]
    local row,bucket=historyRow(ch,leg.old)
    local dest,where=historyRow(ch,leg.new)
    if not row or bucket~="ended" or row.endedReason~="unconfirmed" or not row.missingAfterLogin
        or row.repostedAs or row.returnCollectedAt or not dest or (where~="active" and where~="sold")
        or dest.repostOf or row.itemID~=10026 or dest.itemID~=10026 or row.itemLevel~=dest.itemLevel
        or (row.itemSuffix or 0)~=0 or (dest.itemSuffix or 0)~=0 then return end
    if not a or not b or not x or not x.parts or x.itemID~=10026 or x.quantity~=1 or x.cost~=leg.cost
        or x.left~=0 or x.balance~=0 or a.quantity~=1 or b.quantity~=1 or a.itemID~=10026
        or b.itemID~=10026 or b.at~=leg.posted or not a.unresolved or a.ended or a.ownedSold
        or a.returnedUnits or a.remainderTo or a.soldAt or a.filled or a.gross or a.remainingSeen
        or b.ended or b.returnedUnits or b.remainderTo or b.costRecovery or b.confirmedPurchase
        or AP.VendorCosts.ManualActive(ch,leg.new) then return end
    local src=a.parts and #a.parts==1 and a.parts[1]
    local dst=b.parts and #b.parts==1 and b.parts[1]
    if not src or src.source~=leg.lot or src.cost~=leg.cost or src.n~=1 or src.unknown
        or not dst or dst.n~=1 or not dst.unknown or dst.source or dst.cost~=0
        or dst.reason~="UNKNOWN_ACQUISITION" then return end
    for id,p in pairs(l.posts) do
      for _,v in ipairs(p.parts or {}) do if id~=leg.old and v.source==leg.lot then return end end
    end
    for _,lot in ipairs(l.lots) do
      for _,v in ipairs(lot.parts or {}) do if v.source==leg.lot then return end end
    end
    for _,pool in ipairs({ch.sold or {},ch.deleted or {}}) do
      for _,r in ipairs(pool) do if r.mailFlip and r.mailFlip.source==leg.lot then return end end
    end
  end
  local changes={}
  for _,leg in ipairs(boots) do
    local a,b=l.posts[leg.old],l.posts[leg.new]
    local dest=historyRow(ch,leg.new)
    local part=a.parts[1]
    changes[leg.new]={unknown=b.parts[1],soldAt=b.soldAt,receipt=dest.receiptID,
      from=part.returnedFrom,method=part.method,allocated=part.allocatedAt}
    part.returnedFrom,part.method,part.allocatedAt=tonumber(leg.old),"PLAYER_CONFIRMED_RETURN_FIFO",time()
    b.parts,a.parts={part},{}
    a.remainderTo,a.ended,a.returnedUnits,a.fillLimit,a.unresolved=leg.new,"expired",1,0,nil
    local old=historyRow(ch,leg.old)
    old.endedReason="expired"
    old.confirmedReturned=true
    -- FIFO is an accounting assignment. The physical pair is interchangeable.
  end
  l.confirmedBootsRepostsV1={at=time(),changes=changes,method="Player confirmed both expired pairs were collected and reposted"}
  return true
end

function R.UndoBoots(ch)
  local l=ch and ch.craftLedger
  local j=l and l.confirmedBootsRepostsV1
  if not j or not j.changes or j.undoneAt then return end
  for _,leg in ipairs(boots) do
    local snapshot=j.changes[leg.new]
    local a,b=l.posts[leg.old],l.posts[leg.new]
    local old=historyRow(ch,leg.old)
    local dest,where=historyRow(ch,leg.new)
    local part=b and b.parts and #b.parts==1 and b.parts[1]
    local x=l.lots[leg.lot]
    if not old or not old.confirmedReturned or not dest or (where~="active" and where~="sold")
        or not snapshot or not a or a.remainderTo~=leg.new or #a.parts~=0
        or not part or part.source~=leg.lot or part.cost~=leg.cost
        or part.method~="PLAYER_CONFIRMED_RETURN_FIFO" or b.ended or b.returnedUnits or b.remainderTo
        or b.soldAt~=snapshot.soldAt or dest.receiptID~=snapshot.receipt
        or not x or x.left~=0 or x.balance~=0 then return end
  end
  for _,leg in ipairs(boots) do
    local a,b=l.posts[leg.old],l.posts[leg.new]
    local src=b.parts[1]
    local snapshot=j.changes[leg.new]
    src.method,src.returnedFrom,src.allocatedAt=snapshot.method,snapshot.from,snapshot.allocated
    a.parts,b.parts={src},{snapshot.unknown}
    a.remainderTo,a.ended,a.returnedUnits,a.fillLimit,a.unresolved=nil,nil,nil,nil,true
    local old=historyRow(ch,leg.old)
    old.endedReason,old.confirmedReturned="unconfirmed",nil
  end
  j.undoneAt=time()
  return true
end
