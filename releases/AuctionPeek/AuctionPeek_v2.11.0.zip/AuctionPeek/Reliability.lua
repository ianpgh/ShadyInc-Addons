local _, AP = ...
local R={}
AP.Reliability=R

-- A historical bag-delta recovery is an accounting estimate, not an invoice.
-- Only recover an entire missing reagent from a unique recorded purchase and
-- an isolated zero-to-full-to-zero bag movement, with no other use of its cost.
local function refs(ch,index)
  local list={}
  for _,x in ipairs(ch.craftLedger.lots) do
    for _,p in ipairs(x.parts or {}) do if p.source==index then list[#list+1]={owner=x,part=p} end end
  end
  for _,x in pairs(ch.craftLedger.posts) do
    for _,p in ipairs(x.parts or {}) do if p.source==index then list[#list+1]={owner=x,part=p} end end
  end
  for _,pool in ipairs({ch.sold or {},ch.deleted or {}}) do
    for _,x in ipairs(pool) do if x.mailFlip and x.mailFlip.source==index then list[#list+1]={owner=x,part=x.mailFlip} end end
  end
  return list
end
local function positive(n) return type(n)=="number" and n>0 and n%1==0 end
function R.PendingCosts(ch)
  local pending,crafts=0,0
  local l=ch.craftLedger
  for _,b in ipairs(ch.buys or {}) do
    if b.delivery and b.delivery.stage~="verified" then pending=pending+1 end
  end
  for _,d in ipairs(l and l.craftDiagnostics or {}) do
    local x=l.lots[d.lot]
    if x and x.unknown then crafts=crafts+1 end
  end
  return pending,crafts
end
-- Only an isolated recorded purchase and a matching bag movement can fill
-- a historical material hole. Build its dependency graph after matching.
local function pricedDelivery(ch,l,x,input,observations,buys)
  if not positive(input.required) or input.bag~=input.required or input.tracked~=0
      or input.missing~=input.required then return end
  local missing
  for _,a in ipairs(x.parts) do
    if a.itemID==input.itemID and a.unknown and not a.source and a.cost==0
        and a.reason=="INSUFFICIENT_TRACKED" and a.n==input.required then
      if missing then return end
      missing=a
    end
  end
  if not missing then return end
  local buy
  for _,b in ipairs(buys[input.itemID] or {}) do
    if b.boughtAt and b.boughtAt<=x.at and x.at-b.boughtAt<=600 then
      if buy then return end
      buy=b
    end
  end
  if not buy or not buy.delivery or buy.delivery.stage=="verified" or not buy.notifiedAH
      or buy.quantity~=input.required or not positive(buy.price) or not positive(buy.purchaseID)
      or buy.priceEstimated or l.purchases["p:"..buy.purchaseID]
      or (buy.auctionID and l.purchases["a:"..buy.auctionID]) then return end
  local arrival,consumed,changes=nil,nil,0
  for _,o in ipairs(observations) do
    if o.itemID==input.itemID and o.at>=buy.boughtAt and o.at<=x.at then
      changes=changes+1
      if o.bankOpen or not o.evidence then return end
      if o.before==0 and o.after==input.required and o.evidence.GENERIC_ITEM_RECEIPT==input.required
          and o.at-buy.boughtAt<=120 then
        for k in pairs(o.evidence) do if k~="GENERIC_ITEM_RECEIPT" then return end end
        arrival=o
      elseif o.before==input.required and o.after==0 and o.at==x.at and o.evidence.CRAFT_INPUT==-input.required then
        for k in pairs(o.evidence) do if k~="CRAFT_INPUT" then return end end
        consumed=o
      end
    end
  end
  if changes~=2 or not arrival or not consumed or arrival.at>=consumed.at then return end
  for _,v in ipairs(l.lots) do
    if v.purchase==buy.purchaseID or (buy.auctionID and v.auctionID==buy.auctionID) then return end
  end
  return missing,buy,arrival
end

function R.RecoverCraftDelivery(ch)
  local l=ch.craftLedger
  local observations=ch.inventoryReconciliation and ch.inventoryReconciliation.observations
  if not l or not l.craftDiagnostics or not observations then return 0 end
  local count,buys=0,{}
  for _,b in ipairs(ch.buys or {}) do
    if b.itemID then
      buys[b.itemID]=buys[b.itemID] or {}
      table.insert(buys[b.itemID],b)
    end
  end
  for _,d in ipairs(l.craftDiagnostics) do
    local x=l.lots[d.lot]
    if x and x.unknown and x.parts then
      for _,input in ipairs(d.inputs or {}) do
        local missing,buy,arrival=pricedDelivery(ch,l,x,input,observations,buys)
        local plan=missing and AP.Lifecycle.RepricePlan(ch,d.lot)
        if plan then
          local index=#l.lots+1
          buy.delivery={version=2,stage="verified",collectedAt=arrival.at,prior=buy.delivery,
            evidence={method="HISTORICAL_BAG_DELTA_ESTIMATE",before=0,after=input.required,craftLot=d.lot}}
          buy.deliveryInferred=true
          l.lots[index]={index=index,itemID=input.itemID,quantity=input.required,left=0,cost=buy.price,balance=0,
            at=buy.boughtAt,availableAt=arrival.at,purchase=buy.purchaseID,auctionID=buy.auctionID,estimate=true}
          l.purchases["p:"..buy.purchaseID]=index
          if buy.auctionID then l.purchases["a:"..buy.auctionID]=index end
          missing.source,missing.cost,missing.unknown,missing.estimate=index,buy.price,nil,true
          missing.reason="HISTORICAL_BAG_DELTA_ESTIMATE"
          AP.Lifecycle.Reprice(plan,buy.price)
          count=count+1
        end
      end
    end
  end
  return count
end
-- User reported that this specific purchased stack was collected and reposted.
-- Do not infer other expired returns from similar names or elapsed timers.
function R.ConfirmReportedDye(ch)
  local l=ch.craftLedger
  if not l or l.reportedDyeRepostV211 then return end
  local a,b=l.posts["215808403"],l.posts["224917431"]
  local x=l.lots[1241]
  if not a or not b or not x or a.itemID~=4340 or b.itemID~=4340 or a.quantity~=20 or b.quantity~=20
    or a.at~=1795632867 or b.at~=1795676581 or a.totalPrice~=500 or b.totalPrice~=340
    or a.ended or not a.unresolved or a.returnedUnits or a.remainderTo or a.filled or a.soldAt
    or b.returnedUnits or b.remainderTo or b.filled or b.gross or not b.awaitingReturn
    or x.itemID~=4340 or x.quantity~=20 or x.cost~=5670 or x.left~=0 or x.balance~=0 or x.purchase~=375
    or #(a.parts or {})~=1 or #(b.parts or {})~=1 then return end
  local src,dst=a.parts[1],b.parts[1]
  local links=refs(ch,1241)
  if #links~=1 or links[1].part~=src or src.source~=1241 or src.n~=20 or src.cost~=5670 or src.unknown
    or dst.source or not dst.unknown or dst.n~=20 or dst.cost~=0 or dst.reason~="UNKNOWN_ACQUISITION" then return end
  local old,new,receipt
  for _,e in ipairs(ch.returnEvidence and ch.returnEvidence.pending or {}) do
    if e.id==4340 and e.at>=a.at then return end
  end
  for _,r in ipairs(ch.ended or {}) do
    if r.auctionID==215808403 and r.repostedAs==224917431 and r.endedReason=="unconfirmed" and not r.returnCollectedAt and r.endTime and r.endTime<b.at then old=r end
    if r.auctionID==224917431 and r.repostOf==215808403 and not r.returnCollectedAt and not r.cancelRequestedAt then new=r end
  end
  for _,r in ipairs(ch.sold or {}) do
    if r.receiptID=="mail:283" and r.mailOnly and r.name=="Gray Dye" and r.receiptQty==20 and r.verifiedGross==6800 then receipt=r end
  end
  if not old or not new or not receipt then return end
  for _,pool in ipairs({ch.active or {},ch.sold or {},ch.deleted or {},ch.ended or {}}) do
    for _,r in ipairs(pool) do
      if (r.auctionID==215808403 and r~=old) or (r.auctionID==224917431 and r~=new)
        or (r.receiptID=="mail:283" and r~=receipt) then return end
    end
  end
  l.reportedDyeRepostV211={at=time(),old="215808403",new="224917431",prior=dst,method="PLAYER_REPORTED_REPOST"}
  src.returnedFrom,src.method,src.allocatedAt=215808403,"PLAYER_REPORTED_REPOST",time()
  b.parts,a.parts={src},{}
  a.ended,a.returnedUnits,a.fillLimit,a.remainderTo,a.unresolved="expired",20,0,"224917431",nil
  old.endedReason,old.confirmedReturned="expired",true
  return true
end
