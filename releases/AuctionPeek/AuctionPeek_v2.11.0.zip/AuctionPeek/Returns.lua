-- Observe item returns independently from seller invoices.
local _, AP = ...
local rows, counts, requests = {}, {}, {}
local watching = false

local function readable(v)
  return not issecretvalue or not issecretvalue(v)
end

local function returnedItem(index)
  local _,_,sender,subject,money,cod,_,hasItem = GetInboxHeaderInfo(index)
  if not readable(sender) or not readable(subject) or not readable(money) or not readable(cod)
      or not money or not cod then return nil,false end
  if money~=0 or cod~=0 or type(subject)~="string" then return end
  if sender~="Auction House" and sender~="Horde Auction House" and sender~="Alliance Auction House"
      and sender~="Blackwater Auction House" and (not AUCTION_HOUSE or sender~=AUCTION_HOUSE) then return end
  local name,id,_,n=GetInboxItem(index,1)
  if not readable(name) or not readable(id) or not readable(n) then return nil,false end
  if not name then
    if not readable(hasItem) or (hasItem and hasItem~=0) then return nil,false end
    return
  end
  if type(id)~="number" or type(n)~="number" or n<1 then return nil,false end
  -- Stacked attachments may include their quantity in the auction subject.
  local suffix=" ("..n..")"
  if subject:sub(-#suffix)==suffix then subject=subject:sub(1,-#suffix-1) end
  local function subjectMatches(template)
    return type(template)=="string" and subject==template:gsub("%%s",function() return name end)
  end
  local reason
  if subjectMatches(AUCTION_REMOVED_MAIL_SUBJECT) or subjectMatches(AUCTION_CANCELED_MAIL_SUBJECT) or subject=="Auction cancelled: "..name
      or subject=="Auction canceled: "..name then reason="canceled"
  elseif subjectMatches(AUCTION_EXPIRED_MAIL_SUBJECT) or subject=="Auction expired: "..name then reason="expired"
  else return end
  local link=GetInboxItemLink and GetInboxItemLink(index,1)
  if not readable(link) then return nil,false end
  local payload=type(link)=="string" and link:match("|H(item:[^|]+)|h")
  local suffixID=payload and tonumber((payload:match("^item:[^:]*:[^:]*:[^:]*:[^:]*:[^:]*:[^:]*:([^:]*)")))
  local level
  local detailed=C_Item and C_Item.GetDetailedItemLevelInfo or GetDetailedItemLevelInfo
  if detailed and type(link)=="string" then
    local ok,value=pcall(detailed,link)
    if ok and readable(value) and type(value)=="number" and value>0 then level=value end
  end
  return {id=id,n=n,reason=reason,suffix=suffixID,level=level,
    key=reason.."/"..id.."/"..n.."/"..(suffixID or 0).."/"..(level or 0)}
end

local function confirm(ch,item,snapshot,pending)
  local posts=ch.craftLedger and ch.craftLedger.posts or {}
  local candidates,blocked={},{}
  for _,pool in ipairs({ch.active or {},ch.sold or {},ch.deleted or {}}) do
    for _,row in ipairs(pool) do
      local post=row.auctionID and posts[tostring(row.auctionID)]
      local partial=post and (post.filled or post.remainingSeen) and AP.Crafts.ReturnQuantity(post)
      if row.auctionID and ((pool==ch.active and not snapshot) or (row.sold and not partial)
          or (row.deletedKind=="listed" and not row.endedReason)) then
        blocked[tostring(row.auctionID)]=true
      end
    end
  end
  if not snapshot then
    for _,r in ipairs(ch.active or {}) do
      if r.itemID==item.id and (r.itemSuffix or 0)==(item.suffix or 0)
          and (r.firstSeenAt or 0)<=item.at and not r.cancelRequestedAt
          and not r.sold and ((r.endTime and r.endTime<=item.at) or r.endedReason==item.reason) then return end
    end
  end
  local split,receipts,paid
  if AP.Lifecycle then split,receipts,paid=AP.Lifecycle.OfflineRemainder(ch,item) end
  local seen={}
  for _,pool in ipairs({ch.ended or {},ch.deleted or {},ch.active or {}}) do
    for _,row in ipairs(pool) do
      local key=tostring(row.auctionID)
      local p=posts[key]
      local reason=row.endedReason
      local exact=reason==item.reason or (p and p.ended==item.reason)
      local expired=item.reason=="expired" and row.endTime and row.endTime<=item.at
        and (reason=="unconfirmed" or not reason)
      local canceled=item.reason=="canceled" and row.cancelRequestedAt
        and row.cancelRequestedAt<=item.at and item.at-row.cancelRequestedAt<=60
      local n=p and AP.Crafts.ReturnQuantity(p) or (not p and row.quantity)
      if split and p==split then n=item.n end
      if row.auctionID and not seen[key] and row.itemID==item.id and n==item.n
          and (row.itemSuffix or 0)==(item.suffix or 0)
          and (not item.level or not row.itemLevel or item.level==row.itemLevel)
          and not row.purchase and not row.returnCollectedAt and not row.sold
          and (not reason or reason=="unconfirmed" or reason==item.reason)
          and (not p or not p.ended or p.ended==item.reason)
          and (row.firstSeenAt or (p and p.at) or 0)<=item.at
          and (exact or expired or canceled)
          and not (snapshot and snapshot[key])
          and (not blocked[key] or (not snapshot and canceled and pool==ch.active)) then
        seen[key]=true
        candidates[#candidates+1]={row=row,post=p,exact=exact}
      end
    end
  end
  if #candidates==0 then return end
  local inferred=#candidates>1
  if inferred then
    -- An elapsed timer alone cannot distinguish a sale from an expiration.
    -- Offline returns can be balanced as a group only if every candidate
    -- has an equivalent confirmed mailbox pickup after its expiration.
    local allExact, latestEnd=true,0
    local level=candidates[1].row.itemLevel
    for _,c in ipairs(candidates) do
      if not c.post or (c.row.itemLevel or 0)~=(level or 0) then return end
      if not c.exact then
        if item.reason~="expired" or not c.row.endTime then return end
        latestEnd=math.max(latestEnd,c.row.endTime)
        allExact=false
      end
    end
    if not allExact then
      local equivalent=0
      for _,e in ipairs(pending) do
        if e.id==item.id and e.n==item.n and e.reason==item.reason and e.suffix==item.suffix
            and e.level==item.level and e.at>=latestEnd then equivalent=equivalent+1 end
      end
      if equivalent~=#candidates or item.at<latestEnd then return end
    end
    table.sort(candidates,function(a,b)
      local x,y=a.row.endedAt or a.post.endedAt or a.post.at,
        b.row.endedAt or b.post.endedAt or b.post.at
      if x~=y then return x<y end
      return a.row.auctionID<b.row.auctionID
    end)
  end
  local target,post=candidates[1].row,candidates[1].post
  -- A compatible unmatched seller invoice is competing evidence.
  for _,pool in ipairs({ch.sold or {},ch.deleted or {}}) do
    for _,r in ipairs(pool) do
      if r.mailOnly and not r.auctionID and r.receiptID and not r.mailFlip
          and (r.itemID==item.id or (not r.itemID and r.name==target.name))
          and (not r.observedAt or r.observedAt>=(target.firstSeenAt or 0))
          and not (post==split and receipts and receipts[r.receiptID]) then return end
    end
  end
  if post and post~=split and post.saleNoticeAt and not post.filled then return end
  local cost,parts=0,{}
  if post then
    local ok,restored,slices=AP.Crafts.CollectReturn(ch,post,item.n,item.reason,target.auctionID,inferred,item.at,nil,post==split and paid or nil)
    if not ok then return end
    cost,parts=restored or 0,slices or {}
    if split and post==split then post.splitReturnEvidence={at=item.at,receipts=receipts,units=paid} end
  end
  target.returnCollectedAt=item.at
  target.endedReason=item.reason
  return true,cost,parts,target.auctionID
end

-- The evidence remains available even when the AH has not synchronized yet.
-- Remove it only after the allocation and auction history have been updated.
local pendingPass=setmetatable({}, {__mode="k"})
function AP.ReconcileReturns(ch,snapshot,remaining)
  local journal=ch and ch.returnEvidence
  if not journal or journal.version~=1 or #journal.pending==0 then return 0 end
  local changed,recovered,credits=0,0,{}
  local i=math.min(journal.cursor or 1,#journal.pending)
  local budget=remaining or #journal.pending
  local steps=math.min(16,budget)
  while steps>0 and #journal.pending>0 do
    if i>#journal.pending then i=1 end
    steps=steps-1
    budget=budget-1
    local pickup=journal.pending[i]
    local ok,cost,parts,old=confirm(ch,pickup,snapshot,journal.pending)
    if ok then
      recovered=recovered+cost
      if pickup.waiting then
        for _,part in ipairs(parts) do
          part.waiting,part.old,part.level=pickup.waiting,old,pickup.level
          credits[#credits+1]=part
        end
      end
      table.remove(journal.pending,i)
      changed=changed+1
    else
      i=i+1
    end
  end
  if #credits>0 and AP.RepostCosts then AP.RepostCosts.Apply(ch,credits) end
  journal.cursor=#journal.pending>0 and math.min(i,#journal.pending) or nil
  if budget>0 and not pendingPass[ch] and C_Timer and C_Timer.After then
    pendingPass[ch]=true
    C_Timer.After(.1,function()
      pendingPass[ch]=nil
      if (not AP.Character or AP.Character()==ch) and #journal.pending>0 then
        local resolved=AP.ReconcileReturns(ch,nil,math.min(budget,#journal.pending))
        if resolved>0 and AP.QueueReceiptReview then AP.QueueReceiptReview() end
      end
    end)
  end
  journal.lastChecked=time()
  journal.resolved=journal.resolved+changed
  journal.recoveredCost=(journal.recoveredCost or 0)+recovered
  return changed,recovered
end

local function attemptJournal(ch)
  if not ch then return end
  ch.returnEvidence=ch.returnEvidence or {version=1,pending={},resolved=0}
  if ch.returnEvidence.version~=1 then return end
  ch.returnEvidence.attempts=ch.returnEvidence.attempts or {}
  return ch.returnEvidence.attempts
end

local function retire(item)
  local ch=AP.Character()
  local j=ch and ch.returnEvidence
  if j and j.attempts and item.attemptID then j.attempts[item.attemptID]=nil end
end

local function record(ch,item)
  if not ch then return end
  ch.returnEvidence=ch.returnEvidence or {version=1,pending={},resolved=0}
  if item.attemptID and not (ch.returnEvidence.attempts and ch.returnEvidence.attempts[item.attemptID]) then return end
  local evidence={id=item.id,n=item.n,reason=item.reason,suffix=item.suffix,level=item.level,at=item.requestedAt or time(),waiting=item.waiting,method=item.restarted and "REQUEST_INBOX_BAG" or "REQUEST_INBOX"}
  table.insert(ch.returnEvidence.pending,evidence)
  retire(item)
end

function AP.ScanReturns()
  if not watching or not GetInboxItem or not GetInboxNumItems then return end
  local n,total=GetInboxNumItems()
  if not readable(n) or type(n)~="number" or n>200 or (total and (not readable(total) or total~=n)) then return end
  local fresh,totals={},{}
  for i=1,n do
    local item,valid=returnedItem(i)
    if valid==false then return end
    if item then fresh[i]=item; totals[item.key]=(totals[item.key] or 0)+1 end
  end
  for key,queue in pairs(requests) do
    local gone=math.max(0,(counts[key] or 0)-(totals[key] or 0))
    while #queue>0 do
      local request=queue[1]
      if GetTime()-request.at>10 then table.remove(queue,1)
      elseif gone>0 then
        gone=gone-1
        table.remove(queue,1)
        record(AP.Character(),request.item)
      else break end
    end
    if #queue==0 then requests[key]=nil end
  end
  local bagCounts={}
  for index,item in pairs(fresh) do
    if rows[index] and rows[index].key==item.key and counts[item.key]==totals[item.key] then
      fresh[index]=rows[index]
    end
    if not fresh[index].requestedAt and AP.Reconciliation then
      if bagCounts[item.id]==nil then bagCounts[item.id]=AP.Reconciliation.Count(item.id) end
      fresh[index].before=bagCounts[item.id]
    end
  end
  -- A reload destroys hook state. A unique saved withdrawal request can be
  -- completed from a fresh full inbox plus its exact inventory increase.
  local ch=AP.Character()
  local j=ch and ch.returnEvidence
  local active={}
  for _,queue in pairs(requests) do
    for _,r in ipairs(queue) do if r.item.attemptID then active[r.item.attemptID]=true end end
  end
  for id,e in pairs(j and j.attempts or {}) do
    if not active[id] then
      if not totals[e.key] and e.unique and e.before and not e.competing and time()>=e.requestedAt
          and time()-e.requestedAt<=120 and AP.Reconciliation
          and AP.Reconciliation.Count(e.id)==e.before+e.n then
        e.restarted=true
        record(ch,e)
      end
    end
  end
  rows,counts=fresh,totals
  if AP.ReconcileReturns(AP.Character())>0 and AP.QueueReceiptReview then AP.QueueReceiptReview() end
end

function AP.ReturnMailbox(open)
  rows,counts,requests={},{},{}
  watching=open
  if open then AP.ScanReturns() end
end

function AP.InstallReturnHooks()
  if not hooksecurefunc then return end
  if C_AuctionHouse and C_AuctionHouse.CancelAuction then
    hooksecurefunc(C_AuctionHouse,"CancelAuction",function(id)
      if not readable(id) then return end
      local ch=AP.Character()
      if not ch then return end
      for _,row in ipairs(ch.active) do
        if row.auctionID==id then row.cancelRequestedAt=time();break end
      end
    end)
  end
  local function take(index,attachment)
    if not watching or not readable(index) or not readable(attachment) or (attachment and attachment~=1) then return end
    local item=rows[index]
    if item then
      local queue=requests[item.key] or {}
      requests[item.key]=queue
      for _,request in ipairs(queue) do if request.item==item then return end end
      if #queue>=(counts[item.key] or 0) then return end
      item.requestedAt=time()
      local ch=AP.Character()
      local attempts=attemptJournal(ch)
      if attempts then
        local journal=ch.returnEvidence
        -- Re-observing an identical single attachment supersedes its failed request.
        for id,e in pairs(attempts) do
          if e.key==item.key and counts[item.key]==1 then attempts[id]=nil
          elseif e.id==item.id then e.unique=false end
        end
        journal.sequence=(journal.sequence or 0)+1
        item.attemptID=journal.sequence
        item.unique=counts[item.key]==1
        for _,other in pairs(rows) do if other~=item and other.id==item.id then item.unique=false end end
        attempts[item.attemptID]=item
      end
      queue[#queue+1]={item=item,at=GetTime()}
      AP.ScanReturns()
    end
  end
  AP.BeforeReturnPickup=take
  if TakeInboxItem then hooksecurefunc("TakeInboxItem",take) end
  if AutoLootMailItem then hooksecurefunc("AutoLootMailItem",function(index) take(index) end) end
end
-- A post can be observed between the request and mailbox disappearance.
function AP.WatchReturnRequests(p,id,suffix)
  for _,queue in pairs(requests) do
    for _,r in ipairs(queue) do
      local e=r.item
      if e.id==p.itemID and (e.suffix or 0)==(suffix or 0) and (not e.level or not p.itemLevel or e.level==p.itemLevel) and e.requestedAt<=p.at then
        e.waiting=e.waiting or {}
        e.waiting[tostring(id)]=true
      end
    end
  end
end
function AP.ReturnCompeting(ch,id)
  local j=ch and ch.returnEvidence
  for _,e in pairs(j and j.attempts or {}) do if e.id==id then e.competing=true end end
end

function AP.ReturnTakeFailed()
  for _,queue in pairs(requests) do for _,r in ipairs(queue) do retire(r.item) end end
  requests={}
end
