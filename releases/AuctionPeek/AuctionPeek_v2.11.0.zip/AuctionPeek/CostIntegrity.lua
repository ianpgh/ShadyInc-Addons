local _, AP = ...
local I = {}
AP.CostIntegrity = I

local function journal(ch)
  ch.costIntegrity = ch.costIntegrity or {version=1, history={}}
  return ch.costIntegrity
end

local function state(post, live)
  if post.returnedUnits or post.remainderTo then return "closed" end
  if post.ownedSold or (post.soldAt and not post.remainingSeen and not post.filled) then return "sold" end
  if post.awaitingReturn then return "pending" end
  if live then return "reserved" end
  return "unresolved"
end

-- Summarize the existing ledger. Nested costs are transfers, so original
-- external spend excludes crafted outputs.
function I.Audit(ch)
  local l = ch.craftLedger or {lots={}, posts={}}
  local totals = {original=0, missing=0, partial=0, discrepancies=0}
  for _,key in ipairs({"available","reserved","pending","sold","unresolved","crafting"}) do
    totals[key]={n=0,cost=0}
  end
  local items, live, sales = {}, {}, {}
  local function add(key,n,cost)
    local t=totals[key]
    t.n,t.cost=t.n+n,t.cost+cost
  end
  local function claim(part, key, n, cost, auction)
    if not part.source then return end
    add(key,n,cost)
    local entry=items[part.source]
    if not entry then return end
    entry.n,entry.cost=entry.n+n,entry.cost+cost
    entry.states[key]=true
    if auction then entry.auctions[#entry.auctions+1]=auction.." ("..key..")" end
  end
  for _,r in ipairs(ch.active or {}) do live[tostring(r.auctionID)]=true end
  for index,x in ipairs(l.lots) do
    items[index]={lot=x,index=index,n=x.left,cost=x.balance,states={},auctions={}}
    add("available",x.left,x.balance)
    if not x.parts then totals.original=totals.original+x.cost end
    if x.parts and x.unknown then totals.partial=totals.partial+1 end
  end
  for _,x in ipairs(l.lots) do
    for _,part in ipairs(x.parts or {}) do claim(part,"crafting",part.n,part.cost) end
  end
  for id,p in pairs(l.posts) do
    local status=state(p,live[id])
    local sold=status=="sold" and (p.quantity or 0) or (p.filled or 0)
    local limit=p.returnedUnits and ((p.quantity or 0)-p.returnedUnits)
      or p.remainderTo and sold or (p.quantity or 0)
    if p.ended and not p.awaitingReturn and not p.returnedUnits and not p.remainderTo
        and sold==0 then limit=0 end -- Legacy cancellation already credited the lot.
    local offset=0
    for _,part in ipairs(p.parts or {}) do
      local n=math.max(0,math.min(part.n,limit-offset))
      local paid=math.max(0,math.min(n,sold-offset))
      local paidCost=math.floor(part.cost*paid/part.n)
      if paid>0 then claim(part,"sold",paid,paidCost,id) end
      if n>paid then
        claim(part,status=="closed" and "unresolved" or status,n-paid,
          math.floor(part.cost*n/part.n)-paidCost,id)
      end
      offset=offset+part.n
    end
  end
  for _,pool in ipairs({ch.sold or {},ch.deleted or {}}) do
    for _,r in ipairs(pool) do
      if r.sold or r.deletedKind=="sold" then
        local p=l.posts[tostring(r.auctionID)]
        local n=AP.Accounting.SaleUnits(r)
        if r.mailFlip then
          claim(r.mailFlip,"sold",1,r.mailFlip.cost,r.receiptID)
        elseif not p or not n or AP.Crafts.AllocationCost(p,0,n).unknown then
          totals.missing=totals.missing+1
          sales[#sales+1]=r
        end
      end
    end
  end
  for _,entry in ipairs(items) do
    local x=entry.lot
    if entry.n~=x.quantity or entry.cost~=x.cost then
      entry.discrepancy=true
      totals.discrepancies=totals.discrepancies+1
    end
    table.sort(entry.auctions)
  end
  return totals,items,sales
end

local function saleFor(ch,id)
  if not ch.craftLedger or not id then return end
  local p=ch.craftLedger.posts[tostring(id)]
  if not p or not p.ownedSold or p.quantity~=1 or (p.filled and p.filled~=1)
      or p.returnedUnits or p.remainderTo or p.ended then return end
  local found
  for _,pool in ipairs({ch.sold or {},ch.deleted or {}}) do
    for _,r in ipairs(pool) do
      if tostring(r.auctionID)==tostring(id) and not r.purchase then
        if found or not r.sold or r.itemID~=p.itemID or not r.receiptID
            or AP.Accounting.SaleUnits(r)~=1 or not AP.Reconciliation.VerifiedProceeds(r) then return end
        found=r
      end
    end
  end
  return found,p
end

function I.Choices(ch,id)
  local choices={}
  local r,p=saleFor(ch,id)
  local part=p and p.parts and #p.parts==1 and p.parts[1]
  if not r or p.costRecovery or not part or part.source or part.n~=1 or not part.unknown
      or part.cost~=0 or not p.at then return choices end
  local _,items=I.Audit(ch)
  for _,entry in ipairs(items) do
    local x=entry.lot
    -- An intact, fully available lot permits exact undo. A returned lot
    -- must have been collected before the target was posted.
    if not entry.discrepancy and x.itemID==r.itemID and (x.itemSuffix or 0)==(r.itemSuffix or 0)
        and x.quantity==1 and x.left==1 and x.balance==x.cost and x.at<=p.at
        and not (x.unknown or x.estimate or x.sourceUncertain or x.looted)
        and (not x.lastReturnedAt or x.lastReturnedAt<=p.at)
        and (x.parts or x.purchase) then
      local buyValid=not x.purchase
      for _,b in ipairs(ch.buys or {}) do
        if b.purchaseID==x.purchase and b.itemID==x.itemID
            and (not b.delivery or b.delivery.stage=="verified") then buyValid=true;break end
      end
      if buyValid then choices[#choices+1]=entry end
    end
  end
  table.sort(choices,function(a,b)
    if a.lot.at~=b.lot.at then return a.lot.at<b.lot.at end
    return a.index<b.index
  end)
  return choices
end

function I.Assign(ch,id,index,automatic)
  for _,entry in ipairs(I.Choices(ch,id)) do
    if index==entry.index then
      local r,p=saleFor(ch,id)
      local x=entry.lot
      if automatic and (not r.repostOf or x.returnedFrom~=r.repostOf) then return end
      local history={auction=tostring(id),receipt=r.receiptID,source=index,cost=x.cost,
        acquisition=x.parts and "crafted" or x.vendor and "vendor" or "purchase",
        previous=x.returnedFrom,method=automatic and "verified_repost" or "manual",
        reason=automatic and "Confirmed return and unique linked repost" or "Player confirmed available lot",at=time()}
      local j=journal(ch)
      j.history[#j.history+1]=history
      p.costRecovery={old=p.parts[1],source=index,history=#j.history,receipt=r.receiptID}
      p.parts={{source=index,itemID=r.itemID,n=1,cost=x.cost,recovered=true,manual=not automatic,
        returnedFrom=x.returnedFrom}}
      x.left,x.balance=0,0
      return true
    end
  end
end

function I.Undo(ch,id)
  local r,p=saleFor(ch,id)
  local u=p and p.costRecovery
  local a=u and p.parts and #p.parts==1 and p.parts[1]
  if not r or not a or r.receiptID~=u.receipt or a.source~=u.source or not a.recovered then return end
  local _,items=I.Audit(ch)
  local entry=items[u.source]
  local x=entry and entry.lot
  if not x or entry.discrepancy or x.quantity~=1 or x.left~=0 or x.balance~=0
      or a.n~=1 or a.cost~=x.cost or #entry.auctions~=1 then return end
  x.left,x.balance=1,x.cost
  p.parts,p.costRecovery={u.old},nil
  p.costRecoveryAutoBlocked=true
  local history=journal(ch).history[u.history]
  if history then history.undoneAt=time() end
  return true
end

-- Old same-item lots by themselves are insufficient. Require reciprocal
-- listing evidence plus a fully available, confirmed returned lot.
function I.RecoverReposts(ch)
  local l=ch.craftLedger
  if not l then return 0,0 end
  local ended={}
  for _,r in ipairs(ch.ended or {}) do
    if r.returnCollectedAt and r.repostedAs then ended[r.auctionID]=r end
  end
  local n,cost=0,0
  for _,r in ipairs(ch.sold or {}) do
    local old=ended[r.repostOf]
    local p=old and l.posts[tostring(r.auctionID)]
    if p and old.repostedAs==r.auctionID and old.itemID==r.itemID
        and (old.itemSuffix or 0)==(r.itemSuffix or 0)
        and not (p.costRecovery or p.costRecoveryAutoBlocked) then
      local choices=I.Choices(ch,r.auctionID)
      local choice=#choices==1 and choices[1]
      if choice and choice.lot.returnedFrom==r.repostOf and I.Assign(ch,r.auctionID,choice.index,true) then
        n,cost=n+1,cost+choice.lot.cost
      end
    end
  end
  return n,cost
end

function I.Reconcile(ch)
  local n,returnedCost=AP.ReconcileReturns(ch)
  local assigned,saleCost=I.RecoverReposts(ch)
  if AP.CostPool then
    local changes,cost,released=AP.CostPool.Reconcile(ch)
    assigned,saleCost=assigned+changes,saleCost+cost
    n=n+released
  end
  local j=journal(ch)
  j.lastReconciled=time()
  j.lastCount=n+assigned
  return n,returnedCost or 0,assigned,saleCost
end

local frame
function I.Open(ch, solid, border, label, money, refresh)
  if not ch then return end
  if frame then frame:Hide() end
  -- Reuse a single frame and its controls on subsequent opens.
  if frame then
    frame.background:SetColorTexture(0,0,0,solid and 1 or .78)
    frame:Show()
    frame:Reload()
    return
  end
  frame=CreateFrame("Frame","AuctionPeekCostIntegrity",UIParent)
  frame:SetSize(700,560)
  frame:SetPoint("CENTER")
  frame:SetFrameStrata("DIALOG")
  frame:SetClampedToScreen(true)
  frame:EnableMouse(true)
  border(frame)
  frame.background:SetColorTexture(0,0,0,solid and 1 or .78)
  if UISpecialFrames then table.insert(UISpecialFrames,"AuctionPeekCostIntegrity") end
  local close=CreateFrame("Button",nil,frame,"UIPanelCloseButton")
  close:SetPoint("TOPRIGHT")
  label(frame,"Inventory Cost Integrity",16,-12,640):SetTextColor(1,.8,.5)
  local summary=label(frame,"",16,-35,668)
  local detail=label(frame,"",16,-358,668)
  local message=label(frame,"",16,-520,668)
  local query=CreateFrame("EditBox",nil,frame,"InputBoxTemplate")
  query:SetSize(229,25)
  query:SetPoint("TOPLEFT",20,-115)
  query:SetAutoFocus(false)
  query:SetText("")
  query:SetScript("OnEscapePressed",function(self) self:ClearFocus(); frame:Hide() end)
  label(frame,"Search by item name, item ID or auction ID",18,-102,300)
  local function button(text,x,y,width,callback)
    local b=CreateFrame("Button",nil,frame,"UIPanelButtonTemplate")
    b:SetSize(width,23)
    b:SetPoint("TOPLEFT",x,y)
    b:SetText(text)
    b:SetScript("OnClick",callback)
    return b
  end
  local totals,items,sales,results,selected,page,filter,review
  local preview, confirmAssign
  page,filter=1,false
  local function itemName(id)
    return id and GetItemInfo and GetItemInfo(id) or ("Item #"..tostring(id or "?"))
  end
  local function price(value)
    return value==0 and "0c" or money(value)
  end
  local function contains(text,word)
    return tostring(text or ""):lower():find(word,1,true)
  end
  local icon=frame:CreateTexture(nil,"ARTWORK")
  icon:SetSize(32,32)
  icon:SetPoint("TOPRIGHT",-16,-358)
  local buttons={}
  local function paint()
    local word=(query:GetText() or ""):lower():match("^%s*(.-)%s*$")
    results={}
    for _,r in ipairs(sales) do
      if contains(r.name,word) or contains(r.itemID,word) or contains(r.auctionID,word) then
        results[#results+1]={sale=r}
      end
    end
    for _,entry in ipairs(items) do
      local x=entry.lot
      if (not filter or x.unknown or entry.discrepancy or entry.states.pending or entry.states.unresolved)
          and (contains(itemName(x.itemID),word) or contains(x.itemID,word)
          or contains(table.concat(entry.auctions," "),word)) then results[#results+1]=entry end
    end
    local evidence=ch.returnEvidence and ch.returnEvidence.pending or {}
    for _,r in ipairs(evidence) do
      if contains(itemName(r.id),word) or contains(r.id,word) then results[#results+1]={pickup=r} end
    end
    if review then results=review end
    page=math.max(1,math.min(page,math.ceil(#results/#buttons)))
    for i,b in ipairs(buttons) do
      local row=results[(page-1)*#buttons+i]
      b.row=row
      b:SetShown(row~=nil)
      if row then
        local x,r,pickup=row.lot,row.sale,row.pickup
        local pending=x and (row.states.pending or row.states.unresolved)
        local p=r and ch.craftLedger and ch.craftLedger.posts[tostring(r.auctionID)]
        local assigned=p and p.costRecovery
        local sign=(r and not assigned or row.discrepancy or (x and x.unknown)) and "|cffff6666X "
          or (pending or pickup) and "|cfffaff44! " or "|cff70ff79✓ "
        b:SetText(sign.."|r"..(pickup and (itemName(pickup.id).." · "..pickup.n.." returned · Auction unresolved") or r and ((r.name or itemName(r.itemID)).." · "
          ..tostring(r.auctionID or r.receiptID or "Receipt pending")..(assigned and " · Assigned" or " · Cost unresolved"))
          or (itemName(x.itemID).." · Lot #"..row.index.." · "..price(x.cost))))
      end
    end
    local j=ch.costIntegrity
    local returns=ch.returnEvidence
    local function amount(key)
      local t=totals[key]
      return t.n.." / "..price(t.cost)
    end
    summary:SetText("Tracked external costs "..price(totals.original)
      .."   Available "..amount("available").."   Reserved "..amount("reserved")
      .."\nPending return "..amount("pending").."   Unresolved / stranded "..amount("unresolved")
      .."\nCrafting transfers "..amount("crafting").."   Sold basis "..amount("sold")
      .."\nSales missing basis "..totals.missing.."   Incomplete crafts "..totals.partial
      .."   Lot variances "..totals.discrepancies.."   Unmatched return pickups "..(returns and #returns.pending or 0)
      .."\nLast manual check "..(j and j.lastReconciled and date("%b %d %I:%M %p",j.lastReconciled) or "—")
      .."   Page "..page.."/"..math.max(1,math.ceil(#results/#buttons)))
  end
  function frame:Reload()
    totals,items,sales=I.Audit(ch)
    local shown={}
    for _,r in ipairs(sales) do shown[tostring(r.auctionID)]=true end
    for _,r in ipairs(ch.sold or {}) do
      local p=ch.craftLedger and ch.craftLedger.posts[tostring(r.auctionID)]
      if p and p.costRecovery and not shown[tostring(r.auctionID)] then sales[#sales+1]=r end
    end
    paint()
  end
  for i=1,7 do
    buttons[i]=button("",16,-147-(i-1)*25,667,function(b)
      selected=b.row
      confirmAssign=nil
      local x,r,pickup=selected.lot,selected.sale,selected.pickup
      local id=r and r.itemID or x and x.itemID or pickup and pickup.id
      icon:SetTexture(id and GetItemIcon and GetItemIcon(id))
      if pickup then
        detail:SetText(itemName(pickup.id).." · Item #"..pickup.id.." · "..pickup.n.." × "..pickup.reason
          .."\nConfirmed pickup at "..date("%b %d %I:%M %p",pickup.at)
          .."\nThe auction reservation remains unresolved until matching evidence is sufficient.")
      elseif r then
        local p=ch.craftLedger and ch.craftLedger.posts[tostring(r.auctionID)]
        detail:SetText((r.name or itemName(r.itemID)).." · Item #"..tostring(r.itemID)
          .."\n"..(p and p.costRecovery and "✓ Recorded lot assigned. Undo restores the lot." or
            "X Acquisition cost is unresolved. Review eligible recorded lots."))
      else
        local source=x.parts and "Crafted" or x.vendor and "Vendor" or x.purchase and "Purchase"
          or x.looted and "Looted" or "Other"
        local parts={}
        for _,a in ipairs(x.parts or {}) do
          parts[#parts+1]=a.n.." × "..itemName(a.itemID).." "..(a.unknown and "known portion " or "")..price(a.cost)
        end
        detail:SetText(itemName(x.itemID).." · Item #"..x.itemID.." · "..source
          .." · "..(x.at>0 and date("%b %d %I:%M %p",x.at) or "Date unknown")
          .."\nOriginal "..x.quantity.." / "..price(x.cost).."   Available "..x.left.." / "..price(x.balance)
          .."\nAuctions "..(#selected.auctions>0 and table.concat(selected.auctions,", ",1,math.min(4,#selected.auctions)) or "—")
          .."\n"..(#parts>0 and table.concat(parts,", ",1,math.min(10,#parts)) or ""))
      end
    end)
  end
  button("Previous",16,-325,76,function() page=page-1;paint() end)
  button("Next",96,-325,76,function() page=page+1;paint() end)
  button("Unresolved / All",260,-115,130,function()
    filter=not filter; review=nil; page=1;paint()
  end)
  button("Reconcile Inventory Costs",406,-115,213,function(b)
    if not preview then
      preview=true
      local j=ch.returnEvidence
      message:SetText((j and #j.pending or 0).." unmatched pickups to check. Click Apply to retry supported returns.")
      b:SetText("Apply reconciliation")
    else
      preview=false
      b:SetText("Reconcile Inventory Costs")
      local count,recovered,assigned,saleCost=I.Reconcile(ch)
      review=nil
      frame:Reload()
      local j=ch.returnEvidence
      message:SetText(count.." returns matched ("..price(recovered).."). "..assigned.." sales assigned ("
        ..price(saleCost).."). "..(j and #j.pending or 0).." pickups remain unmatched.")
      if count+assigned>0 then refresh() end
    end
  end)
  button("Review cost lots",16,-479,135,function()
    if not selected or not selected.sale then message:SetText("Select a sale first.");return end
    local id=selected.sale.auctionID
    review=I.Choices(ch,id)
    confirmAssign=nil
    frame.reviewID=id
    selected=nil
    page=1
    detail:SetText("Available, balanced lots acquired before posting. Confirm the actual source before assigning.")
    message:SetText(#review.." eligible lots. Clear review to return to the ledger.")
    paint()
  end)
  button("Assign selected lot",158,-479,142,function()
    if not selected or not selected.lot or not review then message:SetText("Select an eligible lot first.");return end
    if confirmAssign~=selected.index then
      confirmAssign=selected.index
      message:SetText("Click Assign selected lot again to confirm lot #"..selected.index..".")
      return
    end
    local ok=I.Assign(ch,frame.reviewID,selected.index)
    review,selected,confirmAssign=nil,nil,nil
    frame:Reload()
    if ok then refresh() end
    message:SetText(ok and "✓ Cost assigned. Select the sale and click Undo assignment to reverse it." or "X Eligibility changed.")
  end)
  button("Undo assignment",307,-479,134,function()
    if not selected or not selected.sale then message:SetText("Select a sale with an assigned lot.");return end
    local ok=I.Undo(ch,selected.sale.auctionID)
    frame:Reload()
    if ok then refresh() end
    message:SetText(ok and "✓ Original lot balance restored." or "X No safe assignment to undo.")
  end)
  button("Clear review",448,-479,108,function()
    review,selected,confirmAssign=nil,nil,nil
    detail:SetText("")
    message:SetText("")
    paint()
  end)
  query:SetScript("OnTextChanged",function() review,selected,confirmAssign=nil,nil,nil;page=1;paint() end)
  frame:Reload()
end
