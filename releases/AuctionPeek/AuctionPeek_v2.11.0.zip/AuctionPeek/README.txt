Auction Peek 2.11.0 Personal Recovery Edition · unpublished build pending approval for distribution.

Extract AuctionPeek into Interface/AddOns with the game closed. Back up WTF before upgrading. Open Accounting Health from Unmatched or use /ap health.

The audit kit contains the migration guide, verification results and live checklist.
