local _, AP=...
local P={}; AP.PersonalRecovery=P
-- Personal-only evidence extracted from the player's November 26 backup.
-- No price or cost is assigned here; normal conservative recovery must pass.
function P.Restore(ch)
  local l=ch.craftLedger
  local x=l and l.lots[1294]
  local post=l and l.posts['225173046']
  if not x or x.itemID~=10031 or x.at~=1795678043 or x.cost~=12988 or not x.unknown
    or not post or post.itemID~=10031 or post.at~=1795678083 or #post.parts~=1 or post.parts[1].source~=1294 then return end
  local buy
  for _,b in ipairs(ch.buys or {}) do if b.purchaseID==399 then buy=b;break end end
  if not buy or buy.itemID~=4339 or buy.quantity~=6 or buy.price~=12192 or buy.boughtAt~=1795677943
    or not buy.delivery or buy.delivery.stage=='verified' then return end
  local j=ch.inventoryReconciliation
  if not j or not j.observations then return end
  local evidence={
    {itemID=4339,at=1795677962,before=0,after=6,delta=6,evidence={GENERIC_ITEM_RECEIPT=6},reason='UNRESOLVED_BAG_CHANGE'},
    {itemID=4339,at=1795678043,before=6,after=0,delta=-6,evidence={CRAFT_INPUT=-6},reason='EVENTS_AGREE'},
  }
  local seen={}
  for _,o in ipairs(j.observations) do
    if o.itemID==4339 and o.at>=buy.boughtAt and o.at<=x.at then
      local match
      for i,e in ipairs(evidence) do
        if o.at==e.at and o.before==e.before and o.after==e.after and o.delta==e.delta and not o.bankOpen then
          local same=true
          for k,v in pairs(o.evidence or {}) do if e.evidence[k]~=v then same=false end end
          for k,v in pairs(e.evidence) do if (o.evidence or {})[k]~=v then same=false end end
          if same then match=i end
        end
      end
      if not match or seen[match] then return end
      seen[match]=true
    end
  end
  for i,e in ipairs(evidence) do if not seen[i] then e.backupRecovered=true;j.observations[#j.observations+1]=e end end
  j.personalRecoveryV2103=true
end
