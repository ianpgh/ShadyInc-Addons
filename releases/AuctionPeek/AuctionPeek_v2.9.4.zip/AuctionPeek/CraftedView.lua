local _, AP = ...
local V={}
AP.CraftedView=V

local function name(id)
  return (C_Item and C_Item.GetItemNameByID and C_Item.GetItemNameByID(id))
    or (GetItemInfo and GetItemInfo(id)) or "Item #"..tostring(id)
end
local function money(n)
  if n==0 then return "0c" end
  return AP.Money(n)
end
local function confidence(row)
  if row.unknown then return "|cffff6464✗ Incomplete|r" end
  if row.estimate then return "|cffffff00! Estimated|r" end
  return "|cff52ff76✓ Verified|r"
end
local function origin(x)
  if x.vendor then return "Vendor" end
  if x.purchase or x.auctionID then return "AH" end
  if x.looted then return "Loot" end
  return "Unresolved"
end

function V.Rows(ch,issues)
  local l=ch.craftLedger
  if not l then return {} end
  local evidence,used,posts,sales,bagLots={},{},{},{},{}
  for i,x in ipairs(l.lots) do
    if x.left>0 then bagLots[x.itemID]=(bagLots[x.itemID] or 0)+x.left end
    if x.parts then
      local t={unknown=x.unknown,estimate=x.estimate,sources={}}
      for _,p in ipairs(x.parts) do
        local child=evidence[p.source]
        t.unknown=t.unknown or p.unknown or (child and child.unknown)
        t.estimate=t.estimate or p.estimate or (child and child.estimate)
        if child then
          for source in pairs(child.sources) do t.sources[source]=true end
        else
          local src=l.lots[p.source]
          local kind=p.confirmedLoot and "Loot" or src and origin(src) or "Unresolved"
          t.sources[kind]=true
          if kind=="Unresolved" and not p.costEstimateEvidence then t.unknown=true end
        end
        if p.source then used[p.source]=(used[p.source] or 0)+p.n end
      end
      evidence[i]=t
    end
  end
  local active={}
  for _,r in ipairs(ch.active or {}) do active[tostring(r.auctionID)]=true end
  for _,r in ipairs(ch.sold or {}) do
    if r.auctionID then sales[tostring(r.auctionID)]=r end
  end
  for id,p in pairs(l.posts) do
    for _,part in ipairs(p.parts or {}) do
      if evidence[part.source] and not p.remainderTo then
        local a=posts[part.source] or {}
        posts[part.source]=a
        a[#a+1]={id=id,post=p,sale=sales[id],active=active[id]}
      end
    end
  end
  local rows,counts={},{}
  for i,t in pairs(evidence) do
    if (t.sources.AH or t.sources.Vendor or t.unknown or t.estimate) and (not issues or t.unknown or t.estimate) then
      local x=l.lots[i]
      local keys={}
      for _,source in ipairs({"AH","Vendor","Loot","Unresolved"}) do
        if t.sources[source] then keys[#keys+1]=source end
      end
      local relevant=posts[i] or {}
      local status="Unknown"
      table.sort(relevant,function(a,b) return a.post.at>b.post.at end)
      local latest=relevant[1]
      if latest and not latest.post.returnedUnits then
        local p=latest.post
        if p.filled and p.filled>0 and p.filled<p.quantity then status="Partially Sold"
        elseif latest.sale and (p.ownedSold or p.filled==p.quantity) then status="Sold"
        elseif latest.active and not p.ended then status="Listed" end
      end
      if status=="Unknown" then
        if (used[i] or 0)>0 and x.left==0 then status="Used in Craft"
        elseif x.left>0 then
          if counts[x.itemID]==nil then counts[x.itemID]=AP.Reconciliation.Count(x.itemID) or false end
          if counts[x.itemID] and counts[x.itemID]>=bagLots[x.itemID] then status="In Bags" end
        end
      end
      rows[#rows+1]={lot=x,index=i,name=name(x.itemID),status=status,source=table.concat(keys," + "),
        unknown=t.unknown,estimate=t.estimate,posts=relevant}
    end
  end
  return rows
end

function V.Details(ch,row)
  local lines={row.name.." ×"..row.lot.quantity.."    "..confidence(row),
    date("%b %d %Y %I:%M %p",row.lot.at).."    Craft lot #"..row.index,
    "Recorded acquisition cost "..money(row.lot.cost).."    Ledger quantity remaining "..row.lot.left,""}
  local lots=ch.craftLedger.lots
  local function trace(parts,prefix,depth)
    if depth>12 then lines[#lines+1]=prefix.."Further ingredients are recorded in the referenced lot";return end
    for _,p in ipairs(parts) do
      if #lines>=220 then return end
      local src=lots[p.source]
      local kind=p.confirmedLoot and "Player-confirmed loot" or src and (src.parts and "Craft" or origin(src)) or "Unresolved"
      if p.costEstimateEvidence then kind="Historical estimate" end
      local desc=prefix..p.n.." × "..name(p.itemID).." · "..kind.." · "..money(p.cost)
      if src then desc=desc.." · Lot #"..p.source..(src.purchase and " · Purchase #"..src.purchase or "") end
      if p.unknown or p.estimate or p.confirmedLoot then desc=desc.." · "..(p.reason or (p.unknown and "Unresolved cost or source" or "Estimated")) end
      lines[#lines+1]=desc
      if src and src.parts then
        lines[#lines+1]=prefix.."  Source batch (all "..src.quantity.." units)"
        trace(src.parts,prefix.."    ",depth+1)
      end
    end
  end
  if row.unknown then lines[#lines+1]="Some ingredient quantities or sources are unresolved." end
  if row.estimate then lines[#lines+1]="At least one cost or allocation is estimated." end
  trace(row.lot.parts,"",1)
  local seen={}
  for _,a in ipairs(row.posts) do
    if not seen[a.id] then
      seen[a.id]=true
      local r=a.sale
      local line="Auction #"..a.id
      local net=AP.Reconciliation.VerifiedProceeds(r)
      if net then
        line=line.." · Verified proceeds "..money(net)
        local p=a.post
        local units=r.receiptQty or r.quantity
        if not (row.unknown or row.estimate) and units==p.quantity and #p.parts==1 and p.parts[1].source==row.index
            and not p.parts[1].unknown and not p.parts[1].estimate and p.parts[1].n==p.quantity then
          local profit=net-p.parts[1].cost
          line=line.." · Realized profit "..(profit<0 and "−" or "+")..money(math.abs(profit))
        end
      elseif r then line=line.." · Payment pending" end
      lines[#lines+1]=line
    end
  end
  return table.concat(lines,"\n")
end

function V.LayoutTabs(panel,enabled)
  if not panel.tabs or not panel.tabs.crafted then return end
  for i,key in ipairs({"listed","recent","all","buys","flip","de","crafted"}) do
    local tab=panel.tabs[key]
    tab:ClearAllPoints()
    tab:SetPoint("TOPLEFT",panel,"TOPLEFT",8+(i-1)*(enabled and 89 or 104),-33)
    tab:SetWidth(enabled and 86 or 99)
  end
  panel.tabs.crafted:SetShown(enabled)
end

function V.Show(parent,ch,shown)
  if not shown then if parent.craftedView then parent.craftedView:Hide() end;return end
  local frame=parent.craftedView
  if not frame then
    frame=CreateFrame("Frame",nil,parent)
    parent.craftedView=frame
    frame:SetPoint("TOPLEFT",parent,"TOPLEFT",12,-64)
    frame:SetPoint("BOTTOMRIGHT",parent,"BOTTOMRIGHT",-15,12)
    local function text(owner)
      local t=owner:CreateFontString(nil,"ARTWORK","GameFontHighlightSmall")
      t:SetJustifyH("LEFT")
      return t
    end
    local function button(title,width)
      local b=CreateFrame("Button",nil,frame,"UIPanelButtonTemplate")
      b:SetSize(width,22)
      b:SetText(title)
      return b
    end
    local search=CreateFrame("EditBox",nil,frame,"InputBoxTemplate")
    search:SetSize(230,22)
    search:SetPoint("TOPLEFT",6,0)
    search:SetAutoFocus(false)
    search:SetScript("OnEscapePressed",function(self) self:ClearFocus() end)
    search:SetScript("OnEnterPressed",function(self) self:ClearFocus() end)
    local issues=CreateFrame("CheckButton",nil,frame,"UICheckButtonTemplate")
    issues:SetSize(24,24)
    issues:SetPoint("LEFT",search,"RIGHT",7,0)
    local label=text(issues)
    label:SetPoint("LEFT",issues,"RIGHT",0,0)
    label:SetText("Issues Only")
    issues:SetHitRectInsets(0,-70,0,0)
    local sort=button("Newest",94)
    sort:SetPoint("TOPRIGHT")
    local prev,nextPage=button("‹",28),button("›",28)
    prev:SetPoint("BOTTOMLEFT")
    nextPage:SetPoint("LEFT",prev,"RIGHT",2,0)
    local pageText=text(frame)
    pageText:SetPoint("LEFT",nextPage,"RIGHT",8,0)
    local back=button("Back",72)
    back:SetPoint("BOTTOMRIGHT")
    local scroll=CreateFrame("ScrollFrame",nil,frame,"UIPanelScrollFrameTemplate")
    scroll:SetPoint("TOPLEFT",0,-30)
    scroll:SetPoint("BOTTOMRIGHT",-24,26)
    local content=CreateFrame("Frame",nil,scroll)
    content:SetSize(580,1)
    scroll:SetScrollChild(content)
    local detail=text(content)
    detail:SetPoint("TOPLEFT",4,-4)
    detail:SetWidth(565)
    detail:SetJustifyV("TOP")
    detail:SetWordWrap(true)
    local buttons={}
    local page,mode,selected=1,1,nil
    local modes={"Newest","Name","Highest cost"}
    local function paint()
      local rows=V.Rows(ch,issues:GetChecked())
      local q=(search:GetText() or ""):lower():match("^%s*(.-)%s*$")
      local filtered={}
      for _,row in ipairs(rows) do
        if q=="" or row.name:lower():find(q,1,true) or tostring(row.lot.itemID):find(q,1,true) then
          filtered[#filtered+1]=row
        end
      end
      table.sort(filtered,function(a,b)
        if mode==2 and a.name~=b.name then return a.name<b.name end
        if mode==3 and a.lot.cost~=b.lot.cost then return a.lot.cost>b.lot.cost end
        return a.index>b.index
      end)
      local pages=math.max(1,math.ceil(#filtered/18))
      page=math.max(1,math.min(page,pages))
      local opened
      for _,r in ipairs(filtered) do if r.index==selected then opened=r;break end end
      if not opened then selected=nil end
      pageText:SetText("Search item or ID  ·  "..page.."/"..pages.."  ·  "..#filtered.." crafts")
      prev:SetShown(not opened and page>1)
      nextPage:SetShown(not opened and page<pages)
      back:SetShown(opened~=nil)
      for i,b in ipairs(buttons) do
        local r=not opened and filtered[(page-1)*18+i]
        b.row=r
        b:SetShown(r~=nil and r~=false)
        if r then
          b.label:SetText(("%s ×%d    %s    %s    %s    %s"):format(r.name,r.lot.quantity,r.source,
            money(r.lot.cost),r.status,confidence(r)))
          local icon=(C_Item and C_Item.GetItemIconByID and C_Item.GetItemIconByID(r.lot.itemID))
            or (GetItemIcon and GetItemIcon(r.lot.itemID))
          b.icon:SetTexture(icon or 134400)
        end
      end
      if opened or #filtered==0 then
        detail:SetText(opened and V.Details(ch,opened) or "No matching crafted records.")
        detail:Show()
        content:SetHeight(math.max(22,detail:GetStringHeight()+12))
      else
        detail:Hide()
        content:SetHeight(math.max(22,math.min(18,#filtered-(page-1)*18)*23))
      end
    end
    for i=1,18 do
      local b=CreateFrame("Button",nil,content)
      b:SetPoint("TOPLEFT",0,-23*(i-1))
      b:SetSize(578,23)
      b:SetHighlightTexture("Interface\\QuestFrame\\UI-QuestTitleHighlight")
      b.icon=b:CreateTexture(nil,"ARTWORK")
      b.icon:SetSize(17,17)
      b.icon:SetPoint("LEFT",3,0)
      b.label=text(b)
      b.label:SetPoint("LEFT",24,0)
      b:SetScript("OnClick",function() if b.row then selected=b.row.index;scroll:SetVerticalScroll(0);paint() end end)
      buttons[i]=b
    end
    local function reset()
      page,selected=1,nil
      scroll:SetVerticalScroll(0)
      paint()
    end
    search:SetScript("OnTextChanged",reset)
    issues:SetScript("OnClick",reset)
    sort:SetScript("OnClick",function()
      mode=mode%#modes+1
      sort:SetText(modes[mode])
      reset()
    end)
    prev:SetScript("OnClick",function() page=page-1;scroll:SetVerticalScroll(0);paint() end)
    nextPage:SetScript("OnClick",function() page=page+1;scroll:SetVerticalScroll(0);paint() end)
    back:SetScript("OnClick",function() selected=nil;scroll:SetVerticalScroll(0);paint() end)
    frame.Paint=paint
  end
  frame:Show()
  frame.Paint()
end
