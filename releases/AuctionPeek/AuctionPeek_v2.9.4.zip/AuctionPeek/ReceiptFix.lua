-- Auction Peek 2.5.45 | Explicit, guarded reconciliation of a 2026-11-23 save.
-- No changes are made until /ap repairreceipts confirm. No external API calls.
local _, AP = ...

local function one(ch, kind, field, value)
  local result, index, count
  for _, poolName in ipairs({"active", "sold", "ended", "deleted"}) do
    for i, row in ipairs(ch[poolName] or {}) do
      if row[field] == value then
        count = (count or 0) + 1
        if count > 1 then return nil, nil, "Duplicate "..field.." "..tostring(value) end
        result, index, kind = row, i, poolName
      end
    end
  end
  if count ~= 1 then return nil, nil, "Missing "..field.." "..tostring(value) end
  return result, {pool=kind,index=index}
end

local function invoice(r, name, qty, gross, fee, dep, net)
  return r and r.mailOnly == true and r.auctionID == nil and r.sold == true
    and r.name == name and r.receiptQuantityKnown == true
    and r.receiptQty == qty and r.quantity == qty
    and r.verifiedGross == gross and r.verifiedCut == fee
    and r.verifiedDeposit == dep and r.verifiedNet == net
    and r.observedAt and r.soldAt and gross - fee + dep == net
end

local fields = {"receiptID", "verifiedGross", "verifiedNet", "verifiedCut",
  "verifiedDeposit", "receiptBuyer", "receiptQty", "receiptQuantityKnown",
  "observedAt", "reconciledAt"}

local function removeSavedInvoices(ch,receipts)
  for i=#ch.sold,1,-1 do
    for _,r in ipairs(receipts) do
      if ch.sold[i]==r then table.remove(ch.sold,i); break end
    end
  end
end

-- Validate every dependency BEFORE performing any mutation.
function AP.RepairReceipts20261123(ch,apply)
  if type(ch)~="table" then return false,"No Auction Peek character profile loaded" end
  if ch.receiptFix20261123 then return false,"This targeted repair was already applied" end
  local l=ch.craftLedger
  if not l or type(l.posts)~="table" or type(l.lots)~="table" then
    return false,"No original posting/cost ledger; nothing changed" end

  local r169,where169,err = one(ch,nil,"receiptID","mail:169")
  if not r169 then return false,err end
  local r154,where154,e154 = one(ch,nil,"receiptID","mail:154")
  if not r154 then return false,e154 end
  local r37,where37,e37 = one(ch,nil,"receiptID","mail:37")
  if not r37 then return false,e37 end
  local r38,where38,e38 = one(ch,nil,"receiptID","mail:38")
  if not r38 then return false,e38 end
  local r39,where39,e39 = one(ch,nil,"receiptID","mail:39")
  if not r39 then return false,e39 end
  if where169.pool~="sold" or where154.pool~="sold" or
      where37.pool~="sold" or where38.pool~="sold" or where39.pool~="sold" or
      not invoice(r169,"Gray Dye",18,6300,315,312,6297) or
      not invoice(r154,"Gray Dye",2,700,35,34,699) or
      not invoice(r37,"Formula: Lesser Mana Oil",1,20000,1000,500,19500) or
      not invoice(r38,"Formula: Lesser Mana Oil",1,24000,1200,500,23300) or
      not invoice(r39,"Formula: Lesser Mana Oil",1,20000,1000,500,19500) then
    return false,"Receipt details changed; no saved data modified" end
  if not (r154.observedAt < r169.observedAt and r154.observedAt>=1795412470
      and r169.observedAt<=1795440900) then
    return false,"Gray Dye receipt timing differs from audited history" end

  local dye,wd,ed=one(ch,nil,"auctionID",183438400)
  if not dye then return false,ed end
  local pd=l.posts["183438400"]
  if wd.pool~="sold" or dye.name~="Gray Dye" or dye.itemID~=4340
      or not dye.sold or dye.receiptID or dye.quantity~=9 or dye.buyout~=3150
      or dye.soldAt~=1795412470 or not pd or pd.itemID~=4340
      or pd.quantity~=20 or pd.totalPrice~=350 or pd.at~=1795412456
      or pd.soldAt~=dye.soldAt or pd.ended~="canceled" or not pd.awaitingReturn
      or pd.returnedUnits or pd.remainderTo or pd.fills or pd.filled or pd.gross
      or pd.remainingSeen or #(pd.parts or {})~=1
      or pd.parts[1].itemID~=4340 or pd.parts[1].n~=20
      or pd.parts[1].cost~=6300 or not pd.parts[1].source then
    return false,"Third Gray Dye auction no longer matches audited partial snapshot" end
  local dl=l.lots[pd.parts[1].source]
  if not dl or dl.itemID~=4340 or dl.quantity~=20 or dl.cost~=6300 then
    return false,"Gray Dye purchase cost no longer matches; nothing changed" end

  -- Mail identifiers do not disclose which of the two identically priced
  -- formulas belongs to which auction; assign deterministically as a GROUP.
  local mappings={
    {"155255299",r37,20000},
    {"155126689",r38,24000},
    {"155369986",r39,20000},
  }
  for _,entry in ipairs(mappings) do
    local key,r,gross=entry[1],entry[2],entry[3]
    local sale,where,why=one(ch,nil,"auctionID",tonumber(key))
    if not sale then return false,why end
    local p=l.posts[key]
    if where.pool~="ended" or sale.endedReason~="unconfirmed"
        or sale.name~="Formula: Lesser Mana Oil" or sale.itemID~=20754
        or sale.quantity~=1 or sale.buyout~=gross or sale.receiptID
        or sale.sold or sale.returnCollectedAt or sale.cancelRequestedAt
        or not sale.firstSeenAt or sale.firstSeenAt>r.observedAt
        or not p or p.itemID and p.itemID~=20754 or p.quantity~=1
        or p.at and p.at>r.observedAt or (p.totalPrice and p.totalPrice~=gross)
        or p.ended or p.gross or p.filled or p.fills or p.soldAt or p.returnedUnits
        or p.remainderTo or not p.unresolved or #(p.parts or {})~=1 then
      return false,"Formula auction #"..key.." changed; no data modified" end
    local part=p.parts[1]
    local costLot=part.source and l.lots[part.source]
    if part.itemID~=20754 or part.n~=1 or part.cost~=9500 or part.unknown
        or not costLot or costLot.itemID~=20754 or costLot.cost~=9500 then
      return false,"Formula source cost #"..key.." is not verified" end
    entry[4],entry[5]=sale,p
  end
  for _,post in pairs(l.posts) do
    for _,r in ipairs({r169,r154,r37,r38,r39}) do
      if post.fills and post.fills[r.receiptID] then
        return false,"Receipt "..r.receiptID.." already allocated to an auction" end
    end
  end
  if not apply then
    return true,"Ready: merge 18+2 Gray Dye into #183438400 (20 total); link three formula receipts to costed auctions. No changes made." end

  pd.fills={}
  for _,r in ipairs({r154,r169}) do
    pd.fills[r.receiptID]={quantity=r.receiptQty,gross=r.verifiedGross,
      net=r.verifiedNet,fee=r.verifiedCut,deposit=r.verifiedDeposit,
      buyer=r.receiptBuyer,observedAt=r.observedAt,reconciledAt=r.reconciledAt}
  end
  pd.filled,pd.gross,pd.cut=20,7000,350
  pd.ended,pd.awaitingReturn,pd.unresolved=nil,nil,nil
  pd.ownedSold=true
  dye.quantity,dye.buyout,dye.receiptQty=20,7000,20
  dye.receiptQuantityKnown,dye.receiptID=true,"mail:154"
  dye.verifiedGross,dye.verifiedNet,dye.verifiedCut,dye.verifiedDeposit=7000,6996,350,346
  dye.observedAt,dye.reconciledAt=r169.observedAt,r169.reconciledAt
  dye.receiptGroup="mail:154, mail:169"
  dye.receiptBuyer=nil
  dye.groupInvoiceBuyer=nil

  for _,entry in ipairs(mappings) do
    local r,sale,p=entry[2],entry[4],entry[5]
    for i=#ch.ended,1,-1 do
      if ch.ended[i]==sale then table.remove(ch.ended,i);break end
    end
    sale.endedReason,sale.endedAt=nil,nil
    sale.sold,sale.soldAt=true,r.soldAt
    sale.manualPayment=true
    sale.mailOnly=nil
    for _,f in ipairs(fields) do sale[f]=r[f] end
    if entry[3]==20000 then
      sale.receiptGroup="mail:37, mail:39"
      sale.groupInvoiceBuyer=r.receiptBuyer
      sale.receiptBuyer=nil -- Buyer-to-auction ID cannot be independently proven.
    end
    p.ended,p.unresolved,p.awaitingReturn=nil,nil,nil
    p.soldAt,p.ownedSold=r.soldAt,true
    p.totalPrice=p.totalPrice or sale.buyout
    AP.Crafts.Sale(ch,sale)
    table.insert(ch.sold,sale)
  end
  removeSavedInvoices(ch,{r169,r154,r37,r38,r39})
  table.sort(ch.sold,function(a,b)return (a.soldAt or 0)>(b.soldAt or 0) end)
  ch.receiptFix20261123={version="2.5.45",appliedAt=time(),
    grayAuction=183438400,formulaAuctions="155255299,155126689,155369986",
    receipts="mail:37,mail:38,mail:39,mail:154,mail:169"}
  return true,"Repaired five verified receipts: Gray Dye 20/20 and three formula sales; original costs preserved."
end
