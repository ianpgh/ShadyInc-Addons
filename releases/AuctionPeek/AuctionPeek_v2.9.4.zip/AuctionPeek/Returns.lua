-- Observe item returns independently from seller invoices.
local _, AP = ...
local rows, counts, requests = {}, {}, {}
local watching = false

local function readable(v)
  return not issecretvalue or not issecretvalue(v)
end

local function returnedItem(index)
  local _,_,sender,subject,money,cod,_,hasItem = GetInboxHeaderInfo(index)
  if not readable(sender) or not readable(subject) or not readable(money) or not readable(cod)
      or not money or not cod then return nil,false end
  if money~=0 or cod~=0 or type(subject)~="string" then return end
  if sender~="Auction House" and (not AUCTION_HOUSE or sender~=AUCTION_HOUSE) then return end
  local name,id,_,n=GetInboxItem(index,1)
  if not readable(name) or not readable(id) or not readable(n) then return nil,false end
  if not name then
    if not readable(hasItem) or (hasItem and hasItem~=0) then return nil,false end
    return
  end
  if type(id)~="number" or type(n)~="number" or n<1 then return nil,false end
  -- Stacked attachments may include their quantity in the auction subject.
  local suffix=" ("..n..")"
  if subject:sub(-#suffix)==suffix then subject=subject:sub(1,-#suffix-1) end
  local function subjectMatches(template)
    return type(template)=="string" and subject==template:gsub("%%s",function() return name end)
  end
  local reason
  if subjectMatches(AUCTION_REMOVED_MAIL_SUBJECT) or subjectMatches(AUCTION_CANCELED_MAIL_SUBJECT) or subject=="Auction cancelled: "..name
      or subject=="Auction canceled: "..name then reason="canceled"
  elseif subjectMatches(AUCTION_EXPIRED_MAIL_SUBJECT) or subject=="Auction expired: "..name then reason="expired"
  else return end
  return {id=id,n=n,reason=reason,key=reason.."/"..id.."/"..n}
end

local function confirm(ch,item)
  if not ch then return end
  local posts=ch.craftLedger and ch.craftLedger.posts or {}
  local candidates,seen={},{}
  local now=time()
  for _,pool in ipairs({ch.ended,ch.active,ch.deleted,ch.sold}) do
    for _,row in ipairs(pool) do
      local key=tostring(row.auctionID)
      if row.itemID==item.id and row.auctionID and not seen[key] and not row.returnCollectedAt then
        local p=posts[key]
        local n=p and AP.Crafts.ReturnQuantity(p)
        local partial=p and (p.filled or p.remainingSeen)
        local exact=row.endedReason==item.reason or (p and p.ended==item.reason)
        local lastSeen=row.seenAt or row.firstSeenAt
        local timely=lastSeen and now>=lastSeen and now-lastSeen<=86400
          and (item.reason~="expired" or (row.endTime and row.endTime<=now+5))
        if (n==item.n or (not p and row.quantity==item.n)) and (not row.sold or partial)
            and (not row.endedReason or row.endedReason=="unconfirmed" or row.endedReason==item.reason)
            and (not p or not p.ended or p.ended==item.reason) and (exact or timely) then
          seen[key]=true
          candidates[#candidates+1]={row=row,post=p,exact=exact}
        end
      end
    end
  end
  if #candidates==0 then return end
  local inferred=#candidates>1
  if inferred then
    -- Compatible units from independently confirmed end events can return
    -- to a FIFO cost pool. An active or unresolved lookalike is insufficient.
    for _,c in ipairs(candidates) do if not c.exact or not c.post then return end end
    table.sort(candidates,function(a,b)
      local x,y=a.row.endedAt or a.post.endedAt or a.post.at,
        b.row.endedAt or b.post.endedAt or b.post.at
      if x~=y then return x<y end
      return a.row.auctionID<b.row.auctionID
    end)
  end
  local target,post=candidates[1].row,candidates[1].post
  if post and not AP.Crafts.CollectReturn(ch,post,item.n,item.reason,target.auctionID,inferred) then return end
  target.returnCollectedAt=now
  target.endedReason=item.reason
  if AP.QueueReceiptReview then AP.QueueReceiptReview() end
  return true
end

function AP.ScanReturns()
  if not watching or not GetInboxItem or not GetInboxNumItems then return end
  local n=GetInboxNumItems()
  if not readable(n) or type(n)~="number" or n>200 then return end
  local fresh,totals={},{}
  for i=1,n do
    local item,valid=returnedItem(i)
    if valid==false then return end
    if item then fresh[i]=item; totals[item.key]=(totals[item.key] or 0)+1 end
  end
  for key,queue in pairs(requests) do
    local gone=math.max(0,(counts[key] or 0)-(totals[key] or 0))
    for i=#queue,1,-1 do
      local request=queue[i]
      if GetTime()-request.at>10 then table.remove(queue,i)
      elseif gone>0 then
        gone=gone-1
        table.remove(queue,i)
        local ch=AP.Character()
        if not confirm(ch,request.item) and ch then
          ch.returnDiagnostics=ch.returnDiagnostics or {}
          local entries=ch.returnDiagnostics
          entries[#entries+1]={itemID=request.item.id,quantity=request.item.n,at=time(),reason="UNMATCHED_RETURN"}
          if #entries>40 then table.remove(entries,1) end
        end
      end
    end
    if #queue==0 then requests[key]=nil end
  end
  for index,item in pairs(fresh) do
    if rows[index] and rows[index].key==item.key and counts[item.key]==totals[item.key] then
      fresh[index]=rows[index]
    end
  end
  rows,counts=fresh,totals
end

function AP.ReturnMailbox(open)
  rows,counts,requests={},{},{}
  watching=open
  if open then AP.ScanReturns() end
end

function AP.InstallReturnHooks()
  if not hooksecurefunc then return end
  if C_AuctionHouse and C_AuctionHouse.CancelAuction then
    hooksecurefunc(C_AuctionHouse,"CancelAuction",function(id)
      if not readable(id) then return end
      local ch=AP.Character()
      if not ch then return end
      for _,row in ipairs(ch.active) do
        if row.auctionID==id then row.cancelRequestedAt=time();break end
      end
    end)
  end
  local function take(index,attachment)
    if not watching or not readable(index) or not readable(attachment) or (attachment and attachment~=1) then return end
    local item=rows[index]
    if item then
      local queue=requests[item.key] or {}
      requests[item.key]=queue
      for _,request in ipairs(queue) do if request.item==item then return end end
      if #queue>=(counts[item.key] or 0) then return end
      queue[#queue+1]={item=item,at=GetTime()}
      AP.ScanReturns()
    end
  end
  if TakeInboxItem then hooksecurefunc("TakeInboxItem",take) end
  if AutoLootMailItem then hooksecurefunc("AutoLootMailItem",function(index) take(index) end) end
end
function AP.ReturnTakeFailed() requests={} end
