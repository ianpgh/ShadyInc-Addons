local _,AP=...
local D={revision=0}
AP.VendorDiscovery=D
local function read(fn,...)
  if type(fn)~='function' then return end
  local ok,v=pcall(fn,...)
  if ok and not (issecretvalue and issecretvalue(v)) then return v end
end
local function valid(n) return type(n)=='number' and n>0 and n<math.huge end
local function now() return read(GetServerTime) or time() end
local function book(ch)
  if type(ch.vendorDiscovery)~='table' then ch.vendorDiscovery={} end
  return ch.vendorDiscovery
end
local function identity(o) return o.id..'|'..o.merchant..'|'..o.zone end
local function merchant()
  local name=read(UnitName,'npc')
  if type(name)~='string' or name=='' then return end
  local map=read(C_Map and C_Map.GetBestMapForUnit,'player')
  local info=map and read(C_Map.GetMapInfo,map)
  local zone=info and info.name or read(GetRealZoneText) or ''
  local pos=map and read(C_Map.GetPlayerMapPosition,map,'player')
  local loc
  if pos and type(pos.x)=="number" and type(pos.y)=="number" and pos.x>=0 and pos.y>=0 and pos.x<=1 and pos.y<=1 and (pos.x~=0 or pos.y~=0) then loc={map,pos.x*100,pos.y*100} end
  return name,zone,loc
end
function D.Scan(ch)
  if not ch or not D.open then return 0,'Open a vendor first.' end
  local name,zone,loc=merchant()
  if not name then return 0,'Vendor identity unavailable; reopen the merchant.' end
  local modern=C_MerchantFrame or {}
  local count=read(modern.GetNumItems or GetMerchantNumItems)
  if not valid(count) then return 0,'No readable merchant items yet.' end
  local b=book(ch); local added=0
  for i=1,math.min(count,1000) do
    local info=read(modern.GetItemInfo,i)
    if not info and GetMerchantItemInfo then
      local ok,n,_,price,bundle,available,_,extended=pcall(GetMerchantItemInfo,i)
      if ok then info={name=n,price=price,stackCount=bundle,numAvailable=available,hasExtendedCost=extended} end
    end
    if type(info)=='table' then
      local link=read(modern.GetItemLink or GetMerchantItemLink,i)
      local id=info.itemID or read(GetMerchantItemID,i) or (type(link)=='string' and tonumber(link:match('item:(%d+)')))
      if valid(id) and type(info.name)=='string' and info.name~='' then
        local price=not info.hasExtendedCost and valid(info.price) and info.price or 0
        local bundle=valid(info.stackCount) and info.stackCount or 1
        local o={id=id,name=info.name,merchant=name,zone=zone,price=price,bundle=bundle,location=loc,discovered=true,source='merchant',observedAt=now()}
        local k=identity(o); local old=b[k]
        -- Missing/partial data must not erase a previously verified quote or location.
        if old then
          if price==0 and not info.hasExtendedCost and old.price>0 then o.price,o.bundle=old.price,old.bundle; o.observedAt=old.observedAt end
          o.location=o.location or old.location
        end
        b[k]=o; added=added+1
      end
    end
  end
  if added>0 then D.revision=D.revision+1; if AP.RefreshVendorArchive then AP.RefreshVendorArchive() end end
  return added,added..' merchant offers observed.'
end
function D.Install(ch)
  local frame=CreateFrame('Frame')
  for _,event in ipairs({'MERCHANT_SHOW','MERCHANT_UPDATE','MERCHANT_CLOSED'}) do frame:RegisterEvent(event) end
  local session=0; local queued=false
  frame:SetScript('OnEvent',function(_,event)
    if event=='MERCHANT_CLOSED' then D.open=false; session=session+1; queued=false; return end
    if event=='MERCHANT_SHOW' then D.open=true; session=session+1; queued=false end
    if not D.open or queued then return end
    queued=true; local token=session
    local function scan() if token~=session then return end; queued=false; D.Scan(ch) end
    if C_Timer and C_Timer.After then C_Timer.After(.2,scan) else scan() end
  end)
end
function D.PurchaseChanged() D.revision=D.revision+1; if AP.RefreshVendorArchive then AP.RefreshVendorArchive() end end
-- Read-only projection of actual purchases, not a second accounting ledger.
function D.Merge(ch,base,includePurchases)
  local merged,index,seen={}, {}, {}
  local function add(o)
    local k=identity(o); local at=index[k]
    if at then merged[at]=o else merged[#merged+1]=o; index[k]=#merged end
  end
  for _,o in ipairs(base or {}) do add(o) end
  for _,o in pairs(ch and ch.vendorDiscovery or {}) do
    if type(o)=='table' and valid(o.id) and type(o.name)=='string' and type(o.merchant)=='string' and type(o.zone)=='string' then
      add(o); if valid(o.price) and valid(o.bundle) then seen[o.id]=true end
    end
  end
  if includePurchases then
    local latest={}
    for _,r in ipairs(ch and ch.buys or {}) do
      if r.vendor and not r.auctionID and not r.priceEstimated and not r.manualVendor and valid(r.itemID) and valid(r.price) and valid(r.quantity) then
        local old=latest[r.itemID]
        if not old or (r.boughtAt or 0)>(old.boughtAt or 0) or ((r.boughtAt or 0)==(old.boughtAt or 0) and (r.purchaseID or 0)>(old.purchaseID or 0)) then latest[r.itemID]=r end
      end
    end
    for id,r in pairs(latest) do
      -- A merchant observation with a usable quote already gives the item a personal row.
      if not seen[id] then
        add({id=id,name=r.name or ('Item #'..id),merchant='My purchases',zone='',price=r.price,bundle=r.quantity,discovered=true,source='purchase',observedAt=r.boughtAt,purchaseID=r.purchaseID})
      end
    end
  end
  table.sort(merged,function(a,b)
    local x,y=a.name:lower(),b.name:lower()
    if x~=y then return x<y end
    if a.id~=b.id then return a.id<b.id end
    return identity(a)<identity(b)
  end)
  return merged
end
