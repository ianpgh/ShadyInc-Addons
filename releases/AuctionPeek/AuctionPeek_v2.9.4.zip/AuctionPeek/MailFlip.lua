-- Receipt-only flip recovery: no synthetic auction IDs, one intact purchase lot.
local _, AP = ...
local M={}; AP.MailFlip=M
local function integer(n) return type(n)=='number' and n%1==0 end
local function valid(r)
  return r and r.sold and r.mailOnly and not r.auctionID and not r.invoiceAuctionID
    and not r.mailFlip and type(r.receiptID)=='string' and r.receiptID:match('^mail:%d+$')
    and r.receiptQuantityKnown and r.receiptQty==1 and r.quantity==1
    and integer(r.verifiedGross) and r.verifiedGross>0 and integer(r.verifiedCut)
    and r.verifiedCut>=0 and r.verifiedCut<=r.verifiedGross and integer(r.verifiedDeposit)
    and r.verifiedDeposit>=0 and r.verifiedNet==r.verifiedGross-r.verifiedCut+r.verifiedDeposit
    and integer(r.observedAt) and r.observedAt>0
end
local function buckets(ch) return {ch.sold or {},ch.deleted or {},ch.active or {},ch.ended or {}} end
local function sourceUsed(l,index)
  for _,p in pairs(l.posts or {}) do
    for _,a in ipairs(p.parts or {}) do if a.source==index then return true end end
  end
  for _,x in ipairs(l.lots or {}) do
    for _,a in ipairs(x.parts or {}) do if a.source==index then return true end end
  end
end
function M.Choices(ch,r,normalize)
  local l=ch.craftLedger
  local out={}
  if not l or not valid(r) then return out end
  local name=normalize(r.name or '')
  if name=='' or name:match('^unknown') or name:match('^item #') then return out end
  local claims=AP.DETest and AP.DETest.ConfirmedReceiptClaims and AP.DETest.ConfirmedReceiptClaims(ch) or {}
  if claims[r.receiptID] then return out end
  local count,visible=0,false
  for _,pool in ipairs(buckets(ch)) do
    for _,s in ipairs(pool) do
      if s.receiptID==r.receiptID then count=count+1 end
      if s==r and pool==ch.sold then visible=true end
    end
  end
  if count~=1 or not visible then return out end
  for _,p in pairs(l.posts or {}) do if p.fills and p.fills[r.receiptID] then return out end end
  local id=r.itemID
  local buys,seenPurchases={},{}
  for _,b in ipairs(ch.buys or {}) do
    if normalize(b.name or b.link or '')==name then
      if not integer(b.itemID) or b.itemID<=0 or (id and id~=b.itemID) or (b.itemSuffix or 0)~=0 then return out end
      if b.purchaseID and seenPurchases[b.purchaseID] then return out end
      if b.purchaseID then seenPurchases[b.purchaseID]=true end
      id=b.itemID; buys[#buys+1]=b
    end
  end
  if not id then return out end
  -- Refuse name collisions, including deleted purchase evidence.
  for _,pool in ipairs(buckets(ch)) do
    for _,s in ipairs(pool) do
      if normalize(s.name or s.link or '')==name and s.itemID and s.itemID~=id then return out end
    end
  end
  local function same(s) return s.itemID==id or normalize(s.name or s.link or '')==name end
  for _,b in ipairs(buys) do
    local index=b.purchaseID and l.purchases and l.purchases['p:'..b.purchaseID]
    local x=index and l.lots[index]
    if x and x.index==index and x.purchase==b.purchaseID and x.itemID==id and x.quantity==1 and x.left==1
        and integer(x.cost) and x.cost>0 and x.balance==x.cost and x.cost==b.price and b.quantity==1
        and b.purchase and not b.priceEstimated and not (x.parts or x.looted or x.unknown or x.estimate)
        and (not b.delivery or b.delivery.stage=='verified') and integer(b.boughtAt)
        and x.at==b.boughtAt and b.boughtAt<=r.observedAt and not sourceUsed(l,index) then
      local blocked=false
      -- Existing auction/receipt evidence has priority. Unknown timestamps block rather than guess.
      for _,pool in ipairs(buckets(ch)) do
        for _,s in ipairs(pool) do
          if s~=r and not s.purchase and s.deletedKind~='buys' and same(s) then
            local at=s.soldAt or s.observedAt or s.endedAt or s.firstSeenAt or s.seenAt
            if not at or at>=b.boughtAt then blocked=true end
          end
          if s~=r and s.mailFlip and s.mailFlip.source==index then blocked=true end
        end
      end
      for _,p in pairs(l.posts or {}) do
        if p.itemID==id and (not p.at or p.at>=b.boughtAt) then blocked=true end
      end
      for _,d in ipairs(ch.deTests or {}) do
        if d.outputs and d.outputs[id] and (not d.at or d.at>=b.boughtAt) then blocked=true end
      end
      if not blocked then out[#out+1]={buy=b,lot=x,source=index,itemID=id,cost=x.cost} end
    end
  end
  return out,#buys
end
function M.Commit(ch,r,source,normalize,manual)
  local choices,total=M.Choices(ch,r,normalize)
  if not manual and (#choices~=1 or total~=1 or r.mailFlipAutoBlocked or (ch.reviewDismissed or {})[r.receiptID]) then return false end
  for _,c in ipairs(choices) do
    if c.source==source then
      if not manual then
        local held=AP.Reconciliation and AP.Reconciliation.Count and AP.Reconciliation.Count(c.itemID)
        if type(held)=="number" and held>0 then return false end
        -- Other same-item inventory, even a zero/unknown-cost lot, makes origin ambiguous.
        for i,x in ipairs(ch.craftLedger.lots) do if i~=source and x.itemID==c.itemID then return false end end
        for _,b in ipairs(ch.deleted or {}) do if b.deletedKind=='buys' and b.itemID==c.itemID then return false end end
      end
      r.mailFlip={version=1,source=source,purchase=c.buy.purchaseID,itemID=c.itemID,cost=c.cost,
        originalItemID=r.itemID,manual=manual==true,at=time()}
      r.itemID=c.itemID
      c.lot.left,c.lot.balance=0,0
      if ch.reviewDismissed then ch.reviewDismissed[r.receiptID]=nil end
      return true
    end
  end
  return false
end
function M.Reconcile(ch,normalize)
  local n=0
  for _,r in ipairs(ch.sold or {}) do
    if valid(r) then
      local c=M.Choices(ch,r,normalize)
      if #c==1 and M.Commit(ch,r,c[1].source,normalize,false) then n=n+1 end
    end
  end
  return n
end
function M.Undo(ch,r)
  local a=r.mailFlip
  local l=ch.craftLedger
  local x=a and l and l.lots[a.source]
  if not x or x.purchase~=a.purchase or x.itemID~=a.itemID or x.cost~=a.cost or x.left~=0 or x.balance~=0
      or sourceUsed(l,a.source) then return false end
  for _,pool in ipairs(buckets(ch)) do
    for _,s in ipairs(pool) do if s~=r and s.mailFlip and s.mailFlip.source==a.source then return false end end
  end
  x.left,x.balance=1,a.cost
  r.itemID,r.mailFlip,r.mailFlipAutoBlocked=a.originalItemID,nil,true
  return true
end
function M.Rows(ch,flips,sales,profitText)
  for _,r in ipairs(sales or ch.sold or {}) do
    local a=r.mailFlip
    local x=a and ch.craftLedger and ch.craftLedger.lots[a.source]
    if x and x.purchase==a.purchase and x.itemID==a.itemID and x.cost==a.cost and x.left==0 and x.balance==0 then
      local row={}; for k,v in pairs(r) do row[k]=v end
      row.historySource=r
      row.soldCost={cost=a.cost,manual=a.manual,note='Receipt-only purchase attribution #'..a.purchase..'; original auction ID unavailable. Undo in Unmatched.'}
      row.net=r.verifiedGross-r.verifiedCut
      row.profitText=profitText(row.net,row.soldCost)
      flips[#flips+1]=row
    end
  end
end
