local _, AP = ...
local I = {}
AP.Inventory = I

local session
local function readable(v)
  return AP.MailValueReadable(v)
end

local function snapshot()
  local api=C_Container
  local slots=(api and api.GetContainerNumSlots) or GetContainerNumSlots
  local info=api and api.GetContainerItemInfo
  if not slots or not (info or GetContainerItemInfo) then return end
  local counts={}
  local last=NUM_TOTAL_EQUIPPED_BAG_SLOTS or (NUM_BAG_SLOTS or 4)
  if Enum and Enum.BagIndex and Enum.BagIndex.ReagentBag then
    last=math.max(last,Enum.BagIndex.ReagentBag)
  end
  for bag=0,last do
    local n=slots(bag)
    if not readable(n) or type(n)~="number" then return end
    for slot=1,n do
      local id,qty
      if info then
        local item=info(bag,slot)
        if not readable(item) then return end
        if item then id,qty=item.itemID,item.stackCount end
      else
        local _,count,_,_,_,_,link,_,_,itemID=GetContainerItemInfo(bag,slot)
        if not readable(link) then return end
        id,qty=itemID or (link and tonumber(link:match("item:(%d+)"))),count
      end
      if not readable(id) or not readable(qty) then return end
      if id then
        if type(id)~="number" or type(qty)~="number" or qty<1 then return end
        counts[id]=(counts[id] or 0)+qty
      end
    end
  end
  return counts
end

function I.Append(ch,entry)
  ch.inventoryReconciliation=ch.inventoryReconciliation or {version=1,observations={}}
  local list=ch.inventoryReconciliation.observations
  list[#list+1]=entry
  if #list>240 then table.remove(list,1) end
end

function I.Start(ch)
  local ok,counts=pcall(snapshot)
  session={ch=ch,counts=ok and counts or nil,signals={}}
end

function I.Bank(ch,open)
  if not session or session.ch~=ch then return end
  if not open then I.Scan(ch) end
  session.bankOpen=open
end

function I.Signal(ch,id,n,source)
  if not session or session.ch~=ch then return end
  local rows=session.signals[id] or {}
  session.signals[id]=rows
  local r=rows[source]
  if r and time()-r.at<=5 then r.n=r.n+n; r.at=time()
  else rows[source]={n=n,at=time()} end
end

function I.Scan(ch)
  if not session or session.ch~=ch then return end
  local ok,counts=pcall(snapshot)
  if not ok or not counts then return end
  local old=session.counts
  session.counts=counts
  local now=time()
  for id,rows in pairs(session.signals) do
    for source,r in pairs(rows) do if now-r.at>5 then rows[source]=nil end end
    if not next(rows) then session.signals[id]=nil end
  end
  if not old then return end
  local touched={}
  local function record(id,after,before)
    if after==before then return end
    local observed=after-before
    local sources,total={},0
    for source,r in pairs(session.signals[id] or {}) do
      sources[source]=r.n
      total=total+r.n
    end
    session.signals[id]=nil
    I.Append(ch,{at=now,itemID=id,before=before,after=after,delta=observed,evidence=sources,
      bankOpen=session.bankOpen or nil,
      reason=next(sources) and not sources.GENERIC_ITEM_RECEIPT and total==observed
        and "EVENTS_AGREE" or "UNRESOLVED_BAG_CHANGE"})
  end
  for id,after in pairs(counts) do touched[id]=true; record(id,after,old[id] or 0) end
  for id,before in pairs(old) do if not touched[id] then record(id,0,before) end end
end

function I.Queue(ch)
  local active=session
  if not active or active.ch~=ch or active.queued then return end
  if not (C_Timer and C_Timer.After) then I.Scan(ch);return end
  active.queued=true
  C_Timer.After(0.25,function()
    if session~=active then return end
    active.queued=false
    I.Scan(ch)
  end)
end

function I.PrintTrace(ch,id,printLine)
  local tracked,pending=0,0
  for _,x in ipairs(ch.craftLedger and ch.craftLedger.lots or {}) do
    if x.itemID==id then tracked=tracked+x.left end
  end
  for _,r in ipairs(ch.buys or {}) do
    if r.itemID==id and r.delivery and r.delivery.stage~="verified" then
      pending=pending+(r.quantity or 0)
      printLine("Purchase #"..r.purchaseID.." · "..r.delivery.stage..(r.delivery.issue and " · "..r.delivery.issue or ""))
    end
  end
  local bags=AP.Reconciliation.Count(id)
  printLine(("Item #%d · bags %s · available ledger units %d · pending purchase units %d")
    :format(id,tostring(bags or "unobserved"),tracked,pending))
  local j=ch.inventoryReconciliation
  local rows=j and j.observations or {}
  local shown=0
  for i=#rows,1,-1 do
    local r=rows[i]
    if r.itemID==id then
      local evidence={}
      for source,n in pairs(r.evidence or {}) do evidence[#evidence+1]=source.." "..n end
      table.sort(evidence)
      printLine(("%s · %+d · %s%s"):format(date("%b %d %I:%M:%S %p",r.at),r.delta,r.reason,
        (#evidence>0 and (" · "..table.concat(evidence,", ")) or "")
          ..(r.bankOpen and " · Bank open" or "")))
      shown=shown+1
      if shown>=10 then break end
    end
  end
end
