local _, AP = ...
local V = {}
AP.VendorCosts = V
local function integer(n, min, max)
  return type(n)=="number" and n==math.floor(n) and n>=min and n<=max
end
local function key(id) return tostring(id) end
local function book(ch,create)
  if not ch.vendorCostArchive and create then ch.vendorCostArchive={items={},manual={}} end
  return ch.vendorCostArchive
end
local function lookup(ch,id)
  local b=book(ch)
  return b and b.items[key(id)]
end
local function buyByID(ch,id)
  local found
  for _,r in ipairs(ch.buys or {}) do
    if key(r.purchaseID)==key(id) then if found then return end; found=r end
  end
  return found
end
local function validBuy(b)
  return b and b.vendor and not b.priceEstimated and integer(b.itemID,1,100000000)
    and integer(b.quantity,1,1000000) and integer(b.price,1,10000000000)
    and b.price%b.quantity==0 and integer(b.boughtAt,1,10000000000)
    and (b.itemSuffix or 0)==0
end
-- Approval is per character and per exact item ID. An observed purchase is
-- required to seed an entry. Later price changes are append-only, effective now.
function V.Save(ch,purchaseID,price,now)
  local buy=buyByID(ch,purchaseID)
  if not validBuy(buy) or not integer(price,1,10000000000) then return nil,"Select a verified vendor purchase and valid unit cost." end
  local entry=lookup(ch,buy.itemID)
  if not entry and price~=buy.price/buy.quantity then return nil,"Initial cost must match the recorded vendor purchase." end
  local at=entry and now or buy.boughtAt
  if not integer(at,1,10000000000) or at<buy.boughtAt then return nil,"Invalid effective time." end
  if entry then
    local last=entry.history[#entry.history]
    if last.price==price then entry.enabled=true; return true end
    if at<=last.at then return nil,"Wait for a later effective time; previous prices are retained." end
  end
  local b=book(ch,true)
  entry=entry or {itemID=buy.itemID,name=buy.name or ("Item #"..buy.itemID),history={}}
  b.items[key(buy.itemID)]=entry
  entry.enabled=true
  entry.history[#entry.history+1]={at=at,price=price,purchaseID=buy.purchaseID,recorded=price==buy.price/buy.quantity}
  return true
end
-- Catalog quotes are not purchase evidence. A user-approved quote can seed
-- a prospective fallback, never a synthetic purchase or a backdated price.
function V.OfferUnit(o)
  if type(o)~="table" or not integer(o.id,1,100000000) or type(o.name)~="string"
      or not integer(o.price,1,10000000000) or not integer(o.bundle,1,1000000)
      or o.price%o.bundle~=0 then return end
  return o.price/o.bundle
end
function V.SaveOffer(ch,o,price,now)
  local unit=V.OfferUnit(o)
  if not unit or not integer(price,1,10000000000) or not integer(now,1,10000000000) then
    return nil,"Select a valid whole-copper vendor price."
  end
  local entry=lookup(ch,o.id)
  if entry then
    local last=entry.history[#entry.history]
    if last.price==price then entry.enabled=true; return true end
    if now<=last.at then return nil,"Wait for a later effective time; previous prices are retained." end
  end
  local b=book(ch,true)
  entry=entry or {itemID=o.id,name=o.name,history={}}
  b.items[key(o.id)]=entry
  entry.enabled=true
  entry.catalogOffer={id=o.id,name=o.name,price=o.price,bundle=o.bundle,merchant=o.merchant,zone=o.zone}
  entry.history[#entry.history+1]={at=now,price=price,source="catalog",catalogUnit=unit,merchant=o.merchant,recorded=false}
  return true
end
function V.SetEnabled(ch,id,enabled)
  local e=lookup(ch,id); if e then e.enabled=not not enabled; return true end
end
local function saleFor(ch,id)
  local found
  for _,r in ipairs(ch.sold or {}) do
    if key(r.auctionID)==key(id) then if found then return end; found=r end
  end
  if not found or not found.sold or not found.receiptID or found.mailOnly or found.quantity~=1
      or (found.receiptQty and found.receiptQty~=1) or not found.itemID
      or not AP.Reconciliation.VerifiedProceeds(found) then return end
  for _,r in ipairs(ch.sold or {}) do
    if r~=found and r.receiptID==found.receiptID then return end
  end
  for _,pool in ipairs({ch.active or {},ch.deleted or {}}) do
    for _,r in ipairs(pool) do if key(r.auctionID)==key(id) then return end end
  end
  local p=ch.craftLedger and ch.craftLedger.posts[key(id)]
  if not p or p.itemID~=found.itemID or p.quantity~=1 or not p.soldAt or not p.at
      or p.ended or p.returnedUnits or p.remainderTo or p.awaitingReturn
      or (p.filled and p.filled~=1) or #(p.parts or {})~=1 or p.parts[1].n~=1 then return end
  return found,p
end
function V.CanManual(ch,id) return saleFor(ch,id)~=nil end
function V.Manual(ch,id,cost,now)
  local sale,p=saleFor(ch,id)
  if not sale or not integer(cost,0,10000000000) then return nil,"Only a uniquely paid single-item sale can be adjusted." end
  local b=book(ch,true)
  local old=b.manual[key(id)]
  local history=old and old.history or {}
  history[#history+1]={at=now,cost=cost,previous=old and old.cost or nil,original=AP.Crafts.AllocationCost(p,0,1)}
  b.manual[key(id)]={itemID=sale.itemID,receiptID=sale.receiptID,cost=cost,history=history}
  return true
end
function V.UndoManual(ch,id,now)
  local b=book(ch); local m=b and b.manual[key(id)]
  if not m or m.disabled then return end
  m.history[#m.history+1]={at=now,undo=true,previous=m.cost}
  m.disabled=true; return true
end
function V.ManualActive(ch,id)
  local b=book(ch); local m=b and b.manual[key(id)]
  return m and not m.disabled
end
-- No synthetic buys/lots and no ledger withdrawal for a fallback or override.
-- They are separate display/accounting adjustments, and never manufacture receipts.
function V.Cost(ch,id,base)
  local b=book(ch); if not b then return end
  local m=b.manual[key(id)]
  if not (m and not m.disabled) and not (base and base.unknown and next(b.items)) then return end
  local sale,p=saleFor(ch,id); if not sale then return end
  if m and not m.disabled and m.itemID==sale.itemID and m.receiptID==sale.receiptID then
    return {cost=m.cost,manual=true,note="User-confirmed manual cost override. Original ledger unchanged; undo in inspector."}
  end
  if not base or not base.unknown then return end
  local part=p.parts[1]
  if part.source or not part.unknown or part.cost~=0 or (sale.itemSuffix or 0)~=0 then return end
  local e=lookup(ch,sale.itemID)
  if not e or not e.enabled then return end
  -- Never treat known crafted/looted or AH-sourced copies as vendor-only.
  for _,x in ipairs(ch.craftLedger.lots or {}) do
    if x.itemID==sale.itemID and (x.looted or x.parts or (x.purchase and not x.vendor)) then return end
  end
  for _,x in ipairs(ch.buys or {}) do if x.itemID==sale.itemID and not x.vendor then return end end
  local version
  for _,v in ipairs(e.history) do if v.at<=p.at then version=v else break end end
  if version then return {cost=version.price,estimate=true,vendorFallback=true,
    note="Saved vendor cost (V); estimate from approved price effective "..date("%b %d %I:%M %p",version.at)..". No purchase lot consumed."} end
end
function V.Apply(ch,rows,first,profit)
  if not book(ch) then return end
  for i=first or 1,#rows do
    local r=rows[i]
    if r.auctionID and r.soldCost and r.quantity==1 and not r.deAction then
      local cost=V.Cost(ch,r.auctionID,r.soldCost)
      if cost then r.soldCost=cost; r.price=cost.cost; r.profitText=profit(r.net,cost) end
    end
  end
end
-- If an old vendor lot is stranded behind an inferred active repost, the
-- successor must already have a distinct, clean, fully reserved vendor lot.
-- Equal actual prices and exclusive ownership are required. No chain rewriting.
function V.IndependentRepost(ch,old,target)
  local l=ch.craftLedger
  if not old.repostedAs or old.endedReason~="canceled" and old.endedReason~="expired" then return end
  local oldID,newID=key(old.auctionID),key(old.repostedAs)
  local a,b=l.posts[oldID],l.posts[newID]
  if not a or not b or a==b or a.quantity~=1 or b.quantity~=1 or a.itemID~=target.itemID
      or b.itemID~=target.itemID or not a.awaitingReturn or a.returnedUnits or a.remainderTo
      or a.soldAt or a.filled or a.gross or b.ended or b.soldAt or b.filled or b.gross
      or b.returnedUnits or b.remainderTo or b.awaitingReturn or not a.at or not b.at
      or #(a.parts or {})~=1 or #(b.parts or {})~=1 or old.returnCollectedAt
      or not old.endedAt or b.at<old.endedAt or b.at-old.endedAt>120 then return end
  local active
  for _,r in ipairs(ch.active or {}) do
    if key(r.auctionID)==newID then if active then return end; active=r end
  end
  if not active or key(active.repostOf)~=oldID or active.quantity~=1 or active.itemID~=target.itemID
      or (active.itemSuffix or 0)~=(target.itemSuffix or 0) or active.itemLevel~=target.itemLevel then return end
  for _,pool in ipairs({ch.sold or {},ch.deleted or {},ch.ended or {}}) do
    for _,r in ipairs(pool) do if key(r.auctionID)==newID then return end end
  end
  local x,y=a.parts[1],b.parts[1]
  if not x.source or not y.source or x.source==y.source then return end
  local function clean(part)
    local lot=l.lots[part.source]
    local buy=lot and buyByID(ch,lot.purchase)
    return lot and validBuy(buy) and lot.vendor and lot.itemID==target.itemID and buy.itemID==target.itemID
      and lot.quantity==1 and buy.quantity==1 and lot.left==0 and lot.balance==0
      and not (lot.unknown or lot.estimate or lot.parts or lot.looted or lot.sourceUncertain)
      and not (part.unknown or part.estimate or part.sourceUncertain) and part.n==1
      and part.cost==lot.cost and lot.cost==buy.price
  end
  if not clean(x) or not clean(y) or x.cost~=y.cost then return end
  for k,p in pairs(l.posts) do
    if k~=oldID and k~=newID then
      for _,part in ipairs(p.parts or {}) do if part.source==x.source or part.source==y.source then return end end
    end
  end
  for _,lot in ipairs(l.lots) do
    for _,part in ipairs(lot.parts or {}) do if part.source==x.source or part.source==y.source then return end end
  end
  return true
end
-- Explicitly confirmed historical case; generic future recovery is opt-in,
-- with exactly one unresolved paid copy and one eligible stranded purchase.
function V.Reconcile(ch)
  local l=ch.craftLedger; if not l then return 0 end
  local candidates,counts={},{}
  for _,sale in ipairs(ch.sold or {}) do
    local id=key(sale.auctionID)
    local p=l.posts[id]
    if p and p.itemID and p.quantity==1 and #(p.parts or {})==1 and p.parts[1].unknown and not p.parts[1].source then
      counts[p.itemID]=(counts[p.itemID] or 0)+1
      local e=lookup(ch,p.itemID)
      local exact=id=="214922938" and p.itemID==22308 and p.at==1795627266 and sale.receiptID=="mail:258"
        and sale.verifiedGross==34200 and sale.verifiedCut==1710
      if not p.vendorReconciliationUndone and (exact or (e and e.enabled)) and saleFor(ch,id) and not V.ManualActive(ch,id) then
        candidates[#candidates+1]={id=id,item=p.itemID,exact=exact,sale=sale}
      end
    end
  end
  local n=0
  for _,c in ipairs(candidates) do
    if counts[c.item]==1 or c.exact then
      local choices=AP.Crafts.PurchaseSources(ch,c.id)
      local choice=#choices==1 and choices[1]
      if choice and choice.owner and choice.buy.vendor and not choice.buy.priceEstimated then
        local old
        for _,r in ipairs(ch.ended or {}) do if key(r.auctionID)==choice.owner then old=r; break end end
        local competing=false
        for _,r in ipairs(ch.sold or {}) do
          local q=l.posts[key(r.auctionID)]
          if key(r.auctionID)~=c.id and q and q.itemID==c.item and q.at and q.at>=choice.buy.boughtAt
              and #(q.parts or {})==1 and q.parts[1].unknown and not q.parts[1].source then competing=true end
        end
        if not competing and old and V.IndependentRepost(ch,old,c.sale) and (not c.exact or (choice.buy.purchaseID==355 and choice.cost==18000 and choice.owner=="210320879")) then
          if AP.Crafts.ConfirmPurchase(ch,c.id,choice.buy.purchaseID) then
            local p=l.posts[c.id]
            p.vendorReconciliation={reason="INDEPENDENT_REPOST_LOT",owner=choice.owner,purchase=choice.buy.purchaseID,
              evidence=c.exact and "Player confirmed four sold, one listed; equal-cost purchases." or "Approved vendor-only item; unique equal-cost stranded reservation."}
            -- Undo must not immediately re-apply this recovery.
            n=n+1
          end
        end
      end
    end
  end
  return n
end

-- Shared explicit copper editor. Initial archive entry requires a recorded
-- vendor price and an explicit attestation (no silent auto-approval).
local function label(parent,text,x,y,w)
  local f=parent:CreateFontString(nil,"OVERLAY","GameFontHighlightSmall")
  f:SetPoint("TOPLEFT",x,y); f:SetWidth(w); f:SetJustifyH("LEFT"); f:SetText(text); return f
end
local function button(parent,text,x,y,w,fn)
  local b=CreateFrame("Button",nil,parent,"UIPanelButtonTemplate")
  b:SetPoint("TOPLEFT",x,y); b:SetSize(w,24); b:SetText(text); b:SetScript("OnClick",fn); return b
end
local function edit(parent,x,y,w,numeric)
  local e=CreateFrame("EditBox",nil,parent,"InputBoxTemplate")
  e:SetPoint("TOPLEFT",x,y); e:SetSize(w,24); e:SetAutoFocus(false)
  if numeric then e:SetNumeric(true); e:SetMaxLetters(9) end
  e:SetScript("OnEscapePressed",function(self) self:ClearFocus(); parent:Hide() end)
  return e
end
local function cashFields(parent,x,y)
  local fields={}
  for i,v in ipairs({{"Gold",78},{"Silver",55},{"Copper",55}}) do
    label(parent,v[1],x,y,v[2]); fields[i]=edit(parent,x+2,y-18,v[2]-6,true); x=x+v[2]+14
  end
  local function set(n)
    fields[1]:SetText(tostring(math.floor(n/10000)))
    fields[2]:SetText(tostring(math.floor(n/100)%100)); fields[3]:SetText(tostring(n%100))
  end
  local function get()
    local g,s,c=tonumber(fields[1]:GetText()),tonumber(fields[2]:GetText()),tonumber(fields[3]:GetText())
    if integer(g,0,1000000) and integer(s,0,99) and integer(c,0,99) then return g*10000+s*100+c end
  end
  return set,get
end
local function frame(name,w,h)
  local f=CreateFrame("Frame",name,UIParent)
  f:SetSize(w,h); f:SetPoint("CENTER"); f:SetFrameStrata("DIALOG"); f:SetFrameLevel(100)
  f:SetClampedToScreen(true); f:EnableMouse(true); f:SetMovable(true)
  f:RegisterForDrag("LeftButton"); f:SetScript("OnDragStart",f.StartMoving); f:SetScript("OnDragStop",f.StopMovingOrSizing)
  local bg=f:CreateTexture(nil,"BACKGROUND"); bg:SetAllPoints(); bg:SetColorTexture(.07,.06,.05,1)
  local close=CreateFrame("Button",nil,f,"UIPanelCloseButton"); close:SetPoint("TOPRIGHT"); close:SetScript("OnClick",function() f:Hide() end)
  if UISpecialFrames then table.insert(UISpecialFrames,name) end
  f:Hide(); return f
end
local archive,selected,profile,callback,returnTo,page,refreshArchive
local function pick(buy,offer,editExisting)
  selected=offer and {itemID=offer.id,offer=offer} or buy
  local id=selected.itemID
  local e=lookup(profile,id)
  local name=offer and offer.name or buy.name
  archive.item:SetText((name or "Item #"..id).."  (#"..id..")")
  archive.setCost(offer and (editExisting and e and e.history[#e.history].price or V.OfferUnit(offer)) or (e and e.history[#e.history].price or buy.price/buy.quantity))
  archive.approve:SetChecked(false)
  archive.approve:SetShown(not e)
  archive.approveText:SetShown(not e)
  archive.save:SetText(e and "Save new price" or "Approve & save")
  local lines={}
  for i,v in ipairs(e and e.history or {}) do
    lines[#lines+1]=date("%b %d %I:%M %p",v.at).."  "..AP.Money(v.price)..(v.source=="catalog" and (v.price==v.catalogUnit and " (catalog)" or " (catalog adjusted)") or v.recorded and " (recorded)" or " (manual)")
  end
  archive.historyLines=lines
  local recent={}
  for i=math.max(1,#lines-1),#lines do recent[#recent+1]=lines[i] end
  archive.history:SetText(#lines>0 and table.concat(recent,"  |  ") or (offer and "Catalog quote; not a recorded purchase. Effective from approval." or "No saved price yet. Initial price must match this purchase."))
end
local function newestBuy(ch,itemID)
  local best
  for _,b in ipairs(ch.buys or {}) do
    if b.itemID==itemID and validBuy(b) and (not best or b.boughtAt>best.boughtAt) then best=b end
  end
  return best
end
function V.Open(ch,buy,refresh,back,offer)
  if not ch then return end
  profile,callback,returnTo,page=ch,refresh,back,1
  if not archive then
    archive=frame("AuctionPeekSavedVendorCosts",710,482)
    local title=label(archive,"Auction Peek  •  Saved vendor costs",15,-14,400); title:SetTextColor(1,.82,.35)
    button(archive,"Vendor Archive",465,-10,155,function() archive:Hide(); if returnTo then returnTo() elseif AP.ToggleVendors then AP.ToggleVendors() end end)
    label(archive,"Search saved items",15,-51,112)
    archive.search=edit(archive,133,-43,240)
    archive.search:SetScript("OnTextChanged",function() page=1; if refreshArchive then refreshArchive() end end)
    label(archive,"Add item ID",390,-51,78); archive.id=edit(archive,468,-43,110,true)
    button(archive,"Find",585,-43,100,function()
      local b=newestBuy(profile,tonumber(archive.id:GetText()))
      if b then pick(b); archive.status:SetText("Review the item and confirm it is vendor-only.")
      else
        local e=lookup(profile,tonumber(archive.id:GetText()))
        if e and V.OfferUnit(e.catalogOffer) then pick(nil,e.catalogOffer,true); archive.status:SetText("Edit saved catalog cost or toggle fallback.")
        else archive.status:SetText("No recorded purchase or saved catalog cost for this item ID.") end
      end
    end)
    label(archive,"Item",15,-82,330):SetTextColor(1,.82,.35)
    label(archive,"Current cost",365,-82,120):SetTextColor(1,.82,.35)
    label(archive,"Fallback",502,-82,90):SetTextColor(1,.82,.35)
    archive.rows={}
    for i=1,7 do
      local y=-101-(i-1)*26
      local r={name=button(archive,"",12,y,342,function(self)
        local b=newestBuy(profile,self.itemID); local e=lookup(profile,self.itemID)
        if b then pick(b); archive.status:SetText("Edit price or toggle fallback.")
        elseif e and V.OfferUnit(e.catalogOffer) then pick(nil,e.catalogOffer,true); archive.status:SetText("Edit saved catalog cost or toggle fallback.")
        else archive.status:SetText("Original buy is no longer visible; price history retained.") end
      end),cost=label(archive,"",365,y-6,130)}
      r.toggle=button(archive,"",502,y,110,function(self)
        local e=lookup(profile,self.itemID); if e then V.SetEnabled(profile,self.itemID,not e.enabled); refreshArchive(); if callback then callback() end end
      end)
      archive.rows[i]=r
    end
    button(archive,"Previous",12,-286,90,function() page=math.max(1,page-1); refreshArchive() end)
    archive.page=label(archive,"",115,-294,200)
    button(archive,"Next",620,-286,75,function() page=page+1; refreshArchive() end)
    archive.item=label(archive,"Select an item or right-click a vendor purchase in Buy History.",15,-324,675)
    archive.setCost,archive.getCost=cashFields(archive,15,-350)
    archive.approve=CreateFrame("CheckButton",nil,archive,"UICheckButtonTemplate"); archive.approve:SetPoint("TOPLEFT",267,-349); archive.approve:SetSize(24,24)
    archive.approveText=label(archive,"I only acquire this item from vendors (not loot or AH).",295,-356,390)
    archive.save=button(archive,"Approve & save",523,-382,169,function()
      if not selected then archive.status:SetText("Select a vendor purchase or catalog price first."); return end
      local e=lookup(profile,selected.itemID)
      if not e and not archive.approve:GetChecked() then archive.status:SetText("Confirm the vendor-only rule before saving."); return end
      local cost=archive.getCost()
      local ok,why
      if selected.offer then ok,why=V.SaveOffer(profile,selected.offer,cost,time())
      else ok,why=V.Save(profile,selected.purchaseID,cost,time()) end
      if not ok then archive.status:SetText(why); return end
      archive.status:SetText("Saved. Existing verified purchase allocations take precedence.")
      refreshArchive(); if selected.offer then pick(nil,selected.offer,true) else pick(selected) end; if callback then callback() end
    end)
    archive.history=label(archive,"",15,-414,535)
    local historyButton=button(archive,"Price history",548,-410,144,function() end)
    historyButton:SetScript("OnEnter",function(self)
      GameTooltip:SetOwner(self,"ANCHOR_TOP"); GameTooltip:AddLine("Saved price history")
      for _,line in ipairs(archive.historyLines or {}) do GameTooltip:AddLine(line,1,1,1) end
      GameTooltip:Show()
    end)
    historyButton:SetScript("OnLeave",function() GameTooltip:Hide() end)
    archive.status=label(archive,"",15,-452,680); archive.status:SetTextColor(1,.92,.3)
    refreshArchive=function()
      local list={}; local b=book(profile); local q=(archive.search:GetText() or ""):lower()
      for _,e in pairs(b and b.items or {}) do
        if e.name:lower():find(q,1,true) or tostring(e.itemID):find(q,1,true) then list[#list+1]=e end
      end
      table.sort(list,function(a,b) return a.name==b.name and a.itemID<b.itemID or a.name<b.name end)
      local pages=math.max(1,math.ceil(#list/7)); page=math.max(1,math.min(page,pages))
      archive.page:SetText("Page "..page.." / "..pages.."  •  "..#list.." items")
      for i,r in ipairs(archive.rows) do
        local e=list[(page-1)*7+i]; r.name:SetShown(e~=nil); r.cost:SetShown(e~=nil); r.toggle:SetShown(e~=nil)
        if e then
          r.name.itemID=e.itemID; r.toggle.itemID=e.itemID; r.name:SetText(e.name)
          r.cost:SetText(AP.Money(e.history[#e.history].price))
          r.toggle:SetText(e.enabled and "|cff44ff44ON  +|r" or "|cffff5555OFF  X|r")
        end
      end
    end
  end
  selected=nil; archive.item:SetText("Select an item or find a recorded vendor purchase by item ID.")
  archive.setCost(0); archive.approve:Hide(); archive.approveText:Hide(); archive.history:SetText(""); archive.historyLines={}
  archive.status:SetText("Only approved items use fallback prices. Actual recorded costs always win.")
  archive.search:SetText(""); refreshArchive()
  if V.OfferUnit(offer) then
    pick(nil,offer)
    archive.status:SetText("Catalog price selected. Adjust for your discount; confirm and save.")
  elseif validBuy(buy) then pick(buy) end
  archive:Show()
end

local manualWindow,manualContext
function V.OpenManual(ch,id,refresh,displayCost)
  if not V.CanManual(ch,id) then return end
  manualContext={ch=ch,id=id,refresh=refresh}
  if not manualWindow then
    manualWindow=frame("AuctionPeekManualSaleCost",390,212)
    local title=label(manualWindow,"Set manual sale cost",15,-14,330); title:SetTextColor(1,.82,.35)
    manualWindow.item=label(manualWindow,"",15,-43,360)
    manualWindow.setCost,manualWindow.getCost=cashFields(manualWindow,15,-72)
    label(manualWindow,"Overrides displayed sale cost only; original purchase ledger stays intact.",15,-124,360)
    manualWindow.status=label(manualWindow,"",15,-184,360)
    button(manualWindow,"Confirm cost",225,-150,150,function()
      local c=manualContext; local ok,why=V.Manual(c.ch,c.id,manualWindow.getCost(),time())
      if ok then manualWindow:Hide(); if c.refresh then c.refresh() end else manualWindow.status:SetText(why) end
    end)
  end
  local sale,p=saleFor(ch,id); local base=AP.Crafts.AllocationCost(p,0,1)
  local cost=V.Cost(ch,id,base) or (displayCost and not displayCost.unknown and displayCost) or base
  manualWindow.item:SetText((sale.name or "Item").."  #"..id)
  manualWindow.setCost(cost.cost); manualWindow.status:SetText(cost.unknown and "Unknown cost: replace the default 0 with your actual cost." or ""); manualWindow:Show()
end
