-- Unmatched Flip Receipts: review-only until the player explicitly confirms.
-- Never modifies purchases, inventory lots, historical costs, or AH sorting.
local _, AP = ...
local window, selectedReceipt, pendingAction
local showOther, showDismissed = false, false
local textPool, buttonPool = {}, {}
local textsUsed, buttonsUsed = 0, 0

local function copy(row)
  local out={}
  for k,v in pairs(row or {}) do out[k]=v end
  return out
end
local function when(t)
  return type(t)=="number" and date("%b %d %I:%M %p",t) or "Time unknown"
end
local function identity(row,normalize)
  return normalize(row and (row.name or row.link) or "")
end
local function sourceEvidence(ch,sale)
  local l=ch.craftLedger
  local p=l and l.posts and l.posts[tostring(sale.auctionID)]
  if not p then return false,nil,"Posting ledger unavailable" end
  local total,unknown,hasPaid=0,false,false
  if not p.parts or #p.parts==0 then return false,nil,"Source cost not yet allocated" end
  for _,part in ipairs(p.parts) do
    local lot=l.lots and l.lots[part.source]
    total=total+(tonumber(part.cost) or 0)
    if part.unknown or part.sourceUncertain or not lot then unknown=true end
    if lot and (lot.purchase or lot.vendor or lot.parts or (not lot.looted and lot.cost and lot.cost>0)) then
      hasPaid=true
    end
  end
  return hasPaid,unknown and nil or total,unknown and "Cost partly unverified" or "Cost source recorded"
end
local function boughtBefore(ch,receipt,normalize)
  for _,buy in ipairs(ch.buys or {}) do
    if buy.boughtAt and receipt.observedAt and buy.boughtAt<=receipt.observedAt
        and ((buy.itemID and receipt.itemID and buy.itemID==receipt.itemID)
          or (not receipt.itemID and identity(buy,normalize)==identity(receipt,normalize))) then
      return true
    end
  end
  return false
end
local function validInvoice(r)
  return r.mailOnly and not r.auctionID and type(r.receiptID)=="string"
    and r.receiptQuantityKnown and type(r.receiptQty)=="number" and r.receiptQty>=1
    and r.receiptQty==math.floor(r.receiptQty) and type(r.verifiedGross)=="number"
    and r.verifiedGross>0 and type(r.verifiedCut)=="number"
    and type(r.verifiedDeposit)=="number" and type(r.verifiedNet)=="number"
    and r.verifiedGross-r.verifiedCut+r.verifiedDeposit==r.verifiedNet
end

function AP.ReviewReceiptCases(ch,normalize,other,dismissed)
  local all,priority= {},0
  local skipped=ch.reviewDismissed or {}
  local deClaims=AP.DETest and AP.DETest.ConfirmedReceiptClaims
    and AP.DETest.ConfirmedReceiptClaims(ch) or {}
  for _,r in ipairs(ch.sold or {}) do
    -- A receipt already verified by a confirmed DE batch is not an unmatched
    -- FLIP suggestion. Preserve its original sale record and undo support.
    if r.mailOnly and not r.mailFlip and r.receiptID and not r.auctionID and not deClaims[r.receiptID] then
      local choices=validInvoice(r) and AP.ManualTargets(ch,r.receiptID,normalize) or {}
      local paid=false
      for _,sale in ipairs(choices) do
        local hasPaid=sourceEvidence(ch,sale)
        if hasPaid then paid=true end
      end
      -- Prefer recorded purchased/crafted source lots over speculative matches.
      table.sort(choices,function(a,b)
        local ap=sourceEvidence(ch,a)
        local bp=sourceEvidence(ch,b)
        if ap~=bp then return ap end
        return (a.soldAt or 0)>(b.soldAt or 0)
      end)
      -- A previously bought item may require review even if the listing
      -- was missed entirely. Do not invent a match without an auction ID.
      local likely=paid or boughtBefore(ch,r,normalize)
      if likely and not skipped[r.receiptID] then priority=priority+1 end
      if (likely or other) and (dismissed or not skipped[r.receiptID]) then
        all[#all+1]={receipt=r,targets=choices,purchases=AP.MailFlip and AP.MailFlip.Choices(ch,r,normalize) or {},priority=likely,paid=paid,
          dismissed=skipped[r.receiptID]==true}
      end
    end
  end
  table.sort(all,function(a,b)
    if a.priority~=b.priority then return a.priority end
    return (a.receipt.observedAt or 0)>(b.receipt.observedAt or 0)
  end)
  return all,priority
end

function AP.ReviewReceiptCount(ch,normalize)
  local _,priority=AP.ReviewReceiptCases(ch,normalize,false,false)
  return priority
end

local changedFields={"receiptID","verifiedGross","verifiedNet","verifiedCut", "verifiedDeposit",
  "receiptBuyer","receiptQty","receiptQuantityKnown","reconciledAt","observedAt",
  "manualReceiptSource","manualPayment","quantity"}
local receiptFields={"receiptID","verifiedGross","verifiedNet","verifiedCut", "verifiedDeposit",
  "receiptBuyer","receiptQty","receiptQuantityKnown","reconciledAt","observedAt"}

-- A deliberately narrower and reversible version of the existing manual
-- inspector match. Never calls Crafts.Observe or reallocates stock.
function AP.ReviewCommitReceipt(ch,id,auction,normalize)
  local claims=AP.DETest and AP.DETest.ConfirmedReceiptClaims
    and AP.DETest.ConfirmedReceiptClaims(ch) or {}
  if claims[id] then return nil,"Receipt belongs to a player-confirmed DE batch; revoke that confirmation first" end
  local targets,receipt,index=AP.ManualTargets(ch,id,normalize)
  if not receipt or not index then return nil,"Receipt is no longer eligible" end
  ch.reviewMatches=ch.reviewMatches or {}
  if ch.reviewMatches[id] then return nil,"This receipt already has a review link" end
  for _,r in ipairs(targets) do
    if tostring(r.auctionID)==tostring(auction) then
      local p=ch.craftLedger and ch.craftLedger.posts and ch.craftLedger.posts[tostring(auction)]
      if p and (p.fills or p.filled or p.gross or p.ended) then
        return nil,"Posting already has a payment or terminal state"
      end
      local old,expected={},{}
      for _,field in ipairs(changedFields) do old[field]=r[field] end
      local priorPost=p and {gross=p.gross,cut=p.cut,soldAt=p.soldAt} or nil
      r.manualReceiptSource=AP.Crafts.ManualReceiptSource(ch,r,receipt)
      r.manualPayment=true
      for _,field in ipairs(receiptFields) do r[field]=receipt[field] end
      r.quantity=r.quantity or receipt.receiptQty
      if p then
        p.soldAt=p.soldAt or r.soldAt
        p.gross=receipt.verifiedGross
        p.cut=receipt.verifiedCut
      end
      for _,field in ipairs(changedFields) do expected[field]=r[field] end
      ch.reviewMatches[id]={auctionID=r.auctionID,receipt=copy(receipt),
        before=old,expected=expected,postBefore=priorPost,
        postAfter=p and {gross=p.gross,cut=p.cut,soldAt=p.soldAt} or nil,
        confirmedAt=time()}
      table.remove(ch.sold,index)
      if ch.reviewDismissed then ch.reviewDismissed[id]=nil end
      return r
    end
  end
  return nil,"No eligible auction with that ID"
end

function AP.ReviewUndoReceipt(ch,id)
  local records=ch.reviewMatches
  local evidence=records and records[id]
  if not evidence then return false,"No saved review match to undo" end
  local sale,count=nil,0
  for _,pool in ipairs({ch.sold or {},ch.deleted or {},ch.active or {},ch.ended or {}}) do
    for _,row in ipairs(pool) do
      if tostring(row.auctionID)==tostring(evidence.auctionID) then
        if row.receiptID==id and pool==ch.sold then sale=row end
        if row.receiptID==id then count=count+1 end
      end
      if row.mailOnly and row.receiptID==id then
        return false,"Original receipt is already present"
      end
    end
  end
  if count~=1 or not sale then return false,"Auction/payment changed since confirmation" end
  for _,field in ipairs(changedFields) do
    if sale[field]~=evidence.expected[field] then
      return false,"Auction data changed; cannot safely undo"
    end
  end
  local p=ch.craftLedger and ch.craftLedger.posts and ch.craftLedger.posts[tostring(evidence.auctionID)]
  if evidence.postAfter then
    if not p or p.fills or p.filled or p.ended or p.returnedUnits or p.remainderTo
        or p.gross~=evidence.postAfter.gross or p.cut~=evidence.postAfter.cut
        or p.soldAt~=evidence.postAfter.soldAt then
      return false,"Posting changed; cannot safely undo"
    end
  end
  for _,field in ipairs(changedFields) do sale[field]=evidence.before[field] end
  if evidence.postBefore then
    p.gross=evidence.postBefore.gross
    p.cut=evidence.postBefore.cut
    p.soldAt=evidence.postBefore.soldAt
  end
  table.insert(ch.sold,copy(evidence.receipt))
  table.sort(ch.sold,function(a,b) return (a.soldAt or 0)>(b.soldAt or 0) end)
  records[id]=nil
  return true
end

local function textLine(body,s,y,kind)
  textsUsed=textsUsed+1
  local f=textPool[textsUsed]
  if not f then
    f=body:CreateFontString(nil,"OVERLAY","GameFontHighlightSmall")
    textPool[textsUsed]=f
  end
  f:ClearAllPoints()
  f:SetPoint("TOPLEFT",12,-y)
  f:SetWidth(580)
  f:SetJustifyH("LEFT")
  f:SetFontObject(kind or "GameFontHighlightSmall")
  f:SetText(s)
  f:Show()
  return y+20
end
local function action(body,s,y,callback,width)
  buttonsUsed=buttonsUsed+1
  local b=buttonPool[buttonsUsed]
  if not b then
    b=CreateFrame("Button",nil,body,"UIPanelButtonTemplate")
    buttonPool[buttonsUsed]=b
  end
  b:ClearAllPoints()
  b:SetSize(width or 570,24)
  b:SetPoint("TOPLEFT",12,-y)
  b:SetText(s)
  b:SetScript("OnClick",callback)
  b:Show()
  return y+27
end
local function build(ch,normalize,money,refresh)
  if not window or not window:IsShown() then return end
  for _,f in ipairs(textPool) do f:Hide() end
  for _,b in ipairs(buttonPool) do b:Hide() end
  textsUsed,buttonsUsed=0,0
  local rows,priority=AP.ReviewReceiptCases(ch,normalize,showOther,showDismissed)
  local matches,purchases=0,0
  for _,entry in ipairs(rows) do
    if entry.priority then matches=matches+#entry.targets; purchases=purchases+#entry.purchases end
  end
  window.count:SetText(priority.." possible flip receipts | "..matches.." auction / "..purchases.." purchase choices")
  window.other:SetText(showOther and "Hide other sales" or "Show other sales")
  window.dismissed:SetText(showDismissed and "Hide dismissed" or "Show dismissed")
  local body=window.body
  local y=5
  if #rows==0 then
    y=textLine(body,"No receipts in this filter. Existing linked payments are not shown.",y)
  end
  for _,entry in ipairs(rows) do
    local r=entry.receipt
    local id=r.receiptID
    local header=(entry.priority and "? FLIP REVIEW: " or "Other: ")..(r.name or "Unknown item")..
      "  "..id.."  x"..tostring(r.receiptQty or "?").."  "..
      (type(r.verifiedNet)=="number" and money(r.verifiedNet) or "Net unknown")..
      (entry.dismissed and "  [dismissed]" or "")
    y=action(body,header,y,function()
      selectedReceipt=selectedReceipt==id and nil or id
      pendingAction=nil
      build(ch,normalize,money,refresh)
    end)
    if selectedReceipt==id then
      y=textLine(body,"------------ RECEIPT EVIDENCE ------------",y,"GameFontNormalSmall")
      y=textLine(body,"Gross: "..money(r.verifiedGross).."    Cut: "..money(r.verifiedCut)..
        "    Deposit returned: "..money(r.verifiedDeposit),y)
      y=textLine(body,"Collected: "..money(r.verifiedNet).."    Qty: "..tostring(r.receiptQty or "?")..
        "    Seen: "..when(r.observedAt),y)
      y=textLine(body,"------------ POSSIBLE AUCTIONS ------------",y,"GameFontNormalSmall")
      if #entry.targets==0 then
        y=textLine(body,"No recorded auction match. Check available purchase sources below.",y)
      end
      for _,sale in ipairs(entry.targets) do
        local paid,cost,note=sourceEvidence(ch,sale)
        local label="#"..sale.auctionID.."  x"..tostring(sale.quantity or "?")..
          "  "..money(sale.buyout or 0).."  "..when(sale.soldAt).."  "..
          (cost and ("Cost "..money(cost)) or "Cost unverified")..
          (paid and cost and " [STRONG SOURCE]" or paid and " [PARTIAL SOURCE]" or " [POSSIBLE]")
        local key=id.."/"..tostring(sale.auctionID)
        y=action(body,pendingAction==key and "CONFIRM MATCH: "..label or "Review: "..label,y,function()
          if pendingAction~=key then
            pendingAction=key
          else
            local linked,err=AP.ReviewCommitReceipt(ch,id,sale.auctionID,normalize)
            if linked then
              selectedReceipt=nil
              pendingAction=nil
              refresh()
            else
              window.message:SetText("Match declined: "..tostring(err))
              pendingAction=nil
            end
          end
          build(ch,normalize,money,refresh)
        end)
        if pendingAction==key then
          y=textLine(body,"Confirm only if this is the correct auction. "..note..". Click again to link.",y)
        end
      end
      if #entry.purchases>0 and #entry.targets==0 then
        y=textLine(body,"------------ PURCHASE COST RECOVERY ------------",y,"GameFontNormalSmall")
        for _,choice in ipairs(entry.purchases) do
          local source=choice.source
          local key=id.."/purchase/"..source
          local label="Purchase #"..choice.buy.purchaseID.."  "..money(choice.cost).."  "..when(choice.buy.boughtAt)
          y=action(body,(pendingAction==key and "CONFIRM PURCHASE: " or "Review: ")..label,y,function()
            if pendingAction~=key then pendingAction=key
            else
              if AP.MailFlip.Commit(ch,r,source,normalize,true) then selectedReceipt=nil; refresh()
              else window.message:SetText("Purchase is no longer eligible.") end
              pendingAction=nil
            end
            build(ch,normalize,money,refresh)
          end)
        end
      end
      y=action(body,entry.dismissed and "Restore to review queue" or "Reject / dismiss this suggestion",y,function()
        ch.reviewDismissed=ch.reviewDismissed or {}
        ch.reviewDismissed[id]=entry.dismissed and nil or true
        selectedReceipt=nil
        pendingAction=nil
        build(ch,normalize,money,refresh)
        refresh()
      end,320)
    end
  end
  local undo=ch.reviewMatches or {}
  local ids={}
  for id in pairs(undo) do ids[#ids+1]=id end
  table.sort(ids)
  if #ids>0 then
    y=y+12
    y=textLine(body,"------------ MANUALLY LINKED / UNDO ------------",y,"GameFontNormalSmall")
    for _,id in ipairs(ids) do
      local record=undo[id]
      local key="undo/"..id
      y=action(body,(pendingAction==key and "CONFIRM UNDO: " or "Undo available: ")..
        id.." -> #"..tostring(record.auctionID),y,function()
        if pendingAction~=key then pendingAction=key
        else
          local success,err=AP.ReviewUndoReceipt(ch,id)
          if success then
            selectedReceipt=id
            window.message:SetText("Restored "..id.." to unmatched receipts.")
            refresh()
          else window.message:SetText("Undo blocked: "..tostring(err)) end
          pendingAction=nil
        end
        build(ch,normalize,money,refresh)
      end)
    end
  end
  for _,r in ipairs(ch.sold or {}) do
    if r.mailFlip then
      local receipt=r
      local key="undo-purchase/"..r.receiptID
      y=action(body,(pendingAction==key and "CONFIRM UNDO: " or "Undo recovered purchase: ")..r.name.."  "..r.receiptID,y,function()
        if pendingAction~=key then pendingAction=key
        else
          if AP.MailFlip.Undo(ch,receipt) then selectedReceipt=receipt.receiptID; refresh()
          else window.message:SetText("Undo blocked: purchase allocation changed.") end
          pendingAction=nil
        end
        build(ch,normalize,money,refresh)
      end)
    end
  end
  body:SetHeight(math.max(y+12,1))
end

function AP.OpenReceiptReview(parent,ch,normalize,money,refresh)
  if not window then
    window=CreateFrame("Frame","AuctionPeekReceiptReview",UIParent)
    window:SetSize(660,505)
    window:SetPoint("CENTER",UIParent,"CENTER",0,0)
    window:SetFrameStrata("DIALOG")
    window:EnableMouse(true)
    window:SetMovable(true)
    window:RegisterForDrag("LeftButton")
    window:SetScript("OnDragStart",function(self) self:StartMoving() end)
    window:SetScript("OnDragStop",function(self) self:StopMovingOrSizing() end)
    local bg=window:CreateTexture(nil,"BACKGROUND")
    bg:SetAllPoints()
    bg:SetColorTexture(.055,.05,.045,1)
    local border=window:CreateTexture(nil,"BORDER")
    border:SetPoint("TOPLEFT",-1,1)
    border:SetPoint("BOTTOMRIGHT",1,-1)
    border:SetColorTexture(.5,.39,.18,0.6)
    bg:SetDrawLayer("ARTWORK")
    local label=window:CreateFontString(nil,"OVERLAY","GameFontNormalLarge")
    label:SetPoint("TOPLEFT",14,-12)
    label:SetText("Unmatched Flip Receipts")
    local close=CreateFrame("Button",nil,window,"UIPanelCloseButton")
    close:SetPoint("TOPRIGHT",2,2)
    close:SetScript("OnClick",function()window:Hide()end)
    local count=window:CreateFontString(nil,"OVERLAY","GameFontHighlightSmall")
    count:SetPoint("TOPLEFT",14,-38)
    window.count=count
    local other=CreateFrame("Button",nil,window,"UIPanelButtonTemplate")
    other:SetSize(118,21)
    other:SetPoint("TOPRIGHT",-42,-33)
    window.other=other
    local dismissed=CreateFrame("Button",nil,window,"UIPanelButtonTemplate")
    dismissed:SetSize(102,21)
    dismissed:SetPoint("RIGHT",other,"LEFT",-5,0)
    window.dismissed=dismissed
    local scroll=CreateFrame("ScrollFrame",nil,window,"UIPanelScrollFrameTemplate")
    scroll:SetPoint("TOPLEFT",12,-66)
    scroll:SetPoint("BOTTOMRIGHT",-30,41)
    local body=CreateFrame("Frame",nil,scroll)
    body:SetWidth(615)
    body:SetHeight(1)
    scroll:SetScrollChild(body)
    window.body=body
    local message=window:CreateFontString(nil,"OVERLAY","GameFontHighlightSmall")
    message:SetPoint("BOTTOMLEFT",14,15)
    message:SetWidth(630)
    message:SetJustifyH("LEFT")
    message:SetText("Click a receipt, choose a candidate, then click again to confirm. No automatic matches.")
    window.message=message
    window:EnableKeyboard(true)
    window:SetPropagateKeyboardInput(true)
    window:SetScript("OnKeyDown",function(self,key)
      if InCombatLockdown and InCombatLockdown() then return end
      self:SetPropagateKeyboardInput(key~="ESCAPE")
      if key=="ESCAPE" then self:Hide() end
    end)
    other:SetScript("OnClick",function()
      showOther=not showOther
      build(window.ch,window.normalize,window.money,window.refresh)
    end)
    dismissed:SetScript("OnClick",function()
      showDismissed=not showDismissed
      build(window.ch,window.normalize,window.money,window.refresh)
    end)
    window:SetScript("OnHide",function() pendingAction=nil end)
  end
  window.ch,window.normalize,window.money,window.refresh=ch,normalize,money,refresh
  window:Show()
  build(ch,normalize,money,refresh)
end
