-- Auction Peek 2.5.34: timestamped, complete paired AH searches.
local _, AP = ...
local events = CreateFrame("Frame")
local panel, active, redraw
local fields, caps, labels, lines = {}, {}, {}, {}
local message = "Open the auction house to scan."
local function database()
  local char = AP.Character()
  char.supply = char.supply or {ids = {2592, 4306}, limits = {}, history = {}}
  return char.supply
end
local function status(text)
  message = text
  if panel and panel:IsShown() then redraw() end
end
local function finish(text)
  active = nil
  status(text)
end
local function series(db, a, b)
  return db.history[a .. "/" .. b]
end

-- All quantities include bid-only rows. Price metrics use buyouts only.
local function summarize(rows, cap)
  local total, cheap, taken, cost = 0, 0, 0, 0
  table.sort(rows, function(a,b) return (a.price or math.huge) < (b.price or math.huge) end)
  for _, row in ipairs(rows) do
    total = total + row.qty
    if row.price then
      if cap and row.price <= cap then cheap = cheap + row.qty end
      local qty = math.min(20 - taken, row.qty)
      cost = cost + qty * row.price
      taken = taken + qty
    end
  end
  return {lowest=rows[1] and rows[1].price, total=total, cheap=cap and cheap, cap=cap, price=taken == 20 and cost / 20 or nil}
end

local function schedule(job, fn)
  if active ~= job then return end
  if GetTime() >= job.deadline then finish("Scan timed out. No pair saved."); return end
  local api = C_AuctionHouse
  if api.IsThrottledMessageSystemReady and not api.IsThrottledMessageSystemReady() then
    C_Timer.After(0.35, function() schedule(job, fn) end)
    return
  end
  local ok = pcall(fn)
  if not ok and active == job then finish("Search unavailable. No pair saved.") end
end

local function request(job)
  local id = job.ids[job.index]
  job.key = C_AuctionHouse.MakeItemKey(id)
  job.phase = "queue"
  schedule(job, function()
    job.phase = "results"
    C_AuctionHouse.SendSearchQuery(job.key, {}, false)
  end)
end

local function readResults(event, key)
  local job = active
  if not job or job.phase ~= "results" then return end
  local api, id = C_AuctionHouse, job.ids[job.index]
  local commodity = event:find("COMMODITY", 1, true) ~= nil
  if commodity then
    if key ~= id then return end
  elseif type(key) ~= "table" or key.itemID ~= id then return
  else
    for _, field in ipairs({"itemLevel", "itemSuffix", "battlePetSpeciesID"}) do
      if (key[field] or 0) ~= (job.key[field] or 0) then return end
    end
  end
  local full = commodity and api.HasFullCommoditySearchResults or api.HasFullItemSearchResults
  if not full(key) then
    job.phase = "paging"
    schedule(job, function()
      job.phase = "results"
      if commodity then api.RequestMoreCommoditySearchResults(key)
      else api.RequestMoreItemSearchResults(key) end
    end)
    return
  end
  local count = commodity and api.GetNumCommoditySearchResults(key) or api.GetNumItemSearchResults(key)
  local rows = {}
  for i=1,count do
    local row
    if commodity then row = api.GetCommoditySearchResultInfo(key,i)
    else row = api.GetItemSearchResultInfo(key,i) end
    assert(row and row.quantity and row.quantity > 0)
    local price
    if commodity then
      assert(row.unitPrice and row.unitPrice > 0)
      price = row.unitPrice
    elseif row.buyoutAmount and row.buyoutAmount > 0 then price = row.buyoutAmount / row.quantity end
    rows[i] = {qty=row.quantity, price=price}
  end
  job[job.index] = summarize(rows, job.caps[job.index])
  if job.index == 1 then
    job.index = 2
    status("Scanning second item…")
    request(job)
    return
  end
  local db = database()
  local historyKey = job.ids[1] .. "/" .. job.ids[2]
  local history = db.history[historyKey] or {}
  db.history[historyKey] = history
  history[#history+1] = {at=time(), job[1], job[2]}
  if #history > 180 then table.remove(history,1) end
  finish("Pair saved.")
end

-- Bare numbers retain the 1.9 copper convention.
local function parseTarget(text)
  text = text:lower():match("^%s*(.-)%s*$")
  if text == "" then return nil end
  if text:match("^%d+$") then
    local value = tonumber(text)
    if value <= 2147483647 then return value end
    return false
  end
  local value, previous = 0, math.huge
  local units = {g=10000, s=100, c=1}
  while text ~= "" do
    local amount, unit, rest = text:match("^(%d+)%s*([gsc])%s*(.*)$")
    if not unit or units[unit] >= previous then return false end
    previous = units[unit]
    value = value + tonumber(amount) * previous
    if value > 2147483647 then return false end
    text = rest
  end
  return value
end

local function targetText(value)
  if not value then return "" end
  if value == 0 then return "0c" end
  return (AP.Money(value):gsub(" 0[sc]", ""))
end

local function scan()
  if active then return end
  if not AP.AtAuctioneer() then status("Open the auction house to scan."); return end
  local ids, limits = {}, {}
  for i=1,2 do
    ids[i] = tonumber(fields[i]:GetText())
    if not ids[i] or ids[i] < 1 or ids[i] > 2147483647 then status("Enter two positive item IDs."); return end
    limits[i] = parseTarget(caps[i]:GetText())
    if limits[i] == false then status("Use a price like 2s 40c, or leave the target blank."); return end
  end
  if ids[1] == ids[2] then status("Choose two different item IDs."); return end
  local db = database()
  db.ids = ids
  for i=1,2 do db.limits[ids[i]] = limits[i] end
  local job = {ids=ids, caps=limits, index=1, deadline=GetTime()+60}
  active = job
  status("Scanning first item…")
  C_Timer.After(60,function() if active == job then finish("Scan timed out. No pair saved.") end end)
  if not pcall(request,job) then finish("Search unavailable. No pair saved.") end
end
for _, event in ipairs({"COMMODITY_SEARCH_RESULTS_UPDATED","COMMODITY_SEARCH_RESULTS_ADDED",
    "ITEM_SEARCH_RESULTS_UPDATED","ITEM_SEARCH_RESULTS_ADDED","AUCTION_HOUSE_CLOSED"}) do
  pcall(events.RegisterEvent, events, event)
end
events:SetScript("OnEvent", function(_, event, key)
  if not active then return end
  if event == "AUCTION_HOUSE_CLOSED" then finish("Auction house closed. No pair saved.")
  elseif not pcall(readResults,event,key) then finish("Incomplete search data. No pair saved.") end
end)

local function ownCounts(id)
  local char, sold, expired = AP.Character(), 0, 0
  local cutoff = time()-86400
  for _,r in ipairs(char.sold) do
    if tonumber(r.itemID) == id and (r.soldAt or 0) >= cutoff then sold = sold + (r.quantity or 1) end
  end
  for _,r in ipairs(char.ended) do
    if tonumber(r.itemID) == id and r.endedReason == "expired" and (r.endedAt or 0) >= cutoff then
      expired = expired + (r.quantity or 1)
    end
  end
  return sold, expired
end

local colors = {{0.4,0.84,1},{1,0.76,0.32}}
local function chart(history)
  for _,line in ipairs(lines) do line:Hide() end
  local n = #history
  if n < 2 then return "Supply trend • two completed scans needed" end
  local first = math.max(1,n-29)
  local base, peak, used = {}, 100, 0
  for i=1,2 do
    for j=first,n do
      local qty = history[j][i].total
      if qty > 0 and not base[i] then base[i] = qty end
      if base[i] then peak = math.max(peak,100*qty/base[i]) end
    end
  end
  local function point(j,i)
    local span = history[n].at-history[first].at
    local x = span > 0 and (history[j].at-history[first].at)/span or (j-first)/(n-first)
    return 25+510*x,-330+70*(100*history[j][i].total/base[i])/peak
  end
  for i=1,2 do
    if base[i] then
      for j=first+1,n do
        used=used+1
        local line=lines[used] or panel:CreateLine(nil,"ARTWORK")
        lines[used]=line
        local x,y=point(j-1,i)
        line:SetStartPoint("TOPLEFT",panel,x,y)
        x,y=point(j,i)
        line:SetEndPoint("TOPLEFT",panel,x,y)
        line:SetThickness(2)
        line:SetColorTexture(unpack(colors[i]))
        line:Show()
      end
    end
  end
  return "Listed units • first positive count = 100 • " .. date("%m/%d %H:%M",history[first].at) .. " to " .. date("%m/%d %H:%M",history[n].at)
end

local function textAt(x,y,w,text)
  local s = panel:CreateFontString(nil,"OVERLAY","GameFontHighlightSmall")
  s:SetPoint("TOPLEFT",x,y); s:SetWidth(w); s:SetJustifyH("LEFT"); s:SetText(text)
  return s
end
local function input(x,y,w)
  local e = CreateFrame("EditBox",nil,panel,"InputBoxTemplate")
  e:SetPoint("TOPLEFT",x,y); e:SetSize(w,22); e:SetNumeric(true); e:SetMaxLetters(10)
  e:SetAutoFocus(false); e:SetScript("OnEnterPressed",function(self) self:ClearFocus() end)
  return e
end
local function itemName(id)
  local get = C_Item and C_Item.GetItemNameByID or GetItemInfo
  return get and get(id) or ("Item "..id)
end
redraw = function()
  local db = database()
  local a,b = tonumber(fields[1]:GetText()),tonumber(fields[2]:GetText())
  local h = a and b and series(db,a,b) or {}
  for i,id in ipairs({a or 0,b or 0}) do
    local last = h[#h] and h[#h][i]
    local sold, expired = ownCounts(id)
    local target = parseTarget(caps[i]:GetText())
    local cheap = target and last and target == last.cap and last.cheap
    local delta = last and h[#h-1] and string.format(" (%+d)",last.total-h[#h-1][i].total) or ""
    labels[i]:SetText((id>0 and itemName(id) or "Enter item ID").."\nListed units: "..
      (last and last.total or "—")..delta.."\nLowest each: "..(last and last.lowest and AP.Money(last.lowest) or "—")..
      (target and ("\nAt or below "..targetText(target)..": "..(cheap and cheap.." units" or "scan needed")) or "").."\nCheapest 20, avg/unit: "..
      (last and last.price and AP.Money(last.price) or "—")..
      "\nYour units (24h): "..sold.." sold  /  "..expired.." expired")
  end
  panel.caption:SetText(chart(h))
  panel.status:SetText(message..(h[#h] and "   Last pair: "..date("%m/%d %H:%M",h[#h].at) or ""))
  panel.scan:SetEnabled(not active)
  for i=1,2 do fields[i]:SetEnabled(not active); caps[i]:SetEnabled(not active) end
end
function AP.Toggle()
  if panel then panel:SetShown(not panel:IsShown()); return end
  local db=database()
  panel=CreateFrame("Frame","AuctionPeekSupplyFrame",UIParent,"BasicFrameTemplateWithInset")
  panel:SetSize(560,388); panel:SetPoint("CENTER"); panel:SetFrameStrata("DIALOG")
  panel:SetClampedToScreen(true); panel:SetMovable(true); panel:EnableMouse(true)
  panel:RegisterForDrag("LeftButton")
  panel:SetScript("OnDragStart",panel.StartMoving); panel:SetScript("OnDragStop",panel.StopMovingOrSizing)
  table.insert(UISpecialFrames,"AuctionPeekSupplyFrame")
  textAt(14,-6,420,"Auction Peek  v2.5.42   •   Supply trends")
  for i=1,2 do
    local x=20+(i-1)*271
    textAt(x,-39,100,"Item ID")
    textAt(x+108,-39,142,"Buy at or below (each)")
    fields[i]=input(x,-55,88); fields[i]:SetText(tostring(db.ids[i]))
    caps[i]=input(x+108,-55,108); caps[i]:SetNumeric(false); caps[i]:SetMaxLetters(20); caps[i]:SetText(targetText(db.limits[db.ids[i]]))
    fields[i]:SetScript("OnTextChanged",function(self)
      caps[i]:SetText(targetText(db.limits[tonumber(self:GetText()) or 0]))
      if panel.scan then redraw() end
    end)
    caps[i]:SetScript("OnTextChanged", function() if panel.scan then redraw() end end)
    local hover = CreateFrame("Frame", nil, panel)
    hover:SetPoint("TOPLEFT", x, -116); hover:SetSize(255, 100); hover:EnableMouse(true)
    hover:SetScript("OnEnter", function(self)
      local a,b = tonumber(fields[1]:GetText()), tonumber(fields[2]:GetText())
      local h = a and b and series(db,a,b) or {}
      local current = h[#h] and h[#h][i]
      local prev = h[#h-1] and h[#h-1][i]
      local target = parseTarget(caps[i]:GetText())
      if not target then return end
      GameTooltip:SetOwner(self, "ANCHOR_RIGHT")
      GameTooltip:AddLine("Buyouts at or below " .. targetText(target) .. " each")
      if current and current.cap == target and current.cheap then
        GameTooltip:AddLine("Latest scan: " .. current.cheap .. " units")
        if prev and prev.cap == target and prev.cheap then
          GameTooltip:AddLine("Previous scan: " .. prev.cheap .. " units")
        else
          GameTooltip:AddLine("Comparison needs two scans at this target.")
        end
      else
        GameTooltip:AddLine("Scan both items to count units at this target.")
      end
      GameTooltip:Show()
    end)
    hover:SetScript("OnLeave", function() if GameTooltip:IsOwned(hover) then GameTooltip:Hide() end end)
    labels[i]=textAt(x,-116,255,""); labels[i]:SetTextColor(unpack(colors[i]))
  end
  panel.scan=CreateFrame("Button",nil,panel,"UIPanelButtonTemplate")
  panel.scan:SetSize(92,23); panel.scan:SetPoint("TOPLEFT",16,-84); panel.scan:SetText("Scan Both")
  panel.scan:SetScript("OnClick",scan)
  panel.status=textAt(116,-90,428,"")
  panel.caption=textAt(20,-225,520,"")
  textAt(20,-349,520,"Market changes include purchases, expirations, cancellations and new listings.\nYour 24h totals count recorded outcomes matched to the exact item ID.")
  panel:SetScript("OnShow",redraw)
  redraw()
end
