local _, AP = ...
local R = {}
AP.Reconciliation = R

-- This correction is tied to the observed sale and the exact exhausted lots.
-- Validate the entire chain before changing any field.
function R.ConfirmMageweaveBoots(ch)
  local l=ch.craftLedger
  local id="215398138"
  local post=l and l.posts[id]
  if not post or l.mageweaveBootsConfirmationV1 or post.itemID~=10026
      or post.at~=1795630259 or post.soldAt~=1795630310 or post.quantity~=1
      or post.totalPrice~=13900 or not post.ownedSold
      or post.returnedUnits or post.remainderTo or #(post.parts or {})~=1 then return end
  local matching=0
  for _,r in ipairs(ch.sold or {}) do
    if tostring(r.auctionID)==id and r.itemID==10026 and r.sold and r.quantity==1 then
      matching=matching+1
    end
  end
  if matching~=1 then return end
  local function lot(i,item,n,cost)
    local x=l.lots[i]
    if x and x.itemID==item and x.quantity==n and x.cost==cost and x.left==0 and x.balance==0 then return x end
  end
  local function matches(p,source,item,n,cost,unknown)
    return p and p.source==source and p.itemID==item and p.n==n and p.cost==cost
      and not p.estimate and (not not p.unknown)==unknown
  end
  local first=lot(1243,4339,1,436)
  local second=lot(1244,4339,1,1308)
  local boots=lot(1249,10026,1,9119)
  local loot=lot(1067,4338,4,0)
  local cloth=lot(1238,4338,4,1744)
  local bolt=lot(1247,4339,1,2299)
  local leather=lot(1248,4304,2,1836)
  local thread=l.lots[1242]
  if not (loot and loot.looted and cloth and cloth.purchase==372 and bolt and bolt.purchase==377
      and leather and leather.purchase==378 and thread and thread.itemID==8343 and thread.vendor
      and first and first.at==1795628040 and not first.unknown and #(first.parts or {})==2
      and second and second.at==1795628048 and second.unknown and #(second.parts or {})==2
      and boots and boots.at==1795630117 and boots.unknown and #(boots.parts or {})==5) then return end
  local missing=second.parts[2]
  local a=boots.parts
  local posted=post.parts[1]
  if not (matches(first.parts[1],1067,4338,4,0,false)
      and matches(first.parts[2],1238,4338,1,436,false)
      and matches(second.parts[1],1238,4338,3,1308,false)
      and matches(missing,nil,4338,2,0,true) and missing.reason=="INSUFFICIENT_TRACKED"
      and matches(a[1],1243,4339,1,436,false) and matches(a[2],1244,4339,1,1308,true)
      and matches(a[3],1247,4339,1,2299,false) and matches(a[4],1242,8343,2,3240,false)
      and matches(a[5],1248,4304,2,1836,false) and matches(posted,1249,10026,1,9119,true)) then return end
  for _,x in ipairs(l.lots) do
    for _,p in ipairs(x.parts or {}) do
      if p.source==1249 or (p.source==1244 and p~=a[2]) then return end
    end
  end
  for _,x in pairs(l.posts) do
    for _,p in ipairs(x.parts or {}) do
      if p.source==1244 or (p.source==1249 and p~=posted) then return end
    end
  end
  missing.confirmedLoot=true
  missing.reason="PLAYER_CONFIRMED_LOOT_20261125"
  missing.reconciliation={auctionID=id, priorReason="INSUFFICIENT_TRACKED", evidence="Player confirmed the two consumed Mageweave Cloth were looted."}
  missing.unknown,second.unknown,a[2].unknown,boots.unknown,posted.unknown=nil,nil,nil,nil,nil
  l.mageweaveBootsConfirmationV1=true
  return true
end

local function whole(n)
  return AP.MailValueReadable(n) and type(n)=="number" and n>=0 and n%1==0
end

function R.Count(id)
  local count=(C_Item and C_Item.GetItemCount) or GetItemCount
  if count then
    local ok,n=pcall(count,id,false,false)
    if ok and whole(n) then return n end
  end
end

-- A successful cast is authoritative for fixed inputs and outputs even when
-- the client has not published the resulting bag counts yet.
local adjustments=setmetatable({}, {__mode="k"})
function R.CraftCount(ch,id,raw)
  local state=adjustments[ch]
  local entry=state and state[id]
  if entry and raw~=nil then
    local change=raw-entry.raw
    if entry.pending<0 then
      entry.pending=math.min(0,entry.pending-math.min(0,change))
    else
      entry.pending=math.max(0,entry.pending-math.max(0,change))
    end
    entry.raw=raw
    if entry.pending==0 then state[id]=nil end
    return math.max(0,raw+entry.pending)
  end
  return raw
end

function R.CraftCommitted(ch,recipe)
  if not recipe.rawCounts then return end
  local state=adjustments[ch] or {}
  adjustments[ch]=state
  local function adjust(id,n)
    local raw=recipe.rawCounts[id]
    if raw~=nil then
      local entry=state[id] or {raw=raw,pending=0}
      entry.pending=entry.pending+n
      state[id]=entry
    end
  end
  for _,m in ipairs(recipe.mats) do adjust(m.id,-m.n) end
  adjust(recipe.id,recipe.n)
  R.RefreshCounts(ch)
end

function R.RefreshCounts(ch)
  for id in pairs(adjustments[ch] or {}) do R.CraftCount(ch,id,R.Count(id)) end
end

-- These owned sales survived, but no creation event/lot allocation survived.
-- Restore enough evidence for receipt matching and manual purchase review.
function R.RecoverRecipeSales(ch)
  local l=ch.craftLedger
  if not l then return end
  local expected={["214922938"]={22308,34200},["214924314"]={13948,28000}}
  for _,r in ipairs(ch.sold or {}) do
    local key=tostring(r.auctionID)
    local e=expected[key]
    if e and not l.posts[key] and r.sold and r.itemID==e[1] and r.buyout==e[2]
        and r.quantity==1 and r.soldAt==1795627266 and not r.repostedAs and not r.returnCollectedAt then
      l.posts[key]={at=r.soldAt, observedWithoutAllocation=true, restoredFromSale=true,
        itemID=r.itemID,quantity=1,totalPrice=r.buyout,name=r.name,ownedSold=true,soldAt=r.soldAt,
        playerReportedPayment=true,
        parts={{itemID=r.itemID,n=1,cost=0,unknown=true,reason="POSTING_EVENT_MISSING"}}}
    end
  end
end


function R.VerifiedProceeds(r)
  if not r or not r.receiptID then return end
  local gross,cut,deposit,payout=r.verifiedGross,r.verifiedCut,r.verifiedDeposit,r.verifiedNet
  if type(gross)=="number" and type(cut)=="number" and type(deposit)=="number"
      and type(payout)=="number" and gross>0 and cut>=0 and cut<=gross and deposit>=0
      and math.abs(gross-cut+deposit-payout)<=2 then return gross-cut end
end
