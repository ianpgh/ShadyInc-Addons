-- Auction Peek v2.5.47: proof-gated recovery of a sold full DE stack whose
-- owned posting also received a conflicting canceled event.
-- Never infer a payment from item identity alone, and never change cost lots.
local _, AP = ...

local function identity(text)
  if type(text)~="string" then return "" end
  local name=text:match("|h%[([^%]]+)%]|h") or text
  return name:gsub("^%s+",""):gsub("%s+$",""):lower()
end
local function paidReceipt(r)
  return type(r)=="table" and r.mailOnly==true and not r.mailFlip and not r.auctionID
    and type(r.receiptID)=="string" and r.receiptID:match("^mail:%d+$")
    and type(r.name)=="string" and r.receiptQuantityKnown==true
    and type(r.receiptQty)=="number" and r.receiptQty>=1
    and r.receiptQty%1==0 and type(r.verifiedGross)=="number"
    and r.verifiedGross>0 and type(r.verifiedNet)=="number"
    and type(r.verifiedCut)=="number" and r.verifiedCut>=0
    and r.verifiedCut<=r.verifiedGross
    and type(r.verifiedDeposit)=="number" and r.verifiedDeposit>=0
    and r.verifiedGross-r.verifiedCut+r.verifiedDeposit==r.verifiedNet
    and type(r.observedAt)=="number" and r.observedAt>0
end
local function possibleSale(s,r)
  if type(s)~="table" or not s.auctionID or type(s.soldAt)~="number"
      or type(s.quantity)~="number" or type(s.buyout)~="number" then return false end
  if identity(s.name or s.link)~=identity(r.name) or s.quantity~=r.receiptQty
      or s.buyout~=r.verifiedGross or s.soldAt>r.observedAt
      or r.observedAt-s.soldAt>86400 then return false end
  if s.firstSeenAt and s.firstSeenAt>r.observedAt then return false end
  return true
end
local function completePost(p,s,r)
  if type(p)~="table" or p.ended~="canceled" or p.awaitingReturn~=true
      or p.ownedSold or p.filled or p.fills or p.gross or p.returnedUnits
      or p.remainingSeen or p.fillLimit or p.remainderTo or p.unresolved
      or type(p.at)~="number" or type(p.soldAt)~="number"
      or type(p.quantity)~="number" or p.quantity~=r.receiptQty
      or type(p.itemID)~="number" or p.itemID~=s.itemID
      or type(p.totalPrice)~="number" or p.totalPrice<=0
      or p.totalPrice*p.quantity~=r.verifiedGross
      or p.soldAt~=s.soldAt or p.at>p.soldAt
      or s.firstSeenAt and math.abs(s.firstSeenAt-p.at)>120
      or s.cancelRequestedAt or s.returnCollectedAt or s.repostedAs
      or s.endedReason or s.mailOnly or not s.sold or s.receiptID
      or type(p.parts)~="table" or #p.parts==0 then return false end
  local total=0
  for _,part in ipairs(p.parts) do
    if type(part.n)~="number" or part.n<=0 or part.n%1~=0
        or part.itemID~=p.itemID then return false end
    total=total+part.n
  end
  return total==p.quantity
end
local function uniqueCleanDE(ch,p)
  if type(ch.deAutoSinceV2546)~="number" then return false end
  local count=0
  for _,r in ipairs(ch.deTests or {}) do
    if type(r.at)=="number" and r.at>=ch.deAutoSinceV2546 and r.at<=p.at
        and p.at-r.at<=600 and r.status=="Bag and loot agree" and r.held==1
        and type(r.guid)=="string" and type(r.input)=="number"
        and type(r.outputs)=="table" and type(r.preexisting)=="table"
        and r.outputs[p.itemID]==p.quantity and r.preexisting[p.itemID]==0
        and not (r.manualDE and (r.manualDE.purchaseID or r.manualDE.auctionID)) then
      local outputs=0
      for _,n in pairs(r.outputs) do
        if type(n)~="number" or n<=0 then return false end
        outputs=outputs+1
      end
      if outputs==1 then count=count+1 end
    end
  end
  return count==1
end
local function uniqueClaim(ch,mail,target)
  local matches=0
  local receiptCount=0
  local key=tostring(target.auctionID)
  for _,poolName in ipairs({"sold","deleted","active","ended"}) do
    for _,row in ipairs(ch[poolName] or {}) do
      if row.receiptID==mail.receiptID then
        receiptCount=receiptCount+1
        if row~=mail then return false end
      end
      if row.auctionID and tostring(row.auctionID)==key and row~=target then
        return false
      end
      -- A second matching listing, including one already paid, makes this
      -- particular invoice ambiguous; do not award its money to either.
      if row~=target and row.auctionID and possibleSale(row,mail) then return false end
      if row==target then matches=matches+1 end
      -- A second identical collected invoice also makes this ambiguous.
      if row~=mail and row.mailOnly and not row.auctionID and paidReceipt(row)
          and identity(row.name)==identity(mail.name)
          and row.receiptQty==mail.receiptQty and row.verifiedGross==mail.verifiedGross
          and math.abs(row.observedAt-mail.observedAt)<=86400 then return false end
    end
  end
  if matches~=1 or receiptCount~=1 then return false end
  local posts=ch.craftLedger and ch.craftLedger.posts or {}
  for otherID,p in pairs(posts) do
    if tostring(otherID)~=key and p and p.itemID==target.itemID
        and p.quantity==mail.receiptQty and p.totalPrice
        and p.totalPrice*p.quantity==mail.verifiedGross
        and type(p.at)=="number" and p.at<=mail.observedAt
        and mail.observedAt-p.at<=86400
        and (p.soldAt or p.filled or p.gross) then return false end
    for receiptID in pairs(p.fills or {}) do
      if receiptID==mail.receiptID then return false end
    end
  end
  return true
end

-- Atomic operation: determine every dependency first, then update only the
-- target sale's receipt, this posting's verified lifecycle, and the mail row.
-- Store the unmodified invoice as evidence for future recovery/undo tooling.
function AP.ReconcileConflictedFullDE(ch)
  if type(ch)~="table" or not ch.craftLedger
      or type(ch.craftLedger.posts)~="table" then return 0 end
  local recovered=0
  for i=#(ch.sold or {}),1,-1 do
    local r=ch.sold[i]
    if paidReceipt(r) then
      local match,post
      for _,sale in ipairs(ch.sold) do
        local p=ch.craftLedger.posts[tostring(sale.auctionID)]
        if sale~=r and possibleSale(sale,r) and completePost(p,sale,r)
            and uniqueCleanDE(ch,p) then
          if match then match=nil; break end
          match,post=sale,p
        end
      end
      if match and uniqueClaim(ch,r,match) then
        -- Copy rather than alias the mail-only row, preserving audit evidence
        -- after that row is removed from the visible sale list.
        local original={}
        for k,v in pairs(r) do original[k]=v end
        for _,field in ipairs({"receiptID","verifiedGross","verifiedNet","verifiedCut",
            "verifiedDeposit","receiptBuyer","receiptQty","receiptQuantityKnown",
            "observedAt","reconciledAt"}) do match[field]=r[field] end
        post.recoveredFullDESale={rule=1,priorEnded=post.ended,
          originalReceipt=original,auctionID=match.auctionID,at=time()}
        post.ended,post.awaitingReturn,post.unresolved=nil,nil,nil
        post.ownedSold,post.filled,post.gross,post.cut=true,r.receiptQty,
          r.verifiedGross,r.verifiedCut
        post.fills={[r.receiptID]={quantity=r.receiptQty,gross=r.verifiedGross,
          net=r.verifiedNet,fee=r.verifiedCut,deposit=r.verifiedDeposit,
          buyer=r.receiptBuyer,observedAt=r.observedAt,reconciledAt=r.reconciledAt}}
        table.remove(ch.sold,i)
        recovered=recovered+1
      end
    end
  end
  return recovered
end

-- Full commodity invoice: the owned snapshot may report a unit price and
-- omit the delivery countdown. Require the complete stack, unique invoice,
-- and no evidence of an actual cancellation or returned inventory.
function AP.ReconcileUnitPriceStack(ch)
  local ledger=ch.craftLedger
  if not ledger then return 0 end
  local n=0
  local de=AP.DETest and AP.DETest.ConfirmedReceiptClaims and AP.DETest.ConfirmedReceiptClaims(ch) or {}
  for i=#ch.sold,1,-1 do
    local r=ch.sold[i]
    if paidReceipt(r) and r.receiptQty>1 and not de[r.receiptID] then
      local target,post,count=nil,nil,0
      local unit=r.verifiedGross/r.receiptQty
      for _,sale in ipairs(ch.sold) do
        local p=ledger.posts[tostring(sale.auctionID)]
        if sale~=r and sale.buyout==unit and sale.quantity==r.receiptQty then
          local normalized={}
          for k,v in pairs(sale) do normalized[k]=v end
          normalized.buyout=r.verifiedGross
          if possibleSale(normalized,r) and completePost(p,normalized,r) then
            target,post,count=sale,p,count+1
          end
        end
      end
      if count==1 and uniqueClaim(ch,r,target) then
        local safe=true
        for _,pool in ipairs({ch.active,ch.ended,ch.deleted,ch.sold}) do
          for _,other in ipairs(pool) do
            if other~=target and other~=r and identity(other.name or other.link)==identity(r.name)
                and (other.quantity==r.receiptQty or (other.quantity or 0)>r.receiptQty)
                and (other.buyout==unit or other.buyout==r.verifiedGross or other.unitPrice==unit
                  or (other.quantity and other.buyout==unit*other.quantity))
                and not (other.endedAt and other.endedAt<post.at and other.repostedAs==target.auctionID) then safe=false end
          end
        end
        if safe then
          post.unitPriceRecovery={originalReceipt=r,priorEnded=post.ended,priorBuyout=target.buyout}
          for _,field in ipairs({"receiptID","verifiedGross","verifiedNet","verifiedCut","verifiedDeposit",
              "receiptBuyer","receiptQty","receiptQuantityKnown","observedAt","reconciledAt","receiptRecordedAt"}) do target[field]=r[field] end
          post.ended,post.awaitingReturn,post.unresolved=nil,nil,nil
          post.ownedSold,post.filled,post.gross,post.cut=true,r.receiptQty,r.verifiedGross,r.verifiedCut
          post.fills={[r.receiptID]={quantity=r.receiptQty,gross=r.verifiedGross,fee=r.verifiedCut,
            net=r.verifiedNet,deposit=r.verifiedDeposit,buyer=r.receiptBuyer}}
          target.buyout=r.verifiedGross
          table.remove(ch.sold,i)
          n=n+1
        end
      end
    end
  end
  return n
end
