local _, AP = ...

-- A purchase call expresses intent. Commit only after carried units and the
-- actual copper deduction agree with the vendor's displayed bundle price.
function AP.InstallVendorTracking(storeBuy,ch)
  if not hooksecurefunc or not GetMoney then return end
  local modern = C_MerchantFrame or {}
  local countItems = C_Item and C_Item.GetItemCount or GetItemCount
  local numOffers = modern.GetNumItems or GetMerchantNumItems
  if not countItems or not numOffers then return end
  local function read(fn, ...)
    if not fn then return end
    local ok, v = pcall(fn, ...)
    if ok and not (issecretvalue and issecretvalue(v)) then return v end
  end
  local function offer(slot)
    local info = read(modern.GetItemInfo,slot)
    if not info and GetMerchantItemInfo then
      local ok,name,_,price,stack,_,_,extended = pcall(GetMerchantItemInfo,slot)
      if ok then info={name=name,price=price,stackCount=stack,hasExtendedCost=extended} end
    end
    if not info or info.hasExtendedCost or type(info.price)~="number" or info.price<=0 then return end
    local link = read(modern.GetItemLink or GetMerchantItemLink,slot)
    local id = info.itemID or read(GetMerchantItemID,slot) or (link and tonumber(link:match("item:(%d+)")))
    local bundle = info.stackCount or 1
    if type(id)=="number" and id>0 and type(bundle)=="number" and bundle>=1 then
      return {itemID=id,link=link,name=info.name,price=info.price,bundle=bundle}
    end
  end
  local session
  local function catalog(s)
    local n=read(numOffers)
    if type(n)~="number" then return end
    for i=1,n do
      local o=offer(i)
      if o then
        local old=s.offers[o.itemID]
        if old==nil then s.offers[o.itemID]=o
        elseif old and (old.price~=o.price or old.bundle~=o.bundle) then s.offers[o.itemID]=false end
        if s.counts[o.itemID]==nil then s.counts[o.itemID]=read(countItems,o.itemID) end
      end
    end
  end
  local function settle(s,allowRounding)
    local money=read(GetMoney)
    if type(money)~="number" or type(s.money)~="number" then return end
    if money>=s.money then return end
    local records,total={},0
    for id,o in pairs(s.offers) do
      local current=read(countItems,id)
      if type(current)~="number" then return end
      if type(s.counts[id])~="number" then return end
      local units=current-s.counts[id]
      if units<0 or (units>0 and (not o or units%o.bundle~=0)) then return end
      if units>0 then
        local paid=units/o.bundle*o.price
        records[#records+1]={itemID=id,name=o.name,link=o.link,quantity=units,price=paid,
          vendor=true,source="Vendor purchase confirmed by bag quantity and copper paid"}
        total=total+paid
      end
    end
    local spent=s.money-money
    if total==0 then return end
    if total~=spent then
      if allowRounding and ch then
        local details={}
        for _,r in ipairs(records) do
          details[#details+1]=r.quantity.."x "..(r.name or tostring(r.itemID))
        end
        ch.vendorCheck=table.concat(details,", ").." | quoted "..total.."c, money change "..spent.."c"
      end
      -- A discounted stack can round at checkout instead of per unit.
      -- Wait for stable updates and require one matching buy intent.
      local r=records[1]
      local intent=s.pending[r.itemID]
      if not allowRounding or #records~=1 or not intent or intent.bundle~=1
          or next(s.pending,r.itemID) or next(s.pending)~=r.itemID
          or r.quantity<=1 or math.abs(total-spent)>=r.quantity then return end
      r.price=spent
    end
    s.money=money
    for _,r in ipairs(records) do
      s.counts[r.itemID]=s.counts[r.itemID]+r.quantity
      -- Keep other intents pending if their server updates have not arrived.
      local intent=s.pending[r.itemID]
      if intent then
        intent.requested=intent.requested-r.quantity
        if intent.requested<=0 then s.pending[r.itemID]=nil end
      end
    end
    for _,r in ipairs(records) do
      if r.quantity>1 and AP.IsVendorSingle(r.itemID) then
        local total,units=r.price,r.quantity
        for i=1,units do
          local copy={}
          for k,v in pairs(r) do copy[k]=v end
          copy.quantity=1
          copy.price=math.floor(total*i/units)-math.floor(total*(i-1)/units)
          storeBuy(copy)
        end
      else storeBuy(r) end
    end
  end
  local function reset(s)
    s.counts,s.pending,s.offers,s.money={},{},{},read(GetMoney)
    if not s.closed then catalog(s) end
  end
  local function attempted(slot,quantity)
    local s=session
    if not s or s.closed then return end
    local o=offer(slot)
    if not o or s.counts[o.itemID]==nil then return end
    local prev=s.pending[o.itemID]
    if prev and (prev.price~=o.price or prev.bundle~=o.bundle) then reset(s);return end
    o.requested=(prev and prev.requested or 0)+math.max(o.bundle,tonumber(quantity) or o.bundle)
    s.pending[o.itemID]=o
    s.sequence=s.sequence+1
    local serial=s.sequence
    if C_Timer and C_Timer.After then
      C_Timer.After(3,function()
        if session==s and serial==s.sequence then
          if s.closed and s.idle then return end
          settle(s,true)
          if s.closed then session=nil elseif next(s.pending) then reset(s) end
        end
      end)
    end
  end
  if type(BuyMerchantItem)=="function" then hooksecurefunc("BuyMerchantItem",attempted) end
  if type(modern.BuyMerchantItem)=="function" then hooksecurefunc(modern,"BuyMerchantItem",attempted) end
  if type(modern.BuyItem)=="function" then hooksecurefunc(modern,"BuyItem",attempted) end
  local frame=CreateFrame("Frame")
  for _,event in ipairs({"MERCHANT_SHOW","MERCHANT_UPDATE","MERCHANT_CLOSED","PLAYER_MONEY","BAG_UPDATE_DELAYED"}) do frame:RegisterEvent(event) end
  frame:SetScript("OnEvent",function(_,event)
    if event=="MERCHANT_SHOW" then
      if session then settle(session) end
      session={sequence=0}
      reset(session)
      return
    end
    local s=session
    if not s then return end
    settle(s)
    if event=="MERCHANT_CLOSED" then s.closed=true
    elseif not s.closed and event=="MERCHANT_UPDATE" then catalog(s) end
    -- Bag and money notifications can arrive in either order, including after
    -- closing the merchant. Keep both baselines together until updates settle.
    s.idle=(s.idle or 0)+1
    local serial=s.idle
    if C_Timer and C_Timer.After then
      C_Timer.After(3,function()
        if session~=s or s.idle~=serial then return end
        settle(s,true)
        if s.closed then session=nil elseif not next(s.pending) then reset(s) end
      end)
    end
  end)
end

function AP.IsVendorSingle(id)
  local info=(C_Item and C_Item.GetItemInfo) or GetItemInfo
  if info then
    local ok,_,_,_,_,_,_,_,limit=pcall(info,id)
    if ok and not (issecretvalue and issecretvalue(limit)) and type(limit)=="number" and limit>0 then return limit==1 end
  end
  return AP.catalogSingles and AP.catalogSingles[id]
end

function AP.SplitVendorHistory(ch)
  local purchases=ch.craftLedger and ch.craftLedger.purchases
  for i=#ch.buys,1,-1 do
    local r=ch.buys[i]
    if r.vendor and not r.auctionID and r.purchaseID and r.itemID and (r.quantity or 0)>1
        and r.price and AP.IsVendorSingle(r.itemID) then
      local units,total=r.quantity,r.price
      local imported=purchases and purchases["p:"..r.purchaseID]
      r.quantity,r.price=1,math.floor(total/units)
      for k=2,units do
        local copy={}
        for field,value in pairs(r) do copy[field]=value end
        ch.nextPurchaseID=ch.nextPurchaseID+1
        copy.purchaseID=ch.nextPurchaseID
        copy.price=math.floor(total*k/units)-math.floor(total*(k-1)/units)
        table.insert(ch.buys,i,copy)
        -- Previously allocated costs stay on their original lot.
        if imported then purchases["p:"..copy.purchaseID]=imported end
      end
    end
  end
end

-- The player reported a second missed stack after the first recovered buy.
-- Never attach this second purchase to the auction for the first stack.
function AP.RestoreSecondDye(ch,storeBuy)
  local posts=ch.craftLedger and ch.craftLedger.posts
  local p=posts and posts["181419023"]
  if ch.secondDyeRestored or not p or not p.reportedAllSold or p.at~=1795404006 then return end
  local original
  for _,pool in ipairs({ch.buys,ch.deleted}) do
    for _,r in ipairs(pool) do
      if r.itemID==4340 and r.purchase then
        if pool==ch.buys and r.recoveredGrayDye and r.purchaseID==186 and r.quantity==20
            and r.price==5700 then original=r
        elseif (r.boughtAt or 0)>=p.at then return end
      end
    end
  end
  if not original then return end
  storeBuy({itemID=4340,name="Gray Dye",quantity=20,price=original.price,priceEstimated=true,
    vendor=true,manualVendor=true,source="Second player-reported stack. Cost estimated from prior vendor purchase. Time shown is restoration time."})
  ch.secondDyeRestored=true
end

local restoreWindow
function AP.OpenVendorRestore(parent,storeBuy)
  if not restoreWindow then
    local f=CreateFrame("Frame",nil,parent)
    restoreWindow=f
    f:SetFrameStrata("DIALOG"); f:SetFrameLevel(parent:GetFrameLevel()+30)
    f:SetSize(380,195); f:SetPoint("CENTER"); f:EnableMouse(true)
    local bg=f:CreateTexture(nil,"BACKGROUND"); bg:SetAllPoints(); bg:SetColorTexture(.07,.06,.05,1)
    local function label(message,x,y)
      local t=f:CreateFontString(nil,"OVERLAY","GameFontNormal")
      t:SetPoint("TOPLEFT",x,y); t:SetText(message); return t
    end
    label("Restore a missed vendor purchase",14,-12)
    local close=CreateFrame("Button",nil,f,"UIPanelCloseButton"); close:SetPoint("TOPRIGHT")
    close:SetScript("OnClick",function() f:Hide() end)
    f.fields={}
    for i,title in ipairs({"Item ID or item link","Quantity","Copper per item (optional)"}) do
      label(title,16,-39-(i-1)*27)
      local box=CreateFrame("EditBox",nil,f,"InputBoxTemplate")
      box:SetAutoFocus(false); box:SetSize(142,21); box:SetPoint("TOPRIGHT",-18,-35-(i-1)*27)
      box:SetScript("OnEscapePressed",function() f:Hide() end)
      f.fields[i]=box
    end
    local status=label("",16,-126); status:SetWidth(348); status:SetJustifyH("LEFT")
    local save=CreateFrame("Button",nil,f,"UIPanelButtonTemplate")
    save:SetSize(140,24); save:SetPoint("BOTTOM",0,8)
    for _,box in ipairs(f.fields) do box:SetScript("OnTextChanged",function()
      f.ready=nil; save:SetText("Review purchase"); status:SetText("")
    end) end
    save:SetScript("OnClick",function()
      local raw=f.fields[1]:GetText()
      local id=tonumber(raw:match("^%s*(%d+)%s*$") or raw:match("|Hitem:(%d+)"))
      local q=tonumber(f.fields[2]:GetText():match("^%s*(%d+)%s*$"))
      local cost=f.fields[3]:GetText()
      local unit=tonumber(cost:match("^%s*(%d+)%s*$"))
      if not id or id<=0 or not q or q<1 or q>100000 or
          (cost~="" and (not unit or unit<1 or unit>100000000)) then
        status:SetText("Enter an item, a whole quantity and an optional unit cost in copper.");return
      end
      local lookup=(C_Item and C_Item.GetItemInfo) or GetItemInfo
      local name=lookup and lookup(id) or raw:match("%[(.-)%]") or ("Item #"..id)
      if not f.ready then
        f.ready=true;save:SetText("Confirm purchase")
        status:SetText(q.."x "..name.."  •  "..(unit and AP.Money(q*unit).." total" or "Cost unknown"));return
      end
      f.ready=nil; f:Hide()
      storeBuy({itemID=id,name=name,quantity=q,price=unit and unit*q,vendor=true,manualVendor=true,
        source="Vendor purchase entered by you. Time shown is restoration time."})
    end)
    f.reset=function()
      for _,box in ipairs(f.fields) do box:SetText("") end
      f.ready=nil;save:SetText("Review purchase");status:SetText("")
    end
    parent:HookScript("OnHide",function() f:Hide() end)
  end
  restoreWindow.reset(); restoreWindow:Show(); restoreWindow.fields[1]:SetFocus()
end
