local AP={Money=tostring}
time=os.time
local function load(n) assert(loadfile(n..'.lua'))('AuctionPeek',AP) end
for _,n in ipairs({'MailFlip','Crafts','History','ReceiptReview','Accounting'}) do load(n) end
local norm=function(s) return (s or ''):lower() end
local function make()
  local b={purchase=true,purchaseID=1,itemID=10560,name='Unstable Trigger',quantity=1,price=2300,boughtAt=100}
  local x={index=1,itemID=10560,purchase=1,quantity=1,left=1,cost=2300,balance=2300,at=100}
  local r={sold=true,mailOnly=true,name=b.name,receiptID='mail:1',receiptQuantityKnown=true,receiptQty=1,quantity=1,verifiedGross=2288,verifiedCut=114,verifiedDeposit=200,verifiedNet=2374,observedAt=200,soldAt=201}
  local ch={buys={b},sold={r},active={},ended={},deleted={},craftLedger={lots={x},purchases={['p:1']=1},posts={}}}
  return ch,r,x,b
end
local M=AP.MailFlip
local ch,r,x=make()
assert(M.Reconcile(ch,norm)==1 and x.left==0 and x.balance==0 and r.auctionID==nil and r.itemID==10560)
assert(M.Reconcile(ch,norm)==0 and AP.ReviewReceiptCount(ch,norm)==0)
local sales,flips=AP.BuildHistory(ch,norm); AP.Crafts.Rows(ch,flips,sales)
assert(#sales==1 and #flips==1 and flips[1].soldCost.cost==2300 and flips[1].net==2174 and flips[1].profitText=='-126')
local groups=AP.Crafts.ItemGroups(ch,flips,sales); assert(#groups==1 and groups[1].receiptOnly==1); assert(#AP.Crafts.GroupDetails(ch,groups[1])==2)
assert(M.Undo(ch,r) and x.left==1 and x.balance==2300 and not r.itemID)
assert(M.Reconcile(ch,norm)==0 and AP.ReviewReceiptCount(ch,norm)==1)
assert(M.Commit(ch,r,1,norm,true) and x.left==0)
print('PASS unique receipt, accurate P/L, grouped Flip, counter, idempotence, undo, manual re-link')
for _,change in ipairs({
  function(ch,r,x) x.left=0; x.balance=0 end,
  function(ch,r,x) x.unknown=true end,
  function(ch,r,x) ch.craftLedger.posts['9']={itemID=10560,at=150,parts={{source=1}}} end,
  function(ch,r,x) r.name='Craftsman\'s Writ: Unstable Trigger' end,
  function(ch,r,x) r.verifiedNet=999 end,
  function(ch,r,x) r.receiptQuantityKnown=false end,
  function(ch,r,x) r.observedAt=99 end,
  function(ch,r,x) ch.sold[2]={receiptID=r.receiptID} end,
  function(ch,r,x) ch.sold[2]={name=r.name,receiptID='mail:2',soldAt=180} end,
  function(ch,r,x) ch.craftLedger.lots[2]={itemID=10560,looted=true} end,
  function(ch,r,x) ch.deTests={{at=150,outputs={[10560]=1}}} end,
  function(ch,r,x) ch.craftLedger.lots[2]={itemID=12,parts={{source=1}}} end,
  function(ch,r,x) ch.active[1]={itemID=10560,firstSeenAt=150,auctionID=9} end,
  function(ch,r,x) ch.reviewDismissed={['mail:1']=true} end
}) do
  local c,t,l=make(); change(c,t,l); local left=l.left; assert(M.Reconcile(c,norm)==0 and l.left==left and not t.mailFlip)
end
local c,t,l,b=make(); local b2={}; for k,v in pairs(b) do b2[k]=v end; b2.purchaseID=2; b2.price=2400; c.buys[2]=b2
local l2={}; for k,v in pairs(l) do l2[k]=v end; l2.index=2;l2.purchase=2;l2.cost=2400;l2.balance=2400
c.craftLedger.lots[2]=l2;c.craftLedger.purchases['p:2']=2
assert(#M.Choices(c,t,norm)==2 and M.Reconcile(c,norm)==0)
assert(M.Commit(c,t,2,norm,true) and l2.left==0 and l.left==1)
print('PASS ambiguous evidence, consumed lots, duplicate receipts, name collision, manual choice')
if arg and arg[1] then
  dofile(arg[1]); local c=AuctionPeekDB.characters['Crillz - ']
  local n=M.Reconcile(c,norm); print('Real profile new mail-only recoveries: '..n)
  local target; for _,r in ipairs(c.sold) do if r.receiptID=='mail:272' then target=r end end
  assert(target and target.mailFlip and target.mailFlip.source==1076 and target.mailFlip.purchase==333 and target.mailFlip.cost==2300)
  local s,f=AP.BuildHistory(c,norm); M.Rows(c,f,s,function(net,cost) return tostring(net-cost.cost) end)
  local count=0; for _,r in ipairs(f) do if r.receiptID=='mail:272' then count=count+1; assert(r.net==2174 and r.profitText=='-126' and r.auctionID==nil) end end
  assert(count==1 and M.Reconcile(c,norm)==0)
  print('PASS real Unstable Trigger receipt mail:272; 2300c cost, 2174c proceeds, -126c P/L')
end
