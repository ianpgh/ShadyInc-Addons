local AP={}
time=function() return 1795600000 end
for _,name in ipairs({'VendorCatalog','VendorDiscovery','VendorCosts'}) do assert(loadfile(name..'.lua'))('AuctionPeek',AP) end
local D=AP.VendorDiscovery
local ch={buys={{vendor=true,itemID=20754,name='Formula: Lesser Mana Oil',price=9500,quantity=1,boughtAt=1,purchaseID=1},{vendor=true,itemID=20754,name='Formula: Lesser Mana Oil',price=9000,quantity=1,boughtAt=2,purchaseID=2},{vendor=true,itemID=20754,name='Formula: Lesser Mana Oil',price=10000,quantity=1,boughtAt=3,priceEstimated=true},{vendor=false,itemID=77,price=999,quantity=1,boughtAt=4}}}
local function find(rows,id,source) for _,o in ipairs(rows) do if o.id==id and o.source==source then return o end end end
local base={{id=20754,name='Formula: Lesser Mana Oil',merchant='Known vendor',zone='Zone',price=10000,bundle=1}}
local rows=D.Merge(ch,base,true); local r=assert(find(rows,20754,'purchase')); assert(r.price==9000 and r.purchaseID==2 and r.discovered and not r.location and #rows==2)
assert(#D.Merge(ch,base,false)==1 and not ch.vendorDiscovery)
local offers={{itemID=20754,name='Formula: Lesser Mana Oil',price=9000,stackCount=1,numAvailable=0},{itemID=78,name='Extended item',price=100,stackCount=1,hasExtendedCost=true}}
C_MerchantFrame={GetNumItems=function() return #offers end,GetItemInfo=function(i) return offers[i] end}
UnitName=function(unit) assert(unit=='npc'); return 'Known vendor' end
C_Map={GetBestMapForUnit=function() return 42 end,GetMapInfo=function() return {name='Zone'} end,GetPlayerMapPosition=function() return {x=.25,y=.50} end}
local handler
CreateFrame=function() return {RegisterEvent=function() end,SetScript=function(_,k,fn) assert(k=='OnEvent'); handler=fn end} end
D.Install(ch); assert(D.Scan(ch)==0); handler(nil,'MERCHANT_SHOW'); rows=D.Merge(ch,base,true)
r=assert(find(rows,20754,'merchant')); assert(r.price==9000 and r.discovered and r.location[1]==42 and r.location[2]==25 and #rows==2)
assert(not AP.VendorCosts.OfferUnit(assert(find(rows,78,'merchant'))))
-- Partial refresh/stock change must not erase the previously observed item.
offers={{itemID=78,name='Extended item',price=100,stackCount=1,hasExtendedCost=true}}; handler(nil,'MERCHANT_UPDATE'); assert(find(D.Merge(ch,base,true),20754,'merchant').price==9000)
handler(nil,'MERCHANT_CLOSED'); assert(D.Scan(ch)==0 and #ch.buys==4 and not ch.vendorCostArchive)
print('PASS purchase latest, opt-out, duplicate merge, merchant event, stock retention, map, extended cost, read-only buys, no automatic Saved Costs approval')
if arg[1] then
  dofile(arg[1]); local c=AuctionPeekDB.characters['Crillz - ']; local actual=D.Merge(c,AP.LoadVendorOffers(),true)
  local oil=assert(find(actual,20754,'purchase')); assert(oil.price/oil.bundle==9000 and oil.discovered)
  local count=0; for _,o in ipairs(actual) do if o.source=='purchase' then count=count+1 end end
  print('PASS actual SavedVariables: Lesser Mana Oil 9000c/unit; '..count..' personal purchase rows; no synthetic purchases')
end
