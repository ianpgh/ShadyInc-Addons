local AP={Money=tostring,MailValueReadable=function() return true end}
local function load(name) assert(loadfile("./"..name..".lua"))("AuctionPeek",AP) end
for _,name in ipairs({"Transactions","Reconciliation","Crafts","Inventory","Delivery","CraftedView","History"}) do load(name) end
local C,R,D,I,V=AP.Crafts,AP.Reconciliation,AP.Delivery,AP.Inventory,AP.CraftedView
local now=1795631200
time=function() return now end
date=os.date
local function eq(a,b,n) assert(a==b,(n or "").." expected "..tostring(b).." got "..tostring(a)) end
local function new()
  local ch={active={},ended={},sold={},deleted={},buys={},postingEvidence={}}
  AP.Transactions.Migrate(ch)
  return ch
end
local counts={}
GetItemCount=function(id) return counts[id] or 0 end
local function encode(t)
  if type(t)~="table" then return type(t)..":"..tostring(t) end
  local pairsSorted={}
  for k,v in pairs(t) do pairsSorted[#pairsSorted+1]=encode(k).."="..encode(v) end
  table.sort(pairsSorted)
  return "{"..table.concat(pairsSorted,",").."}"
end
local normalize=function(n) return (n or ""):lower() end
local function flips(ch)
  local sales,rows=AP.BuildHistory(ch,normalize)
  C.Rows(ch,rows,sales)
  C.AddTransactionRows(ch,rows,sales)
  local mapped={}
  for _,r in ipairs(rows) do if r.auctionID then mapped[tostring(r.auctionID)]=r end end
  return mapped
end
if arg[1] then
  dofile(arg[1])
  local ch=assert(AuctionPeekDB.characters["Crillz - "])
  local l=ch.craftLedger
  local old=flips(ch)
  local untouched={}
  for _,k in ipairs({"active","ended","sold","buys","deleted"}) do untouched[k]=encode(ch[k]) end
  local oldPosts,oldLots={},{}
  for i,x in ipairs(l.lots) do oldLots[i]=encode(x) end
  for i,p in pairs(l.posts) do oldPosts[i]=encode(p) end
  assert(R.ConfirmMageweaveBoots(ch))
  local original=l.lots[1244].parts[2]
  assert(original.confirmedLoot and not original.unknown and not original.source)
  eq(original.reconciliation.priorReason,"INSUFFICIENT_TRACKED")
  eq(l.lots[1249].cost,9119)
  assert(not l.lots[1249].unknown)
  for k,v in pairs(untouched) do eq(encode(ch[k]),v,k) end
  for i,v in ipairs(oldLots) do
    if i~=1244 and i~=1249 then eq(encode(l.lots[i]),v,"unrelated lot "..i) end
  end
  for i,v in pairs(oldPosts) do
    if i~="215398138" then eq(encode(l.posts[i]),v,"unrelated posting "..i) end
  end
  eq(#l.lots,#oldLots)
  local after=encode(l)
  assert(not R.ConfirmMageweaveBoots(ch))
  eq(encode(l),after,"repeat")
  local changed=flips(ch)
  for id,row in pairs(old) do
    if id~="215398138" and row.soldCost then eq(encode(changed[id].soldCost),encode(row.soldCost),id) end
  end
  local row=assert(changed["215398138"])
  assert(not row.soldCost.unknown and not row.net)
  eq(row.soldCost.cost,9119)
  R.RecoverRecipeSales(ch)
  local recovered=flips(ch)
  for _,id in ipairs({"214922938","214924314"}) do
    eq(recovered[id].profitText,"Receipt missing")
    assert(recovered[id].soldCost.unknown and not recovered[id].net)
    if id=="214924314" then assert(#C.PurchaseSources(ch,id)>0) end
  end
  for _,id in ipairs({"209525828","182906752","173161362","210317410","209816192"}) do
    eq(recovered[id].profitText,old[id].profitText)
  end
  for k,v in pairs(untouched) do eq(encode(ch[k]),v,k) end
  local sold
  for _,r in ipairs(ch.sold) do if r.auctionID==215398138 then sold=r end end
  sold.receiptID="test:verified"
  sold.verifiedGross,sold.verifiedCut,sold.verifiedDeposit,sold.verifiedNet=13900,695,100,13305
  row=flips(ch)["215398138"]
  eq(row.net,13205,"verified after-cut proceeds")
  eq(row.profitText,"+4086")
  print("PASS exact boots migration, unchanged unrelated data, no invented receipt, and two missing recipe receipts")
end

LOOT_ITEM_SELF_MULTIPLE="You loot %1$s x%2$d."
LOOT_ITEM_SELF="You loot %s."
LOOT_ITEM_PUSHED_SELF_MULTIPLE="You receive item: %s x%d."
local cloth,bolt,leather,thread,boots=4338,4339,4304,8343,10026
local link="|Hitem:4338::::::::|h[Mageweave Cloth]|h"
local mats={
  [1]={outputItemID=bolt,quantityMin=1,quantityMax=1,reagentSlotSchematics={{quantityRequired=5,reagents={{itemID=cloth}}}}},
  [2]={outputItemID=boots,quantityMin=1,quantityMax=1,reagentSlotSchematics={
    {quantityRequired=3,reagents={{itemID=bolt}}},{quantityRequired=2,reagents={{itemID=leather}}},
    {quantityRequired=2,reagents={{itemID=thread}}}}}
}
C_TradeSkillUI={GetRecipeSchematic=function(s) return mats[s] end}
local function cast(ch,guid,s)
  C.Cast(ch,"UNIT_SPELLCAST_START","player",guid,s)
  C.Cast(ch,"UNIT_SPELLCAST_START","player",guid,s)
  local x=assert(C.Cast(ch,"UNIT_SPELLCAST_SUCCEEDED","player",guid,s))
  assert(not C.Cast(ch,"UNIT_SPELLCAST_SUCCEEDED","player",guid,s))
  now=now+8
  return x
end
local function buy(ch,id,n,cost,vendor)
  local row={purchaseID=#ch.buys+1,itemID=id,quantity=n,price=cost,boughtAt=now,vendor=vendor}
  table.insert(ch.buys,1,row)
  return row
end
local function mixed(lootLogged)
  local ch=new()
  I.Start(ch)
  C.PersonalLoot(ch,"You loot "..link.." x4.")
  local extra=(lootLogged and "You loot " or "You receive item: ")..link.." x2."
  eq(C.PersonalLoot(ch,extra),lootLogged and cloth or nil,"personal/pushed provenance")
  if lootLogged then eq(#ch.craftLedger.lots,2) end
  now=now+1
  buy(ch,cloth,4,1744)
  counts={[cloth]=10}
  local a=cast(ch,"bolt-a",1)
  local b=cast(ch,"bolt-b",1)
  eq(a.cost+b.cost,1744)
  eq(not not b.unknown,not lootLogged)
  if not lootLogged then
    local diag=ch.craftLedger.craftDiagnostics[1].inputs[1]
    eq(diag.bag,5,"effective second pre-craft quantity")
    eq(diag.missing,2)
    eq(b.parts[2].reason,"INSUFFICIENT_TRACKED")
  end
  eq(R.CraftCount(ch,cloth,0),0)
  counts[cloth]=0
  -- One visible purchased bolt and two still-pending crafted outputs.
  counts[bolt]=1
  -- Observe the crafted outputs before introducing a same-item purchase.
  eq(R.CraftCount(ch,bolt,2),2)
  counts[bolt],counts[leather],counts[thread]=3,2,2
  buy(ch,bolt,1,2299)
  buy(ch,leather,2,1836)
  buy(ch,thread,2,3240,true)
  local finished=cast(ch,"boots",2)
  eq(finished.cost,9119)
  eq(not not finished.unknown,not lootLogged)
  local before=encode(ch)
  local crafted=V.Rows(ch,false)
  eq(#crafted,lootLogged and 2 or 3)
  for _,r in ipairs(crafted) do
    if r.index==finished.index then
      local text=V.Details(ch,r)
      assert(text:find("Purchase #",1,true))
      assert(text:find("Source batch",1,true))
    end
  end
  V.Rows(ch,true)
  eq(encode(ch),before,"Crafted projection is read-only")
end
mixed(false)
mixed(true)
print("PASS consecutive casts, delayed bag counts, generic loot exclusion, FIFO, cost conservation and confidence across crafts")

local callbacks={}
C_Timer={After=function(delay,fn) if delay<1 then callbacks[#callbacks+1]=fn end end}
local function flush()
  local due=callbacks
  callbacks={}
  for _,f in ipairs(due) do f() end
end
local inbox={}
GetInboxNumItems=function() return #inbox end
GetInboxHeaderInfo=function(i)
  local r=inbox[i]
  if r then return nil,nil,"Auction House","Auction won: Cut cloth",0,0,1,1 end
end
GetInboxItem=function(i)
  local r=inbox[i]
  if r then return "Cut cloth",r.id,nil,r.n end
end
GetInboxInvoiceInfo=function(i)
  local r=inbox[i]
  if r then return "buyer","Cut cloth","Seller",r.price,r.price end
end
local function mail()
  local ch=new()
  local row=buy(ch,cloth,4,1744)
  row.notifiedAH=true
  D.Record(row)
  counts={}
  I.Start(ch)
  inbox={{id=cloth,n=4,price=1744}}
  D.Open(ch)
  return ch,row
end
TakeInboxItem=function() end
AutoLootMailItem=function() end
hooksecurefunc=function(k,f)
  local original=_G[k]
  _G[k]=function(...) original(...);f(...) end
end
D.Install()
local ch,b=mail()
eq(b.delivery.stage,"available")
AutoLootMailItem(1)
AutoLootMailItem(1)
eq(b.delivery.stage,"requested")
D.Fail("Item not found")
eq(b.delivery.stage,"awaiting")
eq(#ch.buys,1)
D.Close()
ch,b=mail()
AutoLootMailItem(1)
inbox={}
D.Scan(ch)
flush()
eq(b.delivery.stage,"requested","mail disappearance alone")
counts[cloth]=4
D.Queue(ch)
flush()
eq(b.delivery.stage,"verified")
eq(#ch.buys,1)
D.Queue(ch)
flush()
eq(b.delivery.stage,"verified")
D.Close()
ch,b=mail()
local other=buy(ch,cloth,4,1744)
other.notifiedAH=true
D.Record(other)
D.Scan(ch)
TakeInboxItem(1,1)
assert(b.delivery.stage~="requested" and other.delivery.stage~="requested")
D.Close()
ch,b=mail()
AutoLootMailItem(1)
inbox={}
counts[cloth]=4
D.CompetingIncrease(ch,cloth)
D.Queue(ch)
flush()
eq(b.delivery.stage,"awaiting","competing acquisition")
D.Close()
ch,b=mail()
AutoLootMailItem(1)
D.Reset(ch)
eq(b.delivery.stage,"awaiting","reload")
assert(b.delivery.issue)
D.Close()

local a={signature="a",net=13305}
local b2={signature="b",net=200}
local claims, credited={},{}
local function credit(r) credited[#credited+1]=r end
assert(not AP.ReconcileWalletDrop(ch,{a,b2},{a=1,b=1},{},claims,13305,credit))
eq(#credited,0)
assert(AP.ReconcileWalletDrop(ch,{a,b2},{a=1,b=1},{},claims,13505,credit))
eq(#credited,2)
assert(not AP.ReconcileWalletDrop(ch,{a,b2},{a=1,b=1},{},claims,13505,credit))
eq(#credited,2)
print("PASS mailbox success/failure, duplicate requests, delayed bags, identical candidates, competing source, reload and bulk seller credit")

local bags={{itemID=cloth,stackCount=4}}
C_Container={
  GetContainerNumSlots=function(b) return b==0 and #bags or 0 end,
  GetContainerItemInfo=function(_,slot) return bags[slot] end
}
ch=new()
I.Start(ch)
bags={{itemID=cloth,stackCount=2},{itemID=cloth,stackCount=2}}
I.Scan(ch)
assert(not ch.inventoryReconciliation)
I.Signal(ch,cloth,2,"PERSONAL_LOOT")
bags={{itemID=cloth,stackCount=6}}
I.Scan(ch)
eq(ch.inventoryReconciliation.observations[1].reason,"EVENTS_AGREE")
I.Bank(ch,true)
bags={{itemID=cloth,stackCount=3}}
I.Scan(ch)
local observation=ch.inventoryReconciliation.observations[2]
eq(observation.delta,-3)
assert(observation.bankOpen)
eq(observation.reason,"UNRESOLVED_BAG_CHANGE")
assert(not ch.craftLedger)
I.Bank(ch,false)
print("PASS bag stack splitting, bank context and unresolved changes do not create or consume lots")
