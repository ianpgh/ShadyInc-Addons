> v2.8.2 follow-up: The player approved using the average of purchases #265 and #268. The 206c stack benchmark assigns 155c to the three unpriced Wildvine after whole-copper rounding. Sale #197336860 has 13,230c estimated basis and 2,536c estimated profit after AH fees. The 15,766c proceeds are verified. The estimate is stored with its source references on the craft and creates no purchase or inventory lot.

> v2.8.1 follow-up: The player confirmed that the cloth without a purchase allocation was looted. Both saves showed all recorded earlier cloth purchases allocated before the five-bolt run. The correction marks those exact 25 units as player-confirmed loot, preserving 0c acquisition cost and the original crafts and payments. Three Wildvine remain unpriced. The sections below document the original v2.8.0 investigation.

# Auction Peek v2.8.0 accounting audit

## Findings

Both November 25 SavedVariables snapshots agree on the 14 paid Dreamweave Gloves listings, their crafted source lots and their seller invoices. The detailed listing below follows recorded ingredient allocations through intermediates to purchases, confirmed loot, or unsupported leaves.

No explicit manual purchase or payment link in either snapshot involves Dreamweave Gloves, Wildvine, Mageweave Cloth or Bolts of Mageweave. The 13 manual purchase links concern other items. The cost transfers from 193118601 to 197308295 and 193171512 to 197336860 each move a whole glove's existing basis. The saved links do not identify whether the move was automatic or manually confirmed. There is also a possible repost from 181827411 to 183884198, but the successor explicitly carries a different craft lot. Neither snapshot establishes which physical pair the player reposted.

| Sale | Known basis in copper | Proceeds after AH fee in copper | Remaining basis gap |
|---|---:|---:|---|
| 197336860 | 13075 | 15766 | 3 Wildvine with no allocation |
| 183884198 | 10393 | 14345 | 5 Mageweave Cloth through one bolt |
| 182158220 | 4168 | 15010 | 20 Mageweave Cloth through four bolts |

The three gaps already exist in the ingredient lineage. Lot 861 has one Wildvine allocated at 51c from purchase 268, with three unallocated. Lots 709–713 are five successive bolts whose five-cloth inputs have no source; the preceding run shows both purchased and confirmed looted cloth. This establishes that the eligible ledger ran short when those inputs were allocated. It does not establish whether the physical materials were acquired before tracking, arrived through an acquisition path without cost evidence, or were excluded by the historical allocator. The snapshots lack contemporaneous bag/eligible lot counts for these casts.

Two defects were confirmed in the previous source. The same bag limit could be applied repeatedly when a recipe presented the same reagent in multiple slots, potentially leaving usable allocations behind, and the return observer ignored pickup requests when the inbox contained multiple identical return attachments. Neither defect can be tied conclusively to these specific historical ingredient gaps. A repost with an uncollected remainder could also acquire a historical reservation via an inferred link. This path is disabled for new postings entered under v2.8.0.

No new historical cost amount was substantiated. The release does not rewrite the fixture or supply replacement SavedVariables. Existing allocations and verified invoices are retained.

## Accounting changes

- Apply the pre-cast count once per distinct ingredient. Eligible lots use FIFO by acquisition time and lot index. When the recorded available stock exceeds a verified bag count, restrict the eligible inventory to the most recent lots that fit, then allocate FIFO within that scope. Excluded lots remain available if later evidence supports them.
- Preserve whole-copper balances, actual purchase costs, verified zero-cost loot and unknown input provenance through intermediate crafts. Record an explicit unknown input when supported lot quantities run short.
- Observe pickup requests for identical returned attachments. Confirm by an observed decrease in matching attachments. Multiple eligible and independently ended identical listings can release their cost in end-time order. The selected ownership is an inference and flows into repost cost as estimated. An active or unverified competitor keeps ambiguous ownership unresolved. Process the confirmed sold prefix and returned tail independently. Historical one-off recovery functions remain in place.
- The 80 latest craft exceptions and 40 latest unmatched returns retain diagnostics. Use `/ap costtrace 10019` for gloves or the corresponding reagent item ID. Expanded material details and the Auction ID Inspector show individual cost gaps.
- New manual purchase links preserve their previous allocation. `/ap undocost <auction ID>` checks the lot, post and remaining ownership before undoing. Legacy links lack a saved before-state. Manual craft-source reassignment additionally rejects a lot claimed by another listing or consumed by another craft.
- Collected proceeds and returned deposits remain distinct. Forfeited deposits cannot be reconstructed where the client did not supply the original charge. Mail/trade gifts and pre-tracking stock without acquisition cost evidence stay unknown.
- Bulk casts with a confirmed fixed recipe and output quantity use the same policy. Recipes with variable outputs or ambiguous reagent choices still need reliable client-side evidence. Disenchanting retains its separate evidence and projection path.

## Verification and live checks

The offline suite checks bought, looted, mixed and unpriced ingredients, multi-stage output, exact quantity and copper totals, duplicate reagent slots, duplicate payments, partial sales and returns, multiple same-price listings, identical attachments, repeated cancel/repost cycles, safe manual undo after reloading, consumed inputs, and the vendor resale projection. Both supplied saves load through the simulated addon and preserve the 14 paid glove sales, disenchant records, and repaired Yellowtail payment. UI rendering and actual API timing require a live test.

1. Buy and loot Mageweave and Wildvine, then make bolts and several gloves. Inspect the results with `/ap costtrace 10019` and the expanded material details.
2. Post at least two pairs with different costs. Cancel in reverse order, collect two matching return mails, repost, then sell. Check that total basis is preserved and the inspector marks inferred return allocation.
3. Partially sell a commodity stack, cancel and collect the rest. Collect payment before and after an owned-auction update. Check All Time, 24h and Flip for duplicate units, cash or material costs.
4. Repeat the collection flow using native Open All and Auction Peek's paced pickup. Reload between posting, payment and return events. Confirm that missing pickup evidence is reported and existing revenue stays intact.
5. Test a manual sale-cost attachment and undo on a disposable eligible one-item purchase. Verify vendor/Auction Companion integration and DE tracking with an ordinary purchase, sale and disenchant.

## Recorded glove sales and material lineage

Amounts are integer copper. A purchase number identifies the recorded source. "Loot" is verified acquisition at zero cost. An unallocated leaf has unknown cost even when its stored placeholder copper is zero.

### Auction 165410184 · mail:65

Gross 17512c, AH fee 875c, returned deposit 788c, collected 17425c.

- Craft lot 353 · recorded basis 13086c
  - 4 × Bolt of Mageweave · purchase #94 · 8496c
  - 4 × Wildvine · purchase #91 · 232c
  - 2 × Heart of the Wild · purchase #92 · 818c
  - 2 × Heavy Silken Thread · purchase #93 · 3540c

### Auction 167411334 · mail:67

Gross 17512c, AH fee 875c, returned deposit 788c, collected 17425c.

- Craft lot 410 · recorded basis 12924c
  - 2 × Bolt of Mageweave · purchase #94 · 4248c
  - 1 × Bolt of Mageweave · craft lot 354 · 2046c
    - 5 × Mageweave Cloth · purchase #8 · 2046c
  - 1 × Bolt of Mageweave · craft lot 355 · 2046c
    - 5 × Mageweave Cloth · purchase #8 · 2046c
  - 2 × Wildvine · purchase #91 · 116c
  - 2 × Wildvine · purchase #95 · 110c
  - 2 × Heart of the Wild · purchase #96 · 818c
  - 2 × Heavy Silken Thread · purchase #97 · 3540c

### Auction 167421530 · mail:68

Gross 17512c, AH fee 875c, returned deposit 788c, collected 17425c.

- Craft lot 411 · recorded basis 12926c
  - 4 × Bolt of Mageweave · purchase #101 · 8320c
  - 4 × Wildvine · purchase #98 · 220c
  - 2 × Heart of the Wild · purchase #99 · 818c
  - 2 × Heavy Silken Thread · purchase #14 · 3568c

### Auction 167443830 · mail:69

Gross 17512c, AH fee 875c, returned deposit 788c, collected 17425c.

- Craft lot 412 · recorded basis 12851c
  - 4 × Bolt of Mageweave · purchase #101 · 8320c
  - 4 × Wildvine · purchase #98 · 220c
  - 2 × Heart of the Wild · purchase #99 · 818c
  - 2 × Heavy Silken Thread · purchase #100 · 3493c

### Auction 181843959 · mail:134

Gross 19899c, AH fee 994c, returned deposit 788c, collected 19693c.

- Craft lot 720 · recorded basis 12334c
  - 1 × Bolt of Mageweave · craft lot 692 · 2046c
    - 5 × Mageweave Cloth · purchase #8 · 2046c
  - 1 × Bolt of Mageweave · craft lot 693 · 2046c
    - 5 × Mageweave Cloth · purchase #8 · 2046c
  - 1 × Bolt of Mageweave · craft lot 694 · 2046c
    - 5 × Mageweave Cloth · purchase #8 · 2046c
  - 1 × Bolt of Mageweave · craft lot 695 · 2028c
    - 3 × Mageweave Cloth · purchase #8 · 1228c
    - 2 × Mageweave Cloth · purchase #114 · 800c
  - 4 × Wildvine · purchase #181 · 128c
  - 2 × Heart of the Wild · purchase #182 · 800c
  - 2 × Heavy Silken Thread · purchase #184 · 3240c

### Auction 182058469 · mail:136

Gross 16099c, AH fee 804c, returned deposit 788c, collected 16083c.

- Craft lot 721 · recorded basis 5928c
  - 1 × Bolt of Mageweave · craft lot 696 · 1200c
    - 3 × Mageweave Cloth · purchase #114 · 1200c
    - 1 × Mageweave Cloth · loot · 0c
    - 1 × Mageweave Cloth · loot · 0c
  - 1 × Bolt of Mageweave · craft lot 697 · 0c
    - 1 × Mageweave Cloth · loot · 0c
    - 1 × Mageweave Cloth · loot · 0c
    - 2 × Mageweave Cloth · loot · 0c
    - 1 × Mageweave Cloth · loot · 0c
  - 1 × Bolt of Mageweave · craft lot 698 · 0c
    - 3 × Mageweave Cloth · loot · 0c
    - 2 × Mageweave Cloth · loot · 0c
  - 1 × Bolt of Mageweave · craft lot 699 · 0c
    - 2 × Mageweave Cloth · loot · 0c
    - 2 × Mageweave Cloth · loot · 0c
    - 1 × Mageweave Cloth · loot · 0c
  - 4 × Wildvine · purchase #181 · 128c
  - 2 × Heart of the Wild · purchase #182 · 800c
  - 2 × Heavy Silken Thread · purchase #148 · 3800c

### Auction 182083306 · mail:148

Gross 16099c, AH fee 804c, returned deposit 788c, collected 16083c.

- Craft lot 722 · recorded basis 6183c
  - 1 × Bolt of Mageweave · craft lot 700 · 0c
    - 1 × Mageweave Cloth · loot · 0c
    - 2 × Mageweave Cloth · loot · 0c
    - 2 × Mageweave Cloth · loot · 0c
  - 1 × Bolt of Mageweave · craft lot 701 · 0c
    - 3 × Mageweave Cloth · loot · 0c
    - 2 × Mageweave Cloth · loot · 0c
  - 1 × Bolt of Mageweave · craft lot 702 · 0c
    - 1 × Mageweave Cloth · loot · 0c
    - 3 × Mageweave Cloth · loot · 0c
    - 1 × Mageweave Cloth · loot · 0c
  - 1 × Bolt of Mageweave · craft lot 704 · 2047c
    - 5 × Mageweave Cloth · purchase #8 · 2047c
  - 1 × Wildvine · loot · 0c
  - 3 × Wildvine · purchase #181 · 96c
  - 2 × Heart of the Wild · purchase #182 · 800c
  - 2 × Heavy Silken Thread · purchase #184 · 3240c

### Auction 182140564 · mail:139

Gross 15799c, AH fee 789c, returned deposit 788c, collected 15798c.

- Craft lot 723 · recorded basis 8672c
  - 1 × Bolt of Mageweave · craft lot 705 · 2047c
    - 5 × Mageweave Cloth · purchase #8 · 2047c
  - 1 × Bolt of Mageweave · craft lot 706 · 2047c
    - 5 × Mageweave Cloth · purchase #8 · 2047c
  - 1 × Bolt of Mageweave · craft lot 707 · 410c
    - 1 × Mageweave Cloth · purchase #8 · 410c
    - 3 × Mageweave Cloth · loot · 0c
    - 1 × Mageweave Cloth · loot · 0c
  - 1 × Bolt of Mageweave · craft lot 708 · 0c
    - 3 × Mageweave Cloth · loot · 0c
    - 1 × Mageweave Cloth · loot · 0c
    - 1 × Mageweave Cloth · loot · 0c
  - 4 × Wildvine · purchase #181 · 128c
  - 2 × Heart of the Wild · purchase #182 · 800c
  - 2 × Heavy Silken Thread · purchase #184 · 3240c

### Auction 182158220 · mail:140

Gross 15799c, AH fee 789c, returned deposit 788c, collected 15798c.

- Craft lot 724 · recorded basis 4168c
  - 1 × Bolt of Mageweave · craft lot 709 · 0c
    - 5 × Mageweave Cloth · unallocated
  - 1 × Bolt of Mageweave · craft lot 710 · 0c
    - 5 × Mageweave Cloth · unallocated
  - 1 × Bolt of Mageweave · craft lot 711 · 0c
    - 5 × Mageweave Cloth · unallocated
  - 1 × Bolt of Mageweave · craft lot 712 · 0c
    - 5 × Mageweave Cloth · unallocated
  - 4 × Wildvine · purchase #181 · 128c
  - 2 × Heart of the Wild · purchase #182 · 800c
  - 2 × Heavy Silken Thread · purchase #184 · 3240c

### Auction 183884198 · mail:161

Gross 15099c, AH fee 754c, returned deposit 788c, collected 15133c. Repost reference #181827411.

- Craft lot 725 · recorded basis 10393c
  - 1 × Bolt of Mageweave · craft lot 713 · 0c
    - 5 × Mageweave Cloth · unallocated
  - 3 × Bolt of Mageweave · purchase #180 · 6225c
  - 4 × Wildvine · purchase #181 · 128c
  - 2 × Heart of the Wild · purchase #182 · 800c
  - 2 × Heavy Silken Thread · purchase #184 · 3240c

### Auction 193143705 · mail:186

Gross 19998c, AH fee 999c, returned deposit 788c, collected 19787c.

- Craft lot 860 · recorded basis 12869c
  - 4 × Bolt of Mageweave · purchase #267 · 8624c
  - 1 × Wildvine · purchase #265 · 52c
  - 3 × Wildvine · purchase #268 · 153c
  - 2 × Heart of the Wild · purchase #269 · 800c
  - 2 × Heavy Silken Thread · purchase #184 · 3240c

### Auction 196232941 · mail:200

Gross 16598c, AH fee 829c, returned deposit 788c, collected 16557c.

- Craft lot 1003 · recorded basis 12542c
  - 4 × Bolt of Mageweave · purchase #278 · 7986c
  - 4 × Wildvine · purchase #282 · 112c
  - 2 × Heart of the Wild · purchase #279 · 798c
  - 2 × Heavy Silken Thread · purchase #280 · 3646c

### Auction 197308295 · mail:209

Gross 16595c, AH fee 829c, returned deposit 788c, collected 16554c. Repost reference #193118601.

- Craft lot 859 · recorded basis 13216c
  - 4 × Bolt of Mageweave · purchase #264 · 8628c
  - 1 × Wildvine · purchase #181 · 32c
  - 3 × Wildvine · purchase #265 · 156c
  - 2 × Heart of the Wild · purchase #266 · 800c
  - 1 × Heavy Silken Thread · purchase #215 · 1800c
  - 1 × Heavy Silken Thread · purchase #216 · 1800c

### Auction 197336860 · mail:210

Gross 16595c, AH fee 829c, returned deposit 788c, collected 16554c. Repost reference #193171512.

- Craft lot 861 · recorded basis 13075c
  - 4 × Bolt of Mageweave · purchase #270 · 8624c
  - 1 × Wildvine · purchase #268 · 51c
  - 3 × Wildvine · unallocated
  - 2 × Heart of the Wild · purchase #271 · 800c
  - 1 × Heavy Silken Thread · purchase #216 · 1800c
  - 1 × Heavy Silken Thread · purchase #217 · 1800c
