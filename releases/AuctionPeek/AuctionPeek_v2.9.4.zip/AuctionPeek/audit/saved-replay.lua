time=os.time
date=os.date
GetTime=os.clock
SlashCmdList={}
tinsert=table.insert
UnitName=function() return "Crillz" end
GetRealmName=function() return "" end
UnitGUID=function() return "Player-6934-0084E67D" end
GetItemInfo=function(id) return id==6887 and "Spotted Yellowtail" or id==8999 and "Simulated Commodity" or "Item #"..tostring(id) end
local queue={}
C_Timer={After=function(_,f) queue[#queue+1]=f end}
local frames={}
local methods={}
local mt={__index=function(_,k) return methods[k] or function() end end}
function methods:SetScript(event,f) rawset(self,event,f) end
function methods:RegisterEvent(event) if event=="PLAYER_LOGIN" then rawset(self,"loadsAddon",true) end end
function methods:CreateTexture() return setmetatable({},mt) end
function methods:CreateFontString() return setmetatable({},mt) end
function methods:SetSize(w,h) self.width,self.height=w,h end
function methods:GetWidth() return rawget(self,"width") or 1000 end
function methods:GetHeight() return rawget(self,"height") or 600 end
function methods:GetFrameLevel() return 1 end
function methods:GetFont() return "",12,"" end
function methods:IsShown() return false end
function methods:SetNormalTexture() end
function methods:GetNormalTexture() return setmetatable({},mt) end
function methods:GetName() return rawget(self,"name") end
function methods:SetText(text) self.Text=text end
function methods:GetText() return self.Text end
function CreateFrame(_,name)
  local f=setmetatable({name=name},mt)
  frames[#frames+1]=f
  if name then _G[name]=f end
  return f
end
UIParent=CreateFrame()
WorldFrame=CreateFrame()
Minimap=CreateFrame()
UISpecialFrames={}
GameTooltip=CreateFrame()
local inbox,owned={},{}
C_AuctionHouse={GetOwnedAuctions=function() return owned end,
  HasFullOwnedAuctionResults=function() return true end,
  CancelAuction=function() end}
GetInboxNumItems=function() return #inbox end
GetInboxHeaderInfo=function(index)
  local r=inbox[index]
  if r then return nil,nil,"Auction House",r.subject or "Auction successful",r.money or 0,0,29,r.item and 1 or nil end
end
GetInboxInvoiceInfo=function(index)
  local r=inbox[index]
  if r and not r.item then return "seller",r.name,r.buyer,r.gross,r.gross,r.deposit,r.cut,nil,nil,nil,r.qty end
end
GetInboxItem=function(index)
  local r=inbox[index]
  if r and r.item then return r.name,r.item,nil,r.qty end
end
TakeInboxMoney=function() end
TakeInboxItem=function() end
hooksecurefunc=function(target,method,handler)
  if type(target)=="string" then handler,method,target=method,target,_G end
  local old=target[method]
  target[method]=function(...) if old then old(...) end; handler(...) end
end
local AP={}
local dir="./"
for line in io.lines(dir.."AuctionPeek.toc") do
  if line:match("%.lua$") then assert(loadfile(dir..line))("AuctionPeek",AP) end
end
local main
for _,frame in ipairs(frames) do
  if rawget(frame,"loadsAddon") and rawget(frame,"OnEvent") then main=frame end
end
assert(main)
dofile(arg[1])
local originalDE
for _,profile in pairs(AuctionPeekDB.characters) do
  if profile.craftLedger and profile.craftLedger.posts["210413075"] then originalDE=#(profile.deTests or {}) end
end
main:OnEvent("PLAYER_LOGIN","AuctionPeek")
local ch=assert(AP.Character())
assert(#(ch.deTests or {})==originalDE)
assert(type(AP.DETest.Tracked(ch))=="table")
local function flush()
  for _=1,20 do
    local old=queue; queue={}
    for _,callback in ipairs(old) do callback() end
    if #queue==0 then break end
  end
end
flush()
local p=ch.craftLedger.posts["210413075"]
if arg[2]=="current" then assert(p.filled==2); assert(p.fills["mail:251"].net==1519)
else assert(p.filled==2 and p.fills["mail:251"].net==1519) end
print("PASS complete TOC load and real profile PLAYER_LOGIN",arg[2])

if arg[2]=="current" then
  local id=900000001
  local itemKey={itemID=8999,itemLevel=1,itemSuffix=0}
  owned={{auctionID=id,itemKey=itemKey,quantity=20,unitPrice=700,buyoutAmount=700,status=0}}
  main:OnEvent("AUCTION_HOUSE_SHOW")
  main:OnEvent("AUCTION_HOUSE_AUCTION_CREATED",id)
  main:OnEvent("OWNED_AUCTIONS_UPDATED")
  main:OnEvent("AUCTION_HOUSE_CLOSED")
  local post=assert(ch.craftLedger.posts[tostring(id)])
  assert(post.quantity==20)
  inbox={{name="Simulated Commodity",buyer="A buyer",gross=1400,deposit=2,cut=70,money=1332,qty=2}}
  main:OnEvent("MAIL_SHOW")
  TakeInboxMoney(1)
  inbox={}
  main:OnEvent("MAIL_INBOX_UPDATE")
  main:OnEvent("MAIL_SUCCESS")
  flush()
  assert(not post.filled)
  local seq=ch.nextReceiptID
  main:OnEvent("MAIL_INBOX_UPDATE")
  flush()
  assert(ch.nextReceiptID==seq)
  main:OnEvent("MAIL_CLOSED")
  main:OnEvent("AUCTION_HOUSE_SHOW")
  owned[1].quantity=18
  main:OnEvent("OWNED_AUCTIONS_UPDATED")
  flush()
  assert(post.filled==2)
  main:OnEvent("AUCTION_CANCELED",id)
  main:OnEvent("AUCTION_HOUSE_CLOSED")
  inbox={{name="Simulated Commodity",subject="Auction cancelled: Simulated Commodity",item=8999,qty=18}}
  main:OnEvent("MAIL_SHOW")
  TakeInboxItem(1,1)
  inbox={}
  main:OnEvent("MAIL_INBOX_UPDATE")
  main:OnEvent("MAIL_SUCCESS")
  flush()
  assert(post.returnedUnits==18)
  print("PASS simulated mailbox hooks, repeated events, AH refresh, cancellation and attachment pickup")
end
local normalize=function(n) return (n or ""):lower() end
local sales,flips=AP.BuildHistory(ch,normalize)
AP.Crafts.Rows(ch,flips,sales)
local total,paid,unknown=0,0,0
local before=#ch.buys
AP.Crafts.EstimateNovemberWildvine(ch)
assert(#ch.buys==before and ch.craftLedger.lots[861].cost==13230)
local expectations={["197336860"]={13075,15766,"3× Item #8153"},["183884198"]={10393,14345,"5× Item #4338"},
  ["182158220"]={4168,15010,"20× Item #4338"}}
for _,r in ipairs(flips) do
  if r.itemID==10019 then
    total=total+1
    if r.receiptID then paid=paid+1 end
    if tostring(r.auctionID)=="197336860" then
      assert(r.soldCost.estimate and r.soldCost.cost==13230 and r.profitText=="~+25s 36c")
      assert(AP.InspectorText(ch,r,tostring):find("purchases #265 and #268",1,true))
    end
    if tostring(r.auctionID)=="182158220" then assert(r.profitText=="+1g 8s 42c") end
    if tostring(r.auctionID)=="183884198" then assert(r.profitText=="+39s 52c") end
    if r.soldCost.unknown then
      unknown=unknown+1
      local expected=assert(expectations[tostring(r.auctionID)])
      assert(r.soldCost.cost==expected[1] and r.net==expected[2] and r.profitText=="Cost unknown")
      local text=AP.InspectorText(ch,r,tostring)
      assert(text:find(expected[3],1,true),text)
      assert(text:find("Profit unresolved",1,true))
    end
  end
end
assert(total==14 and paid==14 and unknown==0)
print("PASS Dreamweave Gloves: 14 paid crafts, Wildvine estimate, exact recorded proceeds")

if arg[2]=="current" then
  local l=ch.craftLedger
  assert(l.mageweaveBootsConfirmationV1 and l.lots[1249].cost==9119 and not l.lots[1249].unknown)
  assert(l.posts["214922938"].playerReportedPayment and l.posts["214924314"].playerReportedPayment)
  local wallet=100000
  GetMoney=function() return wallet end
  main:OnEvent("MAIL_CLOSED")
  inbox={
    {name="Test Recipe One",buyer="Buyer One",gross=10000,deposit=100,cut=500,money=9600,qty=1},
    {name="Test Recipe Two",buyer="Buyer Two",gross=20000,deposit=100,cut=1000,money=19100,qty=1}
  }
  main:OnEvent("MAIL_SHOW")
  local seq=ch.nextReceiptID
  wallet=wallet+28700
  inbox={}
  main:OnEvent("MAIL_INBOX_UPDATE")
  assert(ch.nextReceiptID==seq+2)
  TakeInboxMoney(1)
  main:OnEvent("MAIL_INBOX_UPDATE")
  flush()
  assert(ch.nextReceiptID==seq+2)
  print("PASS integrated historical corrections and unhooked bulk seller payment verification")
end
