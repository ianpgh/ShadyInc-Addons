local _,AP=...
local offers
local window,search,status,previous,nextButton,scanButton
local cells,matches={},{}
local page,size=1,12

local mapMarker,mapTarget

local function updateMarker(self)
  local canvas=self:GetParent()
  local show=mapTarget and WorldMapFrame:GetMapID()==mapTarget[1]
  self.symbol:SetShown(show)
  self.caption:SetShown(show)
  if show then
    local x=mapTarget[2]*canvas:GetWidth()/100
    local y=-mapTarget[3]*canvas:GetHeight()/100
    if x~=self.x or y~=self.y then
      self:ClearAllPoints()
      self:SetPoint("CENTER",canvas,"TOPLEFT",x,y)
      self.x,self.y=x,y
    end
  end
end

local function dropWaypoint(loc,name)
  local id,x,y=loc[1],loc[2]/100,loc[3]/100
  -- OpenMap draws the tracked waypoint on its stitched map, even on clients
  -- where Blizzard does not support a user waypoint in this zone.
  if type(OpenMap)=="table" and OpenMap.GetModule then
    local ok,mod=pcall(OpenMap.GetModule,OpenMap,"worldmap")
    if ok and mod and mod.TrackPoint and mod.char then
      local placed=pcall(mod.TrackPoint,id,x,y,name)
      if placed and mod.WaypointPoint then
        local current,px,py=mod.WaypointPoint()
        if current==id and px and py and math.abs(px-x)<0.001 and math.abs(py-y)<0.001 then return true end
      end
    end
  end
  if C_Map and C_Map.SetUserWaypoint and UiMapPoint and UiMapPoint.CreateFromCoordinates
      and (not C_Map.CanSetUserWaypointOnMap or C_Map.CanSetUserWaypointOnMap(id)) then
    local ok,result=pcall(C_Map.SetUserWaypoint,UiMapPoint.CreateFromCoordinates(id,x,y))
    if ok and result~=false then
      local point=C_Map.GetUserWaypoint and C_Map.GetUserWaypoint()
      if not C_Map.GetUserWaypoint or (point and point.uiMapID==id and point.position
          and math.abs(point.position.x-x)<0.001 and math.abs(point.position.y-y)<0.001) then
        if C_SuperTrack and C_SuperTrack.SetSuperTrackedUserWaypoint then
          pcall(C_SuperTrack.SetSuperTrackedUserWaypoint,true)
        end
        return true
      end
    end
  end
end

local mapRequest=0
local function showVendorMap(row)
  local o=row.offer
  local loc=o and AP.VendorLocations[o.merchant.."|"..o.zone]
  if not loc then return end
  if InCombatLockdown and InCombatLockdown() then
    status:SetText("Open the vendor map after combat.")
    return
  end
  if C_Map and C_Map.OpenWorldMap then C_Map.OpenWorldMap(loc[1])
  elseif type(OpenWorldMap)=="function" then OpenWorldMap(loc[1])
  elseif WorldMapFrame and WorldMapFrame.SetMapID then
    WorldMapFrame:Show()
    WorldMapFrame:SetMapID(loc[1])
  else status:SetText("World map unavailable."); return end
  mapRequest=mapRequest+1
  local request=mapRequest
  local tries=0
  local function place()
    if request~=mapRequest then return end
    local map=WorldMapFrame
    if not map or not map:IsShown() then
      tries=tries+1
      if tries<25 and C_Timer and C_Timer.After then C_Timer.After(0.1,place)
      else status:SetText("Map did not open. Click Map to try again.") end
      return
    end
    if dropWaypoint(loc,o.merchant) then
      mapTarget=nil
      window:Hide()
      if AuctionPeekFrame then AuctionPeekFrame:Hide() end
      return
    end
    local canvas=map.GetCanvas and map:GetCanvas()
    mapTarget=loc[2] and loc or nil
    if canvas and mapTarget then
      if not mapMarker then
        mapMarker=CreateFrame("Frame",nil,canvas)
        mapMarker:SetSize(24,24)
        mapMarker:SetFrameLevel(canvas:GetFrameLevel()+150)
        mapMarker.symbol=mapMarker:CreateTexture(nil,"OVERLAY")
        mapMarker.symbol:SetAllPoints()
        mapMarker.symbol:SetTexture("Interface/TargetingFrame/UI-RaidTargetingIcon_1")
        mapMarker.caption=mapMarker:CreateFontString(nil,"OVERLAY","GameFontNormal")
        mapMarker.caption:SetPoint("TOP",mapMarker,"BOTTOM",0,0)
        mapMarker:SetScript("OnUpdate",updateMarker)
      end
      mapMarker.caption:SetText(o.merchant)
      updateMarker(mapMarker)
    end
    window:Hide()
    if AuctionPeekFrame then AuctionPeekFrame:Hide() end
  end
  if C_Timer and C_Timer.After then C_Timer.After(0,place) else place() end
end

-- Keep the native item tooltip (and price-addon lines) on Shift-hover.
local previewRows=setmetatable({}, {__mode="k"})
local hookedComparisons=setmetatable({}, {__mode="k"})
local function hidePreviewComparison(frame)
  if IsShiftKeyDown() and previewRows[GameTooltip:GetOwner()] then frame:Hide() end
end
local function watchComparison(frame)
  if not frame then return end
  if not hookedComparisons[frame] then
    frame:HookScript("OnShow",hidePreviewComparison)
    hookedComparisons[frame]=true
  end
  if frame:IsShown() then hidePreviewComparison(frame) end
end
local function updatePreview(row)
  if not IsShiftKeyDown() or not GameTooltip:IsOwned(row) then return end
  watchComparison(ShoppingTooltip1)
  watchComparison(ShoppingTooltip2)
  for _,frame in pairs(GameTooltip.shoppingTooltips or {}) do watchComparison(frame) end
end

-- Listen only while a row owns the tooltip, including Shift pressed after hover.
function AP.BindShiftTooltip(row)
  previewRows[row]=true
  row:HookScript("OnEnter",function(self)
    self:RegisterEvent("MODIFIER_STATE_CHANGED")
    updatePreview(self)
  end)
  row:HookScript("OnLeave",function(self) self:UnregisterEvent("MODIFIER_STATE_CHANGED") end)
  row:HookScript("OnHide",function(self) self:UnregisterEvent("MODIFIER_STATE_CHANGED") end)
  row:HookScript("OnEvent",function(self,event,key)
    if event=="MODIFIER_STATE_CHANGED" and (key=="LSHIFT" or key=="RSHIFT")
        and self:IsMouseOver() then self:GetScript("OnEnter")(self) end
  end)
end

local function unitMoney(value)
  if value%1==0 then return value==0 and "0c" or AP.Money(value) end
  return string.format("%.2fc",value)
end

local prices,ordered={},nil
local modes={name="Item A–Z",high="AH − vendor: high to low",low="AH − vendor: low to high"}
local mode,hideMissing,hideMissingAH,hideDuplicates="name",false,false,false

local sides,hideAlliance,hideHorde
local sideTags={Alliance="[A]",Horde="[H]",["Alliance seen"]="[A?]",["Horde seen"]="[H?]",Both="[A/H]"}
local sideDetails={
  Alliance="Alliance accessible; Horde observed unfriendly or hostile.",
  Horde="Horde accessible; Alliance observed unfriendly or hostile.",
  ["Alliance seen"]="Alliance accessible; Horde access unverified.",
  ["Horde seen"]="Horde accessible; Alliance access unverified.",
  Both="Accessible reactions observed for both factions.",
}
local function visibleSide(side)
  if side=="Alliance" or side=="Alliance seen" then return not hideAlliance end
  if side=="Horde" or side=="Horde seen" then return not hideHorde end
  return true
end
local excludeBoP
local function binding(id)
  local flag=AP.vendorBinding[id]
  if flag~=-1 then return flag end
  local getInfo=C_Item and C_Item.GetItemInfo or GetItemInfo
  if getInfo then
    local kind=select(14,getInfo(id))
    if type(kind)=="number" then
      flag=kind==1 and 1 or 0
      AP.vendorBinding[id]=flag
    end
  end
  return flag
end

local priceDetails={}
local lastPriceRevision=nil
local function acAPI()
  local api=rawget(_G,'AuctionCompanionAPI')
  return type(api)=='table' and type(api.GetPriceByItemID)=='function' and api or nil
end
local function auctionatorAPI()
  local api=Auctionator and Auctionator.API and Auctionator.API.v1
  return api and type(api.GetAuctionPriceByItemID)=='function' and api or nil
end
local function providerName()
  return acAPI() and 'AC' or auctionatorAPI() and 'Auctionator' or 'No AH price provider'
end
local function validPrice(p)
  return type(p)=='number' and p>0 and p<math.huge
      and not (issecretvalue and issecretvalue(p))
end
local function auctionPrice(o)
  local flag=binding(o.id)
  if flag==1 or flag==-1 then return false end
  if prices[o.id]==nil then
    local price,source,observed=false,nil,nil
    local api=acAPI()
    if api then
      local hasTarget=false
      if type(api.GetItemListScanQuote)=='function' then
        local ok,p,id,at,state=pcall(api.GetItemListScanQuote,o.id)
        if ok and state and state~='not-in-scan' then
          hasTarget=true
          if state=='verified' and validPrice(p) and tonumber(id)==o.id then
            price,source,observed=p,'AC Vendor List Scan',at
          else
            source='AC scan: '..tostring(state)
          end
          -- Once AC completes a NEWER global Full Scan, its snapshot may
          -- supersede either a vendor-list price or a vendor-list miss.
          -- While a targeted scan is still running, never substitute an
          -- older snapshot for a pending/unverified list entry.
          if type(api.GetScannedPrice)=='function' and type(api.GetScanStatus)=='function' then
            local scan=type(api.GetNameScanStatus)=='function' and api.GetNameScanStatus() or nil
            local reference=tonumber(at) or (scan and tonumber(scan.completedAt or scan.startedAt))
            local statusOK,fullStatus=pcall(api.GetScanStatus)
            local snapshotAt=statusOK and fullStatus and tonumber(fullStatus.lastCompleted)
            if reference and snapshotAt and snapshotAt>reference then
              local sOK,scanned=pcall(api.GetScannedPrice,o.id)
              price=sOK and validPrice(scanned) and scanned or false
              source=price and 'AC Full Scan' or 'AC Full Scan: unpriced'
              observed=snapshotAt
            end
          end
        end
      end
      if not hasTarget then
        local ok,p,origin,at=pcall(api.GetPriceByItemID,o.id)
        if ok and validPrice(p) then
          price,source,observed=p,origin=='scan' and 'AC Full Scan' or 'AC recent search',at
        end
      end
    else
      -- Optional legacy fallback for players who do not install AC. Never
      -- mix Auctionator prices into an AC-powered listing.
      local legacy=auctionatorAPI()
      if legacy then
        local ok,p=pcall(legacy.GetAuctionPriceByItemID,'AuctionPeek',o.id)
        if ok and validPrice(p) then price,source=p,'Auctionator cached' end
      end
    end
    prices[o.id]=price
    priceDetails[o.id]={source=source or (api and 'AC unavailable / unpriced' or 'No AH price'),at=observed}
  end
  return prices[o.id]
end

local function orderedOffers()
  if mode=="name" then return offers end
  if ordered then return ordered end
  ordered={}
  local delta,index={},{}
  for i,o in ipairs(offers) do
    ordered[i]=o
    index[o]=i
    local p=auctionPrice(o)
    if p and o.price>0 and o.bundle>0 then delta[o]=p-o.price/o.bundle end
  end
  table.sort(ordered,function(a,b)
    local x,y=delta[a],delta[b]
    if x==y then return index[a]<index[b] end
    if x==nil then return false end
    if y==nil then return true end
    if mode=="high" then return x>y end
    return x<y
  end)
  return ordered
end

local function draw()
  if not window or not window:IsShown() then return end
  local pages=math.max(1,math.ceil(#matches/size))
  page=math.max(1,math.min(page,pages))
  local api=acAPI()
  local legacy=not api and auctionatorAPI() or nil
  for i,row in ipairs(cells) do
    local o=matches[(page-1)*size+i]
    row.offer=o
    row:SetShown(o~=nil)
    if o then
      row.ah:SetEnabled(AP.AtAuctioneer() and
          ((api and type(api.SearchItem)=='function') or (legacy and type(legacy.MultiSearchExact)=='function')) or false)
      row.map:SetEnabled(AP.VendorLocations[o.merchant.."|"..o.zone]~=nil)
      local price=auctionPrice(o)
      local unit=o.price>0 and o.bundle>0 and o.price/o.bundle or nil
      local diff=price and unit and price-unit
      row[1]:SetText(o.name)
      row[2]:SetText((sideTags[sides[o.merchant]] or "[?]").." "..o.merchant)
      row[3]:SetText(unit and unitMoney(unit) or "—")
      row[4]:SetText(binding(o.id)==1 and "BoP" or binding(o.id)==-1 and "Bind unknown" or price and unitMoney(price) or "—")
      row[5]:SetText(diff and ((diff>0 and "+" or diff<0 and "-" or "")..unitMoney(math.abs(diff))) or "—")
    end
  end
  previous:SetEnabled(page>1)
  nextButton:SetEnabled(page<pages)
  local summary=#matches..(hideDuplicates and " items" or " offers").."   •   Page "..page.."/"..pages
  if #matches==0 then summary="No matching offers." end
  local scan=api and type(api.GetNameScanStatus)=='function' and api.GetNameScanStatus() or nil
  if scan and scan.label=='Vendor archive item scan' and scan.phase=='running' then
    summary=('AC Vendor Scan %d/%d • %d priced • %d unresolved'):format(
        scan.done or 0,scan.total or 0,scan.verified or 0,scan.failed or 0)
  elseif scan and scan.label=='Vendor archive item scan' and scan.phase~='running' then
    summary=summary..('   •   Last vendor scan %d/%d priced'):format(scan.verified or 0,scan.total or 0)
  end
  status:SetText(summary..(not api and not legacy and '   •   AC/Auctionator unavailable' or ''))
  if scanButton then
    scanButton:SetText(scan and scan.label=='Vendor archive item scan' and scan.phase=='running' and
        ('Scanning %d/%d'):format(scan.done or 0,scan.total or 0) or 'Scan Vendor List')
  end
end

local function worldPoint(map,pos)
  if not map or not pos then return end
  local continent,point=C_Map.GetWorldPosFromMapPos(map,pos)
  if not point or (issecretvalue and (issecretvalue(continent) or issecretvalue(point.x) or issecretvalue(point.y))) then return end
  if continent and type(point.x)=="number" and type(point.y)=="number" then return continent,point.x,point.y end
end

local function vendorDistances()
  if not (C_Map and C_Map.GetBestMapForUnit and C_Map.GetPlayerMapPosition
      and C_Map.GetWorldPosFromMapPos and CreateVector2D) then return end
  local map=C_Map.GetBestMapForUnit("player")
  if not map then return end
  local continent,x,y=worldPoint(map,C_Map.GetPlayerMapPosition(map,"player"))
  if not continent then return end
  local cache={}
  return function(o)
    local loc=AP.VendorLocations[o.merchant.."|"..o.zone]
    if not loc then return math.huge end
    if not cache[loc] then
      local c,vx,vy=worldPoint(loc[1],CreateVector2D(loc[2]/100,loc[3]/100))
      cache[loc]=c==continent and ((vx-x)^2+(vy-y)^2) or math.huge
    end
    return cache[loc]
  end
end

local function unitCost(o)
  return o.price>0 and o.bundle>0 and o.price/o.bundle or math.huge
end

local function collapseOffers()
  local best={}
  local distance=vendorDistances()
  for _,o in ipairs(matches) do
    local current=best[o.id]
    if not current or unitCost(o)<unitCost(current)
        or (unitCost(o)==unitCost(current) and distance and distance(o)<distance(current)) then
      best[o.id]=o
    end
  end
  local unique={}
  for _,o in ipairs(matches) do
    if best[o.id]==o then unique[#unique+1]=o end
  end
  matches=unique
end

function AP.RefreshVendorArchive()
  if not window or not window:IsShown() then return end
  local q=search:GetText():lower()
  matches={}
  for _,o in ipairs(orderedOffers()) do
    o.searchKey=o.searchKey or (o.name.." "..o.id.." "..o.merchant.." "..o.zone):lower()
    if visibleSide(sides[o.merchant]) and (not excludeBoP or (binding(o.id) or 0)==0) and (not hideMissing or (o.price>0 and o.bundle>0)) and (q=="" or o.searchKey:find(q,1,true))
        and (not hideMissingAH or auctionPrice(o)) then
      matches[#matches+1]=o
    end
  end
  if hideDuplicates then collapseOffers() end
  draw()
end

local function refreshPrices()
  prices,priceDetails,ordered={},{},nil
  AP.RefreshVendorArchive()
end

-- Only scan item IDs included by the current vendor-archive filters, never
-- AC's entire AH. AH-price visibility is intentionally ignored: otherwise
-- items without an existing quote could never be discovered.
local function vendorTargets()
  local targetList,seen={},{}
  for _,o in ipairs(offers or {}) do
    if not seen[o.id] and visibleSide(sides[o.merchant])
        and (not excludeBoP or (binding(o.id) or 0)==0)
        and (not hideMissing or (o.price>0 and o.bundle>0)) then
      seen[o.id]=true
      targetList[#targetList+1]={itemID=o.id,name=o.name}
    end
  end
  table.sort(targetList,function(a,b) return a.itemID<b.itemID end)
  return targetList
end
local function startVendorScan()
  local api=acAPI()
  if not api or type(api.StartItemListScan)~='function' then
    status:SetText('Install Auction Companion v0.1.13+ for Vendor List Scan.')
    return
  end
  if not AP.AtAuctioneer() then
    status:SetText('Open the Auction House before scanning vendor items.')
    return
  end
  local scan=type(api.GetNameScanStatus)=='function' and api.GetNameScanStatus() or nil
  if scan and scan.phase=='running' and scan.label=='Vendor archive item scan' then
    if type(api.CancelNameScan)=='function' then api.CancelNameScan('Vendor List Scan cancelled.') end
    refreshPrices()
    return
  end
  local list=vendorTargets()
  if #list==0 then status:SetText('No eligible vendor items under current filters.'); return end
  local ok,err=api.StartItemListScan(list,'Vendor archive item scan')
  if not ok then status:SetText('AC: '..tostring(err or 'scan unavailable')); return end
  refreshPrices()
end

local function button(text,x,y,width,action)
  local b=CreateFrame("Button",nil,window,"UIPanelButtonTemplate")
  b:SetPoint("TOPLEFT",x,y); b:SetSize(width,22); b:SetText(text); b:SetScript("OnClick",action)
  return b
end

local function label(parent,text,x,y,width,align)
  local f=parent:CreateFontString(nil,"OVERLAY","GameFontHighlightSmall")
  f:SetPoint("TOPLEFT",x,y); f:SetWidth(width); f:SetJustifyH(align or "LEFT")
  f:SetWordWrap(false); f:SetText(text)
  return f
end

function AP.ToggleVendors()
  if window then window:SetShown(not window:IsShown()); return end
  sides=AP.LoadVendorSides()
  offers=AP.LoadVendorOffers()
  AP.VendorLocations=AP.LoadVendorLocations()
  window=CreateFrame("Frame","AuctionPeekVendorArchive",UIParent)
  window:SetSize(850,424); window:SetPoint("CENTER"); window:SetFrameStrata("DIALOG")
  window:SetClampedToScreen(true); window:EnableMouse(true); window:SetMovable(true)
  window:RegisterForDrag("LeftButton"); window:SetScript("OnDragStart",window.StartMoving)
  window:SetScript("OnDragStop",window.StopMovingOrSizing)
  local bg=window:CreateTexture(nil,"BACKGROUND"); bg:SetAllPoints(); bg:SetColorTexture(.085,.075,.055,1)
  table.insert(UISpecialFrames,"AuctionPeekVendorArchive")
  label(window,"Auction Peek   •   Vendor archive",14,-12,400):SetTextColor(1,.82,.35)
  local close=CreateFrame("Button",nil,window,"UIPanelCloseButton")
  close:SetPoint("TOPRIGHT"); close:SetScript("OnClick",function() window:Hide() end)
  label(window,"Search",14,-45,46)
  search=CreateFrame("EditBox",nil,window,"InputBoxTemplate"); search:SetSize(475,22)
  search:SetPoint("TOPLEFT",67,-39); search:SetAutoFocus(false)
  search:SetScript("OnTextChanged",function() page=1; AP.RefreshVendorArchive() end)
  search:SetScript("OnEscapePressed",function() window:Hide() end)
  button("Refresh",620,-39,80,refreshPrices)
  scanButton=button("Scan Vendor List",705,-39,135,startVendorScan)
  scanButton:SetScript('OnEnter',function(self)
    GameTooltip:SetOwner(self,'ANCHOR_RIGHT')
    GameTooltip:AddLine('Scan Vendor List with Auction Companion')
    GameTooltip:AddLine('Only the '..#vendorTargets()..' eligible unique vendor items; not AC Full Scan.',1,1,1,true)
    GameTooltip:AddLine('Honors faction, BoP and vendor-price filters. Includes missing AH prices.',.8,.8,.8,true)
    GameTooltip:AddLine('Live searches require the Auction House and can take several minutes.',.8,.8,.8,true)
    GameTooltip:Show()
  end)
  scanButton:SetScript('OnLeave',function() GameTooltip:Hide() end)
  local prefs=AuctionPeekDB or {}
  mode=modes[prefs.vendorArchiveSort] and prefs.vendorArchiveSort or "name"
  hideMissing=prefs.vendorArchiveHideMissing==true
  hideMissingAH=prefs.vendorArchiveHideMissingAH==true
  hideDuplicates=prefs.vendorArchiveHideDuplicates==true
  excludeBoP=prefs.vendorArchiveExcludeBoP~=false
  local function priceFilter(x,title,checked,save,y)
    local check=CreateFrame("CheckButton",nil,window,"UICheckButtonTemplate")
    check:SetPoint("TOPLEFT",x,y or -65)
    check:SetSize(24,24)
    check:SetChecked(checked)
    label(window,title,x+27,(y or -65)-7,190)
    check:SetHitRectInsets(0,-145,0,0)
    check:SetScript("OnClick",function(self)
      save(self:GetChecked() and true or false)
      page=1
      AP.RefreshVendorArchive()
    end)
  end
  priceFilter(10,"Hide missing AH prices",hideMissingAH,function(value)
    hideMissingAH=value
    prefs.vendorArchiveHideMissingAH=value
  end)
  priceFilter(225,"Hide missing vendor prices",hideMissing,function(value)
    hideMissing=value
    prefs.vendorArchiveHideMissing=value
  end)
  priceFilter(433,"Hide duplicate items",hideDuplicates,function(value)
    hideDuplicates=value
    prefs.vendorArchiveHideDuplicates=value
  end)
  priceFilter(10,"Exclude BoP",excludeBoP,function(value)
    excludeBoP=value
    prefs.vendorArchiveExcludeBoP=value
  end,-86)
  hideAlliance=prefs.vendorArchiveHideAlliance==true
  hideHorde=prefs.vendorArchiveHideHorde==true
  priceFilter(225,"Hide Alliance vendors",hideAlliance,function(value)
    hideAlliance=value
    prefs.vendorArchiveHideAlliance=value
  end,-86)
  priceFilter(433,"Hide Horde vendors",hideHorde,function(value)
    hideHorde=value
    prefs.vendorArchiveHideHorde=value
  end,-86)
  button("Sort: "..modes[mode],625,-66,215,function(self)
    mode=({name="high",high="low",low="name"})[mode]
    prefs.vendorArchiveSort=mode
    self:SetText("Sort: "..modes[mode])
    ordered=nil
    page=1
    AP.RefreshVendorArchive()
  end)
  local x={14,215,371,477,591}
  local widths={194,150,94,104,109}
  local headers={"Item","Vendor","Vendor / unit","AC / unit","AH − vendor"}
  for j,title in ipairs(headers) do label(window,title,x[j],-113,widths[j],j>2 and "RIGHT" or "LEFT"):SetTextColor(1,.82,.35) end
  for i=1,size do
    local row=CreateFrame("Frame",nil,window)
    row:SetSize(846,20); row:SetPoint("TOPLEFT",0,-127-(i-1)*21); row:EnableMouse(true)
    for j=1,5 do row[j]=label(row,"",x[j],-2,widths[j],j>2 and "RIGHT" or "LEFT") end
    row.map=CreateFrame("Button",nil,row,"UIPanelButtonTemplate")
    row.map:SetSize(47,20)
    row.map:SetPoint("TOPLEFT",710,0)
    row.map:SetText("Map")
    row.map:SetScript("OnClick",function() showVendorMap(row) end)
    row.ah=CreateFrame("Button",nil,row,"UIPanelButtonTemplate")
    row.ah:SetPoint("LEFT",row.map,"RIGHT",3,0)
    row.ah:SetSize(77,20)
    row.ah:SetText("AH Search")
    row.ah:SetScript("OnClick",function()
      local o=row.offer
      if not (o and AP.AtAuctioneer()) then return end
      local api=acAPI()
      if api and type(api.SearchItem)=='function' then
        local ok,started,err=pcall(api.SearchItem,o.id,1)
        if not ok or not started then status:SetText('AC could not search: '..tostring(err or started)); return end
      else
        local legacy=auctionatorAPI()
        if not legacy or type(legacy.MultiSearchExact)~='function' then return end
        local name=C_Item and C_Item.GetItemNameByID and C_Item.GetItemNameByID(o.id)
        local ok=pcall(legacy.MultiSearchExact,'AuctionPeek',{name or o.name})
        if not ok then status:SetText('Auctionator could not search.'); return end
      end
      window:Hide()
      if AuctionPeekFrame then AuctionPeekFrame:Hide() end
    end)
    row:SetScript("OnEnter",function(self)
      local o=self.offer
      if not o then return end
      GameTooltip:SetOwner(self,"ANCHOR_RIGHT")
      if IsShiftKeyDown() then
        GameTooltip:SetHyperlink("item:"..o.id)
        GameTooltip:Show()
        return
      end
      GameTooltip:SetText(o.name.."  #"..o.id)
      GameTooltip:AddLine(o.merchant..((o.zone or "")~="" and " • "..o.zone or ""))
      GameTooltip:AddLine(sideDetails[sides[o.merchant]] or "Faction access unverified.")
      local loc=AP.VendorLocations[o.merchant.."|"..o.zone]
      GameTooltip:AddLine(loc and string.format("Vendor location: %.1f, %.1f",loc[2],loc[3]) or "Map location unavailable")
      if o.bundle>0 and o.price>0 then GameTooltip:AddLine(o.bundle.." units for "..AP.Money(o.price).." observed")
      else GameTooltip:AddLine("Coin-only unit price unavailable") end
      GameTooltip:AddLine("Highest recorded standard price for this offer. Your discount may differ.")
      auctionPrice(o)
      local detail=priceDetails[o.id]
      GameTooltip:AddLine('AH source: '..tostring(detail and detail.source or providerName()))
      if detail and detail.at and type(date)=='function' then
        GameTooltip:AddLine('Observed: '..date('%b %d %I:%M %p',detail.at))
      end
      GameTooltip:AddLine('AH minus vendor is before auction fees.')
      GameTooltip:Show()
    end)
    row:SetScript("OnLeave",function() GameTooltip:Hide() end)
    AP.BindShiftTooltip(row)
    cells[i]=row
  end
  status=label(window,"",14,-395,480)
  previous=button("Previous",531,-387,83,function() page=page-1; draw() end)
  nextButton=button("Next",621,-387,79,function() page=page+1; draw() end)
  window:RegisterEvent("GET_ITEM_INFO_RECEIVED")
  local bindingRefreshQueued=false
  window:SetScript("OnEvent",function(self,event,id,success)
    if success and AP.vendorBinding[id]==-1 and binding(id)~=-1 then
      ordered=nil
      if self:IsShown() and not bindingRefreshQueued then
        bindingRefreshQueued=true
        C_Timer.After(0,function()
          bindingRefreshQueued=false
          AP.RefreshVendorArchive()
        end)
      end
    end
  end)
  local refreshElapsed,cacheAge=0,0
  local lastScanProgress=''
  window:SetScript('OnUpdate',function(self,elapsed)
    if not self:IsShown() then return end
    refreshElapsed=refreshElapsed+(elapsed or 0)
    if refreshElapsed<2 then return end
    cacheAge=cacheAge+refreshElapsed
    refreshElapsed=0
    local api=acAPI()
    local revision=api and type(api.GetPriceRevision)=='function' and api.GetPriceRevision() or 0
    local scan=api and type(api.GetNameScanStatus)=='function' and api.GetNameScanStatus() or nil
    local progress=scan and scan.label=='Vendor archive item scan' and
        (tostring(scan.id)..':'..tostring(scan.phase)..':'..tostring(scan.done)) or ''
    -- Invalidate even when no provider event fires, so expiring 30-minute
    -- AC live quotes cannot remain displayed indefinitely in an open archive.
    if revision~=lastPriceRevision or progress~=lastScanProgress or cacheAge>=60 then
      lastPriceRevision,lastScanProgress=revision,progress
      cacheAge=0
      refreshPrices()
    end
  end)
  window:SetScript("OnShow",function()
    lastPriceRevision=nil
    cacheAge=0
    refreshPrices()
  end)
  AP.RefreshVendorArchive()
end
