Stat Gains 1.9.3
WoW Forever item tooltip addon

INSTALLATION
1. Extract the StatGains folder into your Interface\AddOns folder.
2. Restart WoW or type /reload.
3. Make sure Stat Gains is enabled in the AddOns list.
4. Hover an item normally to see class-derived values in parentheses on its stat
   lines. If extra tooltip comparison rows are enabled, when WoW shows its "If you replace this item" comparison, derived stat differences
   are retried while the tooltip is visible. The candidate tooltip shows the upgrade
   deltas, and the visible equipped comparison panel shows the inverse deltas.
5. Type /statgains to enable optional comparison features (both off by default).
   Then hold Shift and middle-click an item to open the side-by-side comparison panel.
   It only opens while the cursor is over a shown item tooltip; while open, the
   same chord can close it from anywhere.
   The headings show the item names followed by (E) for equipped and (C) for
   candidate; click either name to open that item's standard WoW tooltip.
   The version and larger score summary are shown at the bottom.
   Close the panel with its X or Shift+middle-click again.

WHAT IT SHOWS
- Intellect: maximum mana gained (15 mana per point; omitted for Warriors).
- Stamina: maximum health gained (10 per point; 10.5 for Tauren).
- Strength: melee attack power gained, based on the character's class.
- Agility: armor and class-appropriate melee/ranged attack power.
- Agility: critical strike chance based on the viewing character's class and level.
- Weapons: the comparison panel shows estimated weapon DPS and DPS from offensive stats; the normal tooltip keeps the game's own damage and speed lines.
- Gear: Shift+middle-click opens a comparison panel with equipped and candidate stats, derived gains, score change, and estimated melee or ranged auto-attack DPS change. Stat Gains flags armor types your class cannot equip instead of ranking them as upgrades.
- Class/spec: Use the comparison panel dropdowns to select a class and spec, or leave Class on Player and Spec on Auto. Auto uses the highest-spent talent tree when the client exposes it; otherwise it uses a class default. Selection is saved per character.
- Spec scoring: Priest Discipline, Holy, and Shadow have separate starter stat weights. Discipline weights Intellect at 1.5, spell power at 1.8, and Healing Power at 2.2. Other class/spec options map to tank, melee DPS, ranged DPS, caster DPS, or healer starter profiles. Caster and healer profiles ignore melee weapon DPS and include parsed spell/healing power. These are gear comparison weights, not a rotation simulator.
- Changing the selected class also recalculates class-derived comparison values such as attack power, Spirit regeneration, Agility crit, and armor equip restrictions. The DPS estimate still models the character currently logged in.
- Pawn: supports Pawn 2.14.4. The panel uses Pawn's currently selected scale when that scale is visible, and compares both items on that same scale. If Pawn has not exposed a selected scale, it falls back to the highest-scoring visible scale. The scale name is shown in the panel.

This package targets WoW Forever's 1.60.1 interface and modern tooltip API.
- Spirit: mana regenerated per 5 seconds outside the five-second rule, based on class.

Spirit mana regeneration resumes after 5 seconds without a mana-costing spell,
even while still in combat. Spirit values describe the item-derived amount
outside that five-second rule. They do not include talents, buffs, or other
effects that let a character regenerate mana while casting. The weapon stat DPS
line estimates the AP and Agility crit contribution from that weapon's stats.
The Shift comparison estimates melee or ranged auto-attack DPS change from a
weapon's base DPS difference, class-specific Strength/Agility AP, and Agility
crit. Estimates do not model abilities, talents, procs, buffs, or a full rotation.
The comparison panel uses basic textures for compatibility with clients that
do not support the SetBackdrop method. The Stat Gains score is a separate experimental comparison: it weights item
attributes, armor, and (for weapons) base weapon DPS using starter class-level
weights. It is not a DPS percentage, Pawn scale, or role/spec-optimized rating;
the weights may need tuning for your character and playstyle.
Estimate errors are reported to chat without blocking the normal item tooltip.
The addon reads English item stat lines. Agility-to-crit values use the class
and level-specific values from WoW Forever client data.

Meditation: Priest-only checkbox in the Shift+middle-click comparison panel. Shows estimated casting MP5 from Spirit using the active Meditation rank (17/33/50%). No score changes.

Meditation troubleshooting: /sgmed reports detection; /sgmed 3 manually selects rank 3; /sgmed auto restores detection; /sgmed off disables.

Proc Chance (1.9.2): Toggle Show Proc Chance in the Shift+middle-click comparison panel. On by default, saved per character. Blue annotations display explicit probabilities on equip, chance-on-hit, or set effect lines and a small Forever-only seed table (Darkspear, Spider's Kiss, Howling Hide). Unknown/ambiguous rates are omitted; no Classic fallback, network requests, extra timers, or combat logging. Proc rates do not affect the comparison scores. Reopen the tooltip after changing the checkbox.
Sources for seed rates: https://www.wowhead.com/forever/item=12802/darkspear ; https://www.wowforeveraddon.com/items/venomspitter/ ; https://maxdps.com/forever/patch-notes/1-60-1-70959 . Rates may change with game patches.

1.9.3: /statgains opens settings. Extra comparison rows and the Shift+middle-click panel are independently optional and off by default, including on upgrade. Regular stat annotations and native WoW comparisons remain available. Proc chance and Meditation can also be toggled from settings. Reopen tooltips after changing settings. Preferences are saved per character.
