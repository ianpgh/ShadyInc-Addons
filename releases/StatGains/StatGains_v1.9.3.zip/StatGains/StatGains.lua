-- Stat Gains: show derived health, mana, attack power, armor, and Spirit regen
-- from the primary stats on the item currently shown in a tooltip.
-- Designed for the English WoW Forever / Vanilla-style item tooltip.

local ADDON_NAME = "StatGains"
local ADDON_VERSION = "1.9.3"
local function comparisonEnabled(key)
    return type(StatGainsDB) == "table" and StatGainsDB[key] == true
end
local CLASS_AP_PER_STRENGTH = {
    WARRIOR = 2, PALADIN = 2, SHAMAN = 2, DRUID = 2,
    HUNTER = 1, ROGUE = 1, MAGE = 1, PRIEST = 1, WARLOCK = 1,
}
local CLASS_MELEE_AP_PER_AGILITY = { HUNTER = 1, ROGUE = 1, DRUID = 1 }
local CLASS_RANGED_AP_PER_AGILITY = { HUNTER = 2, ROGUE = 2, WARRIOR = 2 }

-- Some client tooltip regions expose protected text that addons may display
-- but cannot inspect. Skip those values before calling any string functions.
local function isUsableTooltipText(value)
    if type(value) ~= "string" then return false end
    if type(issecretvalue) == "function" then
        local ok, isSecret = pcall(issecretvalue, value)
        if not ok or isSecret then return false end
    end
    return true
end

-- Starter focus profiles. These are relative comparison weights, not simulated DPS.
-- Melee weapon DPS is intentionally excluded from healer and caster profiles.
local SCORE_PROFILES = {
    HEALER = { strength = 0.1, agility = 0.1, stamina = 0.8, intellect = 1.7, spirit = 1.4, attackPower = 0.0, rangedAttackPower = 0.0, armor = 0.02, weaponDPS = 0.0, spellPower = 1.4, healingPower = 2.0 },
    CASTER_DPS = { strength = 0.0, agility = 0.1, stamina = 0.6, intellect = 1.7, spirit = 0.7, attackPower = 0.0, rangedAttackPower = 0.0, armor = 0.01, weaponDPS = 0.0, spellPower = 2.0, healingPower = 0.1 },
    MELEE_DPS = { strength = 1.8, agility = 1.3, stamina = 0.8, intellect = 0.1, spirit = 0.1, attackPower = 1.0, rangedAttackPower = 0.1, armor = 0.02, weaponDPS = 14.0, spellPower = 0.0, healingPower = 0.0 },
    RANGED_DPS = { strength = 0.5, agility = 2.0, stamina = 0.8, intellect = 0.6, spirit = 0.3, attackPower = 0.8, rangedAttackPower = 1.0, armor = 0.02, weaponDPS = 14.0, spellPower = 0.0, healingPower = 0.0 },
    TANK = { strength = 1.4, agility = 0.8, stamina = 2.0, intellect = 0.1, spirit = 0.1, attackPower = 0.8, rangedAttackPower = 0.0, armor = 0.08, weaponDPS = 6.0, spellPower = 0.0, healingPower = 0.0 },
}
local CLASS_HEALER_PROFILES = {
    PRIEST = { strength = 0.0, agility = 0.0, stamina = 0.8, intellect = 1.8, spirit = 1.6, attackPower = 0.0, rangedAttackPower = 0.0, armor = 0.01, weaponDPS = 0.0, spellPower = 1.4, healingPower = 2.2 },
    PALADIN = { strength = 0.1, agility = 0.0, stamina = 0.9, intellect = 1.8, spirit = 0.6, attackPower = 0.0, rangedAttackPower = 0.0, armor = 0.02, weaponDPS = 0.0, spellPower = 1.4, healingPower = 2.1 },
    SHAMAN = { strength = 0.0, agility = 0.0, stamina = 0.8, intellect = 1.8, spirit = 1.1, attackPower = 0.0, rangedAttackPower = 0.0, armor = 0.02, weaponDPS = 0.0, spellPower = 1.4, healingPower = 2.1 },
    DRUID = { strength = 0.0, agility = 0.0, stamina = 0.8, intellect = 1.8, spirit = 1.5, attackPower = 0.0, rangedAttackPower = 0.0, armor = 0.01, weaponDPS = 0.0, spellPower = 1.4, healingPower = 2.1 },
}
local PRIEST_SPEC_WEIGHTS = {
    discipline = { strength = 0.0, agility = 0.0, stamina = 0.8, intellect = 1.5, spirit = 1.6, attackPower = 0.0, rangedAttackPower = 0.0, armor = 0.01, weaponDPS = 0.0, spellPower = 1.8, healingPower = 2.2 },
    holy = { strength = 0.0, agility = 0.0, stamina = 0.8, intellect = 1.7, spirit = 1.6, attackPower = 0.0, rangedAttackPower = 0.0, armor = 0.01, weaponDPS = 0.0, spellPower = 1.3, healingPower = 2.4 },
    shadow = { strength = 0.0, agility = 0.1, stamina = 0.6, intellect = 1.7, spirit = 0.7, attackPower = 0.0, rangedAttackPower = 0.0, armor = 0.01, weaponDPS = 0.0, spellPower = 2.2, healingPower = 0.1 },
}
local DEFAULT_PROFILE_BY_CLASS = {
    WARRIOR = "MELEE_DPS", PALADIN = "HEALER", HUNTER = "RANGED_DPS", ROGUE = "MELEE_DPS",
    PRIEST = "HEALER", SHAMAN = "HEALER", MAGE = "CASTER_DPS", WARLOCK = "CASTER_DPS", DRUID = "HEALER",
}
local CLASS_SPEC_PROFILES = {
    WARRIOR = { arms = "MELEE_DPS", fury = "MELEE_DPS", protection = "TANK" },
    PALADIN = { holy = "HEALER", protection = "TANK", retribution = "MELEE_DPS" },
    HUNTER = { ["beast mastery"] = "RANGED_DPS", marksmanship = "RANGED_DPS", survival = "RANGED_DPS" },
    ROGUE = { assassination = "MELEE_DPS", combat = "MELEE_DPS", subtlety = "MELEE_DPS" },
    PRIEST = { discipline = "HEALER", holy = "HEALER", shadow = "CASTER_DPS" },
    SHAMAN = { elemental = "CASTER_DPS", enhancement = "MELEE_DPS", restoration = "HEALER" },
    MAGE = { arcane = "CASTER_DPS", fire = "CASTER_DPS", frost = "CASTER_DPS" },
    WARLOCK = { affliction = "CASTER_DPS", demonology = "CASTER_DPS", destruction = "CASTER_DPS" },
    DRUID = { balance = "CASTER_DPS", ["feral combat"] = "MELEE_DPS", ["feral combat (dps)"] = "MELEE_DPS", ["feral combat (tank)"] = "TANK", restoration = "HEALER" },
}
local CLASS_SPEC_OPTIONS = {
    WARRIOR = { "Arms", "Fury", "Protection" },
    PALADIN = { "Holy", "Protection", "Retribution" },
    HUNTER = { "Beast Mastery", "Marksmanship", "Survival" },
    ROGUE = { "Assassination", "Combat", "Subtlety" },
    PRIEST = { "Discipline", "Holy", "Shadow" },
    SHAMAN = { "Elemental", "Enhancement", "Restoration" },
    MAGE = { "Arcane", "Fire", "Frost" },
    WARLOCK = { "Affliction", "Demonology", "Destruction" },
    DRUID = { "Balance", "Feral Combat (DPS)", "Feral Combat (Tank)", "Restoration" },
}
local CLASS_DISPLAY_NAMES = {
    WARRIOR = "Warrior", PALADIN = "Paladin", HUNTER = "Hunter", ROGUE = "Rogue",
    PRIEST = "Priest", SHAMAN = "Shaman", MAGE = "Mage", WARLOCK = "Warlock", DRUID = "Druid",
}
local function detectTalentFocus(classToken)
    if not GetNumTalentTabs or not GetTalentTabInfo then return nil, nil end
    local ok, tabCount = pcall(GetNumTalentTabs)
    if not ok or not tonumber(tabCount) then return nil, nil end
    local bestName, bestPoints, tied = nil, 0, false
    for tab = 1, tonumber(tabCount) do
        local tabOk, name, _, points = pcall(GetTalentTabInfo, tab)
        points = tabOk and tonumber(points) or nil
        if points and points > bestPoints then
            bestName, bestPoints, tied = name, points, false
        elseif points and points > 0 and points == bestPoints then
            tied = true
        end
    end
    if not bestName or bestPoints <= 0 or tied then return nil, nil end
    local classProfiles = CLASS_SPEC_PROFILES[classToken]
    local profile = classProfiles and classProfiles[string.lower(bestName)]
    return bestName, profile
end
local function getDPSProfile(classToken, specName)
    if classToken == "PRIEST" or classToken == "MAGE" or classToken == "WARLOCK" then return "CASTER_DPS" end
    if classToken == "HUNTER" then return "RANGED_DPS" end
    if classToken == "DRUID" then
        return specName and string.find(string.lower(specName), "feral", 1, true) and "MELEE_DPS" or "CASTER_DPS"
    end
    if classToken == "SHAMAN" then
        return specName and string.find(string.lower(specName), "enhancement", 1, true) and "MELEE_DPS" or "CASTER_DPS"
    end
    return "MELEE_DPS"
end
local function getPlayerScoringProfile(playerClassToken)
    local selectedClass = StatGainsDB and StatGainsDB.scoreClass or "AUTO"
    local scoringClass = selectedClass == "AUTO" and playerClassToken or selectedClass
    if not CLASS_DISPLAY_NAMES[scoringClass] then scoringClass = playerClassToken end

    local selectedSpec = StatGainsDB and StatGainsDB.scoreSpec or "AUTO"
    local specName, profile
    if selectedSpec == "AUTO" then
        if scoringClass == playerClassToken then
            specName, profile = detectTalentFocus(scoringClass)
        end
    else
        local specOptions = CLASS_SPEC_OPTIONS[scoringClass] or {}
        for _, option in ipairs(specOptions) do
            if string.lower(option) == string.lower(selectedSpec) then
                specName = option
                break
            end
        end
        if specName then
            local specProfiles = CLASS_SPEC_PROFILES[scoringClass]
            profile = specProfiles and specProfiles[string.lower(specName)]
        else
            selectedSpec = "AUTO"
        end
    end
    profile = profile or DEFAULT_PROFILE_BY_CLASS[scoringClass] or "CASTER_DPS"

    local weights
    if scoringClass == "PRIEST" and specName then
        weights = PRIEST_SPEC_WEIGHTS[string.lower(specName)]
    end
    if not weights and profile == "HEALER" then
        weights = CLASS_HEALER_PROFILES[scoringClass]
    end
    weights = weights or SCORE_PROFILES[profile] or SCORE_PROFILES.CASTER_DPS

    local profileNames = { HEALER = "Healer", TANK = "Tank", DPS = "DPS", MELEE_DPS = "Melee DPS", RANGED_DPS = "Ranged DPS", CASTER_DPS = "Caster DPS" }
    local className = CLASS_DISPLAY_NAMES[scoringClass] or "Class"
    local profileName = profileNames[profile] or profile
    local selectionIsAuto = selectedClass == "AUTO" and selectedSpec == "AUTO"
    local focusLabel
    if selectionIsAuto then
        focusLabel = "Auto: " .. className .. (specName and (" / " .. specName) or "") .. " — " .. profileName
    else
        focusLabel = "Selected: " .. className .. (specName and (" / " .. specName) or "") .. " — " .. profileName
    end
    return weights, profile, specName, focusLabel, scoringClass
end

-- WoW Forever's class-specific Agility-per-1%-crit values by character level.
-- Values are from the Forever client data, rounded to the precision exposed there.
local AGILITY_PER_CRIT_PERCENT = {
    WARRIOR = "4.0,4.2,4.2,4.4,4.6,4.8,4.8,5.0,5.2,5.2,5.4,5.6,6.0,6.2,6.4,6.6,6.8,7.2,7.4,7.8,7.8,8.0,8.4,8.6,9.0,9.2,9.4,9.8,10.0,10.4,10.6,10.8,11.2,11.4,11.8,12.0,12.2,12.6,12.8,13.2,13.6,13.8,14.2,14.4,14.8,15.0,15.4,15.8,16.0,16.4,16.8,17.0,17.4,17.8,18.2,18.4,18.8,19.2,19.6,20.0",
    PALADIN = "4.7,4.9,4.9,5.1,5.1,5.3,5.3,5.6,5.6,5.8,5.8,6.0,6.5,6.5,7.0,7.0,7.2,7.7,7.7,8.1,8.4,8.4,8.8,9.1,9.3,9.5,9.8,10.0,10.2,10.7,10.9,10.9,11.4,11.6,12.1,12.3,12.3,12.8,13.0,13.5,13.7,13.7,14.2,14.4,14.9,15.1,15.3,15.8,16.1,16.5,16.8,17.0,17.5,17.7,18.1,18.4,18.6,19.1,19.3,19.8",
    HUNTER = "4.6,4.8,5.0,5.4,5.6,5.8,6.0,6.2,6.6,6.8,7.4,8.4,9.2,10.0,11.0,11.6,12.4,13.4,14.2,15.2,15.8,16.8,17.6,18.6,19.4,20.2,21.2,22.0,23.0,24.0,24.6,25.6,26.6,27.4,28.4,29.2,30.2,31.2,32.2,33.0,33.8,34.8,35.8,36.8,37.7,38.6,39.5,40.8,41.8,42.7,43.7,44.6,45.7,46.7,47.8,48.5,49.8,50.8,52.1,52.9",
    ROGUE = "2.3,2.4,2.5,2.7,2.8,2.9,3.1,3.2,3.3,3.5,3.9,4.3,4.8,5.2,5.8,6.2,6.6,7.1,7.6,8.1,8.6,9.0,9.5,9.9,10.5,11.0,11.4,11.9,12.4,13.0,13.4,13.9,14.4,14.9,15.5,16.0,16.4,16.9,17.4,18.0,18.5,19.0,19.5,20.1,20.7,21.2,21.7,22.2,22.7,23.4,23.9,24.4,25.0,25.5,26.1,26.7,27.2,27.8,28.3,29.0",
    PRIEST = "10.0,10.0,10.0,10.5,10.5,10.5,10.5,11.0,11.0,11.0,11.0,11.5,11.5,11.5,11.5,12.0,12.0,12.0,12.5,12.5,12.5,12.5,13.0,13.0,13.0,13.5,13.5,13.5,14.0,14.0,14.0,14.5,14.5,14.5,15.0,15.0,15.0,15.5,15.5,15.5,16.0,16.0,16.5,16.5,16.5,17.0,17.0,17.5,17.5,17.5,18.0,18.0,18.5,18.5,19.0,19.0,19.5,19.5,20.0,20.0",
    SHAMAN = "6.1,6.1,6.4,6.4,6.7,6.7,6.7,7.0,7.0,7.3,7.3,7.6,7.6,7.9,8.2,8.5,8.5,8.8,8.8,9.4,9.4,9.7,9.7,10.0,10.3,10.6,10.6,10.9,10.9,11.5,11.5,11.8,12.1,12.1,12.7,13.0,13.0,13.3,13.3,13.9,14.2,14.2,14.5,14.9,15.2,15.5,15.7,16.1,16.1,16.7,17.0,17.3,17.3,17.6,18.2,18.5,18.8,18.8,19.1,19.7",
    MAGE = "11.1,11.1,11.1,11.7,11.7,11.7,11.7,11.7,11.7,12.2,12.2,12.2,12.2,12.2,12.8,12.8,12.8,12.8,12.8,13.3,13.3,13.3,13.3,13.9,13.9,13.9,13.9,13.9,14.5,14.5,14.5,14.5,15.0,15.0,15.0,15.6,15.6,15.6,15.6,16.1,16.1,16.1,16.1,16.7,16.7,16.7,17.2,17.2,17.2,17.8,17.8,17.8,18.3,18.3,18.3,18.9,18.9,18.9,19.5,19.5",
    WARLOCK = "6.7,6.7,7.0,7.0,7.0,7.3,7.3,7.3,7.7,7.7,8.0,8.0,8.0,8.3,8.7,9.0,9.0,9.0,9.3,9.7,10.0,10.0,10.3,10.3,11.0,11.0,11.0,11.3,11.3,12.0,12.0,12.3,12.3,12.7,13.0,13.3,13.7,13.7,14.0,14.3,14.7,14.7,15.0,15.0,15.7,16.0,16.0,16.3,16.7,17.0,17.3,17.3,17.7,18.0,18.3,18.7,19.0,19.3,19.3,20.0",
    DRUID = "4.9,4.9,5.1,5.1,5.4,5.4,5.6,5.6,5.9,6.3,6.6,6.6,6.8,6.8,7.3,7.3,7.6,7.8,7.8,8.8,8.8,9.0,9.3,9.3,9.8,9.8,10.0,10.2,10.2,11.2,11.5,11.5,11.7,11.9,12.2,12.4,12.7,12.7,12.9,13.9,14.1,14.1,14.4,14.6,15.1,15.4,15.4,15.6,15.8,16.8,17.1,17.3,17.6,17.6,18.1,18.3,18.6,18.8,19.0,20.0",
}

local function getAgilityCritPerPercent(classToken, level)
    local data = AGILITY_PER_CRIT_PERCENT[classToken]
    level = math.max(1, math.min(60, tonumber(level) or 60))
    if not data then return nil end
    local currentLevel = 0
    for value in string.gmatch(data, "[%d%.]+") do
        currentLevel = currentLevel + 1
        if currentLevel == level then return tonumber(value) end
    end
    return nil
end

local function parseStat(text, statName)
    if not isUsableTooltipText(text) then return 0 end
    local lowerText = string.lower(text)
    local lowerStat = string.lower(statName)
    local total = 0

    -- Standard item lines: "+5 Intellect", "5 Intellect", or "-2 Intellect".
    for value in string.gmatch(lowerText, "([+-]?%d+)%s+" .. lowerStat) do
        total = total + (tonumber(value) or 0)
    end

    -- Accept only explicit "Increases your X by Y" wording; avoid parsing our
    -- own derived tooltip lines as raw item stats.
    for value in string.gmatch(lowerText, "increases your " .. lowerStat .. " by ([+-]?%d+)") do
        total = total + (tonumber(value) or 0)
    end
    return total
end

local function parseAttackPower(text, ranged)
    if not isUsableTooltipText(text) then return 0 end
    local lowerText = string.lower(text)
    local isRanged = string.find(lowerText, "ranged", 1, true) ~= nil
    if isRanged ~= ranged then return 0 end
    local value = string.match(lowerText, "([+-]?%d+)%s+attack power")
    if not value and string.find(lowerText, "increases your", 1, true) then
        value = string.match(lowerText, "increases your attack power by ([+-]?%d+)")
    end
    return tonumber(value) or 0
end

local function getStatGains(stats, classToken)
    local meleeAP = stats.attackPower or 0
    meleeAP = meleeAP + stats.strength * (CLASS_AP_PER_STRENGTH[classToken] or 1)
    meleeAP = meleeAP + stats.agility * (CLASS_MELEE_AP_PER_AGILITY[classToken] or 0)

    local rangedAP = stats.rangedAttackPower or 0
    rangedAP = rangedAP + stats.agility * (CLASS_RANGED_AP_PER_AGILITY[classToken] or 0)
    return meleeAP, rangedAP
end

local function readWeaponDPS(text)
    if not isUsableTooltipText(text) then return nil end
    local lowerText = string.lower(text)
    local dps = string.match(lowerText, "%(([%d%.]+)%s+damage per second%)")
        or string.match(lowerText, "([%d%.]+)%s+dps")
    if dps then return tonumber(dps) end
    return nil
end

local function spiritManaPerFive(classToken)
    if classToken == "PRIEST" or classToken == "MAGE" then
        return 0.625 -- (Spirit / 4) mana every 2 seconds
    elseif classToken == "DRUID" then
        return 5 / 9 -- Caster form: Spirit / 4.5 every 2 seconds
    elseif classToken == "WARRIOR" then
        return nil
    end
    return 0.5 -- Hunter, Paladin, Shaman, Warlock; constants cancel for item delta
end

local meditationCacheTime, meditationCacheValue = -100, 0
local meditationStatus = "not scanned"
local function meditationFraction(classToken)
    if classToken ~= "PRIEST" or not StatGainsDB or not StatGainsDB.meditation then return 0 end
    local _, playerClass = UnitClass("player")
    if playerClass ~= "PRIEST" then return 0 end
    local ranks = { [0] = 0, [1] = 0.17, [2] = 0.33, [3] = 0.50 }
    if ranks[StatGainsDB.meditationRank] ~= nil then
        meditationStatus = "manual rank " .. StatGainsDB.meditationRank
        return ranks[StatGainsDB.meditationRank]
    end
    local now = GetTime and GetTime() or 0
    if now - meditationCacheTime < 0.5 then return meditationCacheValue end
    meditationCacheTime, meditationCacheValue = now, 0
    meditationStatus = "talent not detected"
    if not GetNumTalents or not GetTalentInfo then return 0 end
    local tabs = 3
    if GetNumTalentTabs then
        local ok, n = pcall(GetNumTalentTabs)
        if ok and type(n) == "number" and n > 0 then tabs = n end
    end
    for tab = 1, tabs do
        local ok, n = pcall(GetNumTalents, tab)
        if ok and type(n) == "number" then
            for i = 1, n do
                local success, name, _, _, _, rank = pcall(GetTalentInfo, tab, i)
                if success and type(name) == "string" and name:lower():match("^meditation%s*$") then
                    meditationCacheValue = ranks[tonumber(rank)] or 0
                    meditationStatus = "detected rank " .. tostring(rank)
                    return meditationCacheValue
                end
            end
        end
    end
    return 0
end

SLASH_STATGAINSMEDITATION1 = "/sgmed"
SlashCmdList["STATGAINSMEDITATION"] = function(msg)
    if type(StatGainsDB) ~= "table" then return end
    msg = (msg or ""):lower():match("^%s*(.-)%s*$")
    local rank = tonumber(msg)
    if rank and rank >= 0 and rank <= 3 and rank == math.floor(rank) then
        StatGainsDB.meditationRank = rank
        StatGainsDB.meditation = true
    elseif msg == "auto" then
        StatGainsDB.meditationRank = nil
        StatGainsDB.meditation = true
    elseif msg == "off" then
        StatGainsDB.meditation = false
    end
    meditationCacheTime = -100
    local fraction = meditationFraction("PRIEST")
    print("Stat Gains Meditation: " .. (StatGainsDB.meditation and meditationStatus or "disabled") .. " (" .. math.floor(fraction * 100 + 0.5) .. "%). /sgmed auto, 0-3, or off.")
end

local function formatNumber(value)
    if math.abs(value - math.floor(value + 0.5)) < 0.0001 then
        return string.format("%d", math.floor(value + 0.5))
    end
    return string.format("%.2f", value):gsub("0+$", ""):gsub("%.$", "")
end

local function signedNumber(value)
    if value >= 0 then return "+" .. formatNumber(value) end
    return formatNumber(value)
end

local function signedDPS(value)
    return string.format("%+.2f", value)
end

local function formatPercent(value)
    local text = string.format("%.3f", value):gsub("0+$", ""):gsub("%.$", "")
    return (value >= 0 and "+" or "") .. text .. "%"
end

local function getTooltipStats(tooltip)
    local stats = {
        strength = 0, agility = 0, stamina = 0, intellect = 0, spirit = 0,
        attackPower = 0, rangedAttackPower = 0, armor = 0, weaponDPS = nil,
        spellPower = 0, healingPower = 0,
        damageMin = nil, damageMax = nil, weaponSpeed = nil,
    }
    local name = tooltip:GetName()
    if not name then return stats end

    for i = 1, tooltip:NumLines() do
        local left = _G[name .. "TextLeft" .. i]
        local text = left and left:GetText()
        if isUsableTooltipText(text) then
            -- Ignore the game's "If you replace this item" comparison block;
            -- it contains deltas that would otherwise look like item stats.
            if string.find(string.lower(text), "if you replace this item", 1, true) then
                break
            end
            stats.strength = stats.strength + parseStat(text, "Strength")
            stats.agility = stats.agility + parseStat(text, "Agility")
            stats.stamina = stats.stamina + parseStat(text, "Stamina")
            stats.intellect = stats.intellect + parseStat(text, "Intellect")
            stats.spirit = stats.spirit + parseStat(text, "Spirit")
            stats.attackPower = stats.attackPower + parseAttackPower(text, false)
            stats.rangedAttackPower = stats.rangedAttackPower + parseAttackPower(text, true)

            local lowerText = string.lower(text)
            local sharedPower = tonumber(string.match(lowerText, "damage and healing done.-up to ([+-]?%d+)"))
            local healingPower = tonumber(string.match(lowerText, "healing done.-up to ([+-]?%d+)"))
            local spellPower = tonumber(string.match(lowerText, "damage done.-up to ([+-]?%d+)"))
            if sharedPower then
                stats.spellPower = stats.spellPower + sharedPower
            else
                stats.healingPower = stats.healingPower + (healingPower or 0)
                stats.spellPower = stats.spellPower + (spellPower or 0)
            end

            local armor = string.match(string.lower(text), "^%s*(%d+)%s+armor")
                or string.match(string.lower(text), "armor%s*:?[ ]*(%d+)")
            if armor then stats.armor = stats.armor + (tonumber(armor) or 0) end

            local itemDPS = readWeaponDPS(text)
            if itemDPS then stats.weaponDPS = itemDPS end
            local lowerText = string.lower(text)
            if string.find(lowerText, "damage", 1, true) then
                local low, high = string.match(lowerText, "([%d%.]+)%s*%-%s*([%d%.]+)")
                if low and high then
                    stats.damageMin = tonumber(low)
                    stats.damageMax = tonumber(high)
                end
            end
            if string.find(lowerText, "speed", 1, true) then
                local speed = string.match(lowerText, "speed%s*:?[ ]*([%d%.]+)")
                if speed then stats.weaponSpeed = tonumber(speed) end
            end
        end
    end
    if not stats.weaponDPS and stats.damageMin and stats.damageMax and stats.weaponSpeed and stats.weaponSpeed > 0 then
        stats.weaponDPS = ((stats.damageMin + stats.damageMax) / 2) / stats.weaponSpeed
    end
    return stats
end

local function getItemScore(stats, classToken, weights)
    weights = weights or select(1, getPlayerScoringProfile(classToken))
    if not weights then return nil end
    return stats.strength * weights.strength
        + stats.agility * weights.agility
        + stats.stamina * weights.stamina
        + stats.intellect * weights.intellect
        + stats.spirit * weights.spirit
        + stats.attackPower * weights.attackPower
        + stats.rangedAttackPower * weights.rangedAttackPower
        + stats.armor * weights.armor
        + (stats.weaponDPS or 0) * weights.weaponDPS
        + (stats.spellPower or 0) * weights.spellPower
        + (stats.healingPower or 0) * weights.healingPower
end

local function getItemDetails(itemLink)
    if not itemLink then return nil, nil, nil end
    local getInfo = C_Item and C_Item.GetItemInfo or GetItemInfo
    if not getInfo then return nil, nil, nil end

    -- GetItemInfo returns equip location in slot 9, after item subtype and stack size.
    local ok, _, _, _, _, _, itemType, itemSubType, _, equipLocation = pcall(getInfo, itemLink)
    if ok then return equipLocation, itemType, itemSubType end
    return nil, nil, nil
end

local function getTooltipItemLink(tooltip)
    if not tooltip or not tooltip.GetItem then return nil end
    local _, itemLink = tooltip:GetItem()
    return itemLink
end

local function getItemEquipLocation(tooltip)
    return getItemDetails(getTooltipItemLink(tooltip))
end

local function getClassEquipRestriction(itemLink, classToken)
    local _, itemType, itemSubType = getItemDetails(itemLink)
    if not itemType or string.lower(itemType) ~= "armor" or not itemSubType then return nil end

    local armorType = string.lower(itemSubType)
    local level = UnitLevel and (tonumber(UnitLevel("player")) or 1) or 1
    local cannotWear = false
    if armorType == "leather" then
        cannotWear = classToken == "PRIEST" or classToken == "MAGE" or classToken == "WARLOCK"
    elseif armorType == "mail" then
        cannotWear = classToken == "PRIEST" or classToken == "MAGE" or classToken == "WARLOCK"
            or classToken == "ROGUE" or classToken == "DRUID"
            or ((classToken == "HUNTER" or classToken == "SHAMAN") and level < 40)
    elseif armorType == "plate" then
        cannotWear = (classToken ~= "WARRIOR" and classToken ~= "PALADIN") or level < 40
    end

    if cannotWear then
        local displayClass = CLASS_DISPLAY_NAMES[classToken] or "this class"
        return displayClass .. " cannot equip " .. itemSubType .. " armor"
    end
    return nil
end

local function isRangedEquipLocation(location)
    return location == "INVTYPE_RANGED"
        or location == "INVTYPE_RANGEDRIGHT"
        or location == "INVTYPE_THROWN"
end

local function weaponStatDPS(stats, classToken, equipLocation)
    if not stats.weaponDPS then return nil end
    local meleeAP, rangedAP = getStatGains(stats, classToken)
    local ranged = isRangedEquipLocation(equipLocation)
    local itemAP = ranged and rangedAP or meleeAP
    local critPerPercent = getAgilityCritPerPercent(classToken, UnitLevel("player"))
    local critDelta = (critPerPercent and critPerPercent > 0)
        and (stats.agility / critPerPercent / 100) or 0
    local offhand = equipLocation == "INVTYPE_WEAPONOFFHAND"
    local handFactor = offhand and 0.5 or 1
    -- Return only the DPS supplied by this item's offensive stats. The game's
    -- normal tooltip already displays the weapon's base DPS.
    return (itemAP / 14 + stats.weaponDPS * critDelta) * handFactor
end

local function currentMeleeWeaponDPS()
    if not UnitDamage or not UnitAttackSpeed then return nil end
    local ok, value = pcall(function()
        local minimum, maximum = UnitDamage("player")
        local speed = UnitAttackSpeed("player")
        if minimum and maximum and speed and speed > 0 then
            return ((minimum + maximum) / 2) / speed
        end
    end)
    if ok then return value end
    return nil
end

local function currentRangedWeaponDPS()
    if not UnitRangedDamage or not UnitRangedAttackSpeed then return nil end
    local ok, value = pcall(function()
        local minimum, maximum = UnitRangedDamage("player")
        local speed = UnitRangedAttackSpeed("player")
        if minimum and maximum and speed and speed > 0 then
            return ((minimum + maximum) / 2) / speed
        end
    end)
    if ok then return value end
    return nil
end

local function appendGearDPSComparison(lines, candidateStats, classToken)
    if not IsShiftKeyDown or not IsShiftKeyDown() then return end
    if not ShoppingTooltip1 or not ShoppingTooltip1:IsShown() then return end

    local comparisonStats = getTooltipStats(ShoppingTooltip1)
    local restriction = getClassEquipRestriction(getTooltipItemLink(GameTooltip), classToken)
    if restriction then
        table.insert(lines, "Stat Gains: " .. restriction)
        return
    end
    local weights = select(1, getPlayerScoringProfile(classToken))
    local candidateScore = getItemScore(candidateStats, classToken, weights)
    local equippedScore = getItemScore(comparisonStats, classToken, weights)
    if candidateScore and equippedScore then
        local scoreChange = candidateScore - equippedScore
        if math.abs(scoreChange) >= 0.005 then
            if equippedScore > 0 then
                local scorePercent = (scoreChange / equippedScore) * 100
                table.insert(lines, "Stat Gains score change: " .. signedNumber(scoreChange)
                    .. " (" .. formatPercent(scorePercent) .. ") vs equipped")
            else
                table.insert(lines, "Stat Gains score change: " .. signedNumber(scoreChange)
                    .. " (no positive baseline) vs equipped")
            end
        end
    end
    local delta = {
        strength = candidateStats.strength - comparisonStats.strength,
        agility = candidateStats.agility - comparisonStats.agility,
        attackPower = candidateStats.attackPower - comparisonStats.attackPower,
        rangedAttackPower = candidateStats.rangedAttackPower - comparisonStats.rangedAttackPower,
    }
    local meleeAP, rangedAP = getStatGains(delta, classToken)
    local critPerPercent = getAgilityCritPerPercent(classToken, UnitLevel("player"))
    local critDelta = (critPerPercent and critPerPercent > 0) and (delta.agility / critPerPercent / 100) or 0
    local equipLocation = getItemEquipLocation(GameTooltip)
    local rangedItem = isRangedEquipLocation(equipLocation)
    local equippedTooltip = ShoppingTooltip1
    local comparisonLocation = getItemEquipLocation(equippedTooltip)
    local sameWeaponType = candidateStats.weaponDPS and comparisonStats.weaponDPS
    local weaponBaseDelta = sameWeaponType and (candidateStats.weaponDPS - comparisonStats.weaponDPS) or 0

    local meleeDelta = meleeAP / 14
    local meleeDPS = currentMeleeWeaponDPS()
    if meleeDPS then meleeDelta = meleeDelta + meleeDPS * critDelta end
    if sameWeaponType and not isRangedEquipLocation(equipLocation)
        and not isRangedEquipLocation(comparisonLocation) then
        local handFactor = equipLocation == "INVTYPE_WEAPONOFFHAND" and 0.5 or 1
        meleeDelta = meleeDelta + weaponBaseDelta * handFactor
    end
    if math.abs(meleeDelta) >= 0.005 then
        table.insert(lines, "Estimated melee auto-attack DPS change: " .. signedNumber(meleeDelta) .. " vs equipped")
    end

    local rangedDPS = currentRangedWeaponDPS()
    if rangedItem or rangedAP ~= 0 or (critDelta ~= 0 and rangedDPS) then
        local rangedDelta = rangedAP / 14
        if rangedDPS then rangedDelta = rangedDelta + rangedDPS * critDelta end
        if sameWeaponType and isRangedEquipLocation(comparisonLocation) then
            rangedDelta = rangedDelta + weaponBaseDelta
        end
        if math.abs(rangedDelta) >= 0.005 then
            table.insert(lines, "Estimated ranged auto-attack DPS change: " .. signedNumber(rangedDelta) .. " vs equipped")
        end
    end
end

local comparisonFrame
local comparisonRows = {}
local activeInspectButton
local lastComparisonData
local refreshStatGainsScore
local showComparisonScreen

local function comparisonItemData(tooltip)
    local itemName, itemLink
    if tooltip and tooltip.GetItem then
        itemName, itemLink = tooltip:GetItem()
    end
    if (not itemName or itemName == "") and tooltip and tooltip.GetName then
        local name = tooltip:GetName()
        local firstLine = name and _G[name .. "TextLeft1"]
        itemName = firstLine and firstLine:GetText()
        if not isUsableTooltipText(itemName) then itemName = nil end
        if itemName then
            itemName = string.gsub(itemName, "|c%x%x%x%x%x%x%x%x", "")
            itemName = string.gsub(itemName, "|r", "")
            itemName = string.gsub(itemName, "|H.-|h(.-)|h", "%1")
            itemName = string.gsub(itemName, "^%s+", "")
        end
    end
    if not itemName or itemName == "" then itemName = "Item unavailable" end
    return itemName, itemLink
end

local function findEquippedItemLink(itemName)
    if not itemName or not GetInventoryItemLink then return nil end
    for slot = 1, 19 do
        local link = GetInventoryItemLink("player", slot)
        if link then
            local linkedName = GetItemInfo and GetItemInfo(link)
            if linkedName == itemName then return link end
            if not linkedName then
                linkedName = string.match(link, "%[(.-)%]")
                if linkedName == itemName then return link end
            end
        end
    end
    return nil
end

local function hideInspectionTooltip()
    if activeInspectButton and GameTooltip then
        GameTooltip:Hide()
        activeInspectButton = nil
    end
end

local function inspectButtonClick(button)
    if not button.itemLink or not GameTooltip or not GameTooltip.SetHyperlink then return end
    if activeInspectButton == button and GameTooltip:IsShown() then
        hideInspectionTooltip()
        return
    end
    activeInspectButton = button
    GameTooltip:SetOwner(button, "ANCHOR_RIGHT")
    GameTooltip:SetHyperlink(button.itemLink)
    GameTooltip:Show()
end

local function getPawnItemScores(itemLink)
    local scales = PawnCommon and PawnCommon.Scales
    if not itemLink or type(PawnGetItemData) ~= "function"
        or type(PawnGetSingleValueFromItem) ~= "function"
        or type(PawnIsScaleVisible) ~= "function"
        or type(scales) ~= "table" then
        return nil
    end

    local itemOk, itemData = pcall(PawnGetItemData, itemLink)
    if not itemOk or not itemData then return nil end

    local scores = {}
    for scaleName in pairs(scales) do
        local visibleOk, isVisible = pcall(PawnIsScaleVisible, scaleName)
        if visibleOk and isVisible then
            local scoreOk, score = pcall(PawnGetSingleValueFromItem, itemData, scaleName)
            score = scoreOk and tonumber(score) or nil
            if score ~= nil then
                scores[scaleName] = score
            end
        end
    end
    return scores
end

local function choosePawnScale(candidateScores)
    -- Pawn's current UI scale is the user's active choice. Prefer it over
    -- choosing whichever visible scale happens to assign the largest number.
    local selectedScale = type(PawnUICurrentScale) == "string" and PawnUICurrentScale or nil
    if selectedScale and candidateScores and candidateScores[selectedScale] ~= nil then
        return selectedScale, candidateScores[selectedScale]
    end

    -- Some Pawn builds do not expose a current selection until its UI opens.
    -- In that case retain the previous visible-scale fallback.
    local bestName, bestScore
    for scaleName, score in pairs(candidateScores or {}) do
        if bestScore == nil or score > bestScore
            or (score == bestScore and tostring(scaleName) < tostring(bestName)) then
            bestName, bestScore = scaleName, score
        end
    end
    return bestName, bestScore
end

local function formatPawnScore(score)
    local digits = PawnCommon and tonumber(PawnCommon.Digits) or 1
    digits = math.max(0, math.min(3, math.floor(digits)))
    return string.format("%." .. digits .. "f", score)
end

local function makeComparisonValues(stats, classToken, raceToken, equipLocation)
    local meleeAP, rangedAP = getStatGains(stats, classToken)
    local healthPerStamina = (raceToken == "Tauren") and 10.5 or 10
    local regenPerFive = spiritManaPerFive(classToken) or 0
    local critPerPercent = getAgilityCritPerPercent(classToken, UnitLevel("player"))
    local crit = (critPerPercent and critPerPercent > 0)
        and (stats.agility / critPerPercent) or 0
    return {
        { label = "Strength", value = stats.strength },
        { label = "Agility", value = stats.agility },
        { label = "Stamina", value = stats.stamina },
        { label = "Intellect", value = stats.intellect },
        { label = "Spirit", value = stats.spirit },
        { label = "Spell power (damage + healing)", value = stats.spellPower or 0 },
        { label = "Healing power", value = stats.healingPower or 0 },
        { label = "Melee AP from item", value = meleeAP },
        { label = "Ranged AP from item", value = rangedAP },
        { label = "Armor incl. Agility", value = stats.armor + stats.agility * 2 },
        { label = "Health from Stamina", value = stats.stamina * healthPerStamina },
        { label = "Mana from Intellect", value = classToken == "WARRIOR" and 0 or stats.intellect * 15 },
        { label = "Spirit regen / 5 sec", value = stats.spirit * regenPerFive },
        { label = "Meditation MP5 (casting)", value = stats.spirit * regenPerFive * meditationFraction(classToken) },
        { label = "Crit from Agility", value = crit, suffix = "%", precision = 3 },
        { label = "Weapon DPS", value = stats.weaponDPS or 0, precision = 2 },
        { label = "DPS from weapon stats", value = weaponStatDPS(stats, classToken, equipLocation) or 0, precision = 2 },
    }
end

local function comparisonCell(value, precision, signed)
    value = tonumber(value) or 0
    local result
    if precision == 2 then
        result = string.format(signed and "%+.2f" or "%.2f", value)
    elseif precision == 3 then
        result = string.format(signed and "%+.3f" or "%.3f", value):gsub("0+$", ""):gsub("%.$", "")
    else
        result = signed and signedNumber(value) or formatNumber(value)
    end
    return result
end

local function createComparisonFrame()
    if comparisonFrame then return comparisonFrame end

    local panel = CreateFrame("Frame", "StatGainsComparisonFrame", UIParent)
    panel:SetWidth(700)
    panel:SetHeight(530)
    panel:SetPoint("CENTER", UIParent, "CENTER", 0, 0)
    panel:SetFrameStrata("DIALOG")
    panel:SetToplevel(true)
    panel:EnableMouse(true)
    panel:SetMovable(true)
    panel:RegisterForDrag("LeftButton")
    panel:SetScript("OnDragStart", function(self) self:StartMoving() end)
    panel:SetScript("OnDragStop", function(self) self:StopMovingOrSizing() end)

    -- Use plain textures instead of SetBackdrop, which is absent on some
    -- WoW Forever clients unless a special backdrop template is requested.
    local background = panel:CreateTexture(nil, "BACKGROUND")
    background:SetTexture("Interface\\Buttons\\WHITE8X8")
    background:SetVertexColor(0.025, 0.025, 0.025, 0.97)
    background:SetAllPoints(panel)

    local function addBorder(point, x, y, width, height)
        local border = panel:CreateTexture(nil, "BORDER")
        border:SetTexture("Interface\\Buttons\\WHITE8X8")
        border:SetVertexColor(0.68, 0.54, 0.20, 0.95)
        border:SetPoint(point, panel, point, x, y)
        border:SetWidth(width)
        border:SetHeight(height)
        return border
    end
    addBorder("TOPLEFT", 10, -10, 680, 2)
    addBorder("BOTTOMLEFT", 10, 10, 680, 2)
    addBorder("TOPLEFT", 10, -10, 2, 510)
    addBorder("TOPRIGHT", -10, -10, 2, 510)

    local title = panel:CreateFontString(nil, "OVERLAY", "GameFontNormalLarge")
    title:SetPoint("TOP", panel, "TOP", 0, -17)
    title:SetText("Stat Gains Item Comparison")
    panel.title = title

    local profileLabel = panel:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
    profileLabel:SetPoint("TOPLEFT", panel, "TOPLEFT", 24, -38)
    profileLabel:SetText("Class / spec:")
    panel.focusSummary = panel:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
    panel.focusSummary:SetPoint("TOP", panel, "TOP", 0, -57)
    panel.focusSummary:SetWidth(650)
    panel.focusSummary:SetJustifyH("CENTER")

    local function createDropdownButton(x, width)
        local button = CreateFrame("Button", nil, panel)
        button:SetWidth(width)
        button:SetHeight(20)
        button:SetPoint("TOPLEFT", panel, "TOPLEFT", x, -35)
        button.label = button:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
        button.label:SetAllPoints(button)
        button.label:SetJustifyH("CENTER")
        button:SetHighlightTexture("Interface\\QuestFrame\\UI-QuestTitleHighlight")
        return button
    end

    local function createOptionMenu(width)
        local menu = CreateFrame("Frame", nil, panel)
        menu:SetWidth(width)
        menu:SetHeight(40)
        menu:SetFrameStrata("TOOLTIP")
        menu:SetFrameLevel(panel:GetFrameLevel() + 10)
        menu:EnableMouse(true)
        local bg = menu:CreateTexture(nil, "BACKGROUND")
        bg:SetTexture("Interface\\Buttons\\WHITE8X8")
        bg:SetVertexColor(0.015, 0.015, 0.015, 0.98)
        bg:SetAllPoints(menu)
        menu.optionButtons = {}
        menu:Hide()
        return menu
    end

    local function populateOptionMenu(menu, choices, onSelect)
        menu:SetHeight(math.max(24, #choices * 20 + 4))
        for index, choice in ipairs(choices) do
            local button = menu.optionButtons[index]
            if not button then
                button = CreateFrame("Button", nil, menu)
                button:SetHeight(20)
                button.label = button:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
                button.label:SetAllPoints(button)
                button.label:SetJustifyH("LEFT")
                button:SetHighlightTexture("Interface\\QuestFrame\\UI-QuestTitleHighlight")
                menu.optionButtons[index] = button
            end
            button:SetPoint("TOPLEFT", menu, "TOPLEFT", 4, -2 - ((index - 1) * 20))
            button:SetPoint("TOPRIGHT", menu, "TOPRIGHT", -4, -2 - ((index - 1) * 20))
            button.label:SetText(choice.label)
            local selectedChoice = choice
            button:SetScript("OnClick", function()
                menu:Hide()
                onSelect(selectedChoice)
            end)
            button:Show()
        end
        for index = #choices + 1, #menu.optionButtons do
            menu.optionButtons[index]:Hide()
        end
    end

    panel.classDropButton = createDropdownButton(118, 175)
    panel.specDropButton = createDropdownButton(398, 205)
    panel.classMenu = createOptionMenu(175)
    panel.classMenu:SetPoint("TOPLEFT", panel.classDropButton, "BOTTOMLEFT", 0, 0)
    panel.specMenu = createOptionMenu(205)
    panel.specMenu:SetPoint("TOPLEFT", panel.specDropButton, "BOTTOMLEFT", 0, 0)

    local function refreshProfileControls()
        if type(StatGainsDB) ~= "table" then StatGainsDB = {} end
        local playerName, playerClass = UnitClass("player")
        local classChoice = StatGainsDB.scoreClass or "AUTO"
        local scoringClass = classChoice == "AUTO" and playerClass or classChoice
        if not CLASS_DISPLAY_NAMES[scoringClass] then scoringClass = playerClass end
        local classLabel = classChoice == "AUTO" and ("Player: " .. (playerName or "Current"))
            or (CLASS_DISPLAY_NAMES[classChoice] or classChoice)
        panel.classDropButton.label:SetText("Class: " .. classLabel .. " \226\150\188")

        local selectedSpec = StatGainsDB.scoreSpec or "AUTO"
        local specLabel = selectedSpec == "AUTO" and "Auto / default" or selectedSpec
        panel.specDropButton.label:SetText("Spec: " .. specLabel .. " \226\150\188")

        local classChoices = { { key = "AUTO", label = "Player (current class)" } }
        for _, token in ipairs({ "WARRIOR", "PALADIN", "HUNTER", "ROGUE", "PRIEST", "SHAMAN", "MAGE", "WARLOCK", "DRUID" }) do
            table.insert(classChoices, { key = token, label = CLASS_DISPLAY_NAMES[token] })
        end
        populateOptionMenu(panel.classMenu, classChoices, function(choice)
            StatGainsDB.scoreClass = choice.key
            StatGainsDB.scoreSpec = "AUTO"
            refreshProfileControls()
            if lastComparisonData and refreshStatGainsScore then
                refreshStatGainsScore(panel, lastComparisonData)
            end
        end)

        local specChoices = { { key = "AUTO", label = "Auto-detect / class default" } }
        for _, spec in ipairs(CLASS_SPEC_OPTIONS[scoringClass] or {}) do
            table.insert(specChoices, { key = spec, label = spec })
        end
        populateOptionMenu(panel.specMenu, specChoices, function(choice)
            StatGainsDB.scoreSpec = choice.key
            refreshProfileControls()
            if lastComparisonData and refreshStatGainsScore then
                refreshStatGainsScore(panel, lastComparisonData)
            end
        end)
    end
    panel.refreshProfileControls = refreshProfileControls

    panel.classDropButton:SetScript("OnClick", function()
        panel.specMenu:Hide()
        if panel.classMenu:IsShown() then panel.classMenu:Hide() else panel.classMenu:Show() end
    end)
    panel.specDropButton:SetScript("OnClick", function()
        panel.classMenu:Hide()
        if panel.specMenu:IsShown() then panel.specMenu:Hide() else panel.specMenu:Show() end
    end)
    refreshProfileControls()

    local close = CreateFrame("Button", nil, panel)
    close:SetWidth(22)
    close:SetHeight(22)
    close:SetPoint("TOPRIGHT", panel, "TOPRIGHT", -12, -11)
    close:SetNormalTexture("Interface\\Buttons\\UI-Panel-MinimizeButton-Up")
    close:SetPushedTexture("Interface\\Buttons\\UI-Panel-MinimizeButton-Down")
    close:SetHighlightTexture("Interface\\Buttons\\UI-Panel-MinimizeButton-Highlight")
    close:SetScript("OnClick", function()
        hideInspectionTooltip()
        panel:Hide()
    end)

    panel.equippedName = panel:CreateFontString(nil, "OVERLAY", "GameFontNormal")
    panel.equippedName:SetPoint("TOPLEFT", panel, "TOPLEFT", 24, -74)
    panel.equippedName:SetWidth(315)
    panel.equippedName:SetJustifyH("LEFT")
    panel.candidateName = panel:CreateFontString(nil, "OVERLAY", "GameFontNormal")
    panel.candidateName:SetPoint("TOPLEFT", panel, "TOPLEFT", 355, -74)
    panel.candidateName:SetWidth(315)
    panel.candidateName:SetJustifyH("LEFT")

    panel.equippedInspectButton = CreateFrame("Button", nil, panel)
    panel.equippedInspectButton:SetPoint("TOPLEFT", panel, "TOPLEFT", 24, -72)
    panel.equippedInspectButton:SetWidth(315)
    panel.equippedInspectButton:SetHeight(26)
    panel.equippedInspectButton:SetHighlightTexture("Interface\\QuestFrame\\UI-QuestTitleHighlight")
    panel.equippedInspectButton:SetScript("OnClick", function(self) inspectButtonClick(self) end)

    panel.candidateInspectButton = CreateFrame("Button", nil, panel)
    panel.candidateInspectButton:SetPoint("TOPLEFT", panel, "TOPLEFT", 355, -72)
    panel.candidateInspectButton:SetWidth(315)
    panel.candidateInspectButton:SetHeight(26)
    panel.candidateInspectButton:SetHighlightTexture("Interface\\QuestFrame\\UI-QuestTitleHighlight")
    panel.candidateInspectButton:SetScript("OnClick", function(self) inspectButtonClick(self) end)

    panel.dpsSummary = panel:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
    panel.dpsSummary:SetPoint("TOP", panel, "TOP", 0, -98)
    panel.dpsSummary:SetWidth(650)
    panel.dpsSummary:SetJustifyH("CENTER")
    panel.statScoreTitle = panel:CreateFontString(nil, "OVERLAY", "GameFontNormal")
    panel.statScoreTitle:SetPoint("BOTTOMLEFT", panel, "BOTTOMLEFT", 24, 88)
    panel.statScoreTitle:SetWidth(315)
    panel.statScoreTitle:SetText("Stat Gains")
    panel.statScoreFooter = panel:CreateFontString(nil, "OVERLAY", "GameFontNormal")
    panel.statScoreFooter:SetPoint("BOTTOMLEFT", panel, "BOTTOMLEFT", 24, 64)
    panel.statScoreFooter:SetWidth(315)
    panel.statScoreFooter:SetJustifyH("CENTER")
    panel.statBetterFooter = panel:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
    panel.statBetterFooter:SetPoint("BOTTOMLEFT", panel, "BOTTOMLEFT", 24, 40)
    panel.statBetterFooter:SetWidth(315)

    panel.pawnScoreTitle = panel:CreateFontString(nil, "OVERLAY", "GameFontNormal")
    panel.pawnScoreTitle:SetPoint("BOTTOMLEFT", panel, "BOTTOMLEFT", 355, 88)
    panel.pawnScoreTitle:SetWidth(315)
    panel.pawnScoreFooter = panel:CreateFontString(nil, "OVERLAY", "GameFontNormal")
    panel.pawnScoreFooter:SetPoint("BOTTOMLEFT", panel, "BOTTOMLEFT", 355, 64)
    panel.pawnScoreFooter:SetWidth(315)
    panel.pawnScoreFooter:SetJustifyH("CENTER")
    panel.pawnBetterFooter = panel:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
    panel.pawnBetterFooter:SetPoint("BOTTOMLEFT", panel, "BOTTOMLEFT", 355, 40)
    panel.pawnBetterFooter:SetWidth(315)
    panel.versionFooter = panel:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
    panel.versionFooter:SetPoint("BOTTOMLEFT", panel, "BOTTOMLEFT", 23, 14)
    panel.versionFooter:SetText("Stat Gains v" .. ADDON_VERSION)
    panel.versionFooter:SetTextColor(0.72, 0.72, 0.72)

    local meditationCheck = CreateFrame("CheckButton", nil, panel, "UICheckButtonTemplate")
    meditationCheck:SetSize(22, 22)
    meditationCheck:SetPoint("BOTTOM", panel, "BOTTOM", -77, 7)
    local meditationLabel = meditationCheck:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
    meditationLabel:SetPoint("LEFT", meditationCheck, "RIGHT", 2, 0)
    meditationLabel:SetText("Account for Meditation")
    local function syncMeditationCheck()
        local _, playerClass = UnitClass("player")
        meditationCheck:SetShown(playerClass == "PRIEST")
        meditationCheck:SetChecked(StatGainsDB and StatGainsDB.meditation == true)
    end
    meditationCheck:SetScript("OnClick", function(self)
        StatGainsDB = StatGainsDB or {}
        StatGainsDB.meditation = not not self:GetChecked()
        if lastComparisonData and refreshStatGainsScore then
            refreshStatGainsScore(panel, lastComparisonData)
        end
    end)
    panel:HookScript("OnShow", syncMeditationCheck)
    syncMeditationCheck()

    local procCheck = CreateFrame("CheckButton", nil, panel, "UICheckButtonTemplate")
    procCheck:SetSize(22, 22)
    procCheck:SetPoint("BOTTOMLEFT", panel, "BOTTOMLEFT", 474, 7)
    local procLabel = procCheck:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
    procLabel:SetPoint("LEFT", procCheck, "RIGHT", 2, 0)
    procLabel:SetText("Show Proc Chance")
    local function syncProcCheck()
        procCheck:SetChecked(StatGainsDB and StatGainsDB.showProcChance ~= false)
    end
    procCheck:SetScript("OnClick", function(self)
        StatGainsDB = StatGainsDB or {}
        StatGainsDB.showProcChance = not not self:GetChecked()
    end)
    panel:HookScript("OnShow", syncProcCheck)
    syncProcCheck()

    local headers = {
        { text = "Stat / Estimate", x = 24, width = 190, justify = "LEFT" },
        { text = "Equipped", x = 223, width = 130, justify = "CENTER" },
        { text = "Candidate", x = 376, width = 130, justify = "CENTER" },
        { text = "Change", x = 527, width = 145, justify = "CENTER" },
    }
    for _, headerInfo in ipairs(headers) do
        local header = panel:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
        header:SetPoint("TOPLEFT", panel, "TOPLEFT", headerInfo.x, -123)
        header:SetWidth(headerInfo.width)
        header:SetJustifyH(headerInfo.justify)
        header:SetText(headerInfo.text)
    end

    local divider = panel:CreateTexture(nil, "ARTWORK")
    divider:SetTexture("Interface\\Buttons\\WHITE8X8")
    divider:SetVertexColor(0.65, 0.55, 0.25, 0.8)
    divider:SetHeight(1)
    divider:SetPoint("TOPLEFT", panel, "TOPLEFT", 20, -143)
    divider:SetPoint("TOPRIGHT", panel, "TOPRIGHT", -20, -143)

    for row = 1, 18 do
        local y = -151 - ((row - 1) * 16)
        local label = panel:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
        label:SetPoint("TOPLEFT", panel, "TOPLEFT", 24, y)
        label:SetWidth(190)
        label:SetJustifyH("LEFT")

        local equipped = panel:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
        equipped:SetPoint("TOPLEFT", panel, "TOPLEFT", 223, y)
        equipped:SetWidth(130)
        equipped:SetJustifyH("CENTER")

        local candidate = panel:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
        candidate:SetPoint("TOPLEFT", panel, "TOPLEFT", 376, y)
        candidate:SetWidth(130)
        candidate:SetJustifyH("CENTER")

        local change = panel:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
        change:SetPoint("TOPLEFT", panel, "TOPLEFT", 527, y)
        change:SetWidth(145)
        change:SetJustifyH("CENTER")

        comparisonRows[row] = { label = label, equipped = equipped, candidate = candidate, change = change }
    end

    comparisonFrame = panel
    return panel
end

refreshStatGainsScore = function(panel, data)
    local weights, profile, specName, focusLabel, scoringClass = getPlayerScoringProfile(data.classToken)
    panel.focusSummary:SetText(focusLabel)
    if panel.refreshProfileControls then panel.refreshProfileControls() end

    local candidateRestriction = getClassEquipRestriction(data.candidateLink, scoringClass)
    data.activeCandidateRestriction = candidateRestriction
    local displayEstimate = data.autoAttackEstimateRaw or data.autoAttackEstimate
    if candidateRestriction then
        panel.dpsSummary:SetText("DPS estimate skipped — " .. candidateRestriction)
    elseif displayEstimate then
        if profile == "HEALER" or profile == "CASTER_DPS" then
            panel.dpsSummary:SetText("Auto-attack only; excluded from " .. profile:gsub("_", " "):lower() .. " score — " .. displayEstimate)
        else
            panel.dpsSummary:SetText(displayEstimate)
        end
    end

    local equippedScore = getItemScore(data.equippedStats, scoringClass, weights) or 0
    local candidateScore = candidateRestriction and 0
        or (getItemScore(data.candidateStats, scoringClass, weights) or 0)
    local scoreChange = candidateScore - equippedScore
    if candidateRestriction then
        panel.statScoreTitle:SetText("Stat Gains — not equippable")
        panel.statScoreFooter:SetText("N/A (C) — no upgrade score")
        panel.statScoreFooter:SetTextColor(0.9, 0.9, 0.9)
        panel.statBetterFooter:SetText(candidateRestriction)
        panel.statBetterFooter:SetTextColor(1.0, 0.65, 0.35)
    else
        local displaySpec = specName and (" / " .. specName) or ""
        panel.statScoreTitle:SetText("Stat Gains — " .. (CLASS_DISPLAY_NAMES[scoringClass] or "Class") .. displaySpec)
        if data.equippedAvailable and equippedScore > 0 then
            panel.statScoreFooter:SetText(formatNumber(equippedScore) .. " E | "
                .. formatNumber(candidateScore) .. " C | " .. signedNumber(scoreChange)
                .. " (" .. string.format("%+.1f%%", scoreChange / equippedScore * 100) .. ")")
        else
            panel.statScoreFooter:SetText(formatNumber(equippedScore) .. " E | "
                .. formatNumber(candidateScore) .. " C | " .. signedNumber(scoreChange))
        end
        if scoreChange >= 0 then
            panel.statScoreFooter:SetTextColor(0.35, 1.0, 0.35)
        else
            panel.statScoreFooter:SetTextColor(1.0, 0.38, 0.38)
        end
        if data.equippedAvailable and scoreChange > 0 then
            panel.statBetterFooter:SetText("Higher score: " .. data.candidateName .. " (C) — " .. formatNumber(candidateScore))
            panel.statBetterFooter:SetTextColor(0.35, 1.0, 0.35)
        elseif data.equippedAvailable and scoreChange < 0 then
            panel.statBetterFooter:SetText("Higher score: " .. data.equippedName .. " (E) — " .. formatNumber(equippedScore))
            panel.statBetterFooter:SetTextColor(0.35, 1.0, 0.35)
        elseif data.equippedAvailable then
            panel.statBetterFooter:SetText("Scores are tied: " .. formatNumber(equippedScore))
            panel.statBetterFooter:SetTextColor(0.9, 0.9, 0.9)
        else
            panel.statBetterFooter:SetText("Equipped comparison is unavailable")
            panel.statBetterFooter:SetTextColor(0.9, 0.9, 0.9)
        end
    end

    -- Class changes also update class-derived rows such as AP, Spirit regen,
    -- and Agility crit, so the comparison stays consistent with the score.
    if data.raceToken then
        local equippedValues = makeComparisonValues(data.equippedStats, scoringClass, data.raceToken, data.equippedLocation)
        local candidateValues = makeComparisonValues(data.candidateStats, scoringClass, data.raceToken, data.candidateLocation)
        local visibleRows = 0
        for i, row in ipairs(candidateValues) do
            local equippedValue = equippedValues[i] and equippedValues[i].value or 0
            local candidateValue = row.value or 0
            local delta = candidateValue - equippedValue
            if math.abs(equippedValue) > 0.0001 or math.abs(candidateValue) > 0.0001 then
                visibleRows = visibleRows + 1
                local ui = comparisonRows[visibleRows]
                local suffix = row.suffix or ""
                ui.label:SetText(row.label)
                ui.equipped:SetText(comparisonCell(equippedValue, row.precision, false) .. suffix)
                ui.candidate:SetText(comparisonCell(candidateValue, row.precision, false) .. suffix)
                ui.change:SetText(comparisonCell(delta, row.precision, true) .. suffix)
                if delta > 0 then
                    ui.change:SetTextColor(0.35, 1.0, 0.35)
                elseif delta < 0 then
                    ui.change:SetTextColor(1.0, 0.38, 0.38)
                else
                    ui.change:SetTextColor(0.9, 0.9, 0.9)
                end
                for _, cell in ipairs({ ui.label, ui.equipped, ui.candidate, ui.change }) do cell:Show() end
            end
        end
        for i = visibleRows + 1, #comparisonRows do
            local ui = comparisonRows[i]
            for _, cell in ipairs({ ui.label, ui.equipped, ui.candidate, ui.change }) do cell:Hide() end
        end
    end
end

showComparisonScreen = function()
    if not comparisonEnabled("showComparisonPanel") then return end
    local candidateTooltip = GameTooltip
    if not candidateTooltip or not candidateTooltip:IsShown() then return end
    local candidateName, candidateLink = comparisonItemData(candidateTooltip)
    local candidateStats = getTooltipStats(candidateTooltip)
    local candidateLocation = getItemEquipLocation(candidateTooltip)

    local equippedTooltip = ShoppingTooltip1
    local equippedAvailable = equippedTooltip and equippedTooltip:IsShown()
    local equippedName, equippedLink
    if equippedAvailable then
        equippedName, equippedLink = comparisonItemData(equippedTooltip)
        if not equippedLink then equippedLink = findEquippedItemLink(equippedName) end
    else
        equippedName = "No equipped comparison found"
    end
    local equippedStats = equippedAvailable and getTooltipStats(equippedTooltip) or {
        strength = 0, agility = 0, stamina = 0, intellect = 0, spirit = 0,
        attackPower = 0, rangedAttackPower = 0, armor = 0, spellPower = 0, healingPower = 0,
    }
    local equippedLocation = equippedAvailable and getItemEquipLocation(equippedTooltip) or nil
    local _, classToken = UnitClass("player")
    local _, raceToken = UnitRace("player")

    local panel = createComparisonFrame()
    panel.equippedName:SetText("|cffffd100Equipped: " .. equippedName .. " (E)|r")
    panel.candidateName:SetText("|cff82c5ffCandidate: " .. candidateName .. " (C)|r")
    panel.equippedInspectButton.itemLink = equippedLink
    panel.candidateInspectButton.itemLink = candidateLink

    local candidateRestriction = getClassEquipRestriction(candidateLink, classToken)
    lastComparisonData = {
        candidateName = candidateName, candidateLink = candidateLink, candidateStats = candidateStats,
        candidateLocation = candidateLocation,
        equippedName = equippedName, equippedLink = equippedLink, equippedStats = equippedStats,
        equippedAvailable = equippedAvailable, equippedLocation = equippedLocation,
        classToken = classToken, raceToken = raceToken,
    }
    refreshStatGainsScore(panel, lastComparisonData)

    local candidatePawnScores = getPawnItemScores(candidateLink)
    local equippedPawnScores = equippedAvailable and getPawnItemScores(equippedLink) or nil
    local pawnScaleName = choosePawnScale(candidatePawnScores)
    local pawnCandidateScore = pawnScaleName and candidatePawnScores[pawnScaleName]
    local pawnEquippedScore = pawnScaleName and equippedPawnScores and equippedPawnScores[pawnScaleName]
    if pawnScaleName and pawnCandidateScore ~= nil then
        panel.pawnScoreTitle:SetText("Pawn — " .. pawnScaleName)
        if pawnEquippedScore ~= nil then
            local pawnChange = pawnCandidateScore - pawnEquippedScore
            local pawnChangeText = signedNumber(pawnChange)
            if pawnEquippedScore > 0 then
                pawnChangeText = pawnChangeText .. " (" .. string.format("%+.1f%%", pawnChange / pawnEquippedScore * 100) .. ")"
            end
            panel.pawnScoreFooter:SetText(formatPawnScore(pawnEquippedScore) .. " (E)  |  "
                .. formatPawnScore(pawnCandidateScore) .. " (C)  |  " .. pawnChangeText)
            if pawnChange >= 0 then
                panel.pawnScoreFooter:SetTextColor(0.35, 1.0, 0.35)
            else
                panel.pawnScoreFooter:SetTextColor(1.0, 0.38, 0.38)
            end
            if pawnChange > 0 then
                panel.pawnBetterFooter:SetText("Higher score: " .. candidateName .. " (C) — " .. formatPawnScore(pawnCandidateScore))
                panel.pawnBetterFooter:SetTextColor(0.35, 1.0, 0.35)
            elseif pawnChange < 0 then
                panel.pawnBetterFooter:SetText("Higher score: " .. equippedName .. " (E) — " .. formatPawnScore(pawnEquippedScore))
                panel.pawnBetterFooter:SetTextColor(0.35, 1.0, 0.35)
            else
                panel.pawnBetterFooter:SetText("Scores are tied: " .. formatPawnScore(pawnEquippedScore))
                panel.pawnBetterFooter:SetTextColor(0.9, 0.9, 0.9)
            end
        else
            panel.pawnScoreFooter:SetText(formatPawnScore(pawnCandidateScore) .. " (C); equipped score unavailable")
            panel.pawnScoreFooter:SetTextColor(0.9, 0.9, 0.9)
            panel.pawnBetterFooter:SetText("Could not read this scale for equipped gear")
            panel.pawnBetterFooter:SetTextColor(0.9, 0.9, 0.9)
        end
    else
        panel.pawnScoreTitle:SetText("Pawn score unavailable")
        panel.pawnScoreFooter:SetText("Enable a visible Pawn scale")
        panel.pawnScoreFooter:SetTextColor(0.9, 0.9, 0.9)
        panel.pawnBetterFooter:SetText("Pawn's scale is shown here when available")
        panel.pawnBetterFooter:SetTextColor(0.9, 0.9, 0.9)
    end

    local estimateLines = {}
    if equippedAvailable then
        appendGearDPSComparison(estimateLines, candidateStats, classToken)
    end
    local dpsEstimates = {}
    for _, line in ipairs(estimateLines) do
        if string.find(line, "Estimated ", 1, true) == 1 then
            table.insert(dpsEstimates, line)
        end
    end
    local dpsSummary
    if #dpsEstimates > 0 then
        dpsSummary = table.concat(dpsEstimates, "   |   ")
    elseif equippedAvailable then
        dpsSummary = "No estimated auto-attack DPS change detected"
    else
        dpsSummary = "Auto-attack DPS estimate unavailable without equipped comparison"
    end
    lastComparisonData.autoAttackEstimateRaw = dpsSummary
    panel.dpsSummary:SetText(dpsSummary)

    local _, _, _, _, scoringClass = getPlayerScoringProfile(classToken)
    local equippedValues = makeComparisonValues(equippedStats, scoringClass, raceToken, equippedLocation)
    local candidateValues = makeComparisonValues(candidateStats, scoringClass, raceToken, candidateLocation)
    local visibleRows = 0
    for i, row in ipairs(candidateValues) do
        local equippedValue = equippedValues[i] and equippedValues[i].value or 0
        local candidateValue = row.value or 0
        local delta = candidateValue - equippedValue
        if math.abs(equippedValue) > 0.0001 or math.abs(candidateValue) > 0.0001 then
            visibleRows = visibleRows + 1
            local ui = comparisonRows[visibleRows]
            local suffix = row.suffix or ""
            ui.label:SetText(row.label)
            ui.equipped:SetText(comparisonCell(equippedValue, row.precision, false) .. suffix)
            ui.candidate:SetText(comparisonCell(candidateValue, row.precision, false) .. suffix)
            ui.change:SetText(comparisonCell(delta, row.precision, true) .. suffix)
            if delta > 0 then
                ui.change:SetTextColor(0.35, 1.0, 0.35)
            elseif delta < 0 then
                ui.change:SetTextColor(1.0, 0.38, 0.38)
            else
                ui.change:SetTextColor(0.85, 0.85, 0.85)
            end
            ui.label:Show(); ui.equipped:Show(); ui.candidate:Show(); ui.change:Show()
        end
    end
    for i = visibleRows + 1, #comparisonRows do
        comparisonRows[i].label:Hide()
        comparisonRows[i].equipped:Hide()
        comparisonRows[i].candidate:Hide()
        comparisonRows[i].change:Hide()
    end
    refreshStatGainsScore(panel, lastComparisonData)

    panel:Show()
    if candidateTooltip.Hide then candidateTooltip:Hide() end
    if equippedAvailable and equippedTooltip.Hide then equippedTooltip:Hide() end
end

local function deriveStatAnnotation(text, classToken, raceToken)
    if not isUsableTooltipText(text) then return nil end
    text = text:gsub("\n|cff65b5ff%(Meditation:.-%)|r$", "")
    local function withMeditation(base)
        local plain = base:gsub("|c%x%x%x%x%x%x%x%x", ""):gsub("|r", "")
        local spirit = tonumber(plain:lower():match("^%s*([+-]?%d+)%s+spirit%s*%("))
        local fraction = meditationFraction(classToken)
        if spirit and spirit ~= 0 and fraction > 0 then
            return base .. "\n|cff65b5ff(Meditation: " .. signedNumber(spirit * 0.625 * fraction) .. " MP5 while casting)|r"
        end
        return base
    end
    if string.find(text, "(", 1, true) then return withMeditation(text) end
    local lowerText = string.lower(text)
    local bonuses = {}

    local stamina = tonumber(string.match(lowerText, "([+-]?%d+)%s+stamina"))
    if stamina and stamina ~= 0 then
        local healthPerStamina = (raceToken == "Tauren") and 10.5 or 10
        table.insert(bonuses, signedNumber(stamina * healthPerStamina) .. " HP")
    end

    local intellect = tonumber(string.match(lowerText, "([+-]?%d+)%s+intellect"))
    if intellect and intellect ~= 0 and classToken ~= "WARRIOR" then
        table.insert(bonuses, signedNumber(intellect * 15) .. " Mana")
    end

    local strength = tonumber(string.match(lowerText, "([+-]?%d+)%s+strength"))
    if strength and strength ~= 0 then
        local apPerStrength = CLASS_AP_PER_STRENGTH[classToken] or 1
        table.insert(bonuses, signedNumber(strength * apPerStrength) .. " melee AP")
    end

    local agility = tonumber(string.match(lowerText, "([+-]?%d+)%s+agility"))
    if agility and agility ~= 0 then
        table.insert(bonuses, signedNumber(agility * 2) .. " Armor")
        local critPerPercent = getAgilityCritPerPercent(classToken, UnitLevel("player"))
        if critPerPercent and critPerPercent > 0 then
            table.insert(bonuses, formatPercent(agility / critPerPercent) .. " crit")
        end
        local agilityStats = {
            strength = 0, agility = agility, attackPower = 0, rangedAttackPower = 0,
        }
        local meleeAP, rangedAP = getStatGains(agilityStats, classToken)
        if meleeAP ~= 0 then table.insert(bonuses, signedNumber(meleeAP) .. " melee AP") end
        if rangedAP ~= 0 then table.insert(bonuses, signedNumber(rangedAP) .. " ranged AP") end
    end

    local spirit = tonumber(string.match(lowerText, "([+-]?%d+)%s+spirit"))
    if spirit and spirit ~= 0 and classToken ~= "WARRIOR" then
        local regenPerFive = spiritManaPerFive(classToken)
        if regenPerFive then
            table.insert(bonuses, signedNumber(spirit * regenPerFive) .. " MP5 outside 5-sec rule")
        end
    end

    if #bonuses == 0 then return text end
    return withMeditation(text .. " (" .. table.concat(bonuses, ", ") .. ")")
end

local comparisonDerivedDisplayState = setmetatable({}, { __mode = "k" })
local pendingTooltipComparison = setmetatable({}, { __mode = "k" })

local function getTooltipComparisonItem(tooltip)
    if TooltipUtil and type(TooltipUtil.GetDisplayedItem) == "function" then
        local ok, itemData = pcall(TooltipUtil.GetDisplayedItem, tooltip)
        if ok and type(itemData) == "table" then return itemData end
    end
    if tooltip and tooltip.GetItem then
        local ok, _, itemLink = pcall(tooltip.GetItem, tooltip)
        if ok and itemLink then return { hyperlink = itemLink } end
    end
    return nil
end

local function comparisonItemKey(item)
    if type(item) ~= "table" then return nil end
    return item.guid or item.hyperlink or item.link or item.itemID or item.id
end

local function sameComparisonItem(left, right)
    if type(left) ~= "table" or type(right) ~= "table" then return false end
    local leftGuid = left.guid or left.itemGUID or left.itemGuid
    local rightGuid = right.guid or right.itemGUID or right.itemGuid
    if leftGuid and rightGuid and tostring(leftGuid) == tostring(rightGuid) then return true end

    local leftLink = left.hyperlink or left.link
    local rightLink = right.hyperlink or right.link
    if leftLink and rightLink then
        if tostring(leftLink) == tostring(rightLink) then return true end
        local leftID = tostring(leftLink):match("item:(%d+)")
        local rightID = tostring(rightLink):match("item:(%d+)")
        if leftID and rightID and leftID == rightID then return true end
    end

    local leftID = left.itemID or left.itemId or left.id
    local rightID = right.itemID or right.itemId or right.id
    if leftID and rightID and tostring(leftID) == tostring(rightID) then return true end
    if leftID and rightLink and tostring(leftID) == tostring(rightLink):match("item:(%d+)") then return true end
    if rightID and leftLink and tostring(rightID) == tostring(leftLink):match("item:(%d+)") then return true end
    return false
end

local function getComparisonDerivedLines(candidateItem, equippedItem)
    if not candidateItem or not equippedItem or not C_TooltipComparison
        or type(C_TooltipComparison.GetItemComparisonDelta) ~= "function" then return nil end

    local linesOK, deltaLines = pcall(C_TooltipComparison.GetItemComparisonDelta, candidateItem, equippedItem)
    if not linesOK or type(deltaLines) ~= "table" then return nil end

    local _, classToken = UnitClass("player")
    local _, raceToken = UnitRace("player")
    local derivedLines = {}
    for _, line in ipairs(deltaLines) do
        if isUsableTooltipText(line) then
            local plainText = line:gsub("|c%x%x%x%x%x%x%x%x", ""):gsub("|r", "")
            plainText = plainText:gsub("|H.-|h(.-)|h", "%1")
            local annotatedText = deriveStatAnnotation(plainText, classToken, raceToken)
            if annotatedText ~= plainText then
                local amount = tonumber(string.match(plainText, "([+-]?%d+)")) or 0
                table.insert(derivedLines, { text = annotatedText, amount = amount })
            end
        end
    end
    return derivedLines
end

local function appendComparisonRows(tooltip, derivedLines, heading, itemKey)
    if not tooltip or not tooltip.AddLine or not derivedLines or #derivedLines == 0 then return false end

    local signatureParts = { tostring(itemKey or "") , heading }
    for _, row in ipairs(derivedLines) do table.insert(signatureParts, row.text) end
    local signature = table.concat(signatureParts, "\n")
    local previous = comparisonDerivedDisplayState[tooltip]
    local lineCount = tooltip.NumLines and tooltip:NumLines() or 0
    if previous and previous.signature == signature and lineCount >= previous.endLine then return true end

    tooltip:AddLine(heading, 1.0, 0.82, 0.0, true)
    for _, row in ipairs(derivedLines) do
        if row.amount > 0 then
            tooltip:AddLine(row.text, 0.35, 1.0, 0.35, true)
        else
            tooltip:AddLine(row.text, 1.0, 0.38, 0.38, true)
        end
    end
    tooltip:Show()
    comparisonDerivedDisplayState[tooltip] = {
        signature = signature,
        endLine = tooltip.NumLines and tooltip:NumLines() or (lineCount + #derivedLines + 1),
    }
    return true
end

local function appendComparisonDerivedLines(tooltip, comparisonItem)
    if not comparisonEnabled("showTooltipComparison") then return false end
    if not tooltip or not comparisonItem or not C_TooltipComparison
        or type(C_TooltipComparison.GetItemComparisonInfo) ~= "function" then return false end

    local infoOK, comparisonInfo = pcall(C_TooltipComparison.GetItemComparisonInfo, comparisonItem)
    if not infoOK or not comparisonInfo or not comparisonInfo.item then return false end

    local added = false
    local candidateLines = getComparisonDerivedLines(comparisonItem, comparisonInfo.item)
    if candidateLines then
        added = appendComparisonRows(tooltip, candidateLines, "Derived stat changes:", comparisonItemKey(comparisonItem)) or added
    end

    -- The client can expose the ShoppingTooltip item differently from the
    -- comparison API's item object (GUID vs hyperlink), so matching those
    -- objects can fail even though this is the equipped panel. ShoppingTooltip
    -- frames are only used for the active side-by-side item comparison; apply
    -- the reverse delta to the first visible one.
    for _, equippedTooltip in ipairs({ ShoppingTooltip1, ShoppingTooltip2, ShoppingTooltip3 }) do
        if equippedTooltip and equippedTooltip.IsShown and equippedTooltip:IsShown()
            and (not equippedTooltip.NumLines or equippedTooltip:NumLines() > 0) then
            local reverseLines = getComparisonDerivedLines(comparisonInfo.item, comparisonItem)
            if reverseLines and #reverseLines > 0 then
                added = appendComparisonRows(equippedTooltip, reverseLines,
                    "Difference vs hovered item:", comparisonItemKey(comparisonItem)) or added
                break
            end
        end
    end
    return added
end

local comparisonTooltipHideHooked = setmetatable({}, { __mode = "k" })
local function queueTooltipComparison(tooltip, comparisonItem)
    if not comparisonEnabled("showTooltipComparison") then return end
    if not tooltip or not comparisonItem then return end
    if tooltip.HookScript and not comparisonTooltipHideHooked[tooltip] then
        tooltip:HookScript("OnHide", function(self)
            comparisonDerivedDisplayState[self] = nil
            pendingTooltipComparison[self] = nil
        end)
        comparisonTooltipHideHooked[tooltip] = true
    end
    pendingTooltipComparison[tooltip] = { item = comparisonItem, timeLeft = 2.5 }
    appendComparisonDerivedLines(tooltip, comparisonItem)
end

-- Conservative Forever-only seed data. Match the effect text, not arbitrary
-- percentages elsewhere on an item. Do not assume Classic rates or a generic PPM.
-- Sources: MaxDPS patch 70959 (Howling Hide), Wowhead Forever item 12802
-- (Darkspear), 13218/13227 (Spider's Kiss set; also wowforeveraddon.com).
local procEffectRates = {
    { fragment = "chance on hit to grant nearby party members 4% increased critical strike chance", label = "5% proc chance" },
    { fragment = "immobilizes the target and lowers their armor by 100 for 10 sec", label = "5% proc chance", setOnly = true },
    { fragment = "reduces the target enemy's attack power by 60 for 30 sec", label = "10% proc chance", itemID = 284262 },
}

local function annotateProcChance(text, tooltip)
    -- Strip only our own suffix so recycled font strings and repeated hooks are safe.
    local base = text:gsub("\n|cff65b5ff%([^\n]-%% proc chance%)|r$", "")
    if not StatGainsDB or StatGainsDB.showProcChance == false then return base end
    local plain = base:gsub("|c%x%x%x%x%x%x%x%x", ""):gsub("|r", "")
    plain = plain:gsub("|H.-|h(.-)|h", "%1"):lower():gsub("%s+", " ")
    local isSet = plain:match("^%s*%(%d+%)%s*set%s*:") or plain:match("^%s*set%s*:")
    if not (isSet or plain:match("^%s*equip%s*:") or plain:match("^%s*chance on hit%s*:")) then return base end
    -- A percentage describing a slow, stat bonus or damage is NOT a proc chance.
    -- Use only an explicitly stated probability adjacent to the word chance.
    local rate, ambiguous
    for value, nextPos in plain:gmatch("([%d%.]+)%%%s+chance()") do
        local n = tonumber(value)
        local tail = plain:sub(nextPos):match("^[^%.;]*") or ""
        if tail:match("^%s+to%s+hit%s*$") or tail:match("^%s+to%s+hit%s+with")
            or tail:match("^%s+to%s+crit") or tail:match("^%s+to%s+get%s+a%s+critical")
            or tail:match("^%s+to%s+dodge") or tail:match("^%s+to%s+parry")
            or tail:match("^%s+to%s+block") or tail:match("^%s+to%s+miss") then n = nil end
        if n and n > 0 and n <= 100 then
            if rate and rate ~= n then ambiguous = true end
            rate = n
        end
    end
    for value in plain:gmatch("chance%s+of%s+([%d%.]+)%%") do
        local n = tonumber(value)
        if n and n > 0 and n <= 100 then
            if rate and rate ~= n then ambiguous = true end
            rate = n
        end
    end
    if ambiguous then return base end
    -- Avoid duplicating a probability already explicitly listed as a proc chance.
    if plain:find("proc chance:", 1, true) or plain:find("proc chance", 1, true) then return base end
    local label = rate and (tostring(rate) .. "% proc chance") or nil
    if not label then
        for _, row in ipairs(procEffectRates) do
            if (not row.setOnly or isSet) and plain:find(row.fragment, 1, true) then
                local matches = not row.itemID
                if row.itemID and tooltip and tooltip.GetItem then
                    local ok, _, link = pcall(tooltip.GetItem, tooltip)
                    if ok and isUsableTooltipText(link) then
                        matches = tonumber(link:match("item:(%d+)")) == row.itemID
                    end
                end
                if matches then label = row.label; break end
            end
        end
    end
    if not label then return base end
    return base .. "\n|cff65b5ff(" .. label .. ")|r"
end

local function annotateItemTooltipText(text, classToken, raceToken, tooltip)
    -- Remove the proc annotation before the original stat parser checks parentheses.
    local base = text:gsub("\n|cff65b5ff%([^\n]-%% proc chance%)|r$", "")
    return annotateProcChance(deriveStatAnnotation(base, classToken, raceToken), tooltip)
end

local inlineTooltipLineState = setmetatable({}, { __mode = "k" })
local hookedTooltipFontStrings = setmetatable({}, { __mode = "k" })
local writingTooltipFontStrings = setmetatable({}, { __mode = "k" })
local pendingTooltipEnrichment = setmetatable({}, { __mode = "k" })

local function hookTooltipFontString(fontString, tooltip)
    if not fontString or hookedTooltipFontStrings[fontString]
        or not fontString.SetText or not hooksecurefunc then return end
    local ok = pcall(hooksecurefunc, fontString, "SetText", function(self, text)
        if writingTooltipFontStrings[self] or not isUsableTooltipText(text) then return end
        local _, classToken = UnitClass("player")
        local _, raceToken = UnitRace("player")
        local annotatedText = annotateItemTooltipText(text, classToken, raceToken, tooltip)
        if annotatedText ~= text then
            writingTooltipFontStrings[self] = true
            self:SetText(annotatedText)
            writingTooltipFontStrings[self] = nil
        end
    end)
    if ok then hookedTooltipFontStrings[fontString] = true end
end

local function enrichTooltipLines(tooltip, classToken, raceToken)
    local lineState = inlineTooltipLineState[tooltip]
    if not lineState then
        lineState = setmetatable({}, { __mode = "k" })
        inlineTooltipLineState[tooltip] = lineState
    end

    local changed = false
    local visitedFrames = {}
    local visitedFontStrings = {}
    local function processFontString(fontString)
        if not fontString or visitedFontStrings[fontString] or not fontString.GetText or not fontString.SetText then return end
        visitedFontStrings[fontString] = true
        hookTooltipFontString(fontString, tooltip)
        local currentText = fontString:GetText()
        if not isUsableTooltipText(currentText) then
            lineState[fontString] = nil
            return
        end
        local previous = lineState[fontString]
        local originalText = currentText
        if previous and currentText == previous.output then
            originalText = previous.original
        else
            previous = nil
        end
        local annotatedText = annotateItemTooltipText(originalText, classToken, raceToken, tooltip)
        if annotatedText ~= originalText then
            if currentText ~= annotatedText then fontString:SetText(annotatedText); changed = true end
            lineState[fontString] = { original = originalText, output = annotatedText }
        elseif previous or currentText ~= annotatedText then
            if currentText ~= annotatedText then fontString:SetText(annotatedText); changed = true end
            lineState[fontString] = nil
        end
    end

    local function scanFrame(owner, depth)
        if not owner or visitedFrames[owner] or depth > 5 then return end
        visitedFrames[owner] = true
        if owner.GetRegions then
            local regions = { owner:GetRegions() }
            for _, region in ipairs(regions) do
                processFontString(region)
            end
        end
        if owner.GetChildren then
            local children = { owner:GetChildren() }
            for _, child in ipairs(children) do
                scanFrame(child, depth + 1)
            end
        end
    end

    -- Process the standard tooltip lines first, then inspect nested regions too:
    -- some clients/addons create the replacement comparison text dynamically.
    local tooltipName = tooltip.GetName and tooltip:GetName()
    if tooltipName and tooltip.NumLines then
        for index = 1, tooltip:NumLines() do
            processFontString(_G[tooltipName .. "TextLeft" .. index])
            processFontString(_G[tooltipName .. "TextRight" .. index])
        end
    end
    scanFrame(tooltip, 0)
    if changed then tooltip:Show() end
end

local function appendDerivedStatsInternal(tooltip, tooltipData)
    if not tooltip then return end
    -- TooltipDataProcessor can pass comparison and addon-owned tooltip frames,
    -- not only GameTooltip and the two legacy ShoppingTooltips.
    if comparisonEnabled("showComparisonPanel") and tooltip == GameTooltip and IsShiftKeyDown and IsShiftKeyDown()
        and IsMouseButtonDown and IsMouseButtonDown("MiddleButton") then
        return
    end

    local _, classToken = UnitClass("player")
    local _, raceToken = UnitRace("player")
    enrichTooltipLines(tooltip, classToken, raceToken)
    -- WoW may append the built-in "If you replace this item" block after the
    -- item post-call. Recheck briefly so those later comparison lines receive
    -- the same annotations as the item's own stats.
    pendingTooltipEnrichment[tooltip] = 2.0

    -- The item post-call supplies the real item payload and runs even when the
    -- legacy comparison hook misses a refresh. Keep retrying until the paired
    -- equipped item has been resolved and both tooltip panels are annotated.
    if comparisonEnabled("showTooltipComparison") and tooltip == GameTooltip then
        local comparisonItem = getTooltipComparisonItem(tooltip)
        if not comparisonItem and type(tooltipData) == "table" then comparisonItem = tooltipData end
        if comparisonItem then queueTooltipComparison(tooltip, comparisonItem) end
    end
end

local tooltipErrorReported = false
local function appendDerivedStats(tooltip, tooltipData)
    -- A failure in an optional estimate must never interfere with the game's
    -- normal item tooltip. Report the first one so it can be diagnosed.
    local ok, err = pcall(appendDerivedStatsInternal, tooltip, tooltipData)
    if not ok and not tooltipErrorReported then
        tooltipErrorReported = true
        if DEFAULT_CHAT_FRAME then
            DEFAULT_CHAT_FRAME:AddMessage("Stat Gains tooltip error: " .. tostring(err), 1, 0.3, 0.3)
        end
    end
end

local hooked = {}
local function hookTooltip(tooltip)
    if tooltip and tooltip.HookScript and not hooked[tooltip] then
        tooltip:HookScript("OnTooltipSetItem", appendDerivedStats)
        hooked[tooltip] = true
    end
end

local comparisonFunctionHooked = false
local function hookComparisonBuilder()
    if comparisonFunctionHooked or not hooksecurefunc or type(GameTooltip_ShowCompareItem) ~= "function" then return end
    hooksecurefunc("GameTooltip_ShowCompareItem", function(tooltip)
        -- This is the legacy entry point used during comparison refreshes.
        local targetTooltip = tooltip or GameTooltip
        appendDerivedStats(targetTooltip)
        if comparisonEnabled("showTooltipComparison") then
            local comparisonItem = getTooltipComparisonItem(GameTooltip)
            if comparisonItem then queueTooltipComparison(GameTooltip, comparisonItem) end
        end
    end)
    comparisonFunctionHooked = true
end

local settingsFrame
local function showSettings()
    if type(StatGainsDB) ~= "table" then StatGainsDB = {} end
    if not settingsFrame then
        local panel = CreateFrame("Frame", "StatGainsSettingsFrame", UIParent)
        panel:SetSize(390, 254)
        panel:SetPoint("CENTER", UIParent, "CENTER")
        panel:SetFrameStrata("DIALOG")
        panel:SetToplevel(true)
        panel:EnableMouse(true)
        panel:SetMovable(true)
        panel:RegisterForDrag("LeftButton")
        panel:SetScript("OnDragStart", function(self) self:StartMoving() end)
        panel:SetScript("OnDragStop", function(self) self:StopMovingOrSizing() end)
        local bg = panel:CreateTexture(nil, "BACKGROUND")
        bg:SetTexture("Interface\\Buttons\\WHITE8X8")
        bg:SetVertexColor(0.035, 0.035, 0.035, 1)
        bg:SetAllPoints(panel)
        local title = panel:CreateFontString(nil, "OVERLAY", "GameFontNormalLarge")
        title:SetPoint("TOPLEFT", 18, -16)
        title:SetText("Stat Gains Settings")
        local close = CreateFrame("Button", nil, panel, "UIPanelCloseButton")
        close:SetPoint("TOPRIGHT", panel, "TOPRIGHT", -3, -3)
        close:SetScript("OnClick", function() panel:Hide() end)
        local checks = {}
        local function addCheck(key, labelText, y, defaultOn, onChanged)
            local check = CreateFrame("CheckButton", nil, panel, "UICheckButtonTemplate")
            check:SetSize(24, 24)
            check:SetPoint("TOPLEFT", 18, y)
            local label = check:CreateFontString(nil, "OVERLAY", "GameFontHighlight")
            label:SetPoint("LEFT", check, "RIGHT", 5, 0)
            label:SetText(labelText)
            checks[#checks + 1] = { check = check, key = key, defaultOn = defaultOn }
            check:SetScript("OnClick", function(self)
                StatGainsDB[key] = not not self:GetChecked()
                if onChanged then onChanged(StatGainsDB[key]) end
            end)
        end
        addCheck("showTooltipComparison", "Show extra tooltip comparison rows", -50, false, function(enabled)
            if not enabled then
                for tooltip in pairs(pendingTooltipComparison) do pendingTooltipComparison[tooltip] = nil end
            end
        end)
        addCheck("showComparisonPanel", "Enable Shift+middle-click comparison", -82, false, function(enabled)
            if not enabled and comparisonFrame and comparisonFrame:IsShown() then
                hideInspectionTooltip()
                comparisonFrame:Hide()
            end
        end)
        addCheck("showProcChance", "Show proc chance", -114, true)
        addCheck("meditation", "Account for Priest Meditation", -146, true)
        local help = panel:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
        help:SetPoint("TOPLEFT", 20, -184)
        help:SetWidth(350)
        help:SetJustifyH("LEFT")
        help:SetText("Reopen item tooltips after changing settings. Normal stat annotations and WoW's comparison remain available.")
        local version = panel:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
        version:SetPoint("BOTTOMLEFT", 18, 10)
        version:SetText("v" .. ADDON_VERSION)
        local footer = panel:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
        footer:SetPoint("BOTTOMRIGHT", -18, 10)
        footer:SetText("RIP Shady")
        panel:SetScript("OnShow", function()
            for _, entry in ipairs(checks) do
                local value = StatGainsDB[entry.key]
                if value == nil then value = entry.defaultOn end
                entry.check:SetChecked(value == true)
            end
        end)
        if type(UISpecialFrames) == "table" then
            table.insert(UISpecialFrames, "StatGainsSettingsFrame")
        end
        panel:Hide()
        settingsFrame = panel
    end
    if settingsFrame:IsShown() then settingsFrame:Hide() else settingsFrame:Show() end
end

SLASH_STATGAINSSETTINGS1 = "/statgains"
SlashCmdList.STATGAINSSETTINGS = showSettings

local frame = CreateFrame("Frame", ADDON_NAME .. "Frame")
local comparisonCallbackRegistered = false
frame:RegisterEvent("PLAYER_LOGIN")
frame:SetScript("OnEvent", function(self, event)
    if not comparisonCallbackRegistered and EventRegistry and EventRegistry.RegisterCallback then
        EventRegistry:RegisterCallback("TOOLTIP_SHOW_ITEM_COMPARISON", function(_, comparisonItem, comparisonTooltip)
            local targetTooltip = comparisonTooltip or GameTooltip
            appendDerivedStats(targetTooltip)
            queueTooltipComparison(GameTooltip, comparisonItem)
        end, frame)
        comparisonCallbackRegistered = true
    end
    if type(StatGainsDB) ~= "table" then StatGainsDB = {} end
    if StatGainsDB.meditation == nil then StatGainsDB.meditation = true end
    if StatGainsDB.showProcChance == nil then StatGainsDB.showProcChance = true end
    if type(StatGainsDB.showTooltipComparison) ~= "boolean" then StatGainsDB.showTooltipComparison = false end
    if type(StatGainsDB.showComparisonPanel) ~= "boolean" then StatGainsDB.showComparisonPanel = false end
    if StatGainsDB.scoreClass ~= "AUTO" and not CLASS_DISPLAY_NAMES[StatGainsDB.scoreClass] then
        StatGainsDB.scoreClass = "AUTO"
    end
    if StatGainsDB.scoreSpec ~= "AUTO" and type(StatGainsDB.scoreSpec) ~= "string" then
        StatGainsDB.scoreSpec = "AUTO"
    end
    hookComparisonBuilder()
    if TooltipDataProcessor and Enum and Enum.TooltipDataType and Enum.TooltipDataType.Item then
        TooltipDataProcessor.AddTooltipPostCall(Enum.TooltipDataType.Item, appendDerivedStats)
    else
        -- Compatibility fallback for older clients which still provide this
        -- tooltip script handler.
        hookTooltip(GameTooltip)
        hookTooltip(ItemRefTooltip)
        hookTooltip(ShoppingTooltip1)
        hookTooltip(ShoppingTooltip2)
        hookTooltip(ShoppingTooltip3)
    end
end)

-- Require the cursor to still be over the item tooltip's owner before opening
-- the comparison panel. This prevents a stale loot tooltip from making a
-- Shift+middle-click on another addon (for example Danders Frames) open it.
local function isHoveringCurrentItemTooltip()
    if not GameTooltip or not GameTooltip.IsShown or not GameTooltip:IsShown() then return false end
    if not getTooltipComparisonItem(GameTooltip) then return false end

    local owner = GameTooltip.GetOwner and GameTooltip:GetOwner()
    if not owner or owner == UIParent or owner == GameTooltip or not owner.IsMouseOver then return false end
    local ok, isMouseOver = pcall(owner.IsMouseOver, owner)
    return ok and isMouseOver == true
end

-- Shift+middle-click opens or closes the full comparison panel. Opening is
-- limited to when the cursor is over an item tooltip; closing remains available
-- from anywhere while the panel is open.
local lastComparisonChordDown = false
local tooltipScanElapsed = 0
frame:SetScript("OnUpdate", function(self, elapsed)
    tooltipScanElapsed = tooltipScanElapsed + (elapsed or 0)
    if tooltipScanElapsed >= 0.10 then
        local scanStep = tooltipScanElapsed
        tooltipScanElapsed = 0
        for tooltip, timeLeft in pairs(pendingTooltipEnrichment) do
            if not tooltip.IsShown or not tooltip:IsShown() then
                pendingTooltipEnrichment[tooltip] = nil
            else
                local _, classToken = UnitClass("player")
                local _, raceToken = UnitRace("player")
                enrichTooltipLines(tooltip, classToken, raceToken)
                timeLeft = timeLeft - scanStep
                if timeLeft <= 0 then
                    pendingTooltipEnrichment[tooltip] = nil
                else
                    pendingTooltipEnrichment[tooltip] = timeLeft
                end
            end
        end
        for tooltip, pending in pairs(pendingTooltipComparison) do
            if not comparisonEnabled("showTooltipComparison") or not tooltip.IsShown or not tooltip:IsShown() then
                pendingTooltipComparison[tooltip] = nil
            else
                appendComparisonDerivedLines(tooltip, pending.item)
                pending.timeLeft = pending.timeLeft - scanStep
                if pending.timeLeft <= 0 then pendingTooltipComparison[tooltip] = nil end
            end
        end
    end

    local comparisonChordDown = IsMouseButtonDown and IsMouseButtonDown("MiddleButton")
        and IsShiftKeyDown and IsShiftKeyDown() or false
    if comparisonChordDown == lastComparisonChordDown then return end
    lastComparisonChordDown = comparisonChordDown

    if comparisonChordDown and comparisonEnabled("showComparisonPanel") then
        if comparisonFrame and comparisonFrame:IsShown() then
            hideInspectionTooltip()
            comparisonFrame:Hide()
        elseif isHoveringCurrentItemTooltip() then
            showComparisonScreen()
        end
        return
    end

end)
